# For beginners, all code in a single file without functions

# Exercise 1: Basic Conditional Statements
x, y = 5, 8
board_size = 10

# Check if coordinates are within the valid range
if 0 <= x < board_size and 0 <= y < board_size:
    print(f"Coordinates ({x}, {y}) are valid: True")
else:
    print(f"Coordinates ({x}, {y}) are valid: False")

x, y = 10, -1

if 0 <= x < board_size and 0 <= y < board_size:
    print(f"Coordinates ({x}, {y}) are valid: True")
else:
    print(f"Coordinates ({x}, {y}) are valid: False")

# Exercise 2: Conditional with Logical Operators
x, y, orientation = 4, 6, 'horizontal'
valid_orientations = ['horizontal', 'vertical']

# Validate user input for coordinates and orientation
if 0 <= x < board_size and 0 <= y < board_size and orientation in valid_orientations:
    print(f"Input ({x}, {y}, {orientation}) is valid: True")
else:
    print(f"Input ({x}, {y}, {orientation}) is valid: False")

x, y, orientation = 11, 3, 'diagonal'

if 0 <= x < board_size and 0 <= y < board_size and orientation in valid_orientations:
    print(f"Input ({x}, {y}, {orientation}) is valid: True")
else:
    print(f"Input ({x}, {y}, {orientation}) is valid: False")

# Exercise 3: Nested Conditionals
x, y, ship_length, orientation = 3, 5, 4, 'horizontal'

# Validate the placement of a ship
if orientation == 'horizontal':
    if x + ship_length <= board_size:
        print(f"Placement ({x}, {y}, {ship_length}, {orientation}) is valid: True")
    else:
        print(f"Placement ({x}, {y}, {ship_length}, {orientation}) is valid: False")
elif orientation == 'vertical':
    if y + ship_length <= board_size:
        print(f"Placement ({x}, {y}, {ship_length}, {orientation}) is valid: True")
    else:
        print(f"Placement ({x}, {y}, {ship_length}, {orientation}) is valid: False")
else:
    print(f"Placement ({x}, {y}, {ship_length}, {orientation}) is valid: False")

x, y, ship_length, orientation = 7, 7, 4, 'vertical'

if orientation == 'horizontal':
    if x + ship_length <= board_size:
        print(f"Placement ({x}, {y}, {ship_length}, {orientation}) is valid: True")
    else:
        print(f"Placement ({x}, {y}, {ship_length}, {orientation}) is valid: False")
elif orientation == 'vertical':
    if y + ship_length <= board_size:
        print(f"Placement ({x}, {y}, {ship_length}, {orientation}) is valid: True")
    else:
        print(f"Placement ({x}, {y}, {ship_length}, {orientation}) is valid: False")
else:
    print(f"Placement ({x}, {y}, {ship_length}, {orientation}) is valid: False")
