board_size = 10
# Initialize a board_sizexboard_size game board with all cells set to 0 (empty)

board = [[0 for i in range(board_size)] for j in range(board_size)]


# While loop to repeatedly ask for valid attack coordinates
while True:
        row = int(input("Enter attack row (0-9): "))
        col = int(input("Enter attack column (0-9): "))
        
        # Check if coordinates are within the valid range
        if 0 <= row < board_size and 0 <= col < board_size:
            print(f"Coordinates ({row}, {col}) are valid: True")
            board[row][col] = 1
            break
        else:
            print(f"Coordinates ({row}, {col}) are valid: False")
            print("Please enter again")
    
# For loop to iterate through each row and column of the board
for row in range(board_size):
    for col in range(board_size):
        # Print the state of each cell (0 for empty, 1 for ship)
        print(board[row][col], end=' ')
    print()  # Move to the next line after printing each row
