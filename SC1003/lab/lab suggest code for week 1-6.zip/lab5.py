board_size = 10

# Get the start position for the Carrier
print("Please enter start_position of Carrier in the following format (row,col). E.g. 6,4")
user_input_c = input("Enter coordinates: ")

# Split the string at the comma and convert to a tuple of integers
start_c = tuple(map(int, user_input_c.split(',')))

# Get the start position for the Submarine
print("Please enter start_position of Submarine in the following format (row,col). E.g. 6,4")
user_input_s = input("Enter coordinates: ")

# Split the string at the comma and convert to a tuple of integers
start_s = tuple(map(int, user_input_s.split(',')))

# Dictionary to store ship details (name, length, and starting coordinates)
ships = {
    "Carrier": {"length": 5, "start_position": start_c},  # Tuple for starting position
    "Submarine": {"length": 3, "start_position": start_s},
}

# Initialize a board_size x board_size game board with all cells set to 0 (empty)
board = [[0 for i in range(board_size)] for j in range(board_size)]

# Function to place ships on the board based on their start position and length
def place_ship(ship_name):
    ship = ships[ship_name]
    start_row, start_col = ship["start_position"]
    length = ship["length"]
    
    # Place the ship horizontally on the board using a for loop
    for i in range(length):
        board[start_row][start_col + i] = "S"

# Place the ships on the board
place_ship("Carrier")
place_ship("Submarine")

# While loop to repeatedly ask for valid attack coordinates
while True:
    row = int(input("Enter attack row (0-9): "))
    col = int(input("Enter attack column (0-9): "))
    
    # Check if coordinates are within the valid range
    if 0 <= row < board_size and 0 <= col < board_size:
        print(f"Coordinates ({row}, {col}) are valid: True")
        board[row][col] = 1  # Mark the attack on the board
        break
    else:
        print(f"Coordinates ({row}, {col}) are valid: False")
        print("Please enter again")

# For loop to iterate through each row and column of the board
for row in range(board_size):
    for col in range(board_size):
        # Print the state of each cell (0 for empty, 1 for ship, 2 for attacked)
        print(board[row][col], end=' ')
    print()  # Move to the next line after printing each row
