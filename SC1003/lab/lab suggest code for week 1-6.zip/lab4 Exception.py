# Initialize a 10x10 game board with all cells set to 0 (empty)
board = [[0 for _ in range(10)] for _ in range(10)]

# Function to check if input coordinates are valid
def is_valid_coordinate(row, col):
    return 0 <= row < 10 and 0 <= col < 10

# While loop to repeatedly ask for valid attack coordinates
while True:
    try:
        row = int(input("Enter attack row (0-9): "))
        col = int(input("Enter attack column (0-9): "))
        
        if is_valid_coordinate(row, col):
            print(f"Attack coordinates accepted: ({row}, {col})")
            board[row][col] = 1 
            break  # Exit the loop if valid input is received
        else:
            print("Invalid coordinates. Please enter values between 0 and 9.")
    
    except ValueError:
        print("Invalid input. Please enter numeric values.")

# For loop to iterate through each row and column of the board
for row in range(10):
    for col in range(10):
        # Print the state of each cell (0 for empty, 1 for ship)
        print(board[row][col], end=' ')
    print()  # Move to the next line after printing each row
