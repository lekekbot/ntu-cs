# Constants
BOARD_SIZE = 10

# Function 1: Initialize an empty board
def init_board():
    # Return a BOARD_SIZE x BOARD_SIZE list of lists with all cells set to "0"
    return [["0" for _ in range(BOARD_SIZE)] for _ in range(BOARD_SIZE)]

# Function 2: Get starting position for a ship
def get_ship_position(ship_name):
    # Prompt the user for coordinates in "row,col" format and return a tuple of ints
    while True:
        s = input(f"Please enter start_position of {ship_name} (row,col): ").strip()
        try:
            r_str, c_str = s.split(",")
            r, c = int(r_str), int(c_str)
            return (r, c)
        except Exception:
            print("Invalid format. Please enter as row,col (e.g., 4,1).")

# Function 3: Place ship on the board (horizontal to the right)
def place_ship(board, start_pos, length, symbol):
    r, c = start_pos
    # Simple bounds & overlap check
    if r < 0 or r >= BOARD_SIZE or c < 0 or c + length - 1 >= BOARD_SIZE:
        print(f"Cannot place {symbol}: out of bounds. Skipping placement.")
        return
    for cc in range(c, c + length):
        if board[r][cc] != "0":
            print(f"Cannot place {symbol}: overlaps another ship. Skipping placement.")
            return
    # Place the ship
    for cc in range(c, c + length):
        board[r][cc] = symbol

# Function 4: Display the board
def display_board(board):
    for row in board:
        print(" ".join(row))

# Function 5: Check attack validity
def check_attack(board, row, col):
    # Return True if coordinates are within range, else False
    return 0 <= row < BOARD_SIZE and 0 <= col < BOARD_SIZE

# -----------------------
# Main Program
# -----------------------

# Initialize board
game_board = init_board()

# Dictionary to store ships: name, length, symbol
ships = {
    "Carrier": {"length": 5, "symbol": "C"},
    "Submarine": {"length": 3, "symbol": "S"}
}

# Get and place each ship
for name, details in ships.items():
    start_pos = get_ship_position(name)
    place_ship(game_board, start_pos, details["length"], details["symbol"])

# Display the final board with ships placed
display_board(game_board)

# Example attack check
attack_row = int(input("Enter attack row (0-9): "))
attack_col = int(input("Enter attack column (0-9): "))
print("Valid attack?", check_attack(game_board, attack_row, attack_col))
