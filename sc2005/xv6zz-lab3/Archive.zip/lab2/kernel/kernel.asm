
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00008117          	auipc	sp,0x8
    80000004:	91010113          	addi	sp,sp,-1776 # 80007910 <stack0>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	04e000ef          	jal	80000064 <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e406                	sd	ra,8(sp)
    80000020:	e022                	sd	s0,0(sp)
    80000022:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000024:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000028:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002c:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80000030:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000034:	577d                	li	a4,-1
    80000036:	177e                	slli	a4,a4,0x3f
    80000038:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    8000003a:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003e:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000042:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000046:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    8000004a:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    8000004e:	000f4737          	lui	a4,0xf4
    80000052:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000056:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000058:	14d79073          	csrw	stimecmp,a5
}
    8000005c:	60a2                	ld	ra,8(sp)
    8000005e:	6402                	ld	s0,0(sp)
    80000060:	0141                	addi	sp,sp,16
    80000062:	8082                	ret

0000000080000064 <start>:
{
    80000064:	1141                	addi	sp,sp,-16
    80000066:	e406                	sd	ra,8(sp)
    80000068:	e022                	sd	s0,0(sp)
    8000006a:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    8000006c:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000070:	7779                	lui	a4,0xffffe
    80000072:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffddbbf>
    80000076:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000078:	6705                	lui	a4,0x1
    8000007a:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000007e:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80000080:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80000084:	00001797          	auipc	a5,0x1
    80000088:	e5878793          	addi	a5,a5,-424 # 80000edc <main>
    8000008c:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80000090:	4781                	li	a5,0
    80000092:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000096:	67c1                	lui	a5,0x10
    80000098:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000009a:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    8000009e:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    800000a2:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    800000a6:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r" (x));
    800000aa:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000ae:	57fd                	li	a5,-1
    800000b0:	83a9                	srli	a5,a5,0xa
    800000b2:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b6:	47bd                	li	a5,15
    800000b8:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000bc:	f61ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000c0:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c4:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c6:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c8:	30200073          	mret
}
    800000cc:	60a2                	ld	ra,8(sp)
    800000ce:	6402                	ld	s0,0(sp)
    800000d0:	0141                	addi	sp,sp,16
    800000d2:	8082                	ret

00000000800000d4 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d4:	711d                	addi	sp,sp,-96
    800000d6:	ec86                	sd	ra,88(sp)
    800000d8:	e8a2                	sd	s0,80(sp)
    800000da:	e0ca                	sd	s2,64(sp)
    800000dc:	1080                	addi	s0,sp,96
  int i;

  for(i = 0; i < n; i++){
    800000de:	04c05763          	blez	a2,8000012c <consolewrite+0x58>
    800000e2:	e4a6                	sd	s1,72(sp)
    800000e4:	fc4e                	sd	s3,56(sp)
    800000e6:	f852                	sd	s4,48(sp)
    800000e8:	f456                	sd	s5,40(sp)
    800000ea:	f05a                	sd	s6,32(sp)
    800000ec:	ec5e                	sd	s7,24(sp)
    800000ee:	8a2a                	mv	s4,a0
    800000f0:	84ae                	mv	s1,a1
    800000f2:	89b2                	mv	s3,a2
    800000f4:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    800000f6:	faf40b93          	addi	s7,s0,-81
    800000fa:	4b05                	li	s6,1
    800000fc:	5afd                	li	s5,-1
    800000fe:	86da                	mv	a3,s6
    80000100:	8626                	mv	a2,s1
    80000102:	85d2                	mv	a1,s4
    80000104:	855e                	mv	a0,s7
    80000106:	17c020ef          	jal	80002282 <either_copyin>
    8000010a:	03550363          	beq	a0,s5,80000130 <consolewrite+0x5c>
      break;
    uartputc(c);
    8000010e:	faf44503          	lbu	a0,-81(s0)
    80000112:	06b000ef          	jal	8000097c <uartputc>
  for(i = 0; i < n; i++){
    80000116:	2905                	addiw	s2,s2,1
    80000118:	0485                	addi	s1,s1,1
    8000011a:	ff2992e3          	bne	s3,s2,800000fe <consolewrite+0x2a>
    8000011e:	64a6                	ld	s1,72(sp)
    80000120:	79e2                	ld	s3,56(sp)
    80000122:	7a42                	ld	s4,48(sp)
    80000124:	7aa2                	ld	s5,40(sp)
    80000126:	7b02                	ld	s6,32(sp)
    80000128:	6be2                	ld	s7,24(sp)
    8000012a:	a809                	j	8000013c <consolewrite+0x68>
    8000012c:	4901                	li	s2,0
    8000012e:	a039                	j	8000013c <consolewrite+0x68>
    80000130:	64a6                	ld	s1,72(sp)
    80000132:	79e2                	ld	s3,56(sp)
    80000134:	7a42                	ld	s4,48(sp)
    80000136:	7aa2                	ld	s5,40(sp)
    80000138:	7b02                	ld	s6,32(sp)
    8000013a:	6be2                	ld	s7,24(sp)
  }

  return i;
}
    8000013c:	854a                	mv	a0,s2
    8000013e:	60e6                	ld	ra,88(sp)
    80000140:	6446                	ld	s0,80(sp)
    80000142:	6906                	ld	s2,64(sp)
    80000144:	6125                	addi	sp,sp,96
    80000146:	8082                	ret

0000000080000148 <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000148:	711d                	addi	sp,sp,-96
    8000014a:	ec86                	sd	ra,88(sp)
    8000014c:	e8a2                	sd	s0,80(sp)
    8000014e:	e4a6                	sd	s1,72(sp)
    80000150:	e0ca                	sd	s2,64(sp)
    80000152:	fc4e                	sd	s3,56(sp)
    80000154:	f852                	sd	s4,48(sp)
    80000156:	f05a                	sd	s6,32(sp)
    80000158:	ec5e                	sd	s7,24(sp)
    8000015a:	1080                	addi	s0,sp,96
    8000015c:	8b2a                	mv	s6,a0
    8000015e:	8a2e                	mv	s4,a1
    80000160:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000162:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80000164:	0000f517          	auipc	a0,0xf
    80000168:	7ac50513          	addi	a0,a0,1964 # 8000f910 <cons>
    8000016c:	2f9000ef          	jal	80000c64 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80000170:	0000f497          	auipc	s1,0xf
    80000174:	7a048493          	addi	s1,s1,1952 # 8000f910 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    80000178:	00010917          	auipc	s2,0x10
    8000017c:	83090913          	addi	s2,s2,-2000 # 8000f9a8 <cons+0x98>
  while(n > 0){
    80000180:	0b305b63          	blez	s3,80000236 <consoleread+0xee>
    while(cons.r == cons.w){
    80000184:	0984a783          	lw	a5,152(s1)
    80000188:	09c4a703          	lw	a4,156(s1)
    8000018c:	0af71063          	bne	a4,a5,8000022c <consoleread+0xe4>
      if(killed(myproc())){
    80000190:	794010ef          	jal	80001924 <myproc>
    80000194:	789010ef          	jal	8000211c <killed>
    80000198:	e12d                	bnez	a0,800001fa <consoleread+0xb2>
      sleep(&cons.r, &cons.lock);
    8000019a:	85a6                	mv	a1,s1
    8000019c:	854a                	mv	a0,s2
    8000019e:	543010ef          	jal	80001ee0 <sleep>
    while(cons.r == cons.w){
    800001a2:	0984a783          	lw	a5,152(s1)
    800001a6:	09c4a703          	lw	a4,156(s1)
    800001aa:	fef703e3          	beq	a4,a5,80000190 <consoleread+0x48>
    800001ae:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001b0:	0000f717          	auipc	a4,0xf
    800001b4:	76070713          	addi	a4,a4,1888 # 8000f910 <cons>
    800001b8:	0017869b          	addiw	a3,a5,1
    800001bc:	08d72c23          	sw	a3,152(a4)
    800001c0:	07f7f693          	andi	a3,a5,127
    800001c4:	9736                	add	a4,a4,a3
    800001c6:	01874703          	lbu	a4,24(a4)
    800001ca:	00070a9b          	sext.w	s5,a4

    if(c == C('D')){  // end-of-file
    800001ce:	4691                	li	a3,4
    800001d0:	04da8663          	beq	s5,a3,8000021c <consoleread+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    800001d4:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    800001d8:	4685                	li	a3,1
    800001da:	faf40613          	addi	a2,s0,-81
    800001de:	85d2                	mv	a1,s4
    800001e0:	855a                	mv	a0,s6
    800001e2:	056020ef          	jal	80002238 <either_copyout>
    800001e6:	57fd                	li	a5,-1
    800001e8:	04f50663          	beq	a0,a5,80000234 <consoleread+0xec>
      break;

    dst++;
    800001ec:	0a05                	addi	s4,s4,1
    --n;
    800001ee:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    800001f0:	47a9                	li	a5,10
    800001f2:	04fa8b63          	beq	s5,a5,80000248 <consoleread+0x100>
    800001f6:	7aa2                	ld	s5,40(sp)
    800001f8:	b761                	j	80000180 <consoleread+0x38>
        release(&cons.lock);
    800001fa:	0000f517          	auipc	a0,0xf
    800001fe:	71650513          	addi	a0,a0,1814 # 8000f910 <cons>
    80000202:	2f3000ef          	jal	80000cf4 <release>
        return -1;
    80000206:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000208:	60e6                	ld	ra,88(sp)
    8000020a:	6446                	ld	s0,80(sp)
    8000020c:	64a6                	ld	s1,72(sp)
    8000020e:	6906                	ld	s2,64(sp)
    80000210:	79e2                	ld	s3,56(sp)
    80000212:	7a42                	ld	s4,48(sp)
    80000214:	7b02                	ld	s6,32(sp)
    80000216:	6be2                	ld	s7,24(sp)
    80000218:	6125                	addi	sp,sp,96
    8000021a:	8082                	ret
      if(n < target){
    8000021c:	0179fa63          	bgeu	s3,s7,80000230 <consoleread+0xe8>
        cons.r--;
    80000220:	0000f717          	auipc	a4,0xf
    80000224:	78f72423          	sw	a5,1928(a4) # 8000f9a8 <cons+0x98>
    80000228:	7aa2                	ld	s5,40(sp)
    8000022a:	a031                	j	80000236 <consoleread+0xee>
    8000022c:	f456                	sd	s5,40(sp)
    8000022e:	b749                	j	800001b0 <consoleread+0x68>
    80000230:	7aa2                	ld	s5,40(sp)
    80000232:	a011                	j	80000236 <consoleread+0xee>
    80000234:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80000236:	0000f517          	auipc	a0,0xf
    8000023a:	6da50513          	addi	a0,a0,1754 # 8000f910 <cons>
    8000023e:	2b7000ef          	jal	80000cf4 <release>
  return target - n;
    80000242:	413b853b          	subw	a0,s7,s3
    80000246:	b7c9                	j	80000208 <consoleread+0xc0>
    80000248:	7aa2                	ld	s5,40(sp)
    8000024a:	b7f5                	j	80000236 <consoleread+0xee>

000000008000024c <consputc>:
{
    8000024c:	1141                	addi	sp,sp,-16
    8000024e:	e406                	sd	ra,8(sp)
    80000250:	e022                	sd	s0,0(sp)
    80000252:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000254:	10000793          	li	a5,256
    80000258:	00f50863          	beq	a0,a5,80000268 <consputc+0x1c>
    uartputc_sync(c);
    8000025c:	652000ef          	jal	800008ae <uartputc_sync>
}
    80000260:	60a2                	ld	ra,8(sp)
    80000262:	6402                	ld	s0,0(sp)
    80000264:	0141                	addi	sp,sp,16
    80000266:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80000268:	4521                	li	a0,8
    8000026a:	644000ef          	jal	800008ae <uartputc_sync>
    8000026e:	02000513          	li	a0,32
    80000272:	63c000ef          	jal	800008ae <uartputc_sync>
    80000276:	4521                	li	a0,8
    80000278:	636000ef          	jal	800008ae <uartputc_sync>
    8000027c:	b7d5                	j	80000260 <consputc+0x14>

000000008000027e <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    8000027e:	1101                	addi	sp,sp,-32
    80000280:	ec06                	sd	ra,24(sp)
    80000282:	e822                	sd	s0,16(sp)
    80000284:	e426                	sd	s1,8(sp)
    80000286:	1000                	addi	s0,sp,32
    80000288:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    8000028a:	0000f517          	auipc	a0,0xf
    8000028e:	68650513          	addi	a0,a0,1670 # 8000f910 <cons>
    80000292:	1d3000ef          	jal	80000c64 <acquire>

  switch(c){
    80000296:	47d5                	li	a5,21
    80000298:	0af48163          	beq	s1,a5,8000033a <consoleintr+0xbc>
    8000029c:	0297c563          	blt	a5,s1,800002c6 <consoleintr+0x48>
    800002a0:	47a1                	li	a5,8
    800002a2:	0ef48663          	beq	s1,a5,8000038e <consoleintr+0x110>
    800002a6:	47c1                	li	a5,16
    800002a8:	10f49763          	bne	s1,a5,800003b6 <consoleintr+0x138>
  case C('P'):  // Print process list.
    procdump();
    800002ac:	020020ef          	jal	800022cc <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002b0:	0000f517          	auipc	a0,0xf
    800002b4:	66050513          	addi	a0,a0,1632 # 8000f910 <cons>
    800002b8:	23d000ef          	jal	80000cf4 <release>
}
    800002bc:	60e2                	ld	ra,24(sp)
    800002be:	6442                	ld	s0,16(sp)
    800002c0:	64a2                	ld	s1,8(sp)
    800002c2:	6105                	addi	sp,sp,32
    800002c4:	8082                	ret
  switch(c){
    800002c6:	07f00793          	li	a5,127
    800002ca:	0cf48263          	beq	s1,a5,8000038e <consoleintr+0x110>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002ce:	0000f717          	auipc	a4,0xf
    800002d2:	64270713          	addi	a4,a4,1602 # 8000f910 <cons>
    800002d6:	0a072783          	lw	a5,160(a4)
    800002da:	09872703          	lw	a4,152(a4)
    800002de:	9f99                	subw	a5,a5,a4
    800002e0:	07f00713          	li	a4,127
    800002e4:	fcf766e3          	bltu	a4,a5,800002b0 <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    800002e8:	47b5                	li	a5,13
    800002ea:	0cf48963          	beq	s1,a5,800003bc <consoleintr+0x13e>
      consputc(c);
    800002ee:	8526                	mv	a0,s1
    800002f0:	f5dff0ef          	jal	8000024c <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800002f4:	0000f717          	auipc	a4,0xf
    800002f8:	61c70713          	addi	a4,a4,1564 # 8000f910 <cons>
    800002fc:	0a072683          	lw	a3,160(a4)
    80000300:	0016879b          	addiw	a5,a3,1
    80000304:	863e                	mv	a2,a5
    80000306:	0af72023          	sw	a5,160(a4)
    8000030a:	07f6f693          	andi	a3,a3,127
    8000030e:	9736                	add	a4,a4,a3
    80000310:	00970c23          	sb	s1,24(a4)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80000314:	ff648713          	addi	a4,s1,-10
    80000318:	00173713          	seqz	a4,a4
    8000031c:	14f1                	addi	s1,s1,-4
    8000031e:	0014b493          	seqz	s1,s1
    80000322:	8f45                	or	a4,a4,s1
    80000324:	e361                	bnez	a4,800003e4 <consoleintr+0x166>
    80000326:	0000f717          	auipc	a4,0xf
    8000032a:	68272703          	lw	a4,1666(a4) # 8000f9a8 <cons+0x98>
    8000032e:	9f99                	subw	a5,a5,a4
    80000330:	08000713          	li	a4,128
    80000334:	f6e79ee3          	bne	a5,a4,800002b0 <consoleintr+0x32>
    80000338:	a075                	j	800003e4 <consoleintr+0x166>
    8000033a:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    8000033c:	0000f717          	auipc	a4,0xf
    80000340:	5d470713          	addi	a4,a4,1492 # 8000f910 <cons>
    80000344:	0a072783          	lw	a5,160(a4)
    80000348:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    8000034c:	0000f497          	auipc	s1,0xf
    80000350:	5c448493          	addi	s1,s1,1476 # 8000f910 <cons>
    while(cons.e != cons.w &&
    80000354:	4929                	li	s2,10
    80000356:	02f70863          	beq	a4,a5,80000386 <consoleintr+0x108>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    8000035a:	37fd                	addiw	a5,a5,-1
    8000035c:	07f7f713          	andi	a4,a5,127
    80000360:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    80000362:	01874703          	lbu	a4,24(a4)
    80000366:	03270263          	beq	a4,s2,8000038a <consoleintr+0x10c>
      cons.e--;
    8000036a:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    8000036e:	10000513          	li	a0,256
    80000372:	edbff0ef          	jal	8000024c <consputc>
    while(cons.e != cons.w &&
    80000376:	0a04a783          	lw	a5,160(s1)
    8000037a:	09c4a703          	lw	a4,156(s1)
    8000037e:	fcf71ee3          	bne	a4,a5,8000035a <consoleintr+0xdc>
    80000382:	6902                	ld	s2,0(sp)
    80000384:	b735                	j	800002b0 <consoleintr+0x32>
    80000386:	6902                	ld	s2,0(sp)
    80000388:	b725                	j	800002b0 <consoleintr+0x32>
    8000038a:	6902                	ld	s2,0(sp)
    8000038c:	b715                	j	800002b0 <consoleintr+0x32>
    if(cons.e != cons.w){
    8000038e:	0000f717          	auipc	a4,0xf
    80000392:	58270713          	addi	a4,a4,1410 # 8000f910 <cons>
    80000396:	0a072783          	lw	a5,160(a4)
    8000039a:	09c72703          	lw	a4,156(a4)
    8000039e:	f0f709e3          	beq	a4,a5,800002b0 <consoleintr+0x32>
      cons.e--;
    800003a2:	37fd                	addiw	a5,a5,-1
    800003a4:	0000f717          	auipc	a4,0xf
    800003a8:	60f72623          	sw	a5,1548(a4) # 8000f9b0 <cons+0xa0>
      consputc(BACKSPACE);
    800003ac:	10000513          	li	a0,256
    800003b0:	e9dff0ef          	jal	8000024c <consputc>
    800003b4:	bdf5                	j	800002b0 <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800003b6:	ee048de3          	beqz	s1,800002b0 <consoleintr+0x32>
    800003ba:	bf11                	j	800002ce <consoleintr+0x50>
      consputc(c);
    800003bc:	4529                	li	a0,10
    800003be:	e8fff0ef          	jal	8000024c <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003c2:	0000f797          	auipc	a5,0xf
    800003c6:	54e78793          	addi	a5,a5,1358 # 8000f910 <cons>
    800003ca:	0a07a703          	lw	a4,160(a5)
    800003ce:	0017069b          	addiw	a3,a4,1
    800003d2:	8636                	mv	a2,a3
    800003d4:	0ad7a023          	sw	a3,160(a5)
    800003d8:	07f77713          	andi	a4,a4,127
    800003dc:	97ba                	add	a5,a5,a4
    800003de:	4729                	li	a4,10
    800003e0:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    800003e4:	0000f797          	auipc	a5,0xf
    800003e8:	5cc7a423          	sw	a2,1480(a5) # 8000f9ac <cons+0x9c>
        wakeup(&cons.r);
    800003ec:	0000f517          	auipc	a0,0xf
    800003f0:	5bc50513          	addi	a0,a0,1468 # 8000f9a8 <cons+0x98>
    800003f4:	339010ef          	jal	80001f2c <wakeup>
    800003f8:	bd65                	j	800002b0 <consoleintr+0x32>

00000000800003fa <consoleinit>:

void
consoleinit(void)
{
    800003fa:	1141                	addi	sp,sp,-16
    800003fc:	e406                	sd	ra,8(sp)
    800003fe:	e022                	sd	s0,0(sp)
    80000400:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000402:	00007597          	auipc	a1,0x7
    80000406:	bfe58593          	addi	a1,a1,-1026 # 80007000 <etext>
    8000040a:	0000f517          	auipc	a0,0xf
    8000040e:	50650513          	addi	a0,a0,1286 # 8000f910 <cons>
    80000412:	7c8000ef          	jal	80000bda <initlock>

  uartinit();
    80000416:	442000ef          	jal	80000858 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    8000041a:	0001f797          	auipc	a5,0x1f
    8000041e:	68e78793          	addi	a5,a5,1678 # 8001faa8 <devsw>
    80000422:	00000717          	auipc	a4,0x0
    80000426:	d2670713          	addi	a4,a4,-730 # 80000148 <consoleread>
    8000042a:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    8000042c:	00000717          	auipc	a4,0x0
    80000430:	ca870713          	addi	a4,a4,-856 # 800000d4 <consolewrite>
    80000434:	ef98                	sd	a4,24(a5)
}
    80000436:	60a2                	ld	ra,8(sp)
    80000438:	6402                	ld	s0,0(sp)
    8000043a:	0141                	addi	sp,sp,16
    8000043c:	8082                	ret

000000008000043e <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    8000043e:	7139                	addi	sp,sp,-64
    80000440:	fc06                	sd	ra,56(sp)
    80000442:	f822                	sd	s0,48(sp)
    80000444:	f04a                	sd	s2,32(sp)
    80000446:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    80000448:	c219                	beqz	a2,8000044e <printint+0x10>
    8000044a:	08054063          	bltz	a0,800004ca <printint+0x8c>
    x = -xx;
  else
    x = xx;
    8000044e:	4301                	li	t1,0

  i = 0;
    80000450:	fc840913          	addi	s2,s0,-56
    x = xx;
    80000454:	86ca                	mv	a3,s2
  i = 0;
    80000456:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    80000458:	00007817          	auipc	a6,0x7
    8000045c:	31880813          	addi	a6,a6,792 # 80007770 <digits>
    80000460:	88ba                	mv	a7,a4
    80000462:	0017061b          	addiw	a2,a4,1
    80000466:	8732                	mv	a4,a2
    80000468:	02b577b3          	remu	a5,a0,a1
    8000046c:	97c2                	add	a5,a5,a6
    8000046e:	0007c783          	lbu	a5,0(a5)
    80000472:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    80000476:	87aa                	mv	a5,a0
    80000478:	02b55533          	divu	a0,a0,a1
    8000047c:	0685                	addi	a3,a3,1
    8000047e:	feb7f1e3          	bgeu	a5,a1,80000460 <printint+0x22>

  if(sign)
    80000482:	00030b63          	beqz	t1,80000498 <printint+0x5a>
    buf[i++] = '-';
    80000486:	fe040793          	addi	a5,s0,-32
    8000048a:	963e                	add	a2,a2,a5
    8000048c:	02d00793          	li	a5,45
    80000490:	fef60423          	sb	a5,-24(a2)
    80000494:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    80000498:	02e05463          	blez	a4,800004c0 <printint+0x82>
    8000049c:	f426                	sd	s1,40(sp)
    8000049e:	377d                	addiw	a4,a4,-1
    800004a0:	00e904b3          	add	s1,s2,a4
    800004a4:	197d                	addi	s2,s2,-1
    800004a6:	993a                	add	s2,s2,a4
    800004a8:	1702                	slli	a4,a4,0x20
    800004aa:	9301                	srli	a4,a4,0x20
    800004ac:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    800004b0:	0004c503          	lbu	a0,0(s1)
    800004b4:	d99ff0ef          	jal	8000024c <consputc>
  while(--i >= 0)
    800004b8:	14fd                	addi	s1,s1,-1
    800004ba:	ff249be3          	bne	s1,s2,800004b0 <printint+0x72>
    800004be:	74a2                	ld	s1,40(sp)
}
    800004c0:	70e2                	ld	ra,56(sp)
    800004c2:	7442                	ld	s0,48(sp)
    800004c4:	7902                	ld	s2,32(sp)
    800004c6:	6121                	addi	sp,sp,64
    800004c8:	8082                	ret
    x = -xx;
    800004ca:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800004ce:	4305                	li	t1,1
    x = -xx;
    800004d0:	b741                	j	80000450 <printint+0x12>

00000000800004d2 <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004d2:	7131                	addi	sp,sp,-192
    800004d4:	fc86                	sd	ra,120(sp)
    800004d6:	f8a2                	sd	s0,112(sp)
    800004d8:	f4a6                	sd	s1,104(sp)
    800004da:	ec6e                	sd	s11,24(sp)
    800004dc:	0100                	addi	s0,sp,128
    800004de:	84aa                	mv	s1,a0
    800004e0:	e40c                	sd	a1,8(s0)
    800004e2:	e810                	sd	a2,16(s0)
    800004e4:	ec14                	sd	a3,24(s0)
    800004e6:	f018                	sd	a4,32(s0)
    800004e8:	f41c                	sd	a5,40(s0)
    800004ea:	03043823          	sd	a6,48(s0)
    800004ee:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2, locking;
  char *s;

  locking = pr.locking;
    800004f2:	0000fd97          	auipc	s11,0xf
    800004f6:	4dedad83          	lw	s11,1246(s11) # 8000f9d0 <pr+0x18>
  if(locking)
    800004fa:	020d9d63          	bnez	s11,80000534 <printf+0x62>
    acquire(&pr.lock);

  va_start(ap, fmt);
    800004fe:	00840793          	addi	a5,s0,8
    80000502:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000506:	00054503          	lbu	a0,0(a0)
    8000050a:	20050c63          	beqz	a0,80000722 <printf+0x250>
    8000050e:	f0ca                	sd	s2,96(sp)
    80000510:	ecce                	sd	s3,88(sp)
    80000512:	e8d2                	sd	s4,80(sp)
    80000514:	e4d6                	sd	s5,72(sp)
    80000516:	e0da                	sd	s6,64(sp)
    80000518:	fc5e                	sd	s7,56(sp)
    8000051a:	f862                	sd	s8,48(sp)
    8000051c:	f06a                	sd	s10,32(sp)
    8000051e:	4a01                	li	s4,0
    if(cx != '%'){
    80000520:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    80000524:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    80000528:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 10, 0);
    8000052c:	4b29                	li	s6,10
    if(c0 == 'd'){
    8000052e:	06400b93          	li	s7,100
    80000532:	a80d                	j	80000564 <printf+0x92>
    acquire(&pr.lock);
    80000534:	0000f517          	auipc	a0,0xf
    80000538:	48450513          	addi	a0,a0,1156 # 8000f9b8 <pr>
    8000053c:	728000ef          	jal	80000c64 <acquire>
  va_start(ap, fmt);
    80000540:	00840793          	addi	a5,s0,8
    80000544:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000548:	0004c503          	lbu	a0,0(s1)
    8000054c:	f169                	bnez	a0,8000050e <printf+0x3c>
    8000054e:	aacd                	j	80000740 <printf+0x26e>
      consputc(cx);
    80000550:	cfdff0ef          	jal	8000024c <consputc>
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000554:	001a079b          	addiw	a5,s4,1
    80000558:	8a3e                	mv	s4,a5
    8000055a:	97a6                	add	a5,a5,s1
    8000055c:	0007c503          	lbu	a0,0(a5)
    80000560:	1a050763          	beqz	a0,8000070e <printf+0x23c>
    if(cx != '%'){
    80000564:	ff3516e3          	bne	a0,s3,80000550 <printf+0x7e>
    i++;
    80000568:	001a091b          	addiw	s2,s4,1
    c0 = fmt[i+0] & 0xff;
    8000056c:	012487b3          	add	a5,s1,s2
    80000570:	0007ca83          	lbu	s5,0(a5)
    if(c0) c1 = fmt[i+1] & 0xff;
    80000574:	1e0a8663          	beqz	s5,80000760 <printf+0x28e>
    80000578:	0017c703          	lbu	a4,1(a5)
    if(c1) c2 = fmt[i+2] & 0xff;
    8000057c:	1c070963          	beqz	a4,8000074e <printf+0x27c>
    if(c0 == 'd'){
    80000580:	037a8963          	beq	s5,s7,800005b2 <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80000584:	f94a8793          	addi	a5,s5,-108
    80000588:	0017b793          	seqz	a5,a5
    8000058c:	f9c70693          	addi	a3,a4,-100
    80000590:	0016b693          	seqz	a3,a3
    80000594:	8efd                	and	a3,a3,a5
    80000596:	ca9d                	beqz	a3,800005cc <printf+0xfa>
      printint(va_arg(ap, uint64), 10, 1);
    80000598:	f8843783          	ld	a5,-120(s0)
    8000059c:	00878713          	addi	a4,a5,8
    800005a0:	f8e43423          	sd	a4,-120(s0)
    800005a4:	4605                	li	a2,1
    800005a6:	85da                	mv	a1,s6
    800005a8:	6388                	ld	a0,0(a5)
    800005aa:	e95ff0ef          	jal	8000043e <printint>
      i += 1;
    800005ae:	2a09                	addiw	s4,s4,2
    800005b0:	b755                	j	80000554 <printf+0x82>
      printint(va_arg(ap, int), 10, 1);
    800005b2:	f8843783          	ld	a5,-120(s0)
    800005b6:	00878713          	addi	a4,a5,8
    800005ba:	f8e43423          	sd	a4,-120(s0)
    800005be:	4605                	li	a2,1
    800005c0:	85da                	mv	a1,s6
    800005c2:	4388                	lw	a0,0(a5)
    800005c4:	e7bff0ef          	jal	8000043e <printint>
    i++;
    800005c8:	8a4a                	mv	s4,s2
    800005ca:	b769                	j	80000554 <printf+0x82>
    if(c1) c2 = fmt[i+2] & 0xff;
    800005cc:	012486b3          	add	a3,s1,s2
    800005d0:	863a                	mv	a2,a4
    800005d2:	0026c703          	lbu	a4,2(a3)
    800005d6:	aa59                	j	8000076c <printf+0x29a>
      printint(va_arg(ap, uint64), 10, 1);
    800005d8:	f8843783          	ld	a5,-120(s0)
    800005dc:	00878713          	addi	a4,a5,8
    800005e0:	f8e43423          	sd	a4,-120(s0)
    800005e4:	4605                	li	a2,1
    800005e6:	45a9                	li	a1,10
    800005e8:	6388                	ld	a0,0(a5)
    800005ea:	e55ff0ef          	jal	8000043e <printint>
      i += 2;
    800005ee:	2a0d                	addiw	s4,s4,3
    800005f0:	b795                	j	80000554 <printf+0x82>
      printint(va_arg(ap, int), 10, 0);
    800005f2:	f8843783          	ld	a5,-120(s0)
    800005f6:	00878713          	addi	a4,a5,8
    800005fa:	f8e43423          	sd	a4,-120(s0)
    800005fe:	4601                	li	a2,0
    80000600:	85da                	mv	a1,s6
    80000602:	4388                	lw	a0,0(a5)
    80000604:	e3bff0ef          	jal	8000043e <printint>
    80000608:	b7c1                	j	800005c8 <printf+0xf6>
      printint(va_arg(ap, uint64), 10, 0);
    8000060a:	f8843783          	ld	a5,-120(s0)
    8000060e:	00878713          	addi	a4,a5,8
    80000612:	f8e43423          	sd	a4,-120(s0)
    80000616:	4601                	li	a2,0
    80000618:	85da                	mv	a1,s6
    8000061a:	6388                	ld	a0,0(a5)
    8000061c:	e23ff0ef          	jal	8000043e <printint>
      i += 1;
    80000620:	2a09                	addiw	s4,s4,2
    80000622:	bf0d                	j	80000554 <printf+0x82>
      printint(va_arg(ap, uint64), 10, 0);
    80000624:	f8843783          	ld	a5,-120(s0)
    80000628:	00878713          	addi	a4,a5,8
    8000062c:	f8e43423          	sd	a4,-120(s0)
    80000630:	4601                	li	a2,0
    80000632:	45a9                	li	a1,10
    80000634:	6388                	ld	a0,0(a5)
    80000636:	e09ff0ef          	jal	8000043e <printint>
      i += 2;
    8000063a:	2a0d                	addiw	s4,s4,3
    8000063c:	bf21                	j	80000554 <printf+0x82>
      printint(va_arg(ap, int), 16, 0);
    8000063e:	f8843783          	ld	a5,-120(s0)
    80000642:	00878713          	addi	a4,a5,8
    80000646:	f8e43423          	sd	a4,-120(s0)
    8000064a:	4601                	li	a2,0
    8000064c:	45c1                	li	a1,16
    8000064e:	4388                	lw	a0,0(a5)
    80000650:	defff0ef          	jal	8000043e <printint>
    80000654:	bf95                	j	800005c8 <printf+0xf6>
    } else if(c0 == 'l' && c1 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    80000656:	f8843783          	ld	a5,-120(s0)
    8000065a:	00878713          	addi	a4,a5,8
    8000065e:	f8e43423          	sd	a4,-120(s0)
    80000662:	4601                	li	a2,0
    80000664:	45c1                	li	a1,16
    80000666:	6388                	ld	a0,0(a5)
    80000668:	dd7ff0ef          	jal	8000043e <printint>
      i += 1;
    8000066c:	2a09                	addiw	s4,s4,2
    8000066e:	b5dd                	j	80000554 <printf+0x82>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    80000670:	f8843783          	ld	a5,-120(s0)
    80000674:	00878713          	addi	a4,a5,8
    80000678:	f8e43423          	sd	a4,-120(s0)
    8000067c:	45c1                	li	a1,16
    8000067e:	6388                	ld	a0,0(a5)
    80000680:	dbfff0ef          	jal	8000043e <printint>
      i += 2;
    80000684:	2a0d                	addiw	s4,s4,3
    80000686:	b5f9                	j	80000554 <printf+0x82>
    80000688:	f466                	sd	s9,40(sp)
    } else if(c0 == 'p'){
      printptr(va_arg(ap, uint64));
    8000068a:	f8843783          	ld	a5,-120(s0)
    8000068e:	00878713          	addi	a4,a5,8
    80000692:	f8e43423          	sd	a4,-120(s0)
    80000696:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    8000069a:	03000513          	li	a0,48
    8000069e:	bafff0ef          	jal	8000024c <consputc>
  consputc('x');
    800006a2:	07800513          	li	a0,120
    800006a6:	ba7ff0ef          	jal	8000024c <consputc>
    800006aa:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006ac:	00007c97          	auipc	s9,0x7
    800006b0:	0c4c8c93          	addi	s9,s9,196 # 80007770 <digits>
    800006b4:	03cad793          	srli	a5,s5,0x3c
    800006b8:	97e6                	add	a5,a5,s9
    800006ba:	0007c503          	lbu	a0,0(a5)
    800006be:	b8fff0ef          	jal	8000024c <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006c2:	0a92                	slli	s5,s5,0x4
    800006c4:	3a7d                	addiw	s4,s4,-1
    800006c6:	fe0a17e3          	bnez	s4,800006b4 <printf+0x1e2>
    800006ca:	7ca2                	ld	s9,40(sp)
    800006cc:	bdf5                	j	800005c8 <printf+0xf6>
    } else if(c0 == 's'){
      if((s = va_arg(ap, char*)) == 0)
    800006ce:	f8843783          	ld	a5,-120(s0)
    800006d2:	00878713          	addi	a4,a5,8
    800006d6:	f8e43423          	sd	a4,-120(s0)
    800006da:	0007ba03          	ld	s4,0(a5)
    800006de:	000a0d63          	beqz	s4,800006f8 <printf+0x226>
        s = "(null)";
      for(; *s; s++)
    800006e2:	000a4503          	lbu	a0,0(s4)
    800006e6:	ee0501e3          	beqz	a0,800005c8 <printf+0xf6>
        consputc(*s);
    800006ea:	b63ff0ef          	jal	8000024c <consputc>
      for(; *s; s++)
    800006ee:	0a05                	addi	s4,s4,1
    800006f0:	000a4503          	lbu	a0,0(s4)
    800006f4:	f97d                	bnez	a0,800006ea <printf+0x218>
    800006f6:	bdc9                	j	800005c8 <printf+0xf6>
        s = "(null)";
    800006f8:	00007a17          	auipc	s4,0x7
    800006fc:	910a0a13          	addi	s4,s4,-1776 # 80007008 <etext+0x8>
      for(; *s; s++)
    80000700:	02800513          	li	a0,40
    80000704:	b7dd                	j	800006ea <printf+0x218>
    } else if(c0 == '%'){
      consputc('%');
    80000706:	8556                	mv	a0,s5
    80000708:	b45ff0ef          	jal	8000024c <consputc>
    8000070c:	bd75                	j	800005c8 <printf+0xf6>
    }
#endif
  }
  va_end(ap);

  if(locking)
    8000070e:	020d9163          	bnez	s11,80000730 <printf+0x25e>
    80000712:	7906                	ld	s2,96(sp)
    80000714:	69e6                	ld	s3,88(sp)
    80000716:	6a46                	ld	s4,80(sp)
    80000718:	6aa6                	ld	s5,72(sp)
    8000071a:	6b06                	ld	s6,64(sp)
    8000071c:	7be2                	ld	s7,56(sp)
    8000071e:	7c42                	ld	s8,48(sp)
    80000720:	7d02                	ld	s10,32(sp)
    release(&pr.lock);

  return 0;
}
    80000722:	4501                	li	a0,0
    80000724:	70e6                	ld	ra,120(sp)
    80000726:	7446                	ld	s0,112(sp)
    80000728:	74a6                	ld	s1,104(sp)
    8000072a:	6de2                	ld	s11,24(sp)
    8000072c:	6129                	addi	sp,sp,192
    8000072e:	8082                	ret
    80000730:	7906                	ld	s2,96(sp)
    80000732:	69e6                	ld	s3,88(sp)
    80000734:	6a46                	ld	s4,80(sp)
    80000736:	6aa6                	ld	s5,72(sp)
    80000738:	6b06                	ld	s6,64(sp)
    8000073a:	7be2                	ld	s7,56(sp)
    8000073c:	7c42                	ld	s8,48(sp)
    8000073e:	7d02                	ld	s10,32(sp)
    release(&pr.lock);
    80000740:	0000f517          	auipc	a0,0xf
    80000744:	27850513          	addi	a0,a0,632 # 8000f9b8 <pr>
    80000748:	5ac000ef          	jal	80000cf4 <release>
    8000074c:	bfd9                	j	80000722 <printf+0x250>
    if(c0 == 'd'){
    8000074e:	e77a82e3          	beq	s5,s7,800005b2 <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80000752:	f94a8793          	addi	a5,s5,-108
    80000756:	0017b793          	seqz	a5,a5
    8000075a:	863a                	mv	a2,a4
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000075c:	4681                	li	a3,0
    8000075e:	a01d                	j	80000784 <printf+0x2b2>
    } else if(c0 == 'l' && c1 == 'd'){
    80000760:	f94a8793          	addi	a5,s5,-108
    80000764:	0017b793          	seqz	a5,a5
    c1 = c2 = 0;
    80000768:	8656                	mv	a2,s5
    8000076a:	8756                	mv	a4,s5
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000076c:	f9460693          	addi	a3,a2,-108
    80000770:	0016b693          	seqz	a3,a3
    80000774:	8efd                	and	a3,a3,a5
    80000776:	f9c70593          	addi	a1,a4,-100
    8000077a:	0015b593          	seqz	a1,a1
    8000077e:	8df5                	and	a1,a1,a3
    80000780:	e4059ce3          	bnez	a1,800005d8 <printf+0x106>
    } else if(c0 == 'u'){
    80000784:	e78a87e3          	beq	s5,s8,800005f2 <printf+0x120>
    } else if(c0 == 'l' && c1 == 'u'){
    80000788:	f8b60593          	addi	a1,a2,-117
    8000078c:	0015b593          	seqz	a1,a1
    80000790:	8dfd                	and	a1,a1,a5
    80000792:	e6059ce3          	bnez	a1,8000060a <printf+0x138>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80000796:	f8b70593          	addi	a1,a4,-117
    8000079a:	0015b593          	seqz	a1,a1
    8000079e:	8df5                	and	a1,a1,a3
    800007a0:	e80592e3          	bnez	a1,80000624 <printf+0x152>
    } else if(c0 == 'x'){
    800007a4:	e9aa8de3          	beq	s5,s10,8000063e <printf+0x16c>
    } else if(c0 == 'l' && c1 == 'x'){
    800007a8:	f8860613          	addi	a2,a2,-120
    800007ac:	00163613          	seqz	a2,a2
    800007b0:	8e7d                	and	a2,a2,a5
    800007b2:	ea0612e3          	bnez	a2,80000656 <printf+0x184>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    800007b6:	f8870713          	addi	a4,a4,-120
    800007ba:	00173713          	seqz	a4,a4
    800007be:	8f75                	and	a4,a4,a3
    800007c0:	ea0718e3          	bnez	a4,80000670 <printf+0x19e>
    } else if(c0 == 'p'){
    800007c4:	07000793          	li	a5,112
    800007c8:	ecfa80e3          	beq	s5,a5,80000688 <printf+0x1b6>
    } else if(c0 == 's'){
    800007cc:	07300793          	li	a5,115
    800007d0:	eefa8fe3          	beq	s5,a5,800006ce <printf+0x1fc>
    } else if(c0 == '%'){
    800007d4:	02500793          	li	a5,37
    800007d8:	f2fa87e3          	beq	s5,a5,80000706 <printf+0x234>
    } else if(c0 == 0){
    800007dc:	f20a89e3          	beqz	s5,8000070e <printf+0x23c>
      consputc('%');
    800007e0:	02500513          	li	a0,37
    800007e4:	a69ff0ef          	jal	8000024c <consputc>
      consputc(c0);
    800007e8:	8556                	mv	a0,s5
    800007ea:	a63ff0ef          	jal	8000024c <consputc>
    800007ee:	bbe9                	j	800005c8 <printf+0xf6>

00000000800007f0 <panic>:

void
panic(char *s)
{
    800007f0:	1101                	addi	sp,sp,-32
    800007f2:	ec06                	sd	ra,24(sp)
    800007f4:	e822                	sd	s0,16(sp)
    800007f6:	e426                	sd	s1,8(sp)
    800007f8:	1000                	addi	s0,sp,32
    800007fa:	84aa                	mv	s1,a0
  pr.locking = 0;
    800007fc:	0000f797          	auipc	a5,0xf
    80000800:	1c07aa23          	sw	zero,468(a5) # 8000f9d0 <pr+0x18>
  printf("panic: ");
    80000804:	00007517          	auipc	a0,0x7
    80000808:	81450513          	addi	a0,a0,-2028 # 80007018 <etext+0x18>
    8000080c:	cc7ff0ef          	jal	800004d2 <printf>
  printf("%s\n", s);
    80000810:	85a6                	mv	a1,s1
    80000812:	00007517          	auipc	a0,0x7
    80000816:	80e50513          	addi	a0,a0,-2034 # 80007020 <etext+0x20>
    8000081a:	cb9ff0ef          	jal	800004d2 <printf>
  panicked = 1; // freeze uart output from other CPUs
    8000081e:	4785                	li	a5,1
    80000820:	00007717          	auipc	a4,0x7
    80000824:	0af72823          	sw	a5,176(a4) # 800078d0 <panicked>
  for(;;)
    80000828:	a001                	j	80000828 <panic+0x38>

000000008000082a <printfinit>:
    ;
}

void
printfinit(void)
{
    8000082a:	1141                	addi	sp,sp,-16
    8000082c:	e406                	sd	ra,8(sp)
    8000082e:	e022                	sd	s0,0(sp)
    80000830:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000832:	00006597          	auipc	a1,0x6
    80000836:	7f658593          	addi	a1,a1,2038 # 80007028 <etext+0x28>
    8000083a:	0000f517          	auipc	a0,0xf
    8000083e:	17e50513          	addi	a0,a0,382 # 8000f9b8 <pr>
    80000842:	398000ef          	jal	80000bda <initlock>
  pr.locking = 1;
    80000846:	4785                	li	a5,1
    80000848:	0000f717          	auipc	a4,0xf
    8000084c:	18f72423          	sw	a5,392(a4) # 8000f9d0 <pr+0x18>
}
    80000850:	60a2                	ld	ra,8(sp)
    80000852:	6402                	ld	s0,0(sp)
    80000854:	0141                	addi	sp,sp,16
    80000856:	8082                	ret

0000000080000858 <uartinit>:

void uartstart();

void
uartinit(void)
{
    80000858:	1141                	addi	sp,sp,-16
    8000085a:	e406                	sd	ra,8(sp)
    8000085c:	e022                	sd	s0,0(sp)
    8000085e:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80000860:	100007b7          	lui	a5,0x10000
    80000864:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000868:	10000737          	lui	a4,0x10000
    8000086c:	f8000693          	li	a3,-128
    80000870:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80000874:	468d                	li	a3,3
    80000876:	10000637          	lui	a2,0x10000
    8000087a:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    8000087e:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    80000882:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    80000886:	8732                	mv	a4,a2
    80000888:	461d                	li	a2,7
    8000088a:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    8000088e:	00d780a3          	sb	a3,1(a5)

  initlock(&uart_tx_lock, "uart");
    80000892:	00006597          	auipc	a1,0x6
    80000896:	79e58593          	addi	a1,a1,1950 # 80007030 <etext+0x30>
    8000089a:	0000f517          	auipc	a0,0xf
    8000089e:	13e50513          	addi	a0,a0,318 # 8000f9d8 <uart_tx_lock>
    800008a2:	338000ef          	jal	80000bda <initlock>
}
    800008a6:	60a2                	ld	ra,8(sp)
    800008a8:	6402                	ld	s0,0(sp)
    800008aa:	0141                	addi	sp,sp,16
    800008ac:	8082                	ret

00000000800008ae <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    800008ae:	1101                	addi	sp,sp,-32
    800008b0:	ec06                	sd	ra,24(sp)
    800008b2:	e822                	sd	s0,16(sp)
    800008b4:	e426                	sd	s1,8(sp)
    800008b6:	1000                	addi	s0,sp,32
    800008b8:	84aa                	mv	s1,a0
  push_off();
    800008ba:	366000ef          	jal	80000c20 <push_off>

  if(panicked){
    800008be:	00007797          	auipc	a5,0x7
    800008c2:	0127a783          	lw	a5,18(a5) # 800078d0 <panicked>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800008c6:	10000737          	lui	a4,0x10000
    800008ca:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
  if(panicked){
    800008cc:	c391                	beqz	a5,800008d0 <uartputc_sync+0x22>
    for(;;)
    800008ce:	a001                	j	800008ce <uartputc_sync+0x20>
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800008d0:	00074783          	lbu	a5,0(a4)
    800008d4:	0207f793          	andi	a5,a5,32
    800008d8:	dfe5                	beqz	a5,800008d0 <uartputc_sync+0x22>
    ;
  WriteReg(THR, c);
    800008da:	100007b7          	lui	a5,0x10000
    800008de:	00978023          	sb	s1,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    800008e2:	3c2000ef          	jal	80000ca4 <pop_off>
}
    800008e6:	60e2                	ld	ra,24(sp)
    800008e8:	6442                	ld	s0,16(sp)
    800008ea:	64a2                	ld	s1,8(sp)
    800008ec:	6105                	addi	sp,sp,32
    800008ee:	8082                	ret

00000000800008f0 <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    800008f0:	00007797          	auipc	a5,0x7
    800008f4:	fe87b783          	ld	a5,-24(a5) # 800078d8 <uart_tx_r>
    800008f8:	00007717          	auipc	a4,0x7
    800008fc:	fe873703          	ld	a4,-24(a4) # 800078e0 <uart_tx_w>
    80000900:	06f70d63          	beq	a4,a5,8000097a <uartstart+0x8a>
{
    80000904:	7139                	addi	sp,sp,-64
    80000906:	fc06                	sd	ra,56(sp)
    80000908:	f822                	sd	s0,48(sp)
    8000090a:	f426                	sd	s1,40(sp)
    8000090c:	f04a                	sd	s2,32(sp)
    8000090e:	ec4e                	sd	s3,24(sp)
    80000910:	e852                	sd	s4,16(sp)
    80000912:	e456                	sd	s5,8(sp)
    80000914:	e05a                	sd	s6,0(sp)
    80000916:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80000918:	10000937          	lui	s2,0x10000
    8000091c:	0915                	addi	s2,s2,5 # 10000005 <_entry-0x6ffffffb>
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    8000091e:	0000fa97          	auipc	s5,0xf
    80000922:	0baa8a93          	addi	s5,s5,186 # 8000f9d8 <uart_tx_lock>
    uart_tx_r += 1;
    80000926:	00007497          	auipc	s1,0x7
    8000092a:	fb248493          	addi	s1,s1,-78 # 800078d8 <uart_tx_r>
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    
    WriteReg(THR, c);
    8000092e:	10000a37          	lui	s4,0x10000
    if(uart_tx_w == uart_tx_r){
    80000932:	00007997          	auipc	s3,0x7
    80000936:	fae98993          	addi	s3,s3,-82 # 800078e0 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    8000093a:	00094703          	lbu	a4,0(s2)
    8000093e:	02077713          	andi	a4,a4,32
    80000942:	c315                	beqz	a4,80000966 <uartstart+0x76>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80000944:	01f7f713          	andi	a4,a5,31
    80000948:	9756                	add	a4,a4,s5
    8000094a:	01874b03          	lbu	s6,24(a4)
    uart_tx_r += 1;
    8000094e:	0785                	addi	a5,a5,1
    80000950:	e09c                	sd	a5,0(s1)
    wakeup(&uart_tx_r);
    80000952:	8526                	mv	a0,s1
    80000954:	5d8010ef          	jal	80001f2c <wakeup>
    WriteReg(THR, c);
    80000958:	016a0023          	sb	s6,0(s4) # 10000000 <_entry-0x70000000>
    if(uart_tx_w == uart_tx_r){
    8000095c:	609c                	ld	a5,0(s1)
    8000095e:	0009b703          	ld	a4,0(s3)
    80000962:	fcf71ce3          	bne	a4,a5,8000093a <uartstart+0x4a>
  }
}
    80000966:	70e2                	ld	ra,56(sp)
    80000968:	7442                	ld	s0,48(sp)
    8000096a:	74a2                	ld	s1,40(sp)
    8000096c:	7902                	ld	s2,32(sp)
    8000096e:	69e2                	ld	s3,24(sp)
    80000970:	6a42                	ld	s4,16(sp)
    80000972:	6aa2                	ld	s5,8(sp)
    80000974:	6b02                	ld	s6,0(sp)
    80000976:	6121                	addi	sp,sp,64
    80000978:	8082                	ret
    8000097a:	8082                	ret

000000008000097c <uartputc>:
{
    8000097c:	7179                	addi	sp,sp,-48
    8000097e:	f406                	sd	ra,40(sp)
    80000980:	f022                	sd	s0,32(sp)
    80000982:	ec26                	sd	s1,24(sp)
    80000984:	e84a                	sd	s2,16(sp)
    80000986:	e44e                	sd	s3,8(sp)
    80000988:	e052                	sd	s4,0(sp)
    8000098a:	1800                	addi	s0,sp,48
    8000098c:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    8000098e:	0000f517          	auipc	a0,0xf
    80000992:	04a50513          	addi	a0,a0,74 # 8000f9d8 <uart_tx_lock>
    80000996:	2ce000ef          	jal	80000c64 <acquire>
  if(panicked){
    8000099a:	00007797          	auipc	a5,0x7
    8000099e:	f367a783          	lw	a5,-202(a5) # 800078d0 <panicked>
    800009a2:	e3d1                	bnez	a5,80000a26 <uartputc+0xaa>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800009a4:	00007717          	auipc	a4,0x7
    800009a8:	f3c73703          	ld	a4,-196(a4) # 800078e0 <uart_tx_w>
    800009ac:	00007797          	auipc	a5,0x7
    800009b0:	f2c7b783          	ld	a5,-212(a5) # 800078d8 <uart_tx_r>
    800009b4:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    800009b8:	0000f997          	auipc	s3,0xf
    800009bc:	02098993          	addi	s3,s3,32 # 8000f9d8 <uart_tx_lock>
    800009c0:	00007497          	auipc	s1,0x7
    800009c4:	f1848493          	addi	s1,s1,-232 # 800078d8 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800009c8:	00007917          	auipc	s2,0x7
    800009cc:	f1890913          	addi	s2,s2,-232 # 800078e0 <uart_tx_w>
    800009d0:	00e79d63          	bne	a5,a4,800009ea <uartputc+0x6e>
    sleep(&uart_tx_r, &uart_tx_lock);
    800009d4:	85ce                	mv	a1,s3
    800009d6:	8526                	mv	a0,s1
    800009d8:	508010ef          	jal	80001ee0 <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800009dc:	00093703          	ld	a4,0(s2)
    800009e0:	609c                	ld	a5,0(s1)
    800009e2:	02078793          	addi	a5,a5,32
    800009e6:	fee787e3          	beq	a5,a4,800009d4 <uartputc+0x58>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    800009ea:	01f77693          	andi	a3,a4,31
    800009ee:	0000f797          	auipc	a5,0xf
    800009f2:	fea78793          	addi	a5,a5,-22 # 8000f9d8 <uart_tx_lock>
    800009f6:	97b6                	add	a5,a5,a3
    800009f8:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    800009fc:	0705                	addi	a4,a4,1
    800009fe:	00007797          	auipc	a5,0x7
    80000a02:	eee7b123          	sd	a4,-286(a5) # 800078e0 <uart_tx_w>
  uartstart();
    80000a06:	eebff0ef          	jal	800008f0 <uartstart>
  release(&uart_tx_lock);
    80000a0a:	0000f517          	auipc	a0,0xf
    80000a0e:	fce50513          	addi	a0,a0,-50 # 8000f9d8 <uart_tx_lock>
    80000a12:	2e2000ef          	jal	80000cf4 <release>
}
    80000a16:	70a2                	ld	ra,40(sp)
    80000a18:	7402                	ld	s0,32(sp)
    80000a1a:	64e2                	ld	s1,24(sp)
    80000a1c:	6942                	ld	s2,16(sp)
    80000a1e:	69a2                	ld	s3,8(sp)
    80000a20:	6a02                	ld	s4,0(sp)
    80000a22:	6145                	addi	sp,sp,48
    80000a24:	8082                	ret
    for(;;)
    80000a26:	a001                	j	80000a26 <uartputc+0xaa>

0000000080000a28 <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    80000a28:	1141                	addi	sp,sp,-16
    80000a2a:	e406                	sd	ra,8(sp)
    80000a2c:	e022                	sd	s0,0(sp)
    80000a2e:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    80000a30:	100007b7          	lui	a5,0x10000
    80000a34:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80000a38:	8b85                	andi	a5,a5,1
    80000a3a:	cb89                	beqz	a5,80000a4c <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    80000a3c:	100007b7          	lui	a5,0x10000
    80000a40:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    80000a44:	60a2                	ld	ra,8(sp)
    80000a46:	6402                	ld	s0,0(sp)
    80000a48:	0141                	addi	sp,sp,16
    80000a4a:	8082                	ret
    return -1;
    80000a4c:	557d                	li	a0,-1
    80000a4e:	bfdd                	j	80000a44 <uartgetc+0x1c>

0000000080000a50 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    80000a50:	1101                	addi	sp,sp,-32
    80000a52:	ec06                	sd	ra,24(sp)
    80000a54:	e822                	sd	s0,16(sp)
    80000a56:	e426                	sd	s1,8(sp)
    80000a58:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    80000a5a:	100007b7          	lui	a5,0x10000
    80000a5e:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>

  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80000a62:	54fd                	li	s1,-1
    int c = uartgetc();
    80000a64:	fc5ff0ef          	jal	80000a28 <uartgetc>
    if(c == -1)
    80000a68:	00950563          	beq	a0,s1,80000a72 <uartintr+0x22>
      break;
    consoleintr(c);
    80000a6c:	813ff0ef          	jal	8000027e <consoleintr>
  while(1){
    80000a70:	bfd5                	j	80000a64 <uartintr+0x14>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    80000a72:	0000f517          	auipc	a0,0xf
    80000a76:	f6650513          	addi	a0,a0,-154 # 8000f9d8 <uart_tx_lock>
    80000a7a:	1ea000ef          	jal	80000c64 <acquire>
  uartstart();
    80000a7e:	e73ff0ef          	jal	800008f0 <uartstart>
  release(&uart_tx_lock);
    80000a82:	0000f517          	auipc	a0,0xf
    80000a86:	f5650513          	addi	a0,a0,-170 # 8000f9d8 <uart_tx_lock>
    80000a8a:	26a000ef          	jal	80000cf4 <release>
}
    80000a8e:	60e2                	ld	ra,24(sp)
    80000a90:	6442                	ld	s0,16(sp)
    80000a92:	64a2                	ld	s1,8(sp)
    80000a94:	6105                	addi	sp,sp,32
    80000a96:	8082                	ret

0000000080000a98 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a98:	1101                	addi	sp,sp,-32
    80000a9a:	ec06                	sd	ra,24(sp)
    80000a9c:	e822                	sd	s0,16(sp)
    80000a9e:	e426                	sd	s1,8(sp)
    80000aa0:	e04a                	sd	s2,0(sp)
    80000aa2:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000aa4:	00020797          	auipc	a5,0x20
    80000aa8:	19c78793          	addi	a5,a5,412 # 80020c40 <end>
    80000aac:	00f53733          	sltu	a4,a0,a5
    80000ab0:	47c5                	li	a5,17
    80000ab2:	07ee                	slli	a5,a5,0x1b
    80000ab4:	17fd                	addi	a5,a5,-1
    80000ab6:	00a7b7b3          	sltu	a5,a5,a0
    80000aba:	8fd9                	or	a5,a5,a4
    80000abc:	03451713          	slli	a4,a0,0x34
    80000ac0:	8fd9                	or	a5,a5,a4
    80000ac2:	eb9d                	bnez	a5,80000af8 <kfree+0x60>
    80000ac4:	84aa                	mv	s1,a0
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000ac6:	6605                	lui	a2,0x1
    80000ac8:	4585                	li	a1,1
    80000aca:	266000ef          	jal	80000d30 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000ace:	0000f917          	auipc	s2,0xf
    80000ad2:	f4290913          	addi	s2,s2,-190 # 8000fa10 <kmem>
    80000ad6:	854a                	mv	a0,s2
    80000ad8:	18c000ef          	jal	80000c64 <acquire>
  r->next = kmem.freelist;
    80000adc:	01893783          	ld	a5,24(s2)
    80000ae0:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000ae2:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000ae6:	854a                	mv	a0,s2
    80000ae8:	20c000ef          	jal	80000cf4 <release>
}
    80000aec:	60e2                	ld	ra,24(sp)
    80000aee:	6442                	ld	s0,16(sp)
    80000af0:	64a2                	ld	s1,8(sp)
    80000af2:	6902                	ld	s2,0(sp)
    80000af4:	6105                	addi	sp,sp,32
    80000af6:	8082                	ret
    panic("kfree");
    80000af8:	00006517          	auipc	a0,0x6
    80000afc:	54050513          	addi	a0,a0,1344 # 80007038 <etext+0x38>
    80000b00:	cf1ff0ef          	jal	800007f0 <panic>

0000000080000b04 <freerange>:
{
    80000b04:	7179                	addi	sp,sp,-48
    80000b06:	f406                	sd	ra,40(sp)
    80000b08:	f022                	sd	s0,32(sp)
    80000b0a:	ec26                	sd	s1,24(sp)
    80000b0c:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000b0e:	6785                	lui	a5,0x1
    80000b10:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000b14:	00e504b3          	add	s1,a0,a4
    80000b18:	777d                	lui	a4,0xfffff
    80000b1a:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000b1c:	94be                	add	s1,s1,a5
    80000b1e:	0295e263          	bltu	a1,s1,80000b42 <freerange+0x3e>
    80000b22:	e84a                	sd	s2,16(sp)
    80000b24:	e44e                	sd	s3,8(sp)
    80000b26:	e052                	sd	s4,0(sp)
    80000b28:	892e                	mv	s2,a1
    kfree(p);
    80000b2a:	8a3a                	mv	s4,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000b2c:	89be                	mv	s3,a5
    kfree(p);
    80000b2e:	01448533          	add	a0,s1,s4
    80000b32:	f67ff0ef          	jal	80000a98 <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000b36:	94ce                	add	s1,s1,s3
    80000b38:	fe997be3          	bgeu	s2,s1,80000b2e <freerange+0x2a>
    80000b3c:	6942                	ld	s2,16(sp)
    80000b3e:	69a2                	ld	s3,8(sp)
    80000b40:	6a02                	ld	s4,0(sp)
}
    80000b42:	70a2                	ld	ra,40(sp)
    80000b44:	7402                	ld	s0,32(sp)
    80000b46:	64e2                	ld	s1,24(sp)
    80000b48:	6145                	addi	sp,sp,48
    80000b4a:	8082                	ret

0000000080000b4c <kinit>:
{
    80000b4c:	1141                	addi	sp,sp,-16
    80000b4e:	e406                	sd	ra,8(sp)
    80000b50:	e022                	sd	s0,0(sp)
    80000b52:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000b54:	00006597          	auipc	a1,0x6
    80000b58:	4ec58593          	addi	a1,a1,1260 # 80007040 <etext+0x40>
    80000b5c:	0000f517          	auipc	a0,0xf
    80000b60:	eb450513          	addi	a0,a0,-332 # 8000fa10 <kmem>
    80000b64:	076000ef          	jal	80000bda <initlock>
  freerange(end, (void*)PHYSTOP);
    80000b68:	45c5                	li	a1,17
    80000b6a:	05ee                	slli	a1,a1,0x1b
    80000b6c:	00020517          	auipc	a0,0x20
    80000b70:	0d450513          	addi	a0,a0,212 # 80020c40 <end>
    80000b74:	f91ff0ef          	jal	80000b04 <freerange>
}
    80000b78:	60a2                	ld	ra,8(sp)
    80000b7a:	6402                	ld	s0,0(sp)
    80000b7c:	0141                	addi	sp,sp,16
    80000b7e:	8082                	ret

0000000080000b80 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000b80:	1101                	addi	sp,sp,-32
    80000b82:	ec06                	sd	ra,24(sp)
    80000b84:	e822                	sd	s0,16(sp)
    80000b86:	e426                	sd	s1,8(sp)
    80000b88:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b8a:	0000f517          	auipc	a0,0xf
    80000b8e:	e8650513          	addi	a0,a0,-378 # 8000fa10 <kmem>
    80000b92:	0d2000ef          	jal	80000c64 <acquire>
  r = kmem.freelist;
    80000b96:	0000f497          	auipc	s1,0xf
    80000b9a:	e924b483          	ld	s1,-366(s1) # 8000fa28 <kmem+0x18>
  if(r)
    80000b9e:	c49d                	beqz	s1,80000bcc <kalloc+0x4c>
    kmem.freelist = r->next;
    80000ba0:	609c                	ld	a5,0(s1)
    80000ba2:	0000f717          	auipc	a4,0xf
    80000ba6:	e8f73323          	sd	a5,-378(a4) # 8000fa28 <kmem+0x18>
  release(&kmem.lock);
    80000baa:	0000f517          	auipc	a0,0xf
    80000bae:	e6650513          	addi	a0,a0,-410 # 8000fa10 <kmem>
    80000bb2:	142000ef          	jal	80000cf4 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000bb6:	6605                	lui	a2,0x1
    80000bb8:	4595                	li	a1,5
    80000bba:	8526                	mv	a0,s1
    80000bbc:	174000ef          	jal	80000d30 <memset>
  return (void*)r;
}
    80000bc0:	8526                	mv	a0,s1
    80000bc2:	60e2                	ld	ra,24(sp)
    80000bc4:	6442                	ld	s0,16(sp)
    80000bc6:	64a2                	ld	s1,8(sp)
    80000bc8:	6105                	addi	sp,sp,32
    80000bca:	8082                	ret
  release(&kmem.lock);
    80000bcc:	0000f517          	auipc	a0,0xf
    80000bd0:	e4450513          	addi	a0,a0,-444 # 8000fa10 <kmem>
    80000bd4:	120000ef          	jal	80000cf4 <release>
  if(r)
    80000bd8:	b7e5                	j	80000bc0 <kalloc+0x40>

0000000080000bda <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000bda:	1141                	addi	sp,sp,-16
    80000bdc:	e406                	sd	ra,8(sp)
    80000bde:	e022                	sd	s0,0(sp)
    80000be0:	0800                	addi	s0,sp,16
  lk->name = name;
    80000be2:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000be4:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000be8:	00053823          	sd	zero,16(a0)
}
    80000bec:	60a2                	ld	ra,8(sp)
    80000bee:	6402                	ld	s0,0(sp)
    80000bf0:	0141                	addi	sp,sp,16
    80000bf2:	8082                	ret

0000000080000bf4 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000bf4:	411c                	lw	a5,0(a0)
    80000bf6:	e399                	bnez	a5,80000bfc <holding+0x8>
    80000bf8:	4501                	li	a0,0
  return r;
}
    80000bfa:	8082                	ret
{
    80000bfc:	1101                	addi	sp,sp,-32
    80000bfe:	ec06                	sd	ra,24(sp)
    80000c00:	e822                	sd	s0,16(sp)
    80000c02:	e426                	sd	s1,8(sp)
    80000c04:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000c06:	691c                	ld	a5,16(a0)
    80000c08:	84be                	mv	s1,a5
    80000c0a:	4fb000ef          	jal	80001904 <mycpu>
    80000c0e:	40a48533          	sub	a0,s1,a0
    80000c12:	00153513          	seqz	a0,a0
}
    80000c16:	60e2                	ld	ra,24(sp)
    80000c18:	6442                	ld	s0,16(sp)
    80000c1a:	64a2                	ld	s1,8(sp)
    80000c1c:	6105                	addi	sp,sp,32
    80000c1e:	8082                	ret

0000000080000c20 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000c20:	1101                	addi	sp,sp,-32
    80000c22:	ec06                	sd	ra,24(sp)
    80000c24:	e822                	sd	s0,16(sp)
    80000c26:	e426                	sd	s1,8(sp)
    80000c28:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c2a:	100027f3          	csrr	a5,sstatus
    80000c2e:	84be                	mv	s1,a5
  int old = intr_get();

  if(mycpu()->noff == 0){
    80000c30:	4d5000ef          	jal	80001904 <mycpu>
    80000c34:	5d3c                	lw	a5,120(a0)
    80000c36:	cb99                	beqz	a5,80000c4c <push_off+0x2c>
    intr_off();
    mycpu()->intena = old;
  }
  mycpu()->noff += 1;
    80000c38:	4cd000ef          	jal	80001904 <mycpu>
    80000c3c:	5d3c                	lw	a5,120(a0)
    80000c3e:	2785                	addiw	a5,a5,1
    80000c40:	dd3c                	sw	a5,120(a0)
}
    80000c42:	60e2                	ld	ra,24(sp)
    80000c44:	6442                	ld	s0,16(sp)
    80000c46:	64a2                	ld	s1,8(sp)
    80000c48:	6105                	addi	sp,sp,32
    80000c4a:	8082                	ret
    80000c4c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000c50:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c52:	10079073          	csrw	sstatus,a5
    mycpu()->intena = old;
    80000c56:	4af000ef          	jal	80001904 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000c5a:	0014d793          	srli	a5,s1,0x1
    80000c5e:	8b85                	andi	a5,a5,1
    80000c60:	dd7c                	sw	a5,124(a0)
    80000c62:	bfd9                	j	80000c38 <push_off+0x18>

0000000080000c64 <acquire>:
{
    80000c64:	1101                	addi	sp,sp,-32
    80000c66:	ec06                	sd	ra,24(sp)
    80000c68:	e822                	sd	s0,16(sp)
    80000c6a:	e426                	sd	s1,8(sp)
    80000c6c:	1000                	addi	s0,sp,32
    80000c6e:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000c70:	fb1ff0ef          	jal	80000c20 <push_off>
  if(holding(lk))
    80000c74:	8526                	mv	a0,s1
    80000c76:	f7fff0ef          	jal	80000bf4 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c7a:	4705                	li	a4,1
  if(holding(lk))
    80000c7c:	ed11                	bnez	a0,80000c98 <acquire+0x34>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c7e:	0ce4a7af          	amoswap.w.aq	a5,a4,(s1)
    80000c82:	fff5                	bnez	a5,80000c7e <acquire+0x1a>
  __sync_synchronize();
    80000c84:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80000c88:	47d000ef          	jal	80001904 <mycpu>
    80000c8c:	e888                	sd	a0,16(s1)
}
    80000c8e:	60e2                	ld	ra,24(sp)
    80000c90:	6442                	ld	s0,16(sp)
    80000c92:	64a2                	ld	s1,8(sp)
    80000c94:	6105                	addi	sp,sp,32
    80000c96:	8082                	ret
    panic("acquire");
    80000c98:	00006517          	auipc	a0,0x6
    80000c9c:	3b050513          	addi	a0,a0,944 # 80007048 <etext+0x48>
    80000ca0:	b51ff0ef          	jal	800007f0 <panic>

0000000080000ca4 <pop_off>:

void
pop_off(void)
{
    80000ca4:	1141                	addi	sp,sp,-16
    80000ca6:	e406                	sd	ra,8(sp)
    80000ca8:	e022                	sd	s0,0(sp)
    80000caa:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000cac:	459000ef          	jal	80001904 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000cb0:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000cb4:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000cb6:	e39d                	bnez	a5,80000cdc <pop_off+0x38>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000cb8:	5d3c                	lw	a5,120(a0)
    80000cba:	02f05763          	blez	a5,80000ce8 <pop_off+0x44>
    panic("pop_off");
  c->noff -= 1;
    80000cbe:	37fd                	addiw	a5,a5,-1
    80000cc0:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000cc2:	eb89                	bnez	a5,80000cd4 <pop_off+0x30>
    80000cc4:	5d7c                	lw	a5,124(a0)
    80000cc6:	c799                	beqz	a5,80000cd4 <pop_off+0x30>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000cc8:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000ccc:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000cd0:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000cd4:	60a2                	ld	ra,8(sp)
    80000cd6:	6402                	ld	s0,0(sp)
    80000cd8:	0141                	addi	sp,sp,16
    80000cda:	8082                	ret
    panic("pop_off - interruptible");
    80000cdc:	00006517          	auipc	a0,0x6
    80000ce0:	37450513          	addi	a0,a0,884 # 80007050 <etext+0x50>
    80000ce4:	b0dff0ef          	jal	800007f0 <panic>
    panic("pop_off");
    80000ce8:	00006517          	auipc	a0,0x6
    80000cec:	38050513          	addi	a0,a0,896 # 80007068 <etext+0x68>
    80000cf0:	b01ff0ef          	jal	800007f0 <panic>

0000000080000cf4 <release>:
{
    80000cf4:	1101                	addi	sp,sp,-32
    80000cf6:	ec06                	sd	ra,24(sp)
    80000cf8:	e822                	sd	s0,16(sp)
    80000cfa:	e426                	sd	s1,8(sp)
    80000cfc:	1000                	addi	s0,sp,32
    80000cfe:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000d00:	ef5ff0ef          	jal	80000bf4 <holding>
    80000d04:	c105                	beqz	a0,80000d24 <release+0x30>
  lk->cpu = 0;
    80000d06:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000d0a:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    80000d0e:	0310000f          	fence	rw,w
    80000d12:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000d16:	f8fff0ef          	jal	80000ca4 <pop_off>
}
    80000d1a:	60e2                	ld	ra,24(sp)
    80000d1c:	6442                	ld	s0,16(sp)
    80000d1e:	64a2                	ld	s1,8(sp)
    80000d20:	6105                	addi	sp,sp,32
    80000d22:	8082                	ret
    panic("release");
    80000d24:	00006517          	auipc	a0,0x6
    80000d28:	34c50513          	addi	a0,a0,844 # 80007070 <etext+0x70>
    80000d2c:	ac5ff0ef          	jal	800007f0 <panic>

0000000080000d30 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000d30:	1141                	addi	sp,sp,-16
    80000d32:	e406                	sd	ra,8(sp)
    80000d34:	e022                	sd	s0,0(sp)
    80000d36:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000d38:	ca19                	beqz	a2,80000d4e <memset+0x1e>
    80000d3a:	87aa                	mv	a5,a0
    80000d3c:	1602                	slli	a2,a2,0x20
    80000d3e:	9201                	srli	a2,a2,0x20
    80000d40:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000d44:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000d48:	0785                	addi	a5,a5,1
    80000d4a:	fee79de3          	bne	a5,a4,80000d44 <memset+0x14>
  }
  return dst;
}
    80000d4e:	60a2                	ld	ra,8(sp)
    80000d50:	6402                	ld	s0,0(sp)
    80000d52:	0141                	addi	sp,sp,16
    80000d54:	8082                	ret

0000000080000d56 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000d56:	1141                	addi	sp,sp,-16
    80000d58:	e406                	sd	ra,8(sp)
    80000d5a:	e022                	sd	s0,0(sp)
    80000d5c:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000d5e:	ce19                	beqz	a2,80000d7c <memcmp+0x26>
    80000d60:	1602                	slli	a2,a2,0x20
    80000d62:	9201                	srli	a2,a2,0x20
    80000d64:	00c506b3          	add	a3,a0,a2
    if(*s1 != *s2)
    80000d68:	00054783          	lbu	a5,0(a0)
    80000d6c:	0005c703          	lbu	a4,0(a1)
    80000d70:	00e79b63          	bne	a5,a4,80000d86 <memcmp+0x30>
      return *s1 - *s2;
    s1++, s2++;
    80000d74:	0505                	addi	a0,a0,1
    80000d76:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000d78:	fed518e3          	bne	a0,a3,80000d68 <memcmp+0x12>
  }

  return 0;
    80000d7c:	4501                	li	a0,0
}
    80000d7e:	60a2                	ld	ra,8(sp)
    80000d80:	6402                	ld	s0,0(sp)
    80000d82:	0141                	addi	sp,sp,16
    80000d84:	8082                	ret
      return *s1 - *s2;
    80000d86:	40e7853b          	subw	a0,a5,a4
    80000d8a:	bfd5                	j	80000d7e <memcmp+0x28>

0000000080000d8c <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000d8c:	1141                	addi	sp,sp,-16
    80000d8e:	e406                	sd	ra,8(sp)
    80000d90:	e022                	sd	s0,0(sp)
    80000d92:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d94:	c61d                	beqz	a2,80000dc2 <memmove+0x36>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d96:	00a5f963          	bgeu	a1,a0,80000da8 <memmove+0x1c>
    80000d9a:	02061693          	slli	a3,a2,0x20
    80000d9e:	9281                	srli	a3,a3,0x20
    80000da0:	00d58733          	add	a4,a1,a3
    80000da4:	02e56363          	bltu	a0,a4,80000dca <memmove+0x3e>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000da8:	1602                	slli	a2,a2,0x20
    80000daa:	9201                	srli	a2,a2,0x20
    80000dac:	00c587b3          	add	a5,a1,a2
{
    80000db0:	872a                	mv	a4,a0
      *d++ = *s++;
    80000db2:	0585                	addi	a1,a1,1
    80000db4:	0705                	addi	a4,a4,1
    80000db6:	fff5c683          	lbu	a3,-1(a1)
    80000dba:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000dbe:	fef59ae3          	bne	a1,a5,80000db2 <memmove+0x26>

  return dst;
}
    80000dc2:	60a2                	ld	ra,8(sp)
    80000dc4:	6402                	ld	s0,0(sp)
    80000dc6:	0141                	addi	sp,sp,16
    80000dc8:	8082                	ret
    d += n;
    80000dca:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000dcc:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000dd0:	1782                	slli	a5,a5,0x20
    80000dd2:	9381                	srli	a5,a5,0x20
    80000dd4:	fff7c793          	not	a5,a5
    80000dd8:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000dda:	177d                	addi	a4,a4,-1
    80000ddc:	16fd                	addi	a3,a3,-1
    80000dde:	00074603          	lbu	a2,0(a4)
    80000de2:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000de6:	fee79ae3          	bne	a5,a4,80000dda <memmove+0x4e>
    80000dea:	bfe1                	j	80000dc2 <memmove+0x36>

0000000080000dec <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000dec:	1141                	addi	sp,sp,-16
    80000dee:	e406                	sd	ra,8(sp)
    80000df0:	e022                	sd	s0,0(sp)
    80000df2:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000df4:	f99ff0ef          	jal	80000d8c <memmove>
}
    80000df8:	60a2                	ld	ra,8(sp)
    80000dfa:	6402                	ld	s0,0(sp)
    80000dfc:	0141                	addi	sp,sp,16
    80000dfe:	8082                	ret

0000000080000e00 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000e00:	1141                	addi	sp,sp,-16
    80000e02:	e406                	sd	ra,8(sp)
    80000e04:	e022                	sd	s0,0(sp)
    80000e06:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000e08:	ce01                	beqz	a2,80000e20 <strncmp+0x20>
    80000e0a:	00054783          	lbu	a5,0(a0)
    80000e0e:	cb99                	beqz	a5,80000e24 <strncmp+0x24>
    80000e10:	0005c703          	lbu	a4,0(a1)
    80000e14:	00f71863          	bne	a4,a5,80000e24 <strncmp+0x24>
    n--, p++, q++;
    80000e18:	367d                	addiw	a2,a2,-1
    80000e1a:	0505                	addi	a0,a0,1
    80000e1c:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000e1e:	f675                	bnez	a2,80000e0a <strncmp+0xa>
  if(n == 0)
    return 0;
    80000e20:	4501                	li	a0,0
    80000e22:	a031                	j	80000e2e <strncmp+0x2e>
  return (uchar)*p - (uchar)*q;
    80000e24:	00054503          	lbu	a0,0(a0)
    80000e28:	0005c783          	lbu	a5,0(a1)
    80000e2c:	9d1d                	subw	a0,a0,a5
}
    80000e2e:	60a2                	ld	ra,8(sp)
    80000e30:	6402                	ld	s0,0(sp)
    80000e32:	0141                	addi	sp,sp,16
    80000e34:	8082                	ret

0000000080000e36 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000e36:	1141                	addi	sp,sp,-16
    80000e38:	e406                	sd	ra,8(sp)
    80000e3a:	e022                	sd	s0,0(sp)
    80000e3c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000e3e:	87aa                	mv	a5,a0
    80000e40:	a011                	j	80000e44 <strncpy+0xe>
    80000e42:	8636                	mv	a2,a3
    80000e44:	02c05763          	blez	a2,80000e72 <strncpy+0x3c>
    80000e48:	fff6069b          	addiw	a3,a2,-1
    80000e4c:	0785                	addi	a5,a5,1
    80000e4e:	0005c703          	lbu	a4,0(a1)
    80000e52:	fee78fa3          	sb	a4,-1(a5)
    80000e56:	0585                	addi	a1,a1,1
    80000e58:	f76d                	bnez	a4,80000e42 <strncpy+0xc>
    ;
  while(n-- > 0)
    80000e5a:	873e                	mv	a4,a5
    80000e5c:	00d05b63          	blez	a3,80000e72 <strncpy+0x3c>
    80000e60:	9fb1                	addw	a5,a5,a2
    80000e62:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    80000e64:	0705                	addi	a4,a4,1
    80000e66:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    80000e6a:	40e786bb          	subw	a3,a5,a4
    80000e6e:	fed04be3          	bgtz	a3,80000e64 <strncpy+0x2e>
  return os;
}
    80000e72:	60a2                	ld	ra,8(sp)
    80000e74:	6402                	ld	s0,0(sp)
    80000e76:	0141                	addi	sp,sp,16
    80000e78:	8082                	ret

0000000080000e7a <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000e7a:	1141                	addi	sp,sp,-16
    80000e7c:	e406                	sd	ra,8(sp)
    80000e7e:	e022                	sd	s0,0(sp)
    80000e80:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000e82:	02c05363          	blez	a2,80000ea8 <safestrcpy+0x2e>
    80000e86:	fff6069b          	addiw	a3,a2,-1
    80000e8a:	1682                	slli	a3,a3,0x20
    80000e8c:	9281                	srli	a3,a3,0x20
    80000e8e:	96ae                	add	a3,a3,a1
    80000e90:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000e92:	00d58963          	beq	a1,a3,80000ea4 <safestrcpy+0x2a>
    80000e96:	0585                	addi	a1,a1,1
    80000e98:	0785                	addi	a5,a5,1
    80000e9a:	fff5c703          	lbu	a4,-1(a1)
    80000e9e:	fee78fa3          	sb	a4,-1(a5)
    80000ea2:	fb65                	bnez	a4,80000e92 <safestrcpy+0x18>
    ;
  *s = 0;
    80000ea4:	00078023          	sb	zero,0(a5)
  return os;
}
    80000ea8:	60a2                	ld	ra,8(sp)
    80000eaa:	6402                	ld	s0,0(sp)
    80000eac:	0141                	addi	sp,sp,16
    80000eae:	8082                	ret

0000000080000eb0 <strlen>:

int
strlen(const char *s)
{
    80000eb0:	1141                	addi	sp,sp,-16
    80000eb2:	e406                	sd	ra,8(sp)
    80000eb4:	e022                	sd	s0,0(sp)
    80000eb6:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000eb8:	00054783          	lbu	a5,0(a0)
    80000ebc:	cf91                	beqz	a5,80000ed8 <strlen+0x28>
    80000ebe:	00150793          	addi	a5,a0,1
    80000ec2:	86be                	mv	a3,a5
    80000ec4:	0785                	addi	a5,a5,1
    80000ec6:	fff7c703          	lbu	a4,-1(a5)
    80000eca:	ff65                	bnez	a4,80000ec2 <strlen+0x12>
    80000ecc:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000ed0:	60a2                	ld	ra,8(sp)
    80000ed2:	6402                	ld	s0,0(sp)
    80000ed4:	0141                	addi	sp,sp,16
    80000ed6:	8082                	ret
  for(n = 0; s[n]; n++)
    80000ed8:	4501                	li	a0,0
    80000eda:	bfdd                	j	80000ed0 <strlen+0x20>

0000000080000edc <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000edc:	1141                	addi	sp,sp,-16
    80000ede:	e406                	sd	ra,8(sp)
    80000ee0:	e022                	sd	s0,0(sp)
    80000ee2:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000ee4:	20d000ef          	jal	800018f0 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000ee8:	00007717          	auipc	a4,0x7
    80000eec:	a0070713          	addi	a4,a4,-1536 # 800078e8 <started>
  if(cpuid() == 0){
    80000ef0:	c515                	beqz	a0,80000f1c <main+0x40>
    while(started == 0)
    80000ef2:	431c                	lw	a5,0(a4)
    80000ef4:	dffd                	beqz	a5,80000ef2 <main+0x16>
      ;
    __sync_synchronize();
    80000ef6:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    80000efa:	1f7000ef          	jal	800018f0 <cpuid>
    80000efe:	85aa                	mv	a1,a0
    80000f00:	00006517          	auipc	a0,0x6
    80000f04:	19850513          	addi	a0,a0,408 # 80007098 <etext+0x98>
    80000f08:	dcaff0ef          	jal	800004d2 <printf>
    kvminithart();    // turn on paging
    80000f0c:	080000ef          	jal	80000f8c <kvminithart>
    trapinithart();   // install kernel trap vector
    80000f10:	4ea010ef          	jal	800023fa <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000f14:	334040ef          	jal	80005248 <plicinithart>
  }

  scheduler();        
    80000f18:	63b000ef          	jal	80001d52 <scheduler>
    consoleinit();
    80000f1c:	cdeff0ef          	jal	800003fa <consoleinit>
    printfinit();
    80000f20:	90bff0ef          	jal	8000082a <printfinit>
    printf("\n");
    80000f24:	00006517          	auipc	a0,0x6
    80000f28:	15450513          	addi	a0,a0,340 # 80007078 <etext+0x78>
    80000f2c:	da6ff0ef          	jal	800004d2 <printf>
    printf("xv6 kernel is booting\n");
    80000f30:	00006517          	auipc	a0,0x6
    80000f34:	15050513          	addi	a0,a0,336 # 80007080 <etext+0x80>
    80000f38:	d9aff0ef          	jal	800004d2 <printf>
    printf("\n");
    80000f3c:	00006517          	auipc	a0,0x6
    80000f40:	13c50513          	addi	a0,a0,316 # 80007078 <etext+0x78>
    80000f44:	d8eff0ef          	jal	800004d2 <printf>
    kinit();         // physical page allocator
    80000f48:	c05ff0ef          	jal	80000b4c <kinit>
    kvminit();       // create kernel page table
    80000f4c:	2c0000ef          	jal	8000120c <kvminit>
    kvminithart();   // turn on paging
    80000f50:	03c000ef          	jal	80000f8c <kvminithart>
    procinit();      // process table
    80000f54:	0e5000ef          	jal	80001838 <procinit>
    trapinit();      // trap vectors
    80000f58:	47e010ef          	jal	800023d6 <trapinit>
    trapinithart();  // install kernel trap vector
    80000f5c:	49e010ef          	jal	800023fa <trapinithart>
    plicinit();      // set up interrupt controller
    80000f60:	2ce040ef          	jal	8000522e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000f64:	2e4040ef          	jal	80005248 <plicinithart>
    binit();         // buffer cache
    80000f68:	2c3010ef          	jal	80002a2a <binit>
    iinit();         // inode table
    80000f6c:	086020ef          	jal	80002ff2 <iinit>
    fileinit();      // file table
    80000f70:	673020ef          	jal	80003de2 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000f74:	3c4040ef          	jal	80005338 <virtio_disk_init>
    userinit();      // first user process
    80000f78:	415000ef          	jal	80001b8c <userinit>
    __sync_synchronize();
    80000f7c:	0330000f          	fence	rw,rw
    started = 1;
    80000f80:	4785                	li	a5,1
    80000f82:	00007717          	auipc	a4,0x7
    80000f86:	96f72323          	sw	a5,-1690(a4) # 800078e8 <started>
    80000f8a:	b779                	j	80000f18 <main+0x3c>

0000000080000f8c <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    80000f8c:	1141                	addi	sp,sp,-16
    80000f8e:	e406                	sd	ra,8(sp)
    80000f90:	e022                	sd	s0,0(sp)
    80000f92:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000f94:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000f98:	00007797          	auipc	a5,0x7
    80000f9c:	9587b783          	ld	a5,-1704(a5) # 800078f0 <kernel_pagetable>
    80000fa0:	83b1                	srli	a5,a5,0xc
    80000fa2:	577d                	li	a4,-1
    80000fa4:	177e                	slli	a4,a4,0x3f
    80000fa6:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000fa8:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000fac:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000fb0:	60a2                	ld	ra,8(sp)
    80000fb2:	6402                	ld	s0,0(sp)
    80000fb4:	0141                	addi	sp,sp,16
    80000fb6:	8082                	ret

0000000080000fb8 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000fb8:	7139                	addi	sp,sp,-64
    80000fba:	fc06                	sd	ra,56(sp)
    80000fbc:	f822                	sd	s0,48(sp)
    80000fbe:	f426                	sd	s1,40(sp)
    80000fc0:	f04a                	sd	s2,32(sp)
    80000fc2:	ec4e                	sd	s3,24(sp)
    80000fc4:	e852                	sd	s4,16(sp)
    80000fc6:	e456                	sd	s5,8(sp)
    80000fc8:	e05a                	sd	s6,0(sp)
    80000fca:	0080                	addi	s0,sp,64
    80000fcc:	84aa                	mv	s1,a0
    80000fce:	89ae                	mv	s3,a1
    80000fd0:	8b32                	mv	s6,a2
  if(va >= MAXVA)
    80000fd2:	57fd                	li	a5,-1
    80000fd4:	83e9                	srli	a5,a5,0x1a
    80000fd6:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000fd8:	4ab1                	li	s5,12
  if(va >= MAXVA)
    80000fda:	06b7e363          	bltu	a5,a1,80001040 <walk+0x88>
    pte_t *pte = &pagetable[PX(level, va)];
    80000fde:	0149d933          	srl	s2,s3,s4
    80000fe2:	1ff97913          	andi	s2,s2,511
    80000fe6:	090e                	slli	s2,s2,0x3
    80000fe8:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000fea:	00093483          	ld	s1,0(s2)
    80000fee:	0014f793          	andi	a5,s1,1
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000ff2:	80a9                	srli	s1,s1,0xa
    80000ff4:	04b2                	slli	s1,s1,0xc
    if(*pte & PTE_V) {
    80000ff6:	e395                	bnez	a5,8000101a <walk+0x62>
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000ff8:	040b0a63          	beqz	s6,8000104c <walk+0x94>
    80000ffc:	b85ff0ef          	jal	80000b80 <kalloc>
    80001000:	84aa                	mv	s1,a0
    80001002:	c50d                	beqz	a0,8000102c <walk+0x74>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80001004:	6605                	lui	a2,0x1
    80001006:	4581                	li	a1,0
    80001008:	d29ff0ef          	jal	80000d30 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    8000100c:	00c4d793          	srli	a5,s1,0xc
    80001010:	07aa                	slli	a5,a5,0xa
    80001012:	0017e793          	ori	a5,a5,1
    80001016:	00f93023          	sd	a5,0(s2)
  for(int level = 2; level > 0; level--) {
    8000101a:	3a5d                	addiw	s4,s4,-9
    8000101c:	fd5a11e3          	bne	s4,s5,80000fde <walk+0x26>
    }
  }
  return &pagetable[PX(0, va)];
    80001020:	00c9d513          	srli	a0,s3,0xc
    80001024:	1ff57513          	andi	a0,a0,511
    80001028:	050e                	slli	a0,a0,0x3
    8000102a:	9526                	add	a0,a0,s1
}
    8000102c:	70e2                	ld	ra,56(sp)
    8000102e:	7442                	ld	s0,48(sp)
    80001030:	74a2                	ld	s1,40(sp)
    80001032:	7902                	ld	s2,32(sp)
    80001034:	69e2                	ld	s3,24(sp)
    80001036:	6a42                	ld	s4,16(sp)
    80001038:	6aa2                	ld	s5,8(sp)
    8000103a:	6b02                	ld	s6,0(sp)
    8000103c:	6121                	addi	sp,sp,64
    8000103e:	8082                	ret
    panic("walk");
    80001040:	00006517          	auipc	a0,0x6
    80001044:	07050513          	addi	a0,a0,112 # 800070b0 <etext+0xb0>
    80001048:	fa8ff0ef          	jal	800007f0 <panic>
        return 0;
    8000104c:	4501                	li	a0,0
    8000104e:	bff9                	j	8000102c <walk+0x74>

0000000080001050 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    80001050:	57fd                	li	a5,-1
    80001052:	83e9                	srli	a5,a5,0x1a
    80001054:	00b7f463          	bgeu	a5,a1,8000105c <walkaddr+0xc>
    return 0;
    80001058:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    8000105a:	8082                	ret
{
    8000105c:	1141                	addi	sp,sp,-16
    8000105e:	e406                	sd	ra,8(sp)
    80001060:	e022                	sd	s0,0(sp)
    80001062:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80001064:	4601                	li	a2,0
    80001066:	f53ff0ef          	jal	80000fb8 <walk>
  if(pte == 0)
    8000106a:	c519                	beqz	a0,80001078 <walkaddr+0x28>
  if((*pte & PTE_V) == 0)
    8000106c:	6108                	ld	a0,0(a0)
  if((*pte & PTE_U) == 0)
    8000106e:	01157713          	andi	a4,a0,17
    80001072:	47c5                	li	a5,17
    80001074:	00f70763          	beq	a4,a5,80001082 <walkaddr+0x32>
    return 0;
    80001078:	4501                	li	a0,0
}
    8000107a:	60a2                	ld	ra,8(sp)
    8000107c:	6402                	ld	s0,0(sp)
    8000107e:	0141                	addi	sp,sp,16
    80001080:	8082                	ret
  pa = PTE2PA(*pte);
    80001082:	8129                	srli	a0,a0,0xa
    80001084:	0532                	slli	a0,a0,0xc
  return pa;
    80001086:	bfd5                	j	8000107a <walkaddr+0x2a>

0000000080001088 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001088:	715d                	addi	sp,sp,-80
    8000108a:	e486                	sd	ra,72(sp)
    8000108c:	e0a2                	sd	s0,64(sp)
    8000108e:	fc26                	sd	s1,56(sp)
    80001090:	f84a                	sd	s2,48(sp)
    80001092:	f44e                	sd	s3,40(sp)
    80001094:	f052                	sd	s4,32(sp)
    80001096:	ec56                	sd	s5,24(sp)
    80001098:	e85a                	sd	s6,16(sp)
    8000109a:	e45e                	sd	s7,8(sp)
    8000109c:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    8000109e:	03459793          	slli	a5,a1,0x34
    800010a2:	e7b1                	bnez	a5,800010ee <mappages+0x66>
    800010a4:	8a2a                	mv	s4,a0
    800010a6:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    800010a8:	03461793          	slli	a5,a2,0x34
    800010ac:	e7b9                	bnez	a5,800010fa <mappages+0x72>
    panic("mappages: size not aligned");

  if(size == 0)
    800010ae:	ce21                	beqz	a2,80001106 <mappages+0x7e>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    800010b0:	77fd                	lui	a5,0xfffff
    800010b2:	963e                	add	a2,a2,a5
    800010b4:	00b60933          	add	s2,a2,a1
  a = va;
    800010b8:	84ae                	mv	s1,a1
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
    800010ba:	4b05                	li	s6,1
    800010bc:	40b689b3          	sub	s3,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    800010c0:	6b85                	lui	s7,0x1
    if((pte = walk(pagetable, a, 1)) == 0)
    800010c2:	865a                	mv	a2,s6
    800010c4:	85a6                	mv	a1,s1
    800010c6:	8552                	mv	a0,s4
    800010c8:	ef1ff0ef          	jal	80000fb8 <walk>
    800010cc:	c929                	beqz	a0,8000111e <mappages+0x96>
    if(*pte & PTE_V)
    800010ce:	611c                	ld	a5,0(a0)
    800010d0:	8b85                	andi	a5,a5,1
    800010d2:	e3a1                	bnez	a5,80001112 <mappages+0x8a>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800010d4:	013487b3          	add	a5,s1,s3
    800010d8:	83b1                	srli	a5,a5,0xc
    800010da:	07aa                	slli	a5,a5,0xa
    800010dc:	0157e7b3          	or	a5,a5,s5
    800010e0:	0017e793          	ori	a5,a5,1
    800010e4:	e11c                	sd	a5,0(a0)
    if(a == last)
    800010e6:	05248863          	beq	s1,s2,80001136 <mappages+0xae>
    a += PGSIZE;
    800010ea:	94de                	add	s1,s1,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    800010ec:	bfd9                	j	800010c2 <mappages+0x3a>
    panic("mappages: va not aligned");
    800010ee:	00006517          	auipc	a0,0x6
    800010f2:	fca50513          	addi	a0,a0,-54 # 800070b8 <etext+0xb8>
    800010f6:	efaff0ef          	jal	800007f0 <panic>
    panic("mappages: size not aligned");
    800010fa:	00006517          	auipc	a0,0x6
    800010fe:	fde50513          	addi	a0,a0,-34 # 800070d8 <etext+0xd8>
    80001102:	eeeff0ef          	jal	800007f0 <panic>
    panic("mappages: size");
    80001106:	00006517          	auipc	a0,0x6
    8000110a:	ff250513          	addi	a0,a0,-14 # 800070f8 <etext+0xf8>
    8000110e:	ee2ff0ef          	jal	800007f0 <panic>
      panic("mappages: remap");
    80001112:	00006517          	auipc	a0,0x6
    80001116:	ff650513          	addi	a0,a0,-10 # 80007108 <etext+0x108>
    8000111a:	ed6ff0ef          	jal	800007f0 <panic>
      return -1;
    8000111e:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80001120:	60a6                	ld	ra,72(sp)
    80001122:	6406                	ld	s0,64(sp)
    80001124:	74e2                	ld	s1,56(sp)
    80001126:	7942                	ld	s2,48(sp)
    80001128:	79a2                	ld	s3,40(sp)
    8000112a:	7a02                	ld	s4,32(sp)
    8000112c:	6ae2                	ld	s5,24(sp)
    8000112e:	6b42                	ld	s6,16(sp)
    80001130:	6ba2                	ld	s7,8(sp)
    80001132:	6161                	addi	sp,sp,80
    80001134:	8082                	ret
  return 0;
    80001136:	4501                	li	a0,0
    80001138:	b7e5                	j	80001120 <mappages+0x98>

000000008000113a <kvmmap>:
{
    8000113a:	1141                	addi	sp,sp,-16
    8000113c:	e406                	sd	ra,8(sp)
    8000113e:	e022                	sd	s0,0(sp)
    80001140:	0800                	addi	s0,sp,16
    80001142:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80001144:	86b2                	mv	a3,a2
    80001146:	863e                	mv	a2,a5
    80001148:	f41ff0ef          	jal	80001088 <mappages>
    8000114c:	e509                	bnez	a0,80001156 <kvmmap+0x1c>
}
    8000114e:	60a2                	ld	ra,8(sp)
    80001150:	6402                	ld	s0,0(sp)
    80001152:	0141                	addi	sp,sp,16
    80001154:	8082                	ret
    panic("kvmmap");
    80001156:	00006517          	auipc	a0,0x6
    8000115a:	fc250513          	addi	a0,a0,-62 # 80007118 <etext+0x118>
    8000115e:	e92ff0ef          	jal	800007f0 <panic>

0000000080001162 <kvmmake>:
{
    80001162:	1101                	addi	sp,sp,-32
    80001164:	ec06                	sd	ra,24(sp)
    80001166:	e822                	sd	s0,16(sp)
    80001168:	e426                	sd	s1,8(sp)
    8000116a:	e04a                	sd	s2,0(sp)
    8000116c:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    8000116e:	a13ff0ef          	jal	80000b80 <kalloc>
    80001172:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80001174:	6605                	lui	a2,0x1
    80001176:	4581                	li	a1,0
    80001178:	bb9ff0ef          	jal	80000d30 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    8000117c:	4719                	li	a4,6
    8000117e:	6685                	lui	a3,0x1
    80001180:	10000637          	lui	a2,0x10000
    80001184:	85b2                	mv	a1,a2
    80001186:	8526                	mv	a0,s1
    80001188:	fb3ff0ef          	jal	8000113a <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    8000118c:	4719                	li	a4,6
    8000118e:	6685                	lui	a3,0x1
    80001190:	10001637          	lui	a2,0x10001
    80001194:	85b2                	mv	a1,a2
    80001196:	8526                	mv	a0,s1
    80001198:	fa3ff0ef          	jal	8000113a <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    8000119c:	4719                	li	a4,6
    8000119e:	040006b7          	lui	a3,0x4000
    800011a2:	0c000637          	lui	a2,0xc000
    800011a6:	85b2                	mv	a1,a2
    800011a8:	8526                	mv	a0,s1
    800011aa:	f91ff0ef          	jal	8000113a <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    800011ae:	00006917          	auipc	s2,0x6
    800011b2:	e5290913          	addi	s2,s2,-430 # 80007000 <etext>
    800011b6:	4729                	li	a4,10
    800011b8:	800006b7          	lui	a3,0x80000
    800011bc:	96ca                	add	a3,a3,s2
    800011be:	4605                	li	a2,1
    800011c0:	067e                	slli	a2,a2,0x1f
    800011c2:	85b2                	mv	a1,a2
    800011c4:	8526                	mv	a0,s1
    800011c6:	f75ff0ef          	jal	8000113a <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    800011ca:	4719                	li	a4,6
    800011cc:	46c5                	li	a3,17
    800011ce:	06ee                	slli	a3,a3,0x1b
    800011d0:	412686b3          	sub	a3,a3,s2
    800011d4:	864a                	mv	a2,s2
    800011d6:	85ca                	mv	a1,s2
    800011d8:	8526                	mv	a0,s1
    800011da:	f61ff0ef          	jal	8000113a <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800011de:	4729                	li	a4,10
    800011e0:	6685                	lui	a3,0x1
    800011e2:	00005617          	auipc	a2,0x5
    800011e6:	e1e60613          	addi	a2,a2,-482 # 80006000 <_trampoline>
    800011ea:	040005b7          	lui	a1,0x4000
    800011ee:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800011f0:	05b2                	slli	a1,a1,0xc
    800011f2:	8526                	mv	a0,s1
    800011f4:	f47ff0ef          	jal	8000113a <kvmmap>
  proc_mapstacks(kpgtbl);
    800011f8:	8526                	mv	a0,s1
    800011fa:	5aa000ef          	jal	800017a4 <proc_mapstacks>
}
    800011fe:	8526                	mv	a0,s1
    80001200:	60e2                	ld	ra,24(sp)
    80001202:	6442                	ld	s0,16(sp)
    80001204:	64a2                	ld	s1,8(sp)
    80001206:	6902                	ld	s2,0(sp)
    80001208:	6105                	addi	sp,sp,32
    8000120a:	8082                	ret

000000008000120c <kvminit>:
{
    8000120c:	1141                	addi	sp,sp,-16
    8000120e:	e406                	sd	ra,8(sp)
    80001210:	e022                	sd	s0,0(sp)
    80001212:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    80001214:	f4fff0ef          	jal	80001162 <kvmmake>
    80001218:	00006797          	auipc	a5,0x6
    8000121c:	6ca7bc23          	sd	a0,1752(a5) # 800078f0 <kernel_pagetable>
}
    80001220:	60a2                	ld	ra,8(sp)
    80001222:	6402                	ld	s0,0(sp)
    80001224:	0141                	addi	sp,sp,16
    80001226:	8082                	ret

0000000080001228 <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    80001228:	715d                	addi	sp,sp,-80
    8000122a:	e486                	sd	ra,72(sp)
    8000122c:	e0a2                	sd	s0,64(sp)
    8000122e:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001230:	03459793          	slli	a5,a1,0x34
    80001234:	e39d                	bnez	a5,8000125a <uvmunmap+0x32>
    80001236:	f84a                	sd	s2,48(sp)
    80001238:	f44e                	sd	s3,40(sp)
    8000123a:	f052                	sd	s4,32(sp)
    8000123c:	ec56                	sd	s5,24(sp)
    8000123e:	e85a                	sd	s6,16(sp)
    80001240:	e45e                	sd	s7,8(sp)
    80001242:	8a2a                	mv	s4,a0
    80001244:	892e                	mv	s2,a1
    80001246:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001248:	0632                	slli	a2,a2,0xc
    8000124a:	00b609b3          	add	s3,a2,a1
    if((pte = walk(pagetable, a, 0)) == 0)
      panic("uvmunmap: walk");
    if((*pte & PTE_V) == 0)
      panic("uvmunmap: not mapped");
    if(PTE_FLAGS(*pte) == PTE_V)
    8000124e:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001250:	6b05                	lui	s6,0x1
    80001252:	0735ff63          	bgeu	a1,s3,800012d0 <uvmunmap+0xa8>
    80001256:	fc26                	sd	s1,56(sp)
    80001258:	a0a9                	j	800012a2 <uvmunmap+0x7a>
    8000125a:	fc26                	sd	s1,56(sp)
    8000125c:	f84a                	sd	s2,48(sp)
    8000125e:	f44e                	sd	s3,40(sp)
    80001260:	f052                	sd	s4,32(sp)
    80001262:	ec56                	sd	s5,24(sp)
    80001264:	e85a                	sd	s6,16(sp)
    80001266:	e45e                	sd	s7,8(sp)
    panic("uvmunmap: not aligned");
    80001268:	00006517          	auipc	a0,0x6
    8000126c:	eb850513          	addi	a0,a0,-328 # 80007120 <etext+0x120>
    80001270:	d80ff0ef          	jal	800007f0 <panic>
      panic("uvmunmap: walk");
    80001274:	00006517          	auipc	a0,0x6
    80001278:	ec450513          	addi	a0,a0,-316 # 80007138 <etext+0x138>
    8000127c:	d74ff0ef          	jal	800007f0 <panic>
      panic("uvmunmap: not mapped");
    80001280:	00006517          	auipc	a0,0x6
    80001284:	ec850513          	addi	a0,a0,-312 # 80007148 <etext+0x148>
    80001288:	d68ff0ef          	jal	800007f0 <panic>
      panic("uvmunmap: not a leaf");
    8000128c:	00006517          	auipc	a0,0x6
    80001290:	ed450513          	addi	a0,a0,-300 # 80007160 <etext+0x160>
    80001294:	d5cff0ef          	jal	800007f0 <panic>
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    80001298:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    8000129c:	995a                	add	s2,s2,s6
    8000129e:	03397863          	bgeu	s2,s3,800012ce <uvmunmap+0xa6>
    if((pte = walk(pagetable, a, 0)) == 0)
    800012a2:	4601                	li	a2,0
    800012a4:	85ca                	mv	a1,s2
    800012a6:	8552                	mv	a0,s4
    800012a8:	d11ff0ef          	jal	80000fb8 <walk>
    800012ac:	84aa                	mv	s1,a0
    800012ae:	d179                	beqz	a0,80001274 <uvmunmap+0x4c>
    if((*pte & PTE_V) == 0)
    800012b0:	6108                	ld	a0,0(a0)
    800012b2:	00157793          	andi	a5,a0,1
    800012b6:	d7e9                	beqz	a5,80001280 <uvmunmap+0x58>
    if(PTE_FLAGS(*pte) == PTE_V)
    800012b8:	3ff57793          	andi	a5,a0,1023
    800012bc:	fd7788e3          	beq	a5,s7,8000128c <uvmunmap+0x64>
    if(do_free){
    800012c0:	fc0a8ce3          	beqz	s5,80001298 <uvmunmap+0x70>
      uint64 pa = PTE2PA(*pte);
    800012c4:	8129                	srli	a0,a0,0xa
      kfree((void*)pa);
    800012c6:	0532                	slli	a0,a0,0xc
    800012c8:	fd0ff0ef          	jal	80000a98 <kfree>
    800012cc:	b7f1                	j	80001298 <uvmunmap+0x70>
    800012ce:	74e2                	ld	s1,56(sp)
    800012d0:	7942                	ld	s2,48(sp)
    800012d2:	79a2                	ld	s3,40(sp)
    800012d4:	7a02                	ld	s4,32(sp)
    800012d6:	6ae2                	ld	s5,24(sp)
    800012d8:	6b42                	ld	s6,16(sp)
    800012da:	6ba2                	ld	s7,8(sp)
  }
}
    800012dc:	60a6                	ld	ra,72(sp)
    800012de:	6406                	ld	s0,64(sp)
    800012e0:	6161                	addi	sp,sp,80
    800012e2:	8082                	ret

00000000800012e4 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    800012e4:	1101                	addi	sp,sp,-32
    800012e6:	ec06                	sd	ra,24(sp)
    800012e8:	e822                	sd	s0,16(sp)
    800012ea:	e426                	sd	s1,8(sp)
    800012ec:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    800012ee:	893ff0ef          	jal	80000b80 <kalloc>
    800012f2:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800012f4:	c509                	beqz	a0,800012fe <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    800012f6:	6605                	lui	a2,0x1
    800012f8:	4581                	li	a1,0
    800012fa:	a37ff0ef          	jal	80000d30 <memset>
  return pagetable;
}
    800012fe:	8526                	mv	a0,s1
    80001300:	60e2                	ld	ra,24(sp)
    80001302:	6442                	ld	s0,16(sp)
    80001304:	64a2                	ld	s1,8(sp)
    80001306:	6105                	addi	sp,sp,32
    80001308:	8082                	ret

000000008000130a <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    8000130a:	7179                	addi	sp,sp,-48
    8000130c:	f406                	sd	ra,40(sp)
    8000130e:	f022                	sd	s0,32(sp)
    80001310:	ec26                	sd	s1,24(sp)
    80001312:	e84a                	sd	s2,16(sp)
    80001314:	e44e                	sd	s3,8(sp)
    80001316:	e052                	sd	s4,0(sp)
    80001318:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    8000131a:	6785                	lui	a5,0x1
    8000131c:	04f67063          	bgeu	a2,a5,8000135c <uvmfirst+0x52>
    80001320:	89aa                	mv	s3,a0
    80001322:	8a2e                	mv	s4,a1
    80001324:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    80001326:	85bff0ef          	jal	80000b80 <kalloc>
    8000132a:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    8000132c:	6605                	lui	a2,0x1
    8000132e:	4581                	li	a1,0
    80001330:	a01ff0ef          	jal	80000d30 <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    80001334:	4779                	li	a4,30
    80001336:	86ca                	mv	a3,s2
    80001338:	6605                	lui	a2,0x1
    8000133a:	4581                	li	a1,0
    8000133c:	854e                	mv	a0,s3
    8000133e:	d4bff0ef          	jal	80001088 <mappages>
  memmove(mem, src, sz);
    80001342:	8626                	mv	a2,s1
    80001344:	85d2                	mv	a1,s4
    80001346:	854a                	mv	a0,s2
    80001348:	a45ff0ef          	jal	80000d8c <memmove>
}
    8000134c:	70a2                	ld	ra,40(sp)
    8000134e:	7402                	ld	s0,32(sp)
    80001350:	64e2                	ld	s1,24(sp)
    80001352:	6942                	ld	s2,16(sp)
    80001354:	69a2                	ld	s3,8(sp)
    80001356:	6a02                	ld	s4,0(sp)
    80001358:	6145                	addi	sp,sp,48
    8000135a:	8082                	ret
    panic("uvmfirst: more than a page");
    8000135c:	00006517          	auipc	a0,0x6
    80001360:	e1c50513          	addi	a0,a0,-484 # 80007178 <etext+0x178>
    80001364:	c8cff0ef          	jal	800007f0 <panic>

0000000080001368 <uvmdealloc>:
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
  if(newsz >= oldsz)
    80001368:	04b67163          	bgeu	a2,a1,800013aa <uvmdealloc+0x42>
{
    8000136c:	1101                	addi	sp,sp,-32
    8000136e:	ec06                	sd	ra,24(sp)
    80001370:	e822                	sd	s0,16(sp)
    80001372:	e426                	sd	s1,8(sp)
    80001374:	1000                	addi	s0,sp,32
    80001376:	84b2                	mv	s1,a2
    return oldsz;

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    80001378:	6785                	lui	a5,0x1
    8000137a:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000137c:	00f60733          	add	a4,a2,a5
    80001380:	76fd                	lui	a3,0xfffff
    80001382:	8f75                	and	a4,a4,a3
    80001384:	97ae                	add	a5,a5,a1
    80001386:	8ff5                	and	a5,a5,a3
    80001388:	00f76863          	bltu	a4,a5,80001398 <uvmdealloc+0x30>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
    8000138c:	8526                	mv	a0,s1
}
    8000138e:	60e2                	ld	ra,24(sp)
    80001390:	6442                	ld	s0,16(sp)
    80001392:	64a2                	ld	s1,8(sp)
    80001394:	6105                	addi	sp,sp,32
    80001396:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    80001398:	8f99                	sub	a5,a5,a4
    8000139a:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    8000139c:	4685                	li	a3,1
    8000139e:	0007861b          	sext.w	a2,a5
    800013a2:	85ba                	mv	a1,a4
    800013a4:	e85ff0ef          	jal	80001228 <uvmunmap>
    800013a8:	b7d5                	j	8000138c <uvmdealloc+0x24>
    return oldsz;
    800013aa:	852e                	mv	a0,a1
}
    800013ac:	8082                	ret

00000000800013ae <uvmalloc>:
  if(newsz < oldsz)
    800013ae:	08b66e63          	bltu	a2,a1,8000144a <uvmalloc+0x9c>
{
    800013b2:	715d                	addi	sp,sp,-80
    800013b4:	e486                	sd	ra,72(sp)
    800013b6:	e0a2                	sd	s0,64(sp)
    800013b8:	f052                	sd	s4,32(sp)
    800013ba:	ec56                	sd	s5,24(sp)
    800013bc:	e45e                	sd	s7,8(sp)
    800013be:	0880                	addi	s0,sp,80
    800013c0:	8aaa                	mv	s5,a0
    800013c2:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800013c4:	6785                	lui	a5,0x1
    800013c6:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800013c8:	95be                	add	a1,a1,a5
    800013ca:	77fd                	lui	a5,0xfffff
    800013cc:	8fed                	and	a5,a5,a1
    800013ce:	8bbe                	mv	s7,a5
  for(a = oldsz; a < newsz; a += PGSIZE){
    800013d0:	04c7f163          	bgeu	a5,a2,80001412 <uvmalloc+0x64>
    800013d4:	fc26                	sd	s1,56(sp)
    800013d6:	f84a                	sd	s2,48(sp)
    800013d8:	f44e                	sd	s3,40(sp)
    800013da:	e85a                	sd	s6,16(sp)
    800013dc:	893e                	mv	s2,a5
    memset(mem, 0, PGSIZE);
    800013de:	6985                	lui	s3,0x1
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800013e0:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    800013e4:	f9cff0ef          	jal	80000b80 <kalloc>
    800013e8:	84aa                	mv	s1,a0
    if(mem == 0){
    800013ea:	c515                	beqz	a0,80001416 <uvmalloc+0x68>
    memset(mem, 0, PGSIZE);
    800013ec:	864e                	mv	a2,s3
    800013ee:	4581                	li	a1,0
    800013f0:	941ff0ef          	jal	80000d30 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800013f4:	875a                	mv	a4,s6
    800013f6:	86a6                	mv	a3,s1
    800013f8:	864e                	mv	a2,s3
    800013fa:	85ca                	mv	a1,s2
    800013fc:	8556                	mv	a0,s5
    800013fe:	c8bff0ef          	jal	80001088 <mappages>
    80001402:	e91d                	bnez	a0,80001438 <uvmalloc+0x8a>
  for(a = oldsz; a < newsz; a += PGSIZE){
    80001404:	994e                	add	s2,s2,s3
    80001406:	fd496fe3          	bltu	s2,s4,800013e4 <uvmalloc+0x36>
    8000140a:	74e2                	ld	s1,56(sp)
    8000140c:	7942                	ld	s2,48(sp)
    8000140e:	79a2                	ld	s3,40(sp)
    80001410:	6b42                	ld	s6,16(sp)
  return newsz;
    80001412:	8552                	mv	a0,s4
    80001414:	a819                	j	8000142a <uvmalloc+0x7c>
      uvmdealloc(pagetable, a, oldsz);
    80001416:	865e                	mv	a2,s7
    80001418:	85ca                	mv	a1,s2
    8000141a:	8556                	mv	a0,s5
    8000141c:	f4dff0ef          	jal	80001368 <uvmdealloc>
      return 0;
    80001420:	4501                	li	a0,0
    80001422:	74e2                	ld	s1,56(sp)
    80001424:	7942                	ld	s2,48(sp)
    80001426:	79a2                	ld	s3,40(sp)
    80001428:	6b42                	ld	s6,16(sp)
}
    8000142a:	60a6                	ld	ra,72(sp)
    8000142c:	6406                	ld	s0,64(sp)
    8000142e:	7a02                	ld	s4,32(sp)
    80001430:	6ae2                	ld	s5,24(sp)
    80001432:	6ba2                	ld	s7,8(sp)
    80001434:	6161                	addi	sp,sp,80
    80001436:	8082                	ret
      kfree(mem);
    80001438:	8526                	mv	a0,s1
    8000143a:	e5eff0ef          	jal	80000a98 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    8000143e:	865e                	mv	a2,s7
    80001440:	85ca                	mv	a1,s2
    80001442:	8556                	mv	a0,s5
    80001444:	f25ff0ef          	jal	80001368 <uvmdealloc>
      return 0;
    80001448:	bfe1                	j	80001420 <uvmalloc+0x72>
    return oldsz;
    8000144a:	852e                	mv	a0,a1
}
    8000144c:	8082                	ret

000000008000144e <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    8000144e:	7179                	addi	sp,sp,-48
    80001450:	f406                	sd	ra,40(sp)
    80001452:	f022                	sd	s0,32(sp)
    80001454:	ec26                	sd	s1,24(sp)
    80001456:	e84a                	sd	s2,16(sp)
    80001458:	e44e                	sd	s3,8(sp)
    8000145a:	1800                	addi	s0,sp,48
    8000145c:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    8000145e:	84aa                	mv	s1,a0
    80001460:	6905                	lui	s2,0x1
    80001462:	992a                	add	s2,s2,a0
    80001464:	a811                	j	80001478 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      panic("freewalk: leaf");
    80001466:	00006517          	auipc	a0,0x6
    8000146a:	d3250513          	addi	a0,a0,-718 # 80007198 <etext+0x198>
    8000146e:	b82ff0ef          	jal	800007f0 <panic>
  for(int i = 0; i < 512; i++){
    80001472:	04a1                	addi	s1,s1,8
    80001474:	03248163          	beq	s1,s2,80001496 <freewalk+0x48>
    pte_t pte = pagetable[i];
    80001478:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    8000147a:	0017f713          	andi	a4,a5,1
    8000147e:	db75                	beqz	a4,80001472 <freewalk+0x24>
    80001480:	00e7f713          	andi	a4,a5,14
    80001484:	f36d                	bnez	a4,80001466 <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    80001486:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    80001488:	00c79513          	slli	a0,a5,0xc
    8000148c:	fc3ff0ef          	jal	8000144e <freewalk>
      pagetable[i] = 0;
    80001490:	0004b023          	sd	zero,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80001494:	bff9                	j	80001472 <freewalk+0x24>
    }
  }
  kfree((void*)pagetable);
    80001496:	854e                	mv	a0,s3
    80001498:	e00ff0ef          	jal	80000a98 <kfree>
}
    8000149c:	70a2                	ld	ra,40(sp)
    8000149e:	7402                	ld	s0,32(sp)
    800014a0:	64e2                	ld	s1,24(sp)
    800014a2:	6942                	ld	s2,16(sp)
    800014a4:	69a2                	ld	s3,8(sp)
    800014a6:	6145                	addi	sp,sp,48
    800014a8:	8082                	ret

00000000800014aa <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800014aa:	1101                	addi	sp,sp,-32
    800014ac:	ec06                	sd	ra,24(sp)
    800014ae:	e822                	sd	s0,16(sp)
    800014b0:	e426                	sd	s1,8(sp)
    800014b2:	1000                	addi	s0,sp,32
    800014b4:	84aa                	mv	s1,a0
  if(sz > 0)
    800014b6:	e989                	bnez	a1,800014c8 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    800014b8:	8526                	mv	a0,s1
    800014ba:	f95ff0ef          	jal	8000144e <freewalk>
}
    800014be:	60e2                	ld	ra,24(sp)
    800014c0:	6442                	ld	s0,16(sp)
    800014c2:	64a2                	ld	s1,8(sp)
    800014c4:	6105                	addi	sp,sp,32
    800014c6:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    800014c8:	6785                	lui	a5,0x1
    800014ca:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800014cc:	95be                	add	a1,a1,a5
    800014ce:	4685                	li	a3,1
    800014d0:	00c5d613          	srli	a2,a1,0xc
    800014d4:	4581                	li	a1,0
    800014d6:	d53ff0ef          	jal	80001228 <uvmunmap>
    800014da:	bff9                	j	800014b8 <uvmfree+0xe>

00000000800014dc <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    800014dc:	c64d                	beqz	a2,80001586 <uvmcopy+0xaa>
{
    800014de:	715d                	addi	sp,sp,-80
    800014e0:	e486                	sd	ra,72(sp)
    800014e2:	e0a2                	sd	s0,64(sp)
    800014e4:	fc26                	sd	s1,56(sp)
    800014e6:	f84a                	sd	s2,48(sp)
    800014e8:	f44e                	sd	s3,40(sp)
    800014ea:	f052                	sd	s4,32(sp)
    800014ec:	ec56                	sd	s5,24(sp)
    800014ee:	e85a                	sd	s6,16(sp)
    800014f0:	e45e                	sd	s7,8(sp)
    800014f2:	0880                	addi	s0,sp,80
    800014f4:	8b2a                	mv	s6,a0
    800014f6:	8aae                	mv	s5,a1
    800014f8:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    800014fa:	4901                	li	s2,0
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    800014fc:	6985                	lui	s3,0x1
    if((pte = walk(old, i, 0)) == 0)
    800014fe:	4601                	li	a2,0
    80001500:	85ca                	mv	a1,s2
    80001502:	855a                	mv	a0,s6
    80001504:	ab5ff0ef          	jal	80000fb8 <walk>
    80001508:	cd0d                	beqz	a0,80001542 <uvmcopy+0x66>
    if((*pte & PTE_V) == 0)
    8000150a:	00053b83          	ld	s7,0(a0)
    8000150e:	001bf793          	andi	a5,s7,1
    80001512:	cf95                	beqz	a5,8000154e <uvmcopy+0x72>
    if((mem = kalloc()) == 0)
    80001514:	e6cff0ef          	jal	80000b80 <kalloc>
    80001518:	84aa                	mv	s1,a0
    8000151a:	c139                	beqz	a0,80001560 <uvmcopy+0x84>
    pa = PTE2PA(*pte);
    8000151c:	00abd593          	srli	a1,s7,0xa
    memmove(mem, (char*)pa, PGSIZE);
    80001520:	864e                	mv	a2,s3
    80001522:	05b2                	slli	a1,a1,0xc
    80001524:	869ff0ef          	jal	80000d8c <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    80001528:	3ffbf713          	andi	a4,s7,1023
    8000152c:	86a6                	mv	a3,s1
    8000152e:	864e                	mv	a2,s3
    80001530:	85ca                	mv	a1,s2
    80001532:	8556                	mv	a0,s5
    80001534:	b55ff0ef          	jal	80001088 <mappages>
    80001538:	e10d                	bnez	a0,8000155a <uvmcopy+0x7e>
  for(i = 0; i < sz; i += PGSIZE){
    8000153a:	994e                	add	s2,s2,s3
    8000153c:	fd4961e3          	bltu	s2,s4,800014fe <uvmcopy+0x22>
    80001540:	a805                	j	80001570 <uvmcopy+0x94>
      panic("uvmcopy: pte should exist");
    80001542:	00006517          	auipc	a0,0x6
    80001546:	c6650513          	addi	a0,a0,-922 # 800071a8 <etext+0x1a8>
    8000154a:	aa6ff0ef          	jal	800007f0 <panic>
      panic("uvmcopy: page not present");
    8000154e:	00006517          	auipc	a0,0x6
    80001552:	c7a50513          	addi	a0,a0,-902 # 800071c8 <etext+0x1c8>
    80001556:	a9aff0ef          	jal	800007f0 <panic>
      kfree(mem);
    8000155a:	8526                	mv	a0,s1
    8000155c:	d3cff0ef          	jal	80000a98 <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80001560:	4685                	li	a3,1
    80001562:	00c95613          	srli	a2,s2,0xc
    80001566:	4581                	li	a1,0
    80001568:	8556                	mv	a0,s5
    8000156a:	cbfff0ef          	jal	80001228 <uvmunmap>
  return -1;
    8000156e:	557d                	li	a0,-1
}
    80001570:	60a6                	ld	ra,72(sp)
    80001572:	6406                	ld	s0,64(sp)
    80001574:	74e2                	ld	s1,56(sp)
    80001576:	7942                	ld	s2,48(sp)
    80001578:	79a2                	ld	s3,40(sp)
    8000157a:	7a02                	ld	s4,32(sp)
    8000157c:	6ae2                	ld	s5,24(sp)
    8000157e:	6b42                	ld	s6,16(sp)
    80001580:	6ba2                	ld	s7,8(sp)
    80001582:	6161                	addi	sp,sp,80
    80001584:	8082                	ret
  return 0;
    80001586:	4501                	li	a0,0
}
    80001588:	8082                	ret

000000008000158a <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    8000158a:	1141                	addi	sp,sp,-16
    8000158c:	e406                	sd	ra,8(sp)
    8000158e:	e022                	sd	s0,0(sp)
    80001590:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    80001592:	4601                	li	a2,0
    80001594:	a25ff0ef          	jal	80000fb8 <walk>
  if(pte == 0)
    80001598:	c901                	beqz	a0,800015a8 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    8000159a:	611c                	ld	a5,0(a0)
    8000159c:	9bbd                	andi	a5,a5,-17
    8000159e:	e11c                	sd	a5,0(a0)
}
    800015a0:	60a2                	ld	ra,8(sp)
    800015a2:	6402                	ld	s0,0(sp)
    800015a4:	0141                	addi	sp,sp,16
    800015a6:	8082                	ret
    panic("uvmclear");
    800015a8:	00006517          	auipc	a0,0x6
    800015ac:	c4050513          	addi	a0,a0,-960 # 800071e8 <etext+0x1e8>
    800015b0:	a40ff0ef          	jal	800007f0 <panic>

00000000800015b4 <copyout>:
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  while(len > 0){
    800015b4:	c6cd                	beqz	a3,8000165e <copyout+0xaa>
{
    800015b6:	711d                	addi	sp,sp,-96
    800015b8:	ec86                	sd	ra,88(sp)
    800015ba:	e8a2                	sd	s0,80(sp)
    800015bc:	e4a6                	sd	s1,72(sp)
    800015be:	e0ca                	sd	s2,64(sp)
    800015c0:	fc4e                	sd	s3,56(sp)
    800015c2:	f852                	sd	s4,48(sp)
    800015c4:	f456                	sd	s5,40(sp)
    800015c6:	f05a                	sd	s6,32(sp)
    800015c8:	ec5e                	sd	s7,24(sp)
    800015ca:	e862                	sd	s8,16(sp)
    800015cc:	e466                	sd	s9,8(sp)
    800015ce:	1080                	addi	s0,sp,96
    800015d0:	8c2a                	mv	s8,a0
    800015d2:	84ae                	mv	s1,a1
    800015d4:	8ab2                	mv	s5,a2
    800015d6:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    800015d8:	7cfd                	lui	s9,0xfffff
    if(va0 >= MAXVA)
    800015da:	5bfd                	li	s7,-1
    800015dc:	01abdb93          	srli	s7,s7,0x1a
    pte = walk(pagetable, va0, 0);
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
       (*pte & PTE_W) == 0)
      return -1;
    pa0 = PTE2PA(*pte);
    n = PGSIZE - (dstva - va0);
    800015e0:	6b05                	lui	s6,0x1
    800015e2:	a089                	j	80001624 <copyout+0x70>
      return -1;
    800015e4:	557d                	li	a0,-1
    len -= n;
    src += n;
    dstva = va0 + PGSIZE;
  }
  return 0;
}
    800015e6:	60e6                	ld	ra,88(sp)
    800015e8:	6446                	ld	s0,80(sp)
    800015ea:	64a6                	ld	s1,72(sp)
    800015ec:	6906                	ld	s2,64(sp)
    800015ee:	79e2                	ld	s3,56(sp)
    800015f0:	7a42                	ld	s4,48(sp)
    800015f2:	7aa2                	ld	s5,40(sp)
    800015f4:	7b02                	ld	s6,32(sp)
    800015f6:	6be2                	ld	s7,24(sp)
    800015f8:	6c42                	ld	s8,16(sp)
    800015fa:	6ca2                	ld	s9,8(sp)
    800015fc:	6125                	addi	sp,sp,96
    800015fe:	8082                	ret
    pa0 = PTE2PA(*pte);
    80001600:	83a9                	srli	a5,a5,0xa
    80001602:	07b2                	slli	a5,a5,0xc
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001604:	03449513          	slli	a0,s1,0x34
    80001608:	9151                	srli	a0,a0,0x34
    8000160a:	0009061b          	sext.w	a2,s2
    8000160e:	85d6                	mv	a1,s5
    80001610:	953e                	add	a0,a0,a5
    80001612:	f7aff0ef          	jal	80000d8c <memmove>
    len -= n;
    80001616:	412a0a33          	sub	s4,s4,s2
    src += n;
    8000161a:	9aca                	add	s5,s5,s2
    dstva = va0 + PGSIZE;
    8000161c:	016984b3          	add	s1,s3,s6
  while(len > 0){
    80001620:	020a0d63          	beqz	s4,8000165a <copyout+0xa6>
    va0 = PGROUNDDOWN(dstva);
    80001624:	0194f9b3          	and	s3,s1,s9
    if(va0 >= MAXVA)
    80001628:	fb3beee3          	bltu	s7,s3,800015e4 <copyout+0x30>
    pte = walk(pagetable, va0, 0);
    8000162c:	4601                	li	a2,0
    8000162e:	85ce                	mv	a1,s3
    80001630:	8562                	mv	a0,s8
    80001632:	987ff0ef          	jal	80000fb8 <walk>
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80001636:	d55d                	beqz	a0,800015e4 <copyout+0x30>
    80001638:	611c                	ld	a5,0(a0)
    8000163a:	0017f713          	andi	a4,a5,1
    8000163e:	d35d                	beqz	a4,800015e4 <copyout+0x30>
    80001640:	0107f713          	andi	a4,a5,16
    80001644:	d345                	beqz	a4,800015e4 <copyout+0x30>
       (*pte & PTE_W) == 0)
    80001646:	0047f713          	andi	a4,a5,4
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    8000164a:	df49                	beqz	a4,800015e4 <copyout+0x30>
    n = PGSIZE - (dstva - va0);
    8000164c:	40998933          	sub	s2,s3,s1
    80001650:	995a                	add	s2,s2,s6
    if(n > len)
    80001652:	fb2a77e3          	bgeu	s4,s2,80001600 <copyout+0x4c>
    80001656:	8952                	mv	s2,s4
    80001658:	b765                	j	80001600 <copyout+0x4c>
  return 0;
    8000165a:	4501                	li	a0,0
    8000165c:	b769                	j	800015e6 <copyout+0x32>
    8000165e:	4501                	li	a0,0
}
    80001660:	8082                	ret

0000000080001662 <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    80001662:	c2c9                	beqz	a3,800016e4 <copyin+0x82>
{
    80001664:	715d                	addi	sp,sp,-80
    80001666:	e486                	sd	ra,72(sp)
    80001668:	e0a2                	sd	s0,64(sp)
    8000166a:	fc26                	sd	s1,56(sp)
    8000166c:	f84a                	sd	s2,48(sp)
    8000166e:	f44e                	sd	s3,40(sp)
    80001670:	f052                	sd	s4,32(sp)
    80001672:	ec56                	sd	s5,24(sp)
    80001674:	e85a                	sd	s6,16(sp)
    80001676:	e45e                	sd	s7,8(sp)
    80001678:	e062                	sd	s8,0(sp)
    8000167a:	0880                	addi	s0,sp,80
    8000167c:	8baa                	mv	s7,a0
    8000167e:	8aae                	mv	s5,a1
    80001680:	84b2                	mv	s1,a2
    80001682:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80001684:	7c7d                	lui	s8,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80001686:	6b05                	lui	s6,0x1
    80001688:	a00d                	j	800016aa <copyin+0x48>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    8000168a:	03449593          	slli	a1,s1,0x34
    8000168e:	91d1                	srli	a1,a1,0x34
    80001690:	0009061b          	sext.w	a2,s2
    80001694:	95aa                	add	a1,a1,a0
    80001696:	8556                	mv	a0,s5
    80001698:	ef4ff0ef          	jal	80000d8c <memmove>

    len -= n;
    8000169c:	412989b3          	sub	s3,s3,s2
    dst += n;
    800016a0:	9aca                	add	s5,s5,s2
    srcva = va0 + PGSIZE;
    800016a2:	016a04b3          	add	s1,s4,s6
  while(len > 0){
    800016a6:	02098063          	beqz	s3,800016c6 <copyin+0x64>
    va0 = PGROUNDDOWN(srcva);
    800016aa:	0184fa33          	and	s4,s1,s8
    pa0 = walkaddr(pagetable, va0);
    800016ae:	85d2                	mv	a1,s4
    800016b0:	855e                	mv	a0,s7
    800016b2:	99fff0ef          	jal	80001050 <walkaddr>
    if(pa0 == 0)
    800016b6:	c50d                	beqz	a0,800016e0 <copyin+0x7e>
    n = PGSIZE - (srcva - va0);
    800016b8:	409a0933          	sub	s2,s4,s1
    800016bc:	995a                	add	s2,s2,s6
    if(n > len)
    800016be:	fd29f6e3          	bgeu	s3,s2,8000168a <copyin+0x28>
    800016c2:	894e                	mv	s2,s3
    800016c4:	b7d9                	j	8000168a <copyin+0x28>
  }
  return 0;
    800016c6:	4501                	li	a0,0
}
    800016c8:	60a6                	ld	ra,72(sp)
    800016ca:	6406                	ld	s0,64(sp)
    800016cc:	74e2                	ld	s1,56(sp)
    800016ce:	7942                	ld	s2,48(sp)
    800016d0:	79a2                	ld	s3,40(sp)
    800016d2:	7a02                	ld	s4,32(sp)
    800016d4:	6ae2                	ld	s5,24(sp)
    800016d6:	6b42                	ld	s6,16(sp)
    800016d8:	6ba2                	ld	s7,8(sp)
    800016da:	6c02                	ld	s8,0(sp)
    800016dc:	6161                	addi	sp,sp,80
    800016de:	8082                	ret
      return -1;
    800016e0:	557d                	li	a0,-1
    800016e2:	b7dd                	j	800016c8 <copyin+0x66>
  return 0;
    800016e4:	4501                	li	a0,0
}
    800016e6:	8082                	ret

00000000800016e8 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    800016e8:	cac5                	beqz	a3,80001798 <copyinstr+0xb0>
{
    800016ea:	715d                	addi	sp,sp,-80
    800016ec:	e486                	sd	ra,72(sp)
    800016ee:	e0a2                	sd	s0,64(sp)
    800016f0:	fc26                	sd	s1,56(sp)
    800016f2:	f84a                	sd	s2,48(sp)
    800016f4:	f44e                	sd	s3,40(sp)
    800016f6:	f052                	sd	s4,32(sp)
    800016f8:	ec56                	sd	s5,24(sp)
    800016fa:	e85a                	sd	s6,16(sp)
    800016fc:	e45e                	sd	s7,8(sp)
    800016fe:	0880                	addi	s0,sp,80
    80001700:	8aaa                	mv	s5,a0
    80001702:	84ae                	mv	s1,a1
    80001704:	8bb2                	mv	s7,a2
    80001706:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80001708:	7b7d                	lui	s6,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    8000170a:	6a05                	lui	s4,0x1
    8000170c:	a82d                	j	80001746 <copyinstr+0x5e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    8000170e:	00078023          	sb	zero,0(a5)
        got_null = 1;
    80001712:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80001714:	0017c793          	xori	a5,a5,1
    80001718:	40f0053b          	negw	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    8000171c:	60a6                	ld	ra,72(sp)
    8000171e:	6406                	ld	s0,64(sp)
    80001720:	74e2                	ld	s1,56(sp)
    80001722:	7942                	ld	s2,48(sp)
    80001724:	79a2                	ld	s3,40(sp)
    80001726:	7a02                	ld	s4,32(sp)
    80001728:	6ae2                	ld	s5,24(sp)
    8000172a:	6b42                	ld	s6,16(sp)
    8000172c:	6ba2                	ld	s7,8(sp)
    8000172e:	6161                	addi	sp,sp,80
    80001730:	8082                	ret
    80001732:	fff98713          	addi	a4,s3,-1 # fff <_entry-0x7ffff001>
    80001736:	9726                	add	a4,a4,s1
      --max;
    80001738:	40b709b3          	sub	s3,a4,a1
    srcva = va0 + PGSIZE;
    8000173c:	01490bb3          	add	s7,s2,s4
  while(got_null == 0 && max > 0){
    80001740:	04e58463          	beq	a1,a4,80001788 <copyinstr+0xa0>
{
    80001744:	84be                	mv	s1,a5
    va0 = PGROUNDDOWN(srcva);
    80001746:	016bf933          	and	s2,s7,s6
    pa0 = walkaddr(pagetable, va0);
    8000174a:	85ca                	mv	a1,s2
    8000174c:	8556                	mv	a0,s5
    8000174e:	903ff0ef          	jal	80001050 <walkaddr>
    if(pa0 == 0)
    80001752:	cd0d                	beqz	a0,8000178c <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    80001754:	41790633          	sub	a2,s2,s7
    80001758:	9652                	add	a2,a2,s4
    if(n > max)
    8000175a:	00c9f363          	bgeu	s3,a2,80001760 <copyinstr+0x78>
    8000175e:	864e                	mv	a2,s3
    while(n > 0){
    80001760:	ca05                	beqz	a2,80001790 <copyinstr+0xa8>
    char *p = (char *) (pa0 + (srcva - va0));
    80001762:	034b9693          	slli	a3,s7,0x34
    80001766:	92d1                	srli	a3,a3,0x34
    80001768:	96aa                	add	a3,a3,a0
    8000176a:	87a6                	mv	a5,s1
      if(*p == '\0'){
    8000176c:	8e85                	sub	a3,a3,s1
    while(n > 0){
    8000176e:	9626                	add	a2,a2,s1
    80001770:	85be                	mv	a1,a5
      if(*p == '\0'){
    80001772:	00f68733          	add	a4,a3,a5
    80001776:	00074703          	lbu	a4,0(a4)
    8000177a:	db51                	beqz	a4,8000170e <copyinstr+0x26>
        *dst = *p;
    8000177c:	00e78023          	sb	a4,0(a5)
      dst++;
    80001780:	0785                	addi	a5,a5,1
    while(n > 0){
    80001782:	fec797e3          	bne	a5,a2,80001770 <copyinstr+0x88>
    80001786:	b775                	j	80001732 <copyinstr+0x4a>
    srcva = va0 + PGSIZE;
    80001788:	4781                	li	a5,0
    8000178a:	b769                	j	80001714 <copyinstr+0x2c>
      return -1;
    8000178c:	557d                	li	a0,-1
    8000178e:	b779                	j	8000171c <copyinstr+0x34>
    srcva = va0 + PGSIZE;
    80001790:	6b85                	lui	s7,0x1
    80001792:	9bca                	add	s7,s7,s2
    80001794:	87a6                	mv	a5,s1
    80001796:	b77d                	j	80001744 <copyinstr+0x5c>
    80001798:	4781                	li	a5,0
  if(got_null){
    8000179a:	0017c793          	xori	a5,a5,1
    8000179e:	40f0053b          	negw	a0,a5
}
    800017a2:	8082                	ret

00000000800017a4 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    800017a4:	715d                	addi	sp,sp,-80
    800017a6:	e486                	sd	ra,72(sp)
    800017a8:	e0a2                	sd	s0,64(sp)
    800017aa:	fc26                	sd	s1,56(sp)
    800017ac:	f84a                	sd	s2,48(sp)
    800017ae:	f44e                	sd	s3,40(sp)
    800017b0:	f052                	sd	s4,32(sp)
    800017b2:	ec56                	sd	s5,24(sp)
    800017b4:	e85a                	sd	s6,16(sp)
    800017b6:	e45e                	sd	s7,8(sp)
    800017b8:	0880                	addi	s0,sp,80
    800017ba:	8aaa                	mv	s5,a0
    800017bc:	4481                	li	s1,0
  
  for(p = proc; p < &proc[NPROC]; p++) {
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    800017be:	000a57b7          	lui	a5,0xa5
    800017c2:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    800017c6:	07b2                	slli	a5,a5,0xc
    800017c8:	fa578793          	addi	a5,a5,-91
    800017cc:	4fa50937          	lui	s2,0x4fa50
    800017d0:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    800017d4:	1902                	slli	s2,s2,0x20
    800017d6:	993e                	add	s2,s2,a5
    800017d8:	040009b7          	lui	s3,0x4000
    800017dc:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800017de:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017e0:	4b99                	li	s7,6
    800017e2:	6b05                	lui	s6,0x1
  for(p = proc; p < &proc[NPROC]; p++) {
    800017e4:	6a19                	lui	s4,0x6
    800017e6:	a00a0a13          	addi	s4,s4,-1536 # 5a00 <_entry-0x7fffa600>
    char *pa = kalloc();
    800017ea:	b96ff0ef          	jal	80000b80 <kalloc>
    800017ee:	862a                	mv	a2,a0
    if(pa == 0)
    800017f0:	cd15                	beqz	a0,8000182c <proc_mapstacks+0x88>
    uint64 va = KSTACK((int) (p - proc));
    800017f2:	4034d593          	srai	a1,s1,0x3
    800017f6:	032585b3          	mul	a1,a1,s2
    800017fa:	05b6                	slli	a1,a1,0xd
    800017fc:	6789                	lui	a5,0x2
    800017fe:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80001800:	875e                	mv	a4,s7
    80001802:	86da                	mv	a3,s6
    80001804:	40b985b3          	sub	a1,s3,a1
    80001808:	8556                	mv	a0,s5
    8000180a:	931ff0ef          	jal	8000113a <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000180e:	16848493          	addi	s1,s1,360
    80001812:	fd449ce3          	bne	s1,s4,800017ea <proc_mapstacks+0x46>
  }
}
    80001816:	60a6                	ld	ra,72(sp)
    80001818:	6406                	ld	s0,64(sp)
    8000181a:	74e2                	ld	s1,56(sp)
    8000181c:	7942                	ld	s2,48(sp)
    8000181e:	79a2                	ld	s3,40(sp)
    80001820:	7a02                	ld	s4,32(sp)
    80001822:	6ae2                	ld	s5,24(sp)
    80001824:	6b42                	ld	s6,16(sp)
    80001826:	6ba2                	ld	s7,8(sp)
    80001828:	6161                	addi	sp,sp,80
    8000182a:	8082                	ret
      panic("kalloc");
    8000182c:	00006517          	auipc	a0,0x6
    80001830:	9cc50513          	addi	a0,a0,-1588 # 800071f8 <etext+0x1f8>
    80001834:	fbdfe0ef          	jal	800007f0 <panic>

0000000080001838 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80001838:	7139                	addi	sp,sp,-64
    8000183a:	fc06                	sd	ra,56(sp)
    8000183c:	f822                	sd	s0,48(sp)
    8000183e:	f426                	sd	s1,40(sp)
    80001840:	f04a                	sd	s2,32(sp)
    80001842:	ec4e                	sd	s3,24(sp)
    80001844:	e852                	sd	s4,16(sp)
    80001846:	e456                	sd	s5,8(sp)
    80001848:	e05a                	sd	s6,0(sp)
    8000184a:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    8000184c:	00006597          	auipc	a1,0x6
    80001850:	9b458593          	addi	a1,a1,-1612 # 80007200 <etext+0x200>
    80001854:	0000e517          	auipc	a0,0xe
    80001858:	1dc50513          	addi	a0,a0,476 # 8000fa30 <pid_lock>
    8000185c:	b7eff0ef          	jal	80000bda <initlock>
  initlock(&wait_lock, "wait_lock");
    80001860:	00006597          	auipc	a1,0x6
    80001864:	9a858593          	addi	a1,a1,-1624 # 80007208 <etext+0x208>
    80001868:	0000e517          	auipc	a0,0xe
    8000186c:	1e050513          	addi	a0,a0,480 # 8000fa48 <wait_lock>
    80001870:	b6aff0ef          	jal	80000bda <initlock>
    80001874:	4901                	li	s2,0
  for(p = proc; p < &proc[NPROC]; p++) {
    80001876:	0000e497          	auipc	s1,0xe
    8000187a:	5ea48493          	addi	s1,s1,1514 # 8000fe60 <proc>
      initlock(&p->lock, "proc");
    8000187e:	00006a97          	auipc	s5,0x6
    80001882:	99aa8a93          	addi	s5,s5,-1638 # 80007218 <etext+0x218>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80001886:	000a57b7          	lui	a5,0xa5
    8000188a:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    8000188e:	07b2                	slli	a5,a5,0xc
    80001890:	fa578793          	addi	a5,a5,-91
    80001894:	4fa509b7          	lui	s3,0x4fa50
    80001898:	a4f98993          	addi	s3,s3,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    8000189c:	1982                	slli	s3,s3,0x20
    8000189e:	99be                	add	s3,s3,a5
    800018a0:	04000a37          	lui	s4,0x4000
    800018a4:	1a7d                	addi	s4,s4,-1 # 3ffffff <_entry-0x7c000001>
    800018a6:	0a32                	slli	s4,s4,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    800018a8:	00014b17          	auipc	s6,0x14
    800018ac:	fb8b0b13          	addi	s6,s6,-72 # 80015860 <tickslock>
      initlock(&p->lock, "proc");
    800018b0:	85d6                	mv	a1,s5
    800018b2:	8526                	mv	a0,s1
    800018b4:	b26ff0ef          	jal	80000bda <initlock>
      p->state = UNUSED;
    800018b8:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    800018bc:	40395793          	srai	a5,s2,0x3
    800018c0:	033787b3          	mul	a5,a5,s3
    800018c4:	07b6                	slli	a5,a5,0xd
    800018c6:	6709                	lui	a4,0x2
    800018c8:	9fb9                	addw	a5,a5,a4
    800018ca:	40fa07b3          	sub	a5,s4,a5
    800018ce:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    800018d0:	16848493          	addi	s1,s1,360
    800018d4:	16890913          	addi	s2,s2,360
    800018d8:	fd649ce3          	bne	s1,s6,800018b0 <procinit+0x78>
  }
}
    800018dc:	70e2                	ld	ra,56(sp)
    800018de:	7442                	ld	s0,48(sp)
    800018e0:	74a2                	ld	s1,40(sp)
    800018e2:	7902                	ld	s2,32(sp)
    800018e4:	69e2                	ld	s3,24(sp)
    800018e6:	6a42                	ld	s4,16(sp)
    800018e8:	6aa2                	ld	s5,8(sp)
    800018ea:	6b02                	ld	s6,0(sp)
    800018ec:	6121                	addi	sp,sp,64
    800018ee:	8082                	ret

00000000800018f0 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    800018f0:	1141                	addi	sp,sp,-16
    800018f2:	e406                	sd	ra,8(sp)
    800018f4:	e022                	sd	s0,0(sp)
    800018f6:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    800018f8:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    800018fa:	2501                	sext.w	a0,a0
    800018fc:	60a2                	ld	ra,8(sp)
    800018fe:	6402                	ld	s0,0(sp)
    80001900:	0141                	addi	sp,sp,16
    80001902:	8082                	ret

0000000080001904 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80001904:	1141                	addi	sp,sp,-16
    80001906:	e406                	sd	ra,8(sp)
    80001908:	e022                	sd	s0,0(sp)
    8000190a:	0800                	addi	s0,sp,16
    8000190c:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    8000190e:	2781                	sext.w	a5,a5
    80001910:	079e                	slli	a5,a5,0x7
  return c;
}
    80001912:	0000e517          	auipc	a0,0xe
    80001916:	14e50513          	addi	a0,a0,334 # 8000fa60 <cpus>
    8000191a:	953e                	add	a0,a0,a5
    8000191c:	60a2                	ld	ra,8(sp)
    8000191e:	6402                	ld	s0,0(sp)
    80001920:	0141                	addi	sp,sp,16
    80001922:	8082                	ret

0000000080001924 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80001924:	1101                	addi	sp,sp,-32
    80001926:	ec06                	sd	ra,24(sp)
    80001928:	e822                	sd	s0,16(sp)
    8000192a:	e426                	sd	s1,8(sp)
    8000192c:	1000                	addi	s0,sp,32
  push_off();
    8000192e:	af2ff0ef          	jal	80000c20 <push_off>
    80001932:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001934:	2781                	sext.w	a5,a5
    80001936:	079e                	slli	a5,a5,0x7
    80001938:	0000e717          	auipc	a4,0xe
    8000193c:	0f870713          	addi	a4,a4,248 # 8000fa30 <pid_lock>
    80001940:	97ba                	add	a5,a5,a4
    80001942:	7b9c                	ld	a5,48(a5)
    80001944:	84be                	mv	s1,a5
  pop_off();
    80001946:	b5eff0ef          	jal	80000ca4 <pop_off>
  return p;
}
    8000194a:	8526                	mv	a0,s1
    8000194c:	60e2                	ld	ra,24(sp)
    8000194e:	6442                	ld	s0,16(sp)
    80001950:	64a2                	ld	s1,8(sp)
    80001952:	6105                	addi	sp,sp,32
    80001954:	8082                	ret

0000000080001956 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001956:	1141                	addi	sp,sp,-16
    80001958:	e406                	sd	ra,8(sp)
    8000195a:	e022                	sd	s0,0(sp)
    8000195c:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    8000195e:	fc7ff0ef          	jal	80001924 <myproc>
    80001962:	b92ff0ef          	jal	80000cf4 <release>

  if (first) {
    80001966:	00006797          	auipc	a5,0x6
    8000196a:	f1a7a783          	lw	a5,-230(a5) # 80007880 <first.1>
    8000196e:	e799                	bnez	a5,8000197c <forkret+0x26>
    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();
  }

  usertrapret();
    80001970:	2a7000ef          	jal	80002416 <usertrapret>
}
    80001974:	60a2                	ld	ra,8(sp)
    80001976:	6402                	ld	s0,0(sp)
    80001978:	0141                	addi	sp,sp,16
    8000197a:	8082                	ret
    fsinit(ROOTDEV);
    8000197c:	4505                	li	a0,1
    8000197e:	60a010ef          	jal	80002f88 <fsinit>
    first = 0;
    80001982:	00006797          	auipc	a5,0x6
    80001986:	ee07af23          	sw	zero,-258(a5) # 80007880 <first.1>
    __sync_synchronize();
    8000198a:	0330000f          	fence	rw,rw
    8000198e:	b7cd                	j	80001970 <forkret+0x1a>

0000000080001990 <allocpid>:
{
    80001990:	1101                	addi	sp,sp,-32
    80001992:	ec06                	sd	ra,24(sp)
    80001994:	e822                	sd	s0,16(sp)
    80001996:	e426                	sd	s1,8(sp)
    80001998:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    8000199a:	0000e517          	auipc	a0,0xe
    8000199e:	09650513          	addi	a0,a0,150 # 8000fa30 <pid_lock>
    800019a2:	ac2ff0ef          	jal	80000c64 <acquire>
  pid = nextpid;
    800019a6:	00006797          	auipc	a5,0x6
    800019aa:	ede78793          	addi	a5,a5,-290 # 80007884 <nextpid>
    800019ae:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    800019b0:	0014871b          	addiw	a4,s1,1
    800019b4:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    800019b6:	0000e517          	auipc	a0,0xe
    800019ba:	07a50513          	addi	a0,a0,122 # 8000fa30 <pid_lock>
    800019be:	b36ff0ef          	jal	80000cf4 <release>
}
    800019c2:	8526                	mv	a0,s1
    800019c4:	60e2                	ld	ra,24(sp)
    800019c6:	6442                	ld	s0,16(sp)
    800019c8:	64a2                	ld	s1,8(sp)
    800019ca:	6105                	addi	sp,sp,32
    800019cc:	8082                	ret

00000000800019ce <proc_pagetable>:
{
    800019ce:	1101                	addi	sp,sp,-32
    800019d0:	ec06                	sd	ra,24(sp)
    800019d2:	e822                	sd	s0,16(sp)
    800019d4:	e426                	sd	s1,8(sp)
    800019d6:	e04a                	sd	s2,0(sp)
    800019d8:	1000                	addi	s0,sp,32
    800019da:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    800019dc:	909ff0ef          	jal	800012e4 <uvmcreate>
    800019e0:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800019e2:	cd05                	beqz	a0,80001a1a <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    800019e4:	4729                	li	a4,10
    800019e6:	00004697          	auipc	a3,0x4
    800019ea:	61a68693          	addi	a3,a3,1562 # 80006000 <_trampoline>
    800019ee:	6605                	lui	a2,0x1
    800019f0:	040005b7          	lui	a1,0x4000
    800019f4:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800019f6:	05b2                	slli	a1,a1,0xc
    800019f8:	e90ff0ef          	jal	80001088 <mappages>
    800019fc:	02054663          	bltz	a0,80001a28 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001a00:	4719                	li	a4,6
    80001a02:	05893683          	ld	a3,88(s2)
    80001a06:	6605                	lui	a2,0x1
    80001a08:	020005b7          	lui	a1,0x2000
    80001a0c:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a0e:	05b6                	slli	a1,a1,0xd
    80001a10:	8526                	mv	a0,s1
    80001a12:	e76ff0ef          	jal	80001088 <mappages>
    80001a16:	00054f63          	bltz	a0,80001a34 <proc_pagetable+0x66>
}
    80001a1a:	8526                	mv	a0,s1
    80001a1c:	60e2                	ld	ra,24(sp)
    80001a1e:	6442                	ld	s0,16(sp)
    80001a20:	64a2                	ld	s1,8(sp)
    80001a22:	6902                	ld	s2,0(sp)
    80001a24:	6105                	addi	sp,sp,32
    80001a26:	8082                	ret
    uvmfree(pagetable, 0);
    80001a28:	4581                	li	a1,0
    80001a2a:	8526                	mv	a0,s1
    80001a2c:	a7fff0ef          	jal	800014aa <uvmfree>
    return 0;
    80001a30:	4481                	li	s1,0
    80001a32:	b7e5                	j	80001a1a <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a34:	4681                	li	a3,0
    80001a36:	4605                	li	a2,1
    80001a38:	040005b7          	lui	a1,0x4000
    80001a3c:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a3e:	05b2                	slli	a1,a1,0xc
    80001a40:	8526                	mv	a0,s1
    80001a42:	fe6ff0ef          	jal	80001228 <uvmunmap>
    uvmfree(pagetable, 0);
    80001a46:	4581                	li	a1,0
    80001a48:	8526                	mv	a0,s1
    80001a4a:	a61ff0ef          	jal	800014aa <uvmfree>
    return 0;
    80001a4e:	b7cd                	j	80001a30 <proc_pagetable+0x62>

0000000080001a50 <proc_freepagetable>:
{
    80001a50:	1101                	addi	sp,sp,-32
    80001a52:	ec06                	sd	ra,24(sp)
    80001a54:	e822                	sd	s0,16(sp)
    80001a56:	e426                	sd	s1,8(sp)
    80001a58:	e04a                	sd	s2,0(sp)
    80001a5a:	1000                	addi	s0,sp,32
    80001a5c:	84aa                	mv	s1,a0
    80001a5e:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a60:	4681                	li	a3,0
    80001a62:	4605                	li	a2,1
    80001a64:	040005b7          	lui	a1,0x4000
    80001a68:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a6a:	05b2                	slli	a1,a1,0xc
    80001a6c:	fbcff0ef          	jal	80001228 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001a70:	4681                	li	a3,0
    80001a72:	4605                	li	a2,1
    80001a74:	020005b7          	lui	a1,0x2000
    80001a78:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a7a:	05b6                	slli	a1,a1,0xd
    80001a7c:	8526                	mv	a0,s1
    80001a7e:	faaff0ef          	jal	80001228 <uvmunmap>
  uvmfree(pagetable, sz);
    80001a82:	85ca                	mv	a1,s2
    80001a84:	8526                	mv	a0,s1
    80001a86:	a25ff0ef          	jal	800014aa <uvmfree>
}
    80001a8a:	60e2                	ld	ra,24(sp)
    80001a8c:	6442                	ld	s0,16(sp)
    80001a8e:	64a2                	ld	s1,8(sp)
    80001a90:	6902                	ld	s2,0(sp)
    80001a92:	6105                	addi	sp,sp,32
    80001a94:	8082                	ret

0000000080001a96 <freeproc>:
{
    80001a96:	1101                	addi	sp,sp,-32
    80001a98:	ec06                	sd	ra,24(sp)
    80001a9a:	e822                	sd	s0,16(sp)
    80001a9c:	e426                	sd	s1,8(sp)
    80001a9e:	1000                	addi	s0,sp,32
    80001aa0:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001aa2:	6d28                	ld	a0,88(a0)
    80001aa4:	c119                	beqz	a0,80001aaa <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001aa6:	ff3fe0ef          	jal	80000a98 <kfree>
  p->trapframe = 0;
    80001aaa:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001aae:	68a8                	ld	a0,80(s1)
    80001ab0:	c501                	beqz	a0,80001ab8 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001ab2:	64ac                	ld	a1,72(s1)
    80001ab4:	f9dff0ef          	jal	80001a50 <proc_freepagetable>
  p->pagetable = 0;
    80001ab8:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001abc:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001ac0:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001ac4:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001ac8:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001acc:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001ad0:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001ad4:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001ad8:	0004ac23          	sw	zero,24(s1)
}
    80001adc:	60e2                	ld	ra,24(sp)
    80001ade:	6442                	ld	s0,16(sp)
    80001ae0:	64a2                	ld	s1,8(sp)
    80001ae2:	6105                	addi	sp,sp,32
    80001ae4:	8082                	ret

0000000080001ae6 <allocproc>:
{
    80001ae6:	1101                	addi	sp,sp,-32
    80001ae8:	ec06                	sd	ra,24(sp)
    80001aea:	e822                	sd	s0,16(sp)
    80001aec:	e426                	sd	s1,8(sp)
    80001aee:	e04a                	sd	s2,0(sp)
    80001af0:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001af2:	0000e497          	auipc	s1,0xe
    80001af6:	36e48493          	addi	s1,s1,878 # 8000fe60 <proc>
    80001afa:	00014917          	auipc	s2,0x14
    80001afe:	d6690913          	addi	s2,s2,-666 # 80015860 <tickslock>
    acquire(&p->lock);
    80001b02:	8526                	mv	a0,s1
    80001b04:	960ff0ef          	jal	80000c64 <acquire>
    if(p->state == UNUSED) {
    80001b08:	4c9c                	lw	a5,24(s1)
    80001b0a:	cb91                	beqz	a5,80001b1e <allocproc+0x38>
      release(&p->lock);
    80001b0c:	8526                	mv	a0,s1
    80001b0e:	9e6ff0ef          	jal	80000cf4 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b12:	16848493          	addi	s1,s1,360
    80001b16:	ff2496e3          	bne	s1,s2,80001b02 <allocproc+0x1c>
  return 0;
    80001b1a:	4481                	li	s1,0
    80001b1c:	a089                	j	80001b5e <allocproc+0x78>
  p->pid = allocpid();
    80001b1e:	e73ff0ef          	jal	80001990 <allocpid>
    80001b22:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001b24:	4785                	li	a5,1
    80001b26:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001b28:	858ff0ef          	jal	80000b80 <kalloc>
    80001b2c:	892a                	mv	s2,a0
    80001b2e:	eca8                	sd	a0,88(s1)
    80001b30:	cd15                	beqz	a0,80001b6c <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    80001b32:	8526                	mv	a0,s1
    80001b34:	e9bff0ef          	jal	800019ce <proc_pagetable>
    80001b38:	892a                	mv	s2,a0
    80001b3a:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001b3c:	c121                	beqz	a0,80001b7c <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80001b3e:	07000613          	li	a2,112
    80001b42:	4581                	li	a1,0
    80001b44:	06048513          	addi	a0,s1,96
    80001b48:	9e8ff0ef          	jal	80000d30 <memset>
  p->context.ra = (uint64)forkret;
    80001b4c:	00000797          	auipc	a5,0x0
    80001b50:	e0a78793          	addi	a5,a5,-502 # 80001956 <forkret>
    80001b54:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001b56:	60bc                	ld	a5,64(s1)
    80001b58:	6705                	lui	a4,0x1
    80001b5a:	97ba                	add	a5,a5,a4
    80001b5c:	f4bc                	sd	a5,104(s1)
}
    80001b5e:	8526                	mv	a0,s1
    80001b60:	60e2                	ld	ra,24(sp)
    80001b62:	6442                	ld	s0,16(sp)
    80001b64:	64a2                	ld	s1,8(sp)
    80001b66:	6902                	ld	s2,0(sp)
    80001b68:	6105                	addi	sp,sp,32
    80001b6a:	8082                	ret
    freeproc(p);
    80001b6c:	8526                	mv	a0,s1
    80001b6e:	f29ff0ef          	jal	80001a96 <freeproc>
    release(&p->lock);
    80001b72:	8526                	mv	a0,s1
    80001b74:	980ff0ef          	jal	80000cf4 <release>
    return 0;
    80001b78:	84ca                	mv	s1,s2
    80001b7a:	b7d5                	j	80001b5e <allocproc+0x78>
    freeproc(p);
    80001b7c:	8526                	mv	a0,s1
    80001b7e:	f19ff0ef          	jal	80001a96 <freeproc>
    release(&p->lock);
    80001b82:	8526                	mv	a0,s1
    80001b84:	970ff0ef          	jal	80000cf4 <release>
    return 0;
    80001b88:	84ca                	mv	s1,s2
    80001b8a:	bfd1                	j	80001b5e <allocproc+0x78>

0000000080001b8c <userinit>:
{
    80001b8c:	1101                	addi	sp,sp,-32
    80001b8e:	ec06                	sd	ra,24(sp)
    80001b90:	e822                	sd	s0,16(sp)
    80001b92:	e426                	sd	s1,8(sp)
    80001b94:	1000                	addi	s0,sp,32
  p = allocproc();
    80001b96:	f51ff0ef          	jal	80001ae6 <allocproc>
    80001b9a:	84aa                	mv	s1,a0
  initproc = p;
    80001b9c:	00006797          	auipc	a5,0x6
    80001ba0:	d4a7be23          	sd	a0,-676(a5) # 800078f8 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80001ba4:	03400613          	li	a2,52
    80001ba8:	00006597          	auipc	a1,0x6
    80001bac:	ce858593          	addi	a1,a1,-792 # 80007890 <initcode>
    80001bb0:	6928                	ld	a0,80(a0)
    80001bb2:	f58ff0ef          	jal	8000130a <uvmfirst>
  p->sz = PGSIZE;
    80001bb6:	6785                	lui	a5,0x1
    80001bb8:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    80001bba:	6cb8                	ld	a4,88(s1)
    80001bbc:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    80001bc0:	6cb8                	ld	a4,88(s1)
    80001bc2:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    80001bc4:	4641                	li	a2,16
    80001bc6:	00005597          	auipc	a1,0x5
    80001bca:	65a58593          	addi	a1,a1,1626 # 80007220 <etext+0x220>
    80001bce:	15848513          	addi	a0,s1,344
    80001bd2:	aa8ff0ef          	jal	80000e7a <safestrcpy>
  p->cwd = namei("/");
    80001bd6:	00005517          	auipc	a0,0x5
    80001bda:	65a50513          	addi	a0,a0,1626 # 80007230 <etext+0x230>
    80001bde:	4dd010ef          	jal	800038ba <namei>
    80001be2:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001be6:	478d                	li	a5,3
    80001be8:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001bea:	8526                	mv	a0,s1
    80001bec:	908ff0ef          	jal	80000cf4 <release>
}
    80001bf0:	60e2                	ld	ra,24(sp)
    80001bf2:	6442                	ld	s0,16(sp)
    80001bf4:	64a2                	ld	s1,8(sp)
    80001bf6:	6105                	addi	sp,sp,32
    80001bf8:	8082                	ret

0000000080001bfa <growproc>:
{
    80001bfa:	1101                	addi	sp,sp,-32
    80001bfc:	ec06                	sd	ra,24(sp)
    80001bfe:	e822                	sd	s0,16(sp)
    80001c00:	e426                	sd	s1,8(sp)
    80001c02:	e04a                	sd	s2,0(sp)
    80001c04:	1000                	addi	s0,sp,32
    80001c06:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001c08:	d1dff0ef          	jal	80001924 <myproc>
    80001c0c:	84aa                	mv	s1,a0
  sz = p->sz;
    80001c0e:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001c10:	01204c63          	bgtz	s2,80001c28 <growproc+0x2e>
  } else if(n < 0){
    80001c14:	02094463          	bltz	s2,80001c3c <growproc+0x42>
  p->sz = sz;
    80001c18:	e4ac                	sd	a1,72(s1)
  return 0;
    80001c1a:	4501                	li	a0,0
}
    80001c1c:	60e2                	ld	ra,24(sp)
    80001c1e:	6442                	ld	s0,16(sp)
    80001c20:	64a2                	ld	s1,8(sp)
    80001c22:	6902                	ld	s2,0(sp)
    80001c24:	6105                	addi	sp,sp,32
    80001c26:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001c28:	4691                	li	a3,4
    80001c2a:	00b90633          	add	a2,s2,a1
    80001c2e:	6928                	ld	a0,80(a0)
    80001c30:	f7eff0ef          	jal	800013ae <uvmalloc>
    80001c34:	85aa                	mv	a1,a0
    80001c36:	f16d                	bnez	a0,80001c18 <growproc+0x1e>
      return -1;
    80001c38:	557d                	li	a0,-1
    80001c3a:	b7cd                	j	80001c1c <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001c3c:	00b90633          	add	a2,s2,a1
    80001c40:	6928                	ld	a0,80(a0)
    80001c42:	f26ff0ef          	jal	80001368 <uvmdealloc>
    80001c46:	85aa                	mv	a1,a0
    80001c48:	bfc1                	j	80001c18 <growproc+0x1e>

0000000080001c4a <fork>:
{
    80001c4a:	7139                	addi	sp,sp,-64
    80001c4c:	fc06                	sd	ra,56(sp)
    80001c4e:	f822                	sd	s0,48(sp)
    80001c50:	f426                	sd	s1,40(sp)
    80001c52:	e456                	sd	s5,8(sp)
    80001c54:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c56:	ccfff0ef          	jal	80001924 <myproc>
    80001c5a:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001c5c:	e8bff0ef          	jal	80001ae6 <allocproc>
    80001c60:	c92d                	beqz	a0,80001cd2 <fork+0x88>
    80001c62:	e852                	sd	s4,16(sp)
    80001c64:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001c66:	048ab603          	ld	a2,72(s5)
    80001c6a:	692c                	ld	a1,80(a0)
    80001c6c:	050ab503          	ld	a0,80(s5)
    80001c70:	86dff0ef          	jal	800014dc <uvmcopy>
    80001c74:	04054863          	bltz	a0,80001cc4 <fork+0x7a>
    80001c78:	f04a                	sd	s2,32(sp)
    80001c7a:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001c7c:	048ab783          	ld	a5,72(s5)
    80001c80:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001c84:	058ab683          	ld	a3,88(s5)
    80001c88:	87b6                	mv	a5,a3
    80001c8a:	058a3703          	ld	a4,88(s4)
    80001c8e:	12068693          	addi	a3,a3,288
    80001c92:	6388                	ld	a0,0(a5)
    80001c94:	678c                	ld	a1,8(a5)
    80001c96:	6b90                	ld	a2,16(a5)
    80001c98:	e308                	sd	a0,0(a4)
    80001c9a:	e70c                	sd	a1,8(a4)
    80001c9c:	eb10                	sd	a2,16(a4)
    80001c9e:	6f90                	ld	a2,24(a5)
    80001ca0:	ef10                	sd	a2,24(a4)
    80001ca2:	02078793          	addi	a5,a5,32 # 1020 <_entry-0x7fffefe0>
    80001ca6:	02070713          	addi	a4,a4,32
    80001caa:	fed794e3          	bne	a5,a3,80001c92 <fork+0x48>
  np->trapframe->a0 = 0;
    80001cae:	058a3783          	ld	a5,88(s4)
    80001cb2:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001cb6:	0d0a8493          	addi	s1,s5,208
    80001cba:	0d0a0913          	addi	s2,s4,208
    80001cbe:	150a8993          	addi	s3,s5,336
    80001cc2:	a831                	j	80001cde <fork+0x94>
    freeproc(np);
    80001cc4:	8552                	mv	a0,s4
    80001cc6:	dd1ff0ef          	jal	80001a96 <freeproc>
    release(&np->lock);
    80001cca:	8552                	mv	a0,s4
    80001ccc:	828ff0ef          	jal	80000cf4 <release>
    return -1;
    80001cd0:	6a42                	ld	s4,16(sp)
    return -1;
    80001cd2:	54fd                	li	s1,-1
    80001cd4:	a885                	j	80001d44 <fork+0xfa>
  for(i = 0; i < NOFILE; i++)
    80001cd6:	04a1                	addi	s1,s1,8
    80001cd8:	0921                	addi	s2,s2,8
    80001cda:	01348963          	beq	s1,s3,80001cec <fork+0xa2>
    if(p->ofile[i])
    80001cde:	6088                	ld	a0,0(s1)
    80001ce0:	d97d                	beqz	a0,80001cd6 <fork+0x8c>
      np->ofile[i] = filedup(p->ofile[i]);
    80001ce2:	182020ef          	jal	80003e64 <filedup>
    80001ce6:	00a93023          	sd	a0,0(s2)
    80001cea:	b7f5                	j	80001cd6 <fork+0x8c>
  np->cwd = idup(p->cwd);
    80001cec:	150ab503          	ld	a0,336(s5)
    80001cf0:	494010ef          	jal	80003184 <idup>
    80001cf4:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001cf8:	4641                	li	a2,16
    80001cfa:	158a8593          	addi	a1,s5,344
    80001cfe:	158a0513          	addi	a0,s4,344
    80001d02:	978ff0ef          	jal	80000e7a <safestrcpy>
  pid = np->pid;
    80001d06:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    80001d0a:	8552                	mv	a0,s4
    80001d0c:	fe9fe0ef          	jal	80000cf4 <release>
  acquire(&wait_lock);
    80001d10:	0000e517          	auipc	a0,0xe
    80001d14:	d3850513          	addi	a0,a0,-712 # 8000fa48 <wait_lock>
    80001d18:	f4dfe0ef          	jal	80000c64 <acquire>
  np->parent = p;
    80001d1c:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001d20:	0000e517          	auipc	a0,0xe
    80001d24:	d2850513          	addi	a0,a0,-728 # 8000fa48 <wait_lock>
    80001d28:	fcdfe0ef          	jal	80000cf4 <release>
  acquire(&np->lock);
    80001d2c:	8552                	mv	a0,s4
    80001d2e:	f37fe0ef          	jal	80000c64 <acquire>
  np->state = RUNNABLE;
    80001d32:	478d                	li	a5,3
    80001d34:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001d38:	8552                	mv	a0,s4
    80001d3a:	fbbfe0ef          	jal	80000cf4 <release>
    80001d3e:	7902                	ld	s2,32(sp)
    80001d40:	69e2                	ld	s3,24(sp)
    80001d42:	6a42                	ld	s4,16(sp)
}
    80001d44:	8526                	mv	a0,s1
    80001d46:	70e2                	ld	ra,56(sp)
    80001d48:	7442                	ld	s0,48(sp)
    80001d4a:	74a2                	ld	s1,40(sp)
    80001d4c:	6aa2                	ld	s5,8(sp)
    80001d4e:	6121                	addi	sp,sp,64
    80001d50:	8082                	ret

0000000080001d52 <scheduler>:
{
    80001d52:	715d                	addi	sp,sp,-80
    80001d54:	e486                	sd	ra,72(sp)
    80001d56:	e0a2                	sd	s0,64(sp)
    80001d58:	fc26                	sd	s1,56(sp)
    80001d5a:	f84a                	sd	s2,48(sp)
    80001d5c:	f44e                	sd	s3,40(sp)
    80001d5e:	f052                	sd	s4,32(sp)
    80001d60:	ec56                	sd	s5,24(sp)
    80001d62:	e85a                	sd	s6,16(sp)
    80001d64:	e45e                	sd	s7,8(sp)
    80001d66:	e062                	sd	s8,0(sp)
    80001d68:	0880                	addi	s0,sp,80
    80001d6a:	8792                	mv	a5,tp
  int id = r_tp();
    80001d6c:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001d6e:	00779693          	slli	a3,a5,0x7
    80001d72:	0000e717          	auipc	a4,0xe
    80001d76:	cbe70713          	addi	a4,a4,-834 # 8000fa30 <pid_lock>
    80001d7a:	9736                	add	a4,a4,a3
    80001d7c:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001d80:	0000eb17          	auipc	s6,0xe
    80001d84:	ce8b0b13          	addi	s6,s6,-792 # 8000fa68 <cpus+0x8>
    80001d88:	9b36                	add	s6,s6,a3
        p->state = RUNNING;
    80001d8a:	4c11                	li	s8,4
        c->proc = p;
    80001d8c:	8a3a                	mv	s4,a4
        found = 1;
    80001d8e:	4b85                	li	s7,1
    80001d90:	a83d                	j	80001dce <scheduler+0x7c>
      release(&p->lock);
    80001d92:	8526                	mv	a0,s1
    80001d94:	f61fe0ef          	jal	80000cf4 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001d98:	16848493          	addi	s1,s1,360
    80001d9c:	03248563          	beq	s1,s2,80001dc6 <scheduler+0x74>
      acquire(&p->lock);
    80001da0:	8526                	mv	a0,s1
    80001da2:	ec3fe0ef          	jal	80000c64 <acquire>
      if(p->state == RUNNABLE) {
    80001da6:	4c9c                	lw	a5,24(s1)
    80001da8:	ff3795e3          	bne	a5,s3,80001d92 <scheduler+0x40>
        p->state = RUNNING;
    80001dac:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001db0:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001db4:	06048593          	addi	a1,s1,96
    80001db8:	855a                	mv	a0,s6
    80001dba:	5b2000ef          	jal	8000236c <swtch>
        c->proc = 0;
    80001dbe:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001dc2:	8ade                	mv	s5,s7
    80001dc4:	b7f9                	j	80001d92 <scheduler+0x40>
    if(found == 0) {
    80001dc6:	000a9463          	bnez	s5,80001dce <scheduler+0x7c>
      asm volatile("wfi");
    80001dca:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001dce:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001dd2:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001dd6:	10079073          	csrw	sstatus,a5
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001dda:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001dde:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001de0:	10079073          	csrw	sstatus,a5
    int found = 0;
    80001de4:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001de6:	0000e497          	auipc	s1,0xe
    80001dea:	07a48493          	addi	s1,s1,122 # 8000fe60 <proc>
      if(p->state == RUNNABLE) {
    80001dee:	498d                	li	s3,3
    for(p = proc; p < &proc[NPROC]; p++) {
    80001df0:	00014917          	auipc	s2,0x14
    80001df4:	a7090913          	addi	s2,s2,-1424 # 80015860 <tickslock>
    80001df8:	b765                	j	80001da0 <scheduler+0x4e>

0000000080001dfa <sched>:
{
    80001dfa:	7179                	addi	sp,sp,-48
    80001dfc:	f406                	sd	ra,40(sp)
    80001dfe:	f022                	sd	s0,32(sp)
    80001e00:	ec26                	sd	s1,24(sp)
    80001e02:	e84a                	sd	s2,16(sp)
    80001e04:	e44e                	sd	s3,8(sp)
    80001e06:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001e08:	b1dff0ef          	jal	80001924 <myproc>
    80001e0c:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001e0e:	de7fe0ef          	jal	80000bf4 <holding>
    80001e12:	c92d                	beqz	a0,80001e84 <sched+0x8a>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e14:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001e16:	2781                	sext.w	a5,a5
    80001e18:	079e                	slli	a5,a5,0x7
    80001e1a:	0000e717          	auipc	a4,0xe
    80001e1e:	c1670713          	addi	a4,a4,-1002 # 8000fa30 <pid_lock>
    80001e22:	97ba                	add	a5,a5,a4
    80001e24:	0a87a703          	lw	a4,168(a5)
    80001e28:	4785                	li	a5,1
    80001e2a:	06f71363          	bne	a4,a5,80001e90 <sched+0x96>
  if(p->state == RUNNING)
    80001e2e:	4c98                	lw	a4,24(s1)
    80001e30:	4791                	li	a5,4
    80001e32:	06f70563          	beq	a4,a5,80001e9c <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e36:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001e3a:	8b89                	andi	a5,a5,2
  if(intr_get())
    80001e3c:	e7b5                	bnez	a5,80001ea8 <sched+0xae>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e3e:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001e40:	0000e917          	auipc	s2,0xe
    80001e44:	bf090913          	addi	s2,s2,-1040 # 8000fa30 <pid_lock>
    80001e48:	2781                	sext.w	a5,a5
    80001e4a:	079e                	slli	a5,a5,0x7
    80001e4c:	97ca                	add	a5,a5,s2
    80001e4e:	0ac7a983          	lw	s3,172(a5)
    80001e52:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001e54:	2781                	sext.w	a5,a5
    80001e56:	079e                	slli	a5,a5,0x7
    80001e58:	0000e597          	auipc	a1,0xe
    80001e5c:	c1058593          	addi	a1,a1,-1008 # 8000fa68 <cpus+0x8>
    80001e60:	95be                	add	a1,a1,a5
    80001e62:	06048513          	addi	a0,s1,96
    80001e66:	506000ef          	jal	8000236c <swtch>
    80001e6a:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001e6c:	2781                	sext.w	a5,a5
    80001e6e:	079e                	slli	a5,a5,0x7
    80001e70:	993e                	add	s2,s2,a5
    80001e72:	0b392623          	sw	s3,172(s2)
}
    80001e76:	70a2                	ld	ra,40(sp)
    80001e78:	7402                	ld	s0,32(sp)
    80001e7a:	64e2                	ld	s1,24(sp)
    80001e7c:	6942                	ld	s2,16(sp)
    80001e7e:	69a2                	ld	s3,8(sp)
    80001e80:	6145                	addi	sp,sp,48
    80001e82:	8082                	ret
    panic("sched p->lock");
    80001e84:	00005517          	auipc	a0,0x5
    80001e88:	3b450513          	addi	a0,a0,948 # 80007238 <etext+0x238>
    80001e8c:	965fe0ef          	jal	800007f0 <panic>
    panic("sched locks");
    80001e90:	00005517          	auipc	a0,0x5
    80001e94:	3b850513          	addi	a0,a0,952 # 80007248 <etext+0x248>
    80001e98:	959fe0ef          	jal	800007f0 <panic>
    panic("sched RUNNING");
    80001e9c:	00005517          	auipc	a0,0x5
    80001ea0:	3bc50513          	addi	a0,a0,956 # 80007258 <etext+0x258>
    80001ea4:	94dfe0ef          	jal	800007f0 <panic>
    panic("sched interruptible");
    80001ea8:	00005517          	auipc	a0,0x5
    80001eac:	3c050513          	addi	a0,a0,960 # 80007268 <etext+0x268>
    80001eb0:	941fe0ef          	jal	800007f0 <panic>

0000000080001eb4 <yield>:
{
    80001eb4:	1101                	addi	sp,sp,-32
    80001eb6:	ec06                	sd	ra,24(sp)
    80001eb8:	e822                	sd	s0,16(sp)
    80001eba:	e426                	sd	s1,8(sp)
    80001ebc:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001ebe:	a67ff0ef          	jal	80001924 <myproc>
    80001ec2:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001ec4:	da1fe0ef          	jal	80000c64 <acquire>
  p->state = RUNNABLE;
    80001ec8:	478d                	li	a5,3
    80001eca:	cc9c                	sw	a5,24(s1)
  sched();
    80001ecc:	f2fff0ef          	jal	80001dfa <sched>
  release(&p->lock);
    80001ed0:	8526                	mv	a0,s1
    80001ed2:	e23fe0ef          	jal	80000cf4 <release>
}
    80001ed6:	60e2                	ld	ra,24(sp)
    80001ed8:	6442                	ld	s0,16(sp)
    80001eda:	64a2                	ld	s1,8(sp)
    80001edc:	6105                	addi	sp,sp,32
    80001ede:	8082                	ret

0000000080001ee0 <sleep>:

// Sleep on wait channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001ee0:	7179                	addi	sp,sp,-48
    80001ee2:	f406                	sd	ra,40(sp)
    80001ee4:	f022                	sd	s0,32(sp)
    80001ee6:	ec26                	sd	s1,24(sp)
    80001ee8:	e84a                	sd	s2,16(sp)
    80001eea:	e44e                	sd	s3,8(sp)
    80001eec:	1800                	addi	s0,sp,48
    80001eee:	89aa                	mv	s3,a0
    80001ef0:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001ef2:	a33ff0ef          	jal	80001924 <myproc>
    80001ef6:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80001ef8:	d6dfe0ef          	jal	80000c64 <acquire>
  release(lk);
    80001efc:	854a                	mv	a0,s2
    80001efe:	df7fe0ef          	jal	80000cf4 <release>

  // Go to sleep.
  p->chan = chan;
    80001f02:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80001f06:	4789                	li	a5,2
    80001f08:	cc9c                	sw	a5,24(s1)

  sched();
    80001f0a:	ef1ff0ef          	jal	80001dfa <sched>

  // Tidy up.
  p->chan = 0;
    80001f0e:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80001f12:	8526                	mv	a0,s1
    80001f14:	de1fe0ef          	jal	80000cf4 <release>
  acquire(lk);
    80001f18:	854a                	mv	a0,s2
    80001f1a:	d4bfe0ef          	jal	80000c64 <acquire>
}
    80001f1e:	70a2                	ld	ra,40(sp)
    80001f20:	7402                	ld	s0,32(sp)
    80001f22:	64e2                	ld	s1,24(sp)
    80001f24:	6942                	ld	s2,16(sp)
    80001f26:	69a2                	ld	s3,8(sp)
    80001f28:	6145                	addi	sp,sp,48
    80001f2a:	8082                	ret

0000000080001f2c <wakeup>:

// Wake up all processes sleeping on wait channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    80001f2c:	7139                	addi	sp,sp,-64
    80001f2e:	fc06                	sd	ra,56(sp)
    80001f30:	f822                	sd	s0,48(sp)
    80001f32:	f426                	sd	s1,40(sp)
    80001f34:	f04a                	sd	s2,32(sp)
    80001f36:	ec4e                	sd	s3,24(sp)
    80001f38:	e852                	sd	s4,16(sp)
    80001f3a:	e456                	sd	s5,8(sp)
    80001f3c:	0080                	addi	s0,sp,64
    80001f3e:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80001f40:	0000e497          	auipc	s1,0xe
    80001f44:	f2048493          	addi	s1,s1,-224 # 8000fe60 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80001f48:	4989                	li	s3,2
        p->state = RUNNABLE;
    80001f4a:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    80001f4c:	00014917          	auipc	s2,0x14
    80001f50:	91490913          	addi	s2,s2,-1772 # 80015860 <tickslock>
    80001f54:	a801                	j	80001f64 <wakeup+0x38>
      }
      release(&p->lock);
    80001f56:	8526                	mv	a0,s1
    80001f58:	d9dfe0ef          	jal	80000cf4 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001f5c:	16848493          	addi	s1,s1,360
    80001f60:	03248263          	beq	s1,s2,80001f84 <wakeup+0x58>
    if(p != myproc()){
    80001f64:	9c1ff0ef          	jal	80001924 <myproc>
    80001f68:	fe950ae3          	beq	a0,s1,80001f5c <wakeup+0x30>
      acquire(&p->lock);
    80001f6c:	8526                	mv	a0,s1
    80001f6e:	cf7fe0ef          	jal	80000c64 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80001f72:	4c9c                	lw	a5,24(s1)
    80001f74:	ff3791e3          	bne	a5,s3,80001f56 <wakeup+0x2a>
    80001f78:	709c                	ld	a5,32(s1)
    80001f7a:	fd479ee3          	bne	a5,s4,80001f56 <wakeup+0x2a>
        p->state = RUNNABLE;
    80001f7e:	0154ac23          	sw	s5,24(s1)
    80001f82:	bfd1                	j	80001f56 <wakeup+0x2a>
    }
  }
}
    80001f84:	70e2                	ld	ra,56(sp)
    80001f86:	7442                	ld	s0,48(sp)
    80001f88:	74a2                	ld	s1,40(sp)
    80001f8a:	7902                	ld	s2,32(sp)
    80001f8c:	69e2                	ld	s3,24(sp)
    80001f8e:	6a42                	ld	s4,16(sp)
    80001f90:	6aa2                	ld	s5,8(sp)
    80001f92:	6121                	addi	sp,sp,64
    80001f94:	8082                	ret

0000000080001f96 <reparent>:
{
    80001f96:	7179                	addi	sp,sp,-48
    80001f98:	f406                	sd	ra,40(sp)
    80001f9a:	f022                	sd	s0,32(sp)
    80001f9c:	ec26                	sd	s1,24(sp)
    80001f9e:	e84a                	sd	s2,16(sp)
    80001fa0:	e44e                	sd	s3,8(sp)
    80001fa2:	e052                	sd	s4,0(sp)
    80001fa4:	1800                	addi	s0,sp,48
    80001fa6:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001fa8:	0000e497          	auipc	s1,0xe
    80001fac:	eb848493          	addi	s1,s1,-328 # 8000fe60 <proc>
      pp->parent = initproc;
    80001fb0:	00006a17          	auipc	s4,0x6
    80001fb4:	948a0a13          	addi	s4,s4,-1720 # 800078f8 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001fb8:	00014997          	auipc	s3,0x14
    80001fbc:	8a898993          	addi	s3,s3,-1880 # 80015860 <tickslock>
    80001fc0:	a029                	j	80001fca <reparent+0x34>
    80001fc2:	16848493          	addi	s1,s1,360
    80001fc6:	01348b63          	beq	s1,s3,80001fdc <reparent+0x46>
    if(pp->parent == p){
    80001fca:	7c9c                	ld	a5,56(s1)
    80001fcc:	ff279be3          	bne	a5,s2,80001fc2 <reparent+0x2c>
      pp->parent = initproc;
    80001fd0:	000a3503          	ld	a0,0(s4)
    80001fd4:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80001fd6:	f57ff0ef          	jal	80001f2c <wakeup>
    80001fda:	b7e5                	j	80001fc2 <reparent+0x2c>
}
    80001fdc:	70a2                	ld	ra,40(sp)
    80001fde:	7402                	ld	s0,32(sp)
    80001fe0:	64e2                	ld	s1,24(sp)
    80001fe2:	6942                	ld	s2,16(sp)
    80001fe4:	69a2                	ld	s3,8(sp)
    80001fe6:	6a02                	ld	s4,0(sp)
    80001fe8:	6145                	addi	sp,sp,48
    80001fea:	8082                	ret

0000000080001fec <exit>:
{
    80001fec:	7179                	addi	sp,sp,-48
    80001fee:	f406                	sd	ra,40(sp)
    80001ff0:	f022                	sd	s0,32(sp)
    80001ff2:	ec26                	sd	s1,24(sp)
    80001ff4:	e84a                	sd	s2,16(sp)
    80001ff6:	e44e                	sd	s3,8(sp)
    80001ff8:	e052                	sd	s4,0(sp)
    80001ffa:	1800                	addi	s0,sp,48
    80001ffc:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80001ffe:	927ff0ef          	jal	80001924 <myproc>
    80002002:	89aa                	mv	s3,a0
  if(p == initproc)
    80002004:	00006797          	auipc	a5,0x6
    80002008:	8f47b783          	ld	a5,-1804(a5) # 800078f8 <initproc>
    8000200c:	0d050493          	addi	s1,a0,208
    80002010:	15050913          	addi	s2,a0,336
    80002014:	00a79b63          	bne	a5,a0,8000202a <exit+0x3e>
    panic("init exiting");
    80002018:	00005517          	auipc	a0,0x5
    8000201c:	26850513          	addi	a0,a0,616 # 80007280 <etext+0x280>
    80002020:	fd0fe0ef          	jal	800007f0 <panic>
  for(int fd = 0; fd < NOFILE; fd++){
    80002024:	04a1                	addi	s1,s1,8
    80002026:	01248963          	beq	s1,s2,80002038 <exit+0x4c>
    if(p->ofile[fd]){
    8000202a:	6088                	ld	a0,0(s1)
    8000202c:	dd65                	beqz	a0,80002024 <exit+0x38>
      fileclose(f);
    8000202e:	67d010ef          	jal	80003eaa <fileclose>
      p->ofile[fd] = 0;
    80002032:	0004b023          	sd	zero,0(s1)
    80002036:	b7fd                	j	80002024 <exit+0x38>
  begin_op();
    80002038:	245010ef          	jal	80003a7c <begin_op>
  iput(p->cwd);
    8000203c:	1509b503          	ld	a0,336(s3)
    80002040:	2fc010ef          	jal	8000333c <iput>
  end_op();
    80002044:	2a9010ef          	jal	80003aec <end_op>
  p->cwd = 0;
    80002048:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    8000204c:	0000e517          	auipc	a0,0xe
    80002050:	9fc50513          	addi	a0,a0,-1540 # 8000fa48 <wait_lock>
    80002054:	c11fe0ef          	jal	80000c64 <acquire>
  reparent(p);
    80002058:	854e                	mv	a0,s3
    8000205a:	f3dff0ef          	jal	80001f96 <reparent>
  wakeup(p->parent);
    8000205e:	0389b503          	ld	a0,56(s3)
    80002062:	ecbff0ef          	jal	80001f2c <wakeup>
  acquire(&p->lock);
    80002066:	854e                	mv	a0,s3
    80002068:	bfdfe0ef          	jal	80000c64 <acquire>
  p->xstate = status;
    8000206c:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    80002070:	4795                	li	a5,5
    80002072:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    80002076:	0000e517          	auipc	a0,0xe
    8000207a:	9d250513          	addi	a0,a0,-1582 # 8000fa48 <wait_lock>
    8000207e:	c77fe0ef          	jal	80000cf4 <release>
  sched();
    80002082:	d79ff0ef          	jal	80001dfa <sched>
  panic("zombie exit");
    80002086:	00005517          	auipc	a0,0x5
    8000208a:	20a50513          	addi	a0,a0,522 # 80007290 <etext+0x290>
    8000208e:	f62fe0ef          	jal	800007f0 <panic>

0000000080002092 <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    80002092:	7179                	addi	sp,sp,-48
    80002094:	f406                	sd	ra,40(sp)
    80002096:	f022                	sd	s0,32(sp)
    80002098:	ec26                	sd	s1,24(sp)
    8000209a:	e84a                	sd	s2,16(sp)
    8000209c:	e44e                	sd	s3,8(sp)
    8000209e:	1800                	addi	s0,sp,48
    800020a0:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    800020a2:	0000e497          	auipc	s1,0xe
    800020a6:	dbe48493          	addi	s1,s1,-578 # 8000fe60 <proc>
    800020aa:	00013997          	auipc	s3,0x13
    800020ae:	7b698993          	addi	s3,s3,1974 # 80015860 <tickslock>
    acquire(&p->lock);
    800020b2:	8526                	mv	a0,s1
    800020b4:	bb1fe0ef          	jal	80000c64 <acquire>
    if(p->pid == pid){
    800020b8:	589c                	lw	a5,48(s1)
    800020ba:	01278b63          	beq	a5,s2,800020d0 <kill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    800020be:	8526                	mv	a0,s1
    800020c0:	c35fe0ef          	jal	80000cf4 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    800020c4:	16848493          	addi	s1,s1,360
    800020c8:	ff3495e3          	bne	s1,s3,800020b2 <kill+0x20>
  }
  return -1;
    800020cc:	557d                	li	a0,-1
    800020ce:	a819                	j	800020e4 <kill+0x52>
      p->killed = 1;
    800020d0:	4785                	li	a5,1
    800020d2:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    800020d4:	4c98                	lw	a4,24(s1)
    800020d6:	4789                	li	a5,2
    800020d8:	00f70d63          	beq	a4,a5,800020f2 <kill+0x60>
      release(&p->lock);
    800020dc:	8526                	mv	a0,s1
    800020de:	c17fe0ef          	jal	80000cf4 <release>
      return 0;
    800020e2:	4501                	li	a0,0
}
    800020e4:	70a2                	ld	ra,40(sp)
    800020e6:	7402                	ld	s0,32(sp)
    800020e8:	64e2                	ld	s1,24(sp)
    800020ea:	6942                	ld	s2,16(sp)
    800020ec:	69a2                	ld	s3,8(sp)
    800020ee:	6145                	addi	sp,sp,48
    800020f0:	8082                	ret
        p->state = RUNNABLE;
    800020f2:	478d                	li	a5,3
    800020f4:	cc9c                	sw	a5,24(s1)
    800020f6:	b7dd                	j	800020dc <kill+0x4a>

00000000800020f8 <setkilled>:

void
setkilled(struct proc *p)
{
    800020f8:	1101                	addi	sp,sp,-32
    800020fa:	ec06                	sd	ra,24(sp)
    800020fc:	e822                	sd	s0,16(sp)
    800020fe:	e426                	sd	s1,8(sp)
    80002100:	1000                	addi	s0,sp,32
    80002102:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002104:	b61fe0ef          	jal	80000c64 <acquire>
  p->killed = 1;
    80002108:	4785                	li	a5,1
    8000210a:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    8000210c:	8526                	mv	a0,s1
    8000210e:	be7fe0ef          	jal	80000cf4 <release>
}
    80002112:	60e2                	ld	ra,24(sp)
    80002114:	6442                	ld	s0,16(sp)
    80002116:	64a2                	ld	s1,8(sp)
    80002118:	6105                	addi	sp,sp,32
    8000211a:	8082                	ret

000000008000211c <killed>:

int
killed(struct proc *p)
{
    8000211c:	1101                	addi	sp,sp,-32
    8000211e:	ec06                	sd	ra,24(sp)
    80002120:	e822                	sd	s0,16(sp)
    80002122:	e426                	sd	s1,8(sp)
    80002124:	e04a                	sd	s2,0(sp)
    80002126:	1000                	addi	s0,sp,32
    80002128:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    8000212a:	b3bfe0ef          	jal	80000c64 <acquire>
  k = p->killed;
    8000212e:	549c                	lw	a5,40(s1)
    80002130:	893e                	mv	s2,a5
  release(&p->lock);
    80002132:	8526                	mv	a0,s1
    80002134:	bc1fe0ef          	jal	80000cf4 <release>
  return k;
}
    80002138:	854a                	mv	a0,s2
    8000213a:	60e2                	ld	ra,24(sp)
    8000213c:	6442                	ld	s0,16(sp)
    8000213e:	64a2                	ld	s1,8(sp)
    80002140:	6902                	ld	s2,0(sp)
    80002142:	6105                	addi	sp,sp,32
    80002144:	8082                	ret

0000000080002146 <wait>:
{
    80002146:	715d                	addi	sp,sp,-80
    80002148:	e486                	sd	ra,72(sp)
    8000214a:	e0a2                	sd	s0,64(sp)
    8000214c:	fc26                	sd	s1,56(sp)
    8000214e:	f84a                	sd	s2,48(sp)
    80002150:	f44e                	sd	s3,40(sp)
    80002152:	f052                	sd	s4,32(sp)
    80002154:	ec56                	sd	s5,24(sp)
    80002156:	e85a                	sd	s6,16(sp)
    80002158:	e45e                	sd	s7,8(sp)
    8000215a:	0880                	addi	s0,sp,80
    8000215c:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    8000215e:	fc6ff0ef          	jal	80001924 <myproc>
    80002162:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80002164:	0000e517          	auipc	a0,0xe
    80002168:	8e450513          	addi	a0,a0,-1820 # 8000fa48 <wait_lock>
    8000216c:	af9fe0ef          	jal	80000c64 <acquire>
        if(pp->state == ZOMBIE){
    80002170:	4a15                	li	s4,5
        havekids = 1;
    80002172:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002174:	00013997          	auipc	s3,0x13
    80002178:	6ec98993          	addi	s3,s3,1772 # 80015860 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    8000217c:	0000eb17          	auipc	s6,0xe
    80002180:	8ccb0b13          	addi	s6,s6,-1844 # 8000fa48 <wait_lock>
    80002184:	a861                	j	8000221c <wait+0xd6>
          pid = pp->pid;
    80002186:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    8000218a:	000b8c63          	beqz	s7,800021a2 <wait+0x5c>
    8000218e:	4691                	li	a3,4
    80002190:	02c48613          	addi	a2,s1,44
    80002194:	85de                	mv	a1,s7
    80002196:	05093503          	ld	a0,80(s2)
    8000219a:	c1aff0ef          	jal	800015b4 <copyout>
    8000219e:	02054a63          	bltz	a0,800021d2 <wait+0x8c>
          freeproc(pp);
    800021a2:	8526                	mv	a0,s1
    800021a4:	8f3ff0ef          	jal	80001a96 <freeproc>
          release(&pp->lock);
    800021a8:	8526                	mv	a0,s1
    800021aa:	b4bfe0ef          	jal	80000cf4 <release>
          release(&wait_lock);
    800021ae:	0000e517          	auipc	a0,0xe
    800021b2:	89a50513          	addi	a0,a0,-1894 # 8000fa48 <wait_lock>
    800021b6:	b3ffe0ef          	jal	80000cf4 <release>
}
    800021ba:	854e                	mv	a0,s3
    800021bc:	60a6                	ld	ra,72(sp)
    800021be:	6406                	ld	s0,64(sp)
    800021c0:	74e2                	ld	s1,56(sp)
    800021c2:	7942                	ld	s2,48(sp)
    800021c4:	79a2                	ld	s3,40(sp)
    800021c6:	7a02                	ld	s4,32(sp)
    800021c8:	6ae2                	ld	s5,24(sp)
    800021ca:	6b42                	ld	s6,16(sp)
    800021cc:	6ba2                	ld	s7,8(sp)
    800021ce:	6161                	addi	sp,sp,80
    800021d0:	8082                	ret
            release(&pp->lock);
    800021d2:	8526                	mv	a0,s1
    800021d4:	b21fe0ef          	jal	80000cf4 <release>
            release(&wait_lock);
    800021d8:	0000e517          	auipc	a0,0xe
    800021dc:	87050513          	addi	a0,a0,-1936 # 8000fa48 <wait_lock>
    800021e0:	b15fe0ef          	jal	80000cf4 <release>
            return -1;
    800021e4:	a881                	j	80002234 <wait+0xee>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800021e6:	16848493          	addi	s1,s1,360
    800021ea:	03348063          	beq	s1,s3,8000220a <wait+0xc4>
      if(pp->parent == p){
    800021ee:	7c9c                	ld	a5,56(s1)
    800021f0:	ff279be3          	bne	a5,s2,800021e6 <wait+0xa0>
        acquire(&pp->lock);
    800021f4:	8526                	mv	a0,s1
    800021f6:	a6ffe0ef          	jal	80000c64 <acquire>
        if(pp->state == ZOMBIE){
    800021fa:	4c9c                	lw	a5,24(s1)
    800021fc:	f94785e3          	beq	a5,s4,80002186 <wait+0x40>
        release(&pp->lock);
    80002200:	8526                	mv	a0,s1
    80002202:	af3fe0ef          	jal	80000cf4 <release>
        havekids = 1;
    80002206:	8756                	mv	a4,s5
    80002208:	bff9                	j	800021e6 <wait+0xa0>
    if(!havekids || killed(p)){
    8000220a:	cf19                	beqz	a4,80002228 <wait+0xe2>
    8000220c:	854a                	mv	a0,s2
    8000220e:	f0fff0ef          	jal	8000211c <killed>
    80002212:	e919                	bnez	a0,80002228 <wait+0xe2>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002214:	85da                	mv	a1,s6
    80002216:	854a                	mv	a0,s2
    80002218:	cc9ff0ef          	jal	80001ee0 <sleep>
    havekids = 0;
    8000221c:	4701                	li	a4,0
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000221e:	0000e497          	auipc	s1,0xe
    80002222:	c4248493          	addi	s1,s1,-958 # 8000fe60 <proc>
    80002226:	b7e1                	j	800021ee <wait+0xa8>
      release(&wait_lock);
    80002228:	0000e517          	auipc	a0,0xe
    8000222c:	82050513          	addi	a0,a0,-2016 # 8000fa48 <wait_lock>
    80002230:	ac5fe0ef          	jal	80000cf4 <release>
            return -1;
    80002234:	59fd                	li	s3,-1
    80002236:	b751                	j	800021ba <wait+0x74>

0000000080002238 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80002238:	7179                	addi	sp,sp,-48
    8000223a:	f406                	sd	ra,40(sp)
    8000223c:	f022                	sd	s0,32(sp)
    8000223e:	ec26                	sd	s1,24(sp)
    80002240:	e84a                	sd	s2,16(sp)
    80002242:	e44e                	sd	s3,8(sp)
    80002244:	e052                	sd	s4,0(sp)
    80002246:	1800                	addi	s0,sp,48
    80002248:	84aa                	mv	s1,a0
    8000224a:	8a2e                	mv	s4,a1
    8000224c:	89b2                	mv	s3,a2
    8000224e:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80002250:	ed4ff0ef          	jal	80001924 <myproc>
  if(user_dst){
    80002254:	cc99                	beqz	s1,80002272 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    80002256:	86ca                	mv	a3,s2
    80002258:	864e                	mv	a2,s3
    8000225a:	85d2                	mv	a1,s4
    8000225c:	6928                	ld	a0,80(a0)
    8000225e:	b56ff0ef          	jal	800015b4 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80002262:	70a2                	ld	ra,40(sp)
    80002264:	7402                	ld	s0,32(sp)
    80002266:	64e2                	ld	s1,24(sp)
    80002268:	6942                	ld	s2,16(sp)
    8000226a:	69a2                	ld	s3,8(sp)
    8000226c:	6a02                	ld	s4,0(sp)
    8000226e:	6145                	addi	sp,sp,48
    80002270:	8082                	ret
    memmove((char *)dst, src, len);
    80002272:	0009061b          	sext.w	a2,s2
    80002276:	85ce                	mv	a1,s3
    80002278:	8552                	mv	a0,s4
    8000227a:	b13fe0ef          	jal	80000d8c <memmove>
    return 0;
    8000227e:	8526                	mv	a0,s1
    80002280:	b7cd                	j	80002262 <either_copyout+0x2a>

0000000080002282 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80002282:	7179                	addi	sp,sp,-48
    80002284:	f406                	sd	ra,40(sp)
    80002286:	f022                	sd	s0,32(sp)
    80002288:	ec26                	sd	s1,24(sp)
    8000228a:	e84a                	sd	s2,16(sp)
    8000228c:	e44e                	sd	s3,8(sp)
    8000228e:	e052                	sd	s4,0(sp)
    80002290:	1800                	addi	s0,sp,48
    80002292:	8a2a                	mv	s4,a0
    80002294:	84ae                	mv	s1,a1
    80002296:	89b2                	mv	s3,a2
    80002298:	8936                	mv	s2,a3
  struct proc *p = myproc();
    8000229a:	e8aff0ef          	jal	80001924 <myproc>
  if(user_src){
    8000229e:	cc99                	beqz	s1,800022bc <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    800022a0:	86ca                	mv	a3,s2
    800022a2:	864e                	mv	a2,s3
    800022a4:	85d2                	mv	a1,s4
    800022a6:	6928                	ld	a0,80(a0)
    800022a8:	bbaff0ef          	jal	80001662 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    800022ac:	70a2                	ld	ra,40(sp)
    800022ae:	7402                	ld	s0,32(sp)
    800022b0:	64e2                	ld	s1,24(sp)
    800022b2:	6942                	ld	s2,16(sp)
    800022b4:	69a2                	ld	s3,8(sp)
    800022b6:	6a02                	ld	s4,0(sp)
    800022b8:	6145                	addi	sp,sp,48
    800022ba:	8082                	ret
    memmove(dst, (char*)src, len);
    800022bc:	0009061b          	sext.w	a2,s2
    800022c0:	85ce                	mv	a1,s3
    800022c2:	8552                	mv	a0,s4
    800022c4:	ac9fe0ef          	jal	80000d8c <memmove>
    return 0;
    800022c8:	8526                	mv	a0,s1
    800022ca:	b7cd                	j	800022ac <either_copyin+0x2a>

00000000800022cc <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    800022cc:	715d                	addi	sp,sp,-80
    800022ce:	e486                	sd	ra,72(sp)
    800022d0:	e0a2                	sd	s0,64(sp)
    800022d2:	fc26                	sd	s1,56(sp)
    800022d4:	f84a                	sd	s2,48(sp)
    800022d6:	f44e                	sd	s3,40(sp)
    800022d8:	f052                	sd	s4,32(sp)
    800022da:	ec56                	sd	s5,24(sp)
    800022dc:	e85a                	sd	s6,16(sp)
    800022de:	e45e                	sd	s7,8(sp)
    800022e0:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    800022e2:	00005517          	auipc	a0,0x5
    800022e6:	d9650513          	addi	a0,a0,-618 # 80007078 <etext+0x78>
    800022ea:	9e8fe0ef          	jal	800004d2 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800022ee:	0000e497          	auipc	s1,0xe
    800022f2:	cca48493          	addi	s1,s1,-822 # 8000ffb8 <proc+0x158>
    800022f6:	00013917          	auipc	s2,0x13
    800022fa:	6c290913          	addi	s2,s2,1730 # 800159b8 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800022fe:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80002300:	00005a97          	auipc	s5,0x5
    80002304:	fa0a8a93          	addi	s5,s5,-96 # 800072a0 <etext+0x2a0>
    printf("%d %s %s", p->pid, state, p->name);
    80002308:	00005a17          	auipc	s4,0x5
    8000230c:	fa0a0a13          	addi	s4,s4,-96 # 800072a8 <etext+0x2a8>
    printf("\n");
    80002310:	00005997          	auipc	s3,0x5
    80002314:	d6898993          	addi	s3,s3,-664 # 80007078 <etext+0x78>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002318:	00005b97          	auipc	s7,0x5
    8000231c:	470b8b93          	addi	s7,s7,1136 # 80007788 <states.0>
    80002320:	a829                	j	8000233a <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    80002322:	ed86a583          	lw	a1,-296(a3)
    80002326:	8552                	mv	a0,s4
    80002328:	9aafe0ef          	jal	800004d2 <printf>
    printf("\n");
    8000232c:	854e                	mv	a0,s3
    8000232e:	9a4fe0ef          	jal	800004d2 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002332:	16848493          	addi	s1,s1,360
    80002336:	03248063          	beq	s1,s2,80002356 <procdump+0x8a>
    if(p->state == UNUSED)
    8000233a:	86a6                	mv	a3,s1
    8000233c:	ec04a783          	lw	a5,-320(s1)
    80002340:	dbed                	beqz	a5,80002332 <procdump+0x66>
      state = "???";
    80002342:	8656                	mv	a2,s5
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002344:	fcfb6fe3          	bltu	s6,a5,80002322 <procdump+0x56>
    80002348:	02079713          	slli	a4,a5,0x20
    8000234c:	01d75793          	srli	a5,a4,0x1d
    80002350:	97de                	add	a5,a5,s7
    80002352:	6390                	ld	a2,0(a5)
      state = states[p->state];
    80002354:	b7f9                	j	80002322 <procdump+0x56>
  }
}
    80002356:	60a6                	ld	ra,72(sp)
    80002358:	6406                	ld	s0,64(sp)
    8000235a:	74e2                	ld	s1,56(sp)
    8000235c:	7942                	ld	s2,48(sp)
    8000235e:	79a2                	ld	s3,40(sp)
    80002360:	7a02                	ld	s4,32(sp)
    80002362:	6ae2                	ld	s5,24(sp)
    80002364:	6b42                	ld	s6,16(sp)
    80002366:	6ba2                	ld	s7,8(sp)
    80002368:	6161                	addi	sp,sp,80
    8000236a:	8082                	ret

000000008000236c <swtch>:
    8000236c:	00153023          	sd	ra,0(a0)
    80002370:	00253423          	sd	sp,8(a0)
    80002374:	e900                	sd	s0,16(a0)
    80002376:	ed04                	sd	s1,24(a0)
    80002378:	03253023          	sd	s2,32(a0)
    8000237c:	03353423          	sd	s3,40(a0)
    80002380:	03453823          	sd	s4,48(a0)
    80002384:	03553c23          	sd	s5,56(a0)
    80002388:	05653023          	sd	s6,64(a0)
    8000238c:	05753423          	sd	s7,72(a0)
    80002390:	05853823          	sd	s8,80(a0)
    80002394:	05953c23          	sd	s9,88(a0)
    80002398:	07a53023          	sd	s10,96(a0)
    8000239c:	07b53423          	sd	s11,104(a0)
    800023a0:	0005b083          	ld	ra,0(a1)
    800023a4:	0085b103          	ld	sp,8(a1)
    800023a8:	6980                	ld	s0,16(a1)
    800023aa:	6d84                	ld	s1,24(a1)
    800023ac:	0205b903          	ld	s2,32(a1)
    800023b0:	0285b983          	ld	s3,40(a1)
    800023b4:	0305ba03          	ld	s4,48(a1)
    800023b8:	0385ba83          	ld	s5,56(a1)
    800023bc:	0405bb03          	ld	s6,64(a1)
    800023c0:	0485bb83          	ld	s7,72(a1)
    800023c4:	0505bc03          	ld	s8,80(a1)
    800023c8:	0585bc83          	ld	s9,88(a1)
    800023cc:	0605bd03          	ld	s10,96(a1)
    800023d0:	0685bd83          	ld	s11,104(a1)
    800023d4:	8082                	ret

00000000800023d6 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    800023d6:	1141                	addi	sp,sp,-16
    800023d8:	e406                	sd	ra,8(sp)
    800023da:	e022                	sd	s0,0(sp)
    800023dc:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    800023de:	00005597          	auipc	a1,0x5
    800023e2:	f0a58593          	addi	a1,a1,-246 # 800072e8 <etext+0x2e8>
    800023e6:	00013517          	auipc	a0,0x13
    800023ea:	47a50513          	addi	a0,a0,1146 # 80015860 <tickslock>
    800023ee:	fecfe0ef          	jal	80000bda <initlock>
}
    800023f2:	60a2                	ld	ra,8(sp)
    800023f4:	6402                	ld	s0,0(sp)
    800023f6:	0141                	addi	sp,sp,16
    800023f8:	8082                	ret

00000000800023fa <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    800023fa:	1141                	addi	sp,sp,-16
    800023fc:	e406                	sd	ra,8(sp)
    800023fe:	e022                	sd	s0,0(sp)
    80002400:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002402:	00003797          	auipc	a5,0x3
    80002406:	dce78793          	addi	a5,a5,-562 # 800051d0 <kernelvec>
    8000240a:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    8000240e:	60a2                	ld	ra,8(sp)
    80002410:	6402                	ld	s0,0(sp)
    80002412:	0141                	addi	sp,sp,16
    80002414:	8082                	ret

0000000080002416 <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    80002416:	1141                	addi	sp,sp,-16
    80002418:	e406                	sd	ra,8(sp)
    8000241a:	e022                	sd	s0,0(sp)
    8000241c:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    8000241e:	d06ff0ef          	jal	80001924 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002422:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80002426:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002428:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    8000242c:	00004697          	auipc	a3,0x4
    80002430:	bd468693          	addi	a3,a3,-1068 # 80006000 <_trampoline>
    80002434:	00004717          	auipc	a4,0x4
    80002438:	bcc70713          	addi	a4,a4,-1076 # 80006000 <_trampoline>
    8000243c:	8f15                	sub	a4,a4,a3
    8000243e:	040007b7          	lui	a5,0x4000
    80002442:	17fd                	addi	a5,a5,-1 # 3ffffff <_entry-0x7c000001>
    80002444:	07b2                	slli	a5,a5,0xc
    80002446:	973e                	add	a4,a4,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002448:	10571073          	csrw	stvec,a4
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    8000244c:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    8000244e:	18002673          	csrr	a2,satp
    80002452:	e310                	sd	a2,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80002454:	6d30                	ld	a2,88(a0)
    80002456:	6138                	ld	a4,64(a0)
    80002458:	6585                	lui	a1,0x1
    8000245a:	972e                	add	a4,a4,a1
    8000245c:	e618                	sd	a4,8(a2)
  p->trapframe->kernel_trap = (uint64)usertrap;
    8000245e:	6d38                	ld	a4,88(a0)
    80002460:	00000617          	auipc	a2,0x0
    80002464:	10c60613          	addi	a2,a2,268 # 8000256c <usertrap>
    80002468:	eb10                	sd	a2,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    8000246a:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    8000246c:	8612                	mv	a2,tp
    8000246e:	f310                	sd	a2,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002470:	10002773          	csrr	a4,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80002474:	eff77713          	andi	a4,a4,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80002478:	02076713          	ori	a4,a4,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000247c:	10071073          	csrw	sstatus,a4
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    80002480:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    80002482:	6f18                	ld	a4,24(a4)
    80002484:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    80002488:	6928                	ld	a0,80(a0)
    8000248a:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    8000248c:	00004717          	auipc	a4,0x4
    80002490:	c1070713          	addi	a4,a4,-1008 # 8000609c <userret>
    80002494:	8f15                	sub	a4,a4,a3
    80002496:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80002498:	577d                	li	a4,-1
    8000249a:	177e                	slli	a4,a4,0x3f
    8000249c:	8d59                	or	a0,a0,a4
    8000249e:	9782                	jalr	a5
}
    800024a0:	60a2                	ld	ra,8(sp)
    800024a2:	6402                	ld	s0,0(sp)
    800024a4:	0141                	addi	sp,sp,16
    800024a6:	8082                	ret

00000000800024a8 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800024a8:	1141                	addi	sp,sp,-16
    800024aa:	e406                	sd	ra,8(sp)
    800024ac:	e022                	sd	s0,0(sp)
    800024ae:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    800024b0:	c40ff0ef          	jal	800018f0 <cpuid>
    800024b4:	cd11                	beqz	a0,800024d0 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    800024b6:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    800024ba:	000f4737          	lui	a4,0xf4
    800024be:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    800024c2:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    800024c4:	14d79073          	csrw	stimecmp,a5
}
    800024c8:	60a2                	ld	ra,8(sp)
    800024ca:	6402                	ld	s0,0(sp)
    800024cc:	0141                	addi	sp,sp,16
    800024ce:	8082                	ret
    acquire(&tickslock);
    800024d0:	00013517          	auipc	a0,0x13
    800024d4:	39050513          	addi	a0,a0,912 # 80015860 <tickslock>
    800024d8:	f8cfe0ef          	jal	80000c64 <acquire>
    ticks++;
    800024dc:	00005717          	auipc	a4,0x5
    800024e0:	42470713          	addi	a4,a4,1060 # 80007900 <ticks>
    800024e4:	431c                	lw	a5,0(a4)
    800024e6:	2785                	addiw	a5,a5,1
    800024e8:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    800024ea:	853a                	mv	a0,a4
    800024ec:	a41ff0ef          	jal	80001f2c <wakeup>
    release(&tickslock);
    800024f0:	00013517          	auipc	a0,0x13
    800024f4:	37050513          	addi	a0,a0,880 # 80015860 <tickslock>
    800024f8:	ffcfe0ef          	jal	80000cf4 <release>
    800024fc:	bf6d                	j	800024b6 <clockintr+0xe>

00000000800024fe <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    800024fe:	1101                	addi	sp,sp,-32
    80002500:	ec06                	sd	ra,24(sp)
    80002502:	e822                	sd	s0,16(sp)
    80002504:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002506:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    8000250a:	57fd                	li	a5,-1
    8000250c:	17fe                	slli	a5,a5,0x3f
    8000250e:	07a5                	addi	a5,a5,9
    80002510:	00f70c63          	beq	a4,a5,80002528 <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80002514:	57fd                	li	a5,-1
    80002516:	17fe                	slli	a5,a5,0x3f
    80002518:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    8000251a:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    8000251c:	04f70463          	beq	a4,a5,80002564 <devintr+0x66>
  }
}
    80002520:	60e2                	ld	ra,24(sp)
    80002522:	6442                	ld	s0,16(sp)
    80002524:	6105                	addi	sp,sp,32
    80002526:	8082                	ret
    80002528:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    8000252a:	553020ef          	jal	8000527c <plic_claim>
    8000252e:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80002530:	47a9                	li	a5,10
    80002532:	02f50363          	beq	a0,a5,80002558 <devintr+0x5a>
    } else if(irq == VIRTIO0_IRQ){
    80002536:	4785                	li	a5,1
    80002538:	02f50363          	beq	a0,a5,8000255e <devintr+0x60>
    } else if(irq){
    8000253c:	c919                	beqz	a0,80002552 <devintr+0x54>
      printf("unexpected interrupt irq=%d\n", irq);
    8000253e:	85aa                	mv	a1,a0
    80002540:	00005517          	auipc	a0,0x5
    80002544:	db050513          	addi	a0,a0,-592 # 800072f0 <etext+0x2f0>
    80002548:	f8bfd0ef          	jal	800004d2 <printf>
      plic_complete(irq);
    8000254c:	8526                	mv	a0,s1
    8000254e:	54f020ef          	jal	8000529c <plic_complete>
    return 1;
    80002552:	4505                	li	a0,1
    80002554:	64a2                	ld	s1,8(sp)
    80002556:	b7e9                	j	80002520 <devintr+0x22>
      uartintr();
    80002558:	cf8fe0ef          	jal	80000a50 <uartintr>
    if(irq)
    8000255c:	bfc5                	j	8000254c <devintr+0x4e>
      virtio_disk_intr();
    8000255e:	1a2030ef          	jal	80005700 <virtio_disk_intr>
    if(irq)
    80002562:	b7ed                	j	8000254c <devintr+0x4e>
    clockintr();
    80002564:	f45ff0ef          	jal	800024a8 <clockintr>
    return 2;
    80002568:	4509                	li	a0,2
    8000256a:	bf5d                	j	80002520 <devintr+0x22>

000000008000256c <usertrap>:
{
    8000256c:	1101                	addi	sp,sp,-32
    8000256e:	ec06                	sd	ra,24(sp)
    80002570:	e822                	sd	s0,16(sp)
    80002572:	e426                	sd	s1,8(sp)
    80002574:	e04a                	sd	s2,0(sp)
    80002576:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002578:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    8000257c:	1007f793          	andi	a5,a5,256
    80002580:	ef85                	bnez	a5,800025b8 <usertrap+0x4c>
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002582:	00003797          	auipc	a5,0x3
    80002586:	c4e78793          	addi	a5,a5,-946 # 800051d0 <kernelvec>
    8000258a:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    8000258e:	b96ff0ef          	jal	80001924 <myproc>
    80002592:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80002594:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002596:	14102773          	csrr	a4,sepc
    8000259a:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000259c:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    800025a0:	47a1                	li	a5,8
    800025a2:	02f70163          	beq	a4,a5,800025c4 <usertrap+0x58>
  } else if((which_dev = devintr()) != 0){
    800025a6:	f59ff0ef          	jal	800024fe <devintr>
    800025aa:	892a                	mv	s2,a0
    800025ac:	c135                	beqz	a0,80002610 <usertrap+0xa4>
  if(killed(p))
    800025ae:	8526                	mv	a0,s1
    800025b0:	b6dff0ef          	jal	8000211c <killed>
    800025b4:	cd1d                	beqz	a0,800025f2 <usertrap+0x86>
    800025b6:	a81d                	j	800025ec <usertrap+0x80>
    panic("usertrap: not from user mode");
    800025b8:	00005517          	auipc	a0,0x5
    800025bc:	d5850513          	addi	a0,a0,-680 # 80007310 <etext+0x310>
    800025c0:	a30fe0ef          	jal	800007f0 <panic>
    if(killed(p))
    800025c4:	b59ff0ef          	jal	8000211c <killed>
    800025c8:	e121                	bnez	a0,80002608 <usertrap+0x9c>
    p->trapframe->epc += 4;
    800025ca:	6cb8                	ld	a4,88(s1)
    800025cc:	6f1c                	ld	a5,24(a4)
    800025ce:	0791                	addi	a5,a5,4
    800025d0:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800025d2:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    800025d6:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800025da:	10079073          	csrw	sstatus,a5
    syscall();
    800025de:	23e000ef          	jal	8000281c <syscall>
  if(killed(p))
    800025e2:	8526                	mv	a0,s1
    800025e4:	b39ff0ef          	jal	8000211c <killed>
    800025e8:	c901                	beqz	a0,800025f8 <usertrap+0x8c>
    800025ea:	4901                	li	s2,0
    exit(-1);
    800025ec:	557d                	li	a0,-1
    800025ee:	9ffff0ef          	jal	80001fec <exit>
  if(which_dev == 2)
    800025f2:	4789                	li	a5,2
    800025f4:	04f90563          	beq	s2,a5,8000263e <usertrap+0xd2>
  usertrapret();
    800025f8:	e1fff0ef          	jal	80002416 <usertrapret>
}
    800025fc:	60e2                	ld	ra,24(sp)
    800025fe:	6442                	ld	s0,16(sp)
    80002600:	64a2                	ld	s1,8(sp)
    80002602:	6902                	ld	s2,0(sp)
    80002604:	6105                	addi	sp,sp,32
    80002606:	8082                	ret
      exit(-1);
    80002608:	557d                	li	a0,-1
    8000260a:	9e3ff0ef          	jal	80001fec <exit>
    8000260e:	bf75                	j	800025ca <usertrap+0x5e>
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002610:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80002614:	5890                	lw	a2,48(s1)
    80002616:	00005517          	auipc	a0,0x5
    8000261a:	d1a50513          	addi	a0,a0,-742 # 80007330 <etext+0x330>
    8000261e:	eb5fd0ef          	jal	800004d2 <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002622:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002626:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    8000262a:	00005517          	auipc	a0,0x5
    8000262e:	d3650513          	addi	a0,a0,-714 # 80007360 <etext+0x360>
    80002632:	ea1fd0ef          	jal	800004d2 <printf>
    setkilled(p);
    80002636:	8526                	mv	a0,s1
    80002638:	ac1ff0ef          	jal	800020f8 <setkilled>
    8000263c:	b75d                	j	800025e2 <usertrap+0x76>
    yield();
    8000263e:	877ff0ef          	jal	80001eb4 <yield>
    80002642:	bf5d                	j	800025f8 <usertrap+0x8c>

0000000080002644 <kerneltrap>:
{
    80002644:	7179                	addi	sp,sp,-48
    80002646:	f406                	sd	ra,40(sp)
    80002648:	f022                	sd	s0,32(sp)
    8000264a:	ec26                	sd	s1,24(sp)
    8000264c:	e84a                	sd	s2,16(sp)
    8000264e:	e44e                	sd	s3,8(sp)
    80002650:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002652:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002656:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000265a:	142027f3          	csrr	a5,scause
    8000265e:	89be                	mv	s3,a5
  if((sstatus & SSTATUS_SPP) == 0)
    80002660:	1004f793          	andi	a5,s1,256
    80002664:	c795                	beqz	a5,80002690 <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002666:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000266a:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    8000266c:	eb85                	bnez	a5,8000269c <kerneltrap+0x58>
  if((which_dev = devintr()) == 0){
    8000266e:	e91ff0ef          	jal	800024fe <devintr>
    80002672:	c91d                	beqz	a0,800026a8 <kerneltrap+0x64>
  if(which_dev == 2 && myproc() != 0)
    80002674:	4789                	li	a5,2
    80002676:	04f50a63          	beq	a0,a5,800026ca <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r" (x));
    8000267a:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000267e:	10049073          	csrw	sstatus,s1
}
    80002682:	70a2                	ld	ra,40(sp)
    80002684:	7402                	ld	s0,32(sp)
    80002686:	64e2                	ld	s1,24(sp)
    80002688:	6942                	ld	s2,16(sp)
    8000268a:	69a2                	ld	s3,8(sp)
    8000268c:	6145                	addi	sp,sp,48
    8000268e:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002690:	00005517          	auipc	a0,0x5
    80002694:	cf850513          	addi	a0,a0,-776 # 80007388 <etext+0x388>
    80002698:	958fe0ef          	jal	800007f0 <panic>
    panic("kerneltrap: interrupts enabled");
    8000269c:	00005517          	auipc	a0,0x5
    800026a0:	d1450513          	addi	a0,a0,-748 # 800073b0 <etext+0x3b0>
    800026a4:	94cfe0ef          	jal	800007f0 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800026a8:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    800026ac:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    800026b0:	85ce                	mv	a1,s3
    800026b2:	00005517          	auipc	a0,0x5
    800026b6:	d1e50513          	addi	a0,a0,-738 # 800073d0 <etext+0x3d0>
    800026ba:	e19fd0ef          	jal	800004d2 <printf>
    panic("kerneltrap");
    800026be:	00005517          	auipc	a0,0x5
    800026c2:	d3a50513          	addi	a0,a0,-710 # 800073f8 <etext+0x3f8>
    800026c6:	92afe0ef          	jal	800007f0 <panic>
  if(which_dev == 2 && myproc() != 0)
    800026ca:	a5aff0ef          	jal	80001924 <myproc>
    800026ce:	d555                	beqz	a0,8000267a <kerneltrap+0x36>
    yield();
    800026d0:	fe4ff0ef          	jal	80001eb4 <yield>
    800026d4:	b75d                	j	8000267a <kerneltrap+0x36>

00000000800026d6 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    800026d6:	1101                	addi	sp,sp,-32
    800026d8:	ec06                	sd	ra,24(sp)
    800026da:	e822                	sd	s0,16(sp)
    800026dc:	e426                	sd	s1,8(sp)
    800026de:	1000                	addi	s0,sp,32
    800026e0:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    800026e2:	a42ff0ef          	jal	80001924 <myproc>
  switch (n) {
    800026e6:	4795                	li	a5,5
    800026e8:	0497e163          	bltu	a5,s1,8000272a <argraw+0x54>
    800026ec:	048a                	slli	s1,s1,0x2
    800026ee:	00005717          	auipc	a4,0x5
    800026f2:	0ca70713          	addi	a4,a4,202 # 800077b8 <states.0+0x30>
    800026f6:	94ba                	add	s1,s1,a4
    800026f8:	409c                	lw	a5,0(s1)
    800026fa:	97ba                	add	a5,a5,a4
    800026fc:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    800026fe:	6d3c                	ld	a5,88(a0)
    80002700:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002702:	60e2                	ld	ra,24(sp)
    80002704:	6442                	ld	s0,16(sp)
    80002706:	64a2                	ld	s1,8(sp)
    80002708:	6105                	addi	sp,sp,32
    8000270a:	8082                	ret
    return p->trapframe->a1;
    8000270c:	6d3c                	ld	a5,88(a0)
    8000270e:	7fa8                	ld	a0,120(a5)
    80002710:	bfcd                	j	80002702 <argraw+0x2c>
    return p->trapframe->a2;
    80002712:	6d3c                	ld	a5,88(a0)
    80002714:	63c8                	ld	a0,128(a5)
    80002716:	b7f5                	j	80002702 <argraw+0x2c>
    return p->trapframe->a3;
    80002718:	6d3c                	ld	a5,88(a0)
    8000271a:	67c8                	ld	a0,136(a5)
    8000271c:	b7dd                	j	80002702 <argraw+0x2c>
    return p->trapframe->a4;
    8000271e:	6d3c                	ld	a5,88(a0)
    80002720:	6bc8                	ld	a0,144(a5)
    80002722:	b7c5                	j	80002702 <argraw+0x2c>
    return p->trapframe->a5;
    80002724:	6d3c                	ld	a5,88(a0)
    80002726:	6fc8                	ld	a0,152(a5)
    80002728:	bfe9                	j	80002702 <argraw+0x2c>
  panic("argraw");
    8000272a:	00005517          	auipc	a0,0x5
    8000272e:	cde50513          	addi	a0,a0,-802 # 80007408 <etext+0x408>
    80002732:	8befe0ef          	jal	800007f0 <panic>

0000000080002736 <fetchaddr>:
{
    80002736:	1101                	addi	sp,sp,-32
    80002738:	ec06                	sd	ra,24(sp)
    8000273a:	e822                	sd	s0,16(sp)
    8000273c:	e426                	sd	s1,8(sp)
    8000273e:	e04a                	sd	s2,0(sp)
    80002740:	1000                	addi	s0,sp,32
    80002742:	84aa                	mv	s1,a0
    80002744:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002746:	9deff0ef          	jal	80001924 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    8000274a:	653c                	ld	a5,72(a0)
    8000274c:	02f4f663          	bgeu	s1,a5,80002778 <fetchaddr+0x42>
    80002750:	00848713          	addi	a4,s1,8
    80002754:	02e7e263          	bltu	a5,a4,80002778 <fetchaddr+0x42>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80002758:	46a1                	li	a3,8
    8000275a:	8626                	mv	a2,s1
    8000275c:	85ca                	mv	a1,s2
    8000275e:	6928                	ld	a0,80(a0)
    80002760:	f03fe0ef          	jal	80001662 <copyin>
    80002764:	00a03533          	snez	a0,a0
    80002768:	40a0053b          	negw	a0,a0
}
    8000276c:	60e2                	ld	ra,24(sp)
    8000276e:	6442                	ld	s0,16(sp)
    80002770:	64a2                	ld	s1,8(sp)
    80002772:	6902                	ld	s2,0(sp)
    80002774:	6105                	addi	sp,sp,32
    80002776:	8082                	ret
    return -1;
    80002778:	557d                	li	a0,-1
    8000277a:	bfcd                	j	8000276c <fetchaddr+0x36>

000000008000277c <fetchstr>:
{
    8000277c:	7179                	addi	sp,sp,-48
    8000277e:	f406                	sd	ra,40(sp)
    80002780:	f022                	sd	s0,32(sp)
    80002782:	ec26                	sd	s1,24(sp)
    80002784:	e84a                	sd	s2,16(sp)
    80002786:	e44e                	sd	s3,8(sp)
    80002788:	1800                	addi	s0,sp,48
    8000278a:	89aa                	mv	s3,a0
    8000278c:	84ae                	mv	s1,a1
    8000278e:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80002790:	994ff0ef          	jal	80001924 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80002794:	86ca                	mv	a3,s2
    80002796:	864e                	mv	a2,s3
    80002798:	85a6                	mv	a1,s1
    8000279a:	6928                	ld	a0,80(a0)
    8000279c:	f4dfe0ef          	jal	800016e8 <copyinstr>
    800027a0:	00054c63          	bltz	a0,800027b8 <fetchstr+0x3c>
  return strlen(buf);
    800027a4:	8526                	mv	a0,s1
    800027a6:	f0afe0ef          	jal	80000eb0 <strlen>
}
    800027aa:	70a2                	ld	ra,40(sp)
    800027ac:	7402                	ld	s0,32(sp)
    800027ae:	64e2                	ld	s1,24(sp)
    800027b0:	6942                	ld	s2,16(sp)
    800027b2:	69a2                	ld	s3,8(sp)
    800027b4:	6145                	addi	sp,sp,48
    800027b6:	8082                	ret
    return -1;
    800027b8:	557d                	li	a0,-1
    800027ba:	bfc5                	j	800027aa <fetchstr+0x2e>

00000000800027bc <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    800027bc:	1101                	addi	sp,sp,-32
    800027be:	ec06                	sd	ra,24(sp)
    800027c0:	e822                	sd	s0,16(sp)
    800027c2:	e426                	sd	s1,8(sp)
    800027c4:	1000                	addi	s0,sp,32
    800027c6:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800027c8:	f0fff0ef          	jal	800026d6 <argraw>
    800027cc:	c088                	sw	a0,0(s1)
}
    800027ce:	60e2                	ld	ra,24(sp)
    800027d0:	6442                	ld	s0,16(sp)
    800027d2:	64a2                	ld	s1,8(sp)
    800027d4:	6105                	addi	sp,sp,32
    800027d6:	8082                	ret

00000000800027d8 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    800027d8:	1101                	addi	sp,sp,-32
    800027da:	ec06                	sd	ra,24(sp)
    800027dc:	e822                	sd	s0,16(sp)
    800027de:	e426                	sd	s1,8(sp)
    800027e0:	1000                	addi	s0,sp,32
    800027e2:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800027e4:	ef3ff0ef          	jal	800026d6 <argraw>
    800027e8:	e088                	sd	a0,0(s1)
}
    800027ea:	60e2                	ld	ra,24(sp)
    800027ec:	6442                	ld	s0,16(sp)
    800027ee:	64a2                	ld	s1,8(sp)
    800027f0:	6105                	addi	sp,sp,32
    800027f2:	8082                	ret

00000000800027f4 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    800027f4:	1101                	addi	sp,sp,-32
    800027f6:	ec06                	sd	ra,24(sp)
    800027f8:	e822                	sd	s0,16(sp)
    800027fa:	e426                	sd	s1,8(sp)
    800027fc:	e04a                	sd	s2,0(sp)
    800027fe:	1000                	addi	s0,sp,32
    80002800:	892e                	mv	s2,a1
    80002802:	84b2                	mv	s1,a2
  *ip = argraw(n);
    80002804:	ed3ff0ef          	jal	800026d6 <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    80002808:	8626                	mv	a2,s1
    8000280a:	85ca                	mv	a1,s2
    8000280c:	f71ff0ef          	jal	8000277c <fetchstr>
}
    80002810:	60e2                	ld	ra,24(sp)
    80002812:	6442                	ld	s0,16(sp)
    80002814:	64a2                	ld	s1,8(sp)
    80002816:	6902                	ld	s2,0(sp)
    80002818:	6105                	addi	sp,sp,32
    8000281a:	8082                	ret

000000008000281c <syscall>:
[SYS_close]   sys_close,
};

void
syscall(void)
{
    8000281c:	1101                	addi	sp,sp,-32
    8000281e:	ec06                	sd	ra,24(sp)
    80002820:	e822                	sd	s0,16(sp)
    80002822:	e426                	sd	s1,8(sp)
    80002824:	e04a                	sd	s2,0(sp)
    80002826:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002828:	8fcff0ef          	jal	80001924 <myproc>
    8000282c:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    8000282e:	05853903          	ld	s2,88(a0)
    80002832:	0a893783          	ld	a5,168(s2)
    80002836:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    8000283a:	37fd                	addiw	a5,a5,-1
    8000283c:	4751                	li	a4,20
    8000283e:	00f76f63          	bltu	a4,a5,8000285c <syscall+0x40>
    80002842:	00369713          	slli	a4,a3,0x3
    80002846:	00005797          	auipc	a5,0x5
    8000284a:	f8a78793          	addi	a5,a5,-118 # 800077d0 <syscalls>
    8000284e:	97ba                	add	a5,a5,a4
    80002850:	639c                	ld	a5,0(a5)
    80002852:	c789                	beqz	a5,8000285c <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002854:	9782                	jalr	a5
    80002856:	06a93823          	sd	a0,112(s2)
    8000285a:	a829                	j	80002874 <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    8000285c:	15848613          	addi	a2,s1,344
    80002860:	588c                	lw	a1,48(s1)
    80002862:	00005517          	auipc	a0,0x5
    80002866:	bae50513          	addi	a0,a0,-1106 # 80007410 <etext+0x410>
    8000286a:	c69fd0ef          	jal	800004d2 <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    8000286e:	6cbc                	ld	a5,88(s1)
    80002870:	577d                	li	a4,-1
    80002872:	fbb8                	sd	a4,112(a5)
  }
}
    80002874:	60e2                	ld	ra,24(sp)
    80002876:	6442                	ld	s0,16(sp)
    80002878:	64a2                	ld	s1,8(sp)
    8000287a:	6902                	ld	s2,0(sp)
    8000287c:	6105                	addi	sp,sp,32
    8000287e:	8082                	ret

0000000080002880 <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    80002880:	1101                	addi	sp,sp,-32
    80002882:	ec06                	sd	ra,24(sp)
    80002884:	e822                	sd	s0,16(sp)
    80002886:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002888:	fec40593          	addi	a1,s0,-20
    8000288c:	4501                	li	a0,0
    8000288e:	f2fff0ef          	jal	800027bc <argint>
  exit(n);
    80002892:	fec42503          	lw	a0,-20(s0)
    80002896:	f56ff0ef          	jal	80001fec <exit>
  return 0;  // not reached
}
    8000289a:	4501                	li	a0,0
    8000289c:	60e2                	ld	ra,24(sp)
    8000289e:	6442                	ld	s0,16(sp)
    800028a0:	6105                	addi	sp,sp,32
    800028a2:	8082                	ret

00000000800028a4 <sys_getpid>:

uint64
sys_getpid(void)
{
    800028a4:	1141                	addi	sp,sp,-16
    800028a6:	e406                	sd	ra,8(sp)
    800028a8:	e022                	sd	s0,0(sp)
    800028aa:	0800                	addi	s0,sp,16
  return myproc()->pid;
    800028ac:	878ff0ef          	jal	80001924 <myproc>
}
    800028b0:	5908                	lw	a0,48(a0)
    800028b2:	60a2                	ld	ra,8(sp)
    800028b4:	6402                	ld	s0,0(sp)
    800028b6:	0141                	addi	sp,sp,16
    800028b8:	8082                	ret

00000000800028ba <sys_fork>:

uint64
sys_fork(void)
{
    800028ba:	1141                	addi	sp,sp,-16
    800028bc:	e406                	sd	ra,8(sp)
    800028be:	e022                	sd	s0,0(sp)
    800028c0:	0800                	addi	s0,sp,16
  return fork();
    800028c2:	b88ff0ef          	jal	80001c4a <fork>
}
    800028c6:	60a2                	ld	ra,8(sp)
    800028c8:	6402                	ld	s0,0(sp)
    800028ca:	0141                	addi	sp,sp,16
    800028cc:	8082                	ret

00000000800028ce <sys_wait>:

uint64
sys_wait(void)
{
    800028ce:	1101                	addi	sp,sp,-32
    800028d0:	ec06                	sd	ra,24(sp)
    800028d2:	e822                	sd	s0,16(sp)
    800028d4:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    800028d6:	fe840593          	addi	a1,s0,-24
    800028da:	4501                	li	a0,0
    800028dc:	efdff0ef          	jal	800027d8 <argaddr>
  return wait(p);
    800028e0:	fe843503          	ld	a0,-24(s0)
    800028e4:	863ff0ef          	jal	80002146 <wait>
}
    800028e8:	60e2                	ld	ra,24(sp)
    800028ea:	6442                	ld	s0,16(sp)
    800028ec:	6105                	addi	sp,sp,32
    800028ee:	8082                	ret

00000000800028f0 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    800028f0:	7179                	addi	sp,sp,-48
    800028f2:	f406                	sd	ra,40(sp)
    800028f4:	f022                	sd	s0,32(sp)
    800028f6:	ec26                	sd	s1,24(sp)
    800028f8:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    800028fa:	fdc40593          	addi	a1,s0,-36
    800028fe:	4501                	li	a0,0
    80002900:	ebdff0ef          	jal	800027bc <argint>
  addr = myproc()->sz;
    80002904:	820ff0ef          	jal	80001924 <myproc>
    80002908:	653c                	ld	a5,72(a0)
    8000290a:	84be                	mv	s1,a5
  if(growproc(n) < 0)
    8000290c:	fdc42503          	lw	a0,-36(s0)
    80002910:	aeaff0ef          	jal	80001bfa <growproc>
    80002914:	00054863          	bltz	a0,80002924 <sys_sbrk+0x34>
    return -1;
  return addr;
}
    80002918:	8526                	mv	a0,s1
    8000291a:	70a2                	ld	ra,40(sp)
    8000291c:	7402                	ld	s0,32(sp)
    8000291e:	64e2                	ld	s1,24(sp)
    80002920:	6145                	addi	sp,sp,48
    80002922:	8082                	ret
    return -1;
    80002924:	57fd                	li	a5,-1
    80002926:	84be                	mv	s1,a5
    80002928:	bfc5                	j	80002918 <sys_sbrk+0x28>

000000008000292a <sys_sleep>:

uint64
sys_sleep(void)
{
    8000292a:	7139                	addi	sp,sp,-64
    8000292c:	fc06                	sd	ra,56(sp)
    8000292e:	f822                	sd	s0,48(sp)
    80002930:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002932:	fcc40593          	addi	a1,s0,-52
    80002936:	4501                	li	a0,0
    80002938:	e85ff0ef          	jal	800027bc <argint>
  if(n < 0)
    8000293c:	fcc42783          	lw	a5,-52(s0)
    80002940:	0607c863          	bltz	a5,800029b0 <sys_sleep+0x86>
    n = 0;
  acquire(&tickslock);
    80002944:	00013517          	auipc	a0,0x13
    80002948:	f1c50513          	addi	a0,a0,-228 # 80015860 <tickslock>
    8000294c:	b18fe0ef          	jal	80000c64 <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    80002950:	fcc42783          	lw	a5,-52(s0)
    80002954:	c3b9                	beqz	a5,8000299a <sys_sleep+0x70>
    80002956:	f426                	sd	s1,40(sp)
    80002958:	f04a                	sd	s2,32(sp)
    8000295a:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    8000295c:	00005997          	auipc	s3,0x5
    80002960:	fa49a983          	lw	s3,-92(s3) # 80007900 <ticks>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002964:	00013917          	auipc	s2,0x13
    80002968:	efc90913          	addi	s2,s2,-260 # 80015860 <tickslock>
    8000296c:	00005497          	auipc	s1,0x5
    80002970:	f9448493          	addi	s1,s1,-108 # 80007900 <ticks>
    if(killed(myproc())){
    80002974:	fb1fe0ef          	jal	80001924 <myproc>
    80002978:	fa4ff0ef          	jal	8000211c <killed>
    8000297c:	ed0d                	bnez	a0,800029b6 <sys_sleep+0x8c>
    sleep(&ticks, &tickslock);
    8000297e:	85ca                	mv	a1,s2
    80002980:	8526                	mv	a0,s1
    80002982:	d5eff0ef          	jal	80001ee0 <sleep>
  while(ticks - ticks0 < n){
    80002986:	409c                	lw	a5,0(s1)
    80002988:	413787bb          	subw	a5,a5,s3
    8000298c:	fcc42703          	lw	a4,-52(s0)
    80002990:	fee7e2e3          	bltu	a5,a4,80002974 <sys_sleep+0x4a>
    80002994:	74a2                	ld	s1,40(sp)
    80002996:	7902                	ld	s2,32(sp)
    80002998:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    8000299a:	00013517          	auipc	a0,0x13
    8000299e:	ec650513          	addi	a0,a0,-314 # 80015860 <tickslock>
    800029a2:	b52fe0ef          	jal	80000cf4 <release>
  return 0;
    800029a6:	4501                	li	a0,0
}
    800029a8:	70e2                	ld	ra,56(sp)
    800029aa:	7442                	ld	s0,48(sp)
    800029ac:	6121                	addi	sp,sp,64
    800029ae:	8082                	ret
    n = 0;
    800029b0:	fc042623          	sw	zero,-52(s0)
    800029b4:	bf41                	j	80002944 <sys_sleep+0x1a>
      release(&tickslock);
    800029b6:	00013517          	auipc	a0,0x13
    800029ba:	eaa50513          	addi	a0,a0,-342 # 80015860 <tickslock>
    800029be:	b36fe0ef          	jal	80000cf4 <release>
      return -1;
    800029c2:	557d                	li	a0,-1
    800029c4:	74a2                	ld	s1,40(sp)
    800029c6:	7902                	ld	s2,32(sp)
    800029c8:	69e2                	ld	s3,24(sp)
    800029ca:	bff9                	j	800029a8 <sys_sleep+0x7e>

00000000800029cc <sys_kill>:

uint64
sys_kill(void)
{
    800029cc:	1101                	addi	sp,sp,-32
    800029ce:	ec06                	sd	ra,24(sp)
    800029d0:	e822                	sd	s0,16(sp)
    800029d2:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    800029d4:	fec40593          	addi	a1,s0,-20
    800029d8:	4501                	li	a0,0
    800029da:	de3ff0ef          	jal	800027bc <argint>
  return kill(pid);
    800029de:	fec42503          	lw	a0,-20(s0)
    800029e2:	eb0ff0ef          	jal	80002092 <kill>
}
    800029e6:	60e2                	ld	ra,24(sp)
    800029e8:	6442                	ld	s0,16(sp)
    800029ea:	6105                	addi	sp,sp,32
    800029ec:	8082                	ret

00000000800029ee <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    800029ee:	1101                	addi	sp,sp,-32
    800029f0:	ec06                	sd	ra,24(sp)
    800029f2:	e822                	sd	s0,16(sp)
    800029f4:	e426                	sd	s1,8(sp)
    800029f6:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    800029f8:	00013517          	auipc	a0,0x13
    800029fc:	e6850513          	addi	a0,a0,-408 # 80015860 <tickslock>
    80002a00:	a64fe0ef          	jal	80000c64 <acquire>
  xticks = ticks;
    80002a04:	00005797          	auipc	a5,0x5
    80002a08:	efc7a783          	lw	a5,-260(a5) # 80007900 <ticks>
    80002a0c:	84be                	mv	s1,a5
  release(&tickslock);
    80002a0e:	00013517          	auipc	a0,0x13
    80002a12:	e5250513          	addi	a0,a0,-430 # 80015860 <tickslock>
    80002a16:	adefe0ef          	jal	80000cf4 <release>
  return xticks;
}
    80002a1a:	02049513          	slli	a0,s1,0x20
    80002a1e:	9101                	srli	a0,a0,0x20
    80002a20:	60e2                	ld	ra,24(sp)
    80002a22:	6442                	ld	s0,16(sp)
    80002a24:	64a2                	ld	s1,8(sp)
    80002a26:	6105                	addi	sp,sp,32
    80002a28:	8082                	ret

0000000080002a2a <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002a2a:	7179                	addi	sp,sp,-48
    80002a2c:	f406                	sd	ra,40(sp)
    80002a2e:	f022                	sd	s0,32(sp)
    80002a30:	ec26                	sd	s1,24(sp)
    80002a32:	e84a                	sd	s2,16(sp)
    80002a34:	e44e                	sd	s3,8(sp)
    80002a36:	e052                	sd	s4,0(sp)
    80002a38:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002a3a:	00005597          	auipc	a1,0x5
    80002a3e:	9f658593          	addi	a1,a1,-1546 # 80007430 <etext+0x430>
    80002a42:	00013517          	auipc	a0,0x13
    80002a46:	e3650513          	addi	a0,a0,-458 # 80015878 <bcache>
    80002a4a:	990fe0ef          	jal	80000bda <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002a4e:	0001b797          	auipc	a5,0x1b
    80002a52:	e2a78793          	addi	a5,a5,-470 # 8001d878 <bcache+0x8000>
    80002a56:	0001b717          	auipc	a4,0x1b
    80002a5a:	08a70713          	addi	a4,a4,138 # 8001dae0 <bcache+0x8268>
    80002a5e:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002a62:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002a66:	00013497          	auipc	s1,0x13
    80002a6a:	e2a48493          	addi	s1,s1,-470 # 80015890 <bcache+0x18>
    b->next = bcache.head.next;
    80002a6e:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002a70:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002a72:	00005a17          	auipc	s4,0x5
    80002a76:	9c6a0a13          	addi	s4,s4,-1594 # 80007438 <etext+0x438>
    b->next = bcache.head.next;
    80002a7a:	2b893783          	ld	a5,696(s2)
    80002a7e:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002a80:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002a84:	85d2                	mv	a1,s4
    80002a86:	01048513          	addi	a0,s1,16
    80002a8a:	25a010ef          	jal	80003ce4 <initsleeplock>
    bcache.head.next->prev = b;
    80002a8e:	2b893783          	ld	a5,696(s2)
    80002a92:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002a94:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002a98:	45848493          	addi	s1,s1,1112
    80002a9c:	fd349fe3          	bne	s1,s3,80002a7a <binit+0x50>
  }
}
    80002aa0:	70a2                	ld	ra,40(sp)
    80002aa2:	7402                	ld	s0,32(sp)
    80002aa4:	64e2                	ld	s1,24(sp)
    80002aa6:	6942                	ld	s2,16(sp)
    80002aa8:	69a2                	ld	s3,8(sp)
    80002aaa:	6a02                	ld	s4,0(sp)
    80002aac:	6145                	addi	sp,sp,48
    80002aae:	8082                	ret

0000000080002ab0 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002ab0:	7179                	addi	sp,sp,-48
    80002ab2:	f406                	sd	ra,40(sp)
    80002ab4:	f022                	sd	s0,32(sp)
    80002ab6:	ec26                	sd	s1,24(sp)
    80002ab8:	e84a                	sd	s2,16(sp)
    80002aba:	e44e                	sd	s3,8(sp)
    80002abc:	1800                	addi	s0,sp,48
    80002abe:	892a                	mv	s2,a0
    80002ac0:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002ac2:	00013517          	auipc	a0,0x13
    80002ac6:	db650513          	addi	a0,a0,-586 # 80015878 <bcache>
    80002aca:	99afe0ef          	jal	80000c64 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002ace:	0001b497          	auipc	s1,0x1b
    80002ad2:	0624b483          	ld	s1,98(s1) # 8001db30 <bcache+0x82b8>
    80002ad6:	0001b797          	auipc	a5,0x1b
    80002ada:	00a78793          	addi	a5,a5,10 # 8001dae0 <bcache+0x8268>
    80002ade:	02f48b63          	beq	s1,a5,80002b14 <bread+0x64>
    80002ae2:	873e                	mv	a4,a5
    80002ae4:	a021                	j	80002aec <bread+0x3c>
    80002ae6:	68a4                	ld	s1,80(s1)
    80002ae8:	02e48663          	beq	s1,a4,80002b14 <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002aec:	449c                	lw	a5,8(s1)
    80002aee:	ff279ce3          	bne	a5,s2,80002ae6 <bread+0x36>
    80002af2:	44dc                	lw	a5,12(s1)
    80002af4:	ff3799e3          	bne	a5,s3,80002ae6 <bread+0x36>
      b->refcnt++;
    80002af8:	40bc                	lw	a5,64(s1)
    80002afa:	2785                	addiw	a5,a5,1
    80002afc:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002afe:	00013517          	auipc	a0,0x13
    80002b02:	d7a50513          	addi	a0,a0,-646 # 80015878 <bcache>
    80002b06:	9eefe0ef          	jal	80000cf4 <release>
      acquiresleep(&b->lock);
    80002b0a:	01048513          	addi	a0,s1,16
    80002b0e:	20c010ef          	jal	80003d1a <acquiresleep>
      return b;
    80002b12:	a889                	j	80002b64 <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002b14:	0001b497          	auipc	s1,0x1b
    80002b18:	0144b483          	ld	s1,20(s1) # 8001db28 <bcache+0x82b0>
    80002b1c:	0001b797          	auipc	a5,0x1b
    80002b20:	fc478793          	addi	a5,a5,-60 # 8001dae0 <bcache+0x8268>
    80002b24:	00f48863          	beq	s1,a5,80002b34 <bread+0x84>
    80002b28:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002b2a:	40bc                	lw	a5,64(s1)
    80002b2c:	cb91                	beqz	a5,80002b40 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002b2e:	64a4                	ld	s1,72(s1)
    80002b30:	fee49de3          	bne	s1,a4,80002b2a <bread+0x7a>
  panic("bget: no buffers");
    80002b34:	00005517          	auipc	a0,0x5
    80002b38:	90c50513          	addi	a0,a0,-1780 # 80007440 <etext+0x440>
    80002b3c:	cb5fd0ef          	jal	800007f0 <panic>
      b->dev = dev;
    80002b40:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002b44:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002b48:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002b4c:	4785                	li	a5,1
    80002b4e:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002b50:	00013517          	auipc	a0,0x13
    80002b54:	d2850513          	addi	a0,a0,-728 # 80015878 <bcache>
    80002b58:	99cfe0ef          	jal	80000cf4 <release>
      acquiresleep(&b->lock);
    80002b5c:	01048513          	addi	a0,s1,16
    80002b60:	1ba010ef          	jal	80003d1a <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002b64:	409c                	lw	a5,0(s1)
    80002b66:	cb89                	beqz	a5,80002b78 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002b68:	8526                	mv	a0,s1
    80002b6a:	70a2                	ld	ra,40(sp)
    80002b6c:	7402                	ld	s0,32(sp)
    80002b6e:	64e2                	ld	s1,24(sp)
    80002b70:	6942                	ld	s2,16(sp)
    80002b72:	69a2                	ld	s3,8(sp)
    80002b74:	6145                	addi	sp,sp,48
    80002b76:	8082                	ret
    virtio_disk_rw(b, 0);
    80002b78:	4581                	li	a1,0
    80002b7a:	8526                	mv	a0,s1
    80002b7c:	177020ef          	jal	800054f2 <virtio_disk_rw>
    b->valid = 1;
    80002b80:	4785                	li	a5,1
    80002b82:	c09c                	sw	a5,0(s1)
  return b;
    80002b84:	b7d5                	j	80002b68 <bread+0xb8>

0000000080002b86 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80002b86:	1101                	addi	sp,sp,-32
    80002b88:	ec06                	sd	ra,24(sp)
    80002b8a:	e822                	sd	s0,16(sp)
    80002b8c:	e426                	sd	s1,8(sp)
    80002b8e:	1000                	addi	s0,sp,32
    80002b90:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002b92:	0541                	addi	a0,a0,16
    80002b94:	204010ef          	jal	80003d98 <holdingsleep>
    80002b98:	c911                	beqz	a0,80002bac <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002b9a:	4585                	li	a1,1
    80002b9c:	8526                	mv	a0,s1
    80002b9e:	155020ef          	jal	800054f2 <virtio_disk_rw>
}
    80002ba2:	60e2                	ld	ra,24(sp)
    80002ba4:	6442                	ld	s0,16(sp)
    80002ba6:	64a2                	ld	s1,8(sp)
    80002ba8:	6105                	addi	sp,sp,32
    80002baa:	8082                	ret
    panic("bwrite");
    80002bac:	00005517          	auipc	a0,0x5
    80002bb0:	8ac50513          	addi	a0,a0,-1876 # 80007458 <etext+0x458>
    80002bb4:	c3dfd0ef          	jal	800007f0 <panic>

0000000080002bb8 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002bb8:	1101                	addi	sp,sp,-32
    80002bba:	ec06                	sd	ra,24(sp)
    80002bbc:	e822                	sd	s0,16(sp)
    80002bbe:	e426                	sd	s1,8(sp)
    80002bc0:	e04a                	sd	s2,0(sp)
    80002bc2:	1000                	addi	s0,sp,32
    80002bc4:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002bc6:	01050913          	addi	s2,a0,16
    80002bca:	854a                	mv	a0,s2
    80002bcc:	1cc010ef          	jal	80003d98 <holdingsleep>
    80002bd0:	c125                	beqz	a0,80002c30 <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    80002bd2:	854a                	mv	a0,s2
    80002bd4:	18c010ef          	jal	80003d60 <releasesleep>

  acquire(&bcache.lock);
    80002bd8:	00013517          	auipc	a0,0x13
    80002bdc:	ca050513          	addi	a0,a0,-864 # 80015878 <bcache>
    80002be0:	884fe0ef          	jal	80000c64 <acquire>
  b->refcnt--;
    80002be4:	40bc                	lw	a5,64(s1)
    80002be6:	37fd                	addiw	a5,a5,-1
    80002be8:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002bea:	e79d                	bnez	a5,80002c18 <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002bec:	68b8                	ld	a4,80(s1)
    80002bee:	64bc                	ld	a5,72(s1)
    80002bf0:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002bf2:	68b8                	ld	a4,80(s1)
    80002bf4:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002bf6:	0001b797          	auipc	a5,0x1b
    80002bfa:	c8278793          	addi	a5,a5,-894 # 8001d878 <bcache+0x8000>
    80002bfe:	2b87b703          	ld	a4,696(a5)
    80002c02:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002c04:	0001b717          	auipc	a4,0x1b
    80002c08:	edc70713          	addi	a4,a4,-292 # 8001dae0 <bcache+0x8268>
    80002c0c:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002c0e:	2b87b703          	ld	a4,696(a5)
    80002c12:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002c14:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    80002c18:	00013517          	auipc	a0,0x13
    80002c1c:	c6050513          	addi	a0,a0,-928 # 80015878 <bcache>
    80002c20:	8d4fe0ef          	jal	80000cf4 <release>
}
    80002c24:	60e2                	ld	ra,24(sp)
    80002c26:	6442                	ld	s0,16(sp)
    80002c28:	64a2                	ld	s1,8(sp)
    80002c2a:	6902                	ld	s2,0(sp)
    80002c2c:	6105                	addi	sp,sp,32
    80002c2e:	8082                	ret
    panic("brelse");
    80002c30:	00005517          	auipc	a0,0x5
    80002c34:	83050513          	addi	a0,a0,-2000 # 80007460 <etext+0x460>
    80002c38:	bb9fd0ef          	jal	800007f0 <panic>

0000000080002c3c <bpin>:

void
bpin(struct buf *b) {
    80002c3c:	1101                	addi	sp,sp,-32
    80002c3e:	ec06                	sd	ra,24(sp)
    80002c40:	e822                	sd	s0,16(sp)
    80002c42:	e426                	sd	s1,8(sp)
    80002c44:	1000                	addi	s0,sp,32
    80002c46:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002c48:	00013517          	auipc	a0,0x13
    80002c4c:	c3050513          	addi	a0,a0,-976 # 80015878 <bcache>
    80002c50:	814fe0ef          	jal	80000c64 <acquire>
  b->refcnt++;
    80002c54:	40bc                	lw	a5,64(s1)
    80002c56:	2785                	addiw	a5,a5,1
    80002c58:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002c5a:	00013517          	auipc	a0,0x13
    80002c5e:	c1e50513          	addi	a0,a0,-994 # 80015878 <bcache>
    80002c62:	892fe0ef          	jal	80000cf4 <release>
}
    80002c66:	60e2                	ld	ra,24(sp)
    80002c68:	6442                	ld	s0,16(sp)
    80002c6a:	64a2                	ld	s1,8(sp)
    80002c6c:	6105                	addi	sp,sp,32
    80002c6e:	8082                	ret

0000000080002c70 <bunpin>:

void
bunpin(struct buf *b) {
    80002c70:	1101                	addi	sp,sp,-32
    80002c72:	ec06                	sd	ra,24(sp)
    80002c74:	e822                	sd	s0,16(sp)
    80002c76:	e426                	sd	s1,8(sp)
    80002c78:	1000                	addi	s0,sp,32
    80002c7a:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002c7c:	00013517          	auipc	a0,0x13
    80002c80:	bfc50513          	addi	a0,a0,-1028 # 80015878 <bcache>
    80002c84:	fe1fd0ef          	jal	80000c64 <acquire>
  b->refcnt--;
    80002c88:	40bc                	lw	a5,64(s1)
    80002c8a:	37fd                	addiw	a5,a5,-1
    80002c8c:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002c8e:	00013517          	auipc	a0,0x13
    80002c92:	bea50513          	addi	a0,a0,-1046 # 80015878 <bcache>
    80002c96:	85efe0ef          	jal	80000cf4 <release>
}
    80002c9a:	60e2                	ld	ra,24(sp)
    80002c9c:	6442                	ld	s0,16(sp)
    80002c9e:	64a2                	ld	s1,8(sp)
    80002ca0:	6105                	addi	sp,sp,32
    80002ca2:	8082                	ret

0000000080002ca4 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002ca4:	1101                	addi	sp,sp,-32
    80002ca6:	ec06                	sd	ra,24(sp)
    80002ca8:	e822                	sd	s0,16(sp)
    80002caa:	e426                	sd	s1,8(sp)
    80002cac:	e04a                	sd	s2,0(sp)
    80002cae:	1000                	addi	s0,sp,32
    80002cb0:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002cb2:	00d5d79b          	srliw	a5,a1,0xd
    80002cb6:	0001b597          	auipc	a1,0x1b
    80002cba:	29e5a583          	lw	a1,670(a1) # 8001df54 <sb+0x1c>
    80002cbe:	9dbd                	addw	a1,a1,a5
    80002cc0:	df1ff0ef          	jal	80002ab0 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002cc4:	0074f713          	andi	a4,s1,7
    80002cc8:	4785                	li	a5,1
    80002cca:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    80002cce:	14ce                	slli	s1,s1,0x33
  if((bp->data[bi/8] & m) == 0)
    80002cd0:	90d9                	srli	s1,s1,0x36
    80002cd2:	00950733          	add	a4,a0,s1
    80002cd6:	05874703          	lbu	a4,88(a4)
    80002cda:	00e7f6b3          	and	a3,a5,a4
    80002cde:	c29d                	beqz	a3,80002d04 <bfree+0x60>
    80002ce0:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80002ce2:	94aa                	add	s1,s1,a0
    80002ce4:	fff7c793          	not	a5,a5
    80002ce8:	8f7d                	and	a4,a4,a5
    80002cea:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002cee:	729000ef          	jal	80003c16 <log_write>
  brelse(bp);
    80002cf2:	854a                	mv	a0,s2
    80002cf4:	ec5ff0ef          	jal	80002bb8 <brelse>
}
    80002cf8:	60e2                	ld	ra,24(sp)
    80002cfa:	6442                	ld	s0,16(sp)
    80002cfc:	64a2                	ld	s1,8(sp)
    80002cfe:	6902                	ld	s2,0(sp)
    80002d00:	6105                	addi	sp,sp,32
    80002d02:	8082                	ret
    panic("freeing free block");
    80002d04:	00004517          	auipc	a0,0x4
    80002d08:	76450513          	addi	a0,a0,1892 # 80007468 <etext+0x468>
    80002d0c:	ae5fd0ef          	jal	800007f0 <panic>

0000000080002d10 <balloc>:
{
    80002d10:	715d                	addi	sp,sp,-80
    80002d12:	e486                	sd	ra,72(sp)
    80002d14:	e0a2                	sd	s0,64(sp)
    80002d16:	fc26                	sd	s1,56(sp)
    80002d18:	0880                	addi	s0,sp,80
  for(b = 0; b < sb.size; b += BPB){
    80002d1a:	0001b797          	auipc	a5,0x1b
    80002d1e:	2227a783          	lw	a5,546(a5) # 8001df3c <sb+0x4>
    80002d22:	0e078263          	beqz	a5,80002e06 <balloc+0xf6>
    80002d26:	f84a                	sd	s2,48(sp)
    80002d28:	f44e                	sd	s3,40(sp)
    80002d2a:	f052                	sd	s4,32(sp)
    80002d2c:	ec56                	sd	s5,24(sp)
    80002d2e:	e85a                	sd	s6,16(sp)
    80002d30:	e45e                	sd	s7,8(sp)
    80002d32:	e062                	sd	s8,0(sp)
    80002d34:	8baa                	mv	s7,a0
    80002d36:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002d38:	0001bb17          	auipc	s6,0x1b
    80002d3c:	200b0b13          	addi	s6,s6,512 # 8001df38 <sb>
      m = 1 << (bi % 8);
    80002d40:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002d42:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80002d44:	6c09                	lui	s8,0x2
    80002d46:	a09d                	j	80002dac <balloc+0x9c>
        bp->data[bi/8] |= m;  // Mark block in use.
    80002d48:	97ca                	add	a5,a5,s2
    80002d4a:	8e55                	or	a2,a2,a3
    80002d4c:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80002d50:	854a                	mv	a0,s2
    80002d52:	6c5000ef          	jal	80003c16 <log_write>
        brelse(bp);
    80002d56:	854a                	mv	a0,s2
    80002d58:	e61ff0ef          	jal	80002bb8 <brelse>
  bp = bread(dev, bno);
    80002d5c:	85a6                	mv	a1,s1
    80002d5e:	855e                	mv	a0,s7
    80002d60:	d51ff0ef          	jal	80002ab0 <bread>
    80002d64:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002d66:	40000613          	li	a2,1024
    80002d6a:	4581                	li	a1,0
    80002d6c:	05850513          	addi	a0,a0,88
    80002d70:	fc1fd0ef          	jal	80000d30 <memset>
  log_write(bp);
    80002d74:	854a                	mv	a0,s2
    80002d76:	6a1000ef          	jal	80003c16 <log_write>
  brelse(bp);
    80002d7a:	854a                	mv	a0,s2
    80002d7c:	e3dff0ef          	jal	80002bb8 <brelse>
        return b + bi;
    80002d80:	7942                	ld	s2,48(sp)
    80002d82:	79a2                	ld	s3,40(sp)
    80002d84:	7a02                	ld	s4,32(sp)
    80002d86:	6ae2                	ld	s5,24(sp)
    80002d88:	6b42                	ld	s6,16(sp)
    80002d8a:	6ba2                	ld	s7,8(sp)
    80002d8c:	6c02                	ld	s8,0(sp)
}
    80002d8e:	8526                	mv	a0,s1
    80002d90:	60a6                	ld	ra,72(sp)
    80002d92:	6406                	ld	s0,64(sp)
    80002d94:	74e2                	ld	s1,56(sp)
    80002d96:	6161                	addi	sp,sp,80
    80002d98:	8082                	ret
    brelse(bp);
    80002d9a:	854a                	mv	a0,s2
    80002d9c:	e1dff0ef          	jal	80002bb8 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002da0:	015c0abb          	addw	s5,s8,s5
    80002da4:	004b2783          	lw	a5,4(s6)
    80002da8:	04faf863          	bgeu	s5,a5,80002df8 <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    80002dac:	40dad59b          	sraiw	a1,s5,0xd
    80002db0:	01cb2783          	lw	a5,28(s6)
    80002db4:	9dbd                	addw	a1,a1,a5
    80002db6:	855e                	mv	a0,s7
    80002db8:	cf9ff0ef          	jal	80002ab0 <bread>
    80002dbc:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002dbe:	004b2503          	lw	a0,4(s6)
    80002dc2:	84d6                	mv	s1,s5
    80002dc4:	4701                	li	a4,0
    80002dc6:	fca4fae3          	bgeu	s1,a0,80002d9a <balloc+0x8a>
      m = 1 << (bi % 8);
    80002dca:	00777693          	andi	a3,a4,7
    80002dce:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80002dd2:	41f7579b          	sraiw	a5,a4,0x1f
    80002dd6:	01d7d79b          	srliw	a5,a5,0x1d
    80002dda:	9fb9                	addw	a5,a5,a4
    80002ddc:	4037d79b          	sraiw	a5,a5,0x3
    80002de0:	00f90633          	add	a2,s2,a5
    80002de4:	05864603          	lbu	a2,88(a2)
    80002de8:	00c6f5b3          	and	a1,a3,a2
    80002dec:	ddb1                	beqz	a1,80002d48 <balloc+0x38>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002dee:	2705                	addiw	a4,a4,1
    80002df0:	2485                	addiw	s1,s1,1
    80002df2:	fd471ae3          	bne	a4,s4,80002dc6 <balloc+0xb6>
    80002df6:	b755                	j	80002d9a <balloc+0x8a>
    80002df8:	7942                	ld	s2,48(sp)
    80002dfa:	79a2                	ld	s3,40(sp)
    80002dfc:	7a02                	ld	s4,32(sp)
    80002dfe:	6ae2                	ld	s5,24(sp)
    80002e00:	6b42                	ld	s6,16(sp)
    80002e02:	6ba2                	ld	s7,8(sp)
    80002e04:	6c02                	ld	s8,0(sp)
  printf("balloc: out of blocks\n");
    80002e06:	00004517          	auipc	a0,0x4
    80002e0a:	67a50513          	addi	a0,a0,1658 # 80007480 <etext+0x480>
    80002e0e:	ec4fd0ef          	jal	800004d2 <printf>
  return 0;
    80002e12:	4481                	li	s1,0
    80002e14:	bfad                	j	80002d8e <balloc+0x7e>

0000000080002e16 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80002e16:	7179                	addi	sp,sp,-48
    80002e18:	f406                	sd	ra,40(sp)
    80002e1a:	f022                	sd	s0,32(sp)
    80002e1c:	ec26                	sd	s1,24(sp)
    80002e1e:	e84a                	sd	s2,16(sp)
    80002e20:	e44e                	sd	s3,8(sp)
    80002e22:	1800                	addi	s0,sp,48
    80002e24:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    80002e26:	47ad                	li	a5,11
    80002e28:	02b7e363          	bltu	a5,a1,80002e4e <bmap+0x38>
    if((addr = ip->addrs[bn]) == 0){
    80002e2c:	02059793          	slli	a5,a1,0x20
    80002e30:	01e7d593          	srli	a1,a5,0x1e
    80002e34:	00b509b3          	add	s3,a0,a1
    80002e38:	0509a483          	lw	s1,80(s3)
    80002e3c:	e0b5                	bnez	s1,80002ea0 <bmap+0x8a>
      addr = balloc(ip->dev);
    80002e3e:	4108                	lw	a0,0(a0)
    80002e40:	ed1ff0ef          	jal	80002d10 <balloc>
    80002e44:	84aa                	mv	s1,a0
      if(addr == 0)
    80002e46:	cd29                	beqz	a0,80002ea0 <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    80002e48:	04a9a823          	sw	a0,80(s3)
    80002e4c:	a891                	j	80002ea0 <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80002e4e:	ff45879b          	addiw	a5,a1,-12
    80002e52:	873e                	mv	a4,a5
    80002e54:	89be                	mv	s3,a5

  if(bn < NINDIRECT){
    80002e56:	0ff00793          	li	a5,255
    80002e5a:	06e7e763          	bltu	a5,a4,80002ec8 <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    80002e5e:	08052483          	lw	s1,128(a0)
    80002e62:	e891                	bnez	s1,80002e76 <bmap+0x60>
      addr = balloc(ip->dev);
    80002e64:	4108                	lw	a0,0(a0)
    80002e66:	eabff0ef          	jal	80002d10 <balloc>
    80002e6a:	84aa                	mv	s1,a0
      if(addr == 0)
    80002e6c:	c915                	beqz	a0,80002ea0 <bmap+0x8a>
    80002e6e:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002e70:	08a92023          	sw	a0,128(s2)
    80002e74:	a011                	j	80002e78 <bmap+0x62>
    80002e76:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80002e78:	85a6                	mv	a1,s1
    80002e7a:	00092503          	lw	a0,0(s2)
    80002e7e:	c33ff0ef          	jal	80002ab0 <bread>
    80002e82:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80002e84:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80002e88:	02099713          	slli	a4,s3,0x20
    80002e8c:	01e75593          	srli	a1,a4,0x1e
    80002e90:	97ae                	add	a5,a5,a1
    80002e92:	89be                	mv	s3,a5
    80002e94:	4384                	lw	s1,0(a5)
    80002e96:	cc89                	beqz	s1,80002eb0 <bmap+0x9a>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80002e98:	8552                	mv	a0,s4
    80002e9a:	d1fff0ef          	jal	80002bb8 <brelse>
    return addr;
    80002e9e:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80002ea0:	8526                	mv	a0,s1
    80002ea2:	70a2                	ld	ra,40(sp)
    80002ea4:	7402                	ld	s0,32(sp)
    80002ea6:	64e2                	ld	s1,24(sp)
    80002ea8:	6942                	ld	s2,16(sp)
    80002eaa:	69a2                	ld	s3,8(sp)
    80002eac:	6145                	addi	sp,sp,48
    80002eae:	8082                	ret
      addr = balloc(ip->dev);
    80002eb0:	00092503          	lw	a0,0(s2)
    80002eb4:	e5dff0ef          	jal	80002d10 <balloc>
    80002eb8:	84aa                	mv	s1,a0
      if(addr){
    80002eba:	dd79                	beqz	a0,80002e98 <bmap+0x82>
        a[bn] = addr;
    80002ebc:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    80002ec0:	8552                	mv	a0,s4
    80002ec2:	555000ef          	jal	80003c16 <log_write>
    80002ec6:	bfc9                	j	80002e98 <bmap+0x82>
    80002ec8:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    80002eca:	00004517          	auipc	a0,0x4
    80002ece:	5ce50513          	addi	a0,a0,1486 # 80007498 <etext+0x498>
    80002ed2:	91ffd0ef          	jal	800007f0 <panic>

0000000080002ed6 <iget>:
{
    80002ed6:	7179                	addi	sp,sp,-48
    80002ed8:	f406                	sd	ra,40(sp)
    80002eda:	f022                	sd	s0,32(sp)
    80002edc:	ec26                	sd	s1,24(sp)
    80002ede:	e84a                	sd	s2,16(sp)
    80002ee0:	e44e                	sd	s3,8(sp)
    80002ee2:	e052                	sd	s4,0(sp)
    80002ee4:	1800                	addi	s0,sp,48
    80002ee6:	89aa                	mv	s3,a0
    80002ee8:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80002eea:	0001b517          	auipc	a0,0x1b
    80002eee:	06e50513          	addi	a0,a0,110 # 8001df58 <itable>
    80002ef2:	d73fd0ef          	jal	80000c64 <acquire>
  empty = 0;
    80002ef6:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80002ef8:	0001b497          	auipc	s1,0x1b
    80002efc:	07848493          	addi	s1,s1,120 # 8001df70 <itable+0x18>
    80002f00:	0001d697          	auipc	a3,0x1d
    80002f04:	b0068693          	addi	a3,a3,-1280 # 8001fa00 <log>
    80002f08:	a819                	j	80002f1e <iget+0x48>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80002f0a:	0017b793          	seqz	a5,a5
    80002f0e:	00193713          	seqz	a4,s2
    80002f12:	8ff9                	and	a5,a5,a4
    80002f14:	eb85                	bnez	a5,80002f44 <iget+0x6e>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80002f16:	08848493          	addi	s1,s1,136
    80002f1a:	02d48763          	beq	s1,a3,80002f48 <iget+0x72>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    80002f1e:	449c                	lw	a5,8(s1)
    80002f20:	fef055e3          	blez	a5,80002f0a <iget+0x34>
    80002f24:	4098                	lw	a4,0(s1)
    80002f26:	ff3718e3          	bne	a4,s3,80002f16 <iget+0x40>
    80002f2a:	40d8                	lw	a4,4(s1)
    80002f2c:	ff4715e3          	bne	a4,s4,80002f16 <iget+0x40>
      ip->ref++;
    80002f30:	2785                	addiw	a5,a5,1
    80002f32:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80002f34:	0001b517          	auipc	a0,0x1b
    80002f38:	02450513          	addi	a0,a0,36 # 8001df58 <itable>
    80002f3c:	db9fd0ef          	jal	80000cf4 <release>
      return ip;
    80002f40:	8926                	mv	s2,s1
    80002f42:	a025                	j	80002f6a <iget+0x94>
      empty = ip;
    80002f44:	8926                	mv	s2,s1
    80002f46:	bfc1                	j	80002f16 <iget+0x40>
  if(empty == 0)
    80002f48:	02090a63          	beqz	s2,80002f7c <iget+0xa6>
  ip->dev = dev;
    80002f4c:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    80002f50:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    80002f54:	4785                	li	a5,1
    80002f56:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    80002f5a:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    80002f5e:	0001b517          	auipc	a0,0x1b
    80002f62:	ffa50513          	addi	a0,a0,-6 # 8001df58 <itable>
    80002f66:	d8ffd0ef          	jal	80000cf4 <release>
}
    80002f6a:	854a                	mv	a0,s2
    80002f6c:	70a2                	ld	ra,40(sp)
    80002f6e:	7402                	ld	s0,32(sp)
    80002f70:	64e2                	ld	s1,24(sp)
    80002f72:	6942                	ld	s2,16(sp)
    80002f74:	69a2                	ld	s3,8(sp)
    80002f76:	6a02                	ld	s4,0(sp)
    80002f78:	6145                	addi	sp,sp,48
    80002f7a:	8082                	ret
    panic("iget: no inodes");
    80002f7c:	00004517          	auipc	a0,0x4
    80002f80:	53450513          	addi	a0,a0,1332 # 800074b0 <etext+0x4b0>
    80002f84:	86dfd0ef          	jal	800007f0 <panic>

0000000080002f88 <fsinit>:
fsinit(int dev) {
    80002f88:	1101                	addi	sp,sp,-32
    80002f8a:	ec06                	sd	ra,24(sp)
    80002f8c:	e822                	sd	s0,16(sp)
    80002f8e:	e426                	sd	s1,8(sp)
    80002f90:	e04a                	sd	s2,0(sp)
    80002f92:	1000                	addi	s0,sp,32
    80002f94:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80002f96:	4585                	li	a1,1
    80002f98:	b19ff0ef          	jal	80002ab0 <bread>
    80002f9c:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80002f9e:	02000613          	li	a2,32
    80002fa2:	05850593          	addi	a1,a0,88
    80002fa6:	0001b517          	auipc	a0,0x1b
    80002faa:	f9250513          	addi	a0,a0,-110 # 8001df38 <sb>
    80002fae:	ddffd0ef          	jal	80000d8c <memmove>
  brelse(bp);
    80002fb2:	8526                	mv	a0,s1
    80002fb4:	c05ff0ef          	jal	80002bb8 <brelse>
  if(sb.magic != FSMAGIC)
    80002fb8:	0001b717          	auipc	a4,0x1b
    80002fbc:	f8072703          	lw	a4,-128(a4) # 8001df38 <sb>
    80002fc0:	102037b7          	lui	a5,0x10203
    80002fc4:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80002fc8:	00f71f63          	bne	a4,a5,80002fe6 <fsinit+0x5e>
  initlog(dev, &sb);
    80002fcc:	0001b597          	auipc	a1,0x1b
    80002fd0:	f6c58593          	addi	a1,a1,-148 # 8001df38 <sb>
    80002fd4:	854a                	mv	a0,s2
    80002fd6:	223000ef          	jal	800039f8 <initlog>
}
    80002fda:	60e2                	ld	ra,24(sp)
    80002fdc:	6442                	ld	s0,16(sp)
    80002fde:	64a2                	ld	s1,8(sp)
    80002fe0:	6902                	ld	s2,0(sp)
    80002fe2:	6105                	addi	sp,sp,32
    80002fe4:	8082                	ret
    panic("invalid file system");
    80002fe6:	00004517          	auipc	a0,0x4
    80002fea:	4da50513          	addi	a0,a0,1242 # 800074c0 <etext+0x4c0>
    80002fee:	803fd0ef          	jal	800007f0 <panic>

0000000080002ff2 <iinit>:
{
    80002ff2:	7179                	addi	sp,sp,-48
    80002ff4:	f406                	sd	ra,40(sp)
    80002ff6:	f022                	sd	s0,32(sp)
    80002ff8:	ec26                	sd	s1,24(sp)
    80002ffa:	e84a                	sd	s2,16(sp)
    80002ffc:	e44e                	sd	s3,8(sp)
    80002ffe:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80003000:	00004597          	auipc	a1,0x4
    80003004:	4d858593          	addi	a1,a1,1240 # 800074d8 <etext+0x4d8>
    80003008:	0001b517          	auipc	a0,0x1b
    8000300c:	f5050513          	addi	a0,a0,-176 # 8001df58 <itable>
    80003010:	bcbfd0ef          	jal	80000bda <initlock>
  for(i = 0; i < NINODE; i++) {
    80003014:	0001b497          	auipc	s1,0x1b
    80003018:	f6c48493          	addi	s1,s1,-148 # 8001df80 <itable+0x28>
    8000301c:	0001d997          	auipc	s3,0x1d
    80003020:	9f498993          	addi	s3,s3,-1548 # 8001fa10 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    80003024:	00004917          	auipc	s2,0x4
    80003028:	4bc90913          	addi	s2,s2,1212 # 800074e0 <etext+0x4e0>
    8000302c:	85ca                	mv	a1,s2
    8000302e:	8526                	mv	a0,s1
    80003030:	4b5000ef          	jal	80003ce4 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    80003034:	08848493          	addi	s1,s1,136
    80003038:	ff349ae3          	bne	s1,s3,8000302c <iinit+0x3a>
}
    8000303c:	70a2                	ld	ra,40(sp)
    8000303e:	7402                	ld	s0,32(sp)
    80003040:	64e2                	ld	s1,24(sp)
    80003042:	6942                	ld	s2,16(sp)
    80003044:	69a2                	ld	s3,8(sp)
    80003046:	6145                	addi	sp,sp,48
    80003048:	8082                	ret

000000008000304a <ialloc>:
{
    8000304a:	7139                	addi	sp,sp,-64
    8000304c:	fc06                	sd	ra,56(sp)
    8000304e:	f822                	sd	s0,48(sp)
    80003050:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    80003052:	0001b717          	auipc	a4,0x1b
    80003056:	ef272703          	lw	a4,-270(a4) # 8001df44 <sb+0xc>
    8000305a:	4785                	li	a5,1
    8000305c:	06e7f063          	bgeu	a5,a4,800030bc <ialloc+0x72>
    80003060:	f426                	sd	s1,40(sp)
    80003062:	f04a                	sd	s2,32(sp)
    80003064:	ec4e                	sd	s3,24(sp)
    80003066:	e852                	sd	s4,16(sp)
    80003068:	e456                	sd	s5,8(sp)
    8000306a:	e05a                	sd	s6,0(sp)
    8000306c:	8aaa                	mv	s5,a0
    8000306e:	8b2e                	mv	s6,a1
    80003070:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    80003072:	0001ba17          	auipc	s4,0x1b
    80003076:	ec6a0a13          	addi	s4,s4,-314 # 8001df38 <sb>
    8000307a:	00495593          	srli	a1,s2,0x4
    8000307e:	018a2783          	lw	a5,24(s4)
    80003082:	9dbd                	addw	a1,a1,a5
    80003084:	8556                	mv	a0,s5
    80003086:	a2bff0ef          	jal	80002ab0 <bread>
    8000308a:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    8000308c:	05850993          	addi	s3,a0,88
    80003090:	00f97793          	andi	a5,s2,15
    80003094:	079a                	slli	a5,a5,0x6
    80003096:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    80003098:	00099783          	lh	a5,0(s3)
    8000309c:	cb9d                	beqz	a5,800030d2 <ialloc+0x88>
    brelse(bp);
    8000309e:	b1bff0ef          	jal	80002bb8 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    800030a2:	0905                	addi	s2,s2,1
    800030a4:	00ca2703          	lw	a4,12(s4)
    800030a8:	0009079b          	sext.w	a5,s2
    800030ac:	fce7e7e3          	bltu	a5,a4,8000307a <ialloc+0x30>
    800030b0:	74a2                	ld	s1,40(sp)
    800030b2:	7902                	ld	s2,32(sp)
    800030b4:	69e2                	ld	s3,24(sp)
    800030b6:	6a42                	ld	s4,16(sp)
    800030b8:	6aa2                	ld	s5,8(sp)
    800030ba:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    800030bc:	00004517          	auipc	a0,0x4
    800030c0:	42c50513          	addi	a0,a0,1068 # 800074e8 <etext+0x4e8>
    800030c4:	c0efd0ef          	jal	800004d2 <printf>
  return 0;
    800030c8:	4501                	li	a0,0
}
    800030ca:	70e2                	ld	ra,56(sp)
    800030cc:	7442                	ld	s0,48(sp)
    800030ce:	6121                	addi	sp,sp,64
    800030d0:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    800030d2:	04000613          	li	a2,64
    800030d6:	4581                	li	a1,0
    800030d8:	854e                	mv	a0,s3
    800030da:	c57fd0ef          	jal	80000d30 <memset>
      dip->type = type;
    800030de:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    800030e2:	8526                	mv	a0,s1
    800030e4:	333000ef          	jal	80003c16 <log_write>
      brelse(bp);
    800030e8:	8526                	mv	a0,s1
    800030ea:	acfff0ef          	jal	80002bb8 <brelse>
      return iget(dev, inum);
    800030ee:	0009059b          	sext.w	a1,s2
    800030f2:	8556                	mv	a0,s5
    800030f4:	de3ff0ef          	jal	80002ed6 <iget>
    800030f8:	74a2                	ld	s1,40(sp)
    800030fa:	7902                	ld	s2,32(sp)
    800030fc:	69e2                	ld	s3,24(sp)
    800030fe:	6a42                	ld	s4,16(sp)
    80003100:	6aa2                	ld	s5,8(sp)
    80003102:	6b02                	ld	s6,0(sp)
    80003104:	b7d9                	j	800030ca <ialloc+0x80>

0000000080003106 <iupdate>:
{
    80003106:	1101                	addi	sp,sp,-32
    80003108:	ec06                	sd	ra,24(sp)
    8000310a:	e822                	sd	s0,16(sp)
    8000310c:	e426                	sd	s1,8(sp)
    8000310e:	e04a                	sd	s2,0(sp)
    80003110:	1000                	addi	s0,sp,32
    80003112:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003114:	415c                	lw	a5,4(a0)
    80003116:	0047d79b          	srliw	a5,a5,0x4
    8000311a:	0001b597          	auipc	a1,0x1b
    8000311e:	e365a583          	lw	a1,-458(a1) # 8001df50 <sb+0x18>
    80003122:	9dbd                	addw	a1,a1,a5
    80003124:	4108                	lw	a0,0(a0)
    80003126:	98bff0ef          	jal	80002ab0 <bread>
    8000312a:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000312c:	05850793          	addi	a5,a0,88
    80003130:	40d8                	lw	a4,4(s1)
    80003132:	8b3d                	andi	a4,a4,15
    80003134:	071a                	slli	a4,a4,0x6
    80003136:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80003138:	04449703          	lh	a4,68(s1)
    8000313c:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    80003140:	04649703          	lh	a4,70(s1)
    80003144:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80003148:	04849703          	lh	a4,72(s1)
    8000314c:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    80003150:	04a49703          	lh	a4,74(s1)
    80003154:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80003158:	44f8                	lw	a4,76(s1)
    8000315a:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    8000315c:	03400613          	li	a2,52
    80003160:	05048593          	addi	a1,s1,80
    80003164:	00c78513          	addi	a0,a5,12
    80003168:	c25fd0ef          	jal	80000d8c <memmove>
  log_write(bp);
    8000316c:	854a                	mv	a0,s2
    8000316e:	2a9000ef          	jal	80003c16 <log_write>
  brelse(bp);
    80003172:	854a                	mv	a0,s2
    80003174:	a45ff0ef          	jal	80002bb8 <brelse>
}
    80003178:	60e2                	ld	ra,24(sp)
    8000317a:	6442                	ld	s0,16(sp)
    8000317c:	64a2                	ld	s1,8(sp)
    8000317e:	6902                	ld	s2,0(sp)
    80003180:	6105                	addi	sp,sp,32
    80003182:	8082                	ret

0000000080003184 <idup>:
{
    80003184:	1101                	addi	sp,sp,-32
    80003186:	ec06                	sd	ra,24(sp)
    80003188:	e822                	sd	s0,16(sp)
    8000318a:	e426                	sd	s1,8(sp)
    8000318c:	1000                	addi	s0,sp,32
    8000318e:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003190:	0001b517          	auipc	a0,0x1b
    80003194:	dc850513          	addi	a0,a0,-568 # 8001df58 <itable>
    80003198:	acdfd0ef          	jal	80000c64 <acquire>
  ip->ref++;
    8000319c:	449c                	lw	a5,8(s1)
    8000319e:	2785                	addiw	a5,a5,1
    800031a0:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800031a2:	0001b517          	auipc	a0,0x1b
    800031a6:	db650513          	addi	a0,a0,-586 # 8001df58 <itable>
    800031aa:	b4bfd0ef          	jal	80000cf4 <release>
}
    800031ae:	8526                	mv	a0,s1
    800031b0:	60e2                	ld	ra,24(sp)
    800031b2:	6442                	ld	s0,16(sp)
    800031b4:	64a2                	ld	s1,8(sp)
    800031b6:	6105                	addi	sp,sp,32
    800031b8:	8082                	ret

00000000800031ba <ilock>:
{
    800031ba:	1101                	addi	sp,sp,-32
    800031bc:	ec06                	sd	ra,24(sp)
    800031be:	e822                	sd	s0,16(sp)
    800031c0:	e426                	sd	s1,8(sp)
    800031c2:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    800031c4:	cd19                	beqz	a0,800031e2 <ilock+0x28>
    800031c6:	84aa                	mv	s1,a0
    800031c8:	451c                	lw	a5,8(a0)
    800031ca:	00f05c63          	blez	a5,800031e2 <ilock+0x28>
  acquiresleep(&ip->lock);
    800031ce:	0541                	addi	a0,a0,16
    800031d0:	34b000ef          	jal	80003d1a <acquiresleep>
  if(ip->valid == 0){
    800031d4:	40bc                	lw	a5,64(s1)
    800031d6:	cf89                	beqz	a5,800031f0 <ilock+0x36>
}
    800031d8:	60e2                	ld	ra,24(sp)
    800031da:	6442                	ld	s0,16(sp)
    800031dc:	64a2                	ld	s1,8(sp)
    800031de:	6105                	addi	sp,sp,32
    800031e0:	8082                	ret
    800031e2:	e04a                	sd	s2,0(sp)
    panic("ilock");
    800031e4:	00004517          	auipc	a0,0x4
    800031e8:	31c50513          	addi	a0,a0,796 # 80007500 <etext+0x500>
    800031ec:	e04fd0ef          	jal	800007f0 <panic>
    800031f0:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800031f2:	40dc                	lw	a5,4(s1)
    800031f4:	0047d79b          	srliw	a5,a5,0x4
    800031f8:	0001b597          	auipc	a1,0x1b
    800031fc:	d585a583          	lw	a1,-680(a1) # 8001df50 <sb+0x18>
    80003200:	9dbd                	addw	a1,a1,a5
    80003202:	4088                	lw	a0,0(s1)
    80003204:	8adff0ef          	jal	80002ab0 <bread>
    80003208:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000320a:	05850593          	addi	a1,a0,88
    8000320e:	40dc                	lw	a5,4(s1)
    80003210:	8bbd                	andi	a5,a5,15
    80003212:	079a                	slli	a5,a5,0x6
    80003214:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80003216:	00059783          	lh	a5,0(a1)
    8000321a:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    8000321e:	00259783          	lh	a5,2(a1)
    80003222:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80003226:	00459783          	lh	a5,4(a1)
    8000322a:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    8000322e:	00659783          	lh	a5,6(a1)
    80003232:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80003236:	459c                	lw	a5,8(a1)
    80003238:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    8000323a:	03400613          	li	a2,52
    8000323e:	05b1                	addi	a1,a1,12
    80003240:	05048513          	addi	a0,s1,80
    80003244:	b49fd0ef          	jal	80000d8c <memmove>
    brelse(bp);
    80003248:	854a                	mv	a0,s2
    8000324a:	96fff0ef          	jal	80002bb8 <brelse>
    ip->valid = 1;
    8000324e:	4785                	li	a5,1
    80003250:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    80003252:	04449783          	lh	a5,68(s1)
    80003256:	c399                	beqz	a5,8000325c <ilock+0xa2>
    80003258:	6902                	ld	s2,0(sp)
    8000325a:	bfbd                	j	800031d8 <ilock+0x1e>
      panic("ilock: no type");
    8000325c:	00004517          	auipc	a0,0x4
    80003260:	2ac50513          	addi	a0,a0,684 # 80007508 <etext+0x508>
    80003264:	d8cfd0ef          	jal	800007f0 <panic>

0000000080003268 <iunlock>:
{
    80003268:	1101                	addi	sp,sp,-32
    8000326a:	ec06                	sd	ra,24(sp)
    8000326c:	e822                	sd	s0,16(sp)
    8000326e:	e426                	sd	s1,8(sp)
    80003270:	e04a                	sd	s2,0(sp)
    80003272:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80003274:	c505                	beqz	a0,8000329c <iunlock+0x34>
    80003276:	84aa                	mv	s1,a0
    80003278:	01050913          	addi	s2,a0,16
    8000327c:	854a                	mv	a0,s2
    8000327e:	31b000ef          	jal	80003d98 <holdingsleep>
    80003282:	cd09                	beqz	a0,8000329c <iunlock+0x34>
    80003284:	449c                	lw	a5,8(s1)
    80003286:	00f05b63          	blez	a5,8000329c <iunlock+0x34>
  releasesleep(&ip->lock);
    8000328a:	854a                	mv	a0,s2
    8000328c:	2d5000ef          	jal	80003d60 <releasesleep>
}
    80003290:	60e2                	ld	ra,24(sp)
    80003292:	6442                	ld	s0,16(sp)
    80003294:	64a2                	ld	s1,8(sp)
    80003296:	6902                	ld	s2,0(sp)
    80003298:	6105                	addi	sp,sp,32
    8000329a:	8082                	ret
    panic("iunlock");
    8000329c:	00004517          	auipc	a0,0x4
    800032a0:	27c50513          	addi	a0,a0,636 # 80007518 <etext+0x518>
    800032a4:	d4cfd0ef          	jal	800007f0 <panic>

00000000800032a8 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    800032a8:	7179                	addi	sp,sp,-48
    800032aa:	f406                	sd	ra,40(sp)
    800032ac:	f022                	sd	s0,32(sp)
    800032ae:	ec26                	sd	s1,24(sp)
    800032b0:	e84a                	sd	s2,16(sp)
    800032b2:	e44e                	sd	s3,8(sp)
    800032b4:	1800                	addi	s0,sp,48
    800032b6:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    800032b8:	05050493          	addi	s1,a0,80
    800032bc:	08050913          	addi	s2,a0,128
    800032c0:	a021                	j	800032c8 <itrunc+0x20>
    800032c2:	0491                	addi	s1,s1,4
    800032c4:	01248b63          	beq	s1,s2,800032da <itrunc+0x32>
    if(ip->addrs[i]){
    800032c8:	408c                	lw	a1,0(s1)
    800032ca:	dde5                	beqz	a1,800032c2 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    800032cc:	0009a503          	lw	a0,0(s3)
    800032d0:	9d5ff0ef          	jal	80002ca4 <bfree>
      ip->addrs[i] = 0;
    800032d4:	0004a023          	sw	zero,0(s1)
    800032d8:	b7ed                	j	800032c2 <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    800032da:	0809a583          	lw	a1,128(s3)
    800032de:	ed89                	bnez	a1,800032f8 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    800032e0:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    800032e4:	854e                	mv	a0,s3
    800032e6:	e21ff0ef          	jal	80003106 <iupdate>
}
    800032ea:	70a2                	ld	ra,40(sp)
    800032ec:	7402                	ld	s0,32(sp)
    800032ee:	64e2                	ld	s1,24(sp)
    800032f0:	6942                	ld	s2,16(sp)
    800032f2:	69a2                	ld	s3,8(sp)
    800032f4:	6145                	addi	sp,sp,48
    800032f6:	8082                	ret
    800032f8:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    800032fa:	0009a503          	lw	a0,0(s3)
    800032fe:	fb2ff0ef          	jal	80002ab0 <bread>
    80003302:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80003304:	05850493          	addi	s1,a0,88
    80003308:	45850913          	addi	s2,a0,1112
    8000330c:	a021                	j	80003314 <itrunc+0x6c>
    8000330e:	0491                	addi	s1,s1,4
    80003310:	01248963          	beq	s1,s2,80003322 <itrunc+0x7a>
      if(a[j])
    80003314:	408c                	lw	a1,0(s1)
    80003316:	dde5                	beqz	a1,8000330e <itrunc+0x66>
        bfree(ip->dev, a[j]);
    80003318:	0009a503          	lw	a0,0(s3)
    8000331c:	989ff0ef          	jal	80002ca4 <bfree>
    80003320:	b7fd                	j	8000330e <itrunc+0x66>
    brelse(bp);
    80003322:	8552                	mv	a0,s4
    80003324:	895ff0ef          	jal	80002bb8 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80003328:	0809a583          	lw	a1,128(s3)
    8000332c:	0009a503          	lw	a0,0(s3)
    80003330:	975ff0ef          	jal	80002ca4 <bfree>
    ip->addrs[NDIRECT] = 0;
    80003334:	0809a023          	sw	zero,128(s3)
    80003338:	6a02                	ld	s4,0(sp)
    8000333a:	b75d                	j	800032e0 <itrunc+0x38>

000000008000333c <iput>:
{
    8000333c:	1101                	addi	sp,sp,-32
    8000333e:	ec06                	sd	ra,24(sp)
    80003340:	e822                	sd	s0,16(sp)
    80003342:	e426                	sd	s1,8(sp)
    80003344:	1000                	addi	s0,sp,32
    80003346:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003348:	0001b517          	auipc	a0,0x1b
    8000334c:	c1050513          	addi	a0,a0,-1008 # 8001df58 <itable>
    80003350:	915fd0ef          	jal	80000c64 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003354:	4498                	lw	a4,8(s1)
    80003356:	4785                	li	a5,1
    80003358:	02f70063          	beq	a4,a5,80003378 <iput+0x3c>
  ip->ref--;
    8000335c:	449c                	lw	a5,8(s1)
    8000335e:	37fd                	addiw	a5,a5,-1
    80003360:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003362:	0001b517          	auipc	a0,0x1b
    80003366:	bf650513          	addi	a0,a0,-1034 # 8001df58 <itable>
    8000336a:	98bfd0ef          	jal	80000cf4 <release>
}
    8000336e:	60e2                	ld	ra,24(sp)
    80003370:	6442                	ld	s0,16(sp)
    80003372:	64a2                	ld	s1,8(sp)
    80003374:	6105                	addi	sp,sp,32
    80003376:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003378:	40bc                	lw	a5,64(s1)
    8000337a:	d3ed                	beqz	a5,8000335c <iput+0x20>
    8000337c:	04a49783          	lh	a5,74(s1)
    80003380:	fff1                	bnez	a5,8000335c <iput+0x20>
    80003382:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    80003384:	01048793          	addi	a5,s1,16
    80003388:	893e                	mv	s2,a5
    8000338a:	853e                	mv	a0,a5
    8000338c:	18f000ef          	jal	80003d1a <acquiresleep>
    release(&itable.lock);
    80003390:	0001b517          	auipc	a0,0x1b
    80003394:	bc850513          	addi	a0,a0,-1080 # 8001df58 <itable>
    80003398:	95dfd0ef          	jal	80000cf4 <release>
    itrunc(ip);
    8000339c:	8526                	mv	a0,s1
    8000339e:	f0bff0ef          	jal	800032a8 <itrunc>
    ip->type = 0;
    800033a2:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    800033a6:	8526                	mv	a0,s1
    800033a8:	d5fff0ef          	jal	80003106 <iupdate>
    ip->valid = 0;
    800033ac:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    800033b0:	854a                	mv	a0,s2
    800033b2:	1af000ef          	jal	80003d60 <releasesleep>
    acquire(&itable.lock);
    800033b6:	0001b517          	auipc	a0,0x1b
    800033ba:	ba250513          	addi	a0,a0,-1118 # 8001df58 <itable>
    800033be:	8a7fd0ef          	jal	80000c64 <acquire>
    800033c2:	6902                	ld	s2,0(sp)
    800033c4:	bf61                	j	8000335c <iput+0x20>

00000000800033c6 <iunlockput>:
{
    800033c6:	1101                	addi	sp,sp,-32
    800033c8:	ec06                	sd	ra,24(sp)
    800033ca:	e822                	sd	s0,16(sp)
    800033cc:	e426                	sd	s1,8(sp)
    800033ce:	1000                	addi	s0,sp,32
    800033d0:	84aa                	mv	s1,a0
  iunlock(ip);
    800033d2:	e97ff0ef          	jal	80003268 <iunlock>
  iput(ip);
    800033d6:	8526                	mv	a0,s1
    800033d8:	f65ff0ef          	jal	8000333c <iput>
}
    800033dc:	60e2                	ld	ra,24(sp)
    800033de:	6442                	ld	s0,16(sp)
    800033e0:	64a2                	ld	s1,8(sp)
    800033e2:	6105                	addi	sp,sp,32
    800033e4:	8082                	ret

00000000800033e6 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    800033e6:	1141                	addi	sp,sp,-16
    800033e8:	e406                	sd	ra,8(sp)
    800033ea:	e022                	sd	s0,0(sp)
    800033ec:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    800033ee:	411c                	lw	a5,0(a0)
    800033f0:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    800033f2:	415c                	lw	a5,4(a0)
    800033f4:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    800033f6:	04451783          	lh	a5,68(a0)
    800033fa:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    800033fe:	04a51783          	lh	a5,74(a0)
    80003402:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003406:	04c56783          	lwu	a5,76(a0)
    8000340a:	e99c                	sd	a5,16(a1)
}
    8000340c:	60a2                	ld	ra,8(sp)
    8000340e:	6402                	ld	s0,0(sp)
    80003410:	0141                	addi	sp,sp,16
    80003412:	8082                	ret

0000000080003414 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003414:	457c                	lw	a5,76(a0)
    80003416:	0ed7e663          	bltu	a5,a3,80003502 <readi+0xee>
{
    8000341a:	7159                	addi	sp,sp,-112
    8000341c:	f486                	sd	ra,104(sp)
    8000341e:	f0a2                	sd	s0,96(sp)
    80003420:	eca6                	sd	s1,88(sp)
    80003422:	e0d2                	sd	s4,64(sp)
    80003424:	fc56                	sd	s5,56(sp)
    80003426:	f85a                	sd	s6,48(sp)
    80003428:	f45e                	sd	s7,40(sp)
    8000342a:	1880                	addi	s0,sp,112
    8000342c:	8b2a                	mv	s6,a0
    8000342e:	8bae                	mv	s7,a1
    80003430:	8a32                	mv	s4,a2
    80003432:	84b6                	mv	s1,a3
    80003434:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80003436:	9f35                	addw	a4,a4,a3
    return 0;
    80003438:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    8000343a:	0ad76b63          	bltu	a4,a3,800034f0 <readi+0xdc>
    8000343e:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    80003440:	00e7f463          	bgeu	a5,a4,80003448 <readi+0x34>
    n = ip->size - off;
    80003444:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003448:	080a8b63          	beqz	s5,800034de <readi+0xca>
    8000344c:	e8ca                	sd	s2,80(sp)
    8000344e:	f062                	sd	s8,32(sp)
    80003450:	ec66                	sd	s9,24(sp)
    80003452:	e86a                	sd	s10,16(sp)
    80003454:	e46e                	sd	s11,8(sp)
    80003456:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003458:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    8000345c:	5c7d                	li	s8,-1
    8000345e:	a80d                	j	80003490 <readi+0x7c>
    80003460:	020d1d93          	slli	s11,s10,0x20
    80003464:	020ddd93          	srli	s11,s11,0x20
    80003468:	05890613          	addi	a2,s2,88
    8000346c:	86ee                	mv	a3,s11
    8000346e:	963e                	add	a2,a2,a5
    80003470:	85d2                	mv	a1,s4
    80003472:	855e                	mv	a0,s7
    80003474:	dc5fe0ef          	jal	80002238 <either_copyout>
    80003478:	05850363          	beq	a0,s8,800034be <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    8000347c:	854a                	mv	a0,s2
    8000347e:	f3aff0ef          	jal	80002bb8 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003482:	013d09bb          	addw	s3,s10,s3
    80003486:	009d04bb          	addw	s1,s10,s1
    8000348a:	9a6e                	add	s4,s4,s11
    8000348c:	0559f363          	bgeu	s3,s5,800034d2 <readi+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80003490:	00a4d59b          	srliw	a1,s1,0xa
    80003494:	855a                	mv	a0,s6
    80003496:	981ff0ef          	jal	80002e16 <bmap>
    8000349a:	85aa                	mv	a1,a0
    if(addr == 0)
    8000349c:	c139                	beqz	a0,800034e2 <readi+0xce>
    bp = bread(ip->dev, addr);
    8000349e:	000b2503          	lw	a0,0(s6)
    800034a2:	e0eff0ef          	jal	80002ab0 <bread>
    800034a6:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    800034a8:	3ff4f793          	andi	a5,s1,1023
    800034ac:	40fc873b          	subw	a4,s9,a5
    800034b0:	413a86bb          	subw	a3,s5,s3
    800034b4:	8d3a                	mv	s10,a4
    800034b6:	fae6f5e3          	bgeu	a3,a4,80003460 <readi+0x4c>
    800034ba:	8d36                	mv	s10,a3
    800034bc:	b755                	j	80003460 <readi+0x4c>
      brelse(bp);
    800034be:	854a                	mv	a0,s2
    800034c0:	ef8ff0ef          	jal	80002bb8 <brelse>
      tot = -1;
    800034c4:	59fd                	li	s3,-1
      break;
    800034c6:	6946                	ld	s2,80(sp)
    800034c8:	7c02                	ld	s8,32(sp)
    800034ca:	6ce2                	ld	s9,24(sp)
    800034cc:	6d42                	ld	s10,16(sp)
    800034ce:	6da2                	ld	s11,8(sp)
    800034d0:	a831                	j	800034ec <readi+0xd8>
    800034d2:	6946                	ld	s2,80(sp)
    800034d4:	7c02                	ld	s8,32(sp)
    800034d6:	6ce2                	ld	s9,24(sp)
    800034d8:	6d42                	ld	s10,16(sp)
    800034da:	6da2                	ld	s11,8(sp)
    800034dc:	a801                	j	800034ec <readi+0xd8>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800034de:	89d6                	mv	s3,s5
    800034e0:	a031                	j	800034ec <readi+0xd8>
    800034e2:	6946                	ld	s2,80(sp)
    800034e4:	7c02                	ld	s8,32(sp)
    800034e6:	6ce2                	ld	s9,24(sp)
    800034e8:	6d42                	ld	s10,16(sp)
    800034ea:	6da2                	ld	s11,8(sp)
  }
  return tot;
    800034ec:	854e                	mv	a0,s3
    800034ee:	69a6                	ld	s3,72(sp)
}
    800034f0:	70a6                	ld	ra,104(sp)
    800034f2:	7406                	ld	s0,96(sp)
    800034f4:	64e6                	ld	s1,88(sp)
    800034f6:	6a06                	ld	s4,64(sp)
    800034f8:	7ae2                	ld	s5,56(sp)
    800034fa:	7b42                	ld	s6,48(sp)
    800034fc:	7ba2                	ld	s7,40(sp)
    800034fe:	6165                	addi	sp,sp,112
    80003500:	8082                	ret
    return 0;
    80003502:	4501                	li	a0,0
}
    80003504:	8082                	ret

0000000080003506 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003506:	457c                	lw	a5,76(a0)
    80003508:	0ed7ee63          	bltu	a5,a3,80003604 <writei+0xfe>
{
    8000350c:	7159                	addi	sp,sp,-112
    8000350e:	f486                	sd	ra,104(sp)
    80003510:	f0a2                	sd	s0,96(sp)
    80003512:	e8ca                	sd	s2,80(sp)
    80003514:	e0d2                	sd	s4,64(sp)
    80003516:	fc56                	sd	s5,56(sp)
    80003518:	f85a                	sd	s6,48(sp)
    8000351a:	f45e                	sd	s7,40(sp)
    8000351c:	1880                	addi	s0,sp,112
    8000351e:	8aaa                	mv	s5,a0
    80003520:	8bae                	mv	s7,a1
    80003522:	8a32                	mv	s4,a2
    80003524:	8936                	mv	s2,a3
    80003526:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80003528:	9f35                	addw	a4,a4,a3
    return -1;
  if(off + n > MAXFILE*BSIZE)
    8000352a:	000437b7          	lui	a5,0x43
    8000352e:	00e7b7b3          	sltu	a5,a5,a4
  if(off > ip->size || off + n < off)
    80003532:	00d73733          	sltu	a4,a4,a3
  if(off + n > MAXFILE*BSIZE)
    80003536:	8fd9                	or	a5,a5,a4
    80003538:	ef91                	bnez	a5,80003554 <writei+0x4e>
    8000353a:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    8000353c:	0a0b0c63          	beqz	s6,800035f4 <writei+0xee>
    80003540:	eca6                	sd	s1,88(sp)
    80003542:	f062                	sd	s8,32(sp)
    80003544:	ec66                	sd	s9,24(sp)
    80003546:	e86a                	sd	s10,16(sp)
    80003548:	e46e                	sd	s11,8(sp)
    8000354a:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    8000354c:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003550:	5c7d                	li	s8,-1
    80003552:	a835                	j	8000358e <writei+0x88>
    return -1;
    80003554:	557d                	li	a0,-1
    80003556:	a071                	j	800035e2 <writei+0xdc>
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003558:	020d1d93          	slli	s11,s10,0x20
    8000355c:	020ddd93          	srli	s11,s11,0x20
    80003560:	05848513          	addi	a0,s1,88
    80003564:	86ee                	mv	a3,s11
    80003566:	8652                	mv	a2,s4
    80003568:	85de                	mv	a1,s7
    8000356a:	953e                	add	a0,a0,a5
    8000356c:	d17fe0ef          	jal	80002282 <either_copyin>
    80003570:	05850663          	beq	a0,s8,800035bc <writei+0xb6>
      brelse(bp);
      break;
    }
    log_write(bp);
    80003574:	8526                	mv	a0,s1
    80003576:	6a0000ef          	jal	80003c16 <log_write>
    brelse(bp);
    8000357a:	8526                	mv	a0,s1
    8000357c:	e3cff0ef          	jal	80002bb8 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003580:	013d09bb          	addw	s3,s10,s3
    80003584:	012d093b          	addw	s2,s10,s2
    80003588:	9a6e                	add	s4,s4,s11
    8000358a:	0369fc63          	bgeu	s3,s6,800035c2 <writei+0xbc>
    uint addr = bmap(ip, off/BSIZE);
    8000358e:	00a9559b          	srliw	a1,s2,0xa
    80003592:	8556                	mv	a0,s5
    80003594:	883ff0ef          	jal	80002e16 <bmap>
    80003598:	85aa                	mv	a1,a0
    if(addr == 0)
    8000359a:	c505                	beqz	a0,800035c2 <writei+0xbc>
    bp = bread(ip->dev, addr);
    8000359c:	000aa503          	lw	a0,0(s5)
    800035a0:	d10ff0ef          	jal	80002ab0 <bread>
    800035a4:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    800035a6:	3ff97793          	andi	a5,s2,1023
    800035aa:	40fc873b          	subw	a4,s9,a5
    800035ae:	413b06bb          	subw	a3,s6,s3
    800035b2:	8d3a                	mv	s10,a4
    800035b4:	fae6f2e3          	bgeu	a3,a4,80003558 <writei+0x52>
    800035b8:	8d36                	mv	s10,a3
    800035ba:	bf79                	j	80003558 <writei+0x52>
      brelse(bp);
    800035bc:	8526                	mv	a0,s1
    800035be:	dfaff0ef          	jal	80002bb8 <brelse>
  }

  if(off > ip->size)
    800035c2:	04caa783          	lw	a5,76(s5)
    800035c6:	0327f963          	bgeu	a5,s2,800035f8 <writei+0xf2>
    ip->size = off;
    800035ca:	052aa623          	sw	s2,76(s5)
    800035ce:	64e6                	ld	s1,88(sp)
    800035d0:	7c02                	ld	s8,32(sp)
    800035d2:	6ce2                	ld	s9,24(sp)
    800035d4:	6d42                	ld	s10,16(sp)
    800035d6:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    800035d8:	8556                	mv	a0,s5
    800035da:	b2dff0ef          	jal	80003106 <iupdate>

  return tot;
    800035de:	854e                	mv	a0,s3
    800035e0:	69a6                	ld	s3,72(sp)
}
    800035e2:	70a6                	ld	ra,104(sp)
    800035e4:	7406                	ld	s0,96(sp)
    800035e6:	6946                	ld	s2,80(sp)
    800035e8:	6a06                	ld	s4,64(sp)
    800035ea:	7ae2                	ld	s5,56(sp)
    800035ec:	7b42                	ld	s6,48(sp)
    800035ee:	7ba2                	ld	s7,40(sp)
    800035f0:	6165                	addi	sp,sp,112
    800035f2:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800035f4:	89da                	mv	s3,s6
    800035f6:	b7cd                	j	800035d8 <writei+0xd2>
    800035f8:	64e6                	ld	s1,88(sp)
    800035fa:	7c02                	ld	s8,32(sp)
    800035fc:	6ce2                	ld	s9,24(sp)
    800035fe:	6d42                	ld	s10,16(sp)
    80003600:	6da2                	ld	s11,8(sp)
    80003602:	bfd9                	j	800035d8 <writei+0xd2>
    return -1;
    80003604:	557d                	li	a0,-1
}
    80003606:	8082                	ret

0000000080003608 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003608:	1141                	addi	sp,sp,-16
    8000360a:	e406                	sd	ra,8(sp)
    8000360c:	e022                	sd	s0,0(sp)
    8000360e:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003610:	4639                	li	a2,14
    80003612:	feefd0ef          	jal	80000e00 <strncmp>
}
    80003616:	60a2                	ld	ra,8(sp)
    80003618:	6402                	ld	s0,0(sp)
    8000361a:	0141                	addi	sp,sp,16
    8000361c:	8082                	ret

000000008000361e <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    8000361e:	711d                	addi	sp,sp,-96
    80003620:	ec86                	sd	ra,88(sp)
    80003622:	e8a2                	sd	s0,80(sp)
    80003624:	e4a6                	sd	s1,72(sp)
    80003626:	e0ca                	sd	s2,64(sp)
    80003628:	fc4e                	sd	s3,56(sp)
    8000362a:	f852                	sd	s4,48(sp)
    8000362c:	f456                	sd	s5,40(sp)
    8000362e:	f05a                	sd	s6,32(sp)
    80003630:	ec5e                	sd	s7,24(sp)
    80003632:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003634:	04451703          	lh	a4,68(a0)
    80003638:	4785                	li	a5,1
    8000363a:	02f71963          	bne	a4,a5,8000366c <dirlookup+0x4e>
    8000363e:	892a                	mv	s2,a0
    80003640:	8aae                	mv	s5,a1
    80003642:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003644:	457c                	lw	a5,76(a0)
    80003646:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003648:	fa040a13          	addi	s4,s0,-96
    8000364c:	49c1                	li	s3,16
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    if(namecmp(name, de.name) == 0){
    8000364e:	fa240b13          	addi	s6,s0,-94
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003652:	ef95                	bnez	a5,8000368e <dirlookup+0x70>
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003654:	4501                	li	a0,0
}
    80003656:	60e6                	ld	ra,88(sp)
    80003658:	6446                	ld	s0,80(sp)
    8000365a:	64a6                	ld	s1,72(sp)
    8000365c:	6906                	ld	s2,64(sp)
    8000365e:	79e2                	ld	s3,56(sp)
    80003660:	7a42                	ld	s4,48(sp)
    80003662:	7aa2                	ld	s5,40(sp)
    80003664:	7b02                	ld	s6,32(sp)
    80003666:	6be2                	ld	s7,24(sp)
    80003668:	6125                	addi	sp,sp,96
    8000366a:	8082                	ret
    panic("dirlookup not DIR");
    8000366c:	00004517          	auipc	a0,0x4
    80003670:	eb450513          	addi	a0,a0,-332 # 80007520 <etext+0x520>
    80003674:	97cfd0ef          	jal	800007f0 <panic>
      panic("dirlookup read");
    80003678:	00004517          	auipc	a0,0x4
    8000367c:	ec050513          	addi	a0,a0,-320 # 80007538 <etext+0x538>
    80003680:	970fd0ef          	jal	800007f0 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003684:	24c1                	addiw	s1,s1,16
    80003686:	04c92783          	lw	a5,76(s2)
    8000368a:	fcf4f5e3          	bgeu	s1,a5,80003654 <dirlookup+0x36>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000368e:	874e                	mv	a4,s3
    80003690:	86a6                	mv	a3,s1
    80003692:	8652                	mv	a2,s4
    80003694:	4581                	li	a1,0
    80003696:	854a                	mv	a0,s2
    80003698:	d7dff0ef          	jal	80003414 <readi>
    8000369c:	fd351ee3          	bne	a0,s3,80003678 <dirlookup+0x5a>
    if(de.inum == 0)
    800036a0:	fa045783          	lhu	a5,-96(s0)
    800036a4:	d3e5                	beqz	a5,80003684 <dirlookup+0x66>
    if(namecmp(name, de.name) == 0){
    800036a6:	85da                	mv	a1,s6
    800036a8:	8556                	mv	a0,s5
    800036aa:	f5fff0ef          	jal	80003608 <namecmp>
    800036ae:	f979                	bnez	a0,80003684 <dirlookup+0x66>
      if(poff)
    800036b0:	000b8463          	beqz	s7,800036b8 <dirlookup+0x9a>
        *poff = off;
    800036b4:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    800036b8:	fa045583          	lhu	a1,-96(s0)
    800036bc:	00092503          	lw	a0,0(s2)
    800036c0:	817ff0ef          	jal	80002ed6 <iget>
    800036c4:	bf49                	j	80003656 <dirlookup+0x38>

00000000800036c6 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    800036c6:	711d                	addi	sp,sp,-96
    800036c8:	ec86                	sd	ra,88(sp)
    800036ca:	e8a2                	sd	s0,80(sp)
    800036cc:	e4a6                	sd	s1,72(sp)
    800036ce:	e0ca                	sd	s2,64(sp)
    800036d0:	fc4e                	sd	s3,56(sp)
    800036d2:	f852                	sd	s4,48(sp)
    800036d4:	f456                	sd	s5,40(sp)
    800036d6:	f05a                	sd	s6,32(sp)
    800036d8:	ec5e                	sd	s7,24(sp)
    800036da:	e862                	sd	s8,16(sp)
    800036dc:	e466                	sd	s9,8(sp)
    800036de:	e06a                	sd	s10,0(sp)
    800036e0:	1080                	addi	s0,sp,96
    800036e2:	84aa                	mv	s1,a0
    800036e4:	8b2e                	mv	s6,a1
    800036e6:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    800036e8:	00054703          	lbu	a4,0(a0)
    800036ec:	02f00793          	li	a5,47
    800036f0:	00f70f63          	beq	a4,a5,8000370e <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    800036f4:	a30fe0ef          	jal	80001924 <myproc>
    800036f8:	15053503          	ld	a0,336(a0)
    800036fc:	a89ff0ef          	jal	80003184 <idup>
    80003700:	8a2a                	mv	s4,a0
  while(*path == '/')
    80003702:	02f00993          	li	s3,47
  if(len >= DIRSIZ)
    80003706:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    80003708:	4cb9                	li	s9,14

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    8000370a:	4b85                	li	s7,1
    8000370c:	a879                	j	800037aa <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    8000370e:	4585                	li	a1,1
    80003710:	852e                	mv	a0,a1
    80003712:	fc4ff0ef          	jal	80002ed6 <iget>
    80003716:	8a2a                	mv	s4,a0
    80003718:	b7ed                	j	80003702 <namex+0x3c>
      iunlockput(ip);
    8000371a:	8552                	mv	a0,s4
    8000371c:	cabff0ef          	jal	800033c6 <iunlockput>
      return 0;
    80003720:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003722:	8552                	mv	a0,s4
    80003724:	60e6                	ld	ra,88(sp)
    80003726:	6446                	ld	s0,80(sp)
    80003728:	64a6                	ld	s1,72(sp)
    8000372a:	6906                	ld	s2,64(sp)
    8000372c:	79e2                	ld	s3,56(sp)
    8000372e:	7a42                	ld	s4,48(sp)
    80003730:	7aa2                	ld	s5,40(sp)
    80003732:	7b02                	ld	s6,32(sp)
    80003734:	6be2                	ld	s7,24(sp)
    80003736:	6c42                	ld	s8,16(sp)
    80003738:	6ca2                	ld	s9,8(sp)
    8000373a:	6d02                	ld	s10,0(sp)
    8000373c:	6125                	addi	sp,sp,96
    8000373e:	8082                	ret
      iunlock(ip);
    80003740:	8552                	mv	a0,s4
    80003742:	b27ff0ef          	jal	80003268 <iunlock>
      return ip;
    80003746:	bff1                	j	80003722 <namex+0x5c>
      iunlockput(ip);
    80003748:	8552                	mv	a0,s4
    8000374a:	c7dff0ef          	jal	800033c6 <iunlockput>
      return 0;
    8000374e:	8a4a                	mv	s4,s2
    80003750:	bfc9                	j	80003722 <namex+0x5c>
  while(*path != '/' && *path != 0)
    80003752:	8926                	mv	s2,s1
  len = path - s;
    80003754:	4d01                	li	s10,0
    80003756:	4601                	li	a2,0
    memmove(name, s, len);
    80003758:	2601                	sext.w	a2,a2
    8000375a:	85a6                	mv	a1,s1
    8000375c:	8556                	mv	a0,s5
    8000375e:	e2efd0ef          	jal	80000d8c <memmove>
    name[len] = 0;
    80003762:	9d56                	add	s10,s10,s5
    80003764:	000d0023          	sb	zero,0(s10)
    80003768:	84ca                	mv	s1,s2
  while(*path == '/')
    8000376a:	0004c783          	lbu	a5,0(s1)
    8000376e:	01379763          	bne	a5,s3,8000377c <namex+0xb6>
    path++;
    80003772:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003774:	0004c783          	lbu	a5,0(s1)
    80003778:	ff378de3          	beq	a5,s3,80003772 <namex+0xac>
    ilock(ip);
    8000377c:	8552                	mv	a0,s4
    8000377e:	a3dff0ef          	jal	800031ba <ilock>
    if(ip->type != T_DIR){
    80003782:	044a1783          	lh	a5,68(s4)
    80003786:	f9779ae3          	bne	a5,s7,8000371a <namex+0x54>
    if(nameiparent && *path == '\0'){
    8000378a:	000b0563          	beqz	s6,80003794 <namex+0xce>
    8000378e:	0004c783          	lbu	a5,0(s1)
    80003792:	d7dd                	beqz	a5,80003740 <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003794:	4601                	li	a2,0
    80003796:	85d6                	mv	a1,s5
    80003798:	8552                	mv	a0,s4
    8000379a:	e85ff0ef          	jal	8000361e <dirlookup>
    8000379e:	892a                	mv	s2,a0
    800037a0:	d545                	beqz	a0,80003748 <namex+0x82>
    iunlockput(ip);
    800037a2:	8552                	mv	a0,s4
    800037a4:	c23ff0ef          	jal	800033c6 <iunlockput>
    ip = next;
    800037a8:	8a4a                	mv	s4,s2
  while(*path == '/')
    800037aa:	0004c783          	lbu	a5,0(s1)
    800037ae:	01379763          	bne	a5,s3,800037bc <namex+0xf6>
    path++;
    800037b2:	0485                	addi	s1,s1,1
  while(*path == '/')
    800037b4:	0004c783          	lbu	a5,0(s1)
    800037b8:	ff378de3          	beq	a5,s3,800037b2 <namex+0xec>
  if(*path == 0)
    800037bc:	c7a1                	beqz	a5,80003804 <namex+0x13e>
  while(*path != '/' && *path != 0)
    800037be:	0004c703          	lbu	a4,0(s1)
    800037c2:	fd170793          	addi	a5,a4,-47
    800037c6:	00f037b3          	snez	a5,a5
    800037ca:	00e03733          	snez	a4,a4
    800037ce:	8ff9                	and	a5,a5,a4
    800037d0:	d3c9                	beqz	a5,80003752 <namex+0x8c>
    800037d2:	8926                	mv	s2,s1
    path++;
    800037d4:	0905                	addi	s2,s2,1
  while(*path != '/' && *path != 0)
    800037d6:	00094703          	lbu	a4,0(s2)
    800037da:	fd170793          	addi	a5,a4,-47
    800037de:	00f037b3          	snez	a5,a5
    800037e2:	00e03733          	snez	a4,a4
    800037e6:	8ff9                	and	a5,a5,a4
    800037e8:	f7f5                	bnez	a5,800037d4 <namex+0x10e>
  len = path - s;
    800037ea:	40990633          	sub	a2,s2,s1
    800037ee:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    800037f2:	f7ac53e3          	bge	s8,s10,80003758 <namex+0x92>
    memmove(name, s, DIRSIZ);
    800037f6:	8666                	mv	a2,s9
    800037f8:	85a6                	mv	a1,s1
    800037fa:	8556                	mv	a0,s5
    800037fc:	d90fd0ef          	jal	80000d8c <memmove>
    80003800:	84ca                	mv	s1,s2
    80003802:	b7a5                	j	8000376a <namex+0xa4>
  if(nameiparent){
    80003804:	f00b0fe3          	beqz	s6,80003722 <namex+0x5c>
    iput(ip);
    80003808:	8552                	mv	a0,s4
    8000380a:	b33ff0ef          	jal	8000333c <iput>
    return 0;
    8000380e:	bf09                	j	80003720 <namex+0x5a>

0000000080003810 <dirlink>:
{
    80003810:	715d                	addi	sp,sp,-80
    80003812:	e486                	sd	ra,72(sp)
    80003814:	e0a2                	sd	s0,64(sp)
    80003816:	f84a                	sd	s2,48(sp)
    80003818:	ec56                	sd	s5,24(sp)
    8000381a:	e85a                	sd	s6,16(sp)
    8000381c:	0880                	addi	s0,sp,80
    8000381e:	892a                	mv	s2,a0
    80003820:	8aae                	mv	s5,a1
    80003822:	8b32                	mv	s6,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003824:	4601                	li	a2,0
    80003826:	df9ff0ef          	jal	8000361e <dirlookup>
    8000382a:	ed1d                	bnez	a0,80003868 <dirlink+0x58>
    8000382c:	fc26                	sd	s1,56(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    8000382e:	04c92483          	lw	s1,76(s2)
    80003832:	c4b9                	beqz	s1,80003880 <dirlink+0x70>
    80003834:	f44e                	sd	s3,40(sp)
    80003836:	f052                	sd	s4,32(sp)
    80003838:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000383a:	fb040a13          	addi	s4,s0,-80
    8000383e:	49c1                	li	s3,16
    80003840:	874e                	mv	a4,s3
    80003842:	86a6                	mv	a3,s1
    80003844:	8652                	mv	a2,s4
    80003846:	4581                	li	a1,0
    80003848:	854a                	mv	a0,s2
    8000384a:	bcbff0ef          	jal	80003414 <readi>
    8000384e:	03351163          	bne	a0,s3,80003870 <dirlink+0x60>
    if(de.inum == 0)
    80003852:	fb045783          	lhu	a5,-80(s0)
    80003856:	c39d                	beqz	a5,8000387c <dirlink+0x6c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003858:	24c1                	addiw	s1,s1,16
    8000385a:	04c92783          	lw	a5,76(s2)
    8000385e:	fef4e1e3          	bltu	s1,a5,80003840 <dirlink+0x30>
    80003862:	79a2                	ld	s3,40(sp)
    80003864:	7a02                	ld	s4,32(sp)
    80003866:	a829                	j	80003880 <dirlink+0x70>
    iput(ip);
    80003868:	ad5ff0ef          	jal	8000333c <iput>
    return -1;
    8000386c:	557d                	li	a0,-1
    8000386e:	a83d                	j	800038ac <dirlink+0x9c>
      panic("dirlink read");
    80003870:	00004517          	auipc	a0,0x4
    80003874:	cd850513          	addi	a0,a0,-808 # 80007548 <etext+0x548>
    80003878:	f79fc0ef          	jal	800007f0 <panic>
    8000387c:	79a2                	ld	s3,40(sp)
    8000387e:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80003880:	4639                	li	a2,14
    80003882:	85d6                	mv	a1,s5
    80003884:	fb240513          	addi	a0,s0,-78
    80003888:	daefd0ef          	jal	80000e36 <strncpy>
  de.inum = inum;
    8000388c:	fb641823          	sh	s6,-80(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003890:	4741                	li	a4,16
    80003892:	86a6                	mv	a3,s1
    80003894:	fb040613          	addi	a2,s0,-80
    80003898:	4581                	li	a1,0
    8000389a:	854a                	mv	a0,s2
    8000389c:	c6bff0ef          	jal	80003506 <writei>
    800038a0:	1541                	addi	a0,a0,-16
    800038a2:	00a03533          	snez	a0,a0
    800038a6:	40a0053b          	negw	a0,a0
    800038aa:	74e2                	ld	s1,56(sp)
}
    800038ac:	60a6                	ld	ra,72(sp)
    800038ae:	6406                	ld	s0,64(sp)
    800038b0:	7942                	ld	s2,48(sp)
    800038b2:	6ae2                	ld	s5,24(sp)
    800038b4:	6b42                	ld	s6,16(sp)
    800038b6:	6161                	addi	sp,sp,80
    800038b8:	8082                	ret

00000000800038ba <namei>:

struct inode*
namei(char *path)
{
    800038ba:	1101                	addi	sp,sp,-32
    800038bc:	ec06                	sd	ra,24(sp)
    800038be:	e822                	sd	s0,16(sp)
    800038c0:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    800038c2:	fe040613          	addi	a2,s0,-32
    800038c6:	4581                	li	a1,0
    800038c8:	dffff0ef          	jal	800036c6 <namex>
}
    800038cc:	60e2                	ld	ra,24(sp)
    800038ce:	6442                	ld	s0,16(sp)
    800038d0:	6105                	addi	sp,sp,32
    800038d2:	8082                	ret

00000000800038d4 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    800038d4:	1141                	addi	sp,sp,-16
    800038d6:	e406                	sd	ra,8(sp)
    800038d8:	e022                	sd	s0,0(sp)
    800038da:	0800                	addi	s0,sp,16
    800038dc:	862e                	mv	a2,a1
  return namex(path, 1, name);
    800038de:	4585                	li	a1,1
    800038e0:	de7ff0ef          	jal	800036c6 <namex>
}
    800038e4:	60a2                	ld	ra,8(sp)
    800038e6:	6402                	ld	s0,0(sp)
    800038e8:	0141                	addi	sp,sp,16
    800038ea:	8082                	ret

00000000800038ec <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    800038ec:	1101                	addi	sp,sp,-32
    800038ee:	ec06                	sd	ra,24(sp)
    800038f0:	e822                	sd	s0,16(sp)
    800038f2:	e426                	sd	s1,8(sp)
    800038f4:	e04a                	sd	s2,0(sp)
    800038f6:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    800038f8:	0001c917          	auipc	s2,0x1c
    800038fc:	10890913          	addi	s2,s2,264 # 8001fa00 <log>
    80003900:	01892583          	lw	a1,24(s2)
    80003904:	02892503          	lw	a0,40(s2)
    80003908:	9a8ff0ef          	jal	80002ab0 <bread>
    8000390c:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    8000390e:	02c92603          	lw	a2,44(s2)
    80003912:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003914:	00c05f63          	blez	a2,80003932 <write_head+0x46>
    80003918:	0001c717          	auipc	a4,0x1c
    8000391c:	11870713          	addi	a4,a4,280 # 8001fa30 <log+0x30>
    80003920:	87aa                	mv	a5,a0
    80003922:	060a                	slli	a2,a2,0x2
    80003924:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003926:	4314                	lw	a3,0(a4)
    80003928:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    8000392a:	0711                	addi	a4,a4,4
    8000392c:	0791                	addi	a5,a5,4 # 43004 <_entry-0x7ffbcffc>
    8000392e:	fec79ce3          	bne	a5,a2,80003926 <write_head+0x3a>
  }
  bwrite(buf);
    80003932:	8526                	mv	a0,s1
    80003934:	a52ff0ef          	jal	80002b86 <bwrite>
  brelse(buf);
    80003938:	8526                	mv	a0,s1
    8000393a:	a7eff0ef          	jal	80002bb8 <brelse>
}
    8000393e:	60e2                	ld	ra,24(sp)
    80003940:	6442                	ld	s0,16(sp)
    80003942:	64a2                	ld	s1,8(sp)
    80003944:	6902                	ld	s2,0(sp)
    80003946:	6105                	addi	sp,sp,32
    80003948:	8082                	ret

000000008000394a <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    8000394a:	0001c797          	auipc	a5,0x1c
    8000394e:	0e27a783          	lw	a5,226(a5) # 8001fa2c <log+0x2c>
    80003952:	0af05263          	blez	a5,800039f6 <install_trans+0xac>
{
    80003956:	715d                	addi	sp,sp,-80
    80003958:	e486                	sd	ra,72(sp)
    8000395a:	e0a2                	sd	s0,64(sp)
    8000395c:	fc26                	sd	s1,56(sp)
    8000395e:	f84a                	sd	s2,48(sp)
    80003960:	f44e                	sd	s3,40(sp)
    80003962:	f052                	sd	s4,32(sp)
    80003964:	ec56                	sd	s5,24(sp)
    80003966:	e85a                	sd	s6,16(sp)
    80003968:	e45e                	sd	s7,8(sp)
    8000396a:	0880                	addi	s0,sp,80
    8000396c:	8b2a                	mv	s6,a0
    8000396e:	0001ca97          	auipc	s5,0x1c
    80003972:	0c2a8a93          	addi	s5,s5,194 # 8001fa30 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003976:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003978:	0001c997          	auipc	s3,0x1c
    8000397c:	08898993          	addi	s3,s3,136 # 8001fa00 <log>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003980:	40000b93          	li	s7,1024
    80003984:	a829                	j	8000399e <install_trans+0x54>
    brelse(lbuf);
    80003986:	854a                	mv	a0,s2
    80003988:	a30ff0ef          	jal	80002bb8 <brelse>
    brelse(dbuf);
    8000398c:	8526                	mv	a0,s1
    8000398e:	a2aff0ef          	jal	80002bb8 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003992:	2a05                	addiw	s4,s4,1
    80003994:	0a91                	addi	s5,s5,4
    80003996:	02c9a783          	lw	a5,44(s3)
    8000399a:	04fa5363          	bge	s4,a5,800039e0 <install_trans+0x96>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    8000399e:	0189a583          	lw	a1,24(s3)
    800039a2:	014585bb          	addw	a1,a1,s4
    800039a6:	2585                	addiw	a1,a1,1
    800039a8:	0289a503          	lw	a0,40(s3)
    800039ac:	904ff0ef          	jal	80002ab0 <bread>
    800039b0:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    800039b2:	000aa583          	lw	a1,0(s5)
    800039b6:	0289a503          	lw	a0,40(s3)
    800039ba:	8f6ff0ef          	jal	80002ab0 <bread>
    800039be:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    800039c0:	865e                	mv	a2,s7
    800039c2:	05890593          	addi	a1,s2,88
    800039c6:	05850513          	addi	a0,a0,88
    800039ca:	bc2fd0ef          	jal	80000d8c <memmove>
    bwrite(dbuf);  // write dst to disk
    800039ce:	8526                	mv	a0,s1
    800039d0:	9b6ff0ef          	jal	80002b86 <bwrite>
    if(recovering == 0)
    800039d4:	fa0b19e3          	bnez	s6,80003986 <install_trans+0x3c>
      bunpin(dbuf);
    800039d8:	8526                	mv	a0,s1
    800039da:	a96ff0ef          	jal	80002c70 <bunpin>
    800039de:	b765                	j	80003986 <install_trans+0x3c>
}
    800039e0:	60a6                	ld	ra,72(sp)
    800039e2:	6406                	ld	s0,64(sp)
    800039e4:	74e2                	ld	s1,56(sp)
    800039e6:	7942                	ld	s2,48(sp)
    800039e8:	79a2                	ld	s3,40(sp)
    800039ea:	7a02                	ld	s4,32(sp)
    800039ec:	6ae2                	ld	s5,24(sp)
    800039ee:	6b42                	ld	s6,16(sp)
    800039f0:	6ba2                	ld	s7,8(sp)
    800039f2:	6161                	addi	sp,sp,80
    800039f4:	8082                	ret
    800039f6:	8082                	ret

00000000800039f8 <initlog>:
{
    800039f8:	7179                	addi	sp,sp,-48
    800039fa:	f406                	sd	ra,40(sp)
    800039fc:	f022                	sd	s0,32(sp)
    800039fe:	ec26                	sd	s1,24(sp)
    80003a00:	e84a                	sd	s2,16(sp)
    80003a02:	e44e                	sd	s3,8(sp)
    80003a04:	1800                	addi	s0,sp,48
    80003a06:	892a                	mv	s2,a0
    80003a08:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003a0a:	0001c497          	auipc	s1,0x1c
    80003a0e:	ff648493          	addi	s1,s1,-10 # 8001fa00 <log>
    80003a12:	00004597          	auipc	a1,0x4
    80003a16:	b4658593          	addi	a1,a1,-1210 # 80007558 <etext+0x558>
    80003a1a:	8526                	mv	a0,s1
    80003a1c:	9befd0ef          	jal	80000bda <initlock>
  log.start = sb->logstart;
    80003a20:	0149a583          	lw	a1,20(s3)
    80003a24:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    80003a26:	0109a783          	lw	a5,16(s3)
    80003a2a:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    80003a2c:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003a30:	854a                	mv	a0,s2
    80003a32:	87eff0ef          	jal	80002ab0 <bread>
  log.lh.n = lh->n;
    80003a36:	4d30                	lw	a2,88(a0)
    80003a38:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    80003a3a:	00c05f63          	blez	a2,80003a58 <initlog+0x60>
    80003a3e:	87aa                	mv	a5,a0
    80003a40:	0001c717          	auipc	a4,0x1c
    80003a44:	ff070713          	addi	a4,a4,-16 # 8001fa30 <log+0x30>
    80003a48:	060a                	slli	a2,a2,0x2
    80003a4a:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003a4c:	4ff4                	lw	a3,92(a5)
    80003a4e:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003a50:	0791                	addi	a5,a5,4
    80003a52:	0711                	addi	a4,a4,4
    80003a54:	fec79ce3          	bne	a5,a2,80003a4c <initlog+0x54>
  brelse(buf);
    80003a58:	960ff0ef          	jal	80002bb8 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003a5c:	4505                	li	a0,1
    80003a5e:	eedff0ef          	jal	8000394a <install_trans>
  log.lh.n = 0;
    80003a62:	0001c797          	auipc	a5,0x1c
    80003a66:	fc07a523          	sw	zero,-54(a5) # 8001fa2c <log+0x2c>
  write_head(); // clear the log
    80003a6a:	e83ff0ef          	jal	800038ec <write_head>
}
    80003a6e:	70a2                	ld	ra,40(sp)
    80003a70:	7402                	ld	s0,32(sp)
    80003a72:	64e2                	ld	s1,24(sp)
    80003a74:	6942                	ld	s2,16(sp)
    80003a76:	69a2                	ld	s3,8(sp)
    80003a78:	6145                	addi	sp,sp,48
    80003a7a:	8082                	ret

0000000080003a7c <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003a7c:	1101                	addi	sp,sp,-32
    80003a7e:	ec06                	sd	ra,24(sp)
    80003a80:	e822                	sd	s0,16(sp)
    80003a82:	e426                	sd	s1,8(sp)
    80003a84:	e04a                	sd	s2,0(sp)
    80003a86:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003a88:	0001c517          	auipc	a0,0x1c
    80003a8c:	f7850513          	addi	a0,a0,-136 # 8001fa00 <log>
    80003a90:	9d4fd0ef          	jal	80000c64 <acquire>
  while(1){
    if(log.committing){
    80003a94:	0001c497          	auipc	s1,0x1c
    80003a98:	f6c48493          	addi	s1,s1,-148 # 8001fa00 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003a9c:	4979                	li	s2,30
    80003a9e:	a029                	j	80003aa8 <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003aa0:	85a6                	mv	a1,s1
    80003aa2:	8526                	mv	a0,s1
    80003aa4:	c3cfe0ef          	jal	80001ee0 <sleep>
    if(log.committing){
    80003aa8:	50dc                	lw	a5,36(s1)
    80003aaa:	fbfd                	bnez	a5,80003aa0 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003aac:	5098                	lw	a4,32(s1)
    80003aae:	2705                	addiw	a4,a4,1
    80003ab0:	0027179b          	slliw	a5,a4,0x2
    80003ab4:	9fb9                	addw	a5,a5,a4
    80003ab6:	0017979b          	slliw	a5,a5,0x1
    80003aba:	54d4                	lw	a3,44(s1)
    80003abc:	9fb5                	addw	a5,a5,a3
    80003abe:	00f95763          	bge	s2,a5,80003acc <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80003ac2:	85a6                	mv	a1,s1
    80003ac4:	8526                	mv	a0,s1
    80003ac6:	c1afe0ef          	jal	80001ee0 <sleep>
    80003aca:	bff9                	j	80003aa8 <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003acc:	0001c797          	auipc	a5,0x1c
    80003ad0:	f4e7aa23          	sw	a4,-172(a5) # 8001fa20 <log+0x20>
      release(&log.lock);
    80003ad4:	0001c517          	auipc	a0,0x1c
    80003ad8:	f2c50513          	addi	a0,a0,-212 # 8001fa00 <log>
    80003adc:	a18fd0ef          	jal	80000cf4 <release>
      break;
    }
  }
}
    80003ae0:	60e2                	ld	ra,24(sp)
    80003ae2:	6442                	ld	s0,16(sp)
    80003ae4:	64a2                	ld	s1,8(sp)
    80003ae6:	6902                	ld	s2,0(sp)
    80003ae8:	6105                	addi	sp,sp,32
    80003aea:	8082                	ret

0000000080003aec <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003aec:	7139                	addi	sp,sp,-64
    80003aee:	fc06                	sd	ra,56(sp)
    80003af0:	f822                	sd	s0,48(sp)
    80003af2:	f426                	sd	s1,40(sp)
    80003af4:	f04a                	sd	s2,32(sp)
    80003af6:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003af8:	0001c497          	auipc	s1,0x1c
    80003afc:	f0848493          	addi	s1,s1,-248 # 8001fa00 <log>
    80003b00:	8526                	mv	a0,s1
    80003b02:	962fd0ef          	jal	80000c64 <acquire>
  log.outstanding -= 1;
    80003b06:	509c                	lw	a5,32(s1)
    80003b08:	37fd                	addiw	a5,a5,-1
    80003b0a:	893e                	mv	s2,a5
    80003b0c:	d09c                	sw	a5,32(s1)
  if(log.committing)
    80003b0e:	50dc                	lw	a5,36(s1)
    80003b10:	ebb9                	bnez	a5,80003b66 <end_op+0x7a>
    panic("log.committing");
  if(log.outstanding == 0){
    80003b12:	06091363          	bnez	s2,80003b78 <end_op+0x8c>
    do_commit = 1;
    log.committing = 1;
    80003b16:	0001c497          	auipc	s1,0x1c
    80003b1a:	eea48493          	addi	s1,s1,-278 # 8001fa00 <log>
    80003b1e:	4785                	li	a5,1
    80003b20:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003b22:	8526                	mv	a0,s1
    80003b24:	9d0fd0ef          	jal	80000cf4 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003b28:	54dc                	lw	a5,44(s1)
    80003b2a:	06f04463          	bgtz	a5,80003b92 <end_op+0xa6>
    acquire(&log.lock);
    80003b2e:	0001c517          	auipc	a0,0x1c
    80003b32:	ed250513          	addi	a0,a0,-302 # 8001fa00 <log>
    80003b36:	92efd0ef          	jal	80000c64 <acquire>
    log.committing = 0;
    80003b3a:	0001c797          	auipc	a5,0x1c
    80003b3e:	ee07a523          	sw	zero,-278(a5) # 8001fa24 <log+0x24>
    wakeup(&log);
    80003b42:	0001c517          	auipc	a0,0x1c
    80003b46:	ebe50513          	addi	a0,a0,-322 # 8001fa00 <log>
    80003b4a:	be2fe0ef          	jal	80001f2c <wakeup>
    release(&log.lock);
    80003b4e:	0001c517          	auipc	a0,0x1c
    80003b52:	eb250513          	addi	a0,a0,-334 # 8001fa00 <log>
    80003b56:	99efd0ef          	jal	80000cf4 <release>
}
    80003b5a:	70e2                	ld	ra,56(sp)
    80003b5c:	7442                	ld	s0,48(sp)
    80003b5e:	74a2                	ld	s1,40(sp)
    80003b60:	7902                	ld	s2,32(sp)
    80003b62:	6121                	addi	sp,sp,64
    80003b64:	8082                	ret
    80003b66:	ec4e                	sd	s3,24(sp)
    80003b68:	e852                	sd	s4,16(sp)
    80003b6a:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003b6c:	00004517          	auipc	a0,0x4
    80003b70:	9f450513          	addi	a0,a0,-1548 # 80007560 <etext+0x560>
    80003b74:	c7dfc0ef          	jal	800007f0 <panic>
    wakeup(&log);
    80003b78:	0001c517          	auipc	a0,0x1c
    80003b7c:	e8850513          	addi	a0,a0,-376 # 8001fa00 <log>
    80003b80:	bacfe0ef          	jal	80001f2c <wakeup>
  release(&log.lock);
    80003b84:	0001c517          	auipc	a0,0x1c
    80003b88:	e7c50513          	addi	a0,a0,-388 # 8001fa00 <log>
    80003b8c:	968fd0ef          	jal	80000cf4 <release>
  if(do_commit){
    80003b90:	b7e9                	j	80003b5a <end_op+0x6e>
    80003b92:	ec4e                	sd	s3,24(sp)
    80003b94:	e852                	sd	s4,16(sp)
    80003b96:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003b98:	0001ca97          	auipc	s5,0x1c
    80003b9c:	e98a8a93          	addi	s5,s5,-360 # 8001fa30 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003ba0:	0001ca17          	auipc	s4,0x1c
    80003ba4:	e60a0a13          	addi	s4,s4,-416 # 8001fa00 <log>
    80003ba8:	018a2583          	lw	a1,24(s4)
    80003bac:	012585bb          	addw	a1,a1,s2
    80003bb0:	2585                	addiw	a1,a1,1
    80003bb2:	028a2503          	lw	a0,40(s4)
    80003bb6:	efbfe0ef          	jal	80002ab0 <bread>
    80003bba:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003bbc:	000aa583          	lw	a1,0(s5)
    80003bc0:	028a2503          	lw	a0,40(s4)
    80003bc4:	eedfe0ef          	jal	80002ab0 <bread>
    80003bc8:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003bca:	40000613          	li	a2,1024
    80003bce:	05850593          	addi	a1,a0,88
    80003bd2:	05848513          	addi	a0,s1,88
    80003bd6:	9b6fd0ef          	jal	80000d8c <memmove>
    bwrite(to);  // write the log
    80003bda:	8526                	mv	a0,s1
    80003bdc:	fabfe0ef          	jal	80002b86 <bwrite>
    brelse(from);
    80003be0:	854e                	mv	a0,s3
    80003be2:	fd7fe0ef          	jal	80002bb8 <brelse>
    brelse(to);
    80003be6:	8526                	mv	a0,s1
    80003be8:	fd1fe0ef          	jal	80002bb8 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003bec:	2905                	addiw	s2,s2,1
    80003bee:	0a91                	addi	s5,s5,4
    80003bf0:	02ca2783          	lw	a5,44(s4)
    80003bf4:	faf94ae3          	blt	s2,a5,80003ba8 <end_op+0xbc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80003bf8:	cf5ff0ef          	jal	800038ec <write_head>
    install_trans(0); // Now install writes to home locations
    80003bfc:	4501                	li	a0,0
    80003bfe:	d4dff0ef          	jal	8000394a <install_trans>
    log.lh.n = 0;
    80003c02:	0001c797          	auipc	a5,0x1c
    80003c06:	e207a523          	sw	zero,-470(a5) # 8001fa2c <log+0x2c>
    write_head();    // Erase the transaction from the log
    80003c0a:	ce3ff0ef          	jal	800038ec <write_head>
    80003c0e:	69e2                	ld	s3,24(sp)
    80003c10:	6a42                	ld	s4,16(sp)
    80003c12:	6aa2                	ld	s5,8(sp)
    80003c14:	bf29                	j	80003b2e <end_op+0x42>

0000000080003c16 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003c16:	1101                	addi	sp,sp,-32
    80003c18:	ec06                	sd	ra,24(sp)
    80003c1a:	e822                	sd	s0,16(sp)
    80003c1c:	e426                	sd	s1,8(sp)
    80003c1e:	1000                	addi	s0,sp,32
    80003c20:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003c22:	0001c517          	auipc	a0,0x1c
    80003c26:	dde50513          	addi	a0,a0,-546 # 8001fa00 <log>
    80003c2a:	83afd0ef          	jal	80000c64 <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    80003c2e:	0001c617          	auipc	a2,0x1c
    80003c32:	dfe62603          	lw	a2,-514(a2) # 8001fa2c <log+0x2c>
    80003c36:	47f5                	li	a5,29
    80003c38:	06c7c363          	blt	a5,a2,80003c9e <log_write+0x88>
    80003c3c:	0001c797          	auipc	a5,0x1c
    80003c40:	de07a783          	lw	a5,-544(a5) # 8001fa1c <log+0x1c>
    80003c44:	37fd                	addiw	a5,a5,-1
    80003c46:	04f65c63          	bge	a2,a5,80003c9e <log_write+0x88>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003c4a:	0001c797          	auipc	a5,0x1c
    80003c4e:	dd67a783          	lw	a5,-554(a5) # 8001fa20 <log+0x20>
    80003c52:	04f05c63          	blez	a5,80003caa <log_write+0x94>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003c56:	4781                	li	a5,0
    80003c58:	04c05f63          	blez	a2,80003cb6 <log_write+0xa0>
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003c5c:	44cc                	lw	a1,12(s1)
    80003c5e:	0001c717          	auipc	a4,0x1c
    80003c62:	dd270713          	addi	a4,a4,-558 # 8001fa30 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80003c66:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003c68:	4314                	lw	a3,0(a4)
    80003c6a:	04b68663          	beq	a3,a1,80003cb6 <log_write+0xa0>
  for (i = 0; i < log.lh.n; i++) {
    80003c6e:	2785                	addiw	a5,a5,1
    80003c70:	0711                	addi	a4,a4,4
    80003c72:	fef61be3          	bne	a2,a5,80003c68 <log_write+0x52>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003c76:	0621                	addi	a2,a2,8
    80003c78:	060a                	slli	a2,a2,0x2
    80003c7a:	0001c797          	auipc	a5,0x1c
    80003c7e:	d8678793          	addi	a5,a5,-634 # 8001fa00 <log>
    80003c82:	97b2                	add	a5,a5,a2
    80003c84:	44d8                	lw	a4,12(s1)
    80003c86:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80003c88:	8526                	mv	a0,s1
    80003c8a:	fb3fe0ef          	jal	80002c3c <bpin>
    log.lh.n++;
    80003c8e:	0001c717          	auipc	a4,0x1c
    80003c92:	d7270713          	addi	a4,a4,-654 # 8001fa00 <log>
    80003c96:	575c                	lw	a5,44(a4)
    80003c98:	2785                	addiw	a5,a5,1
    80003c9a:	d75c                	sw	a5,44(a4)
    80003c9c:	a80d                	j	80003cce <log_write+0xb8>
    panic("too big a transaction");
    80003c9e:	00004517          	auipc	a0,0x4
    80003ca2:	8d250513          	addi	a0,a0,-1838 # 80007570 <etext+0x570>
    80003ca6:	b4bfc0ef          	jal	800007f0 <panic>
    panic("log_write outside of trans");
    80003caa:	00004517          	auipc	a0,0x4
    80003cae:	8de50513          	addi	a0,a0,-1826 # 80007588 <etext+0x588>
    80003cb2:	b3ffc0ef          	jal	800007f0 <panic>
  log.lh.block[i] = b->blockno;
    80003cb6:	00878693          	addi	a3,a5,8
    80003cba:	068a                	slli	a3,a3,0x2
    80003cbc:	0001c717          	auipc	a4,0x1c
    80003cc0:	d4470713          	addi	a4,a4,-700 # 8001fa00 <log>
    80003cc4:	9736                	add	a4,a4,a3
    80003cc6:	44d4                	lw	a3,12(s1)
    80003cc8:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    80003cca:	faf60fe3          	beq	a2,a5,80003c88 <log_write+0x72>
  }
  release(&log.lock);
    80003cce:	0001c517          	auipc	a0,0x1c
    80003cd2:	d3250513          	addi	a0,a0,-718 # 8001fa00 <log>
    80003cd6:	81efd0ef          	jal	80000cf4 <release>
}
    80003cda:	60e2                	ld	ra,24(sp)
    80003cdc:	6442                	ld	s0,16(sp)
    80003cde:	64a2                	ld	s1,8(sp)
    80003ce0:	6105                	addi	sp,sp,32
    80003ce2:	8082                	ret

0000000080003ce4 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80003ce4:	1101                	addi	sp,sp,-32
    80003ce6:	ec06                	sd	ra,24(sp)
    80003ce8:	e822                	sd	s0,16(sp)
    80003cea:	e426                	sd	s1,8(sp)
    80003cec:	e04a                	sd	s2,0(sp)
    80003cee:	1000                	addi	s0,sp,32
    80003cf0:	84aa                	mv	s1,a0
    80003cf2:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80003cf4:	00004597          	auipc	a1,0x4
    80003cf8:	8b458593          	addi	a1,a1,-1868 # 800075a8 <etext+0x5a8>
    80003cfc:	0521                	addi	a0,a0,8
    80003cfe:	eddfc0ef          	jal	80000bda <initlock>
  lk->name = name;
    80003d02:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80003d06:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003d0a:	0204a423          	sw	zero,40(s1)
}
    80003d0e:	60e2                	ld	ra,24(sp)
    80003d10:	6442                	ld	s0,16(sp)
    80003d12:	64a2                	ld	s1,8(sp)
    80003d14:	6902                	ld	s2,0(sp)
    80003d16:	6105                	addi	sp,sp,32
    80003d18:	8082                	ret

0000000080003d1a <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80003d1a:	1101                	addi	sp,sp,-32
    80003d1c:	ec06                	sd	ra,24(sp)
    80003d1e:	e822                	sd	s0,16(sp)
    80003d20:	e426                	sd	s1,8(sp)
    80003d22:	e04a                	sd	s2,0(sp)
    80003d24:	1000                	addi	s0,sp,32
    80003d26:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003d28:	00850913          	addi	s2,a0,8
    80003d2c:	854a                	mv	a0,s2
    80003d2e:	f37fc0ef          	jal	80000c64 <acquire>
  while (lk->locked) {
    80003d32:	409c                	lw	a5,0(s1)
    80003d34:	c799                	beqz	a5,80003d42 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    80003d36:	85ca                	mv	a1,s2
    80003d38:	8526                	mv	a0,s1
    80003d3a:	9a6fe0ef          	jal	80001ee0 <sleep>
  while (lk->locked) {
    80003d3e:	409c                	lw	a5,0(s1)
    80003d40:	fbfd                	bnez	a5,80003d36 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80003d42:	4785                	li	a5,1
    80003d44:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80003d46:	bdffd0ef          	jal	80001924 <myproc>
    80003d4a:	591c                	lw	a5,48(a0)
    80003d4c:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80003d4e:	854a                	mv	a0,s2
    80003d50:	fa5fc0ef          	jal	80000cf4 <release>
}
    80003d54:	60e2                	ld	ra,24(sp)
    80003d56:	6442                	ld	s0,16(sp)
    80003d58:	64a2                	ld	s1,8(sp)
    80003d5a:	6902                	ld	s2,0(sp)
    80003d5c:	6105                	addi	sp,sp,32
    80003d5e:	8082                	ret

0000000080003d60 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80003d60:	1101                	addi	sp,sp,-32
    80003d62:	ec06                	sd	ra,24(sp)
    80003d64:	e822                	sd	s0,16(sp)
    80003d66:	e426                	sd	s1,8(sp)
    80003d68:	e04a                	sd	s2,0(sp)
    80003d6a:	1000                	addi	s0,sp,32
    80003d6c:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003d6e:	00850913          	addi	s2,a0,8
    80003d72:	854a                	mv	a0,s2
    80003d74:	ef1fc0ef          	jal	80000c64 <acquire>
  lk->locked = 0;
    80003d78:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003d7c:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80003d80:	8526                	mv	a0,s1
    80003d82:	9aafe0ef          	jal	80001f2c <wakeup>
  release(&lk->lk);
    80003d86:	854a                	mv	a0,s2
    80003d88:	f6dfc0ef          	jal	80000cf4 <release>
}
    80003d8c:	60e2                	ld	ra,24(sp)
    80003d8e:	6442                	ld	s0,16(sp)
    80003d90:	64a2                	ld	s1,8(sp)
    80003d92:	6902                	ld	s2,0(sp)
    80003d94:	6105                	addi	sp,sp,32
    80003d96:	8082                	ret

0000000080003d98 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80003d98:	7179                	addi	sp,sp,-48
    80003d9a:	f406                	sd	ra,40(sp)
    80003d9c:	f022                	sd	s0,32(sp)
    80003d9e:	ec26                	sd	s1,24(sp)
    80003da0:	e84a                	sd	s2,16(sp)
    80003da2:	1800                	addi	s0,sp,48
    80003da4:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    80003da6:	00850913          	addi	s2,a0,8
    80003daa:	854a                	mv	a0,s2
    80003dac:	eb9fc0ef          	jal	80000c64 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80003db0:	409c                	lw	a5,0(s1)
    80003db2:	ef81                	bnez	a5,80003dca <holdingsleep+0x32>
    80003db4:	4481                	li	s1,0
  release(&lk->lk);
    80003db6:	854a                	mv	a0,s2
    80003db8:	f3dfc0ef          	jal	80000cf4 <release>
  return r;
}
    80003dbc:	8526                	mv	a0,s1
    80003dbe:	70a2                	ld	ra,40(sp)
    80003dc0:	7402                	ld	s0,32(sp)
    80003dc2:	64e2                	ld	s1,24(sp)
    80003dc4:	6942                	ld	s2,16(sp)
    80003dc6:	6145                	addi	sp,sp,48
    80003dc8:	8082                	ret
    80003dca:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80003dcc:	0284a983          	lw	s3,40(s1)
    80003dd0:	b55fd0ef          	jal	80001924 <myproc>
    80003dd4:	5904                	lw	s1,48(a0)
    80003dd6:	413484b3          	sub	s1,s1,s3
    80003dda:	0014b493          	seqz	s1,s1
    80003dde:	69a2                	ld	s3,8(sp)
    80003de0:	bfd9                	j	80003db6 <holdingsleep+0x1e>

0000000080003de2 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80003de2:	1141                	addi	sp,sp,-16
    80003de4:	e406                	sd	ra,8(sp)
    80003de6:	e022                	sd	s0,0(sp)
    80003de8:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80003dea:	00003597          	auipc	a1,0x3
    80003dee:	7ce58593          	addi	a1,a1,1998 # 800075b8 <etext+0x5b8>
    80003df2:	0001c517          	auipc	a0,0x1c
    80003df6:	d5650513          	addi	a0,a0,-682 # 8001fb48 <ftable>
    80003dfa:	de1fc0ef          	jal	80000bda <initlock>
}
    80003dfe:	60a2                	ld	ra,8(sp)
    80003e00:	6402                	ld	s0,0(sp)
    80003e02:	0141                	addi	sp,sp,16
    80003e04:	8082                	ret

0000000080003e06 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    80003e06:	1101                	addi	sp,sp,-32
    80003e08:	ec06                	sd	ra,24(sp)
    80003e0a:	e822                	sd	s0,16(sp)
    80003e0c:	e426                	sd	s1,8(sp)
    80003e0e:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80003e10:	0001c517          	auipc	a0,0x1c
    80003e14:	d3850513          	addi	a0,a0,-712 # 8001fb48 <ftable>
    80003e18:	e4dfc0ef          	jal	80000c64 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003e1c:	0001c497          	auipc	s1,0x1c
    80003e20:	d4448493          	addi	s1,s1,-700 # 8001fb60 <ftable+0x18>
    80003e24:	0001d717          	auipc	a4,0x1d
    80003e28:	cdc70713          	addi	a4,a4,-804 # 80020b00 <disk>
    if(f->ref == 0){
    80003e2c:	40dc                	lw	a5,4(s1)
    80003e2e:	cf89                	beqz	a5,80003e48 <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003e30:	02848493          	addi	s1,s1,40
    80003e34:	fee49ce3          	bne	s1,a4,80003e2c <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80003e38:	0001c517          	auipc	a0,0x1c
    80003e3c:	d1050513          	addi	a0,a0,-752 # 8001fb48 <ftable>
    80003e40:	eb5fc0ef          	jal	80000cf4 <release>
  return 0;
    80003e44:	4481                	li	s1,0
    80003e46:	a809                	j	80003e58 <filealloc+0x52>
      f->ref = 1;
    80003e48:	4785                	li	a5,1
    80003e4a:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80003e4c:	0001c517          	auipc	a0,0x1c
    80003e50:	cfc50513          	addi	a0,a0,-772 # 8001fb48 <ftable>
    80003e54:	ea1fc0ef          	jal	80000cf4 <release>
}
    80003e58:	8526                	mv	a0,s1
    80003e5a:	60e2                	ld	ra,24(sp)
    80003e5c:	6442                	ld	s0,16(sp)
    80003e5e:	64a2                	ld	s1,8(sp)
    80003e60:	6105                	addi	sp,sp,32
    80003e62:	8082                	ret

0000000080003e64 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80003e64:	1101                	addi	sp,sp,-32
    80003e66:	ec06                	sd	ra,24(sp)
    80003e68:	e822                	sd	s0,16(sp)
    80003e6a:	e426                	sd	s1,8(sp)
    80003e6c:	1000                	addi	s0,sp,32
    80003e6e:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80003e70:	0001c517          	auipc	a0,0x1c
    80003e74:	cd850513          	addi	a0,a0,-808 # 8001fb48 <ftable>
    80003e78:	dedfc0ef          	jal	80000c64 <acquire>
  if(f->ref < 1)
    80003e7c:	40dc                	lw	a5,4(s1)
    80003e7e:	02f05063          	blez	a5,80003e9e <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80003e82:	2785                	addiw	a5,a5,1
    80003e84:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80003e86:	0001c517          	auipc	a0,0x1c
    80003e8a:	cc250513          	addi	a0,a0,-830 # 8001fb48 <ftable>
    80003e8e:	e67fc0ef          	jal	80000cf4 <release>
  return f;
}
    80003e92:	8526                	mv	a0,s1
    80003e94:	60e2                	ld	ra,24(sp)
    80003e96:	6442                	ld	s0,16(sp)
    80003e98:	64a2                	ld	s1,8(sp)
    80003e9a:	6105                	addi	sp,sp,32
    80003e9c:	8082                	ret
    panic("filedup");
    80003e9e:	00003517          	auipc	a0,0x3
    80003ea2:	72250513          	addi	a0,a0,1826 # 800075c0 <etext+0x5c0>
    80003ea6:	94bfc0ef          	jal	800007f0 <panic>

0000000080003eaa <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80003eaa:	7139                	addi	sp,sp,-64
    80003eac:	fc06                	sd	ra,56(sp)
    80003eae:	f822                	sd	s0,48(sp)
    80003eb0:	f426                	sd	s1,40(sp)
    80003eb2:	0080                	addi	s0,sp,64
    80003eb4:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80003eb6:	0001c517          	auipc	a0,0x1c
    80003eba:	c9250513          	addi	a0,a0,-878 # 8001fb48 <ftable>
    80003ebe:	da7fc0ef          	jal	80000c64 <acquire>
  if(f->ref < 1)
    80003ec2:	40dc                	lw	a5,4(s1)
    80003ec4:	04f05a63          	blez	a5,80003f18 <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    80003ec8:	37fd                	addiw	a5,a5,-1
    80003eca:	c0dc                	sw	a5,4(s1)
    80003ecc:	06f04063          	bgtz	a5,80003f2c <fileclose+0x82>
    80003ed0:	f04a                	sd	s2,32(sp)
    80003ed2:	ec4e                	sd	s3,24(sp)
    80003ed4:	e852                	sd	s4,16(sp)
    80003ed6:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80003ed8:	0004a903          	lw	s2,0(s1)
    80003edc:	0094c783          	lbu	a5,9(s1)
    80003ee0:	89be                	mv	s3,a5
    80003ee2:	689c                	ld	a5,16(s1)
    80003ee4:	8a3e                	mv	s4,a5
    80003ee6:	6c9c                	ld	a5,24(s1)
    80003ee8:	8abe                	mv	s5,a5
  f->ref = 0;
    80003eea:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80003eee:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80003ef2:	0001c517          	auipc	a0,0x1c
    80003ef6:	c5650513          	addi	a0,a0,-938 # 8001fb48 <ftable>
    80003efa:	dfbfc0ef          	jal	80000cf4 <release>

  if(ff.type == FD_PIPE){
    80003efe:	4785                	li	a5,1
    80003f00:	04f90163          	beq	s2,a5,80003f42 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    80003f04:	ffe9079b          	addiw	a5,s2,-2
    80003f08:	4705                	li	a4,1
    80003f0a:	04f77563          	bgeu	a4,a5,80003f54 <fileclose+0xaa>
    80003f0e:	7902                	ld	s2,32(sp)
    80003f10:	69e2                	ld	s3,24(sp)
    80003f12:	6a42                	ld	s4,16(sp)
    80003f14:	6aa2                	ld	s5,8(sp)
    80003f16:	a00d                	j	80003f38 <fileclose+0x8e>
    80003f18:	f04a                	sd	s2,32(sp)
    80003f1a:	ec4e                	sd	s3,24(sp)
    80003f1c:	e852                	sd	s4,16(sp)
    80003f1e:	e456                	sd	s5,8(sp)
    panic("fileclose");
    80003f20:	00003517          	auipc	a0,0x3
    80003f24:	6a850513          	addi	a0,a0,1704 # 800075c8 <etext+0x5c8>
    80003f28:	8c9fc0ef          	jal	800007f0 <panic>
    release(&ftable.lock);
    80003f2c:	0001c517          	auipc	a0,0x1c
    80003f30:	c1c50513          	addi	a0,a0,-996 # 8001fb48 <ftable>
    80003f34:	dc1fc0ef          	jal	80000cf4 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    80003f38:	70e2                	ld	ra,56(sp)
    80003f3a:	7442                	ld	s0,48(sp)
    80003f3c:	74a2                	ld	s1,40(sp)
    80003f3e:	6121                	addi	sp,sp,64
    80003f40:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80003f42:	85ce                	mv	a1,s3
    80003f44:	8552                	mv	a0,s4
    80003f46:	332000ef          	jal	80004278 <pipeclose>
    80003f4a:	7902                	ld	s2,32(sp)
    80003f4c:	69e2                	ld	s3,24(sp)
    80003f4e:	6a42                	ld	s4,16(sp)
    80003f50:	6aa2                	ld	s5,8(sp)
    80003f52:	b7dd                	j	80003f38 <fileclose+0x8e>
    begin_op();
    80003f54:	b29ff0ef          	jal	80003a7c <begin_op>
    iput(ff.ip);
    80003f58:	8556                	mv	a0,s5
    80003f5a:	be2ff0ef          	jal	8000333c <iput>
    end_op();
    80003f5e:	b8fff0ef          	jal	80003aec <end_op>
    80003f62:	7902                	ld	s2,32(sp)
    80003f64:	69e2                	ld	s3,24(sp)
    80003f66:	6a42                	ld	s4,16(sp)
    80003f68:	6aa2                	ld	s5,8(sp)
    80003f6a:	b7f9                	j	80003f38 <fileclose+0x8e>

0000000080003f6c <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80003f6c:	715d                	addi	sp,sp,-80
    80003f6e:	e486                	sd	ra,72(sp)
    80003f70:	e0a2                	sd	s0,64(sp)
    80003f72:	fc26                	sd	s1,56(sp)
    80003f74:	f052                	sd	s4,32(sp)
    80003f76:	0880                	addi	s0,sp,80
    80003f78:	84aa                	mv	s1,a0
    80003f7a:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    80003f7c:	9a9fd0ef          	jal	80001924 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80003f80:	409c                	lw	a5,0(s1)
    80003f82:	37f9                	addiw	a5,a5,-2
    80003f84:	4705                	li	a4,1
    80003f86:	04f76263          	bltu	a4,a5,80003fca <filestat+0x5e>
    80003f8a:	f84a                	sd	s2,48(sp)
    80003f8c:	f44e                	sd	s3,40(sp)
    80003f8e:	89aa                	mv	s3,a0
    ilock(f->ip);
    80003f90:	6c88                	ld	a0,24(s1)
    80003f92:	a28ff0ef          	jal	800031ba <ilock>
    stati(f->ip, &st);
    80003f96:	fb840913          	addi	s2,s0,-72
    80003f9a:	85ca                	mv	a1,s2
    80003f9c:	6c88                	ld	a0,24(s1)
    80003f9e:	c48ff0ef          	jal	800033e6 <stati>
    iunlock(f->ip);
    80003fa2:	6c88                	ld	a0,24(s1)
    80003fa4:	ac4ff0ef          	jal	80003268 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    80003fa8:	46e1                	li	a3,24
    80003faa:	864a                	mv	a2,s2
    80003fac:	85d2                	mv	a1,s4
    80003fae:	0509b503          	ld	a0,80(s3)
    80003fb2:	e02fd0ef          	jal	800015b4 <copyout>
    80003fb6:	41f5551b          	sraiw	a0,a0,0x1f
    80003fba:	7942                	ld	s2,48(sp)
    80003fbc:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80003fbe:	60a6                	ld	ra,72(sp)
    80003fc0:	6406                	ld	s0,64(sp)
    80003fc2:	74e2                	ld	s1,56(sp)
    80003fc4:	7a02                	ld	s4,32(sp)
    80003fc6:	6161                	addi	sp,sp,80
    80003fc8:	8082                	ret
  return -1;
    80003fca:	557d                	li	a0,-1
    80003fcc:	bfcd                	j	80003fbe <filestat+0x52>

0000000080003fce <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80003fce:	7179                	addi	sp,sp,-48
    80003fd0:	f406                	sd	ra,40(sp)
    80003fd2:	f022                	sd	s0,32(sp)
    80003fd4:	e84a                	sd	s2,16(sp)
    80003fd6:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80003fd8:	00854783          	lbu	a5,8(a0)
    80003fdc:	c3c5                	beqz	a5,8000407c <fileread+0xae>
    80003fde:	ec26                	sd	s1,24(sp)
    80003fe0:	e44e                	sd	s3,8(sp)
    80003fe2:	84aa                	mv	s1,a0
    80003fe4:	892e                	mv	s2,a1
    80003fe6:	89b2                	mv	s3,a2
    return -1;

  if(f->type == FD_PIPE){
    80003fe8:	411c                	lw	a5,0(a0)
    80003fea:	4705                	li	a4,1
    80003fec:	04e78363          	beq	a5,a4,80004032 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80003ff0:	470d                	li	a4,3
    80003ff2:	04e78763          	beq	a5,a4,80004040 <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    80003ff6:	4709                	li	a4,2
    80003ff8:	06e79a63          	bne	a5,a4,8000406c <fileread+0x9e>
    ilock(f->ip);
    80003ffc:	6d08                	ld	a0,24(a0)
    80003ffe:	9bcff0ef          	jal	800031ba <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004002:	874e                	mv	a4,s3
    80004004:	5094                	lw	a3,32(s1)
    80004006:	864a                	mv	a2,s2
    80004008:	4585                	li	a1,1
    8000400a:	6c88                	ld	a0,24(s1)
    8000400c:	c08ff0ef          	jal	80003414 <readi>
    80004010:	892a                	mv	s2,a0
    80004012:	00a05563          	blez	a0,8000401c <fileread+0x4e>
      f->off += r;
    80004016:	509c                	lw	a5,32(s1)
    80004018:	9fa9                	addw	a5,a5,a0
    8000401a:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    8000401c:	6c88                	ld	a0,24(s1)
    8000401e:	a4aff0ef          	jal	80003268 <iunlock>
    80004022:	64e2                	ld	s1,24(sp)
    80004024:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    80004026:	854a                	mv	a0,s2
    80004028:	70a2                	ld	ra,40(sp)
    8000402a:	7402                	ld	s0,32(sp)
    8000402c:	6942                	ld	s2,16(sp)
    8000402e:	6145                	addi	sp,sp,48
    80004030:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80004032:	6908                	ld	a0,16(a0)
    80004034:	39a000ef          	jal	800043ce <piperead>
    80004038:	892a                	mv	s2,a0
    8000403a:	64e2                	ld	s1,24(sp)
    8000403c:	69a2                	ld	s3,8(sp)
    8000403e:	b7e5                	j	80004026 <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80004040:	02451783          	lh	a5,36(a0)
    80004044:	03079693          	slli	a3,a5,0x30
    80004048:	92c1                	srli	a3,a3,0x30
    8000404a:	4725                	li	a4,9
    8000404c:	02d76663          	bltu	a4,a3,80004078 <fileread+0xaa>
    80004050:	0792                	slli	a5,a5,0x4
    80004052:	0001c717          	auipc	a4,0x1c
    80004056:	a5670713          	addi	a4,a4,-1450 # 8001faa8 <devsw>
    8000405a:	97ba                	add	a5,a5,a4
    8000405c:	639c                	ld	a5,0(a5)
    8000405e:	c395                	beqz	a5,80004082 <fileread+0xb4>
    r = devsw[f->major].read(1, addr, n);
    80004060:	4505                	li	a0,1
    80004062:	9782                	jalr	a5
    80004064:	892a                	mv	s2,a0
    80004066:	64e2                	ld	s1,24(sp)
    80004068:	69a2                	ld	s3,8(sp)
    8000406a:	bf75                	j	80004026 <fileread+0x58>
    panic("fileread");
    8000406c:	00003517          	auipc	a0,0x3
    80004070:	56c50513          	addi	a0,a0,1388 # 800075d8 <etext+0x5d8>
    80004074:	f7cfc0ef          	jal	800007f0 <panic>
    80004078:	64e2                	ld	s1,24(sp)
    8000407a:	69a2                	ld	s3,8(sp)
    return -1;
    8000407c:	57fd                	li	a5,-1
    8000407e:	893e                	mv	s2,a5
    80004080:	b75d                	j	80004026 <fileread+0x58>
    80004082:	64e2                	ld	s1,24(sp)
    80004084:	69a2                	ld	s3,8(sp)
    80004086:	bfdd                	j	8000407c <fileread+0xae>

0000000080004088 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    80004088:	00954783          	lbu	a5,9(a0)
    8000408c:	12078463          	beqz	a5,800041b4 <filewrite+0x12c>
{
    80004090:	711d                	addi	sp,sp,-96
    80004092:	ec86                	sd	ra,88(sp)
    80004094:	e8a2                	sd	s0,80(sp)
    80004096:	e0ca                	sd	s2,64(sp)
    80004098:	f456                	sd	s5,40(sp)
    8000409a:	f05a                	sd	s6,32(sp)
    8000409c:	1080                	addi	s0,sp,96
    8000409e:	892a                	mv	s2,a0
    800040a0:	8b2e                	mv	s6,a1
    800040a2:	8ab2                	mv	s5,a2
    return -1;

  if(f->type == FD_PIPE){
    800040a4:	411c                	lw	a5,0(a0)
    800040a6:	4705                	li	a4,1
    800040a8:	02e78a63          	beq	a5,a4,800040dc <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800040ac:	470d                	li	a4,3
    800040ae:	02e78b63          	beq	a5,a4,800040e4 <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800040b2:	4709                	li	a4,2
    800040b4:	0ce79f63          	bne	a5,a4,80004192 <filewrite+0x10a>
    800040b8:	f852                	sd	s4,48(sp)
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800040ba:	0ac05a63          	blez	a2,8000416e <filewrite+0xe6>
    800040be:	e4a6                	sd	s1,72(sp)
    800040c0:	fc4e                	sd	s3,56(sp)
    800040c2:	ec5e                	sd	s7,24(sp)
    800040c4:	e862                	sd	s8,16(sp)
    800040c6:	e466                	sd	s9,8(sp)
    int i = 0;
    800040c8:	4a01                	li	s4,0
      int n1 = n - i;
      if(n1 > max)
    800040ca:	6b85                	lui	s7,0x1
    800040cc:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    800040d0:	6785                	lui	a5,0x1
    800040d2:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    800040d6:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800040d8:	4c05                	li	s8,1
    800040da:	a8ad                	j	80004154 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    800040dc:	6908                	ld	a0,16(a0)
    800040de:	1f8000ef          	jal	800042d6 <pipewrite>
    800040e2:	a04d                	j	80004184 <filewrite+0xfc>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    800040e4:	02451783          	lh	a5,36(a0)
    800040e8:	03079693          	slli	a3,a5,0x30
    800040ec:	92c1                	srli	a3,a3,0x30
    800040ee:	4725                	li	a4,9
    800040f0:	0ad76d63          	bltu	a4,a3,800041aa <filewrite+0x122>
    800040f4:	0792                	slli	a5,a5,0x4
    800040f6:	0001c717          	auipc	a4,0x1c
    800040fa:	9b270713          	addi	a4,a4,-1614 # 8001faa8 <devsw>
    800040fe:	97ba                	add	a5,a5,a4
    80004100:	679c                	ld	a5,8(a5)
    80004102:	c7c5                	beqz	a5,800041aa <filewrite+0x122>
    ret = devsw[f->major].write(1, addr, n);
    80004104:	4505                	li	a0,1
    80004106:	9782                	jalr	a5
    80004108:	a8b5                	j	80004184 <filewrite+0xfc>
      if(n1 > max)
    8000410a:	2981                	sext.w	s3,s3
      begin_op();
    8000410c:	971ff0ef          	jal	80003a7c <begin_op>
      ilock(f->ip);
    80004110:	01893503          	ld	a0,24(s2)
    80004114:	8a6ff0ef          	jal	800031ba <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004118:	874e                	mv	a4,s3
    8000411a:	02092683          	lw	a3,32(s2)
    8000411e:	016a0633          	add	a2,s4,s6
    80004122:	85e2                	mv	a1,s8
    80004124:	01893503          	ld	a0,24(s2)
    80004128:	bdeff0ef          	jal	80003506 <writei>
    8000412c:	84aa                	mv	s1,a0
    8000412e:	00a05763          	blez	a0,8000413c <filewrite+0xb4>
        f->off += r;
    80004132:	02092783          	lw	a5,32(s2)
    80004136:	9fa9                	addw	a5,a5,a0
    80004138:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    8000413c:	01893503          	ld	a0,24(s2)
    80004140:	928ff0ef          	jal	80003268 <iunlock>
      end_op();
    80004144:	9a9ff0ef          	jal	80003aec <end_op>

      if(r != n1){
    80004148:	02999563          	bne	s3,s1,80004172 <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    8000414c:	01448a3b          	addw	s4,s1,s4
    while(i < n){
    80004150:	015a5963          	bge	s4,s5,80004162 <filewrite+0xda>
      int n1 = n - i;
    80004154:	414a87bb          	subw	a5,s5,s4
    80004158:	89be                	mv	s3,a5
      if(n1 > max)
    8000415a:	fafbd8e3          	bge	s7,a5,8000410a <filewrite+0x82>
    8000415e:	89e6                	mv	s3,s9
    80004160:	b76d                	j	8000410a <filewrite+0x82>
    80004162:	64a6                	ld	s1,72(sp)
    80004164:	79e2                	ld	s3,56(sp)
    80004166:	6be2                	ld	s7,24(sp)
    80004168:	6c42                	ld	s8,16(sp)
    8000416a:	6ca2                	ld	s9,8(sp)
    8000416c:	a801                	j	8000417c <filewrite+0xf4>
    int i = 0;
    8000416e:	4a01                	li	s4,0
    80004170:	a031                	j	8000417c <filewrite+0xf4>
    80004172:	64a6                	ld	s1,72(sp)
    80004174:	79e2                	ld	s3,56(sp)
    80004176:	6be2                	ld	s7,24(sp)
    80004178:	6c42                	ld	s8,16(sp)
    8000417a:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    8000417c:	034a9963          	bne	s5,s4,800041ae <filewrite+0x126>
    80004180:	8556                	mv	a0,s5
    80004182:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80004184:	60e6                	ld	ra,88(sp)
    80004186:	6446                	ld	s0,80(sp)
    80004188:	6906                	ld	s2,64(sp)
    8000418a:	7aa2                	ld	s5,40(sp)
    8000418c:	7b02                	ld	s6,32(sp)
    8000418e:	6125                	addi	sp,sp,96
    80004190:	8082                	ret
    80004192:	e4a6                	sd	s1,72(sp)
    80004194:	fc4e                	sd	s3,56(sp)
    80004196:	f852                	sd	s4,48(sp)
    80004198:	ec5e                	sd	s7,24(sp)
    8000419a:	e862                	sd	s8,16(sp)
    8000419c:	e466                	sd	s9,8(sp)
    panic("filewrite");
    8000419e:	00003517          	auipc	a0,0x3
    800041a2:	44a50513          	addi	a0,a0,1098 # 800075e8 <etext+0x5e8>
    800041a6:	e4afc0ef          	jal	800007f0 <panic>
    return -1;
    800041aa:	557d                	li	a0,-1
    800041ac:	bfe1                	j	80004184 <filewrite+0xfc>
    ret = (i == n ? n : -1);
    800041ae:	557d                	li	a0,-1
    800041b0:	7a42                	ld	s4,48(sp)
    800041b2:	bfc9                	j	80004184 <filewrite+0xfc>
    return -1;
    800041b4:	557d                	li	a0,-1
}
    800041b6:	8082                	ret

00000000800041b8 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800041b8:	7179                	addi	sp,sp,-48
    800041ba:	f406                	sd	ra,40(sp)
    800041bc:	f022                	sd	s0,32(sp)
    800041be:	ec26                	sd	s1,24(sp)
    800041c0:	e052                	sd	s4,0(sp)
    800041c2:	1800                	addi	s0,sp,48
    800041c4:	84aa                	mv	s1,a0
    800041c6:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800041c8:	0005b023          	sd	zero,0(a1)
    800041cc:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800041d0:	c37ff0ef          	jal	80003e06 <filealloc>
    800041d4:	e088                	sd	a0,0(s1)
    800041d6:	c549                	beqz	a0,80004260 <pipealloc+0xa8>
    800041d8:	c2fff0ef          	jal	80003e06 <filealloc>
    800041dc:	00aa3023          	sd	a0,0(s4)
    800041e0:	cd25                	beqz	a0,80004258 <pipealloc+0xa0>
    800041e2:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    800041e4:	99dfc0ef          	jal	80000b80 <kalloc>
    800041e8:	892a                	mv	s2,a0
    800041ea:	c12d                	beqz	a0,8000424c <pipealloc+0x94>
    800041ec:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    800041ee:	4985                	li	s3,1
    800041f0:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    800041f4:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    800041f8:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    800041fc:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004200:	00003597          	auipc	a1,0x3
    80004204:	3f858593          	addi	a1,a1,1016 # 800075f8 <etext+0x5f8>
    80004208:	9d3fc0ef          	jal	80000bda <initlock>
  (*f0)->type = FD_PIPE;
    8000420c:	609c                	ld	a5,0(s1)
    8000420e:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80004212:	609c                	ld	a5,0(s1)
    80004214:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004218:	609c                	ld	a5,0(s1)
    8000421a:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    8000421e:	609c                	ld	a5,0(s1)
    80004220:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004224:	000a3783          	ld	a5,0(s4)
    80004228:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    8000422c:	000a3783          	ld	a5,0(s4)
    80004230:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004234:	000a3783          	ld	a5,0(s4)
    80004238:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    8000423c:	000a3783          	ld	a5,0(s4)
    80004240:	0127b823          	sd	s2,16(a5)
  return 0;
    80004244:	4501                	li	a0,0
    80004246:	6942                	ld	s2,16(sp)
    80004248:	69a2                	ld	s3,8(sp)
    8000424a:	a00d                	j	8000426c <pipealloc+0xb4>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    8000424c:	6088                	ld	a0,0(s1)
    8000424e:	c119                	beqz	a0,80004254 <pipealloc+0x9c>
    80004250:	6942                	ld	s2,16(sp)
    80004252:	a029                	j	8000425c <pipealloc+0xa4>
    80004254:	6942                	ld	s2,16(sp)
    80004256:	a029                	j	80004260 <pipealloc+0xa8>
    80004258:	6088                	ld	a0,0(s1)
    8000425a:	c901                	beqz	a0,8000426a <pipealloc+0xb2>
    fileclose(*f0);
    8000425c:	c4fff0ef          	jal	80003eaa <fileclose>
  if(*f1)
    80004260:	000a3503          	ld	a0,0(s4)
    80004264:	c119                	beqz	a0,8000426a <pipealloc+0xb2>
    fileclose(*f1);
    80004266:	c45ff0ef          	jal	80003eaa <fileclose>
  return -1;
    8000426a:	557d                	li	a0,-1
}
    8000426c:	70a2                	ld	ra,40(sp)
    8000426e:	7402                	ld	s0,32(sp)
    80004270:	64e2                	ld	s1,24(sp)
    80004272:	6a02                	ld	s4,0(sp)
    80004274:	6145                	addi	sp,sp,48
    80004276:	8082                	ret

0000000080004278 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004278:	1101                	addi	sp,sp,-32
    8000427a:	ec06                	sd	ra,24(sp)
    8000427c:	e822                	sd	s0,16(sp)
    8000427e:	e426                	sd	s1,8(sp)
    80004280:	e04a                	sd	s2,0(sp)
    80004282:	1000                	addi	s0,sp,32
    80004284:	84aa                	mv	s1,a0
    80004286:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004288:	9ddfc0ef          	jal	80000c64 <acquire>
  if(writable){
    8000428c:	02090763          	beqz	s2,800042ba <pipeclose+0x42>
    pi->writeopen = 0;
    80004290:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004294:	21848513          	addi	a0,s1,536
    80004298:	c95fd0ef          	jal	80001f2c <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    8000429c:	2204a783          	lw	a5,544(s1)
    800042a0:	e781                	bnez	a5,800042a8 <pipeclose+0x30>
    800042a2:	2244a783          	lw	a5,548(s1)
    800042a6:	c38d                	beqz	a5,800042c8 <pipeclose+0x50>
    release(&pi->lock);
    kfree((char*)pi);
  } else
    release(&pi->lock);
    800042a8:	8526                	mv	a0,s1
    800042aa:	a4bfc0ef          	jal	80000cf4 <release>
}
    800042ae:	60e2                	ld	ra,24(sp)
    800042b0:	6442                	ld	s0,16(sp)
    800042b2:	64a2                	ld	s1,8(sp)
    800042b4:	6902                	ld	s2,0(sp)
    800042b6:	6105                	addi	sp,sp,32
    800042b8:	8082                	ret
    pi->readopen = 0;
    800042ba:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    800042be:	21c48513          	addi	a0,s1,540
    800042c2:	c6bfd0ef          	jal	80001f2c <wakeup>
    800042c6:	bfd9                	j	8000429c <pipeclose+0x24>
    release(&pi->lock);
    800042c8:	8526                	mv	a0,s1
    800042ca:	a2bfc0ef          	jal	80000cf4 <release>
    kfree((char*)pi);
    800042ce:	8526                	mv	a0,s1
    800042d0:	fc8fc0ef          	jal	80000a98 <kfree>
    800042d4:	bfe9                	j	800042ae <pipeclose+0x36>

00000000800042d6 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800042d6:	7159                	addi	sp,sp,-112
    800042d8:	f486                	sd	ra,104(sp)
    800042da:	f0a2                	sd	s0,96(sp)
    800042dc:	eca6                	sd	s1,88(sp)
    800042de:	e8ca                	sd	s2,80(sp)
    800042e0:	e4ce                	sd	s3,72(sp)
    800042e2:	e0d2                	sd	s4,64(sp)
    800042e4:	fc56                	sd	s5,56(sp)
    800042e6:	1880                	addi	s0,sp,112
    800042e8:	84aa                	mv	s1,a0
    800042ea:	8aae                	mv	s5,a1
    800042ec:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    800042ee:	e36fd0ef          	jal	80001924 <myproc>
    800042f2:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    800042f4:	8526                	mv	a0,s1
    800042f6:	96ffc0ef          	jal	80000c64 <acquire>
  while(i < n){
    800042fa:	0d405263          	blez	s4,800043be <pipewrite+0xe8>
    800042fe:	f85a                	sd	s6,48(sp)
    80004300:	f45e                	sd	s7,40(sp)
    80004302:	f062                	sd	s8,32(sp)
    80004304:	ec66                	sd	s9,24(sp)
    80004306:	e86a                	sd	s10,16(sp)
  int i = 0;
    80004308:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    8000430a:	f9f40c13          	addi	s8,s0,-97
    8000430e:	4b85                	li	s7,1
    80004310:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80004312:	21848d13          	addi	s10,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80004316:	21c48c93          	addi	s9,s1,540
    8000431a:	a82d                	j	80004354 <pipewrite+0x7e>
      release(&pi->lock);
    8000431c:	8526                	mv	a0,s1
    8000431e:	9d7fc0ef          	jal	80000cf4 <release>
      return -1;
    80004322:	597d                	li	s2,-1
    80004324:	7b42                	ld	s6,48(sp)
    80004326:	7ba2                	ld	s7,40(sp)
    80004328:	7c02                	ld	s8,32(sp)
    8000432a:	6ce2                	ld	s9,24(sp)
    8000432c:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    8000432e:	854a                	mv	a0,s2
    80004330:	70a6                	ld	ra,104(sp)
    80004332:	7406                	ld	s0,96(sp)
    80004334:	64e6                	ld	s1,88(sp)
    80004336:	6946                	ld	s2,80(sp)
    80004338:	69a6                	ld	s3,72(sp)
    8000433a:	6a06                	ld	s4,64(sp)
    8000433c:	7ae2                	ld	s5,56(sp)
    8000433e:	6165                	addi	sp,sp,112
    80004340:	8082                	ret
      wakeup(&pi->nread);
    80004342:	856a                	mv	a0,s10
    80004344:	be9fd0ef          	jal	80001f2c <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80004348:	85a6                	mv	a1,s1
    8000434a:	8566                	mv	a0,s9
    8000434c:	b95fd0ef          	jal	80001ee0 <sleep>
  while(i < n){
    80004350:	05495a63          	bge	s2,s4,800043a4 <pipewrite+0xce>
    if(pi->readopen == 0 || killed(pr)){
    80004354:	2204a783          	lw	a5,544(s1)
    80004358:	d3f1                	beqz	a5,8000431c <pipewrite+0x46>
    8000435a:	854e                	mv	a0,s3
    8000435c:	dc1fd0ef          	jal	8000211c <killed>
    80004360:	fd55                	bnez	a0,8000431c <pipewrite+0x46>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80004362:	2184a783          	lw	a5,536(s1)
    80004366:	21c4a703          	lw	a4,540(s1)
    8000436a:	2007879b          	addiw	a5,a5,512
    8000436e:	fcf70ae3          	beq	a4,a5,80004342 <pipewrite+0x6c>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004372:	86de                	mv	a3,s7
    80004374:	01590633          	add	a2,s2,s5
    80004378:	85e2                	mv	a1,s8
    8000437a:	0509b503          	ld	a0,80(s3)
    8000437e:	ae4fd0ef          	jal	80001662 <copyin>
    80004382:	05650063          	beq	a0,s6,800043c2 <pipewrite+0xec>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004386:	21c4a783          	lw	a5,540(s1)
    8000438a:	0017871b          	addiw	a4,a5,1
    8000438e:	20e4ae23          	sw	a4,540(s1)
    80004392:	1ff7f793          	andi	a5,a5,511
    80004396:	97a6                	add	a5,a5,s1
    80004398:	f9f44703          	lbu	a4,-97(s0)
    8000439c:	00e78c23          	sb	a4,24(a5)
      i++;
    800043a0:	2905                	addiw	s2,s2,1
    800043a2:	b77d                	j	80004350 <pipewrite+0x7a>
    800043a4:	7b42                	ld	s6,48(sp)
    800043a6:	7ba2                	ld	s7,40(sp)
    800043a8:	7c02                	ld	s8,32(sp)
    800043aa:	6ce2                	ld	s9,24(sp)
    800043ac:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    800043ae:	21848513          	addi	a0,s1,536
    800043b2:	b7bfd0ef          	jal	80001f2c <wakeup>
  release(&pi->lock);
    800043b6:	8526                	mv	a0,s1
    800043b8:	93dfc0ef          	jal	80000cf4 <release>
  return i;
    800043bc:	bf8d                	j	8000432e <pipewrite+0x58>
  int i = 0;
    800043be:	4901                	li	s2,0
    800043c0:	b7fd                	j	800043ae <pipewrite+0xd8>
    800043c2:	7b42                	ld	s6,48(sp)
    800043c4:	7ba2                	ld	s7,40(sp)
    800043c6:	7c02                	ld	s8,32(sp)
    800043c8:	6ce2                	ld	s9,24(sp)
    800043ca:	6d42                	ld	s10,16(sp)
    800043cc:	b7cd                	j	800043ae <pipewrite+0xd8>

00000000800043ce <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    800043ce:	711d                	addi	sp,sp,-96
    800043d0:	ec86                	sd	ra,88(sp)
    800043d2:	e8a2                	sd	s0,80(sp)
    800043d4:	e4a6                	sd	s1,72(sp)
    800043d6:	e0ca                	sd	s2,64(sp)
    800043d8:	fc4e                	sd	s3,56(sp)
    800043da:	f852                	sd	s4,48(sp)
    800043dc:	f456                	sd	s5,40(sp)
    800043de:	1080                	addi	s0,sp,96
    800043e0:	84aa                	mv	s1,a0
    800043e2:	892e                	mv	s2,a1
    800043e4:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    800043e6:	d3efd0ef          	jal	80001924 <myproc>
    800043ea:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    800043ec:	8526                	mv	a0,s1
    800043ee:	877fc0ef          	jal	80000c64 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800043f2:	2184a703          	lw	a4,536(s1)
    800043f6:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800043fa:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800043fe:	02f71363          	bne	a4,a5,80004424 <piperead+0x56>
    80004402:	2244a783          	lw	a5,548(s1)
    80004406:	cf99                	beqz	a5,80004424 <piperead+0x56>
    if(killed(pr)){
    80004408:	8552                	mv	a0,s4
    8000440a:	d13fd0ef          	jal	8000211c <killed>
    8000440e:	e53d                	bnez	a0,8000447c <piperead+0xae>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004410:	85a6                	mv	a1,s1
    80004412:	854e                	mv	a0,s3
    80004414:	acdfd0ef          	jal	80001ee0 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004418:	2184a703          	lw	a4,536(s1)
    8000441c:	21c4a783          	lw	a5,540(s1)
    80004420:	fef701e3          	beq	a4,a5,80004402 <piperead+0x34>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004424:	07505163          	blez	s5,80004486 <piperead+0xb8>
    80004428:	f05a                	sd	s6,32(sp)
    8000442a:	ec5e                	sd	s7,24(sp)
    8000442c:	e862                	sd	s8,16(sp)
    8000442e:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004430:	faf40c13          	addi	s8,s0,-81
    80004434:	4b85                	li	s7,1
    80004436:	5b7d                	li	s6,-1
    if(pi->nread == pi->nwrite)
    80004438:	2184a783          	lw	a5,536(s1)
    8000443c:	21c4a703          	lw	a4,540(s1)
    80004440:	04f70563          	beq	a4,a5,8000448a <piperead+0xbc>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80004444:	0017871b          	addiw	a4,a5,1
    80004448:	20e4ac23          	sw	a4,536(s1)
    8000444c:	1ff7f793          	andi	a5,a5,511
    80004450:	97a6                	add	a5,a5,s1
    80004452:	0187c783          	lbu	a5,24(a5)
    80004456:	faf407a3          	sb	a5,-81(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    8000445a:	86de                	mv	a3,s7
    8000445c:	8662                	mv	a2,s8
    8000445e:	85ca                	mv	a1,s2
    80004460:	050a3503          	ld	a0,80(s4)
    80004464:	950fd0ef          	jal	800015b4 <copyout>
    80004468:	05650563          	beq	a0,s6,800044b2 <piperead+0xe4>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    8000446c:	2985                	addiw	s3,s3,1
    8000446e:	0905                	addi	s2,s2,1
    80004470:	fd3a94e3          	bne	s5,s3,80004438 <piperead+0x6a>
    80004474:	7b02                	ld	s6,32(sp)
    80004476:	6be2                	ld	s7,24(sp)
    80004478:	6c42                	ld	s8,16(sp)
    8000447a:	a819                	j	80004490 <piperead+0xc2>
      release(&pi->lock);
    8000447c:	8526                	mv	a0,s1
    8000447e:	877fc0ef          	jal	80000cf4 <release>
      return -1;
    80004482:	59fd                	li	s3,-1
    80004484:	a829                	j	8000449e <piperead+0xd0>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004486:	4981                	li	s3,0
    80004488:	a021                	j	80004490 <piperead+0xc2>
    8000448a:	7b02                	ld	s6,32(sp)
    8000448c:	6be2                	ld	s7,24(sp)
    8000448e:	6c42                	ld	s8,16(sp)
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80004490:	21c48513          	addi	a0,s1,540
    80004494:	a99fd0ef          	jal	80001f2c <wakeup>
  release(&pi->lock);
    80004498:	8526                	mv	a0,s1
    8000449a:	85bfc0ef          	jal	80000cf4 <release>
  return i;
}
    8000449e:	854e                	mv	a0,s3
    800044a0:	60e6                	ld	ra,88(sp)
    800044a2:	6446                	ld	s0,80(sp)
    800044a4:	64a6                	ld	s1,72(sp)
    800044a6:	6906                	ld	s2,64(sp)
    800044a8:	79e2                	ld	s3,56(sp)
    800044aa:	7a42                	ld	s4,48(sp)
    800044ac:	7aa2                	ld	s5,40(sp)
    800044ae:	6125                	addi	sp,sp,96
    800044b0:	8082                	ret
    800044b2:	7b02                	ld	s6,32(sp)
    800044b4:	6be2                	ld	s7,24(sp)
    800044b6:	6c42                	ld	s8,16(sp)
    800044b8:	bfe1                	j	80004490 <piperead+0xc2>

00000000800044ba <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    800044ba:	1141                	addi	sp,sp,-16
    800044bc:	e406                	sd	ra,8(sp)
    800044be:	e022                	sd	s0,0(sp)
    800044c0:	0800                	addi	s0,sp,16
    800044c2:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    800044c4:	0035151b          	slliw	a0,a0,0x3
    800044c8:	8921                	andi	a0,a0,8
      perm = PTE_X;
    if(flags & 0x2)
    800044ca:	8b89                	andi	a5,a5,2
    800044cc:	c399                	beqz	a5,800044d2 <flags2perm+0x18>
      perm |= PTE_W;
    800044ce:	00456513          	ori	a0,a0,4
    return perm;
}
    800044d2:	60a2                	ld	ra,8(sp)
    800044d4:	6402                	ld	s0,0(sp)
    800044d6:	0141                	addi	sp,sp,16
    800044d8:	8082                	ret

00000000800044da <exec>:

int
exec(char *path, char **argv)
{
    800044da:	df010113          	addi	sp,sp,-528
    800044de:	20113423          	sd	ra,520(sp)
    800044e2:	20813023          	sd	s0,512(sp)
    800044e6:	ffa6                	sd	s1,504(sp)
    800044e8:	fbca                	sd	s2,496(sp)
    800044ea:	0c00                	addi	s0,sp,528
    800044ec:	892a                	mv	s2,a0
    800044ee:	e0a43023          	sd	a0,-512(s0)
    800044f2:	deb43c23          	sd	a1,-520(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    800044f6:	c2efd0ef          	jal	80001924 <myproc>
    800044fa:	84aa                	mv	s1,a0

  begin_op();
    800044fc:	d80ff0ef          	jal	80003a7c <begin_op>

  if((ip = namei(path)) == 0){
    80004500:	854a                	mv	a0,s2
    80004502:	bb8ff0ef          	jal	800038ba <namei>
    80004506:	c931                	beqz	a0,8000455a <exec+0x80>
    80004508:	f3d2                	sd	s4,480(sp)
    8000450a:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    8000450c:	caffe0ef          	jal	800031ba <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004510:	04000713          	li	a4,64
    80004514:	4681                	li	a3,0
    80004516:	e5040613          	addi	a2,s0,-432
    8000451a:	4581                	li	a1,0
    8000451c:	8552                	mv	a0,s4
    8000451e:	ef7fe0ef          	jal	80003414 <readi>
    80004522:	04000793          	li	a5,64
    80004526:	00f51a63          	bne	a0,a5,8000453a <exec+0x60>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    8000452a:	e5042703          	lw	a4,-432(s0)
    8000452e:	464c47b7          	lui	a5,0x464c4
    80004532:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004536:	02f70563          	beq	a4,a5,80004560 <exec+0x86>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    8000453a:	8552                	mv	a0,s4
    8000453c:	e8bfe0ef          	jal	800033c6 <iunlockput>
    end_op();
    80004540:	dacff0ef          	jal	80003aec <end_op>
    80004544:	7a1e                	ld	s4,480(sp)
    return -1;
    80004546:	557d                	li	a0,-1
  }
  return -1;
}
    80004548:	20813083          	ld	ra,520(sp)
    8000454c:	20013403          	ld	s0,512(sp)
    80004550:	74fe                	ld	s1,504(sp)
    80004552:	795e                	ld	s2,496(sp)
    80004554:	21010113          	addi	sp,sp,528
    80004558:	8082                	ret
    end_op();
    8000455a:	d92ff0ef          	jal	80003aec <end_op>
    return -1;
    8000455e:	b7e5                	j	80004546 <exec+0x6c>
    80004560:	ebda                	sd	s6,464(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    80004562:	8526                	mv	a0,s1
    80004564:	c6afd0ef          	jal	800019ce <proc_pagetable>
    80004568:	8b2a                	mv	s6,a0
    8000456a:	26050063          	beqz	a0,800047ca <exec+0x2f0>
    8000456e:	f7ce                	sd	s3,488(sp)
    80004570:	efd6                	sd	s5,472(sp)
    80004572:	e7de                	sd	s7,456(sp)
    80004574:	e3e2                	sd	s8,448(sp)
    80004576:	ff66                	sd	s9,440(sp)
    80004578:	fb6a                	sd	s10,432(sp)
    8000457a:	f76e                	sd	s11,424(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    8000457c:	e8845783          	lhu	a5,-376(s0)
    80004580:	cff9                	beqz	a5,8000465e <exec+0x184>
    80004582:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004586:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004588:	4d01                	li	s10,0
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    8000458a:	03800d93          	li	s11,56

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    8000458e:	6c85                	lui	s9,0x1
    80004590:	6a85                	lui	s5,0x1
    80004592:	a085                	j	800045f2 <exec+0x118>
      panic("loadseg: address should exist");
    80004594:	00003517          	auipc	a0,0x3
    80004598:	06c50513          	addi	a0,a0,108 # 80007600 <etext+0x600>
    8000459c:	a54fc0ef          	jal	800007f0 <panic>
    if(sz - i < PGSIZE)
    800045a0:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    800045a2:	874a                	mv	a4,s2
    800045a4:	009b86bb          	addw	a3,s7,s1
    800045a8:	4581                	li	a1,0
    800045aa:	8552                	mv	a0,s4
    800045ac:	e69fe0ef          	jal	80003414 <readi>
    800045b0:	22a91163          	bne	s2,a0,800047d2 <exec+0x2f8>
  for(i = 0; i < sz; i += PGSIZE){
    800045b4:	009a84bb          	addw	s1,s5,s1
    800045b8:	0334f263          	bgeu	s1,s3,800045dc <exec+0x102>
    pa = walkaddr(pagetable, va + i);
    800045bc:	02049593          	slli	a1,s1,0x20
    800045c0:	9181                	srli	a1,a1,0x20
    800045c2:	95e2                	add	a1,a1,s8
    800045c4:	855a                	mv	a0,s6
    800045c6:	a8bfc0ef          	jal	80001050 <walkaddr>
    800045ca:	862a                	mv	a2,a0
    if(pa == 0)
    800045cc:	d561                	beqz	a0,80004594 <exec+0xba>
    if(sz - i < PGSIZE)
    800045ce:	409987bb          	subw	a5,s3,s1
    800045d2:	893e                	mv	s2,a5
    800045d4:	fcfcf6e3          	bgeu	s9,a5,800045a0 <exec+0xc6>
    800045d8:	8956                	mv	s2,s5
    800045da:	b7d9                	j	800045a0 <exec+0xc6>
    sz = sz1;
    800045dc:	df043903          	ld	s2,-528(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    800045e0:	2d05                	addiw	s10,s10,1
    800045e2:	e0843783          	ld	a5,-504(s0)
    800045e6:	0387869b          	addiw	a3,a5,56
    800045ea:	e8845783          	lhu	a5,-376(s0)
    800045ee:	06fd5963          	bge	s10,a5,80004660 <exec+0x186>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    800045f2:	e0d43423          	sd	a3,-504(s0)
    800045f6:	876e                	mv	a4,s11
    800045f8:	e1840613          	addi	a2,s0,-488
    800045fc:	4581                	li	a1,0
    800045fe:	8552                	mv	a0,s4
    80004600:	e15fe0ef          	jal	80003414 <readi>
    80004604:	1db51563          	bne	a0,s11,800047ce <exec+0x2f4>
    if(ph.type != ELF_PROG_LOAD)
    80004608:	e1842783          	lw	a5,-488(s0)
    8000460c:	4705                	li	a4,1
    8000460e:	fce799e3          	bne	a5,a4,800045e0 <exec+0x106>
    if(ph.memsz < ph.filesz)
    80004612:	e4043483          	ld	s1,-448(s0)
    80004616:	e3843783          	ld	a5,-456(s0)
    8000461a:	1af4ea63          	bltu	s1,a5,800047ce <exec+0x2f4>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    8000461e:	e2843783          	ld	a5,-472(s0)
    80004622:	94be                	add	s1,s1,a5
    80004624:	1af4e563          	bltu	s1,a5,800047ce <exec+0x2f4>
    if(ph.vaddr % PGSIZE != 0)
    80004628:	17d2                	slli	a5,a5,0x34
    8000462a:	1a079263          	bnez	a5,800047ce <exec+0x2f4>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    8000462e:	e1c42503          	lw	a0,-484(s0)
    80004632:	e89ff0ef          	jal	800044ba <flags2perm>
    80004636:	86aa                	mv	a3,a0
    80004638:	8626                	mv	a2,s1
    8000463a:	85ca                	mv	a1,s2
    8000463c:	855a                	mv	a0,s6
    8000463e:	d71fc0ef          	jal	800013ae <uvmalloc>
    80004642:	dea43823          	sd	a0,-528(s0)
    80004646:	18050463          	beqz	a0,800047ce <exec+0x2f4>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    8000464a:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    8000464e:	f80987e3          	beqz	s3,800045dc <exec+0x102>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004652:	e2843c03          	ld	s8,-472(s0)
    80004656:	e2042b83          	lw	s7,-480(s0)
  for(i = 0; i < sz; i += PGSIZE){
    8000465a:	4481                	li	s1,0
    8000465c:	b785                	j	800045bc <exec+0xe2>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    8000465e:	4901                	li	s2,0
  iunlockput(ip);
    80004660:	8552                	mv	a0,s4
    80004662:	d65fe0ef          	jal	800033c6 <iunlockput>
  end_op();
    80004666:	c86ff0ef          	jal	80003aec <end_op>
  p = myproc();
    8000466a:	abafd0ef          	jal	80001924 <myproc>
    8000466e:	89aa                	mv	s3,a0
  uint64 oldsz = p->sz;
    80004670:	04853a83          	ld	s5,72(a0)
  sz = PGROUNDUP(sz);
    80004674:	6485                	lui	s1,0x1
    80004676:	14fd                	addi	s1,s1,-1 # fff <_entry-0x7ffff001>
    80004678:	94ca                	add	s1,s1,s2
    8000467a:	77fd                	lui	a5,0xfffff
    8000467c:	8cfd                	and	s1,s1,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    8000467e:	4691                	li	a3,4
    80004680:	6609                	lui	a2,0x2
    80004682:	9626                	add	a2,a2,s1
    80004684:	85a6                	mv	a1,s1
    80004686:	855a                	mv	a0,s6
    80004688:	d27fc0ef          	jal	800013ae <uvmalloc>
    8000468c:	8a2a                	mv	s4,a0
    8000468e:	ed19                	bnez	a0,800046ac <exec+0x1d2>
    proc_freepagetable(pagetable, sz);
    80004690:	85a6                	mv	a1,s1
    80004692:	855a                	mv	a0,s6
    80004694:	bbcfd0ef          	jal	80001a50 <proc_freepagetable>
  if(ip){
    80004698:	79be                	ld	s3,488(sp)
    8000469a:	7a1e                	ld	s4,480(sp)
    8000469c:	6afe                	ld	s5,472(sp)
    8000469e:	6b5e                	ld	s6,464(sp)
    800046a0:	6bbe                	ld	s7,456(sp)
    800046a2:	6c1e                	ld	s8,448(sp)
    800046a4:	7cfa                	ld	s9,440(sp)
    800046a6:	7d5a                	ld	s10,432(sp)
    800046a8:	7dba                	ld	s11,424(sp)
    800046aa:	bd71                	j	80004546 <exec+0x6c>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    800046ac:	75f9                	lui	a1,0xffffe
    800046ae:	95aa                	add	a1,a1,a0
    800046b0:	855a                	mv	a0,s6
    800046b2:	ed9fc0ef          	jal	8000158a <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    800046b6:	7c7d                	lui	s8,0xfffff
    800046b8:	9c52                	add	s8,s8,s4
  for(argc = 0; argv[argc]; argc++) {
    800046ba:	df843783          	ld	a5,-520(s0)
    800046be:	6388                	ld	a0,0(a5)
  sp = sz;
    800046c0:	8952                	mv	s2,s4
  for(argc = 0; argv[argc]; argc++) {
    800046c2:	4481                	li	s1,0
    ustack[argc] = sp;
    800046c4:	e9040c93          	addi	s9,s0,-368
    if(argc >= MAXARG)
    800046c8:	02000d13          	li	s10,32
  for(argc = 0; argv[argc]; argc++) {
    800046cc:	cd21                	beqz	a0,80004724 <exec+0x24a>
    sp -= strlen(argv[argc]) + 1;
    800046ce:	fe2fc0ef          	jal	80000eb0 <strlen>
    800046d2:	0015079b          	addiw	a5,a0,1
    800046d6:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    800046da:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    800046de:	05896163          	bltu	s2,s8,80004720 <exec+0x246>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    800046e2:	df843d83          	ld	s11,-520(s0)
    800046e6:	000dbb83          	ld	s7,0(s11)
    800046ea:	855e                	mv	a0,s7
    800046ec:	fc4fc0ef          	jal	80000eb0 <strlen>
    800046f0:	0015069b          	addiw	a3,a0,1
    800046f4:	865e                	mv	a2,s7
    800046f6:	85ca                	mv	a1,s2
    800046f8:	855a                	mv	a0,s6
    800046fa:	ebbfc0ef          	jal	800015b4 <copyout>
    800046fe:	02054163          	bltz	a0,80004720 <exec+0x246>
    ustack[argc] = sp;
    80004702:	00349793          	slli	a5,s1,0x3
    80004706:	97e6                	add	a5,a5,s9
    80004708:	0127b023          	sd	s2,0(a5) # fffffffffffff000 <end+0xffffffff7ffde3c0>
  for(argc = 0; argv[argc]; argc++) {
    8000470c:	0485                	addi	s1,s1,1
    8000470e:	008d8793          	addi	a5,s11,8
    80004712:	def43c23          	sd	a5,-520(s0)
    80004716:	008db503          	ld	a0,8(s11)
    8000471a:	c509                	beqz	a0,80004724 <exec+0x24a>
    if(argc >= MAXARG)
    8000471c:	fba499e3          	bne	s1,s10,800046ce <exec+0x1f4>
  sz = sz1;
    80004720:	84d2                	mv	s1,s4
    80004722:	b7bd                	j	80004690 <exec+0x1b6>
  ustack[argc] = 0;
    80004724:	00349793          	slli	a5,s1,0x3
    80004728:	f9040713          	addi	a4,s0,-112
    8000472c:	97ba                	add	a5,a5,a4
    8000472e:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80004732:	00148693          	addi	a3,s1,1
    80004736:	068e                	slli	a3,a3,0x3
    80004738:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    8000473c:	ff097913          	andi	s2,s2,-16
  if(sp < stackbase)
    80004740:	ff8960e3          	bltu	s2,s8,80004720 <exec+0x246>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004744:	e9040613          	addi	a2,s0,-368
    80004748:	85ca                	mv	a1,s2
    8000474a:	855a                	mv	a0,s6
    8000474c:	e69fc0ef          	jal	800015b4 <copyout>
    80004750:	fc0548e3          	bltz	a0,80004720 <exec+0x246>
  p->trapframe->a1 = sp;
    80004754:	0589b783          	ld	a5,88(s3)
    80004758:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    8000475c:	e0043783          	ld	a5,-512(s0)
    80004760:	0007c703          	lbu	a4,0(a5)
    80004764:	cf11                	beqz	a4,80004780 <exec+0x2a6>
    80004766:	0785                	addi	a5,a5,1
    if(*s == '/')
    80004768:	02f00693          	li	a3,47
    8000476c:	a029                	j	80004776 <exec+0x29c>
  for(last=s=path; *s; s++)
    8000476e:	0785                	addi	a5,a5,1
    80004770:	fff7c703          	lbu	a4,-1(a5)
    80004774:	c711                	beqz	a4,80004780 <exec+0x2a6>
    if(*s == '/')
    80004776:	fed71ce3          	bne	a4,a3,8000476e <exec+0x294>
      last = s+1;
    8000477a:	e0f43023          	sd	a5,-512(s0)
    8000477e:	bfc5                	j	8000476e <exec+0x294>
  safestrcpy(p->name, last, sizeof(p->name));
    80004780:	4641                	li	a2,16
    80004782:	e0043583          	ld	a1,-512(s0)
    80004786:	15898513          	addi	a0,s3,344
    8000478a:	ef0fc0ef          	jal	80000e7a <safestrcpy>
  oldpagetable = p->pagetable;
    8000478e:	0509b503          	ld	a0,80(s3)
  p->pagetable = pagetable;
    80004792:	0569b823          	sd	s6,80(s3)
  p->sz = sz;
    80004796:	0549b423          	sd	s4,72(s3)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    8000479a:	0589b783          	ld	a5,88(s3)
    8000479e:	e6843703          	ld	a4,-408(s0)
    800047a2:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    800047a4:	0589b783          	ld	a5,88(s3)
    800047a8:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    800047ac:	85d6                	mv	a1,s5
    800047ae:	aa2fd0ef          	jal	80001a50 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    800047b2:	0004851b          	sext.w	a0,s1
    800047b6:	79be                	ld	s3,488(sp)
    800047b8:	7a1e                	ld	s4,480(sp)
    800047ba:	6afe                	ld	s5,472(sp)
    800047bc:	6b5e                	ld	s6,464(sp)
    800047be:	6bbe                	ld	s7,456(sp)
    800047c0:	6c1e                	ld	s8,448(sp)
    800047c2:	7cfa                	ld	s9,440(sp)
    800047c4:	7d5a                	ld	s10,432(sp)
    800047c6:	7dba                	ld	s11,424(sp)
    800047c8:	b341                	j	80004548 <exec+0x6e>
    800047ca:	6b5e                	ld	s6,464(sp)
    800047cc:	b3bd                	j	8000453a <exec+0x60>
    return -1;
    800047ce:	df243823          	sd	s2,-528(s0)
    proc_freepagetable(pagetable, sz);
    800047d2:	df043583          	ld	a1,-528(s0)
    800047d6:	855a                	mv	a0,s6
    800047d8:	a78fd0ef          	jal	80001a50 <proc_freepagetable>
  if(ip){
    800047dc:	79be                	ld	s3,488(sp)
    800047de:	6afe                	ld	s5,472(sp)
    800047e0:	6b5e                	ld	s6,464(sp)
    800047e2:	6bbe                	ld	s7,456(sp)
    800047e4:	6c1e                	ld	s8,448(sp)
    800047e6:	7cfa                	ld	s9,440(sp)
    800047e8:	7d5a                	ld	s10,432(sp)
    800047ea:	7dba                	ld	s11,424(sp)
    800047ec:	b3b9                	j	8000453a <exec+0x60>

00000000800047ee <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    800047ee:	7179                	addi	sp,sp,-48
    800047f0:	f406                	sd	ra,40(sp)
    800047f2:	f022                	sd	s0,32(sp)
    800047f4:	ec26                	sd	s1,24(sp)
    800047f6:	e84a                	sd	s2,16(sp)
    800047f8:	1800                	addi	s0,sp,48
    800047fa:	892e                	mv	s2,a1
    800047fc:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    800047fe:	fdc40593          	addi	a1,s0,-36
    80004802:	fbbfd0ef          	jal	800027bc <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80004806:	fdc42703          	lw	a4,-36(s0)
    8000480a:	47bd                	li	a5,15
    8000480c:	02e7e963          	bltu	a5,a4,8000483e <argfd+0x50>
    80004810:	914fd0ef          	jal	80001924 <myproc>
    80004814:	fdc42703          	lw	a4,-36(s0)
    80004818:	01a70793          	addi	a5,a4,26
    8000481c:	078e                	slli	a5,a5,0x3
    8000481e:	953e                	add	a0,a0,a5
    80004820:	611c                	ld	a5,0(a0)
    80004822:	cf91                	beqz	a5,8000483e <argfd+0x50>
    return -1;
  if(pfd)
    80004824:	00090463          	beqz	s2,8000482c <argfd+0x3e>
    *pfd = fd;
    80004828:	00e92023          	sw	a4,0(s2)
  if(pf)
    8000482c:	c091                	beqz	s1,80004830 <argfd+0x42>
    *pf = f;
    8000482e:	e09c                	sd	a5,0(s1)
  return 0;
    80004830:	4501                	li	a0,0
}
    80004832:	70a2                	ld	ra,40(sp)
    80004834:	7402                	ld	s0,32(sp)
    80004836:	64e2                	ld	s1,24(sp)
    80004838:	6942                	ld	s2,16(sp)
    8000483a:	6145                	addi	sp,sp,48
    8000483c:	8082                	ret
    return -1;
    8000483e:	557d                	li	a0,-1
    80004840:	bfcd                	j	80004832 <argfd+0x44>

0000000080004842 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004842:	1101                	addi	sp,sp,-32
    80004844:	ec06                	sd	ra,24(sp)
    80004846:	e822                	sd	s0,16(sp)
    80004848:	e426                	sd	s1,8(sp)
    8000484a:	1000                	addi	s0,sp,32
    8000484c:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    8000484e:	8d6fd0ef          	jal	80001924 <myproc>
    80004852:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80004854:	0d050793          	addi	a5,a0,208
    80004858:	4501                	li	a0,0
    8000485a:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    8000485c:	6398                	ld	a4,0(a5)
    8000485e:	cb19                	beqz	a4,80004874 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80004860:	2505                	addiw	a0,a0,1
    80004862:	07a1                	addi	a5,a5,8
    80004864:	fed51ce3          	bne	a0,a3,8000485c <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004868:	557d                	li	a0,-1
}
    8000486a:	60e2                	ld	ra,24(sp)
    8000486c:	6442                	ld	s0,16(sp)
    8000486e:	64a2                	ld	s1,8(sp)
    80004870:	6105                	addi	sp,sp,32
    80004872:	8082                	ret
      p->ofile[fd] = f;
    80004874:	01a50793          	addi	a5,a0,26
    80004878:	078e                	slli	a5,a5,0x3
    8000487a:	963e                	add	a2,a2,a5
    8000487c:	e204                	sd	s1,0(a2)
      return fd;
    8000487e:	b7f5                	j	8000486a <fdalloc+0x28>

0000000080004880 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80004880:	715d                	addi	sp,sp,-80
    80004882:	e486                	sd	ra,72(sp)
    80004884:	e0a2                	sd	s0,64(sp)
    80004886:	fc26                	sd	s1,56(sp)
    80004888:	f84a                	sd	s2,48(sp)
    8000488a:	f44e                	sd	s3,40(sp)
    8000488c:	f052                	sd	s4,32(sp)
    8000488e:	ec56                	sd	s5,24(sp)
    80004890:	e85a                	sd	s6,16(sp)
    80004892:	0880                	addi	s0,sp,80
    80004894:	892e                	mv	s2,a1
    80004896:	8a2e                	mv	s4,a1
    80004898:	8ab2                	mv	s5,a2
    8000489a:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    8000489c:	fb040593          	addi	a1,s0,-80
    800048a0:	834ff0ef          	jal	800038d4 <nameiparent>
    800048a4:	84aa                	mv	s1,a0
    return 0;
    800048a6:	89aa                	mv	s3,a0
  if((dp = nameiparent(path, name)) == 0)
    800048a8:	cd05                	beqz	a0,800048e0 <create+0x60>

  ilock(dp);
    800048aa:	911fe0ef          	jal	800031ba <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    800048ae:	4601                	li	a2,0
    800048b0:	fb040593          	addi	a1,s0,-80
    800048b4:	8526                	mv	a0,s1
    800048b6:	d69fe0ef          	jal	8000361e <dirlookup>
    800048ba:	89aa                	mv	s3,a0
    800048bc:	c131                	beqz	a0,80004900 <create+0x80>
    iunlockput(dp);
    800048be:	8526                	mv	a0,s1
    800048c0:	b07fe0ef          	jal	800033c6 <iunlockput>
    ilock(ip);
    800048c4:	854e                	mv	a0,s3
    800048c6:	8f5fe0ef          	jal	800031ba <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    800048ca:	4789                	li	a5,2
    800048cc:	02f91563          	bne	s2,a5,800048f6 <create+0x76>
    800048d0:	0449d783          	lhu	a5,68(s3)
    800048d4:	37f9                	addiw	a5,a5,-2
    800048d6:	17c2                	slli	a5,a5,0x30
    800048d8:	93c1                	srli	a5,a5,0x30
    800048da:	4705                	li	a4,1
    800048dc:	00f76d63          	bltu	a4,a5,800048f6 <create+0x76>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    800048e0:	854e                	mv	a0,s3
    800048e2:	60a6                	ld	ra,72(sp)
    800048e4:	6406                	ld	s0,64(sp)
    800048e6:	74e2                	ld	s1,56(sp)
    800048e8:	7942                	ld	s2,48(sp)
    800048ea:	79a2                	ld	s3,40(sp)
    800048ec:	7a02                	ld	s4,32(sp)
    800048ee:	6ae2                	ld	s5,24(sp)
    800048f0:	6b42                	ld	s6,16(sp)
    800048f2:	6161                	addi	sp,sp,80
    800048f4:	8082                	ret
    iunlockput(ip);
    800048f6:	854e                	mv	a0,s3
    800048f8:	acffe0ef          	jal	800033c6 <iunlockput>
    return 0;
    800048fc:	4981                	li	s3,0
    800048fe:	b7cd                	j	800048e0 <create+0x60>
  if((ip = ialloc(dp->dev, type)) == 0){
    80004900:	85ca                	mv	a1,s2
    80004902:	4088                	lw	a0,0(s1)
    80004904:	f46fe0ef          	jal	8000304a <ialloc>
    80004908:	892a                	mv	s2,a0
    8000490a:	cd15                	beqz	a0,80004946 <create+0xc6>
  ilock(ip);
    8000490c:	8affe0ef          	jal	800031ba <ilock>
  ip->major = major;
    80004910:	05591323          	sh	s5,70(s2)
  ip->minor = minor;
    80004914:	05691423          	sh	s6,72(s2)
  ip->nlink = 1;
    80004918:	4785                	li	a5,1
    8000491a:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    8000491e:	854a                	mv	a0,s2
    80004920:	fe6fe0ef          	jal	80003106 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80004924:	4705                	li	a4,1
    80004926:	02ea0463          	beq	s4,a4,8000494e <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    8000492a:	00492603          	lw	a2,4(s2)
    8000492e:	fb040593          	addi	a1,s0,-80
    80004932:	8526                	mv	a0,s1
    80004934:	eddfe0ef          	jal	80003810 <dirlink>
    80004938:	06054263          	bltz	a0,8000499c <create+0x11c>
  iunlockput(dp);
    8000493c:	8526                	mv	a0,s1
    8000493e:	a89fe0ef          	jal	800033c6 <iunlockput>
    return 0;
    80004942:	89ca                	mv	s3,s2
    80004944:	bf71                	j	800048e0 <create+0x60>
    iunlockput(dp);
    80004946:	8526                	mv	a0,s1
    80004948:	a7ffe0ef          	jal	800033c6 <iunlockput>
    return 0;
    8000494c:	bfdd                	j	80004942 <create+0xc2>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    8000494e:	00492603          	lw	a2,4(s2)
    80004952:	00003597          	auipc	a1,0x3
    80004956:	cce58593          	addi	a1,a1,-818 # 80007620 <etext+0x620>
    8000495a:	854a                	mv	a0,s2
    8000495c:	eb5fe0ef          	jal	80003810 <dirlink>
    80004960:	02054e63          	bltz	a0,8000499c <create+0x11c>
    80004964:	40d0                	lw	a2,4(s1)
    80004966:	00003597          	auipc	a1,0x3
    8000496a:	cc258593          	addi	a1,a1,-830 # 80007628 <etext+0x628>
    8000496e:	854a                	mv	a0,s2
    80004970:	ea1fe0ef          	jal	80003810 <dirlink>
    80004974:	02054463          	bltz	a0,8000499c <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    80004978:	00492603          	lw	a2,4(s2)
    8000497c:	fb040593          	addi	a1,s0,-80
    80004980:	8526                	mv	a0,s1
    80004982:	e8ffe0ef          	jal	80003810 <dirlink>
    80004986:	00054b63          	bltz	a0,8000499c <create+0x11c>
    dp->nlink++;  // for ".."
    8000498a:	04a4d783          	lhu	a5,74(s1)
    8000498e:	2785                	addiw	a5,a5,1
    80004990:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004994:	8526                	mv	a0,s1
    80004996:	f70fe0ef          	jal	80003106 <iupdate>
    8000499a:	b74d                	j	8000493c <create+0xbc>
  ip->nlink = 0;
    8000499c:	04091523          	sh	zero,74(s2)
  iupdate(ip);
    800049a0:	854a                	mv	a0,s2
    800049a2:	f64fe0ef          	jal	80003106 <iupdate>
  iunlockput(ip);
    800049a6:	854a                	mv	a0,s2
    800049a8:	a1ffe0ef          	jal	800033c6 <iunlockput>
  iunlockput(dp);
    800049ac:	8526                	mv	a0,s1
    800049ae:	a19fe0ef          	jal	800033c6 <iunlockput>
  return 0;
    800049b2:	b73d                	j	800048e0 <create+0x60>

00000000800049b4 <sys_dup>:
{
    800049b4:	7179                	addi	sp,sp,-48
    800049b6:	f406                	sd	ra,40(sp)
    800049b8:	f022                	sd	s0,32(sp)
    800049ba:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    800049bc:	fd840613          	addi	a2,s0,-40
    800049c0:	4581                	li	a1,0
    800049c2:	4501                	li	a0,0
    800049c4:	e2bff0ef          	jal	800047ee <argfd>
    800049c8:	02054863          	bltz	a0,800049f8 <sys_dup+0x44>
    800049cc:	ec26                	sd	s1,24(sp)
    800049ce:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    800049d0:	fd843483          	ld	s1,-40(s0)
    800049d4:	8526                	mv	a0,s1
    800049d6:	e6dff0ef          	jal	80004842 <fdalloc>
    800049da:	892a                	mv	s2,a0
    800049dc:	00054c63          	bltz	a0,800049f4 <sys_dup+0x40>
  filedup(f);
    800049e0:	8526                	mv	a0,s1
    800049e2:	c82ff0ef          	jal	80003e64 <filedup>
  return fd;
    800049e6:	854a                	mv	a0,s2
    800049e8:	64e2                	ld	s1,24(sp)
    800049ea:	6942                	ld	s2,16(sp)
}
    800049ec:	70a2                	ld	ra,40(sp)
    800049ee:	7402                	ld	s0,32(sp)
    800049f0:	6145                	addi	sp,sp,48
    800049f2:	8082                	ret
    800049f4:	64e2                	ld	s1,24(sp)
    800049f6:	6942                	ld	s2,16(sp)
    return -1;
    800049f8:	557d                	li	a0,-1
    800049fa:	bfcd                	j	800049ec <sys_dup+0x38>

00000000800049fc <sys_read>:
{
    800049fc:	7179                	addi	sp,sp,-48
    800049fe:	f406                	sd	ra,40(sp)
    80004a00:	f022                	sd	s0,32(sp)
    80004a02:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004a04:	fd840593          	addi	a1,s0,-40
    80004a08:	4505                	li	a0,1
    80004a0a:	dcffd0ef          	jal	800027d8 <argaddr>
  argint(2, &n);
    80004a0e:	fe440593          	addi	a1,s0,-28
    80004a12:	4509                	li	a0,2
    80004a14:	da9fd0ef          	jal	800027bc <argint>
  if(argfd(0, 0, &f) < 0)
    80004a18:	fe840613          	addi	a2,s0,-24
    80004a1c:	4581                	li	a1,0
    80004a1e:	4501                	li	a0,0
    80004a20:	dcfff0ef          	jal	800047ee <argfd>
    80004a24:	87aa                	mv	a5,a0
    return -1;
    80004a26:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004a28:	0007ca63          	bltz	a5,80004a3c <sys_read+0x40>
  return fileread(f, p, n);
    80004a2c:	fe442603          	lw	a2,-28(s0)
    80004a30:	fd843583          	ld	a1,-40(s0)
    80004a34:	fe843503          	ld	a0,-24(s0)
    80004a38:	d96ff0ef          	jal	80003fce <fileread>
}
    80004a3c:	70a2                	ld	ra,40(sp)
    80004a3e:	7402                	ld	s0,32(sp)
    80004a40:	6145                	addi	sp,sp,48
    80004a42:	8082                	ret

0000000080004a44 <sys_write>:
{
    80004a44:	7179                	addi	sp,sp,-48
    80004a46:	f406                	sd	ra,40(sp)
    80004a48:	f022                	sd	s0,32(sp)
    80004a4a:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004a4c:	fd840593          	addi	a1,s0,-40
    80004a50:	4505                	li	a0,1
    80004a52:	d87fd0ef          	jal	800027d8 <argaddr>
  argint(2, &n);
    80004a56:	fe440593          	addi	a1,s0,-28
    80004a5a:	4509                	li	a0,2
    80004a5c:	d61fd0ef          	jal	800027bc <argint>
  if(argfd(0, 0, &f) < 0)
    80004a60:	fe840613          	addi	a2,s0,-24
    80004a64:	4581                	li	a1,0
    80004a66:	4501                	li	a0,0
    80004a68:	d87ff0ef          	jal	800047ee <argfd>
    80004a6c:	87aa                	mv	a5,a0
    return -1;
    80004a6e:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004a70:	0007ca63          	bltz	a5,80004a84 <sys_write+0x40>
  return filewrite(f, p, n);
    80004a74:	fe442603          	lw	a2,-28(s0)
    80004a78:	fd843583          	ld	a1,-40(s0)
    80004a7c:	fe843503          	ld	a0,-24(s0)
    80004a80:	e08ff0ef          	jal	80004088 <filewrite>
}
    80004a84:	70a2                	ld	ra,40(sp)
    80004a86:	7402                	ld	s0,32(sp)
    80004a88:	6145                	addi	sp,sp,48
    80004a8a:	8082                	ret

0000000080004a8c <sys_close>:
{
    80004a8c:	1101                	addi	sp,sp,-32
    80004a8e:	ec06                	sd	ra,24(sp)
    80004a90:	e822                	sd	s0,16(sp)
    80004a92:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004a94:	fe040613          	addi	a2,s0,-32
    80004a98:	fec40593          	addi	a1,s0,-20
    80004a9c:	4501                	li	a0,0
    80004a9e:	d51ff0ef          	jal	800047ee <argfd>
    return -1;
    80004aa2:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004aa4:	02054063          	bltz	a0,80004ac4 <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    80004aa8:	e7dfc0ef          	jal	80001924 <myproc>
    80004aac:	fec42783          	lw	a5,-20(s0)
    80004ab0:	07e9                	addi	a5,a5,26
    80004ab2:	078e                	slli	a5,a5,0x3
    80004ab4:	953e                	add	a0,a0,a5
    80004ab6:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004aba:	fe043503          	ld	a0,-32(s0)
    80004abe:	becff0ef          	jal	80003eaa <fileclose>
  return 0;
    80004ac2:	4781                	li	a5,0
}
    80004ac4:	853e                	mv	a0,a5
    80004ac6:	60e2                	ld	ra,24(sp)
    80004ac8:	6442                	ld	s0,16(sp)
    80004aca:	6105                	addi	sp,sp,32
    80004acc:	8082                	ret

0000000080004ace <sys_fstat>:
{
    80004ace:	1101                	addi	sp,sp,-32
    80004ad0:	ec06                	sd	ra,24(sp)
    80004ad2:	e822                	sd	s0,16(sp)
    80004ad4:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004ad6:	fe040593          	addi	a1,s0,-32
    80004ada:	4505                	li	a0,1
    80004adc:	cfdfd0ef          	jal	800027d8 <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004ae0:	fe840613          	addi	a2,s0,-24
    80004ae4:	4581                	li	a1,0
    80004ae6:	4501                	li	a0,0
    80004ae8:	d07ff0ef          	jal	800047ee <argfd>
    80004aec:	87aa                	mv	a5,a0
    return -1;
    80004aee:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004af0:	0007c863          	bltz	a5,80004b00 <sys_fstat+0x32>
  return filestat(f, st);
    80004af4:	fe043583          	ld	a1,-32(s0)
    80004af8:	fe843503          	ld	a0,-24(s0)
    80004afc:	c70ff0ef          	jal	80003f6c <filestat>
}
    80004b00:	60e2                	ld	ra,24(sp)
    80004b02:	6442                	ld	s0,16(sp)
    80004b04:	6105                	addi	sp,sp,32
    80004b06:	8082                	ret

0000000080004b08 <sys_link>:
{
    80004b08:	7169                	addi	sp,sp,-304
    80004b0a:	f606                	sd	ra,296(sp)
    80004b0c:	f222                	sd	s0,288(sp)
    80004b0e:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004b10:	08000613          	li	a2,128
    80004b14:	ed040593          	addi	a1,s0,-304
    80004b18:	4501                	li	a0,0
    80004b1a:	cdbfd0ef          	jal	800027f4 <argstr>
    80004b1e:	0c054a63          	bltz	a0,80004bf2 <sys_link+0xea>
    80004b22:	08000613          	li	a2,128
    80004b26:	f5040593          	addi	a1,s0,-176
    80004b2a:	4505                	li	a0,1
    80004b2c:	cc9fd0ef          	jal	800027f4 <argstr>
    80004b30:	0c054163          	bltz	a0,80004bf2 <sys_link+0xea>
    80004b34:	ee26                	sd	s1,280(sp)
  begin_op();
    80004b36:	f47fe0ef          	jal	80003a7c <begin_op>
  if((ip = namei(old)) == 0){
    80004b3a:	ed040513          	addi	a0,s0,-304
    80004b3e:	d7dfe0ef          	jal	800038ba <namei>
    80004b42:	84aa                	mv	s1,a0
    80004b44:	c53d                	beqz	a0,80004bb2 <sys_link+0xaa>
  ilock(ip);
    80004b46:	e74fe0ef          	jal	800031ba <ilock>
  if(ip->type == T_DIR){
    80004b4a:	04449703          	lh	a4,68(s1)
    80004b4e:	4785                	li	a5,1
    80004b50:	06f70563          	beq	a4,a5,80004bba <sys_link+0xb2>
    80004b54:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004b56:	04a4d783          	lhu	a5,74(s1)
    80004b5a:	2785                	addiw	a5,a5,1
    80004b5c:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004b60:	8526                	mv	a0,s1
    80004b62:	da4fe0ef          	jal	80003106 <iupdate>
  iunlock(ip);
    80004b66:	8526                	mv	a0,s1
    80004b68:	f00fe0ef          	jal	80003268 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80004b6c:	fd040593          	addi	a1,s0,-48
    80004b70:	f5040513          	addi	a0,s0,-176
    80004b74:	d61fe0ef          	jal	800038d4 <nameiparent>
    80004b78:	892a                	mv	s2,a0
    80004b7a:	c931                	beqz	a0,80004bce <sys_link+0xc6>
  ilock(dp);
    80004b7c:	e3efe0ef          	jal	800031ba <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80004b80:	854a                	mv	a0,s2
    80004b82:	00092703          	lw	a4,0(s2)
    80004b86:	409c                	lw	a5,0(s1)
    80004b88:	04f71063          	bne	a4,a5,80004bc8 <sys_link+0xc0>
    80004b8c:	40d0                	lw	a2,4(s1)
    80004b8e:	fd040593          	addi	a1,s0,-48
    80004b92:	c7ffe0ef          	jal	80003810 <dirlink>
    80004b96:	02054963          	bltz	a0,80004bc8 <sys_link+0xc0>
  iunlockput(dp);
    80004b9a:	854a                	mv	a0,s2
    80004b9c:	82bfe0ef          	jal	800033c6 <iunlockput>
  iput(ip);
    80004ba0:	8526                	mv	a0,s1
    80004ba2:	f9afe0ef          	jal	8000333c <iput>
  end_op();
    80004ba6:	f47fe0ef          	jal	80003aec <end_op>
  return 0;
    80004baa:	4501                	li	a0,0
    80004bac:	64f2                	ld	s1,280(sp)
    80004bae:	6952                	ld	s2,272(sp)
    80004bb0:	a091                	j	80004bf4 <sys_link+0xec>
    end_op();
    80004bb2:	f3bfe0ef          	jal	80003aec <end_op>
    return -1;
    80004bb6:	64f2                	ld	s1,280(sp)
    80004bb8:	a82d                	j	80004bf2 <sys_link+0xea>
    iunlockput(ip);
    80004bba:	8526                	mv	a0,s1
    80004bbc:	80bfe0ef          	jal	800033c6 <iunlockput>
    end_op();
    80004bc0:	f2dfe0ef          	jal	80003aec <end_op>
    return -1;
    80004bc4:	64f2                	ld	s1,280(sp)
    80004bc6:	a035                	j	80004bf2 <sys_link+0xea>
    iunlockput(dp);
    80004bc8:	854a                	mv	a0,s2
    80004bca:	ffcfe0ef          	jal	800033c6 <iunlockput>
  ilock(ip);
    80004bce:	8526                	mv	a0,s1
    80004bd0:	deafe0ef          	jal	800031ba <ilock>
  ip->nlink--;
    80004bd4:	04a4d783          	lhu	a5,74(s1)
    80004bd8:	37fd                	addiw	a5,a5,-1
    80004bda:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004bde:	8526                	mv	a0,s1
    80004be0:	d26fe0ef          	jal	80003106 <iupdate>
  iunlockput(ip);
    80004be4:	8526                	mv	a0,s1
    80004be6:	fe0fe0ef          	jal	800033c6 <iunlockput>
  end_op();
    80004bea:	f03fe0ef          	jal	80003aec <end_op>
  return -1;
    80004bee:	64f2                	ld	s1,280(sp)
    80004bf0:	6952                	ld	s2,272(sp)
    return -1;
    80004bf2:	557d                	li	a0,-1
}
    80004bf4:	70b2                	ld	ra,296(sp)
    80004bf6:	7412                	ld	s0,288(sp)
    80004bf8:	6155                	addi	sp,sp,304
    80004bfa:	8082                	ret

0000000080004bfc <sys_unlink>:
{
    80004bfc:	7151                	addi	sp,sp,-240
    80004bfe:	f586                	sd	ra,232(sp)
    80004c00:	f1a2                	sd	s0,224(sp)
    80004c02:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004c04:	08000613          	li	a2,128
    80004c08:	f3040593          	addi	a1,s0,-208
    80004c0c:	4501                	li	a0,0
    80004c0e:	be7fd0ef          	jal	800027f4 <argstr>
    80004c12:	14054763          	bltz	a0,80004d60 <sys_unlink+0x164>
    80004c16:	eda6                	sd	s1,216(sp)
  begin_op();
    80004c18:	e65fe0ef          	jal	80003a7c <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004c1c:	fb040593          	addi	a1,s0,-80
    80004c20:	f3040513          	addi	a0,s0,-208
    80004c24:	cb1fe0ef          	jal	800038d4 <nameiparent>
    80004c28:	84aa                	mv	s1,a0
    80004c2a:	c955                	beqz	a0,80004cde <sys_unlink+0xe2>
  ilock(dp);
    80004c2c:	d8efe0ef          	jal	800031ba <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004c30:	00003597          	auipc	a1,0x3
    80004c34:	9f058593          	addi	a1,a1,-1552 # 80007620 <etext+0x620>
    80004c38:	fb040513          	addi	a0,s0,-80
    80004c3c:	9cdfe0ef          	jal	80003608 <namecmp>
    80004c40:	10050a63          	beqz	a0,80004d54 <sys_unlink+0x158>
    80004c44:	00003597          	auipc	a1,0x3
    80004c48:	9e458593          	addi	a1,a1,-1564 # 80007628 <etext+0x628>
    80004c4c:	fb040513          	addi	a0,s0,-80
    80004c50:	9b9fe0ef          	jal	80003608 <namecmp>
    80004c54:	10050063          	beqz	a0,80004d54 <sys_unlink+0x158>
    80004c58:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    80004c5a:	f2c40613          	addi	a2,s0,-212
    80004c5e:	fb040593          	addi	a1,s0,-80
    80004c62:	8526                	mv	a0,s1
    80004c64:	9bbfe0ef          	jal	8000361e <dirlookup>
    80004c68:	892a                	mv	s2,a0
    80004c6a:	0e050463          	beqz	a0,80004d52 <sys_unlink+0x156>
    80004c6e:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    80004c70:	d4afe0ef          	jal	800031ba <ilock>
  if(ip->nlink < 1)
    80004c74:	04a91783          	lh	a5,74(s2)
    80004c78:	06f05763          	blez	a5,80004ce6 <sys_unlink+0xea>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80004c7c:	04491703          	lh	a4,68(s2)
    80004c80:	4785                	li	a5,1
    80004c82:	06f70863          	beq	a4,a5,80004cf2 <sys_unlink+0xf6>
  memset(&de, 0, sizeof(de));
    80004c86:	fc040993          	addi	s3,s0,-64
    80004c8a:	4641                	li	a2,16
    80004c8c:	4581                	li	a1,0
    80004c8e:	854e                	mv	a0,s3
    80004c90:	8a0fc0ef          	jal	80000d30 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004c94:	4741                	li	a4,16
    80004c96:	f2c42683          	lw	a3,-212(s0)
    80004c9a:	864e                	mv	a2,s3
    80004c9c:	4581                	li	a1,0
    80004c9e:	8526                	mv	a0,s1
    80004ca0:	867fe0ef          	jal	80003506 <writei>
    80004ca4:	47c1                	li	a5,16
    80004ca6:	08f51763          	bne	a0,a5,80004d34 <sys_unlink+0x138>
  if(ip->type == T_DIR){
    80004caa:	04491703          	lh	a4,68(s2)
    80004cae:	4785                	li	a5,1
    80004cb0:	08f70863          	beq	a4,a5,80004d40 <sys_unlink+0x144>
  iunlockput(dp);
    80004cb4:	8526                	mv	a0,s1
    80004cb6:	f10fe0ef          	jal	800033c6 <iunlockput>
  ip->nlink--;
    80004cba:	04a95783          	lhu	a5,74(s2)
    80004cbe:	37fd                	addiw	a5,a5,-1
    80004cc0:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004cc4:	854a                	mv	a0,s2
    80004cc6:	c40fe0ef          	jal	80003106 <iupdate>
  iunlockput(ip);
    80004cca:	854a                	mv	a0,s2
    80004ccc:	efafe0ef          	jal	800033c6 <iunlockput>
  end_op();
    80004cd0:	e1dfe0ef          	jal	80003aec <end_op>
  return 0;
    80004cd4:	4501                	li	a0,0
    80004cd6:	64ee                	ld	s1,216(sp)
    80004cd8:	694e                	ld	s2,208(sp)
    80004cda:	69ae                	ld	s3,200(sp)
    80004cdc:	a059                	j	80004d62 <sys_unlink+0x166>
    end_op();
    80004cde:	e0ffe0ef          	jal	80003aec <end_op>
    return -1;
    80004ce2:	64ee                	ld	s1,216(sp)
    80004ce4:	a8b5                	j	80004d60 <sys_unlink+0x164>
    panic("unlink: nlink < 1");
    80004ce6:	00003517          	auipc	a0,0x3
    80004cea:	94a50513          	addi	a0,a0,-1718 # 80007630 <etext+0x630>
    80004cee:	b03fb0ef          	jal	800007f0 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004cf2:	04c92703          	lw	a4,76(s2)
    80004cf6:	02000793          	li	a5,32
    80004cfa:	f8e7f6e3          	bgeu	a5,a4,80004c86 <sys_unlink+0x8a>
    80004cfe:	89be                	mv	s3,a5
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004d00:	4741                	li	a4,16
    80004d02:	86ce                	mv	a3,s3
    80004d04:	f1840613          	addi	a2,s0,-232
    80004d08:	4581                	li	a1,0
    80004d0a:	854a                	mv	a0,s2
    80004d0c:	f08fe0ef          	jal	80003414 <readi>
    80004d10:	47c1                	li	a5,16
    80004d12:	00f51b63          	bne	a0,a5,80004d28 <sys_unlink+0x12c>
    if(de.inum != 0)
    80004d16:	f1845783          	lhu	a5,-232(s0)
    80004d1a:	eba1                	bnez	a5,80004d6a <sys_unlink+0x16e>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004d1c:	29c1                	addiw	s3,s3,16
    80004d1e:	04c92783          	lw	a5,76(s2)
    80004d22:	fcf9efe3          	bltu	s3,a5,80004d00 <sys_unlink+0x104>
    80004d26:	b785                	j	80004c86 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    80004d28:	00003517          	auipc	a0,0x3
    80004d2c:	92050513          	addi	a0,a0,-1760 # 80007648 <etext+0x648>
    80004d30:	ac1fb0ef          	jal	800007f0 <panic>
    panic("unlink: writei");
    80004d34:	00003517          	auipc	a0,0x3
    80004d38:	92c50513          	addi	a0,a0,-1748 # 80007660 <etext+0x660>
    80004d3c:	ab5fb0ef          	jal	800007f0 <panic>
    dp->nlink--;
    80004d40:	04a4d783          	lhu	a5,74(s1)
    80004d44:	37fd                	addiw	a5,a5,-1
    80004d46:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004d4a:	8526                	mv	a0,s1
    80004d4c:	bbafe0ef          	jal	80003106 <iupdate>
    80004d50:	b795                	j	80004cb4 <sys_unlink+0xb8>
    80004d52:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    80004d54:	8526                	mv	a0,s1
    80004d56:	e70fe0ef          	jal	800033c6 <iunlockput>
  end_op();
    80004d5a:	d93fe0ef          	jal	80003aec <end_op>
  return -1;
    80004d5e:	64ee                	ld	s1,216(sp)
    return -1;
    80004d60:	557d                	li	a0,-1
}
    80004d62:	70ae                	ld	ra,232(sp)
    80004d64:	740e                	ld	s0,224(sp)
    80004d66:	616d                	addi	sp,sp,240
    80004d68:	8082                	ret
    iunlockput(ip);
    80004d6a:	854a                	mv	a0,s2
    80004d6c:	e5afe0ef          	jal	800033c6 <iunlockput>
    goto bad;
    80004d70:	694e                	ld	s2,208(sp)
    80004d72:	69ae                	ld	s3,200(sp)
    80004d74:	b7c5                	j	80004d54 <sys_unlink+0x158>

0000000080004d76 <sys_open>:

uint64
sys_open(void)
{
    80004d76:	7131                	addi	sp,sp,-192
    80004d78:	fd06                	sd	ra,184(sp)
    80004d7a:	f922                	sd	s0,176(sp)
    80004d7c:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80004d7e:	f4c40593          	addi	a1,s0,-180
    80004d82:	4505                	li	a0,1
    80004d84:	a39fd0ef          	jal	800027bc <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004d88:	08000613          	li	a2,128
    80004d8c:	f5040593          	addi	a1,s0,-176
    80004d90:	4501                	li	a0,0
    80004d92:	a63fd0ef          	jal	800027f4 <argstr>
    80004d96:	10054563          	bltz	a0,80004ea0 <sys_open+0x12a>
    80004d9a:	f526                	sd	s1,168(sp)
    return -1;

  begin_op();
    80004d9c:	ce1fe0ef          	jal	80003a7c <begin_op>

  if(omode & O_CREATE){
    80004da0:	f4c42783          	lw	a5,-180(s0)
    80004da4:	2007f793          	andi	a5,a5,512
    80004da8:	cfd9                	beqz	a5,80004e46 <sys_open+0xd0>
    ip = create(path, T_FILE, 0, 0);
    80004daa:	4681                	li	a3,0
    80004dac:	4601                	li	a2,0
    80004dae:	4589                	li	a1,2
    80004db0:	f5040513          	addi	a0,s0,-176
    80004db4:	acdff0ef          	jal	80004880 <create>
    80004db8:	84aa                	mv	s1,a0
    if(ip == 0){
    80004dba:	c151                	beqz	a0,80004e3e <sys_open+0xc8>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    80004dbc:	04449703          	lh	a4,68(s1)
    80004dc0:	478d                	li	a5,3
    80004dc2:	00f71763          	bne	a4,a5,80004dd0 <sys_open+0x5a>
    80004dc6:	0464d703          	lhu	a4,70(s1)
    80004dca:	47a5                	li	a5,9
    80004dcc:	0ae7e863          	bltu	a5,a4,80004e7c <sys_open+0x106>
    80004dd0:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80004dd2:	834ff0ef          	jal	80003e06 <filealloc>
    80004dd6:	892a                	mv	s2,a0
    80004dd8:	cd4d                	beqz	a0,80004e92 <sys_open+0x11c>
    80004dda:	ed4e                	sd	s3,152(sp)
    80004ddc:	a67ff0ef          	jal	80004842 <fdalloc>
    80004de0:	89aa                	mv	s3,a0
    80004de2:	0a054463          	bltz	a0,80004e8a <sys_open+0x114>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80004de6:	04449703          	lh	a4,68(s1)
    80004dea:	478d                	li	a5,3
    80004dec:	0af70f63          	beq	a4,a5,80004eaa <sys_open+0x134>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80004df0:	4789                	li	a5,2
    80004df2:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    80004df6:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    80004dfa:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80004dfe:	f4c42783          	lw	a5,-180(s0)
    80004e02:	0017f713          	andi	a4,a5,1
    80004e06:	00174713          	xori	a4,a4,1
    80004e0a:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80004e0e:	0037f713          	andi	a4,a5,3
    80004e12:	00e03733          	snez	a4,a4
    80004e16:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80004e1a:	4007f793          	andi	a5,a5,1024
    80004e1e:	c791                	beqz	a5,80004e2a <sys_open+0xb4>
    80004e20:	04449703          	lh	a4,68(s1)
    80004e24:	4789                	li	a5,2
    80004e26:	08f70963          	beq	a4,a5,80004eb8 <sys_open+0x142>
    itrunc(ip);
  }

  iunlock(ip);
    80004e2a:	8526                	mv	a0,s1
    80004e2c:	c3cfe0ef          	jal	80003268 <iunlock>
  end_op();
    80004e30:	cbdfe0ef          	jal	80003aec <end_op>

  return fd;
    80004e34:	854e                	mv	a0,s3
    80004e36:	74aa                	ld	s1,168(sp)
    80004e38:	790a                	ld	s2,160(sp)
    80004e3a:	69ea                	ld	s3,152(sp)
    80004e3c:	a09d                	j	80004ea2 <sys_open+0x12c>
      end_op();
    80004e3e:	caffe0ef          	jal	80003aec <end_op>
      return -1;
    80004e42:	74aa                	ld	s1,168(sp)
    80004e44:	a8b1                	j	80004ea0 <sys_open+0x12a>
    if((ip = namei(path)) == 0){
    80004e46:	f5040513          	addi	a0,s0,-176
    80004e4a:	a71fe0ef          	jal	800038ba <namei>
    80004e4e:	84aa                	mv	s1,a0
    80004e50:	c115                	beqz	a0,80004e74 <sys_open+0xfe>
    ilock(ip);
    80004e52:	b68fe0ef          	jal	800031ba <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    80004e56:	04449703          	lh	a4,68(s1)
    80004e5a:	4785                	li	a5,1
    80004e5c:	f6f710e3          	bne	a4,a5,80004dbc <sys_open+0x46>
    80004e60:	f4c42783          	lw	a5,-180(s0)
    80004e64:	d7b5                	beqz	a5,80004dd0 <sys_open+0x5a>
      iunlockput(ip);
    80004e66:	8526                	mv	a0,s1
    80004e68:	d5efe0ef          	jal	800033c6 <iunlockput>
      end_op();
    80004e6c:	c81fe0ef          	jal	80003aec <end_op>
      return -1;
    80004e70:	74aa                	ld	s1,168(sp)
    80004e72:	a03d                	j	80004ea0 <sys_open+0x12a>
      end_op();
    80004e74:	c79fe0ef          	jal	80003aec <end_op>
      return -1;
    80004e78:	74aa                	ld	s1,168(sp)
    80004e7a:	a01d                	j	80004ea0 <sys_open+0x12a>
    iunlockput(ip);
    80004e7c:	8526                	mv	a0,s1
    80004e7e:	d48fe0ef          	jal	800033c6 <iunlockput>
    end_op();
    80004e82:	c6bfe0ef          	jal	80003aec <end_op>
    return -1;
    80004e86:	74aa                	ld	s1,168(sp)
    80004e88:	a821                	j	80004ea0 <sys_open+0x12a>
      fileclose(f);
    80004e8a:	854a                	mv	a0,s2
    80004e8c:	81eff0ef          	jal	80003eaa <fileclose>
    80004e90:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80004e92:	8526                	mv	a0,s1
    80004e94:	d32fe0ef          	jal	800033c6 <iunlockput>
    end_op();
    80004e98:	c55fe0ef          	jal	80003aec <end_op>
    return -1;
    80004e9c:	74aa                	ld	s1,168(sp)
    80004e9e:	790a                	ld	s2,160(sp)
    return -1;
    80004ea0:	557d                	li	a0,-1
}
    80004ea2:	70ea                	ld	ra,184(sp)
    80004ea4:	744a                	ld	s0,176(sp)
    80004ea6:	6129                	addi	sp,sp,192
    80004ea8:	8082                	ret
    f->type = FD_DEVICE;
    80004eaa:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    80004eae:	04649783          	lh	a5,70(s1)
    80004eb2:	02f91223          	sh	a5,36(s2)
    80004eb6:	b791                	j	80004dfa <sys_open+0x84>
    itrunc(ip);
    80004eb8:	8526                	mv	a0,s1
    80004eba:	beefe0ef          	jal	800032a8 <itrunc>
    80004ebe:	b7b5                	j	80004e2a <sys_open+0xb4>

0000000080004ec0 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80004ec0:	7175                	addi	sp,sp,-144
    80004ec2:	e506                	sd	ra,136(sp)
    80004ec4:	e122                	sd	s0,128(sp)
    80004ec6:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80004ec8:	bb5fe0ef          	jal	80003a7c <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    80004ecc:	08000613          	li	a2,128
    80004ed0:	f7040593          	addi	a1,s0,-144
    80004ed4:	4501                	li	a0,0
    80004ed6:	91ffd0ef          	jal	800027f4 <argstr>
    80004eda:	02054363          	bltz	a0,80004f00 <sys_mkdir+0x40>
    80004ede:	4681                	li	a3,0
    80004ee0:	4601                	li	a2,0
    80004ee2:	4585                	li	a1,1
    80004ee4:	f7040513          	addi	a0,s0,-144
    80004ee8:	999ff0ef          	jal	80004880 <create>
    80004eec:	c911                	beqz	a0,80004f00 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004eee:	cd8fe0ef          	jal	800033c6 <iunlockput>
  end_op();
    80004ef2:	bfbfe0ef          	jal	80003aec <end_op>
  return 0;
    80004ef6:	4501                	li	a0,0
}
    80004ef8:	60aa                	ld	ra,136(sp)
    80004efa:	640a                	ld	s0,128(sp)
    80004efc:	6149                	addi	sp,sp,144
    80004efe:	8082                	ret
    end_op();
    80004f00:	bedfe0ef          	jal	80003aec <end_op>
    return -1;
    80004f04:	557d                	li	a0,-1
    80004f06:	bfcd                	j	80004ef8 <sys_mkdir+0x38>

0000000080004f08 <sys_mknod>:

uint64
sys_mknod(void)
{
    80004f08:	7135                	addi	sp,sp,-160
    80004f0a:	ed06                	sd	ra,152(sp)
    80004f0c:	e922                	sd	s0,144(sp)
    80004f0e:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80004f10:	b6dfe0ef          	jal	80003a7c <begin_op>
  argint(1, &major);
    80004f14:	f6c40593          	addi	a1,s0,-148
    80004f18:	4505                	li	a0,1
    80004f1a:	8a3fd0ef          	jal	800027bc <argint>
  argint(2, &minor);
    80004f1e:	f6840593          	addi	a1,s0,-152
    80004f22:	4509                	li	a0,2
    80004f24:	899fd0ef          	jal	800027bc <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004f28:	08000613          	li	a2,128
    80004f2c:	f7040593          	addi	a1,s0,-144
    80004f30:	4501                	li	a0,0
    80004f32:	8c3fd0ef          	jal	800027f4 <argstr>
    80004f36:	02054563          	bltz	a0,80004f60 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    80004f3a:	f6841683          	lh	a3,-152(s0)
    80004f3e:	f6c41603          	lh	a2,-148(s0)
    80004f42:	458d                	li	a1,3
    80004f44:	f7040513          	addi	a0,s0,-144
    80004f48:	939ff0ef          	jal	80004880 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004f4c:	c911                	beqz	a0,80004f60 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004f4e:	c78fe0ef          	jal	800033c6 <iunlockput>
  end_op();
    80004f52:	b9bfe0ef          	jal	80003aec <end_op>
  return 0;
    80004f56:	4501                	li	a0,0
}
    80004f58:	60ea                	ld	ra,152(sp)
    80004f5a:	644a                	ld	s0,144(sp)
    80004f5c:	610d                	addi	sp,sp,160
    80004f5e:	8082                	ret
    end_op();
    80004f60:	b8dfe0ef          	jal	80003aec <end_op>
    return -1;
    80004f64:	557d                	li	a0,-1
    80004f66:	bfcd                	j	80004f58 <sys_mknod+0x50>

0000000080004f68 <sys_chdir>:

uint64
sys_chdir(void)
{
    80004f68:	7135                	addi	sp,sp,-160
    80004f6a:	ed06                	sd	ra,152(sp)
    80004f6c:	e922                	sd	s0,144(sp)
    80004f6e:	e14a                	sd	s2,128(sp)
    80004f70:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80004f72:	9b3fc0ef          	jal	80001924 <myproc>
    80004f76:	892a                	mv	s2,a0
  
  begin_op();
    80004f78:	b05fe0ef          	jal	80003a7c <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    80004f7c:	08000613          	li	a2,128
    80004f80:	f6040593          	addi	a1,s0,-160
    80004f84:	4501                	li	a0,0
    80004f86:	86ffd0ef          	jal	800027f4 <argstr>
    80004f8a:	02054f63          	bltz	a0,80004fc8 <sys_chdir+0x60>
    80004f8e:	e526                	sd	s1,136(sp)
    80004f90:	f6040513          	addi	a0,s0,-160
    80004f94:	927fe0ef          	jal	800038ba <namei>
    80004f98:	84aa                	mv	s1,a0
    80004f9a:	c515                	beqz	a0,80004fc6 <sys_chdir+0x5e>
    end_op();
    return -1;
  }
  ilock(ip);
    80004f9c:	a1efe0ef          	jal	800031ba <ilock>
  if(ip->type != T_DIR){
    80004fa0:	04449703          	lh	a4,68(s1)
    80004fa4:	4785                	li	a5,1
    80004fa6:	02f71963          	bne	a4,a5,80004fd8 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    80004faa:	8526                	mv	a0,s1
    80004fac:	abcfe0ef          	jal	80003268 <iunlock>
  iput(p->cwd);
    80004fb0:	15093503          	ld	a0,336(s2)
    80004fb4:	b88fe0ef          	jal	8000333c <iput>
  end_op();
    80004fb8:	b35fe0ef          	jal	80003aec <end_op>
  p->cwd = ip;
    80004fbc:	14993823          	sd	s1,336(s2)
  return 0;
    80004fc0:	4501                	li	a0,0
    80004fc2:	64aa                	ld	s1,136(sp)
    80004fc4:	a029                	j	80004fce <sys_chdir+0x66>
    80004fc6:	64aa                	ld	s1,136(sp)
    end_op();
    80004fc8:	b25fe0ef          	jal	80003aec <end_op>
    return -1;
    80004fcc:	557d                	li	a0,-1
}
    80004fce:	60ea                	ld	ra,152(sp)
    80004fd0:	644a                	ld	s0,144(sp)
    80004fd2:	690a                	ld	s2,128(sp)
    80004fd4:	610d                	addi	sp,sp,160
    80004fd6:	8082                	ret
    iunlockput(ip);
    80004fd8:	8526                	mv	a0,s1
    80004fda:	becfe0ef          	jal	800033c6 <iunlockput>
    end_op();
    80004fde:	b0ffe0ef          	jal	80003aec <end_op>
    return -1;
    80004fe2:	64aa                	ld	s1,136(sp)
    80004fe4:	b7e5                	j	80004fcc <sys_chdir+0x64>

0000000080004fe6 <sys_exec>:

uint64
sys_exec(void)
{
    80004fe6:	7105                	addi	sp,sp,-480
    80004fe8:	ef86                	sd	ra,472(sp)
    80004fea:	eba2                	sd	s0,464(sp)
    80004fec:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80004fee:	e2840593          	addi	a1,s0,-472
    80004ff2:	4505                	li	a0,1
    80004ff4:	fe4fd0ef          	jal	800027d8 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80004ff8:	08000613          	li	a2,128
    80004ffc:	f3040593          	addi	a1,s0,-208
    80005000:	4501                	li	a0,0
    80005002:	ff2fd0ef          	jal	800027f4 <argstr>
    80005006:	0c054e63          	bltz	a0,800050e2 <sys_exec+0xfc>
    8000500a:	e7a6                	sd	s1,456(sp)
    8000500c:	e3ca                	sd	s2,448(sp)
    8000500e:	ff4e                	sd	s3,440(sp)
    80005010:	fb52                	sd	s4,432(sp)
    80005012:	f756                	sd	s5,424(sp)
    80005014:	f35a                	sd	s6,416(sp)
    80005016:	ef5e                	sd	s7,408(sp)
    return -1;
  }
  memset(argv, 0, sizeof(argv));
    80005018:	e3040a13          	addi	s4,s0,-464
    8000501c:	10000613          	li	a2,256
    80005020:	4581                	li	a1,0
    80005022:	8552                	mv	a0,s4
    80005024:	d0dfb0ef          	jal	80000d30 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80005028:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    8000502a:	89d2                	mv	s3,s4
    8000502c:	4901                	li	s2,0
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    8000502e:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005032:	6b05                	lui	s6,0x1
    if(i >= NELEM(argv)){
    80005034:	02000b93          	li	s7,32
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80005038:	00391513          	slli	a0,s2,0x3
    8000503c:	85d6                	mv	a1,s5
    8000503e:	e2843783          	ld	a5,-472(s0)
    80005042:	953e                	add	a0,a0,a5
    80005044:	ef2fd0ef          	jal	80002736 <fetchaddr>
    80005048:	02054663          	bltz	a0,80005074 <sys_exec+0x8e>
    if(uarg == 0){
    8000504c:	e2043783          	ld	a5,-480(s0)
    80005050:	c3b9                	beqz	a5,80005096 <sys_exec+0xb0>
    argv[i] = kalloc();
    80005052:	b2ffb0ef          	jal	80000b80 <kalloc>
    80005056:	85aa                	mv	a1,a0
    80005058:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    8000505c:	cd01                	beqz	a0,80005074 <sys_exec+0x8e>
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    8000505e:	865a                	mv	a2,s6
    80005060:	e2043503          	ld	a0,-480(s0)
    80005064:	f18fd0ef          	jal	8000277c <fetchstr>
    80005068:	00054663          	bltz	a0,80005074 <sys_exec+0x8e>
    if(i >= NELEM(argv)){
    8000506c:	0905                	addi	s2,s2,1
    8000506e:	09a1                	addi	s3,s3,8
    80005070:	fd7914e3          	bne	s2,s7,80005038 <sys_exec+0x52>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005074:	100a0a13          	addi	s4,s4,256
    80005078:	6088                	ld	a0,0(s1)
    8000507a:	cd29                	beqz	a0,800050d4 <sys_exec+0xee>
    kfree(argv[i]);
    8000507c:	a1dfb0ef          	jal	80000a98 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005080:	04a1                	addi	s1,s1,8
    80005082:	ff449be3          	bne	s1,s4,80005078 <sys_exec+0x92>
    80005086:	64be                	ld	s1,456(sp)
    80005088:	691e                	ld	s2,448(sp)
    8000508a:	79fa                	ld	s3,440(sp)
    8000508c:	7a5a                	ld	s4,432(sp)
    8000508e:	7aba                	ld	s5,424(sp)
    80005090:	7b1a                	ld	s6,416(sp)
    80005092:	6bfa                	ld	s7,408(sp)
    80005094:	a0b9                	j	800050e2 <sys_exec+0xfc>
      argv[i] = 0;
    80005096:	0009079b          	sext.w	a5,s2
    8000509a:	e3040593          	addi	a1,s0,-464
    8000509e:	078e                	slli	a5,a5,0x3
    800050a0:	97ae                	add	a5,a5,a1
    800050a2:	0007b023          	sd	zero,0(a5)
  int ret = exec(path, argv);
    800050a6:	f3040513          	addi	a0,s0,-208
    800050aa:	c30ff0ef          	jal	800044da <exec>
    800050ae:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800050b0:	100a0a13          	addi	s4,s4,256
    800050b4:	6088                	ld	a0,0(s1)
    800050b6:	c511                	beqz	a0,800050c2 <sys_exec+0xdc>
    kfree(argv[i]);
    800050b8:	9e1fb0ef          	jal	80000a98 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800050bc:	04a1                	addi	s1,s1,8
    800050be:	ff449be3          	bne	s1,s4,800050b4 <sys_exec+0xce>
  return ret;
    800050c2:	854a                	mv	a0,s2
    800050c4:	64be                	ld	s1,456(sp)
    800050c6:	691e                	ld	s2,448(sp)
    800050c8:	79fa                	ld	s3,440(sp)
    800050ca:	7a5a                	ld	s4,432(sp)
    800050cc:	7aba                	ld	s5,424(sp)
    800050ce:	7b1a                	ld	s6,416(sp)
    800050d0:	6bfa                	ld	s7,408(sp)
    800050d2:	a809                	j	800050e4 <sys_exec+0xfe>
    800050d4:	64be                	ld	s1,456(sp)
    800050d6:	691e                	ld	s2,448(sp)
    800050d8:	79fa                	ld	s3,440(sp)
    800050da:	7a5a                	ld	s4,432(sp)
    800050dc:	7aba                	ld	s5,424(sp)
    800050de:	7b1a                	ld	s6,416(sp)
    800050e0:	6bfa                	ld	s7,408(sp)
    return -1;
    800050e2:	557d                	li	a0,-1
  return -1;
}
    800050e4:	60fe                	ld	ra,472(sp)
    800050e6:	645e                	ld	s0,464(sp)
    800050e8:	613d                	addi	sp,sp,480
    800050ea:	8082                	ret

00000000800050ec <sys_pipe>:

uint64
sys_pipe(void)
{
    800050ec:	7139                	addi	sp,sp,-64
    800050ee:	fc06                	sd	ra,56(sp)
    800050f0:	f822                	sd	s0,48(sp)
    800050f2:	f426                	sd	s1,40(sp)
    800050f4:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    800050f6:	82ffc0ef          	jal	80001924 <myproc>
    800050fa:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    800050fc:	fd840593          	addi	a1,s0,-40
    80005100:	4501                	li	a0,0
    80005102:	ed6fd0ef          	jal	800027d8 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80005106:	fc840593          	addi	a1,s0,-56
    8000510a:	fd040513          	addi	a0,s0,-48
    8000510e:	8aaff0ef          	jal	800041b8 <pipealloc>
    80005112:	0a054463          	bltz	a0,800051ba <sys_pipe+0xce>
    return -1;
  fd0 = -1;
    80005116:	57fd                	li	a5,-1
    80005118:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    8000511c:	fd043503          	ld	a0,-48(s0)
    80005120:	f22ff0ef          	jal	80004842 <fdalloc>
    80005124:	fca42223          	sw	a0,-60(s0)
    80005128:	08054163          	bltz	a0,800051aa <sys_pipe+0xbe>
    8000512c:	fc843503          	ld	a0,-56(s0)
    80005130:	f12ff0ef          	jal	80004842 <fdalloc>
    80005134:	fca42023          	sw	a0,-64(s0)
    80005138:	06054063          	bltz	a0,80005198 <sys_pipe+0xac>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    8000513c:	4691                	li	a3,4
    8000513e:	fc440613          	addi	a2,s0,-60
    80005142:	fd843583          	ld	a1,-40(s0)
    80005146:	68a8                	ld	a0,80(s1)
    80005148:	c6cfc0ef          	jal	800015b4 <copyout>
    8000514c:	00054f63          	bltz	a0,8000516a <sys_pipe+0x7e>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80005150:	4691                	li	a3,4
    80005152:	fc040613          	addi	a2,s0,-64
    80005156:	fd843583          	ld	a1,-40(s0)
    8000515a:	95b6                	add	a1,a1,a3
    8000515c:	68a8                	ld	a0,80(s1)
    8000515e:	c56fc0ef          	jal	800015b4 <copyout>
    80005162:	87aa                	mv	a5,a0
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    80005164:	4501                	li	a0,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005166:	0407db63          	bgez	a5,800051bc <sys_pipe+0xd0>
    p->ofile[fd0] = 0;
    8000516a:	fc442783          	lw	a5,-60(s0)
    8000516e:	07e9                	addi	a5,a5,26
    80005170:	078e                	slli	a5,a5,0x3
    80005172:	97a6                	add	a5,a5,s1
    80005174:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    80005178:	fc042783          	lw	a5,-64(s0)
    8000517c:	07e9                	addi	a5,a5,26
    8000517e:	078e                	slli	a5,a5,0x3
    80005180:	97a6                	add	a5,a5,s1
    80005182:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005186:	fd043503          	ld	a0,-48(s0)
    8000518a:	d21fe0ef          	jal	80003eaa <fileclose>
    fileclose(wf);
    8000518e:	fc843503          	ld	a0,-56(s0)
    80005192:	d19fe0ef          	jal	80003eaa <fileclose>
    return -1;
    80005196:	a015                	j	800051ba <sys_pipe+0xce>
    if(fd0 >= 0)
    80005198:	fc442783          	lw	a5,-60(s0)
    8000519c:	0007c763          	bltz	a5,800051aa <sys_pipe+0xbe>
      p->ofile[fd0] = 0;
    800051a0:	07e9                	addi	a5,a5,26
    800051a2:	078e                	slli	a5,a5,0x3
    800051a4:	97a6                	add	a5,a5,s1
    800051a6:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    800051aa:	fd043503          	ld	a0,-48(s0)
    800051ae:	cfdfe0ef          	jal	80003eaa <fileclose>
    fileclose(wf);
    800051b2:	fc843503          	ld	a0,-56(s0)
    800051b6:	cf5fe0ef          	jal	80003eaa <fileclose>
    return -1;
    800051ba:	557d                	li	a0,-1
}
    800051bc:	70e2                	ld	ra,56(sp)
    800051be:	7442                	ld	s0,48(sp)
    800051c0:	74a2                	ld	s1,40(sp)
    800051c2:	6121                	addi	sp,sp,64
    800051c4:	8082                	ret
	...

00000000800051d0 <kernelvec>:
    800051d0:	7111                	addi	sp,sp,-256
    800051d2:	e006                	sd	ra,0(sp)
    800051d4:	e40a                	sd	sp,8(sp)
    800051d6:	e80e                	sd	gp,16(sp)
    800051d8:	ec12                	sd	tp,24(sp)
    800051da:	f016                	sd	t0,32(sp)
    800051dc:	f41a                	sd	t1,40(sp)
    800051de:	f81e                	sd	t2,48(sp)
    800051e0:	e4aa                	sd	a0,72(sp)
    800051e2:	e8ae                	sd	a1,80(sp)
    800051e4:	ecb2                	sd	a2,88(sp)
    800051e6:	f0b6                	sd	a3,96(sp)
    800051e8:	f4ba                	sd	a4,104(sp)
    800051ea:	f8be                	sd	a5,112(sp)
    800051ec:	fcc2                	sd	a6,120(sp)
    800051ee:	e146                	sd	a7,128(sp)
    800051f0:	edf2                	sd	t3,216(sp)
    800051f2:	f1f6                	sd	t4,224(sp)
    800051f4:	f5fa                	sd	t5,232(sp)
    800051f6:	f9fe                	sd	t6,240(sp)
    800051f8:	c4cfd0ef          	jal	80002644 <kerneltrap>
    800051fc:	6082                	ld	ra,0(sp)
    800051fe:	6122                	ld	sp,8(sp)
    80005200:	61c2                	ld	gp,16(sp)
    80005202:	7282                	ld	t0,32(sp)
    80005204:	7322                	ld	t1,40(sp)
    80005206:	73c2                	ld	t2,48(sp)
    80005208:	6526                	ld	a0,72(sp)
    8000520a:	65c6                	ld	a1,80(sp)
    8000520c:	6666                	ld	a2,88(sp)
    8000520e:	7686                	ld	a3,96(sp)
    80005210:	7726                	ld	a4,104(sp)
    80005212:	77c6                	ld	a5,112(sp)
    80005214:	7866                	ld	a6,120(sp)
    80005216:	688a                	ld	a7,128(sp)
    80005218:	6e6e                	ld	t3,216(sp)
    8000521a:	7e8e                	ld	t4,224(sp)
    8000521c:	7f2e                	ld	t5,232(sp)
    8000521e:	7fce                	ld	t6,240(sp)
    80005220:	6111                	addi	sp,sp,256
    80005222:	10200073          	sret
    80005226:	00000013          	nop
    8000522a:	00000013          	nop

000000008000522e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000522e:	1141                	addi	sp,sp,-16
    80005230:	e406                	sd	ra,8(sp)
    80005232:	e022                	sd	s0,0(sp)
    80005234:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80005236:	0c000737          	lui	a4,0xc000
    8000523a:	4785                	li	a5,1
    8000523c:	d71c                	sw	a5,40(a4)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000523e:	c35c                	sw	a5,4(a4)
}
    80005240:	60a2                	ld	ra,8(sp)
    80005242:	6402                	ld	s0,0(sp)
    80005244:	0141                	addi	sp,sp,16
    80005246:	8082                	ret

0000000080005248 <plicinithart>:

void
plicinithart(void)
{
    80005248:	1141                	addi	sp,sp,-16
    8000524a:	e406                	sd	ra,8(sp)
    8000524c:	e022                	sd	s0,0(sp)
    8000524e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005250:	ea0fc0ef          	jal	800018f0 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005254:	0085171b          	slliw	a4,a0,0x8
    80005258:	0c0027b7          	lui	a5,0xc002
    8000525c:	97ba                	add	a5,a5,a4
    8000525e:	40200713          	li	a4,1026
    80005262:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    80005266:	00d5151b          	slliw	a0,a0,0xd
    8000526a:	0c2017b7          	lui	a5,0xc201
    8000526e:	97aa                	add	a5,a5,a0
    80005270:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    80005274:	60a2                	ld	ra,8(sp)
    80005276:	6402                	ld	s0,0(sp)
    80005278:	0141                	addi	sp,sp,16
    8000527a:	8082                	ret

000000008000527c <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    8000527c:	1141                	addi	sp,sp,-16
    8000527e:	e406                	sd	ra,8(sp)
    80005280:	e022                	sd	s0,0(sp)
    80005282:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005284:	e6cfc0ef          	jal	800018f0 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80005288:	00d5151b          	slliw	a0,a0,0xd
    8000528c:	0c2017b7          	lui	a5,0xc201
    80005290:	97aa                	add	a5,a5,a0
  return irq;
}
    80005292:	43c8                	lw	a0,4(a5)
    80005294:	60a2                	ld	ra,8(sp)
    80005296:	6402                	ld	s0,0(sp)
    80005298:	0141                	addi	sp,sp,16
    8000529a:	8082                	ret

000000008000529c <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    8000529c:	1101                	addi	sp,sp,-32
    8000529e:	ec06                	sd	ra,24(sp)
    800052a0:	e822                	sd	s0,16(sp)
    800052a2:	e426                	sd	s1,8(sp)
    800052a4:	1000                	addi	s0,sp,32
    800052a6:	84aa                	mv	s1,a0
  int hart = cpuid();
    800052a8:	e48fc0ef          	jal	800018f0 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    800052ac:	00d5179b          	slliw	a5,a0,0xd
    800052b0:	0c201737          	lui	a4,0xc201
    800052b4:	97ba                	add	a5,a5,a4
    800052b6:	c3c4                	sw	s1,4(a5)
}
    800052b8:	60e2                	ld	ra,24(sp)
    800052ba:	6442                	ld	s0,16(sp)
    800052bc:	64a2                	ld	s1,8(sp)
    800052be:	6105                	addi	sp,sp,32
    800052c0:	8082                	ret

00000000800052c2 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    800052c2:	1141                	addi	sp,sp,-16
    800052c4:	e406                	sd	ra,8(sp)
    800052c6:	e022                	sd	s0,0(sp)
    800052c8:	0800                	addi	s0,sp,16
  if(i >= NUM)
    800052ca:	479d                	li	a5,7
    800052cc:	04a7ca63          	blt	a5,a0,80005320 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    800052d0:	0001c797          	auipc	a5,0x1c
    800052d4:	83078793          	addi	a5,a5,-2000 # 80020b00 <disk>
    800052d8:	97aa                	add	a5,a5,a0
    800052da:	0187c783          	lbu	a5,24(a5)
    800052de:	e7b9                	bnez	a5,8000532c <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    800052e0:	00451693          	slli	a3,a0,0x4
    800052e4:	0001c797          	auipc	a5,0x1c
    800052e8:	81c78793          	addi	a5,a5,-2020 # 80020b00 <disk>
    800052ec:	6398                	ld	a4,0(a5)
    800052ee:	9736                	add	a4,a4,a3
    800052f0:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    800052f4:	6398                	ld	a4,0(a5)
    800052f6:	9736                	add	a4,a4,a3
    800052f8:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    800052fc:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005300:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005304:	97aa                	add	a5,a5,a0
    80005306:	4705                	li	a4,1
    80005308:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    8000530c:	0001c517          	auipc	a0,0x1c
    80005310:	80c50513          	addi	a0,a0,-2036 # 80020b18 <disk+0x18>
    80005314:	c19fc0ef          	jal	80001f2c <wakeup>
}
    80005318:	60a2                	ld	ra,8(sp)
    8000531a:	6402                	ld	s0,0(sp)
    8000531c:	0141                	addi	sp,sp,16
    8000531e:	8082                	ret
    panic("free_desc 1");
    80005320:	00002517          	auipc	a0,0x2
    80005324:	35050513          	addi	a0,a0,848 # 80007670 <etext+0x670>
    80005328:	cc8fb0ef          	jal	800007f0 <panic>
    panic("free_desc 2");
    8000532c:	00002517          	auipc	a0,0x2
    80005330:	35450513          	addi	a0,a0,852 # 80007680 <etext+0x680>
    80005334:	cbcfb0ef          	jal	800007f0 <panic>

0000000080005338 <virtio_disk_init>:
{
    80005338:	1101                	addi	sp,sp,-32
    8000533a:	ec06                	sd	ra,24(sp)
    8000533c:	e822                	sd	s0,16(sp)
    8000533e:	e426                	sd	s1,8(sp)
    80005340:	e04a                	sd	s2,0(sp)
    80005342:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005344:	00002597          	auipc	a1,0x2
    80005348:	34c58593          	addi	a1,a1,844 # 80007690 <etext+0x690>
    8000534c:	0001c517          	auipc	a0,0x1c
    80005350:	8dc50513          	addi	a0,a0,-1828 # 80020c28 <disk+0x128>
    80005354:	887fb0ef          	jal	80000bda <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005358:	100017b7          	lui	a5,0x10001
    8000535c:	4398                	lw	a4,0(a5)
    8000535e:	747277b7          	lui	a5,0x74727
    80005362:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005366:	14f71263          	bne	a4,a5,800054aa <virtio_disk_init+0x172>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    8000536a:	100017b7          	lui	a5,0x10001
    8000536e:	43d8                	lw	a4,4(a5)
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005370:	4789                	li	a5,2
    80005372:	12f71c63          	bne	a4,a5,800054aa <virtio_disk_init+0x172>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005376:	100017b7          	lui	a5,0x10001
    8000537a:	4798                	lw	a4,8(a5)
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    8000537c:	4789                	li	a5,2
    8000537e:	12f71663          	bne	a4,a5,800054aa <virtio_disk_init+0x172>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80005382:	100017b7          	lui	a5,0x10001
    80005386:	47d8                	lw	a4,12(a5)
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005388:	554d47b7          	lui	a5,0x554d4
    8000538c:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005390:	10f71d63          	bne	a4,a5,800054aa <virtio_disk_init+0x172>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005394:	100017b7          	lui	a5,0x10001
    80005398:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000539c:	4705                	li	a4,1
    8000539e:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800053a0:	470d                	li	a4,3
    800053a2:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    800053a4:	10001737          	lui	a4,0x10001
    800053a8:	4b18                	lw	a4,16(a4)
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    800053aa:	c7ffe6b7          	lui	a3,0xc7ffe
    800053ae:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fddb1f>
    800053b2:	8f75                	and	a4,a4,a3
    800053b4:	100016b7          	lui	a3,0x10001
    800053b8:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    800053ba:	472d                	li	a4,11
    800053bc:	dbb8                	sw	a4,112(a5)
  status = *R(VIRTIO_MMIO_STATUS);
    800053be:	0707a903          	lw	s2,112(a5)
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    800053c2:	00897793          	andi	a5,s2,8
    800053c6:	0e078863          	beqz	a5,800054b6 <virtio_disk_init+0x17e>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    800053ca:	100017b7          	lui	a5,0x10001
    800053ce:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    800053d2:	43fc                	lw	a5,68(a5)
    800053d4:	0e079763          	bnez	a5,800054c2 <virtio_disk_init+0x18a>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    800053d8:	100017b7          	lui	a5,0x10001
    800053dc:	5bdc                	lw	a5,52(a5)
  if(max == 0)
    800053de:	0e078863          	beqz	a5,800054ce <virtio_disk_init+0x196>
  if(max < NUM)
    800053e2:	471d                	li	a4,7
    800053e4:	0ef77b63          	bgeu	a4,a5,800054da <virtio_disk_init+0x1a2>
  disk.desc = kalloc();
    800053e8:	f98fb0ef          	jal	80000b80 <kalloc>
    800053ec:	0001b497          	auipc	s1,0x1b
    800053f0:	71448493          	addi	s1,s1,1812 # 80020b00 <disk>
    800053f4:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    800053f6:	f8afb0ef          	jal	80000b80 <kalloc>
    800053fa:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    800053fc:	f84fb0ef          	jal	80000b80 <kalloc>
    80005400:	87aa                	mv	a5,a0
    80005402:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80005404:	6088                	ld	a0,0(s1)
    80005406:	0e050063          	beqz	a0,800054e6 <virtio_disk_init+0x1ae>
    8000540a:	0001b717          	auipc	a4,0x1b
    8000540e:	6fe73703          	ld	a4,1790(a4) # 80020b08 <disk+0x8>
    80005412:	00173713          	seqz	a4,a4
    80005416:	0017b793          	seqz	a5,a5
    8000541a:	8fd9                	or	a5,a5,a4
    8000541c:	e7e9                	bnez	a5,800054e6 <virtio_disk_init+0x1ae>
  memset(disk.desc, 0, PGSIZE);
    8000541e:	6605                	lui	a2,0x1
    80005420:	4581                	li	a1,0
    80005422:	90ffb0ef          	jal	80000d30 <memset>
  memset(disk.avail, 0, PGSIZE);
    80005426:	0001b497          	auipc	s1,0x1b
    8000542a:	6da48493          	addi	s1,s1,1754 # 80020b00 <disk>
    8000542e:	6605                	lui	a2,0x1
    80005430:	4581                	li	a1,0
    80005432:	6488                	ld	a0,8(s1)
    80005434:	8fdfb0ef          	jal	80000d30 <memset>
  memset(disk.used, 0, PGSIZE);
    80005438:	6605                	lui	a2,0x1
    8000543a:	4581                	li	a1,0
    8000543c:	6888                	ld	a0,16(s1)
    8000543e:	8f3fb0ef          	jal	80000d30 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80005442:	100017b7          	lui	a5,0x10001
    80005446:	4721                	li	a4,8
    80005448:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    8000544a:	4098                	lw	a4,0(s1)
    8000544c:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80005450:	40d8                	lw	a4,4(s1)
    80005452:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005456:	649c                	ld	a5,8(s1)
    80005458:	10001737          	lui	a4,0x10001
    8000545c:	08f72823          	sw	a5,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80005460:	9781                	srai	a5,a5,0x20
    80005462:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    80005466:	689c                	ld	a5,16(s1)
    80005468:	0af72023          	sw	a5,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    8000546c:	9781                	srai	a5,a5,0x20
    8000546e:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    80005472:	4785                	li	a5,1
    80005474:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80005476:	00f48c23          	sb	a5,24(s1)
    8000547a:	00f48ca3          	sb	a5,25(s1)
    8000547e:	00f48d23          	sb	a5,26(s1)
    80005482:	00f48da3          	sb	a5,27(s1)
    80005486:	00f48e23          	sb	a5,28(s1)
    8000548a:	00f48ea3          	sb	a5,29(s1)
    8000548e:	00f48f23          	sb	a5,30(s1)
    80005492:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005496:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    8000549a:	07272823          	sw	s2,112(a4)
}
    8000549e:	60e2                	ld	ra,24(sp)
    800054a0:	6442                	ld	s0,16(sp)
    800054a2:	64a2                	ld	s1,8(sp)
    800054a4:	6902                	ld	s2,0(sp)
    800054a6:	6105                	addi	sp,sp,32
    800054a8:	8082                	ret
    panic("could not find virtio disk");
    800054aa:	00002517          	auipc	a0,0x2
    800054ae:	1f650513          	addi	a0,a0,502 # 800076a0 <etext+0x6a0>
    800054b2:	b3efb0ef          	jal	800007f0 <panic>
    panic("virtio disk FEATURES_OK unset");
    800054b6:	00002517          	auipc	a0,0x2
    800054ba:	20a50513          	addi	a0,a0,522 # 800076c0 <etext+0x6c0>
    800054be:	b32fb0ef          	jal	800007f0 <panic>
    panic("virtio disk should not be ready");
    800054c2:	00002517          	auipc	a0,0x2
    800054c6:	21e50513          	addi	a0,a0,542 # 800076e0 <etext+0x6e0>
    800054ca:	b26fb0ef          	jal	800007f0 <panic>
    panic("virtio disk has no queue 0");
    800054ce:	00002517          	auipc	a0,0x2
    800054d2:	23250513          	addi	a0,a0,562 # 80007700 <etext+0x700>
    800054d6:	b1afb0ef          	jal	800007f0 <panic>
    panic("virtio disk max queue too short");
    800054da:	00002517          	auipc	a0,0x2
    800054de:	24650513          	addi	a0,a0,582 # 80007720 <etext+0x720>
    800054e2:	b0efb0ef          	jal	800007f0 <panic>
    panic("virtio disk kalloc");
    800054e6:	00002517          	auipc	a0,0x2
    800054ea:	25a50513          	addi	a0,a0,602 # 80007740 <etext+0x740>
    800054ee:	b02fb0ef          	jal	800007f0 <panic>

00000000800054f2 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    800054f2:	711d                	addi	sp,sp,-96
    800054f4:	ec86                	sd	ra,88(sp)
    800054f6:	e8a2                	sd	s0,80(sp)
    800054f8:	e4a6                	sd	s1,72(sp)
    800054fa:	e0ca                	sd	s2,64(sp)
    800054fc:	fc4e                	sd	s3,56(sp)
    800054fe:	f852                	sd	s4,48(sp)
    80005500:	f456                	sd	s5,40(sp)
    80005502:	f05a                	sd	s6,32(sp)
    80005504:	ec5e                	sd	s7,24(sp)
    80005506:	e862                	sd	s8,16(sp)
    80005508:	1080                	addi	s0,sp,96
    8000550a:	89aa                	mv	s3,a0
    8000550c:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    8000550e:	00c52b83          	lw	s7,12(a0)
    80005512:	001b9b9b          	slliw	s7,s7,0x1
    80005516:	1b82                	slli	s7,s7,0x20
    80005518:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    8000551c:	0001b517          	auipc	a0,0x1b
    80005520:	70c50513          	addi	a0,a0,1804 # 80020c28 <disk+0x128>
    80005524:	f40fb0ef          	jal	80000c64 <acquire>
  for(int i = 0; i < NUM; i++){
    80005528:	44a1                	li	s1,8
      disk.free[i] = 0;
    8000552a:	0001ba97          	auipc	s5,0x1b
    8000552e:	5d6a8a93          	addi	s5,s5,1494 # 80020b00 <disk>
  for(int i = 0; i < 3; i++){
    80005532:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    80005534:	5c7d                	li	s8,-1
    80005536:	a095                	j	8000559a <virtio_disk_rw+0xa8>
      disk.free[i] = 0;
    80005538:	00fa8733          	add	a4,s5,a5
    8000553c:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80005540:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80005542:	0207c563          	bltz	a5,8000556c <virtio_disk_rw+0x7a>
  for(int i = 0; i < 3; i++){
    80005546:	2905                	addiw	s2,s2,1
    80005548:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    8000554a:	05490c63          	beq	s2,s4,800055a2 <virtio_disk_rw+0xb0>
    idx[i] = alloc_desc();
    8000554e:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80005550:	0001b717          	auipc	a4,0x1b
    80005554:	5b070713          	addi	a4,a4,1456 # 80020b00 <disk>
    80005558:	4781                	li	a5,0
    if(disk.free[i]){
    8000555a:	01874683          	lbu	a3,24(a4)
    8000555e:	fee9                	bnez	a3,80005538 <virtio_disk_rw+0x46>
  for(int i = 0; i < NUM; i++){
    80005560:	2785                	addiw	a5,a5,1
    80005562:	0705                	addi	a4,a4,1
    80005564:	fe979be3          	bne	a5,s1,8000555a <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    80005568:	0185a023          	sw	s8,0(a1)
      for(int j = 0; j < i; j++)
    8000556c:	01205d63          	blez	s2,80005586 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    80005570:	fa042503          	lw	a0,-96(s0)
    80005574:	d4fff0ef          	jal	800052c2 <free_desc>
      for(int j = 0; j < i; j++)
    80005578:	4785                	li	a5,1
    8000557a:	0127d663          	bge	a5,s2,80005586 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    8000557e:	fa442503          	lw	a0,-92(s0)
    80005582:	d41ff0ef          	jal	800052c2 <free_desc>
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005586:	0001b597          	auipc	a1,0x1b
    8000558a:	6a258593          	addi	a1,a1,1698 # 80020c28 <disk+0x128>
    8000558e:	0001b517          	auipc	a0,0x1b
    80005592:	58a50513          	addi	a0,a0,1418 # 80020b18 <disk+0x18>
    80005596:	94bfc0ef          	jal	80001ee0 <sleep>
  for(int i = 0; i < 3; i++){
    8000559a:	fa040613          	addi	a2,s0,-96
    8000559e:	4901                	li	s2,0
    800055a0:	b77d                	j	8000554e <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800055a2:	fa042503          	lw	a0,-96(s0)
    800055a6:	00451693          	slli	a3,a0,0x4

  if(write)
    800055aa:	0001b797          	auipc	a5,0x1b
    800055ae:	55678793          	addi	a5,a5,1366 # 80020b00 <disk>
    800055b2:	00451713          	slli	a4,a0,0x4
    800055b6:	0a070713          	addi	a4,a4,160
    800055ba:	973e                	add	a4,a4,a5
    800055bc:	01603633          	snez	a2,s6
    800055c0:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    800055c2:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    800055c6:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    800055ca:	6398                	ld	a4,0(a5)
    800055cc:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800055ce:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    800055d2:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    800055d4:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    800055d6:	6390                	ld	a2,0(a5)
    800055d8:	00d605b3          	add	a1,a2,a3
    800055dc:	4741                	li	a4,16
    800055de:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    800055e0:	4805                	li	a6,1
    800055e2:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    800055e6:	fa442703          	lw	a4,-92(s0)
    800055ea:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64) b->data;
    800055ee:	0712                	slli	a4,a4,0x4
    800055f0:	963a                	add	a2,a2,a4
    800055f2:	05898593          	addi	a1,s3,88
    800055f6:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    800055f8:	0007b883          	ld	a7,0(a5)
    800055fc:	9746                	add	a4,a4,a7
    800055fe:	40000613          	li	a2,1024
    80005602:	c710                	sw	a2,8(a4)
  if(write)
    80005604:	001b3613          	seqz	a2,s6
    80005608:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    8000560c:	01066633          	or	a2,a2,a6
    80005610:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005614:	fa842583          	lw	a1,-88(s0)
    80005618:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    8000561c:	00250613          	addi	a2,a0,2
    80005620:	0612                	slli	a2,a2,0x4
    80005622:	963e                	add	a2,a2,a5
    80005624:	577d                	li	a4,-1
    80005626:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    8000562a:	0592                	slli	a1,a1,0x4
    8000562c:	98ae                	add	a7,a7,a1
    8000562e:	03068713          	addi	a4,a3,48
    80005632:	973e                	add	a4,a4,a5
    80005634:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005638:	6398                	ld	a4,0(a5)
    8000563a:	972e                	add	a4,a4,a1
    8000563c:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005640:	4689                	li	a3,2
    80005642:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005646:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    8000564a:	0109a223          	sw	a6,4(s3)
  disk.info[idx[0]].b = b;
    8000564e:	01363423          	sd	s3,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005652:	6794                	ld	a3,8(a5)
    80005654:	0026d703          	lhu	a4,2(a3)
    80005658:	8b1d                	andi	a4,a4,7
    8000565a:	0706                	slli	a4,a4,0x1
    8000565c:	96ba                	add	a3,a3,a4
    8000565e:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80005662:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80005666:	6798                	ld	a4,8(a5)
    80005668:	00275783          	lhu	a5,2(a4)
    8000566c:	2785                	addiw	a5,a5,1
    8000566e:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80005672:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80005676:	100017b7          	lui	a5,0x10001
    8000567a:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    8000567e:	0049a783          	lw	a5,4(s3)
    80005682:	01079f63          	bne	a5,a6,800056a0 <virtio_disk_rw+0x1ae>
    sleep(b, &disk.vdisk_lock);
    80005686:	0001b917          	auipc	s2,0x1b
    8000568a:	5a290913          	addi	s2,s2,1442 # 80020c28 <disk+0x128>
  while(b->disk == 1) {
    8000568e:	84be                	mv	s1,a5
    sleep(b, &disk.vdisk_lock);
    80005690:	85ca                	mv	a1,s2
    80005692:	854e                	mv	a0,s3
    80005694:	84dfc0ef          	jal	80001ee0 <sleep>
  while(b->disk == 1) {
    80005698:	0049a783          	lw	a5,4(s3)
    8000569c:	fe978ae3          	beq	a5,s1,80005690 <virtio_disk_rw+0x19e>
  }

  disk.info[idx[0]].b = 0;
    800056a0:	fa042903          	lw	s2,-96(s0)
    800056a4:	00290713          	addi	a4,s2,2
    800056a8:	0712                	slli	a4,a4,0x4
    800056aa:	0001b797          	auipc	a5,0x1b
    800056ae:	45678793          	addi	a5,a5,1110 # 80020b00 <disk>
    800056b2:	97ba                	add	a5,a5,a4
    800056b4:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    800056b8:	0001b997          	auipc	s3,0x1b
    800056bc:	44898993          	addi	s3,s3,1096 # 80020b00 <disk>
    800056c0:	00491713          	slli	a4,s2,0x4
    800056c4:	0009b783          	ld	a5,0(s3)
    800056c8:	97ba                	add	a5,a5,a4
    800056ca:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    800056ce:	854a                	mv	a0,s2
    800056d0:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    800056d4:	befff0ef          	jal	800052c2 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    800056d8:	8885                	andi	s1,s1,1
    800056da:	f0fd                	bnez	s1,800056c0 <virtio_disk_rw+0x1ce>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    800056dc:	0001b517          	auipc	a0,0x1b
    800056e0:	54c50513          	addi	a0,a0,1356 # 80020c28 <disk+0x128>
    800056e4:	e10fb0ef          	jal	80000cf4 <release>
}
    800056e8:	60e6                	ld	ra,88(sp)
    800056ea:	6446                	ld	s0,80(sp)
    800056ec:	64a6                	ld	s1,72(sp)
    800056ee:	6906                	ld	s2,64(sp)
    800056f0:	79e2                	ld	s3,56(sp)
    800056f2:	7a42                	ld	s4,48(sp)
    800056f4:	7aa2                	ld	s5,40(sp)
    800056f6:	7b02                	ld	s6,32(sp)
    800056f8:	6be2                	ld	s7,24(sp)
    800056fa:	6c42                	ld	s8,16(sp)
    800056fc:	6125                	addi	sp,sp,96
    800056fe:	8082                	ret

0000000080005700 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005700:	1101                	addi	sp,sp,-32
    80005702:	ec06                	sd	ra,24(sp)
    80005704:	e822                	sd	s0,16(sp)
    80005706:	e426                	sd	s1,8(sp)
    80005708:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    8000570a:	0001b497          	auipc	s1,0x1b
    8000570e:	3f648493          	addi	s1,s1,1014 # 80020b00 <disk>
    80005712:	0001b517          	auipc	a0,0x1b
    80005716:	51650513          	addi	a0,a0,1302 # 80020c28 <disk+0x128>
    8000571a:	d4afb0ef          	jal	80000c64 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    8000571e:	100017b7          	lui	a5,0x10001
    80005722:	53bc                	lw	a5,96(a5)
    80005724:	8b8d                	andi	a5,a5,3
    80005726:	10001737          	lui	a4,0x10001
    8000572a:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    8000572c:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80005730:	689c                	ld	a5,16(s1)
    80005732:	0204d703          	lhu	a4,32(s1)
    80005736:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    8000573a:	04f70663          	beq	a4,a5,80005786 <virtio_disk_intr+0x86>
    __sync_synchronize();
    8000573e:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005742:	6898                	ld	a4,16(s1)
    80005744:	0204d783          	lhu	a5,32(s1)
    80005748:	8b9d                	andi	a5,a5,7
    8000574a:	078e                	slli	a5,a5,0x3
    8000574c:	97ba                	add	a5,a5,a4
    8000574e:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80005750:	00278713          	addi	a4,a5,2
    80005754:	0712                	slli	a4,a4,0x4
    80005756:	9726                	add	a4,a4,s1
    80005758:	01074703          	lbu	a4,16(a4) # 10001010 <_entry-0x6fffeff0>
    8000575c:	e321                	bnez	a4,8000579c <virtio_disk_intr+0x9c>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    8000575e:	0789                	addi	a5,a5,2
    80005760:	0792                	slli	a5,a5,0x4
    80005762:	97a6                	add	a5,a5,s1
    80005764:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    80005766:	00052223          	sw	zero,4(a0)
    wakeup(b);
    8000576a:	fc2fc0ef          	jal	80001f2c <wakeup>

    disk.used_idx += 1;
    8000576e:	0204d783          	lhu	a5,32(s1)
    80005772:	2785                	addiw	a5,a5,1
    80005774:	17c2                	slli	a5,a5,0x30
    80005776:	93c1                	srli	a5,a5,0x30
    80005778:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    8000577c:	6898                	ld	a4,16(s1)
    8000577e:	00275703          	lhu	a4,2(a4)
    80005782:	faf71ee3          	bne	a4,a5,8000573e <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005786:	0001b517          	auipc	a0,0x1b
    8000578a:	4a250513          	addi	a0,a0,1186 # 80020c28 <disk+0x128>
    8000578e:	d66fb0ef          	jal	80000cf4 <release>
}
    80005792:	60e2                	ld	ra,24(sp)
    80005794:	6442                	ld	s0,16(sp)
    80005796:	64a2                	ld	s1,8(sp)
    80005798:	6105                	addi	sp,sp,32
    8000579a:	8082                	ret
      panic("virtio_disk_intr status");
    8000579c:	00002517          	auipc	a0,0x2
    800057a0:	fbc50513          	addi	a0,a0,-68 # 80007758 <etext+0x758>
    800057a4:	84cfb0ef          	jal	800007f0 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	8282                	jr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
