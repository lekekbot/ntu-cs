
user/_cat:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <cat>:

char buf[512];

void
cat(int fd)
{
   0:	7139                	addi	sp,sp,-64
   2:	fc06                	sd	ra,56(sp)
   4:	f822                	sd	s0,48(sp)
   6:	f426                	sd	s1,40(sp)
   8:	f04a                	sd	s2,32(sp)
   a:	ec4e                	sd	s3,24(sp)
   c:	e852                	sd	s4,16(sp)
   e:	e456                	sd	s5,8(sp)
  10:	0080                	addi	s0,sp,64
  12:	89aa                	mv	s3,a0
  int n;

  while((n = read(fd, buf, sizeof(buf))) > 0) {
  14:	20000a13          	li	s4,512
  18:	00001917          	auipc	s2,0x1
  1c:	ff890913          	addi	s2,s2,-8 # 1010 <buf>
    if (write(1, buf, n) != n) {
  20:	4a85                	li	s5,1
  while((n = read(fd, buf, sizeof(buf))) > 0) {
  22:	8652                	mv	a2,s4
  24:	85ca                	mv	a1,s2
  26:	854e                	mv	a0,s3
  28:	372000ef          	jal	39a <read>
  2c:	84aa                	mv	s1,a0
  2e:	02a05363          	blez	a0,54 <cat+0x54>
    if (write(1, buf, n) != n) {
  32:	8626                	mv	a2,s1
  34:	85ca                	mv	a1,s2
  36:	8556                	mv	a0,s5
  38:	36a000ef          	jal	3a2 <write>
  3c:	fe9503e3          	beq	a0,s1,22 <cat+0x22>
      fprintf(2, "cat: write error\n");
  40:	00001597          	auipc	a1,0x1
  44:	b1058593          	addi	a1,a1,-1264 # b50 <thread_switch+0x6c>
  48:	4509                	li	a0,2
  4a:	750000ef          	jal	79a <fprintf>
      exit(1);
  4e:	4505                	li	a0,1
  50:	332000ef          	jal	382 <exit>
    }
  }
  if(n < 0){
  54:	00054b63          	bltz	a0,6a <cat+0x6a>
    fprintf(2, "cat: read error\n");
    exit(1);
  }
}
  58:	70e2                	ld	ra,56(sp)
  5a:	7442                	ld	s0,48(sp)
  5c:	74a2                	ld	s1,40(sp)
  5e:	7902                	ld	s2,32(sp)
  60:	69e2                	ld	s3,24(sp)
  62:	6a42                	ld	s4,16(sp)
  64:	6aa2                	ld	s5,8(sp)
  66:	6121                	addi	sp,sp,64
  68:	8082                	ret
    fprintf(2, "cat: read error\n");
  6a:	00001597          	auipc	a1,0x1
  6e:	afe58593          	addi	a1,a1,-1282 # b68 <thread_switch+0x84>
  72:	4509                	li	a0,2
  74:	726000ef          	jal	79a <fprintf>
    exit(1);
  78:	4505                	li	a0,1
  7a:	308000ef          	jal	382 <exit>

000000000000007e <main>:

int
main(int argc, char *argv[])
{
  7e:	7179                	addi	sp,sp,-48
  80:	f406                	sd	ra,40(sp)
  82:	f022                	sd	s0,32(sp)
  84:	1800                	addi	s0,sp,48
  int fd, i;

  if(argc <= 1){
  86:	4785                	li	a5,1
  88:	04a7d263          	bge	a5,a0,cc <main+0x4e>
  8c:	ec26                	sd	s1,24(sp)
  8e:	e84a                	sd	s2,16(sp)
  90:	e44e                	sd	s3,8(sp)
  92:	00858913          	addi	s2,a1,8
  96:	ffe5099b          	addiw	s3,a0,-2
  9a:	02099793          	slli	a5,s3,0x20
  9e:	01d7d993          	srli	s3,a5,0x1d
  a2:	05c1                	addi	a1,a1,16
  a4:	99ae                	add	s3,s3,a1
    cat(0);
    exit(0);
  }

  for(i = 1; i < argc; i++){
    if((fd = open(argv[i], O_RDONLY)) < 0){
  a6:	4581                	li	a1,0
  a8:	00093503          	ld	a0,0(s2)
  ac:	316000ef          	jal	3c2 <open>
  b0:	84aa                	mv	s1,a0
  b2:	02054663          	bltz	a0,de <main+0x60>
      fprintf(2, "cat: cannot open %s\n", argv[i]);
      exit(1);
    }
    cat(fd);
  b6:	f4bff0ef          	jal	0 <cat>
    close(fd);
  ba:	8526                	mv	a0,s1
  bc:	2ee000ef          	jal	3aa <close>
  for(i = 1; i < argc; i++){
  c0:	0921                	addi	s2,s2,8
  c2:	ff3912e3          	bne	s2,s3,a6 <main+0x28>
  }
  exit(0);
  c6:	4501                	li	a0,0
  c8:	2ba000ef          	jal	382 <exit>
  cc:	ec26                	sd	s1,24(sp)
  ce:	e84a                	sd	s2,16(sp)
  d0:	e44e                	sd	s3,8(sp)
    cat(0);
  d2:	4501                	li	a0,0
  d4:	f2dff0ef          	jal	0 <cat>
    exit(0);
  d8:	4501                	li	a0,0
  da:	2a8000ef          	jal	382 <exit>
      fprintf(2, "cat: cannot open %s\n", argv[i]);
  de:	00093603          	ld	a2,0(s2)
  e2:	00001597          	auipc	a1,0x1
  e6:	a9e58593          	addi	a1,a1,-1378 # b80 <thread_switch+0x9c>
  ea:	4509                	li	a0,2
  ec:	6ae000ef          	jal	79a <fprintf>
      exit(1);
  f0:	4505                	li	a0,1
  f2:	290000ef          	jal	382 <exit>

00000000000000f6 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  f6:	1141                	addi	sp,sp,-16
  f8:	e406                	sd	ra,8(sp)
  fa:	e022                	sd	s0,0(sp)
  fc:	0800                	addi	s0,sp,16
  extern int main();
  main();
  fe:	f81ff0ef          	jal	7e <main>
  exit(0);
 102:	4501                	li	a0,0
 104:	27e000ef          	jal	382 <exit>

0000000000000108 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 108:	1141                	addi	sp,sp,-16
 10a:	e406                	sd	ra,8(sp)
 10c:	e022                	sd	s0,0(sp)
 10e:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 110:	87aa                	mv	a5,a0
 112:	0585                	addi	a1,a1,1
 114:	0785                	addi	a5,a5,1
 116:	fff5c703          	lbu	a4,-1(a1)
 11a:	fee78fa3          	sb	a4,-1(a5)
 11e:	fb75                	bnez	a4,112 <strcpy+0xa>
    ;
  return os;
}
 120:	60a2                	ld	ra,8(sp)
 122:	6402                	ld	s0,0(sp)
 124:	0141                	addi	sp,sp,16
 126:	8082                	ret

0000000000000128 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 128:	1141                	addi	sp,sp,-16
 12a:	e406                	sd	ra,8(sp)
 12c:	e022                	sd	s0,0(sp)
 12e:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 130:	00054783          	lbu	a5,0(a0)
 134:	cb91                	beqz	a5,148 <strcmp+0x20>
 136:	0005c703          	lbu	a4,0(a1)
 13a:	00f71763          	bne	a4,a5,148 <strcmp+0x20>
    p++, q++;
 13e:	0505                	addi	a0,a0,1
 140:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 142:	00054783          	lbu	a5,0(a0)
 146:	fbe5                	bnez	a5,136 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 148:	0005c503          	lbu	a0,0(a1)
}
 14c:	40a7853b          	subw	a0,a5,a0
 150:	60a2                	ld	ra,8(sp)
 152:	6402                	ld	s0,0(sp)
 154:	0141                	addi	sp,sp,16
 156:	8082                	ret

0000000000000158 <strlen>:

uint
strlen(const char *s)
{
 158:	1141                	addi	sp,sp,-16
 15a:	e406                	sd	ra,8(sp)
 15c:	e022                	sd	s0,0(sp)
 15e:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 160:	00054783          	lbu	a5,0(a0)
 164:	cf91                	beqz	a5,180 <strlen+0x28>
 166:	00150793          	addi	a5,a0,1
 16a:	86be                	mv	a3,a5
 16c:	0785                	addi	a5,a5,1
 16e:	fff7c703          	lbu	a4,-1(a5)
 172:	ff65                	bnez	a4,16a <strlen+0x12>
 174:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 178:	60a2                	ld	ra,8(sp)
 17a:	6402                	ld	s0,0(sp)
 17c:	0141                	addi	sp,sp,16
 17e:	8082                	ret
  for(n = 0; s[n]; n++)
 180:	4501                	li	a0,0
 182:	bfdd                	j	178 <strlen+0x20>

0000000000000184 <memset>:

void*
memset(void *dst, int c, uint n)
{
 184:	1141                	addi	sp,sp,-16
 186:	e406                	sd	ra,8(sp)
 188:	e022                	sd	s0,0(sp)
 18a:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 18c:	ca19                	beqz	a2,1a2 <memset+0x1e>
 18e:	87aa                	mv	a5,a0
 190:	1602                	slli	a2,a2,0x20
 192:	9201                	srli	a2,a2,0x20
 194:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 198:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 19c:	0785                	addi	a5,a5,1
 19e:	fee79de3          	bne	a5,a4,198 <memset+0x14>
  }
  return dst;
}
 1a2:	60a2                	ld	ra,8(sp)
 1a4:	6402                	ld	s0,0(sp)
 1a6:	0141                	addi	sp,sp,16
 1a8:	8082                	ret

00000000000001aa <strchr>:

char*
strchr(const char *s, char c)
{
 1aa:	1141                	addi	sp,sp,-16
 1ac:	e406                	sd	ra,8(sp)
 1ae:	e022                	sd	s0,0(sp)
 1b0:	0800                	addi	s0,sp,16
  for(; *s; s++)
 1b2:	00054783          	lbu	a5,0(a0)
 1b6:	c799                	beqz	a5,1c4 <strchr+0x1a>
    if(*s == c)
 1b8:	00f58763          	beq	a1,a5,1c6 <strchr+0x1c>
  for(; *s; s++)
 1bc:	0505                	addi	a0,a0,1
 1be:	00054783          	lbu	a5,0(a0)
 1c2:	fbfd                	bnez	a5,1b8 <strchr+0xe>
      return (char*)s;
  return 0;
 1c4:	4501                	li	a0,0
}
 1c6:	60a2                	ld	ra,8(sp)
 1c8:	6402                	ld	s0,0(sp)
 1ca:	0141                	addi	sp,sp,16
 1cc:	8082                	ret

00000000000001ce <gets>:

char*
gets(char *buf, int max)
{
 1ce:	711d                	addi	sp,sp,-96
 1d0:	ec86                	sd	ra,88(sp)
 1d2:	e8a2                	sd	s0,80(sp)
 1d4:	e4a6                	sd	s1,72(sp)
 1d6:	e0ca                	sd	s2,64(sp)
 1d8:	fc4e                	sd	s3,56(sp)
 1da:	f852                	sd	s4,48(sp)
 1dc:	f456                	sd	s5,40(sp)
 1de:	f05a                	sd	s6,32(sp)
 1e0:	ec5e                	sd	s7,24(sp)
 1e2:	e862                	sd	s8,16(sp)
 1e4:	1080                	addi	s0,sp,96
 1e6:	8baa                	mv	s7,a0
 1e8:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 1ea:	892a                	mv	s2,a0
 1ec:	4481                	li	s1,0
    cc = read(0, &c, 1);
 1ee:	faf40b13          	addi	s6,s0,-81
 1f2:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 1f4:	8c26                	mv	s8,s1
 1f6:	0014899b          	addiw	s3,s1,1
 1fa:	84ce                	mv	s1,s3
 1fc:	0349d863          	bge	s3,s4,22c <gets+0x5e>
    cc = read(0, &c, 1);
 200:	8656                	mv	a2,s5
 202:	85da                	mv	a1,s6
 204:	4501                	li	a0,0
 206:	194000ef          	jal	39a <read>
    if(cc < 1)
 20a:	02a05163          	blez	a0,22c <gets+0x5e>
      break;
    buf[i++] = c;
 20e:	faf44783          	lbu	a5,-81(s0)
 212:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 216:	0905                	addi	s2,s2,1
 218:	ff678713          	addi	a4,a5,-10
 21c:	00173713          	seqz	a4,a4
 220:	17cd                	addi	a5,a5,-13
 222:	0017b793          	seqz	a5,a5
 226:	8fd9                	or	a5,a5,a4
 228:	d7f1                	beqz	a5,1f4 <gets+0x26>
    buf[i++] = c;
 22a:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 22c:	9c5e                	add	s8,s8,s7
 22e:	000c0023          	sb	zero,0(s8)
  return buf;
}
 232:	855e                	mv	a0,s7
 234:	60e6                	ld	ra,88(sp)
 236:	6446                	ld	s0,80(sp)
 238:	64a6                	ld	s1,72(sp)
 23a:	6906                	ld	s2,64(sp)
 23c:	79e2                	ld	s3,56(sp)
 23e:	7a42                	ld	s4,48(sp)
 240:	7aa2                	ld	s5,40(sp)
 242:	7b02                	ld	s6,32(sp)
 244:	6be2                	ld	s7,24(sp)
 246:	6c42                	ld	s8,16(sp)
 248:	6125                	addi	sp,sp,96
 24a:	8082                	ret

000000000000024c <stat>:

int
stat(const char *n, struct stat *st)
{
 24c:	1101                	addi	sp,sp,-32
 24e:	ec06                	sd	ra,24(sp)
 250:	e822                	sd	s0,16(sp)
 252:	e04a                	sd	s2,0(sp)
 254:	1000                	addi	s0,sp,32
 256:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 258:	4581                	li	a1,0
 25a:	168000ef          	jal	3c2 <open>
  if(fd < 0)
 25e:	02054263          	bltz	a0,282 <stat+0x36>
 262:	e426                	sd	s1,8(sp)
 264:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 266:	85ca                	mv	a1,s2
 268:	172000ef          	jal	3da <fstat>
 26c:	892a                	mv	s2,a0
  close(fd);
 26e:	8526                	mv	a0,s1
 270:	13a000ef          	jal	3aa <close>
  return r;
 274:	64a2                	ld	s1,8(sp)
}
 276:	854a                	mv	a0,s2
 278:	60e2                	ld	ra,24(sp)
 27a:	6442                	ld	s0,16(sp)
 27c:	6902                	ld	s2,0(sp)
 27e:	6105                	addi	sp,sp,32
 280:	8082                	ret
    return -1;
 282:	57fd                	li	a5,-1
 284:	893e                	mv	s2,a5
 286:	bfc5                	j	276 <stat+0x2a>

0000000000000288 <atoi>:

int
atoi(const char *s)
{
 288:	1141                	addi	sp,sp,-16
 28a:	e406                	sd	ra,8(sp)
 28c:	e022                	sd	s0,0(sp)
 28e:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 290:	00054683          	lbu	a3,0(a0)
 294:	fd06879b          	addiw	a5,a3,-48
 298:	0ff7f793          	zext.b	a5,a5
 29c:	4625                	li	a2,9
 29e:	02f66963          	bltu	a2,a5,2d0 <atoi+0x48>
 2a2:	872a                	mv	a4,a0
  n = 0;
 2a4:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 2a6:	0705                	addi	a4,a4,1
 2a8:	0025179b          	slliw	a5,a0,0x2
 2ac:	9fa9                	addw	a5,a5,a0
 2ae:	0017979b          	slliw	a5,a5,0x1
 2b2:	9fb5                	addw	a5,a5,a3
 2b4:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 2b8:	00074683          	lbu	a3,0(a4)
 2bc:	fd06879b          	addiw	a5,a3,-48
 2c0:	0ff7f793          	zext.b	a5,a5
 2c4:	fef671e3          	bgeu	a2,a5,2a6 <atoi+0x1e>
  return n;
}
 2c8:	60a2                	ld	ra,8(sp)
 2ca:	6402                	ld	s0,0(sp)
 2cc:	0141                	addi	sp,sp,16
 2ce:	8082                	ret
  n = 0;
 2d0:	4501                	li	a0,0
 2d2:	bfdd                	j	2c8 <atoi+0x40>

00000000000002d4 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 2d4:	1141                	addi	sp,sp,-16
 2d6:	e406                	sd	ra,8(sp)
 2d8:	e022                	sd	s0,0(sp)
 2da:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 2dc:	02b57563          	bgeu	a0,a1,306 <memmove+0x32>
    while(n-- > 0)
 2e0:	00c05f63          	blez	a2,2fe <memmove+0x2a>
 2e4:	1602                	slli	a2,a2,0x20
 2e6:	9201                	srli	a2,a2,0x20
 2e8:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 2ec:	872a                	mv	a4,a0
      *dst++ = *src++;
 2ee:	0585                	addi	a1,a1,1
 2f0:	0705                	addi	a4,a4,1
 2f2:	fff5c683          	lbu	a3,-1(a1)
 2f6:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 2fa:	fee79ae3          	bne	a5,a4,2ee <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 2fe:	60a2                	ld	ra,8(sp)
 300:	6402                	ld	s0,0(sp)
 302:	0141                	addi	sp,sp,16
 304:	8082                	ret
    while(n-- > 0)
 306:	fec05ce3          	blez	a2,2fe <memmove+0x2a>
    dst += n;
 30a:	00c50733          	add	a4,a0,a2
    src += n;
 30e:	95b2                	add	a1,a1,a2
 310:	fff6079b          	addiw	a5,a2,-1
 314:	1782                	slli	a5,a5,0x20
 316:	9381                	srli	a5,a5,0x20
 318:	fff7c793          	not	a5,a5
 31c:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 31e:	15fd                	addi	a1,a1,-1
 320:	177d                	addi	a4,a4,-1
 322:	0005c683          	lbu	a3,0(a1)
 326:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 32a:	fef71ae3          	bne	a4,a5,31e <memmove+0x4a>
 32e:	bfc1                	j	2fe <memmove+0x2a>

0000000000000330 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 330:	1141                	addi	sp,sp,-16
 332:	e406                	sd	ra,8(sp)
 334:	e022                	sd	s0,0(sp)
 336:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 338:	ce19                	beqz	a2,356 <memcmp+0x26>
 33a:	1602                	slli	a2,a2,0x20
 33c:	9201                	srli	a2,a2,0x20
 33e:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 342:	00054783          	lbu	a5,0(a0)
 346:	0005c703          	lbu	a4,0(a1)
 34a:	00e79b63          	bne	a5,a4,360 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 34e:	0505                	addi	a0,a0,1
    p2++;
 350:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 352:	fed518e3          	bne	a0,a3,342 <memcmp+0x12>
  }
  return 0;
 356:	4501                	li	a0,0
}
 358:	60a2                	ld	ra,8(sp)
 35a:	6402                	ld	s0,0(sp)
 35c:	0141                	addi	sp,sp,16
 35e:	8082                	ret
      return *p1 - *p2;
 360:	40e7853b          	subw	a0,a5,a4
 364:	bfd5                	j	358 <memcmp+0x28>

0000000000000366 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 366:	1141                	addi	sp,sp,-16
 368:	e406                	sd	ra,8(sp)
 36a:	e022                	sd	s0,0(sp)
 36c:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 36e:	f67ff0ef          	jal	2d4 <memmove>
}
 372:	60a2                	ld	ra,8(sp)
 374:	6402                	ld	s0,0(sp)
 376:	0141                	addi	sp,sp,16
 378:	8082                	ret

000000000000037a <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 37a:	4885                	li	a7,1
 ecall
 37c:	00000073          	ecall
 ret
 380:	8082                	ret

0000000000000382 <exit>:
.global exit
exit:
 li a7, SYS_exit
 382:	4889                	li	a7,2
 ecall
 384:	00000073          	ecall
 ret
 388:	8082                	ret

000000000000038a <wait>:
.global wait
wait:
 li a7, SYS_wait
 38a:	488d                	li	a7,3
 ecall
 38c:	00000073          	ecall
 ret
 390:	8082                	ret

0000000000000392 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 392:	4891                	li	a7,4
 ecall
 394:	00000073          	ecall
 ret
 398:	8082                	ret

000000000000039a <read>:
.global read
read:
 li a7, SYS_read
 39a:	4895                	li	a7,5
 ecall
 39c:	00000073          	ecall
 ret
 3a0:	8082                	ret

00000000000003a2 <write>:
.global write
write:
 li a7, SYS_write
 3a2:	48c1                	li	a7,16
 ecall
 3a4:	00000073          	ecall
 ret
 3a8:	8082                	ret

00000000000003aa <close>:
.global close
close:
 li a7, SYS_close
 3aa:	48d5                	li	a7,21
 ecall
 3ac:	00000073          	ecall
 ret
 3b0:	8082                	ret

00000000000003b2 <kill>:
.global kill
kill:
 li a7, SYS_kill
 3b2:	4899                	li	a7,6
 ecall
 3b4:	00000073          	ecall
 ret
 3b8:	8082                	ret

00000000000003ba <exec>:
.global exec
exec:
 li a7, SYS_exec
 3ba:	489d                	li	a7,7
 ecall
 3bc:	00000073          	ecall
 ret
 3c0:	8082                	ret

00000000000003c2 <open>:
.global open
open:
 li a7, SYS_open
 3c2:	48bd                	li	a7,15
 ecall
 3c4:	00000073          	ecall
 ret
 3c8:	8082                	ret

00000000000003ca <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 3ca:	48c5                	li	a7,17
 ecall
 3cc:	00000073          	ecall
 ret
 3d0:	8082                	ret

00000000000003d2 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 3d2:	48c9                	li	a7,18
 ecall
 3d4:	00000073          	ecall
 ret
 3d8:	8082                	ret

00000000000003da <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 3da:	48a1                	li	a7,8
 ecall
 3dc:	00000073          	ecall
 ret
 3e0:	8082                	ret

00000000000003e2 <link>:
.global link
link:
 li a7, SYS_link
 3e2:	48cd                	li	a7,19
 ecall
 3e4:	00000073          	ecall
 ret
 3e8:	8082                	ret

00000000000003ea <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 3ea:	48d1                	li	a7,20
 ecall
 3ec:	00000073          	ecall
 ret
 3f0:	8082                	ret

00000000000003f2 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 3f2:	48a5                	li	a7,9
 ecall
 3f4:	00000073          	ecall
 ret
 3f8:	8082                	ret

00000000000003fa <dup>:
.global dup
dup:
 li a7, SYS_dup
 3fa:	48a9                	li	a7,10
 ecall
 3fc:	00000073          	ecall
 ret
 400:	8082                	ret

0000000000000402 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 402:	48ad                	li	a7,11
 ecall
 404:	00000073          	ecall
 ret
 408:	8082                	ret

000000000000040a <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 40a:	48b1                	li	a7,12
 ecall
 40c:	00000073          	ecall
 ret
 410:	8082                	ret

0000000000000412 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 412:	48b5                	li	a7,13
 ecall
 414:	00000073          	ecall
 ret
 418:	8082                	ret

000000000000041a <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 41a:	48b9                	li	a7,14
 ecall
 41c:	00000073          	ecall
 ret
 420:	8082                	ret

0000000000000422 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 422:	1101                	addi	sp,sp,-32
 424:	ec06                	sd	ra,24(sp)
 426:	e822                	sd	s0,16(sp)
 428:	1000                	addi	s0,sp,32
 42a:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 42e:	4605                	li	a2,1
 430:	fef40593          	addi	a1,s0,-17
 434:	f6fff0ef          	jal	3a2 <write>
}
 438:	60e2                	ld	ra,24(sp)
 43a:	6442                	ld	s0,16(sp)
 43c:	6105                	addi	sp,sp,32
 43e:	8082                	ret

0000000000000440 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 440:	715d                	addi	sp,sp,-80
 442:	e486                	sd	ra,72(sp)
 444:	e0a2                	sd	s0,64(sp)
 446:	f84a                	sd	s2,48(sp)
 448:	f44e                	sd	s3,40(sp)
 44a:	0880                	addi	s0,sp,80
 44c:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 44e:	00d036b3          	snez	a3,a3
 452:	03f5d793          	srli	a5,a1,0x3f
 456:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 458:	0005871b          	sext.w	a4,a1
  neg = 0;
 45c:	4301                	li	t1,0
  if(sgn && xx < 0){
 45e:	c681                	beqz	a3,466 <printint+0x26>
    x = -xx;
 460:	40b0073b          	negw	a4,a1
    neg = 1;
 464:	4305                	li	t1,1
  }

  i = 0;
 466:	fb840993          	addi	s3,s0,-72
  neg = 0;
 46a:	85ce                	mv	a1,s3
  i = 0;
 46c:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 46e:	00000817          	auipc	a6,0x0
 472:	75a80813          	addi	a6,a6,1882 # bc8 <digits>
 476:	88b6                	mv	a7,a3
 478:	0016851b          	addiw	a0,a3,1
 47c:	86aa                	mv	a3,a0
 47e:	02c777bb          	remuw	a5,a4,a2
 482:	1782                	slli	a5,a5,0x20
 484:	9381                	srli	a5,a5,0x20
 486:	97c2                	add	a5,a5,a6
 488:	0007c783          	lbu	a5,0(a5)
 48c:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 490:	87ba                	mv	a5,a4
 492:	02c7573b          	divuw	a4,a4,a2
 496:	0585                	addi	a1,a1,1
 498:	fcc7ffe3          	bgeu	a5,a2,476 <printint+0x36>
  if(neg)
 49c:	00030b63          	beqz	t1,4b2 <printint+0x72>
    buf[i++] = '-';
 4a0:	fd040793          	addi	a5,s0,-48
 4a4:	953e                	add	a0,a0,a5
 4a6:	02d00793          	li	a5,45
 4aa:	fef50423          	sb	a5,-24(a0)
 4ae:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 4b2:	02d05563          	blez	a3,4dc <printint+0x9c>
 4b6:	fc26                	sd	s1,56(sp)
 4b8:	36fd                	addiw	a3,a3,-1
 4ba:	00d984b3          	add	s1,s3,a3
 4be:	19fd                	addi	s3,s3,-1
 4c0:	99b6                	add	s3,s3,a3
 4c2:	1682                	slli	a3,a3,0x20
 4c4:	9281                	srli	a3,a3,0x20
 4c6:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 4ca:	0004c583          	lbu	a1,0(s1)
 4ce:	854a                	mv	a0,s2
 4d0:	f53ff0ef          	jal	422 <putc>
  while(--i >= 0)
 4d4:	14fd                	addi	s1,s1,-1
 4d6:	ff349ae3          	bne	s1,s3,4ca <printint+0x8a>
 4da:	74e2                	ld	s1,56(sp)
}
 4dc:	60a6                	ld	ra,72(sp)
 4de:	6406                	ld	s0,64(sp)
 4e0:	7942                	ld	s2,48(sp)
 4e2:	79a2                	ld	s3,40(sp)
 4e4:	6161                	addi	sp,sp,80
 4e6:	8082                	ret

00000000000004e8 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 4e8:	711d                	addi	sp,sp,-96
 4ea:	ec86                	sd	ra,88(sp)
 4ec:	e8a2                	sd	s0,80(sp)
 4ee:	e4a6                	sd	s1,72(sp)
 4f0:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 4f2:	0005c483          	lbu	s1,0(a1)
 4f6:	28048263          	beqz	s1,77a <vprintf+0x292>
 4fa:	e0ca                	sd	s2,64(sp)
 4fc:	fc4e                	sd	s3,56(sp)
 4fe:	f852                	sd	s4,48(sp)
 500:	f456                	sd	s5,40(sp)
 502:	f05a                	sd	s6,32(sp)
 504:	ec5e                	sd	s7,24(sp)
 506:	e862                	sd	s8,16(sp)
 508:	8b2a                	mv	s6,a0
 50a:	8a2e                	mv	s4,a1
 50c:	8bb2                	mv	s7,a2
  state = 0;
 50e:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 510:	4901                	li	s2,0
 512:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 514:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 518:	06400c13          	li	s8,100
 51c:	a00d                	j	53e <vprintf+0x56>
        putc(fd, c0);
 51e:	85a6                	mv	a1,s1
 520:	855a                	mv	a0,s6
 522:	f01ff0ef          	jal	422 <putc>
 526:	a019                	j	52c <vprintf+0x44>
    } else if(state == '%'){
 528:	03598363          	beq	s3,s5,54e <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 52c:	0019079b          	addiw	a5,s2,1
 530:	893e                	mv	s2,a5
 532:	873e                	mv	a4,a5
 534:	97d2                	add	a5,a5,s4
 536:	0007c483          	lbu	s1,0(a5)
 53a:	22048963          	beqz	s1,76c <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 53e:	0004879b          	sext.w	a5,s1
    if(state == 0){
 542:	fe0993e3          	bnez	s3,528 <vprintf+0x40>
      if(c0 == '%'){
 546:	fd579ce3          	bne	a5,s5,51e <vprintf+0x36>
        state = '%';
 54a:	89be                	mv	s3,a5
 54c:	b7c5                	j	52c <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 54e:	00ea06b3          	add	a3,s4,a4
 552:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 556:	22060763          	beqz	a2,784 <vprintf+0x29c>
      if(c0 == 'd'){
 55a:	0b878363          	beq	a5,s8,600 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 55e:	f9478693          	addi	a3,a5,-108
 562:	0016b693          	seqz	a3,a3
 566:	f9c60593          	addi	a1,a2,-100
 56a:	0015b593          	seqz	a1,a1
 56e:	8df5                	and	a1,a1,a3
 570:	e5c5                	bnez	a1,618 <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 572:	9752                	add	a4,a4,s4
 574:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 578:	f9460713          	addi	a4,a2,-108
 57c:	00173713          	seqz	a4,a4
 580:	8f75                	and	a4,a4,a3
 582:	f9c50593          	addi	a1,a0,-100
 586:	0015b593          	seqz	a1,a1
 58a:	8df9                	and	a1,a1,a4
 58c:	e1dd                	bnez	a1,632 <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 58e:	07500593          	li	a1,117
 592:	0ab78d63          	beq	a5,a1,64c <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 596:	f8b60593          	addi	a1,a2,-117
 59a:	0015b593          	seqz	a1,a1
 59e:	8df5                	and	a1,a1,a3
 5a0:	e1f1                	bnez	a1,664 <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 5a2:	f8b50593          	addi	a1,a0,-117
 5a6:	0015b593          	seqz	a1,a1
 5aa:	8df9                	and	a1,a1,a4
 5ac:	e9e9                	bnez	a1,67e <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 5ae:	07800593          	li	a1,120
 5b2:	0eb78363          	beq	a5,a1,698 <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 5b6:	f8860613          	addi	a2,a2,-120
 5ba:	00163613          	seqz	a2,a2
 5be:	8ef1                	and	a3,a3,a2
 5c0:	0e069863          	bnez	a3,6b0 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 5c4:	f8850513          	addi	a0,a0,-120
 5c8:	00153513          	seqz	a0,a0
 5cc:	8f69                	and	a4,a4,a0
 5ce:	0e071e63          	bnez	a4,6ca <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 5d2:	07000713          	li	a4,112
 5d6:	10e78663          	beq	a5,a4,6e2 <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 5da:	07300713          	li	a4,115
 5de:	14e78663          	beq	a5,a4,72a <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 5e2:	02500713          	li	a4,37
 5e6:	16e78e63          	beq	a5,a4,762 <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 5ea:	02500593          	li	a1,37
 5ee:	855a                	mv	a0,s6
 5f0:	e33ff0ef          	jal	422 <putc>
        putc(fd, c0);
 5f4:	85a6                	mv	a1,s1
 5f6:	855a                	mv	a0,s6
 5f8:	e2bff0ef          	jal	422 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 5fc:	4981                	li	s3,0
 5fe:	b73d                	j	52c <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 600:	008b8493          	addi	s1,s7,8
 604:	4685                	li	a3,1
 606:	4629                	li	a2,10
 608:	000ba583          	lw	a1,0(s7)
 60c:	855a                	mv	a0,s6
 60e:	e33ff0ef          	jal	440 <printint>
 612:	8ba6                	mv	s7,s1
      state = 0;
 614:	4981                	li	s3,0
 616:	bf19                	j	52c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 618:	008b8493          	addi	s1,s7,8
 61c:	4685                	li	a3,1
 61e:	4629                	li	a2,10
 620:	000bb583          	ld	a1,0(s7)
 624:	855a                	mv	a0,s6
 626:	e1bff0ef          	jal	440 <printint>
        i += 1;
 62a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 62c:	8ba6                	mv	s7,s1
      state = 0;
 62e:	4981                	li	s3,0
 630:	bdf5                	j	52c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 632:	008b8493          	addi	s1,s7,8
 636:	4685                	li	a3,1
 638:	4629                	li	a2,10
 63a:	000bb583          	ld	a1,0(s7)
 63e:	855a                	mv	a0,s6
 640:	e01ff0ef          	jal	440 <printint>
        i += 2;
 644:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 646:	8ba6                	mv	s7,s1
      state = 0;
 648:	4981                	li	s3,0
        i += 2;
 64a:	b5cd                	j	52c <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 64c:	008b8493          	addi	s1,s7,8
 650:	4681                	li	a3,0
 652:	4629                	li	a2,10
 654:	000ba583          	lw	a1,0(s7)
 658:	855a                	mv	a0,s6
 65a:	de7ff0ef          	jal	440 <printint>
 65e:	8ba6                	mv	s7,s1
      state = 0;
 660:	4981                	li	s3,0
 662:	b5e9                	j	52c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 664:	008b8493          	addi	s1,s7,8
 668:	4681                	li	a3,0
 66a:	4629                	li	a2,10
 66c:	000bb583          	ld	a1,0(s7)
 670:	855a                	mv	a0,s6
 672:	dcfff0ef          	jal	440 <printint>
        i += 1;
 676:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 678:	8ba6                	mv	s7,s1
      state = 0;
 67a:	4981                	li	s3,0
 67c:	bd45                	j	52c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 67e:	008b8493          	addi	s1,s7,8
 682:	4681                	li	a3,0
 684:	4629                	li	a2,10
 686:	000bb583          	ld	a1,0(s7)
 68a:	855a                	mv	a0,s6
 68c:	db5ff0ef          	jal	440 <printint>
        i += 2;
 690:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 692:	8ba6                	mv	s7,s1
      state = 0;
 694:	4981                	li	s3,0
        i += 2;
 696:	bd59                	j	52c <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 698:	008b8493          	addi	s1,s7,8
 69c:	4681                	li	a3,0
 69e:	4641                	li	a2,16
 6a0:	000ba583          	lw	a1,0(s7)
 6a4:	855a                	mv	a0,s6
 6a6:	d9bff0ef          	jal	440 <printint>
 6aa:	8ba6                	mv	s7,s1
      state = 0;
 6ac:	4981                	li	s3,0
 6ae:	bdbd                	j	52c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6b0:	008b8493          	addi	s1,s7,8
 6b4:	4681                	li	a3,0
 6b6:	4641                	li	a2,16
 6b8:	000bb583          	ld	a1,0(s7)
 6bc:	855a                	mv	a0,s6
 6be:	d83ff0ef          	jal	440 <printint>
        i += 1;
 6c2:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 6c4:	8ba6                	mv	s7,s1
      state = 0;
 6c6:	4981                	li	s3,0
 6c8:	b595                	j	52c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6ca:	008b8493          	addi	s1,s7,8
 6ce:	4641                	li	a2,16
 6d0:	000bb583          	ld	a1,0(s7)
 6d4:	855a                	mv	a0,s6
 6d6:	d6bff0ef          	jal	440 <printint>
        i += 2;
 6da:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 6dc:	8ba6                	mv	s7,s1
      state = 0;
 6de:	4981                	li	s3,0
        i += 2;
 6e0:	b5b1                	j	52c <vprintf+0x44>
 6e2:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 6e4:	008b8793          	addi	a5,s7,8
 6e8:	8cbe                	mv	s9,a5
 6ea:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 6ee:	03000593          	li	a1,48
 6f2:	855a                	mv	a0,s6
 6f4:	d2fff0ef          	jal	422 <putc>
  putc(fd, 'x');
 6f8:	07800593          	li	a1,120
 6fc:	855a                	mv	a0,s6
 6fe:	d25ff0ef          	jal	422 <putc>
 702:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 704:	00000b97          	auipc	s7,0x0
 708:	4c4b8b93          	addi	s7,s7,1220 # bc8 <digits>
 70c:	03c9d793          	srli	a5,s3,0x3c
 710:	97de                	add	a5,a5,s7
 712:	0007c583          	lbu	a1,0(a5)
 716:	855a                	mv	a0,s6
 718:	d0bff0ef          	jal	422 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 71c:	0992                	slli	s3,s3,0x4
 71e:	34fd                	addiw	s1,s1,-1
 720:	f4f5                	bnez	s1,70c <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 722:	8be6                	mv	s7,s9
      state = 0;
 724:	4981                	li	s3,0
 726:	6ca2                	ld	s9,8(sp)
 728:	b511                	j	52c <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 72a:	008b8993          	addi	s3,s7,8
 72e:	000bb483          	ld	s1,0(s7)
 732:	cc91                	beqz	s1,74e <vprintf+0x266>
        for(; *s; s++)
 734:	0004c583          	lbu	a1,0(s1)
 738:	c195                	beqz	a1,75c <vprintf+0x274>
          putc(fd, *s);
 73a:	855a                	mv	a0,s6
 73c:	ce7ff0ef          	jal	422 <putc>
        for(; *s; s++)
 740:	0485                	addi	s1,s1,1
 742:	0004c583          	lbu	a1,0(s1)
 746:	f9f5                	bnez	a1,73a <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 748:	8bce                	mv	s7,s3
      state = 0;
 74a:	4981                	li	s3,0
 74c:	b3c5                	j	52c <vprintf+0x44>
          s = "(null)";
 74e:	00000497          	auipc	s1,0x0
 752:	44a48493          	addi	s1,s1,1098 # b98 <thread_switch+0xb4>
        for(; *s; s++)
 756:	02800593          	li	a1,40
 75a:	b7c5                	j	73a <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 75c:	8bce                	mv	s7,s3
      state = 0;
 75e:	4981                	li	s3,0
 760:	b3f1                	j	52c <vprintf+0x44>
        putc(fd, '%');
 762:	85be                	mv	a1,a5
 764:	855a                	mv	a0,s6
 766:	cbdff0ef          	jal	422 <putc>
 76a:	bd49                	j	5fc <vprintf+0x114>
 76c:	6906                	ld	s2,64(sp)
 76e:	79e2                	ld	s3,56(sp)
 770:	7a42                	ld	s4,48(sp)
 772:	7aa2                	ld	s5,40(sp)
 774:	7b02                	ld	s6,32(sp)
 776:	6be2                	ld	s7,24(sp)
 778:	6c42                	ld	s8,16(sp)
    }
  }
}
 77a:	60e6                	ld	ra,88(sp)
 77c:	6446                	ld	s0,80(sp)
 77e:	64a6                	ld	s1,72(sp)
 780:	6125                	addi	sp,sp,96
 782:	8082                	ret
      if(c0 == 'd'){
 784:	06400713          	li	a4,100
 788:	e6e78ce3          	beq	a5,a4,600 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 78c:	f9478693          	addi	a3,a5,-108
 790:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 794:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 796:	4701                	li	a4,0
 798:	bbdd                	j	58e <vprintf+0xa6>

000000000000079a <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 79a:	715d                	addi	sp,sp,-80
 79c:	ec06                	sd	ra,24(sp)
 79e:	e822                	sd	s0,16(sp)
 7a0:	1000                	addi	s0,sp,32
 7a2:	e010                	sd	a2,0(s0)
 7a4:	e414                	sd	a3,8(s0)
 7a6:	e818                	sd	a4,16(s0)
 7a8:	ec1c                	sd	a5,24(s0)
 7aa:	03043023          	sd	a6,32(s0)
 7ae:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 7b2:	8622                	mv	a2,s0
 7b4:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 7b8:	d31ff0ef          	jal	4e8 <vprintf>
}
 7bc:	60e2                	ld	ra,24(sp)
 7be:	6442                	ld	s0,16(sp)
 7c0:	6161                	addi	sp,sp,80
 7c2:	8082                	ret

00000000000007c4 <printf>:

void
printf(const char *fmt, ...)
{
 7c4:	711d                	addi	sp,sp,-96
 7c6:	ec06                	sd	ra,24(sp)
 7c8:	e822                	sd	s0,16(sp)
 7ca:	1000                	addi	s0,sp,32
 7cc:	e40c                	sd	a1,8(s0)
 7ce:	e810                	sd	a2,16(s0)
 7d0:	ec14                	sd	a3,24(s0)
 7d2:	f018                	sd	a4,32(s0)
 7d4:	f41c                	sd	a5,40(s0)
 7d6:	03043823          	sd	a6,48(s0)
 7da:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 7de:	00840613          	addi	a2,s0,8
 7e2:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 7e6:	85aa                	mv	a1,a0
 7e8:	4505                	li	a0,1
 7ea:	cffff0ef          	jal	4e8 <vprintf>
}
 7ee:	60e2                	ld	ra,24(sp)
 7f0:	6442                	ld	s0,16(sp)
 7f2:	6125                	addi	sp,sp,96
 7f4:	8082                	ret

00000000000007f6 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 7f6:	1141                	addi	sp,sp,-16
 7f8:	e406                	sd	ra,8(sp)
 7fa:	e022                	sd	s0,0(sp)
 7fc:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 7fe:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 802:	00000797          	auipc	a5,0x0
 806:	7fe7b783          	ld	a5,2046(a5) # 1000 <freep>
 80a:	a095                	j	86e <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 80c:	ff852583          	lw	a1,-8(a0)
 810:	6390                	ld	a2,0(a5)
 812:	02059813          	slli	a6,a1,0x20
 816:	01c85693          	srli	a3,a6,0x1c
 81a:	96ba                	add	a3,a3,a4
 81c:	02d60563          	beq	a2,a3,846 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 820:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 824:	4790                	lw	a2,8(a5)
 826:	02061593          	slli	a1,a2,0x20
 82a:	01c5d693          	srli	a3,a1,0x1c
 82e:	96be                	add	a3,a3,a5
 830:	02d70263          	beq	a4,a3,854 <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 834:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 836:	00000717          	auipc	a4,0x0
 83a:	7cf73523          	sd	a5,1994(a4) # 1000 <freep>
}
 83e:	60a2                	ld	ra,8(sp)
 840:	6402                	ld	s0,0(sp)
 842:	0141                	addi	sp,sp,16
 844:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 846:	4614                	lw	a3,8(a2)
 848:	9ead                	addw	a3,a3,a1
 84a:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 84e:	6394                	ld	a3,0(a5)
 850:	6290                	ld	a2,0(a3)
 852:	b7f9                	j	820 <free+0x2a>
    p->s.size += bp->s.size;
 854:	ff852703          	lw	a4,-8(a0)
 858:	9f31                	addw	a4,a4,a2
 85a:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 85c:	ff053703          	ld	a4,-16(a0)
 860:	bfd1                	j	834 <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 862:	6394                	ld	a3,0(a5)
 864:	00d7e463          	bltu	a5,a3,86c <free+0x76>
 868:	fad762e3          	bltu	a4,a3,80c <free+0x16>
 86c:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 86e:	fee7fae3          	bgeu	a5,a4,862 <free+0x6c>
 872:	6394                	ld	a3,0(a5)
 874:	f8d76ce3          	bltu	a4,a3,80c <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 878:	f8d7fae3          	bgeu	a5,a3,80c <free+0x16>
 87c:	87b6                	mv	a5,a3
 87e:	bfc5                	j	86e <free+0x78>

0000000000000880 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 880:	7139                	addi	sp,sp,-64
 882:	fc06                	sd	ra,56(sp)
 884:	f822                	sd	s0,48(sp)
 886:	f04a                	sd	s2,32(sp)
 888:	ec4e                	sd	s3,24(sp)
 88a:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 88c:	02051993          	slli	s3,a0,0x20
 890:	0209d993          	srli	s3,s3,0x20
 894:	09bd                	addi	s3,s3,15
 896:	0049d993          	srli	s3,s3,0x4
 89a:	2985                	addiw	s3,s3,1
 89c:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 89e:	00000517          	auipc	a0,0x0
 8a2:	76253503          	ld	a0,1890(a0) # 1000 <freep>
 8a6:	c905                	beqz	a0,8d6 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 8a8:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 8aa:	4798                	lw	a4,8(a5)
 8ac:	09377663          	bgeu	a4,s3,938 <malloc+0xb8>
 8b0:	f426                	sd	s1,40(sp)
 8b2:	e852                	sd	s4,16(sp)
 8b4:	e456                	sd	s5,8(sp)
 8b6:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 8b8:	8a4e                	mv	s4,s3
 8ba:	6705                	lui	a4,0x1
 8bc:	00e9f363          	bgeu	s3,a4,8c2 <malloc+0x42>
 8c0:	6a05                	lui	s4,0x1
 8c2:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 8c6:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 8ca:	00000497          	auipc	s1,0x0
 8ce:	73648493          	addi	s1,s1,1846 # 1000 <freep>
  if(p == (char*)-1)
 8d2:	5afd                	li	s5,-1
 8d4:	a83d                	j	912 <malloc+0x92>
 8d6:	f426                	sd	s1,40(sp)
 8d8:	e852                	sd	s4,16(sp)
 8da:	e456                	sd	s5,8(sp)
 8dc:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 8de:	00001797          	auipc	a5,0x1
 8e2:	93278793          	addi	a5,a5,-1742 # 1210 <base>
 8e6:	00000717          	auipc	a4,0x0
 8ea:	70f73d23          	sd	a5,1818(a4) # 1000 <freep>
 8ee:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 8f0:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 8f4:	b7d1                	j	8b8 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 8f6:	6398                	ld	a4,0(a5)
 8f8:	e118                	sd	a4,0(a0)
 8fa:	a899                	j	950 <malloc+0xd0>
  hp->s.size = nu;
 8fc:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 900:	0541                	addi	a0,a0,16
 902:	ef5ff0ef          	jal	7f6 <free>
  return freep;
 906:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 908:	c125                	beqz	a0,968 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 90a:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 90c:	4798                	lw	a4,8(a5)
 90e:	03277163          	bgeu	a4,s2,930 <malloc+0xb0>
    if(p == freep)
 912:	6098                	ld	a4,0(s1)
 914:	853e                	mv	a0,a5
 916:	fef71ae3          	bne	a4,a5,90a <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 91a:	8552                	mv	a0,s4
 91c:	aefff0ef          	jal	40a <sbrk>
  if(p == (char*)-1)
 920:	fd551ee3          	bne	a0,s5,8fc <malloc+0x7c>
        return 0;
 924:	4501                	li	a0,0
 926:	74a2                	ld	s1,40(sp)
 928:	6a42                	ld	s4,16(sp)
 92a:	6aa2                	ld	s5,8(sp)
 92c:	6b02                	ld	s6,0(sp)
 92e:	a03d                	j	95c <malloc+0xdc>
 930:	74a2                	ld	s1,40(sp)
 932:	6a42                	ld	s4,16(sp)
 934:	6aa2                	ld	s5,8(sp)
 936:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 938:	fae90fe3          	beq	s2,a4,8f6 <malloc+0x76>
        p->s.size -= nunits;
 93c:	4137073b          	subw	a4,a4,s3
 940:	c798                	sw	a4,8(a5)
        p += p->s.size;
 942:	02071693          	slli	a3,a4,0x20
 946:	01c6d713          	srli	a4,a3,0x1c
 94a:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 94c:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 950:	00000717          	auipc	a4,0x0
 954:	6aa73823          	sd	a0,1712(a4) # 1000 <freep>
      return (void*)(p + 1);
 958:	01078513          	addi	a0,a5,16
  }
}
 95c:	70e2                	ld	ra,56(sp)
 95e:	7442                	ld	s0,48(sp)
 960:	7902                	ld	s2,32(sp)
 962:	69e2                	ld	s3,24(sp)
 964:	6121                	addi	sp,sp,64
 966:	8082                	ret
 968:	74a2                	ld	s1,40(sp)
 96a:	6a42                	ld	s4,16(sp)
 96c:	6aa2                	ld	s5,8(sp)
 96e:	6b02                	ld	s6,0(sp)
 970:	b7f5                	j	95c <malloc+0xdc>

0000000000000972 <thread_init>:
struct thread *current_thread;
extern void thread_switch(uint64, uint64);
              
void 
thread_init(void)
{
 972:	1141                	addi	sp,sp,-16
 974:	e406                	sd	ra,8(sp)
 976:	e022                	sd	s0,0(sp)
 978:	0800                	addi	s0,sp,16
  // main() is thread 0, which will make the first invocation to
  // thread_schedule(). It needs a stack so that the first thread_switch() can
  // save thread 0's state.
  current_thread = &all_thread[0];
 97a:	00001797          	auipc	a5,0x1
 97e:	8a678793          	addi	a5,a5,-1882 # 1220 <all_thread>
 982:	00000717          	auipc	a4,0x0
 986:	68f73323          	sd	a5,1670(a4) # 1008 <current_thread>
  current_thread->state = RUNNING;
 98a:	00003717          	auipc	a4,0x3
 98e:	89670713          	addi	a4,a4,-1898 # 3220 <all_thread+0x2000>
 992:	4785                	li	a5,1
 994:	c31c                	sw	a5,0(a4)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 996:	00003797          	auipc	a5,0x3
 99a:	81a78793          	addi	a5,a5,-2022 # 31b0 <all_thread+0x1f90>
  return (struct context *)(top & ~(uint64)0xf);
 99e:	9bc1                	andi	a5,a5,-16
  // Thread 0 runs on the process's own stack, but the first thread_switch()
  // still needs a writable place to save its context.
  current_thread->context = thread_context_slot(current_thread);
 9a0:	e71c                	sd	a5,8(a4)
}
 9a2:	60a2                	ld	ra,8(sp)
 9a4:	6402                	ld	s0,0(sp)
 9a6:	0141                	addi	sp,sp,16
 9a8:	8082                	ret

00000000000009aa <thread_schedule>:

void 
thread_schedule(void)
{
 9aa:	1141                	addi	sp,sp,-16
 9ac:	e406                	sd	ra,8(sp)
 9ae:	e022                	sd	s0,0(sp)
 9b0:	0800                	addi	s0,sp,16
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
 9b2:	00000597          	auipc	a1,0x0
 9b6:	6565b583          	ld	a1,1622(a1) # 1008 <current_thread>
 9ba:	6789                	lui	a5,0x2
 9bc:	07c1                	addi	a5,a5,16 # 2010 <all_thread+0xdf0>
 9be:	97ae                	add	a5,a5,a1
 9c0:	4711                	li	a4,4
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
 9c2:	00009897          	auipc	a7,0x9
 9c6:	89e88893          	addi	a7,a7,-1890 # 9260 <all_thread+0x8040>
      t = all_thread;
    if(t->state == RUNNABLE) {
 9ca:	6809                	lui	a6,0x2
 9cc:	4509                	li	a0,2
      next_thread = t;
      break;
    }
    t = t + 1;
 9ce:	01080613          	addi	a2,a6,16 # 2010 <all_thread+0xdf0>
 9d2:	a809                	j	9e4 <thread_schedule+0x3a>
    if(t->state == RUNNABLE) {
 9d4:	010786b3          	add	a3,a5,a6
 9d8:	4294                	lw	a3,0(a3)
 9da:	02a68563          	beq	a3,a0,a04 <thread_schedule+0x5a>
    t = t + 1;
 9de:	97b2                	add	a5,a5,a2
  for(int i = 0; i < MAX_THREAD; i++){
 9e0:	377d                	addiw	a4,a4,-1
 9e2:	cb01                	beqz	a4,9f2 <thread_schedule+0x48>
    if(t >= all_thread + MAX_THREAD)
 9e4:	ff17e8e3          	bltu	a5,a7,9d4 <thread_schedule+0x2a>
      t = all_thread;
 9e8:	00001797          	auipc	a5,0x1
 9ec:	83878793          	addi	a5,a5,-1992 # 1220 <all_thread>
 9f0:	b7d5                	j	9d4 <thread_schedule+0x2a>
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
 9f2:	00000517          	auipc	a0,0x0
 9f6:	1ae50513          	addi	a0,a0,430 # ba0 <thread_switch+0xbc>
 9fa:	dcbff0ef          	jal	7c4 <printf>
    exit(-1);
 9fe:	557d                	li	a0,-1
 a00:	983ff0ef          	jal	382 <exit>
  }

  if (current_thread != next_thread) {         /* switch threads?  */
 a04:	02f58163          	beq	a1,a5,a26 <thread_schedule+0x7c>
    next_thread->state = RUNNING;
 a08:	6689                	lui	a3,0x2
 a0a:	00d78733          	add	a4,a5,a3
 a0e:	4605                	li	a2,1
 a10:	c310                	sw	a2,0(a4)
    t = current_thread;
    current_thread = next_thread;
 a12:	00000617          	auipc	a2,0x0
 a16:	5ef63b23          	sd	a5,1526(a2) # 1008 <current_thread>
    thread_switch((uint64)t->context, (uint64)next_thread->context);
 a1a:	00d587b3          	add	a5,a1,a3
 a1e:	670c                	ld	a1,8(a4)
 a20:	6788                	ld	a0,8(a5)
 a22:	0c2000ef          	jal	ae4 <thread_switch>
  } else
    next_thread = 0;
}
 a26:	60a2                	ld	ra,8(sp)
 a28:	6402                	ld	s0,0(sp)
 a2a:	0141                	addi	sp,sp,16
 a2c:	8082                	ret

0000000000000a2e <thread_create>:

void 
thread_create(void (*func)())
{
 a2e:	1101                	addi	sp,sp,-32
 a30:	ec06                	sd	ra,24(sp)
 a32:	e822                	sd	s0,16(sp)
 a34:	e426                	sd	s1,8(sp)
 a36:	e04a                	sd	s2,0(sp)
 a38:	1000                	addi	s0,sp,32
 a3a:	892a                	mv	s2,a0
  struct thread *t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 a3c:	00002797          	auipc	a5,0x2
 a40:	7f478793          	addi	a5,a5,2036 # 3230 <all_thread+0x2010>
 a44:	0000b597          	auipc	a1,0xb
 a48:	82c58593          	addi	a1,a1,-2004 # b270 <all_thread+0xa050>
 a4c:	6609                	lui	a2,0x2
 a4e:	0641                	addi	a2,a2,16 # 2010 <all_thread+0xdf0>
    if (t->state == FREE) break;
 a50:	873e                	mv	a4,a5
 a52:	ff07a683          	lw	a3,-16(a5)
 a56:	ce9d                	beqz	a3,a94 <thread_create+0x66>
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 a58:	97b2                	add	a5,a5,a2
 a5a:	feb79be3          	bne	a5,a1,a50 <thread_create+0x22>
  }
  t->state = RUNNABLE;
 a5e:	6489                	lui	s1,0x2
 a60:	94ba                	add	s1,s1,a4
 a62:	4789                	li	a5,2
 a64:	c09c                	sw	a5,0(s1)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 a66:	6789                	lui	a5,0x2
 a68:	f9078793          	addi	a5,a5,-112 # 1f90 <all_thread+0xd70>
 a6c:	973e                	add	a4,a4,a5
  return (struct context *)(top & ~(uint64)0xf);
 a6e:	ff077513          	andi	a0,a4,-16
  // A never-run thread has no saved state, so construct one: thread_switch()
  // restores ra and sp, and `ret` then starts func on this thread's own stack.
  t->context = thread_context_slot(t);
 a72:	e488                	sd	a0,8(s1)
  memset(t->context, 0, sizeof(struct context));
 a74:	07000613          	li	a2,112
 a78:	4581                	li	a1,0
 a7a:	f0aff0ef          	jal	184 <memset>
  t->context->ra = (uint64)func;
 a7e:	649c                	ld	a5,8(s1)
 a80:	0127b023          	sd	s2,0(a5)
  t->context->sp = (uint64)t->context;   // 16-byte aligned, grows down
 a84:	649c                	ld	a5,8(s1)
 a86:	e79c                	sd	a5,8(a5)
}
 a88:	60e2                	ld	ra,24(sp)
 a8a:	6442                	ld	s0,16(sp)
 a8c:	64a2                	ld	s1,8(sp)
 a8e:	6902                	ld	s2,0(sp)
 a90:	6105                	addi	sp,sp,32
 a92:	8082                	ret
 a94:	7779                	lui	a4,0xffffe
 a96:	1741                	addi	a4,a4,-16 # ffffffffffffdff0 <all_thread+0xffffffffffffcdd0>
 a98:	973e                	add	a4,a4,a5
 a9a:	b7d1                	j	a5e <thread_create+0x30>

0000000000000a9c <thread_yield>:

void 
thread_yield(void)
{
 a9c:	1141                	addi	sp,sp,-16
 a9e:	e406                	sd	ra,8(sp)
 aa0:	e022                	sd	s0,0(sp)
 aa2:	0800                	addi	s0,sp,16
  current_thread->state = RUNNABLE;
 aa4:	00000797          	auipc	a5,0x0
 aa8:	5647b783          	ld	a5,1380(a5) # 1008 <current_thread>
 aac:	6709                	lui	a4,0x2
 aae:	97ba                	add	a5,a5,a4
 ab0:	4709                	li	a4,2
 ab2:	c398                	sw	a4,0(a5)
  thread_schedule();
 ab4:	ef7ff0ef          	jal	9aa <thread_schedule>
}
 ab8:	60a2                	ld	ra,8(sp)
 aba:	6402                	ld	s0,0(sp)
 abc:	0141                	addi	sp,sp,16
 abe:	8082                	ret

0000000000000ac0 <thread_exit>:

void thread_exit(void) {
 ac0:	1141                	addi	sp,sp,-16
 ac2:	e406                	sd	ra,8(sp)
 ac4:	e022                	sd	s0,0(sp)
 ac6:	0800                	addi	s0,sp,16
  current_thread->state = FREE;
 ac8:	00000797          	auipc	a5,0x0
 acc:	5407b783          	ld	a5,1344(a5) # 1008 <current_thread>
 ad0:	6709                	lui	a4,0x2
 ad2:	97ba                	add	a5,a5,a4
 ad4:	0007a023          	sw	zero,0(a5)
  thread_schedule();
 ad8:	ed3ff0ef          	jal	9aa <thread_schedule>
}
 adc:	60a2                	ld	ra,8(sp)
 ade:	6402                	ld	s0,0(sp)
 ae0:	0141                	addi	sp,sp,16
 ae2:	8082                	ret

0000000000000ae4 <thread_switch>:
 ae4:	00153023          	sd	ra,0(a0)
 ae8:	00253423          	sd	sp,8(a0)
 aec:	e900                	sd	s0,16(a0)
 aee:	ed04                	sd	s1,24(a0)
 af0:	03253023          	sd	s2,32(a0)
 af4:	03353423          	sd	s3,40(a0)
 af8:	03453823          	sd	s4,48(a0)
 afc:	03553c23          	sd	s5,56(a0)
 b00:	05653023          	sd	s6,64(a0)
 b04:	05753423          	sd	s7,72(a0)
 b08:	05853823          	sd	s8,80(a0)
 b0c:	05953c23          	sd	s9,88(a0)
 b10:	07a53023          	sd	s10,96(a0)
 b14:	07b53423          	sd	s11,104(a0)
 b18:	0005b083          	ld	ra,0(a1)
 b1c:	0085b103          	ld	sp,8(a1)
 b20:	6980                	ld	s0,16(a1)
 b22:	6d84                	ld	s1,24(a1)
 b24:	0205b903          	ld	s2,32(a1)
 b28:	0285b983          	ld	s3,40(a1)
 b2c:	0305ba03          	ld	s4,48(a1)
 b30:	0385ba83          	ld	s5,56(a1)
 b34:	0405bb03          	ld	s6,64(a1)
 b38:	0485bb83          	ld	s7,72(a1)
 b3c:	0505bc03          	ld	s8,80(a1)
 b40:	0585bc83          	ld	s9,88(a1)
 b44:	0605bd03          	ld	s10,96(a1)
 b48:	0685bd83          	ld	s11,104(a1)
 b4c:	8082                	ret
