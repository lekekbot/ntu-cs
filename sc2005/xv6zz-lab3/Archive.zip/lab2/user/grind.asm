
user/_grind:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <do_rand>:
#include "kernel/riscv.h"

// from FreeBSD.
int
do_rand(unsigned long *ctx)
{
       0:	1141                	addi	sp,sp,-16
       2:	e406                	sd	ra,8(sp)
       4:	e022                	sd	s0,0(sp)
       6:	0800                	addi	s0,sp,16
 * October 1988, p. 1195.
 */
    long hi, lo, x;

    /* Transform to [1, 0x7ffffffe] range. */
    x = (*ctx % 0x7ffffffe) + 1;
       8:	611c                	ld	a5,0(a0)
       a:	0017d693          	srli	a3,a5,0x1
       e:	c0000737          	lui	a4,0xc0000
      12:	0705                	addi	a4,a4,1 # ffffffffc0000001 <all_thread+0xffffffffbfffdbe9>
      14:	1706                	slli	a4,a4,0x21
      16:	0725                	addi	a4,a4,9
      18:	02e6b733          	mulhu	a4,a3,a4
      1c:	8375                	srli	a4,a4,0x1d
      1e:	01e71693          	slli	a3,a4,0x1e
      22:	40e68733          	sub	a4,a3,a4
      26:	0706                	slli	a4,a4,0x1
      28:	8f99                	sub	a5,a5,a4
      2a:	0785                	addi	a5,a5,1
    hi = x / 127773;
    lo = x % 127773;
      2c:	1fe406b7          	lui	a3,0x1fe40
      30:	b7968693          	addi	a3,a3,-1159 # 1fe3fb79 <all_thread+0x1fe3d761>
      34:	41a70737          	lui	a4,0x41a70
      38:	5af70713          	addi	a4,a4,1455 # 41a705af <all_thread+0x41a6e197>
      3c:	1702                	slli	a4,a4,0x20
      3e:	9736                	add	a4,a4,a3
      40:	02e79733          	mulh	a4,a5,a4
      44:	873d                	srai	a4,a4,0xf
      46:	43f7d693          	srai	a3,a5,0x3f
      4a:	8f15                	sub	a4,a4,a3
      4c:	66fd                	lui	a3,0x1f
      4e:	31d68693          	addi	a3,a3,797 # 1f31d <all_thread+0x1cf05>
      52:	02d706b3          	mul	a3,a4,a3
      56:	8f95                	sub	a5,a5,a3
    x = 16807 * lo - 2836 * hi;
      58:	6691                	lui	a3,0x4
      5a:	1a768693          	addi	a3,a3,423 # 41a7 <all_thread+0x1d8f>
      5e:	02d787b3          	mul	a5,a5,a3
      62:	76fd                	lui	a3,0xfffff
      64:	4ec68693          	addi	a3,a3,1260 # fffffffffffff4ec <all_thread+0xffffffffffffd0d4>
      68:	02d70733          	mul	a4,a4,a3
      6c:	97ba                	add	a5,a5,a4
    if (x < 0)
      6e:	0007ca63          	bltz	a5,82 <do_rand+0x82>
        x += 0x7fffffff;
    /* Transform to [0, 0x7ffffffd] range. */
    x--;
      72:	17fd                	addi	a5,a5,-1
    *ctx = x;
      74:	e11c                	sd	a5,0(a0)
    return (x);
}
      76:	0007851b          	sext.w	a0,a5
      7a:	60a2                	ld	ra,8(sp)
      7c:	6402                	ld	s0,0(sp)
      7e:	0141                	addi	sp,sp,16
      80:	8082                	ret
        x += 0x7fffffff;
      82:	80000737          	lui	a4,0x80000
      86:	fff74713          	not	a4,a4
      8a:	97ba                	add	a5,a5,a4
      8c:	b7dd                	j	72 <do_rand+0x72>

000000000000008e <rand>:

unsigned long rand_next = 1;

int
rand(void)
{
      8e:	1141                	addi	sp,sp,-16
      90:	e406                	sd	ra,8(sp)
      92:	e022                	sd	s0,0(sp)
      94:	0800                	addi	s0,sp,16
    return (do_rand(&rand_next));
      96:	00002517          	auipc	a0,0x2
      9a:	f6a50513          	addi	a0,a0,-150 # 2000 <rand_next>
      9e:	f63ff0ef          	jal	0 <do_rand>
}
      a2:	60a2                	ld	ra,8(sp)
      a4:	6402                	ld	s0,0(sp)
      a6:	0141                	addi	sp,sp,16
      a8:	8082                	ret

00000000000000aa <go>:

void
go(int which_child)
{
      aa:	7171                	addi	sp,sp,-176
      ac:	f506                	sd	ra,168(sp)
      ae:	f122                	sd	s0,160(sp)
      b0:	ed26                	sd	s1,152(sp)
      b2:	1900                	addi	s0,sp,176
      b4:	84aa                	mv	s1,a0
  int fd = -1;
  static char buf[999];
  char *break0 = sbrk(0);
      b6:	4501                	li	a0,0
      b8:	3e3000ef          	jal	c9a <sbrk>
      bc:	f4a43c23          	sd	a0,-168(s0)
  uint64 iters = 0;

  mkdir("grindir");
      c0:	00001517          	auipc	a0,0x1
      c4:	32050513          	addi	a0,a0,800 # 13e0 <thread_switch+0x6c>
      c8:	3b3000ef          	jal	c7a <mkdir>
  if(chdir("grindir") != 0){
      cc:	00001517          	auipc	a0,0x1
      d0:	31450513          	addi	a0,a0,788 # 13e0 <thread_switch+0x6c>
      d4:	3af000ef          	jal	c82 <chdir>
      d8:	c505                	beqz	a0,100 <go+0x56>
      da:	e94a                	sd	s2,144(sp)
      dc:	e54e                	sd	s3,136(sp)
      de:	e152                	sd	s4,128(sp)
      e0:	fcd6                	sd	s5,120(sp)
      e2:	f8da                	sd	s6,112(sp)
      e4:	f4de                	sd	s7,104(sp)
      e6:	f0e2                	sd	s8,96(sp)
      e8:	ece6                	sd	s9,88(sp)
      ea:	e8ea                	sd	s10,80(sp)
      ec:	e4ee                	sd	s11,72(sp)
    printf("grind: chdir grindir failed\n");
      ee:	00001517          	auipc	a0,0x1
      f2:	2fa50513          	addi	a0,a0,762 # 13e8 <thread_switch+0x74>
      f6:	75f000ef          	jal	1054 <printf>
    exit(1);
      fa:	4505                	li	a0,1
      fc:	317000ef          	jal	c12 <exit>
     100:	e94a                	sd	s2,144(sp)
     102:	e54e                	sd	s3,136(sp)
     104:	e152                	sd	s4,128(sp)
     106:	fcd6                	sd	s5,120(sp)
     108:	f8da                	sd	s6,112(sp)
     10a:	f4de                	sd	s7,104(sp)
     10c:	f0e2                	sd	s8,96(sp)
     10e:	ece6                	sd	s9,88(sp)
     110:	e8ea                	sd	s10,80(sp)
     112:	e4ee                	sd	s11,72(sp)
  }
  chdir("/");
     114:	00001517          	auipc	a0,0x1
     118:	2fc50513          	addi	a0,a0,764 # 1410 <thread_switch+0x9c>
     11c:	367000ef          	jal	c82 <chdir>
     120:	00001c17          	auipc	s8,0x1
     124:	300c0c13          	addi	s8,s8,768 # 1420 <thread_switch+0xac>
     128:	c489                	beqz	s1,132 <go+0x88>
     12a:	00001c17          	auipc	s8,0x1
     12e:	2eec0c13          	addi	s8,s8,750 # 1418 <thread_switch+0xa4>
  uint64 iters = 0;
     132:	4481                	li	s1,0
  int fd = -1;
     134:	5cfd                	li	s9,-1
  
  while(1){
    iters++;
    if((iters % 500) == 0)
     136:	106259b7          	lui	s3,0x10625
     13a:	dd398993          	addi	s3,s3,-557 # 10624dd3 <all_thread+0x106229bb>
     13e:	09be                	slli	s3,s3,0xf
     140:	8d598993          	addi	s3,s3,-1835
     144:	09ca                	slli	s3,s3,0x12
     146:	80098993          	addi	s3,s3,-2048
     14a:	fcf98993          	addi	s3,s3,-49
     14e:	1f400b93          	li	s7,500
      write(1, which_child?"B":"A", 1);
     152:	4a05                	li	s4,1
    int what = rand() % 23;
     154:	b2164ab7          	lui	s5,0xb2164
     158:	2c9a8a93          	addi	s5,s5,713 # ffffffffb21642c9 <all_thread+0xffffffffb2161eb1>
     15c:	4b59                	li	s6,22
     15e:	00001917          	auipc	s2,0x1
     162:	5ba90913          	addi	s2,s2,1466 # 1718 <thread_switch+0x3a4>
      close(fd1);
      unlink("c");
    } else if(what == 22){
      // echo hi | cat
      int aa[2], bb[2];
      if(pipe(aa) < 0){
     166:	f6840d93          	addi	s11,s0,-152
     16a:	a819                	j	180 <go+0xd6>
      close(open("grindir/../a", O_CREATE|O_RDWR));
     16c:	20200593          	li	a1,514
     170:	00001517          	auipc	a0,0x1
     174:	2b850513          	addi	a0,a0,696 # 1428 <thread_switch+0xb4>
     178:	2db000ef          	jal	c52 <open>
     17c:	2bf000ef          	jal	c3a <close>
    iters++;
     180:	0485                	addi	s1,s1,1
    if((iters % 500) == 0)
     182:	0024d793          	srli	a5,s1,0x2
     186:	0337b7b3          	mulhu	a5,a5,s3
     18a:	8391                	srli	a5,a5,0x4
     18c:	037787b3          	mul	a5,a5,s7
     190:	00f49763          	bne	s1,a5,19e <go+0xf4>
      write(1, which_child?"B":"A", 1);
     194:	8652                	mv	a2,s4
     196:	85e2                	mv	a1,s8
     198:	8552                	mv	a0,s4
     19a:	299000ef          	jal	c32 <write>
    int what = rand() % 23;
     19e:	ef1ff0ef          	jal	8e <rand>
     1a2:	035507b3          	mul	a5,a0,s5
     1a6:	9381                	srli	a5,a5,0x20
     1a8:	9fa9                	addw	a5,a5,a0
     1aa:	4047d79b          	sraiw	a5,a5,0x4
     1ae:	41f5571b          	sraiw	a4,a0,0x1f
     1b2:	9f99                	subw	a5,a5,a4
     1b4:	0017971b          	slliw	a4,a5,0x1
     1b8:	9f3d                	addw	a4,a4,a5
     1ba:	0037171b          	slliw	a4,a4,0x3
     1be:	40f707bb          	subw	a5,a4,a5
     1c2:	9d1d                	subw	a0,a0,a5
     1c4:	faab6ee3          	bltu	s6,a0,180 <go+0xd6>
     1c8:	02051793          	slli	a5,a0,0x20
     1cc:	01e7d513          	srli	a0,a5,0x1e
     1d0:	954a                	add	a0,a0,s2
     1d2:	411c                	lw	a5,0(a0)
     1d4:	97ca                	add	a5,a5,s2
     1d6:	8782                	jr	a5
      close(open("grindir/../grindir/../b", O_CREATE|O_RDWR));
     1d8:	20200593          	li	a1,514
     1dc:	00001517          	auipc	a0,0x1
     1e0:	25c50513          	addi	a0,a0,604 # 1438 <thread_switch+0xc4>
     1e4:	26f000ef          	jal	c52 <open>
     1e8:	253000ef          	jal	c3a <close>
     1ec:	bf51                	j	180 <go+0xd6>
      unlink("grindir/../a");
     1ee:	00001517          	auipc	a0,0x1
     1f2:	23a50513          	addi	a0,a0,570 # 1428 <thread_switch+0xb4>
     1f6:	26d000ef          	jal	c62 <unlink>
     1fa:	b759                	j	180 <go+0xd6>
      if(chdir("grindir") != 0){
     1fc:	00001517          	auipc	a0,0x1
     200:	1e450513          	addi	a0,a0,484 # 13e0 <thread_switch+0x6c>
     204:	27f000ef          	jal	c82 <chdir>
     208:	ed11                	bnez	a0,224 <go+0x17a>
      unlink("../b");
     20a:	00001517          	auipc	a0,0x1
     20e:	24650513          	addi	a0,a0,582 # 1450 <thread_switch+0xdc>
     212:	251000ef          	jal	c62 <unlink>
      chdir("/");
     216:	00001517          	auipc	a0,0x1
     21a:	1fa50513          	addi	a0,a0,506 # 1410 <thread_switch+0x9c>
     21e:	265000ef          	jal	c82 <chdir>
     222:	bfb9                	j	180 <go+0xd6>
        printf("grind: chdir grindir failed\n");
     224:	00001517          	auipc	a0,0x1
     228:	1c450513          	addi	a0,a0,452 # 13e8 <thread_switch+0x74>
     22c:	629000ef          	jal	1054 <printf>
        exit(1);
     230:	4505                	li	a0,1
     232:	1e1000ef          	jal	c12 <exit>
      close(fd);
     236:	8566                	mv	a0,s9
     238:	203000ef          	jal	c3a <close>
      fd = open("/grindir/../a", O_CREATE|O_RDWR);
     23c:	20200593          	li	a1,514
     240:	00001517          	auipc	a0,0x1
     244:	21850513          	addi	a0,a0,536 # 1458 <thread_switch+0xe4>
     248:	20b000ef          	jal	c52 <open>
     24c:	8caa                	mv	s9,a0
     24e:	bf0d                	j	180 <go+0xd6>
      close(fd);
     250:	8566                	mv	a0,s9
     252:	1e9000ef          	jal	c3a <close>
      fd = open("/./grindir/./../b", O_CREATE|O_RDWR);
     256:	20200593          	li	a1,514
     25a:	00001517          	auipc	a0,0x1
     25e:	20e50513          	addi	a0,a0,526 # 1468 <thread_switch+0xf4>
     262:	1f1000ef          	jal	c52 <open>
     266:	8caa                	mv	s9,a0
     268:	bf21                	j	180 <go+0xd6>
      write(fd, buf, sizeof(buf));
     26a:	3e700613          	li	a2,999
     26e:	00002597          	auipc	a1,0x2
     272:	db258593          	addi	a1,a1,-590 # 2020 <buf.0>
     276:	8566                	mv	a0,s9
     278:	1bb000ef          	jal	c32 <write>
     27c:	b711                	j	180 <go+0xd6>
      read(fd, buf, sizeof(buf));
     27e:	3e700613          	li	a2,999
     282:	00002597          	auipc	a1,0x2
     286:	d9e58593          	addi	a1,a1,-610 # 2020 <buf.0>
     28a:	8566                	mv	a0,s9
     28c:	19f000ef          	jal	c2a <read>
     290:	bdc5                	j	180 <go+0xd6>
      mkdir("grindir/../a");
     292:	00001517          	auipc	a0,0x1
     296:	19650513          	addi	a0,a0,406 # 1428 <thread_switch+0xb4>
     29a:	1e1000ef          	jal	c7a <mkdir>
      close(open("a/../a/./a", O_CREATE|O_RDWR));
     29e:	20200593          	li	a1,514
     2a2:	00001517          	auipc	a0,0x1
     2a6:	1de50513          	addi	a0,a0,478 # 1480 <thread_switch+0x10c>
     2aa:	1a9000ef          	jal	c52 <open>
     2ae:	18d000ef          	jal	c3a <close>
      unlink("a/a");
     2b2:	00001517          	auipc	a0,0x1
     2b6:	1de50513          	addi	a0,a0,478 # 1490 <thread_switch+0x11c>
     2ba:	1a9000ef          	jal	c62 <unlink>
     2be:	b5c9                	j	180 <go+0xd6>
      mkdir("/../b");
     2c0:	00001517          	auipc	a0,0x1
     2c4:	1d850513          	addi	a0,a0,472 # 1498 <thread_switch+0x124>
     2c8:	1b3000ef          	jal	c7a <mkdir>
      close(open("grindir/../b/b", O_CREATE|O_RDWR));
     2cc:	20200593          	li	a1,514
     2d0:	00001517          	auipc	a0,0x1
     2d4:	1d050513          	addi	a0,a0,464 # 14a0 <thread_switch+0x12c>
     2d8:	17b000ef          	jal	c52 <open>
     2dc:	15f000ef          	jal	c3a <close>
      unlink("b/b");
     2e0:	00001517          	auipc	a0,0x1
     2e4:	1d050513          	addi	a0,a0,464 # 14b0 <thread_switch+0x13c>
     2e8:	17b000ef          	jal	c62 <unlink>
     2ec:	bd51                	j	180 <go+0xd6>
      unlink("b");
     2ee:	00001517          	auipc	a0,0x1
     2f2:	1ca50513          	addi	a0,a0,458 # 14b8 <thread_switch+0x144>
     2f6:	16d000ef          	jal	c62 <unlink>
      link("../grindir/./../a", "../b");
     2fa:	00001597          	auipc	a1,0x1
     2fe:	15658593          	addi	a1,a1,342 # 1450 <thread_switch+0xdc>
     302:	00001517          	auipc	a0,0x1
     306:	1be50513          	addi	a0,a0,446 # 14c0 <thread_switch+0x14c>
     30a:	169000ef          	jal	c72 <link>
     30e:	bd8d                	j	180 <go+0xd6>
      unlink("../grindir/../a");
     310:	00001517          	auipc	a0,0x1
     314:	1c850513          	addi	a0,a0,456 # 14d8 <thread_switch+0x164>
     318:	14b000ef          	jal	c62 <unlink>
      link(".././b", "/grindir/../a");
     31c:	00001597          	auipc	a1,0x1
     320:	13c58593          	addi	a1,a1,316 # 1458 <thread_switch+0xe4>
     324:	00001517          	auipc	a0,0x1
     328:	1c450513          	addi	a0,a0,452 # 14e8 <thread_switch+0x174>
     32c:	147000ef          	jal	c72 <link>
     330:	bd81                	j	180 <go+0xd6>
      int pid = fork();
     332:	0d9000ef          	jal	c0a <fork>
      if(pid == 0){
     336:	c519                	beqz	a0,344 <go+0x29a>
      } else if(pid < 0){
     338:	00054863          	bltz	a0,348 <go+0x29e>
      wait(0);
     33c:	4501                	li	a0,0
     33e:	0dd000ef          	jal	c1a <wait>
     342:	bd3d                	j	180 <go+0xd6>
        exit(0);
     344:	0cf000ef          	jal	c12 <exit>
        printf("grind: fork failed\n");
     348:	00001517          	auipc	a0,0x1
     34c:	1a850513          	addi	a0,a0,424 # 14f0 <thread_switch+0x17c>
     350:	505000ef          	jal	1054 <printf>
        exit(1);
     354:	4505                	li	a0,1
     356:	0bd000ef          	jal	c12 <exit>
      int pid = fork();
     35a:	0b1000ef          	jal	c0a <fork>
      if(pid == 0){
     35e:	c519                	beqz	a0,36c <go+0x2c2>
      } else if(pid < 0){
     360:	00054d63          	bltz	a0,37a <go+0x2d0>
      wait(0);
     364:	4501                	li	a0,0
     366:	0b5000ef          	jal	c1a <wait>
     36a:	bd19                	j	180 <go+0xd6>
        fork();
     36c:	09f000ef          	jal	c0a <fork>
        fork();
     370:	09b000ef          	jal	c0a <fork>
        exit(0);
     374:	4501                	li	a0,0
     376:	09d000ef          	jal	c12 <exit>
        printf("grind: fork failed\n");
     37a:	00001517          	auipc	a0,0x1
     37e:	17650513          	addi	a0,a0,374 # 14f0 <thread_switch+0x17c>
     382:	4d3000ef          	jal	1054 <printf>
        exit(1);
     386:	4505                	li	a0,1
     388:	08b000ef          	jal	c12 <exit>
      sbrk(6011);
     38c:	6505                	lui	a0,0x1
     38e:	77b50513          	addi	a0,a0,1915 # 177b <digits+0x3>
     392:	109000ef          	jal	c9a <sbrk>
     396:	b3ed                	j	180 <go+0xd6>
      if(sbrk(0) > break0)
     398:	4501                	li	a0,0
     39a:	101000ef          	jal	c9a <sbrk>
     39e:	f5843783          	ld	a5,-168(s0)
     3a2:	dca7ffe3          	bgeu	a5,a0,180 <go+0xd6>
        sbrk(-(sbrk(0) - break0));
     3a6:	4501                	li	a0,0
     3a8:	0f3000ef          	jal	c9a <sbrk>
     3ac:	f5843783          	ld	a5,-168(s0)
     3b0:	40a7853b          	subw	a0,a5,a0
     3b4:	0e7000ef          	jal	c9a <sbrk>
     3b8:	b3e1                	j	180 <go+0xd6>
      int pid = fork();
     3ba:	051000ef          	jal	c0a <fork>
     3be:	8d2a                	mv	s10,a0
      if(pid == 0){
     3c0:	c10d                	beqz	a0,3e2 <go+0x338>
      } else if(pid < 0){
     3c2:	02054d63          	bltz	a0,3fc <go+0x352>
      if(chdir("../grindir/..") != 0){
     3c6:	00001517          	auipc	a0,0x1
     3ca:	14a50513          	addi	a0,a0,330 # 1510 <thread_switch+0x19c>
     3ce:	0b5000ef          	jal	c82 <chdir>
     3d2:	ed15                	bnez	a0,40e <go+0x364>
      kill(pid);
     3d4:	856a                	mv	a0,s10
     3d6:	06d000ef          	jal	c42 <kill>
      wait(0);
     3da:	4501                	li	a0,0
     3dc:	03f000ef          	jal	c1a <wait>
     3e0:	b345                	j	180 <go+0xd6>
        close(open("a", O_CREATE|O_RDWR));
     3e2:	20200593          	li	a1,514
     3e6:	00001517          	auipc	a0,0x1
     3ea:	12250513          	addi	a0,a0,290 # 1508 <thread_switch+0x194>
     3ee:	065000ef          	jal	c52 <open>
     3f2:	049000ef          	jal	c3a <close>
        exit(0);
     3f6:	4501                	li	a0,0
     3f8:	01b000ef          	jal	c12 <exit>
        printf("grind: fork failed\n");
     3fc:	00001517          	auipc	a0,0x1
     400:	0f450513          	addi	a0,a0,244 # 14f0 <thread_switch+0x17c>
     404:	451000ef          	jal	1054 <printf>
        exit(1);
     408:	4505                	li	a0,1
     40a:	009000ef          	jal	c12 <exit>
        printf("grind: chdir failed\n");
     40e:	00001517          	auipc	a0,0x1
     412:	11250513          	addi	a0,a0,274 # 1520 <thread_switch+0x1ac>
     416:	43f000ef          	jal	1054 <printf>
        exit(1);
     41a:	4505                	li	a0,1
     41c:	7f6000ef          	jal	c12 <exit>
      int pid = fork();
     420:	7ea000ef          	jal	c0a <fork>
      if(pid == 0){
     424:	c519                	beqz	a0,432 <go+0x388>
      } else if(pid < 0){
     426:	00054d63          	bltz	a0,440 <go+0x396>
      wait(0);
     42a:	4501                	li	a0,0
     42c:	7ee000ef          	jal	c1a <wait>
     430:	bb81                	j	180 <go+0xd6>
        kill(getpid());
     432:	061000ef          	jal	c92 <getpid>
     436:	00d000ef          	jal	c42 <kill>
        exit(0);
     43a:	4501                	li	a0,0
     43c:	7d6000ef          	jal	c12 <exit>
        printf("grind: fork failed\n");
     440:	00001517          	auipc	a0,0x1
     444:	0b050513          	addi	a0,a0,176 # 14f0 <thread_switch+0x17c>
     448:	40d000ef          	jal	1054 <printf>
        exit(1);
     44c:	4505                	li	a0,1
     44e:	7c4000ef          	jal	c12 <exit>
      if(pipe(fds) < 0){
     452:	f7840513          	addi	a0,s0,-136
     456:	7cc000ef          	jal	c22 <pipe>
     45a:	02054363          	bltz	a0,480 <go+0x3d6>
      int pid = fork();
     45e:	7ac000ef          	jal	c0a <fork>
      if(pid == 0){
     462:	c905                	beqz	a0,492 <go+0x3e8>
      } else if(pid < 0){
     464:	08054263          	bltz	a0,4e8 <go+0x43e>
      close(fds[0]);
     468:	f7842503          	lw	a0,-136(s0)
     46c:	7ce000ef          	jal	c3a <close>
      close(fds[1]);
     470:	f7c42503          	lw	a0,-132(s0)
     474:	7c6000ef          	jal	c3a <close>
      wait(0);
     478:	4501                	li	a0,0
     47a:	7a0000ef          	jal	c1a <wait>
     47e:	b309                	j	180 <go+0xd6>
        printf("grind: pipe failed\n");
     480:	00001517          	auipc	a0,0x1
     484:	0b850513          	addi	a0,a0,184 # 1538 <thread_switch+0x1c4>
     488:	3cd000ef          	jal	1054 <printf>
        exit(1);
     48c:	4505                	li	a0,1
     48e:	784000ef          	jal	c12 <exit>
        fork();
     492:	778000ef          	jal	c0a <fork>
        fork();
     496:	774000ef          	jal	c0a <fork>
        if(write(fds[1], "x", 1) != 1)
     49a:	4605                	li	a2,1
     49c:	00001597          	auipc	a1,0x1
     4a0:	0b458593          	addi	a1,a1,180 # 1550 <thread_switch+0x1dc>
     4a4:	f7c42503          	lw	a0,-132(s0)
     4a8:	78a000ef          	jal	c32 <write>
     4ac:	4785                	li	a5,1
     4ae:	00f51f63          	bne	a0,a5,4cc <go+0x422>
        if(read(fds[0], &c, 1) != 1)
     4b2:	4605                	li	a2,1
     4b4:	f7040593          	addi	a1,s0,-144
     4b8:	f7842503          	lw	a0,-136(s0)
     4bc:	76e000ef          	jal	c2a <read>
     4c0:	4785                	li	a5,1
     4c2:	00f51c63          	bne	a0,a5,4da <go+0x430>
        exit(0);
     4c6:	4501                	li	a0,0
     4c8:	74a000ef          	jal	c12 <exit>
          printf("grind: pipe write failed\n");
     4cc:	00001517          	auipc	a0,0x1
     4d0:	08c50513          	addi	a0,a0,140 # 1558 <thread_switch+0x1e4>
     4d4:	381000ef          	jal	1054 <printf>
     4d8:	bfe9                	j	4b2 <go+0x408>
          printf("grind: pipe read failed\n");
     4da:	00001517          	auipc	a0,0x1
     4de:	09e50513          	addi	a0,a0,158 # 1578 <thread_switch+0x204>
     4e2:	373000ef          	jal	1054 <printf>
     4e6:	b7c5                	j	4c6 <go+0x41c>
        printf("grind: fork failed\n");
     4e8:	00001517          	auipc	a0,0x1
     4ec:	00850513          	addi	a0,a0,8 # 14f0 <thread_switch+0x17c>
     4f0:	365000ef          	jal	1054 <printf>
        exit(1);
     4f4:	4505                	li	a0,1
     4f6:	71c000ef          	jal	c12 <exit>
      int pid = fork();
     4fa:	710000ef          	jal	c0a <fork>
      if(pid == 0){
     4fe:	c519                	beqz	a0,50c <go+0x462>
      } else if(pid < 0){
     500:	04054f63          	bltz	a0,55e <go+0x4b4>
      wait(0);
     504:	4501                	li	a0,0
     506:	714000ef          	jal	c1a <wait>
     50a:	b99d                	j	180 <go+0xd6>
        unlink("a");
     50c:	00001517          	auipc	a0,0x1
     510:	ffc50513          	addi	a0,a0,-4 # 1508 <thread_switch+0x194>
     514:	74e000ef          	jal	c62 <unlink>
        mkdir("a");
     518:	00001517          	auipc	a0,0x1
     51c:	ff050513          	addi	a0,a0,-16 # 1508 <thread_switch+0x194>
     520:	75a000ef          	jal	c7a <mkdir>
        chdir("a");
     524:	00001517          	auipc	a0,0x1
     528:	fe450513          	addi	a0,a0,-28 # 1508 <thread_switch+0x194>
     52c:	756000ef          	jal	c82 <chdir>
        unlink("../a");
     530:	00001517          	auipc	a0,0x1
     534:	06850513          	addi	a0,a0,104 # 1598 <thread_switch+0x224>
     538:	72a000ef          	jal	c62 <unlink>
        fd = open("x", O_CREATE|O_RDWR);
     53c:	20200593          	li	a1,514
     540:	00001517          	auipc	a0,0x1
     544:	01050513          	addi	a0,a0,16 # 1550 <thread_switch+0x1dc>
     548:	70a000ef          	jal	c52 <open>
        unlink("x");
     54c:	00001517          	auipc	a0,0x1
     550:	00450513          	addi	a0,a0,4 # 1550 <thread_switch+0x1dc>
     554:	70e000ef          	jal	c62 <unlink>
        exit(0);
     558:	4501                	li	a0,0
     55a:	6b8000ef          	jal	c12 <exit>
        printf("grind: fork failed\n");
     55e:	00001517          	auipc	a0,0x1
     562:	f9250513          	addi	a0,a0,-110 # 14f0 <thread_switch+0x17c>
     566:	2ef000ef          	jal	1054 <printf>
        exit(1);
     56a:	4505                	li	a0,1
     56c:	6a6000ef          	jal	c12 <exit>
      unlink("c");
     570:	00001517          	auipc	a0,0x1
     574:	03050513          	addi	a0,a0,48 # 15a0 <thread_switch+0x22c>
     578:	6ea000ef          	jal	c62 <unlink>
      int fd1 = open("c", O_CREATE|O_RDWR);
     57c:	20200593          	li	a1,514
     580:	00001517          	auipc	a0,0x1
     584:	02050513          	addi	a0,a0,32 # 15a0 <thread_switch+0x22c>
     588:	6ca000ef          	jal	c52 <open>
     58c:	8d2a                	mv	s10,a0
      if(fd1 < 0){
     58e:	04054563          	bltz	a0,5d8 <go+0x52e>
      if(write(fd1, "x", 1) != 1){
     592:	8652                	mv	a2,s4
     594:	00001597          	auipc	a1,0x1
     598:	fbc58593          	addi	a1,a1,-68 # 1550 <thread_switch+0x1dc>
     59c:	696000ef          	jal	c32 <write>
     5a0:	05451563          	bne	a0,s4,5ea <go+0x540>
      if(fstat(fd1, &st) != 0){
     5a4:	f7840593          	addi	a1,s0,-136
     5a8:	856a                	mv	a0,s10
     5aa:	6c0000ef          	jal	c6a <fstat>
     5ae:	e539                	bnez	a0,5fc <go+0x552>
      if(st.size != 1){
     5b0:	f8843583          	ld	a1,-120(s0)
     5b4:	05459d63          	bne	a1,s4,60e <go+0x564>
      if(st.ino > 200){
     5b8:	f7c42583          	lw	a1,-132(s0)
     5bc:	0c800793          	li	a5,200
     5c0:	06b7e163          	bltu	a5,a1,622 <go+0x578>
      close(fd1);
     5c4:	856a                	mv	a0,s10
     5c6:	674000ef          	jal	c3a <close>
      unlink("c");
     5ca:	00001517          	auipc	a0,0x1
     5ce:	fd650513          	addi	a0,a0,-42 # 15a0 <thread_switch+0x22c>
     5d2:	690000ef          	jal	c62 <unlink>
     5d6:	b66d                	j	180 <go+0xd6>
        printf("grind: create c failed\n");
     5d8:	00001517          	auipc	a0,0x1
     5dc:	fd050513          	addi	a0,a0,-48 # 15a8 <thread_switch+0x234>
     5e0:	275000ef          	jal	1054 <printf>
        exit(1);
     5e4:	4505                	li	a0,1
     5e6:	62c000ef          	jal	c12 <exit>
        printf("grind: write c failed\n");
     5ea:	00001517          	auipc	a0,0x1
     5ee:	fd650513          	addi	a0,a0,-42 # 15c0 <thread_switch+0x24c>
     5f2:	263000ef          	jal	1054 <printf>
        exit(1);
     5f6:	4505                	li	a0,1
     5f8:	61a000ef          	jal	c12 <exit>
        printf("grind: fstat failed\n");
     5fc:	00001517          	auipc	a0,0x1
     600:	fdc50513          	addi	a0,a0,-36 # 15d8 <thread_switch+0x264>
     604:	251000ef          	jal	1054 <printf>
        exit(1);
     608:	4505                	li	a0,1
     60a:	608000ef          	jal	c12 <exit>
        printf("grind: fstat reports wrong size %d\n", (int)st.size);
     60e:	2581                	sext.w	a1,a1
     610:	00001517          	auipc	a0,0x1
     614:	fe050513          	addi	a0,a0,-32 # 15f0 <thread_switch+0x27c>
     618:	23d000ef          	jal	1054 <printf>
        exit(1);
     61c:	4505                	li	a0,1
     61e:	5f4000ef          	jal	c12 <exit>
        printf("grind: fstat reports crazy i-number %d\n", st.ino);
     622:	00001517          	auipc	a0,0x1
     626:	ff650513          	addi	a0,a0,-10 # 1618 <thread_switch+0x2a4>
     62a:	22b000ef          	jal	1054 <printf>
        exit(1);
     62e:	4505                	li	a0,1
     630:	5e2000ef          	jal	c12 <exit>
      if(pipe(aa) < 0){
     634:	856e                	mv	a0,s11
     636:	5ec000ef          	jal	c22 <pipe>
     63a:	0a054863          	bltz	a0,6ea <go+0x640>
        fprintf(2, "grind: pipe failed\n");
        exit(1);
      }
      if(pipe(bb) < 0){
     63e:	f7040513          	addi	a0,s0,-144
     642:	5e0000ef          	jal	c22 <pipe>
     646:	0a054c63          	bltz	a0,6fe <go+0x654>
        fprintf(2, "grind: pipe failed\n");
        exit(1);
      }
      int pid1 = fork();
     64a:	5c0000ef          	jal	c0a <fork>
      if(pid1 == 0){
     64e:	0c050263          	beqz	a0,712 <go+0x668>
        close(aa[1]);
        char *args[3] = { "echo", "hi", 0 };
        exec("grindir/../echo", args);
        fprintf(2, "grind: echo: not found\n");
        exit(2);
      } else if(pid1 < 0){
     652:	14054463          	bltz	a0,79a <go+0x6f0>
        fprintf(2, "grind: fork failed\n");
        exit(3);
      }
      int pid2 = fork();
     656:	5b4000ef          	jal	c0a <fork>
      if(pid2 == 0){
     65a:	14050a63          	beqz	a0,7ae <go+0x704>
        close(bb[1]);
        char *args[2] = { "cat", 0 };
        exec("/cat", args);
        fprintf(2, "grind: cat: not found\n");
        exit(6);
      } else if(pid2 < 0){
     65e:	1e054863          	bltz	a0,84e <go+0x7a4>
        fprintf(2, "grind: fork failed\n");
        exit(7);
      }
      close(aa[0]);
     662:	f6842503          	lw	a0,-152(s0)
     666:	5d4000ef          	jal	c3a <close>
      close(aa[1]);
     66a:	f6c42503          	lw	a0,-148(s0)
     66e:	5cc000ef          	jal	c3a <close>
      close(bb[1]);
     672:	f7442503          	lw	a0,-140(s0)
     676:	5c4000ef          	jal	c3a <close>
      char buf[4] = { 0, 0, 0, 0 };
     67a:	f6042023          	sw	zero,-160(s0)
      read(bb[0], buf+0, 1);
     67e:	8652                	mv	a2,s4
     680:	f6040593          	addi	a1,s0,-160
     684:	f7042503          	lw	a0,-144(s0)
     688:	5a2000ef          	jal	c2a <read>
      read(bb[0], buf+1, 1);
     68c:	8652                	mv	a2,s4
     68e:	f6140593          	addi	a1,s0,-159
     692:	f7042503          	lw	a0,-144(s0)
     696:	594000ef          	jal	c2a <read>
      read(bb[0], buf+2, 1);
     69a:	8652                	mv	a2,s4
     69c:	f6240593          	addi	a1,s0,-158
     6a0:	f7042503          	lw	a0,-144(s0)
     6a4:	586000ef          	jal	c2a <read>
      close(bb[0]);
     6a8:	f7042503          	lw	a0,-144(s0)
     6ac:	58e000ef          	jal	c3a <close>
      int st1, st2;
      wait(&st1);
     6b0:	f6440513          	addi	a0,s0,-156
     6b4:	566000ef          	jal	c1a <wait>
      wait(&st2);
     6b8:	f7840513          	addi	a0,s0,-136
     6bc:	55e000ef          	jal	c1a <wait>
      if(st1 != 0 || st2 != 0 || strcmp(buf, "hi\n") != 0){
     6c0:	f6442783          	lw	a5,-156(s0)
     6c4:	f7842703          	lw	a4,-136(s0)
     6c8:	f4e43823          	sd	a4,-176(s0)
     6cc:	00e7ed33          	or	s10,a5,a4
     6d0:	180d1963          	bnez	s10,862 <go+0x7b8>
     6d4:	00001597          	auipc	a1,0x1
     6d8:	fe458593          	addi	a1,a1,-28 # 16b8 <thread_switch+0x344>
     6dc:	f6040513          	addi	a0,s0,-160
     6e0:	2d8000ef          	jal	9b8 <strcmp>
     6e4:	a8050ee3          	beqz	a0,180 <go+0xd6>
     6e8:	aab5                	j	864 <go+0x7ba>
        fprintf(2, "grind: pipe failed\n");
     6ea:	00001597          	auipc	a1,0x1
     6ee:	e4e58593          	addi	a1,a1,-434 # 1538 <thread_switch+0x1c4>
     6f2:	4509                	li	a0,2
     6f4:	137000ef          	jal	102a <fprintf>
        exit(1);
     6f8:	4505                	li	a0,1
     6fa:	518000ef          	jal	c12 <exit>
        fprintf(2, "grind: pipe failed\n");
     6fe:	00001597          	auipc	a1,0x1
     702:	e3a58593          	addi	a1,a1,-454 # 1538 <thread_switch+0x1c4>
     706:	4509                	li	a0,2
     708:	123000ef          	jal	102a <fprintf>
        exit(1);
     70c:	4505                	li	a0,1
     70e:	504000ef          	jal	c12 <exit>
        close(bb[0]);
     712:	f7042503          	lw	a0,-144(s0)
     716:	524000ef          	jal	c3a <close>
        close(bb[1]);
     71a:	f7442503          	lw	a0,-140(s0)
     71e:	51c000ef          	jal	c3a <close>
        close(aa[0]);
     722:	f6842503          	lw	a0,-152(s0)
     726:	514000ef          	jal	c3a <close>
        close(1);
     72a:	4505                	li	a0,1
     72c:	50e000ef          	jal	c3a <close>
        if(dup(aa[1]) != 1){
     730:	f6c42503          	lw	a0,-148(s0)
     734:	556000ef          	jal	c8a <dup>
     738:	4785                	li	a5,1
     73a:	00f50c63          	beq	a0,a5,752 <go+0x6a8>
          fprintf(2, "grind: dup failed\n");
     73e:	00001597          	auipc	a1,0x1
     742:	f0258593          	addi	a1,a1,-254 # 1640 <thread_switch+0x2cc>
     746:	4509                	li	a0,2
     748:	0e3000ef          	jal	102a <fprintf>
          exit(1);
     74c:	4505                	li	a0,1
     74e:	4c4000ef          	jal	c12 <exit>
        close(aa[1]);
     752:	f6c42503          	lw	a0,-148(s0)
     756:	4e4000ef          	jal	c3a <close>
        char *args[3] = { "echo", "hi", 0 };
     75a:	00001797          	auipc	a5,0x1
     75e:	efe78793          	addi	a5,a5,-258 # 1658 <thread_switch+0x2e4>
     762:	f6f43c23          	sd	a5,-136(s0)
     766:	00001797          	auipc	a5,0x1
     76a:	efa78793          	addi	a5,a5,-262 # 1660 <thread_switch+0x2ec>
     76e:	f8f43023          	sd	a5,-128(s0)
     772:	f8043423          	sd	zero,-120(s0)
        exec("grindir/../echo", args);
     776:	f7840593          	addi	a1,s0,-136
     77a:	00001517          	auipc	a0,0x1
     77e:	eee50513          	addi	a0,a0,-274 # 1668 <thread_switch+0x2f4>
     782:	4c8000ef          	jal	c4a <exec>
        fprintf(2, "grind: echo: not found\n");
     786:	00001597          	auipc	a1,0x1
     78a:	ef258593          	addi	a1,a1,-270 # 1678 <thread_switch+0x304>
     78e:	4509                	li	a0,2
     790:	09b000ef          	jal	102a <fprintf>
        exit(2);
     794:	4509                	li	a0,2
     796:	47c000ef          	jal	c12 <exit>
        fprintf(2, "grind: fork failed\n");
     79a:	00001597          	auipc	a1,0x1
     79e:	d5658593          	addi	a1,a1,-682 # 14f0 <thread_switch+0x17c>
     7a2:	4509                	li	a0,2
     7a4:	087000ef          	jal	102a <fprintf>
        exit(3);
     7a8:	450d                	li	a0,3
     7aa:	468000ef          	jal	c12 <exit>
        close(aa[1]);
     7ae:	f6c42503          	lw	a0,-148(s0)
     7b2:	488000ef          	jal	c3a <close>
        close(bb[0]);
     7b6:	f7042503          	lw	a0,-144(s0)
     7ba:	480000ef          	jal	c3a <close>
        close(0);
     7be:	4501                	li	a0,0
     7c0:	47a000ef          	jal	c3a <close>
        if(dup(aa[0]) != 0){
     7c4:	f6842503          	lw	a0,-152(s0)
     7c8:	4c2000ef          	jal	c8a <dup>
     7cc:	c919                	beqz	a0,7e2 <go+0x738>
          fprintf(2, "grind: dup failed\n");
     7ce:	00001597          	auipc	a1,0x1
     7d2:	e7258593          	addi	a1,a1,-398 # 1640 <thread_switch+0x2cc>
     7d6:	4509                	li	a0,2
     7d8:	053000ef          	jal	102a <fprintf>
          exit(4);
     7dc:	4511                	li	a0,4
     7de:	434000ef          	jal	c12 <exit>
        close(aa[0]);
     7e2:	f6842503          	lw	a0,-152(s0)
     7e6:	454000ef          	jal	c3a <close>
        close(1);
     7ea:	4505                	li	a0,1
     7ec:	44e000ef          	jal	c3a <close>
        if(dup(bb[1]) != 1){
     7f0:	f7442503          	lw	a0,-140(s0)
     7f4:	496000ef          	jal	c8a <dup>
     7f8:	4785                	li	a5,1
     7fa:	00f50c63          	beq	a0,a5,812 <go+0x768>
          fprintf(2, "grind: dup failed\n");
     7fe:	00001597          	auipc	a1,0x1
     802:	e4258593          	addi	a1,a1,-446 # 1640 <thread_switch+0x2cc>
     806:	4509                	li	a0,2
     808:	023000ef          	jal	102a <fprintf>
          exit(5);
     80c:	4515                	li	a0,5
     80e:	404000ef          	jal	c12 <exit>
        close(bb[1]);
     812:	f7442503          	lw	a0,-140(s0)
     816:	424000ef          	jal	c3a <close>
        char *args[2] = { "cat", 0 };
     81a:	00001797          	auipc	a5,0x1
     81e:	e7678793          	addi	a5,a5,-394 # 1690 <thread_switch+0x31c>
     822:	f6f43c23          	sd	a5,-136(s0)
     826:	f8043023          	sd	zero,-128(s0)
        exec("/cat", args);
     82a:	f7840593          	addi	a1,s0,-136
     82e:	00001517          	auipc	a0,0x1
     832:	e6a50513          	addi	a0,a0,-406 # 1698 <thread_switch+0x324>
     836:	414000ef          	jal	c4a <exec>
        fprintf(2, "grind: cat: not found\n");
     83a:	00001597          	auipc	a1,0x1
     83e:	e6658593          	addi	a1,a1,-410 # 16a0 <thread_switch+0x32c>
     842:	4509                	li	a0,2
     844:	7e6000ef          	jal	102a <fprintf>
        exit(6);
     848:	4519                	li	a0,6
     84a:	3c8000ef          	jal	c12 <exit>
        fprintf(2, "grind: fork failed\n");
     84e:	00001597          	auipc	a1,0x1
     852:	ca258593          	addi	a1,a1,-862 # 14f0 <thread_switch+0x17c>
     856:	4509                	li	a0,2
     858:	7d2000ef          	jal	102a <fprintf>
        exit(7);
     85c:	451d                	li	a0,7
     85e:	3b4000ef          	jal	c12 <exit>
      if(st1 != 0 || st2 != 0 || strcmp(buf, "hi\n") != 0){
     862:	8d3e                	mv	s10,a5
        printf("grind: exec pipeline failed %d %d \"%s\"\n", st1, st2, buf);
     864:	f6040693          	addi	a3,s0,-160
     868:	f5043603          	ld	a2,-176(s0)
     86c:	85ea                	mv	a1,s10
     86e:	00001517          	auipc	a0,0x1
     872:	e5250513          	addi	a0,a0,-430 # 16c0 <thread_switch+0x34c>
     876:	7de000ef          	jal	1054 <printf>
        exit(1);
     87a:	4505                	li	a0,1
     87c:	396000ef          	jal	c12 <exit>

0000000000000880 <iter>:
  }
}

void
iter()
{
     880:	7179                	addi	sp,sp,-48
     882:	f406                	sd	ra,40(sp)
     884:	f022                	sd	s0,32(sp)
     886:	1800                	addi	s0,sp,48
  unlink("a");
     888:	00001517          	auipc	a0,0x1
     88c:	c8050513          	addi	a0,a0,-896 # 1508 <thread_switch+0x194>
     890:	3d2000ef          	jal	c62 <unlink>
  unlink("b");
     894:	00001517          	auipc	a0,0x1
     898:	c2450513          	addi	a0,a0,-988 # 14b8 <thread_switch+0x144>
     89c:	3c6000ef          	jal	c62 <unlink>
  
  int pid1 = fork();
     8a0:	36a000ef          	jal	c0a <fork>
  if(pid1 < 0){
     8a4:	02054163          	bltz	a0,8c6 <iter+0x46>
     8a8:	ec26                	sd	s1,24(sp)
     8aa:	84aa                	mv	s1,a0
    printf("grind: fork failed\n");
    exit(1);
  }
  if(pid1 == 0){
     8ac:	e905                	bnez	a0,8dc <iter+0x5c>
     8ae:	e84a                	sd	s2,16(sp)
    rand_next ^= 31;
     8b0:	00001717          	auipc	a4,0x1
     8b4:	75070713          	addi	a4,a4,1872 # 2000 <rand_next>
     8b8:	631c                	ld	a5,0(a4)
     8ba:	01f7c793          	xori	a5,a5,31
     8be:	e31c                	sd	a5,0(a4)
    go(0);
     8c0:	4501                	li	a0,0
     8c2:	fe8ff0ef          	jal	aa <go>
     8c6:	ec26                	sd	s1,24(sp)
     8c8:	e84a                	sd	s2,16(sp)
    printf("grind: fork failed\n");
     8ca:	00001517          	auipc	a0,0x1
     8ce:	c2650513          	addi	a0,a0,-986 # 14f0 <thread_switch+0x17c>
     8d2:	782000ef          	jal	1054 <printf>
    exit(1);
     8d6:	4505                	li	a0,1
     8d8:	33a000ef          	jal	c12 <exit>
     8dc:	e84a                	sd	s2,16(sp)
    exit(0);
  }

  int pid2 = fork();
     8de:	32c000ef          	jal	c0a <fork>
     8e2:	892a                	mv	s2,a0
  if(pid2 < 0){
     8e4:	02054063          	bltz	a0,904 <iter+0x84>
    printf("grind: fork failed\n");
    exit(1);
  }
  if(pid2 == 0){
     8e8:	e51d                	bnez	a0,916 <iter+0x96>
    rand_next ^= 7177;
     8ea:	00001697          	auipc	a3,0x1
     8ee:	71668693          	addi	a3,a3,1814 # 2000 <rand_next>
     8f2:	629c                	ld	a5,0(a3)
     8f4:	6709                	lui	a4,0x2
     8f6:	c0970713          	addi	a4,a4,-1015 # 1c09 <digits+0x491>
     8fa:	8fb9                	xor	a5,a5,a4
     8fc:	e29c                	sd	a5,0(a3)
    go(1);
     8fe:	4505                	li	a0,1
     900:	faaff0ef          	jal	aa <go>
    printf("grind: fork failed\n");
     904:	00001517          	auipc	a0,0x1
     908:	bec50513          	addi	a0,a0,-1044 # 14f0 <thread_switch+0x17c>
     90c:	748000ef          	jal	1054 <printf>
    exit(1);
     910:	4505                	li	a0,1
     912:	300000ef          	jal	c12 <exit>
    exit(0);
  }

  int st1 = -1;
     916:	57fd                	li	a5,-1
     918:	fcf42e23          	sw	a5,-36(s0)
  wait(&st1);
     91c:	fdc40513          	addi	a0,s0,-36
     920:	2fa000ef          	jal	c1a <wait>
  if(st1 != 0){
     924:	fdc42783          	lw	a5,-36(s0)
     928:	eb99                	bnez	a5,93e <iter+0xbe>
    kill(pid1);
    kill(pid2);
  }
  int st2 = -1;
     92a:	57fd                	li	a5,-1
     92c:	fcf42c23          	sw	a5,-40(s0)
  wait(&st2);
     930:	fd840513          	addi	a0,s0,-40
     934:	2e6000ef          	jal	c1a <wait>

  exit(0);
     938:	4501                	li	a0,0
     93a:	2d8000ef          	jal	c12 <exit>
    kill(pid1);
     93e:	8526                	mv	a0,s1
     940:	302000ef          	jal	c42 <kill>
    kill(pid2);
     944:	854a                	mv	a0,s2
     946:	2fc000ef          	jal	c42 <kill>
     94a:	b7c5                	j	92a <iter+0xaa>

000000000000094c <main>:
}

int
main()
{
     94c:	1101                	addi	sp,sp,-32
     94e:	ec06                	sd	ra,24(sp)
     950:	e822                	sd	s0,16(sp)
     952:	e426                	sd	s1,8(sp)
     954:	e04a                	sd	s2,0(sp)
     956:	1000                	addi	s0,sp,32
      exit(0);
    }
    if(pid > 0){
      wait(0);
    }
    sleep(20);
     958:	4951                	li	s2,20
    rand_next += 1;
     95a:	00001497          	auipc	s1,0x1
     95e:	6a648493          	addi	s1,s1,1702 # 2000 <rand_next>
     962:	a809                	j	974 <main+0x28>
      iter();
     964:	f1dff0ef          	jal	880 <iter>
    sleep(20);
     968:	854a                	mv	a0,s2
     96a:	338000ef          	jal	ca2 <sleep>
    rand_next += 1;
     96e:	609c                	ld	a5,0(s1)
     970:	0785                	addi	a5,a5,1
     972:	e09c                	sd	a5,0(s1)
    int pid = fork();
     974:	296000ef          	jal	c0a <fork>
    if(pid == 0){
     978:	d575                	beqz	a0,964 <main+0x18>
    if(pid > 0){
     97a:	fea057e3          	blez	a0,968 <main+0x1c>
      wait(0);
     97e:	4501                	li	a0,0
     980:	29a000ef          	jal	c1a <wait>
     984:	b7d5                	j	968 <main+0x1c>

0000000000000986 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
     986:	1141                	addi	sp,sp,-16
     988:	e406                	sd	ra,8(sp)
     98a:	e022                	sd	s0,0(sp)
     98c:	0800                	addi	s0,sp,16
  extern int main();
  main();
     98e:	fbfff0ef          	jal	94c <main>
  exit(0);
     992:	4501                	li	a0,0
     994:	27e000ef          	jal	c12 <exit>

0000000000000998 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
     998:	1141                	addi	sp,sp,-16
     99a:	e406                	sd	ra,8(sp)
     99c:	e022                	sd	s0,0(sp)
     99e:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
     9a0:	87aa                	mv	a5,a0
     9a2:	0585                	addi	a1,a1,1
     9a4:	0785                	addi	a5,a5,1
     9a6:	fff5c703          	lbu	a4,-1(a1)
     9aa:	fee78fa3          	sb	a4,-1(a5)
     9ae:	fb75                	bnez	a4,9a2 <strcpy+0xa>
    ;
  return os;
}
     9b0:	60a2                	ld	ra,8(sp)
     9b2:	6402                	ld	s0,0(sp)
     9b4:	0141                	addi	sp,sp,16
     9b6:	8082                	ret

00000000000009b8 <strcmp>:

int
strcmp(const char *p, const char *q)
{
     9b8:	1141                	addi	sp,sp,-16
     9ba:	e406                	sd	ra,8(sp)
     9bc:	e022                	sd	s0,0(sp)
     9be:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
     9c0:	00054783          	lbu	a5,0(a0)
     9c4:	cb91                	beqz	a5,9d8 <strcmp+0x20>
     9c6:	0005c703          	lbu	a4,0(a1)
     9ca:	00f71763          	bne	a4,a5,9d8 <strcmp+0x20>
    p++, q++;
     9ce:	0505                	addi	a0,a0,1
     9d0:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
     9d2:	00054783          	lbu	a5,0(a0)
     9d6:	fbe5                	bnez	a5,9c6 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
     9d8:	0005c503          	lbu	a0,0(a1)
}
     9dc:	40a7853b          	subw	a0,a5,a0
     9e0:	60a2                	ld	ra,8(sp)
     9e2:	6402                	ld	s0,0(sp)
     9e4:	0141                	addi	sp,sp,16
     9e6:	8082                	ret

00000000000009e8 <strlen>:

uint
strlen(const char *s)
{
     9e8:	1141                	addi	sp,sp,-16
     9ea:	e406                	sd	ra,8(sp)
     9ec:	e022                	sd	s0,0(sp)
     9ee:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
     9f0:	00054783          	lbu	a5,0(a0)
     9f4:	cf91                	beqz	a5,a10 <strlen+0x28>
     9f6:	00150793          	addi	a5,a0,1
     9fa:	86be                	mv	a3,a5
     9fc:	0785                	addi	a5,a5,1
     9fe:	fff7c703          	lbu	a4,-1(a5)
     a02:	ff65                	bnez	a4,9fa <strlen+0x12>
     a04:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
     a08:	60a2                	ld	ra,8(sp)
     a0a:	6402                	ld	s0,0(sp)
     a0c:	0141                	addi	sp,sp,16
     a0e:	8082                	ret
  for(n = 0; s[n]; n++)
     a10:	4501                	li	a0,0
     a12:	bfdd                	j	a08 <strlen+0x20>

0000000000000a14 <memset>:

void*
memset(void *dst, int c, uint n)
{
     a14:	1141                	addi	sp,sp,-16
     a16:	e406                	sd	ra,8(sp)
     a18:	e022                	sd	s0,0(sp)
     a1a:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
     a1c:	ca19                	beqz	a2,a32 <memset+0x1e>
     a1e:	87aa                	mv	a5,a0
     a20:	1602                	slli	a2,a2,0x20
     a22:	9201                	srli	a2,a2,0x20
     a24:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
     a28:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
     a2c:	0785                	addi	a5,a5,1
     a2e:	fee79de3          	bne	a5,a4,a28 <memset+0x14>
  }
  return dst;
}
     a32:	60a2                	ld	ra,8(sp)
     a34:	6402                	ld	s0,0(sp)
     a36:	0141                	addi	sp,sp,16
     a38:	8082                	ret

0000000000000a3a <strchr>:

char*
strchr(const char *s, char c)
{
     a3a:	1141                	addi	sp,sp,-16
     a3c:	e406                	sd	ra,8(sp)
     a3e:	e022                	sd	s0,0(sp)
     a40:	0800                	addi	s0,sp,16
  for(; *s; s++)
     a42:	00054783          	lbu	a5,0(a0)
     a46:	c799                	beqz	a5,a54 <strchr+0x1a>
    if(*s == c)
     a48:	00f58763          	beq	a1,a5,a56 <strchr+0x1c>
  for(; *s; s++)
     a4c:	0505                	addi	a0,a0,1
     a4e:	00054783          	lbu	a5,0(a0)
     a52:	fbfd                	bnez	a5,a48 <strchr+0xe>
      return (char*)s;
  return 0;
     a54:	4501                	li	a0,0
}
     a56:	60a2                	ld	ra,8(sp)
     a58:	6402                	ld	s0,0(sp)
     a5a:	0141                	addi	sp,sp,16
     a5c:	8082                	ret

0000000000000a5e <gets>:

char*
gets(char *buf, int max)
{
     a5e:	711d                	addi	sp,sp,-96
     a60:	ec86                	sd	ra,88(sp)
     a62:	e8a2                	sd	s0,80(sp)
     a64:	e4a6                	sd	s1,72(sp)
     a66:	e0ca                	sd	s2,64(sp)
     a68:	fc4e                	sd	s3,56(sp)
     a6a:	f852                	sd	s4,48(sp)
     a6c:	f456                	sd	s5,40(sp)
     a6e:	f05a                	sd	s6,32(sp)
     a70:	ec5e                	sd	s7,24(sp)
     a72:	e862                	sd	s8,16(sp)
     a74:	1080                	addi	s0,sp,96
     a76:	8baa                	mv	s7,a0
     a78:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
     a7a:	892a                	mv	s2,a0
     a7c:	4481                	li	s1,0
    cc = read(0, &c, 1);
     a7e:	faf40b13          	addi	s6,s0,-81
     a82:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
     a84:	8c26                	mv	s8,s1
     a86:	0014899b          	addiw	s3,s1,1
     a8a:	84ce                	mv	s1,s3
     a8c:	0349d863          	bge	s3,s4,abc <gets+0x5e>
    cc = read(0, &c, 1);
     a90:	8656                	mv	a2,s5
     a92:	85da                	mv	a1,s6
     a94:	4501                	li	a0,0
     a96:	194000ef          	jal	c2a <read>
    if(cc < 1)
     a9a:	02a05163          	blez	a0,abc <gets+0x5e>
      break;
    buf[i++] = c;
     a9e:	faf44783          	lbu	a5,-81(s0)
     aa2:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
     aa6:	0905                	addi	s2,s2,1
     aa8:	ff678713          	addi	a4,a5,-10
     aac:	00173713          	seqz	a4,a4
     ab0:	17cd                	addi	a5,a5,-13
     ab2:	0017b793          	seqz	a5,a5
     ab6:	8fd9                	or	a5,a5,a4
     ab8:	d7f1                	beqz	a5,a84 <gets+0x26>
    buf[i++] = c;
     aba:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
     abc:	9c5e                	add	s8,s8,s7
     abe:	000c0023          	sb	zero,0(s8)
  return buf;
}
     ac2:	855e                	mv	a0,s7
     ac4:	60e6                	ld	ra,88(sp)
     ac6:	6446                	ld	s0,80(sp)
     ac8:	64a6                	ld	s1,72(sp)
     aca:	6906                	ld	s2,64(sp)
     acc:	79e2                	ld	s3,56(sp)
     ace:	7a42                	ld	s4,48(sp)
     ad0:	7aa2                	ld	s5,40(sp)
     ad2:	7b02                	ld	s6,32(sp)
     ad4:	6be2                	ld	s7,24(sp)
     ad6:	6c42                	ld	s8,16(sp)
     ad8:	6125                	addi	sp,sp,96
     ada:	8082                	ret

0000000000000adc <stat>:

int
stat(const char *n, struct stat *st)
{
     adc:	1101                	addi	sp,sp,-32
     ade:	ec06                	sd	ra,24(sp)
     ae0:	e822                	sd	s0,16(sp)
     ae2:	e04a                	sd	s2,0(sp)
     ae4:	1000                	addi	s0,sp,32
     ae6:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
     ae8:	4581                	li	a1,0
     aea:	168000ef          	jal	c52 <open>
  if(fd < 0)
     aee:	02054263          	bltz	a0,b12 <stat+0x36>
     af2:	e426                	sd	s1,8(sp)
     af4:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
     af6:	85ca                	mv	a1,s2
     af8:	172000ef          	jal	c6a <fstat>
     afc:	892a                	mv	s2,a0
  close(fd);
     afe:	8526                	mv	a0,s1
     b00:	13a000ef          	jal	c3a <close>
  return r;
     b04:	64a2                	ld	s1,8(sp)
}
     b06:	854a                	mv	a0,s2
     b08:	60e2                	ld	ra,24(sp)
     b0a:	6442                	ld	s0,16(sp)
     b0c:	6902                	ld	s2,0(sp)
     b0e:	6105                	addi	sp,sp,32
     b10:	8082                	ret
    return -1;
     b12:	57fd                	li	a5,-1
     b14:	893e                	mv	s2,a5
     b16:	bfc5                	j	b06 <stat+0x2a>

0000000000000b18 <atoi>:

int
atoi(const char *s)
{
     b18:	1141                	addi	sp,sp,-16
     b1a:	e406                	sd	ra,8(sp)
     b1c:	e022                	sd	s0,0(sp)
     b1e:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
     b20:	00054683          	lbu	a3,0(a0)
     b24:	fd06879b          	addiw	a5,a3,-48
     b28:	0ff7f793          	zext.b	a5,a5
     b2c:	4625                	li	a2,9
     b2e:	02f66963          	bltu	a2,a5,b60 <atoi+0x48>
     b32:	872a                	mv	a4,a0
  n = 0;
     b34:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
     b36:	0705                	addi	a4,a4,1
     b38:	0025179b          	slliw	a5,a0,0x2
     b3c:	9fa9                	addw	a5,a5,a0
     b3e:	0017979b          	slliw	a5,a5,0x1
     b42:	9fb5                	addw	a5,a5,a3
     b44:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
     b48:	00074683          	lbu	a3,0(a4)
     b4c:	fd06879b          	addiw	a5,a3,-48
     b50:	0ff7f793          	zext.b	a5,a5
     b54:	fef671e3          	bgeu	a2,a5,b36 <atoi+0x1e>
  return n;
}
     b58:	60a2                	ld	ra,8(sp)
     b5a:	6402                	ld	s0,0(sp)
     b5c:	0141                	addi	sp,sp,16
     b5e:	8082                	ret
  n = 0;
     b60:	4501                	li	a0,0
     b62:	bfdd                	j	b58 <atoi+0x40>

0000000000000b64 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
     b64:	1141                	addi	sp,sp,-16
     b66:	e406                	sd	ra,8(sp)
     b68:	e022                	sd	s0,0(sp)
     b6a:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
     b6c:	02b57563          	bgeu	a0,a1,b96 <memmove+0x32>
    while(n-- > 0)
     b70:	00c05f63          	blez	a2,b8e <memmove+0x2a>
     b74:	1602                	slli	a2,a2,0x20
     b76:	9201                	srli	a2,a2,0x20
     b78:	00c507b3          	add	a5,a0,a2
  dst = vdst;
     b7c:	872a                	mv	a4,a0
      *dst++ = *src++;
     b7e:	0585                	addi	a1,a1,1
     b80:	0705                	addi	a4,a4,1
     b82:	fff5c683          	lbu	a3,-1(a1)
     b86:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
     b8a:	fee79ae3          	bne	a5,a4,b7e <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
     b8e:	60a2                	ld	ra,8(sp)
     b90:	6402                	ld	s0,0(sp)
     b92:	0141                	addi	sp,sp,16
     b94:	8082                	ret
    while(n-- > 0)
     b96:	fec05ce3          	blez	a2,b8e <memmove+0x2a>
    dst += n;
     b9a:	00c50733          	add	a4,a0,a2
    src += n;
     b9e:	95b2                	add	a1,a1,a2
     ba0:	fff6079b          	addiw	a5,a2,-1
     ba4:	1782                	slli	a5,a5,0x20
     ba6:	9381                	srli	a5,a5,0x20
     ba8:	fff7c793          	not	a5,a5
     bac:	97ba                	add	a5,a5,a4
      *--dst = *--src;
     bae:	15fd                	addi	a1,a1,-1
     bb0:	177d                	addi	a4,a4,-1
     bb2:	0005c683          	lbu	a3,0(a1)
     bb6:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
     bba:	fef71ae3          	bne	a4,a5,bae <memmove+0x4a>
     bbe:	bfc1                	j	b8e <memmove+0x2a>

0000000000000bc0 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
     bc0:	1141                	addi	sp,sp,-16
     bc2:	e406                	sd	ra,8(sp)
     bc4:	e022                	sd	s0,0(sp)
     bc6:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
     bc8:	ce19                	beqz	a2,be6 <memcmp+0x26>
     bca:	1602                	slli	a2,a2,0x20
     bcc:	9201                	srli	a2,a2,0x20
     bce:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
     bd2:	00054783          	lbu	a5,0(a0)
     bd6:	0005c703          	lbu	a4,0(a1)
     bda:	00e79b63          	bne	a5,a4,bf0 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
     bde:	0505                	addi	a0,a0,1
    p2++;
     be0:	0585                	addi	a1,a1,1
  while (n-- > 0) {
     be2:	fed518e3          	bne	a0,a3,bd2 <memcmp+0x12>
  }
  return 0;
     be6:	4501                	li	a0,0
}
     be8:	60a2                	ld	ra,8(sp)
     bea:	6402                	ld	s0,0(sp)
     bec:	0141                	addi	sp,sp,16
     bee:	8082                	ret
      return *p1 - *p2;
     bf0:	40e7853b          	subw	a0,a5,a4
     bf4:	bfd5                	j	be8 <memcmp+0x28>

0000000000000bf6 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
     bf6:	1141                	addi	sp,sp,-16
     bf8:	e406                	sd	ra,8(sp)
     bfa:	e022                	sd	s0,0(sp)
     bfc:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
     bfe:	f67ff0ef          	jal	b64 <memmove>
}
     c02:	60a2                	ld	ra,8(sp)
     c04:	6402                	ld	s0,0(sp)
     c06:	0141                	addi	sp,sp,16
     c08:	8082                	ret

0000000000000c0a <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
     c0a:	4885                	li	a7,1
 ecall
     c0c:	00000073          	ecall
 ret
     c10:	8082                	ret

0000000000000c12 <exit>:
.global exit
exit:
 li a7, SYS_exit
     c12:	4889                	li	a7,2
 ecall
     c14:	00000073          	ecall
 ret
     c18:	8082                	ret

0000000000000c1a <wait>:
.global wait
wait:
 li a7, SYS_wait
     c1a:	488d                	li	a7,3
 ecall
     c1c:	00000073          	ecall
 ret
     c20:	8082                	ret

0000000000000c22 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
     c22:	4891                	li	a7,4
 ecall
     c24:	00000073          	ecall
 ret
     c28:	8082                	ret

0000000000000c2a <read>:
.global read
read:
 li a7, SYS_read
     c2a:	4895                	li	a7,5
 ecall
     c2c:	00000073          	ecall
 ret
     c30:	8082                	ret

0000000000000c32 <write>:
.global write
write:
 li a7, SYS_write
     c32:	48c1                	li	a7,16
 ecall
     c34:	00000073          	ecall
 ret
     c38:	8082                	ret

0000000000000c3a <close>:
.global close
close:
 li a7, SYS_close
     c3a:	48d5                	li	a7,21
 ecall
     c3c:	00000073          	ecall
 ret
     c40:	8082                	ret

0000000000000c42 <kill>:
.global kill
kill:
 li a7, SYS_kill
     c42:	4899                	li	a7,6
 ecall
     c44:	00000073          	ecall
 ret
     c48:	8082                	ret

0000000000000c4a <exec>:
.global exec
exec:
 li a7, SYS_exec
     c4a:	489d                	li	a7,7
 ecall
     c4c:	00000073          	ecall
 ret
     c50:	8082                	ret

0000000000000c52 <open>:
.global open
open:
 li a7, SYS_open
     c52:	48bd                	li	a7,15
 ecall
     c54:	00000073          	ecall
 ret
     c58:	8082                	ret

0000000000000c5a <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
     c5a:	48c5                	li	a7,17
 ecall
     c5c:	00000073          	ecall
 ret
     c60:	8082                	ret

0000000000000c62 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
     c62:	48c9                	li	a7,18
 ecall
     c64:	00000073          	ecall
 ret
     c68:	8082                	ret

0000000000000c6a <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
     c6a:	48a1                	li	a7,8
 ecall
     c6c:	00000073          	ecall
 ret
     c70:	8082                	ret

0000000000000c72 <link>:
.global link
link:
 li a7, SYS_link
     c72:	48cd                	li	a7,19
 ecall
     c74:	00000073          	ecall
 ret
     c78:	8082                	ret

0000000000000c7a <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
     c7a:	48d1                	li	a7,20
 ecall
     c7c:	00000073          	ecall
 ret
     c80:	8082                	ret

0000000000000c82 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
     c82:	48a5                	li	a7,9
 ecall
     c84:	00000073          	ecall
 ret
     c88:	8082                	ret

0000000000000c8a <dup>:
.global dup
dup:
 li a7, SYS_dup
     c8a:	48a9                	li	a7,10
 ecall
     c8c:	00000073          	ecall
 ret
     c90:	8082                	ret

0000000000000c92 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
     c92:	48ad                	li	a7,11
 ecall
     c94:	00000073          	ecall
 ret
     c98:	8082                	ret

0000000000000c9a <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
     c9a:	48b1                	li	a7,12
 ecall
     c9c:	00000073          	ecall
 ret
     ca0:	8082                	ret

0000000000000ca2 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
     ca2:	48b5                	li	a7,13
 ecall
     ca4:	00000073          	ecall
 ret
     ca8:	8082                	ret

0000000000000caa <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
     caa:	48b9                	li	a7,14
 ecall
     cac:	00000073          	ecall
 ret
     cb0:	8082                	ret

0000000000000cb2 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
     cb2:	1101                	addi	sp,sp,-32
     cb4:	ec06                	sd	ra,24(sp)
     cb6:	e822                	sd	s0,16(sp)
     cb8:	1000                	addi	s0,sp,32
     cba:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
     cbe:	4605                	li	a2,1
     cc0:	fef40593          	addi	a1,s0,-17
     cc4:	f6fff0ef          	jal	c32 <write>
}
     cc8:	60e2                	ld	ra,24(sp)
     cca:	6442                	ld	s0,16(sp)
     ccc:	6105                	addi	sp,sp,32
     cce:	8082                	ret

0000000000000cd0 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
     cd0:	715d                	addi	sp,sp,-80
     cd2:	e486                	sd	ra,72(sp)
     cd4:	e0a2                	sd	s0,64(sp)
     cd6:	f84a                	sd	s2,48(sp)
     cd8:	f44e                	sd	s3,40(sp)
     cda:	0880                	addi	s0,sp,80
     cdc:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
     cde:	00d036b3          	snez	a3,a3
     ce2:	03f5d793          	srli	a5,a1,0x3f
     ce6:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
     ce8:	0005871b          	sext.w	a4,a1
  neg = 0;
     cec:	4301                	li	t1,0
  if(sgn && xx < 0){
     cee:	c681                	beqz	a3,cf6 <printint+0x26>
    x = -xx;
     cf0:	40b0073b          	negw	a4,a1
    neg = 1;
     cf4:	4305                	li	t1,1
  }

  i = 0;
     cf6:	fb840993          	addi	s3,s0,-72
  neg = 0;
     cfa:	85ce                	mv	a1,s3
  i = 0;
     cfc:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
     cfe:	00001817          	auipc	a6,0x1
     d02:	a7a80813          	addi	a6,a6,-1414 # 1778 <digits>
     d06:	88b6                	mv	a7,a3
     d08:	0016851b          	addiw	a0,a3,1
     d0c:	86aa                	mv	a3,a0
     d0e:	02c777bb          	remuw	a5,a4,a2
     d12:	1782                	slli	a5,a5,0x20
     d14:	9381                	srli	a5,a5,0x20
     d16:	97c2                	add	a5,a5,a6
     d18:	0007c783          	lbu	a5,0(a5)
     d1c:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
     d20:	87ba                	mv	a5,a4
     d22:	02c7573b          	divuw	a4,a4,a2
     d26:	0585                	addi	a1,a1,1
     d28:	fcc7ffe3          	bgeu	a5,a2,d06 <printint+0x36>
  if(neg)
     d2c:	00030b63          	beqz	t1,d42 <printint+0x72>
    buf[i++] = '-';
     d30:	fd040793          	addi	a5,s0,-48
     d34:	953e                	add	a0,a0,a5
     d36:	02d00793          	li	a5,45
     d3a:	fef50423          	sb	a5,-24(a0)
     d3e:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
     d42:	02d05563          	blez	a3,d6c <printint+0x9c>
     d46:	fc26                	sd	s1,56(sp)
     d48:	36fd                	addiw	a3,a3,-1
     d4a:	00d984b3          	add	s1,s3,a3
     d4e:	19fd                	addi	s3,s3,-1
     d50:	99b6                	add	s3,s3,a3
     d52:	1682                	slli	a3,a3,0x20
     d54:	9281                	srli	a3,a3,0x20
     d56:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
     d5a:	0004c583          	lbu	a1,0(s1)
     d5e:	854a                	mv	a0,s2
     d60:	f53ff0ef          	jal	cb2 <putc>
  while(--i >= 0)
     d64:	14fd                	addi	s1,s1,-1
     d66:	ff349ae3          	bne	s1,s3,d5a <printint+0x8a>
     d6a:	74e2                	ld	s1,56(sp)
}
     d6c:	60a6                	ld	ra,72(sp)
     d6e:	6406                	ld	s0,64(sp)
     d70:	7942                	ld	s2,48(sp)
     d72:	79a2                	ld	s3,40(sp)
     d74:	6161                	addi	sp,sp,80
     d76:	8082                	ret

0000000000000d78 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
     d78:	711d                	addi	sp,sp,-96
     d7a:	ec86                	sd	ra,88(sp)
     d7c:	e8a2                	sd	s0,80(sp)
     d7e:	e4a6                	sd	s1,72(sp)
     d80:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
     d82:	0005c483          	lbu	s1,0(a1)
     d86:	28048263          	beqz	s1,100a <vprintf+0x292>
     d8a:	e0ca                	sd	s2,64(sp)
     d8c:	fc4e                	sd	s3,56(sp)
     d8e:	f852                	sd	s4,48(sp)
     d90:	f456                	sd	s5,40(sp)
     d92:	f05a                	sd	s6,32(sp)
     d94:	ec5e                	sd	s7,24(sp)
     d96:	e862                	sd	s8,16(sp)
     d98:	8b2a                	mv	s6,a0
     d9a:	8a2e                	mv	s4,a1
     d9c:	8bb2                	mv	s7,a2
  state = 0;
     d9e:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
     da0:	4901                	li	s2,0
     da2:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
     da4:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
     da8:	06400c13          	li	s8,100
     dac:	a00d                	j	dce <vprintf+0x56>
        putc(fd, c0);
     dae:	85a6                	mv	a1,s1
     db0:	855a                	mv	a0,s6
     db2:	f01ff0ef          	jal	cb2 <putc>
     db6:	a019                	j	dbc <vprintf+0x44>
    } else if(state == '%'){
     db8:	03598363          	beq	s3,s5,dde <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
     dbc:	0019079b          	addiw	a5,s2,1
     dc0:	893e                	mv	s2,a5
     dc2:	873e                	mv	a4,a5
     dc4:	97d2                	add	a5,a5,s4
     dc6:	0007c483          	lbu	s1,0(a5)
     dca:	22048963          	beqz	s1,ffc <vprintf+0x284>
    c0 = fmt[i] & 0xff;
     dce:	0004879b          	sext.w	a5,s1
    if(state == 0){
     dd2:	fe0993e3          	bnez	s3,db8 <vprintf+0x40>
      if(c0 == '%'){
     dd6:	fd579ce3          	bne	a5,s5,dae <vprintf+0x36>
        state = '%';
     dda:	89be                	mv	s3,a5
     ddc:	b7c5                	j	dbc <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
     dde:	00ea06b3          	add	a3,s4,a4
     de2:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
     de6:	22060763          	beqz	a2,1014 <vprintf+0x29c>
      if(c0 == 'd'){
     dea:	0b878363          	beq	a5,s8,e90 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
     dee:	f9478693          	addi	a3,a5,-108
     df2:	0016b693          	seqz	a3,a3
     df6:	f9c60593          	addi	a1,a2,-100
     dfa:	0015b593          	seqz	a1,a1
     dfe:	8df5                	and	a1,a1,a3
     e00:	e5c5                	bnez	a1,ea8 <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
     e02:	9752                	add	a4,a4,s4
     e04:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
     e08:	f9460713          	addi	a4,a2,-108
     e0c:	00173713          	seqz	a4,a4
     e10:	8f75                	and	a4,a4,a3
     e12:	f9c50593          	addi	a1,a0,-100
     e16:	0015b593          	seqz	a1,a1
     e1a:	8df9                	and	a1,a1,a4
     e1c:	e1dd                	bnez	a1,ec2 <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
     e1e:	07500593          	li	a1,117
     e22:	0ab78d63          	beq	a5,a1,edc <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
     e26:	f8b60593          	addi	a1,a2,-117
     e2a:	0015b593          	seqz	a1,a1
     e2e:	8df5                	and	a1,a1,a3
     e30:	e1f1                	bnez	a1,ef4 <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
     e32:	f8b50593          	addi	a1,a0,-117
     e36:	0015b593          	seqz	a1,a1
     e3a:	8df9                	and	a1,a1,a4
     e3c:	e9e9                	bnez	a1,f0e <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
     e3e:	07800593          	li	a1,120
     e42:	0eb78363          	beq	a5,a1,f28 <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
     e46:	f8860613          	addi	a2,a2,-120
     e4a:	00163613          	seqz	a2,a2
     e4e:	8ef1                	and	a3,a3,a2
     e50:	0e069863          	bnez	a3,f40 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
     e54:	f8850513          	addi	a0,a0,-120
     e58:	00153513          	seqz	a0,a0
     e5c:	8f69                	and	a4,a4,a0
     e5e:	0e071e63          	bnez	a4,f5a <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
     e62:	07000713          	li	a4,112
     e66:	10e78663          	beq	a5,a4,f72 <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
     e6a:	07300713          	li	a4,115
     e6e:	14e78663          	beq	a5,a4,fba <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
     e72:	02500713          	li	a4,37
     e76:	16e78e63          	beq	a5,a4,ff2 <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
     e7a:	02500593          	li	a1,37
     e7e:	855a                	mv	a0,s6
     e80:	e33ff0ef          	jal	cb2 <putc>
        putc(fd, c0);
     e84:	85a6                	mv	a1,s1
     e86:	855a                	mv	a0,s6
     e88:	e2bff0ef          	jal	cb2 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
     e8c:	4981                	li	s3,0
     e8e:	b73d                	j	dbc <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
     e90:	008b8493          	addi	s1,s7,8
     e94:	4685                	li	a3,1
     e96:	4629                	li	a2,10
     e98:	000ba583          	lw	a1,0(s7)
     e9c:	855a                	mv	a0,s6
     e9e:	e33ff0ef          	jal	cd0 <printint>
     ea2:	8ba6                	mv	s7,s1
      state = 0;
     ea4:	4981                	li	s3,0
     ea6:	bf19                	j	dbc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
     ea8:	008b8493          	addi	s1,s7,8
     eac:	4685                	li	a3,1
     eae:	4629                	li	a2,10
     eb0:	000bb583          	ld	a1,0(s7)
     eb4:	855a                	mv	a0,s6
     eb6:	e1bff0ef          	jal	cd0 <printint>
        i += 1;
     eba:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
     ebc:	8ba6                	mv	s7,s1
      state = 0;
     ebe:	4981                	li	s3,0
     ec0:	bdf5                	j	dbc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
     ec2:	008b8493          	addi	s1,s7,8
     ec6:	4685                	li	a3,1
     ec8:	4629                	li	a2,10
     eca:	000bb583          	ld	a1,0(s7)
     ece:	855a                	mv	a0,s6
     ed0:	e01ff0ef          	jal	cd0 <printint>
        i += 2;
     ed4:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
     ed6:	8ba6                	mv	s7,s1
      state = 0;
     ed8:	4981                	li	s3,0
        i += 2;
     eda:	b5cd                	j	dbc <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
     edc:	008b8493          	addi	s1,s7,8
     ee0:	4681                	li	a3,0
     ee2:	4629                	li	a2,10
     ee4:	000ba583          	lw	a1,0(s7)
     ee8:	855a                	mv	a0,s6
     eea:	de7ff0ef          	jal	cd0 <printint>
     eee:	8ba6                	mv	s7,s1
      state = 0;
     ef0:	4981                	li	s3,0
     ef2:	b5e9                	j	dbc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
     ef4:	008b8493          	addi	s1,s7,8
     ef8:	4681                	li	a3,0
     efa:	4629                	li	a2,10
     efc:	000bb583          	ld	a1,0(s7)
     f00:	855a                	mv	a0,s6
     f02:	dcfff0ef          	jal	cd0 <printint>
        i += 1;
     f06:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
     f08:	8ba6                	mv	s7,s1
      state = 0;
     f0a:	4981                	li	s3,0
     f0c:	bd45                	j	dbc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
     f0e:	008b8493          	addi	s1,s7,8
     f12:	4681                	li	a3,0
     f14:	4629                	li	a2,10
     f16:	000bb583          	ld	a1,0(s7)
     f1a:	855a                	mv	a0,s6
     f1c:	db5ff0ef          	jal	cd0 <printint>
        i += 2;
     f20:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
     f22:	8ba6                	mv	s7,s1
      state = 0;
     f24:	4981                	li	s3,0
        i += 2;
     f26:	bd59                	j	dbc <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
     f28:	008b8493          	addi	s1,s7,8
     f2c:	4681                	li	a3,0
     f2e:	4641                	li	a2,16
     f30:	000ba583          	lw	a1,0(s7)
     f34:	855a                	mv	a0,s6
     f36:	d9bff0ef          	jal	cd0 <printint>
     f3a:	8ba6                	mv	s7,s1
      state = 0;
     f3c:	4981                	li	s3,0
     f3e:	bdbd                	j	dbc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
     f40:	008b8493          	addi	s1,s7,8
     f44:	4681                	li	a3,0
     f46:	4641                	li	a2,16
     f48:	000bb583          	ld	a1,0(s7)
     f4c:	855a                	mv	a0,s6
     f4e:	d83ff0ef          	jal	cd0 <printint>
        i += 1;
     f52:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
     f54:	8ba6                	mv	s7,s1
      state = 0;
     f56:	4981                	li	s3,0
     f58:	b595                	j	dbc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
     f5a:	008b8493          	addi	s1,s7,8
     f5e:	4641                	li	a2,16
     f60:	000bb583          	ld	a1,0(s7)
     f64:	855a                	mv	a0,s6
     f66:	d6bff0ef          	jal	cd0 <printint>
        i += 2;
     f6a:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
     f6c:	8ba6                	mv	s7,s1
      state = 0;
     f6e:	4981                	li	s3,0
        i += 2;
     f70:	b5b1                	j	dbc <vprintf+0x44>
     f72:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
     f74:	008b8793          	addi	a5,s7,8
     f78:	8cbe                	mv	s9,a5
     f7a:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
     f7e:	03000593          	li	a1,48
     f82:	855a                	mv	a0,s6
     f84:	d2fff0ef          	jal	cb2 <putc>
  putc(fd, 'x');
     f88:	07800593          	li	a1,120
     f8c:	855a                	mv	a0,s6
     f8e:	d25ff0ef          	jal	cb2 <putc>
     f92:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
     f94:	00000b97          	auipc	s7,0x0
     f98:	7e4b8b93          	addi	s7,s7,2020 # 1778 <digits>
     f9c:	03c9d793          	srli	a5,s3,0x3c
     fa0:	97de                	add	a5,a5,s7
     fa2:	0007c583          	lbu	a1,0(a5)
     fa6:	855a                	mv	a0,s6
     fa8:	d0bff0ef          	jal	cb2 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
     fac:	0992                	slli	s3,s3,0x4
     fae:	34fd                	addiw	s1,s1,-1
     fb0:	f4f5                	bnez	s1,f9c <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
     fb2:	8be6                	mv	s7,s9
      state = 0;
     fb4:	4981                	li	s3,0
     fb6:	6ca2                	ld	s9,8(sp)
     fb8:	b511                	j	dbc <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
     fba:	008b8993          	addi	s3,s7,8
     fbe:	000bb483          	ld	s1,0(s7)
     fc2:	cc91                	beqz	s1,fde <vprintf+0x266>
        for(; *s; s++)
     fc4:	0004c583          	lbu	a1,0(s1)
     fc8:	c195                	beqz	a1,fec <vprintf+0x274>
          putc(fd, *s);
     fca:	855a                	mv	a0,s6
     fcc:	ce7ff0ef          	jal	cb2 <putc>
        for(; *s; s++)
     fd0:	0485                	addi	s1,s1,1
     fd2:	0004c583          	lbu	a1,0(s1)
     fd6:	f9f5                	bnez	a1,fca <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
     fd8:	8bce                	mv	s7,s3
      state = 0;
     fda:	4981                	li	s3,0
     fdc:	b3c5                	j	dbc <vprintf+0x44>
          s = "(null)";
     fde:	00000497          	auipc	s1,0x0
     fe2:	70a48493          	addi	s1,s1,1802 # 16e8 <thread_switch+0x374>
        for(; *s; s++)
     fe6:	02800593          	li	a1,40
     fea:	b7c5                	j	fca <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
     fec:	8bce                	mv	s7,s3
      state = 0;
     fee:	4981                	li	s3,0
     ff0:	b3f1                	j	dbc <vprintf+0x44>
        putc(fd, '%');
     ff2:	85be                	mv	a1,a5
     ff4:	855a                	mv	a0,s6
     ff6:	cbdff0ef          	jal	cb2 <putc>
     ffa:	bd49                	j	e8c <vprintf+0x114>
     ffc:	6906                	ld	s2,64(sp)
     ffe:	79e2                	ld	s3,56(sp)
    1000:	7a42                	ld	s4,48(sp)
    1002:	7aa2                	ld	s5,40(sp)
    1004:	7b02                	ld	s6,32(sp)
    1006:	6be2                	ld	s7,24(sp)
    1008:	6c42                	ld	s8,16(sp)
    }
  }
}
    100a:	60e6                	ld	ra,88(sp)
    100c:	6446                	ld	s0,80(sp)
    100e:	64a6                	ld	s1,72(sp)
    1010:	6125                	addi	sp,sp,96
    1012:	8082                	ret
      if(c0 == 'd'){
    1014:	06400713          	li	a4,100
    1018:	e6e78ce3          	beq	a5,a4,e90 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
    101c:	f9478693          	addi	a3,a5,-108
    1020:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
    1024:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    1026:	4701                	li	a4,0
    1028:	bbdd                	j	e1e <vprintf+0xa6>

000000000000102a <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
    102a:	715d                	addi	sp,sp,-80
    102c:	ec06                	sd	ra,24(sp)
    102e:	e822                	sd	s0,16(sp)
    1030:	1000                	addi	s0,sp,32
    1032:	e010                	sd	a2,0(s0)
    1034:	e414                	sd	a3,8(s0)
    1036:	e818                	sd	a4,16(s0)
    1038:	ec1c                	sd	a5,24(s0)
    103a:	03043023          	sd	a6,32(s0)
    103e:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
    1042:	8622                	mv	a2,s0
    1044:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
    1048:	d31ff0ef          	jal	d78 <vprintf>
}
    104c:	60e2                	ld	ra,24(sp)
    104e:	6442                	ld	s0,16(sp)
    1050:	6161                	addi	sp,sp,80
    1052:	8082                	ret

0000000000001054 <printf>:

void
printf(const char *fmt, ...)
{
    1054:	711d                	addi	sp,sp,-96
    1056:	ec06                	sd	ra,24(sp)
    1058:	e822                	sd	s0,16(sp)
    105a:	1000                	addi	s0,sp,32
    105c:	e40c                	sd	a1,8(s0)
    105e:	e810                	sd	a2,16(s0)
    1060:	ec14                	sd	a3,24(s0)
    1062:	f018                	sd	a4,32(s0)
    1064:	f41c                	sd	a5,40(s0)
    1066:	03043823          	sd	a6,48(s0)
    106a:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
    106e:	00840613          	addi	a2,s0,8
    1072:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
    1076:	85aa                	mv	a1,a0
    1078:	4505                	li	a0,1
    107a:	cffff0ef          	jal	d78 <vprintf>
}
    107e:	60e2                	ld	ra,24(sp)
    1080:	6442                	ld	s0,16(sp)
    1082:	6125                	addi	sp,sp,96
    1084:	8082                	ret

0000000000001086 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
    1086:	1141                	addi	sp,sp,-16
    1088:	e406                	sd	ra,8(sp)
    108a:	e022                	sd	s0,0(sp)
    108c:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
    108e:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    1092:	00001797          	auipc	a5,0x1
    1096:	f7e7b783          	ld	a5,-130(a5) # 2010 <freep>
    109a:	a095                	j	10fe <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    109c:	ff852583          	lw	a1,-8(a0)
    10a0:	6390                	ld	a2,0(a5)
    10a2:	02059813          	slli	a6,a1,0x20
    10a6:	01c85693          	srli	a3,a6,0x1c
    10aa:	96ba                	add	a3,a3,a4
    10ac:	02d60563          	beq	a2,a3,10d6 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
    10b0:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    10b4:	4790                	lw	a2,8(a5)
    10b6:	02061593          	slli	a1,a2,0x20
    10ba:	01c5d693          	srli	a3,a1,0x1c
    10be:	96be                	add	a3,a3,a5
    10c0:	02d70263          	beq	a4,a3,10e4 <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
    10c4:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
    10c6:	00001717          	auipc	a4,0x1
    10ca:	f4f73523          	sd	a5,-182(a4) # 2010 <freep>
}
    10ce:	60a2                	ld	ra,8(sp)
    10d0:	6402                	ld	s0,0(sp)
    10d2:	0141                	addi	sp,sp,16
    10d4:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
    10d6:	4614                	lw	a3,8(a2)
    10d8:	9ead                	addw	a3,a3,a1
    10da:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
    10de:	6394                	ld	a3,0(a5)
    10e0:	6290                	ld	a2,0(a3)
    10e2:	b7f9                	j	10b0 <free+0x2a>
    p->s.size += bp->s.size;
    10e4:	ff852703          	lw	a4,-8(a0)
    10e8:	9f31                	addw	a4,a4,a2
    10ea:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
    10ec:	ff053703          	ld	a4,-16(a0)
    10f0:	bfd1                	j	10c4 <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    10f2:	6394                	ld	a3,0(a5)
    10f4:	00d7e463          	bltu	a5,a3,10fc <free+0x76>
    10f8:	fad762e3          	bltu	a4,a3,109c <free+0x16>
    10fc:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    10fe:	fee7fae3          	bgeu	a5,a4,10f2 <free+0x6c>
    1102:	6394                	ld	a3,0(a5)
    1104:	f8d76ce3          	bltu	a4,a3,109c <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    1108:	f8d7fae3          	bgeu	a5,a3,109c <free+0x16>
    110c:	87b6                	mv	a5,a3
    110e:	bfc5                	j	10fe <free+0x78>

0000000000001110 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
    1110:	7139                	addi	sp,sp,-64
    1112:	fc06                	sd	ra,56(sp)
    1114:	f822                	sd	s0,48(sp)
    1116:	f04a                	sd	s2,32(sp)
    1118:	ec4e                	sd	s3,24(sp)
    111a:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    111c:	02051993          	slli	s3,a0,0x20
    1120:	0209d993          	srli	s3,s3,0x20
    1124:	09bd                	addi	s3,s3,15
    1126:	0049d993          	srli	s3,s3,0x4
    112a:	2985                	addiw	s3,s3,1
    112c:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
    112e:	00001517          	auipc	a0,0x1
    1132:	ee253503          	ld	a0,-286(a0) # 2010 <freep>
    1136:	c905                	beqz	a0,1166 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    1138:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    113a:	4798                	lw	a4,8(a5)
    113c:	09377663          	bgeu	a4,s3,11c8 <malloc+0xb8>
    1140:	f426                	sd	s1,40(sp)
    1142:	e852                	sd	s4,16(sp)
    1144:	e456                	sd	s5,8(sp)
    1146:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
    1148:	8a4e                	mv	s4,s3
    114a:	6705                	lui	a4,0x1
    114c:	00e9f363          	bgeu	s3,a4,1152 <malloc+0x42>
    1150:	6a05                	lui	s4,0x1
    1152:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
    1156:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
    115a:	00001497          	auipc	s1,0x1
    115e:	eb648493          	addi	s1,s1,-330 # 2010 <freep>
  if(p == (char*)-1)
    1162:	5afd                	li	s5,-1
    1164:	a83d                	j	11a2 <malloc+0x92>
    1166:	f426                	sd	s1,40(sp)
    1168:	e852                	sd	s4,16(sp)
    116a:	e456                	sd	s5,8(sp)
    116c:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
    116e:	00001797          	auipc	a5,0x1
    1172:	29a78793          	addi	a5,a5,666 # 2408 <base>
    1176:	00001717          	auipc	a4,0x1
    117a:	e8f73d23          	sd	a5,-358(a4) # 2010 <freep>
    117e:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
    1180:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
    1184:	b7d1                	j	1148 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
    1186:	6398                	ld	a4,0(a5)
    1188:	e118                	sd	a4,0(a0)
    118a:	a899                	j	11e0 <malloc+0xd0>
  hp->s.size = nu;
    118c:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
    1190:	0541                	addi	a0,a0,16
    1192:	ef5ff0ef          	jal	1086 <free>
  return freep;
    1196:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
    1198:	c125                	beqz	a0,11f8 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    119a:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    119c:	4798                	lw	a4,8(a5)
    119e:	03277163          	bgeu	a4,s2,11c0 <malloc+0xb0>
    if(p == freep)
    11a2:	6098                	ld	a4,0(s1)
    11a4:	853e                	mv	a0,a5
    11a6:	fef71ae3          	bne	a4,a5,119a <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
    11aa:	8552                	mv	a0,s4
    11ac:	aefff0ef          	jal	c9a <sbrk>
  if(p == (char*)-1)
    11b0:	fd551ee3          	bne	a0,s5,118c <malloc+0x7c>
        return 0;
    11b4:	4501                	li	a0,0
    11b6:	74a2                	ld	s1,40(sp)
    11b8:	6a42                	ld	s4,16(sp)
    11ba:	6aa2                	ld	s5,8(sp)
    11bc:	6b02                	ld	s6,0(sp)
    11be:	a03d                	j	11ec <malloc+0xdc>
    11c0:	74a2                	ld	s1,40(sp)
    11c2:	6a42                	ld	s4,16(sp)
    11c4:	6aa2                	ld	s5,8(sp)
    11c6:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
    11c8:	fae90fe3          	beq	s2,a4,1186 <malloc+0x76>
        p->s.size -= nunits;
    11cc:	4137073b          	subw	a4,a4,s3
    11d0:	c798                	sw	a4,8(a5)
        p += p->s.size;
    11d2:	02071693          	slli	a3,a4,0x20
    11d6:	01c6d713          	srli	a4,a3,0x1c
    11da:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
    11dc:	0137a423          	sw	s3,8(a5)
      freep = prevp;
    11e0:	00001717          	auipc	a4,0x1
    11e4:	e2a73823          	sd	a0,-464(a4) # 2010 <freep>
      return (void*)(p + 1);
    11e8:	01078513          	addi	a0,a5,16
  }
}
    11ec:	70e2                	ld	ra,56(sp)
    11ee:	7442                	ld	s0,48(sp)
    11f0:	7902                	ld	s2,32(sp)
    11f2:	69e2                	ld	s3,24(sp)
    11f4:	6121                	addi	sp,sp,64
    11f6:	8082                	ret
    11f8:	74a2                	ld	s1,40(sp)
    11fa:	6a42                	ld	s4,16(sp)
    11fc:	6aa2                	ld	s5,8(sp)
    11fe:	6b02                	ld	s6,0(sp)
    1200:	b7f5                	j	11ec <malloc+0xdc>

0000000000001202 <thread_init>:
struct thread *current_thread;
extern void thread_switch(uint64, uint64);
              
void 
thread_init(void)
{
    1202:	1141                	addi	sp,sp,-16
    1204:	e406                	sd	ra,8(sp)
    1206:	e022                	sd	s0,0(sp)
    1208:	0800                	addi	s0,sp,16
  // main() is thread 0, which will make the first invocation to
  // thread_schedule(). It needs a stack so that the first thread_switch() can
  // save thread 0's state.
  current_thread = &all_thread[0];
    120a:	00001797          	auipc	a5,0x1
    120e:	20e78793          	addi	a5,a5,526 # 2418 <all_thread>
    1212:	00001717          	auipc	a4,0x1
    1216:	e0f73323          	sd	a5,-506(a4) # 2018 <current_thread>
  current_thread->state = RUNNING;
    121a:	00003717          	auipc	a4,0x3
    121e:	1fe70713          	addi	a4,a4,510 # 4418 <all_thread+0x2000>
    1222:	4785                	li	a5,1
    1224:	c31c                	sw	a5,0(a4)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
    1226:	00003797          	auipc	a5,0x3
    122a:	18278793          	addi	a5,a5,386 # 43a8 <all_thread+0x1f90>
  return (struct context *)(top & ~(uint64)0xf);
    122e:	9bc1                	andi	a5,a5,-16
  // Thread 0 runs on the process's own stack, but the first thread_switch()
  // still needs a writable place to save its context.
  current_thread->context = thread_context_slot(current_thread);
    1230:	e71c                	sd	a5,8(a4)
}
    1232:	60a2                	ld	ra,8(sp)
    1234:	6402                	ld	s0,0(sp)
    1236:	0141                	addi	sp,sp,16
    1238:	8082                	ret

000000000000123a <thread_schedule>:

void 
thread_schedule(void)
{
    123a:	1141                	addi	sp,sp,-16
    123c:	e406                	sd	ra,8(sp)
    123e:	e022                	sd	s0,0(sp)
    1240:	0800                	addi	s0,sp,16
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
    1242:	00001597          	auipc	a1,0x1
    1246:	dd65b583          	ld	a1,-554(a1) # 2018 <current_thread>
    124a:	6789                	lui	a5,0x2
    124c:	07c1                	addi	a5,a5,16 # 2010 <freep>
    124e:	97ae                	add	a5,a5,a1
    1250:	4711                	li	a4,4
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
    1252:	00009897          	auipc	a7,0x9
    1256:	20688893          	addi	a7,a7,518 # a458 <all_thread+0x8040>
      t = all_thread;
    if(t->state == RUNNABLE) {
    125a:	6809                	lui	a6,0x2
    125c:	4509                	li	a0,2
      next_thread = t;
      break;
    }
    t = t + 1;
    125e:	01080613          	addi	a2,a6,16 # 2010 <freep>
    1262:	a809                	j	1274 <thread_schedule+0x3a>
    if(t->state == RUNNABLE) {
    1264:	010786b3          	add	a3,a5,a6
    1268:	4294                	lw	a3,0(a3)
    126a:	02a68563          	beq	a3,a0,1294 <thread_schedule+0x5a>
    t = t + 1;
    126e:	97b2                	add	a5,a5,a2
  for(int i = 0; i < MAX_THREAD; i++){
    1270:	377d                	addiw	a4,a4,-1
    1272:	cb01                	beqz	a4,1282 <thread_schedule+0x48>
    if(t >= all_thread + MAX_THREAD)
    1274:	ff17e8e3          	bltu	a5,a7,1264 <thread_schedule+0x2a>
      t = all_thread;
    1278:	00001797          	auipc	a5,0x1
    127c:	1a078793          	addi	a5,a5,416 # 2418 <all_thread>
    1280:	b7d5                	j	1264 <thread_schedule+0x2a>
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
    1282:	00000517          	auipc	a0,0x0
    1286:	46e50513          	addi	a0,a0,1134 # 16f0 <thread_switch+0x37c>
    128a:	dcbff0ef          	jal	1054 <printf>
    exit(-1);
    128e:	557d                	li	a0,-1
    1290:	983ff0ef          	jal	c12 <exit>
  }

  if (current_thread != next_thread) {         /* switch threads?  */
    1294:	02f58163          	beq	a1,a5,12b6 <thread_schedule+0x7c>
    next_thread->state = RUNNING;
    1298:	6689                	lui	a3,0x2
    129a:	00d78733          	add	a4,a5,a3
    129e:	4605                	li	a2,1
    12a0:	c310                	sw	a2,0(a4)
    t = current_thread;
    current_thread = next_thread;
    12a2:	00001617          	auipc	a2,0x1
    12a6:	d6f63b23          	sd	a5,-650(a2) # 2018 <current_thread>
    thread_switch((uint64)t->context, (uint64)next_thread->context);
    12aa:	00d587b3          	add	a5,a1,a3
    12ae:	670c                	ld	a1,8(a4)
    12b0:	6788                	ld	a0,8(a5)
    12b2:	0c2000ef          	jal	1374 <thread_switch>
  } else
    next_thread = 0;
}
    12b6:	60a2                	ld	ra,8(sp)
    12b8:	6402                	ld	s0,0(sp)
    12ba:	0141                	addi	sp,sp,16
    12bc:	8082                	ret

00000000000012be <thread_create>:

void 
thread_create(void (*func)())
{
    12be:	1101                	addi	sp,sp,-32
    12c0:	ec06                	sd	ra,24(sp)
    12c2:	e822                	sd	s0,16(sp)
    12c4:	e426                	sd	s1,8(sp)
    12c6:	e04a                	sd	s2,0(sp)
    12c8:	1000                	addi	s0,sp,32
    12ca:	892a                	mv	s2,a0
  struct thread *t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
    12cc:	00003797          	auipc	a5,0x3
    12d0:	15c78793          	addi	a5,a5,348 # 4428 <all_thread+0x2010>
    12d4:	0000b597          	auipc	a1,0xb
    12d8:	19458593          	addi	a1,a1,404 # c468 <all_thread+0xa050>
    12dc:	6609                	lui	a2,0x2
    12de:	0641                	addi	a2,a2,16 # 2010 <freep>
    if (t->state == FREE) break;
    12e0:	873e                	mv	a4,a5
    12e2:	ff07a683          	lw	a3,-16(a5)
    12e6:	ce9d                	beqz	a3,1324 <thread_create+0x66>
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
    12e8:	97b2                	add	a5,a5,a2
    12ea:	feb79be3          	bne	a5,a1,12e0 <thread_create+0x22>
  }
  t->state = RUNNABLE;
    12ee:	6489                	lui	s1,0x2
    12f0:	94ba                	add	s1,s1,a4
    12f2:	4789                	li	a5,2
    12f4:	c09c                	sw	a5,0(s1)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
    12f6:	6789                	lui	a5,0x2
    12f8:	f9078793          	addi	a5,a5,-112 # 1f90 <digits+0x818>
    12fc:	973e                	add	a4,a4,a5
  return (struct context *)(top & ~(uint64)0xf);
    12fe:	ff077513          	andi	a0,a4,-16
  // A never-run thread has no saved state, so construct one: thread_switch()
  // restores ra and sp, and `ret` then starts func on this thread's own stack.
  t->context = thread_context_slot(t);
    1302:	e488                	sd	a0,8(s1)
  memset(t->context, 0, sizeof(struct context));
    1304:	07000613          	li	a2,112
    1308:	4581                	li	a1,0
    130a:	f0aff0ef          	jal	a14 <memset>
  t->context->ra = (uint64)func;
    130e:	649c                	ld	a5,8(s1)
    1310:	0127b023          	sd	s2,0(a5)
  t->context->sp = (uint64)t->context;   // 16-byte aligned, grows down
    1314:	649c                	ld	a5,8(s1)
    1316:	e79c                	sd	a5,8(a5)
}
    1318:	60e2                	ld	ra,24(sp)
    131a:	6442                	ld	s0,16(sp)
    131c:	64a2                	ld	s1,8(sp)
    131e:	6902                	ld	s2,0(sp)
    1320:	6105                	addi	sp,sp,32
    1322:	8082                	ret
    1324:	7779                	lui	a4,0xffffe
    1326:	1741                	addi	a4,a4,-16 # ffffffffffffdff0 <all_thread+0xffffffffffffbbd8>
    1328:	973e                	add	a4,a4,a5
    132a:	b7d1                	j	12ee <thread_create+0x30>

000000000000132c <thread_yield>:

void 
thread_yield(void)
{
    132c:	1141                	addi	sp,sp,-16
    132e:	e406                	sd	ra,8(sp)
    1330:	e022                	sd	s0,0(sp)
    1332:	0800                	addi	s0,sp,16
  current_thread->state = RUNNABLE;
    1334:	00001797          	auipc	a5,0x1
    1338:	ce47b783          	ld	a5,-796(a5) # 2018 <current_thread>
    133c:	6709                	lui	a4,0x2
    133e:	97ba                	add	a5,a5,a4
    1340:	4709                	li	a4,2
    1342:	c398                	sw	a4,0(a5)
  thread_schedule();
    1344:	ef7ff0ef          	jal	123a <thread_schedule>
}
    1348:	60a2                	ld	ra,8(sp)
    134a:	6402                	ld	s0,0(sp)
    134c:	0141                	addi	sp,sp,16
    134e:	8082                	ret

0000000000001350 <thread_exit>:

void thread_exit(void) {
    1350:	1141                	addi	sp,sp,-16
    1352:	e406                	sd	ra,8(sp)
    1354:	e022                	sd	s0,0(sp)
    1356:	0800                	addi	s0,sp,16
  current_thread->state = FREE;
    1358:	00001797          	auipc	a5,0x1
    135c:	cc07b783          	ld	a5,-832(a5) # 2018 <current_thread>
    1360:	6709                	lui	a4,0x2
    1362:	97ba                	add	a5,a5,a4
    1364:	0007a023          	sw	zero,0(a5)
  thread_schedule();
    1368:	ed3ff0ef          	jal	123a <thread_schedule>
}
    136c:	60a2                	ld	ra,8(sp)
    136e:	6402                	ld	s0,0(sp)
    1370:	0141                	addi	sp,sp,16
    1372:	8082                	ret

0000000000001374 <thread_switch>:
    1374:	00153023          	sd	ra,0(a0)
    1378:	00253423          	sd	sp,8(a0)
    137c:	e900                	sd	s0,16(a0)
    137e:	ed04                	sd	s1,24(a0)
    1380:	03253023          	sd	s2,32(a0)
    1384:	03353423          	sd	s3,40(a0)
    1388:	03453823          	sd	s4,48(a0)
    138c:	03553c23          	sd	s5,56(a0)
    1390:	05653023          	sd	s6,64(a0)
    1394:	05753423          	sd	s7,72(a0)
    1398:	05853823          	sd	s8,80(a0)
    139c:	05953c23          	sd	s9,88(a0)
    13a0:	07a53023          	sd	s10,96(a0)
    13a4:	07b53423          	sd	s11,104(a0)
    13a8:	0005b083          	ld	ra,0(a1)
    13ac:	0085b103          	ld	sp,8(a1)
    13b0:	6980                	ld	s0,16(a1)
    13b2:	6d84                	ld	s1,24(a1)
    13b4:	0205b903          	ld	s2,32(a1)
    13b8:	0285b983          	ld	s3,40(a1)
    13bc:	0305ba03          	ld	s4,48(a1)
    13c0:	0385ba83          	ld	s5,56(a1)
    13c4:	0405bb03          	ld	s6,64(a1)
    13c8:	0485bb83          	ld	s7,72(a1)
    13cc:	0505bc03          	ld	s8,80(a1)
    13d0:	0585bc83          	ld	s9,88(a1)
    13d4:	0605bd03          	ld	s10,96(a1)
    13d8:	0685bd83          	ld	s11,104(a1)
    13dc:	8082                	ret
