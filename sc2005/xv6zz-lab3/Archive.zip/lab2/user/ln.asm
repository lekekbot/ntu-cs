
user/_ln:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	1000                	addi	s0,sp,32
  if(argc != 3){
   8:	478d                	li	a5,3
   a:	00f50d63          	beq	a0,a5,24 <main+0x24>
   e:	e426                	sd	s1,8(sp)
    fprintf(2, "Usage: ln old new\n");
  10:	00001597          	auipc	a1,0x1
  14:	aa058593          	addi	a1,a1,-1376 # ab0 <thread_switch+0x74>
  18:	4509                	li	a0,2
  1a:	6d8000ef          	jal	6f2 <fprintf>
    exit(1);
  1e:	4505                	li	a0,1
  20:	2ba000ef          	jal	2da <exit>
  24:	e426                	sd	s1,8(sp)
  26:	84ae                	mv	s1,a1
  }
  if(link(argv[1], argv[2]) < 0)
  28:	698c                	ld	a1,16(a1)
  2a:	6488                	ld	a0,8(s1)
  2c:	30e000ef          	jal	33a <link>
  30:	00054563          	bltz	a0,3a <main+0x3a>
    fprintf(2, "link %s %s: failed\n", argv[1], argv[2]);
  exit(0);
  34:	4501                	li	a0,0
  36:	2a4000ef          	jal	2da <exit>
    fprintf(2, "link %s %s: failed\n", argv[1], argv[2]);
  3a:	6894                	ld	a3,16(s1)
  3c:	6490                	ld	a2,8(s1)
  3e:	00001597          	auipc	a1,0x1
  42:	a8a58593          	addi	a1,a1,-1398 # ac8 <thread_switch+0x8c>
  46:	4509                	li	a0,2
  48:	6aa000ef          	jal	6f2 <fprintf>
  4c:	b7e5                	j	34 <main+0x34>

000000000000004e <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  4e:	1141                	addi	sp,sp,-16
  50:	e406                	sd	ra,8(sp)
  52:	e022                	sd	s0,0(sp)
  54:	0800                	addi	s0,sp,16
  extern int main();
  main();
  56:	fabff0ef          	jal	0 <main>
  exit(0);
  5a:	4501                	li	a0,0
  5c:	27e000ef          	jal	2da <exit>

0000000000000060 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  60:	1141                	addi	sp,sp,-16
  62:	e406                	sd	ra,8(sp)
  64:	e022                	sd	s0,0(sp)
  66:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  68:	87aa                	mv	a5,a0
  6a:	0585                	addi	a1,a1,1
  6c:	0785                	addi	a5,a5,1
  6e:	fff5c703          	lbu	a4,-1(a1)
  72:	fee78fa3          	sb	a4,-1(a5)
  76:	fb75                	bnez	a4,6a <strcpy+0xa>
    ;
  return os;
}
  78:	60a2                	ld	ra,8(sp)
  7a:	6402                	ld	s0,0(sp)
  7c:	0141                	addi	sp,sp,16
  7e:	8082                	ret

0000000000000080 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  80:	1141                	addi	sp,sp,-16
  82:	e406                	sd	ra,8(sp)
  84:	e022                	sd	s0,0(sp)
  86:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  88:	00054783          	lbu	a5,0(a0)
  8c:	cb91                	beqz	a5,a0 <strcmp+0x20>
  8e:	0005c703          	lbu	a4,0(a1)
  92:	00f71763          	bne	a4,a5,a0 <strcmp+0x20>
    p++, q++;
  96:	0505                	addi	a0,a0,1
  98:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
  9a:	00054783          	lbu	a5,0(a0)
  9e:	fbe5                	bnez	a5,8e <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
  a0:	0005c503          	lbu	a0,0(a1)
}
  a4:	40a7853b          	subw	a0,a5,a0
  a8:	60a2                	ld	ra,8(sp)
  aa:	6402                	ld	s0,0(sp)
  ac:	0141                	addi	sp,sp,16
  ae:	8082                	ret

00000000000000b0 <strlen>:

uint
strlen(const char *s)
{
  b0:	1141                	addi	sp,sp,-16
  b2:	e406                	sd	ra,8(sp)
  b4:	e022                	sd	s0,0(sp)
  b6:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
  b8:	00054783          	lbu	a5,0(a0)
  bc:	cf91                	beqz	a5,d8 <strlen+0x28>
  be:	00150793          	addi	a5,a0,1
  c2:	86be                	mv	a3,a5
  c4:	0785                	addi	a5,a5,1
  c6:	fff7c703          	lbu	a4,-1(a5)
  ca:	ff65                	bnez	a4,c2 <strlen+0x12>
  cc:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
  d0:	60a2                	ld	ra,8(sp)
  d2:	6402                	ld	s0,0(sp)
  d4:	0141                	addi	sp,sp,16
  d6:	8082                	ret
  for(n = 0; s[n]; n++)
  d8:	4501                	li	a0,0
  da:	bfdd                	j	d0 <strlen+0x20>

00000000000000dc <memset>:

void*
memset(void *dst, int c, uint n)
{
  dc:	1141                	addi	sp,sp,-16
  de:	e406                	sd	ra,8(sp)
  e0:	e022                	sd	s0,0(sp)
  e2:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
  e4:	ca19                	beqz	a2,fa <memset+0x1e>
  e6:	87aa                	mv	a5,a0
  e8:	1602                	slli	a2,a2,0x20
  ea:	9201                	srli	a2,a2,0x20
  ec:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
  f0:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
  f4:	0785                	addi	a5,a5,1
  f6:	fee79de3          	bne	a5,a4,f0 <memset+0x14>
  }
  return dst;
}
  fa:	60a2                	ld	ra,8(sp)
  fc:	6402                	ld	s0,0(sp)
  fe:	0141                	addi	sp,sp,16
 100:	8082                	ret

0000000000000102 <strchr>:

char*
strchr(const char *s, char c)
{
 102:	1141                	addi	sp,sp,-16
 104:	e406                	sd	ra,8(sp)
 106:	e022                	sd	s0,0(sp)
 108:	0800                	addi	s0,sp,16
  for(; *s; s++)
 10a:	00054783          	lbu	a5,0(a0)
 10e:	c799                	beqz	a5,11c <strchr+0x1a>
    if(*s == c)
 110:	00f58763          	beq	a1,a5,11e <strchr+0x1c>
  for(; *s; s++)
 114:	0505                	addi	a0,a0,1
 116:	00054783          	lbu	a5,0(a0)
 11a:	fbfd                	bnez	a5,110 <strchr+0xe>
      return (char*)s;
  return 0;
 11c:	4501                	li	a0,0
}
 11e:	60a2                	ld	ra,8(sp)
 120:	6402                	ld	s0,0(sp)
 122:	0141                	addi	sp,sp,16
 124:	8082                	ret

0000000000000126 <gets>:

char*
gets(char *buf, int max)
{
 126:	711d                	addi	sp,sp,-96
 128:	ec86                	sd	ra,88(sp)
 12a:	e8a2                	sd	s0,80(sp)
 12c:	e4a6                	sd	s1,72(sp)
 12e:	e0ca                	sd	s2,64(sp)
 130:	fc4e                	sd	s3,56(sp)
 132:	f852                	sd	s4,48(sp)
 134:	f456                	sd	s5,40(sp)
 136:	f05a                	sd	s6,32(sp)
 138:	ec5e                	sd	s7,24(sp)
 13a:	e862                	sd	s8,16(sp)
 13c:	1080                	addi	s0,sp,96
 13e:	8baa                	mv	s7,a0
 140:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 142:	892a                	mv	s2,a0
 144:	4481                	li	s1,0
    cc = read(0, &c, 1);
 146:	faf40b13          	addi	s6,s0,-81
 14a:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 14c:	8c26                	mv	s8,s1
 14e:	0014899b          	addiw	s3,s1,1
 152:	84ce                	mv	s1,s3
 154:	0349d863          	bge	s3,s4,184 <gets+0x5e>
    cc = read(0, &c, 1);
 158:	8656                	mv	a2,s5
 15a:	85da                	mv	a1,s6
 15c:	4501                	li	a0,0
 15e:	194000ef          	jal	2f2 <read>
    if(cc < 1)
 162:	02a05163          	blez	a0,184 <gets+0x5e>
      break;
    buf[i++] = c;
 166:	faf44783          	lbu	a5,-81(s0)
 16a:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 16e:	0905                	addi	s2,s2,1
 170:	ff678713          	addi	a4,a5,-10
 174:	00173713          	seqz	a4,a4
 178:	17cd                	addi	a5,a5,-13
 17a:	0017b793          	seqz	a5,a5
 17e:	8fd9                	or	a5,a5,a4
 180:	d7f1                	beqz	a5,14c <gets+0x26>
    buf[i++] = c;
 182:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 184:	9c5e                	add	s8,s8,s7
 186:	000c0023          	sb	zero,0(s8)
  return buf;
}
 18a:	855e                	mv	a0,s7
 18c:	60e6                	ld	ra,88(sp)
 18e:	6446                	ld	s0,80(sp)
 190:	64a6                	ld	s1,72(sp)
 192:	6906                	ld	s2,64(sp)
 194:	79e2                	ld	s3,56(sp)
 196:	7a42                	ld	s4,48(sp)
 198:	7aa2                	ld	s5,40(sp)
 19a:	7b02                	ld	s6,32(sp)
 19c:	6be2                	ld	s7,24(sp)
 19e:	6c42                	ld	s8,16(sp)
 1a0:	6125                	addi	sp,sp,96
 1a2:	8082                	ret

00000000000001a4 <stat>:

int
stat(const char *n, struct stat *st)
{
 1a4:	1101                	addi	sp,sp,-32
 1a6:	ec06                	sd	ra,24(sp)
 1a8:	e822                	sd	s0,16(sp)
 1aa:	e04a                	sd	s2,0(sp)
 1ac:	1000                	addi	s0,sp,32
 1ae:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 1b0:	4581                	li	a1,0
 1b2:	168000ef          	jal	31a <open>
  if(fd < 0)
 1b6:	02054263          	bltz	a0,1da <stat+0x36>
 1ba:	e426                	sd	s1,8(sp)
 1bc:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 1be:	85ca                	mv	a1,s2
 1c0:	172000ef          	jal	332 <fstat>
 1c4:	892a                	mv	s2,a0
  close(fd);
 1c6:	8526                	mv	a0,s1
 1c8:	13a000ef          	jal	302 <close>
  return r;
 1cc:	64a2                	ld	s1,8(sp)
}
 1ce:	854a                	mv	a0,s2
 1d0:	60e2                	ld	ra,24(sp)
 1d2:	6442                	ld	s0,16(sp)
 1d4:	6902                	ld	s2,0(sp)
 1d6:	6105                	addi	sp,sp,32
 1d8:	8082                	ret
    return -1;
 1da:	57fd                	li	a5,-1
 1dc:	893e                	mv	s2,a5
 1de:	bfc5                	j	1ce <stat+0x2a>

00000000000001e0 <atoi>:

int
atoi(const char *s)
{
 1e0:	1141                	addi	sp,sp,-16
 1e2:	e406                	sd	ra,8(sp)
 1e4:	e022                	sd	s0,0(sp)
 1e6:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 1e8:	00054683          	lbu	a3,0(a0)
 1ec:	fd06879b          	addiw	a5,a3,-48
 1f0:	0ff7f793          	zext.b	a5,a5
 1f4:	4625                	li	a2,9
 1f6:	02f66963          	bltu	a2,a5,228 <atoi+0x48>
 1fa:	872a                	mv	a4,a0
  n = 0;
 1fc:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 1fe:	0705                	addi	a4,a4,1
 200:	0025179b          	slliw	a5,a0,0x2
 204:	9fa9                	addw	a5,a5,a0
 206:	0017979b          	slliw	a5,a5,0x1
 20a:	9fb5                	addw	a5,a5,a3
 20c:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 210:	00074683          	lbu	a3,0(a4)
 214:	fd06879b          	addiw	a5,a3,-48
 218:	0ff7f793          	zext.b	a5,a5
 21c:	fef671e3          	bgeu	a2,a5,1fe <atoi+0x1e>
  return n;
}
 220:	60a2                	ld	ra,8(sp)
 222:	6402                	ld	s0,0(sp)
 224:	0141                	addi	sp,sp,16
 226:	8082                	ret
  n = 0;
 228:	4501                	li	a0,0
 22a:	bfdd                	j	220 <atoi+0x40>

000000000000022c <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 22c:	1141                	addi	sp,sp,-16
 22e:	e406                	sd	ra,8(sp)
 230:	e022                	sd	s0,0(sp)
 232:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 234:	02b57563          	bgeu	a0,a1,25e <memmove+0x32>
    while(n-- > 0)
 238:	00c05f63          	blez	a2,256 <memmove+0x2a>
 23c:	1602                	slli	a2,a2,0x20
 23e:	9201                	srli	a2,a2,0x20
 240:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 244:	872a                	mv	a4,a0
      *dst++ = *src++;
 246:	0585                	addi	a1,a1,1
 248:	0705                	addi	a4,a4,1
 24a:	fff5c683          	lbu	a3,-1(a1)
 24e:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 252:	fee79ae3          	bne	a5,a4,246 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 256:	60a2                	ld	ra,8(sp)
 258:	6402                	ld	s0,0(sp)
 25a:	0141                	addi	sp,sp,16
 25c:	8082                	ret
    while(n-- > 0)
 25e:	fec05ce3          	blez	a2,256 <memmove+0x2a>
    dst += n;
 262:	00c50733          	add	a4,a0,a2
    src += n;
 266:	95b2                	add	a1,a1,a2
 268:	fff6079b          	addiw	a5,a2,-1
 26c:	1782                	slli	a5,a5,0x20
 26e:	9381                	srli	a5,a5,0x20
 270:	fff7c793          	not	a5,a5
 274:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 276:	15fd                	addi	a1,a1,-1
 278:	177d                	addi	a4,a4,-1
 27a:	0005c683          	lbu	a3,0(a1)
 27e:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 282:	fef71ae3          	bne	a4,a5,276 <memmove+0x4a>
 286:	bfc1                	j	256 <memmove+0x2a>

0000000000000288 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 288:	1141                	addi	sp,sp,-16
 28a:	e406                	sd	ra,8(sp)
 28c:	e022                	sd	s0,0(sp)
 28e:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 290:	ce19                	beqz	a2,2ae <memcmp+0x26>
 292:	1602                	slli	a2,a2,0x20
 294:	9201                	srli	a2,a2,0x20
 296:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 29a:	00054783          	lbu	a5,0(a0)
 29e:	0005c703          	lbu	a4,0(a1)
 2a2:	00e79b63          	bne	a5,a4,2b8 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 2a6:	0505                	addi	a0,a0,1
    p2++;
 2a8:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 2aa:	fed518e3          	bne	a0,a3,29a <memcmp+0x12>
  }
  return 0;
 2ae:	4501                	li	a0,0
}
 2b0:	60a2                	ld	ra,8(sp)
 2b2:	6402                	ld	s0,0(sp)
 2b4:	0141                	addi	sp,sp,16
 2b6:	8082                	ret
      return *p1 - *p2;
 2b8:	40e7853b          	subw	a0,a5,a4
 2bc:	bfd5                	j	2b0 <memcmp+0x28>

00000000000002be <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 2be:	1141                	addi	sp,sp,-16
 2c0:	e406                	sd	ra,8(sp)
 2c2:	e022                	sd	s0,0(sp)
 2c4:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 2c6:	f67ff0ef          	jal	22c <memmove>
}
 2ca:	60a2                	ld	ra,8(sp)
 2cc:	6402                	ld	s0,0(sp)
 2ce:	0141                	addi	sp,sp,16
 2d0:	8082                	ret

00000000000002d2 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 2d2:	4885                	li	a7,1
 ecall
 2d4:	00000073          	ecall
 ret
 2d8:	8082                	ret

00000000000002da <exit>:
.global exit
exit:
 li a7, SYS_exit
 2da:	4889                	li	a7,2
 ecall
 2dc:	00000073          	ecall
 ret
 2e0:	8082                	ret

00000000000002e2 <wait>:
.global wait
wait:
 li a7, SYS_wait
 2e2:	488d                	li	a7,3
 ecall
 2e4:	00000073          	ecall
 ret
 2e8:	8082                	ret

00000000000002ea <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 2ea:	4891                	li	a7,4
 ecall
 2ec:	00000073          	ecall
 ret
 2f0:	8082                	ret

00000000000002f2 <read>:
.global read
read:
 li a7, SYS_read
 2f2:	4895                	li	a7,5
 ecall
 2f4:	00000073          	ecall
 ret
 2f8:	8082                	ret

00000000000002fa <write>:
.global write
write:
 li a7, SYS_write
 2fa:	48c1                	li	a7,16
 ecall
 2fc:	00000073          	ecall
 ret
 300:	8082                	ret

0000000000000302 <close>:
.global close
close:
 li a7, SYS_close
 302:	48d5                	li	a7,21
 ecall
 304:	00000073          	ecall
 ret
 308:	8082                	ret

000000000000030a <kill>:
.global kill
kill:
 li a7, SYS_kill
 30a:	4899                	li	a7,6
 ecall
 30c:	00000073          	ecall
 ret
 310:	8082                	ret

0000000000000312 <exec>:
.global exec
exec:
 li a7, SYS_exec
 312:	489d                	li	a7,7
 ecall
 314:	00000073          	ecall
 ret
 318:	8082                	ret

000000000000031a <open>:
.global open
open:
 li a7, SYS_open
 31a:	48bd                	li	a7,15
 ecall
 31c:	00000073          	ecall
 ret
 320:	8082                	ret

0000000000000322 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 322:	48c5                	li	a7,17
 ecall
 324:	00000073          	ecall
 ret
 328:	8082                	ret

000000000000032a <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 32a:	48c9                	li	a7,18
 ecall
 32c:	00000073          	ecall
 ret
 330:	8082                	ret

0000000000000332 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 332:	48a1                	li	a7,8
 ecall
 334:	00000073          	ecall
 ret
 338:	8082                	ret

000000000000033a <link>:
.global link
link:
 li a7, SYS_link
 33a:	48cd                	li	a7,19
 ecall
 33c:	00000073          	ecall
 ret
 340:	8082                	ret

0000000000000342 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 342:	48d1                	li	a7,20
 ecall
 344:	00000073          	ecall
 ret
 348:	8082                	ret

000000000000034a <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 34a:	48a5                	li	a7,9
 ecall
 34c:	00000073          	ecall
 ret
 350:	8082                	ret

0000000000000352 <dup>:
.global dup
dup:
 li a7, SYS_dup
 352:	48a9                	li	a7,10
 ecall
 354:	00000073          	ecall
 ret
 358:	8082                	ret

000000000000035a <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 35a:	48ad                	li	a7,11
 ecall
 35c:	00000073          	ecall
 ret
 360:	8082                	ret

0000000000000362 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 362:	48b1                	li	a7,12
 ecall
 364:	00000073          	ecall
 ret
 368:	8082                	ret

000000000000036a <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 36a:	48b5                	li	a7,13
 ecall
 36c:	00000073          	ecall
 ret
 370:	8082                	ret

0000000000000372 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 372:	48b9                	li	a7,14
 ecall
 374:	00000073          	ecall
 ret
 378:	8082                	ret

000000000000037a <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 37a:	1101                	addi	sp,sp,-32
 37c:	ec06                	sd	ra,24(sp)
 37e:	e822                	sd	s0,16(sp)
 380:	1000                	addi	s0,sp,32
 382:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 386:	4605                	li	a2,1
 388:	fef40593          	addi	a1,s0,-17
 38c:	f6fff0ef          	jal	2fa <write>
}
 390:	60e2                	ld	ra,24(sp)
 392:	6442                	ld	s0,16(sp)
 394:	6105                	addi	sp,sp,32
 396:	8082                	ret

0000000000000398 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 398:	715d                	addi	sp,sp,-80
 39a:	e486                	sd	ra,72(sp)
 39c:	e0a2                	sd	s0,64(sp)
 39e:	f84a                	sd	s2,48(sp)
 3a0:	f44e                	sd	s3,40(sp)
 3a2:	0880                	addi	s0,sp,80
 3a4:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 3a6:	00d036b3          	snez	a3,a3
 3aa:	03f5d793          	srli	a5,a1,0x3f
 3ae:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 3b0:	0005871b          	sext.w	a4,a1
  neg = 0;
 3b4:	4301                	li	t1,0
  if(sgn && xx < 0){
 3b6:	c681                	beqz	a3,3be <printint+0x26>
    x = -xx;
 3b8:	40b0073b          	negw	a4,a1
    neg = 1;
 3bc:	4305                	li	t1,1
  }

  i = 0;
 3be:	fb840993          	addi	s3,s0,-72
  neg = 0;
 3c2:	85ce                	mv	a1,s3
  i = 0;
 3c4:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 3c6:	00000817          	auipc	a6,0x0
 3ca:	74a80813          	addi	a6,a6,1866 # b10 <digits>
 3ce:	88b6                	mv	a7,a3
 3d0:	0016851b          	addiw	a0,a3,1
 3d4:	86aa                	mv	a3,a0
 3d6:	02c777bb          	remuw	a5,a4,a2
 3da:	1782                	slli	a5,a5,0x20
 3dc:	9381                	srli	a5,a5,0x20
 3de:	97c2                	add	a5,a5,a6
 3e0:	0007c783          	lbu	a5,0(a5)
 3e4:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 3e8:	87ba                	mv	a5,a4
 3ea:	02c7573b          	divuw	a4,a4,a2
 3ee:	0585                	addi	a1,a1,1
 3f0:	fcc7ffe3          	bgeu	a5,a2,3ce <printint+0x36>
  if(neg)
 3f4:	00030b63          	beqz	t1,40a <printint+0x72>
    buf[i++] = '-';
 3f8:	fd040793          	addi	a5,s0,-48
 3fc:	953e                	add	a0,a0,a5
 3fe:	02d00793          	li	a5,45
 402:	fef50423          	sb	a5,-24(a0)
 406:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 40a:	02d05563          	blez	a3,434 <printint+0x9c>
 40e:	fc26                	sd	s1,56(sp)
 410:	36fd                	addiw	a3,a3,-1
 412:	00d984b3          	add	s1,s3,a3
 416:	19fd                	addi	s3,s3,-1
 418:	99b6                	add	s3,s3,a3
 41a:	1682                	slli	a3,a3,0x20
 41c:	9281                	srli	a3,a3,0x20
 41e:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 422:	0004c583          	lbu	a1,0(s1)
 426:	854a                	mv	a0,s2
 428:	f53ff0ef          	jal	37a <putc>
  while(--i >= 0)
 42c:	14fd                	addi	s1,s1,-1
 42e:	ff349ae3          	bne	s1,s3,422 <printint+0x8a>
 432:	74e2                	ld	s1,56(sp)
}
 434:	60a6                	ld	ra,72(sp)
 436:	6406                	ld	s0,64(sp)
 438:	7942                	ld	s2,48(sp)
 43a:	79a2                	ld	s3,40(sp)
 43c:	6161                	addi	sp,sp,80
 43e:	8082                	ret

0000000000000440 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 440:	711d                	addi	sp,sp,-96
 442:	ec86                	sd	ra,88(sp)
 444:	e8a2                	sd	s0,80(sp)
 446:	e4a6                	sd	s1,72(sp)
 448:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 44a:	0005c483          	lbu	s1,0(a1)
 44e:	28048263          	beqz	s1,6d2 <vprintf+0x292>
 452:	e0ca                	sd	s2,64(sp)
 454:	fc4e                	sd	s3,56(sp)
 456:	f852                	sd	s4,48(sp)
 458:	f456                	sd	s5,40(sp)
 45a:	f05a                	sd	s6,32(sp)
 45c:	ec5e                	sd	s7,24(sp)
 45e:	e862                	sd	s8,16(sp)
 460:	8b2a                	mv	s6,a0
 462:	8a2e                	mv	s4,a1
 464:	8bb2                	mv	s7,a2
  state = 0;
 466:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 468:	4901                	li	s2,0
 46a:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 46c:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 470:	06400c13          	li	s8,100
 474:	a00d                	j	496 <vprintf+0x56>
        putc(fd, c0);
 476:	85a6                	mv	a1,s1
 478:	855a                	mv	a0,s6
 47a:	f01ff0ef          	jal	37a <putc>
 47e:	a019                	j	484 <vprintf+0x44>
    } else if(state == '%'){
 480:	03598363          	beq	s3,s5,4a6 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 484:	0019079b          	addiw	a5,s2,1
 488:	893e                	mv	s2,a5
 48a:	873e                	mv	a4,a5
 48c:	97d2                	add	a5,a5,s4
 48e:	0007c483          	lbu	s1,0(a5)
 492:	22048963          	beqz	s1,6c4 <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 496:	0004879b          	sext.w	a5,s1
    if(state == 0){
 49a:	fe0993e3          	bnez	s3,480 <vprintf+0x40>
      if(c0 == '%'){
 49e:	fd579ce3          	bne	a5,s5,476 <vprintf+0x36>
        state = '%';
 4a2:	89be                	mv	s3,a5
 4a4:	b7c5                	j	484 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 4a6:	00ea06b3          	add	a3,s4,a4
 4aa:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 4ae:	22060763          	beqz	a2,6dc <vprintf+0x29c>
      if(c0 == 'd'){
 4b2:	0b878363          	beq	a5,s8,558 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 4b6:	f9478693          	addi	a3,a5,-108
 4ba:	0016b693          	seqz	a3,a3
 4be:	f9c60593          	addi	a1,a2,-100
 4c2:	0015b593          	seqz	a1,a1
 4c6:	8df5                	and	a1,a1,a3
 4c8:	e5c5                	bnez	a1,570 <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 4ca:	9752                	add	a4,a4,s4
 4cc:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 4d0:	f9460713          	addi	a4,a2,-108
 4d4:	00173713          	seqz	a4,a4
 4d8:	8f75                	and	a4,a4,a3
 4da:	f9c50593          	addi	a1,a0,-100
 4de:	0015b593          	seqz	a1,a1
 4e2:	8df9                	and	a1,a1,a4
 4e4:	e1dd                	bnez	a1,58a <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 4e6:	07500593          	li	a1,117
 4ea:	0ab78d63          	beq	a5,a1,5a4 <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 4ee:	f8b60593          	addi	a1,a2,-117
 4f2:	0015b593          	seqz	a1,a1
 4f6:	8df5                	and	a1,a1,a3
 4f8:	e1f1                	bnez	a1,5bc <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 4fa:	f8b50593          	addi	a1,a0,-117
 4fe:	0015b593          	seqz	a1,a1
 502:	8df9                	and	a1,a1,a4
 504:	e9e9                	bnez	a1,5d6 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 506:	07800593          	li	a1,120
 50a:	0eb78363          	beq	a5,a1,5f0 <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 50e:	f8860613          	addi	a2,a2,-120
 512:	00163613          	seqz	a2,a2
 516:	8ef1                	and	a3,a3,a2
 518:	0e069863          	bnez	a3,608 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 51c:	f8850513          	addi	a0,a0,-120
 520:	00153513          	seqz	a0,a0
 524:	8f69                	and	a4,a4,a0
 526:	0e071e63          	bnez	a4,622 <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 52a:	07000713          	li	a4,112
 52e:	10e78663          	beq	a5,a4,63a <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 532:	07300713          	li	a4,115
 536:	14e78663          	beq	a5,a4,682 <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 53a:	02500713          	li	a4,37
 53e:	16e78e63          	beq	a5,a4,6ba <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 542:	02500593          	li	a1,37
 546:	855a                	mv	a0,s6
 548:	e33ff0ef          	jal	37a <putc>
        putc(fd, c0);
 54c:	85a6                	mv	a1,s1
 54e:	855a                	mv	a0,s6
 550:	e2bff0ef          	jal	37a <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 554:	4981                	li	s3,0
 556:	b73d                	j	484 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 558:	008b8493          	addi	s1,s7,8
 55c:	4685                	li	a3,1
 55e:	4629                	li	a2,10
 560:	000ba583          	lw	a1,0(s7)
 564:	855a                	mv	a0,s6
 566:	e33ff0ef          	jal	398 <printint>
 56a:	8ba6                	mv	s7,s1
      state = 0;
 56c:	4981                	li	s3,0
 56e:	bf19                	j	484 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 570:	008b8493          	addi	s1,s7,8
 574:	4685                	li	a3,1
 576:	4629                	li	a2,10
 578:	000bb583          	ld	a1,0(s7)
 57c:	855a                	mv	a0,s6
 57e:	e1bff0ef          	jal	398 <printint>
        i += 1;
 582:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 584:	8ba6                	mv	s7,s1
      state = 0;
 586:	4981                	li	s3,0
 588:	bdf5                	j	484 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 58a:	008b8493          	addi	s1,s7,8
 58e:	4685                	li	a3,1
 590:	4629                	li	a2,10
 592:	000bb583          	ld	a1,0(s7)
 596:	855a                	mv	a0,s6
 598:	e01ff0ef          	jal	398 <printint>
        i += 2;
 59c:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 59e:	8ba6                	mv	s7,s1
      state = 0;
 5a0:	4981                	li	s3,0
        i += 2;
 5a2:	b5cd                	j	484 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 5a4:	008b8493          	addi	s1,s7,8
 5a8:	4681                	li	a3,0
 5aa:	4629                	li	a2,10
 5ac:	000ba583          	lw	a1,0(s7)
 5b0:	855a                	mv	a0,s6
 5b2:	de7ff0ef          	jal	398 <printint>
 5b6:	8ba6                	mv	s7,s1
      state = 0;
 5b8:	4981                	li	s3,0
 5ba:	b5e9                	j	484 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 5bc:	008b8493          	addi	s1,s7,8
 5c0:	4681                	li	a3,0
 5c2:	4629                	li	a2,10
 5c4:	000bb583          	ld	a1,0(s7)
 5c8:	855a                	mv	a0,s6
 5ca:	dcfff0ef          	jal	398 <printint>
        i += 1;
 5ce:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 5d0:	8ba6                	mv	s7,s1
      state = 0;
 5d2:	4981                	li	s3,0
 5d4:	bd45                	j	484 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 5d6:	008b8493          	addi	s1,s7,8
 5da:	4681                	li	a3,0
 5dc:	4629                	li	a2,10
 5de:	000bb583          	ld	a1,0(s7)
 5e2:	855a                	mv	a0,s6
 5e4:	db5ff0ef          	jal	398 <printint>
        i += 2;
 5e8:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 5ea:	8ba6                	mv	s7,s1
      state = 0;
 5ec:	4981                	li	s3,0
        i += 2;
 5ee:	bd59                	j	484 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 5f0:	008b8493          	addi	s1,s7,8
 5f4:	4681                	li	a3,0
 5f6:	4641                	li	a2,16
 5f8:	000ba583          	lw	a1,0(s7)
 5fc:	855a                	mv	a0,s6
 5fe:	d9bff0ef          	jal	398 <printint>
 602:	8ba6                	mv	s7,s1
      state = 0;
 604:	4981                	li	s3,0
 606:	bdbd                	j	484 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 608:	008b8493          	addi	s1,s7,8
 60c:	4681                	li	a3,0
 60e:	4641                	li	a2,16
 610:	000bb583          	ld	a1,0(s7)
 614:	855a                	mv	a0,s6
 616:	d83ff0ef          	jal	398 <printint>
        i += 1;
 61a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 61c:	8ba6                	mv	s7,s1
      state = 0;
 61e:	4981                	li	s3,0
 620:	b595                	j	484 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 622:	008b8493          	addi	s1,s7,8
 626:	4641                	li	a2,16
 628:	000bb583          	ld	a1,0(s7)
 62c:	855a                	mv	a0,s6
 62e:	d6bff0ef          	jal	398 <printint>
        i += 2;
 632:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 634:	8ba6                	mv	s7,s1
      state = 0;
 636:	4981                	li	s3,0
        i += 2;
 638:	b5b1                	j	484 <vprintf+0x44>
 63a:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 63c:	008b8793          	addi	a5,s7,8
 640:	8cbe                	mv	s9,a5
 642:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 646:	03000593          	li	a1,48
 64a:	855a                	mv	a0,s6
 64c:	d2fff0ef          	jal	37a <putc>
  putc(fd, 'x');
 650:	07800593          	li	a1,120
 654:	855a                	mv	a0,s6
 656:	d25ff0ef          	jal	37a <putc>
 65a:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 65c:	00000b97          	auipc	s7,0x0
 660:	4b4b8b93          	addi	s7,s7,1204 # b10 <digits>
 664:	03c9d793          	srli	a5,s3,0x3c
 668:	97de                	add	a5,a5,s7
 66a:	0007c583          	lbu	a1,0(a5)
 66e:	855a                	mv	a0,s6
 670:	d0bff0ef          	jal	37a <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 674:	0992                	slli	s3,s3,0x4
 676:	34fd                	addiw	s1,s1,-1
 678:	f4f5                	bnez	s1,664 <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 67a:	8be6                	mv	s7,s9
      state = 0;
 67c:	4981                	li	s3,0
 67e:	6ca2                	ld	s9,8(sp)
 680:	b511                	j	484 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 682:	008b8993          	addi	s3,s7,8
 686:	000bb483          	ld	s1,0(s7)
 68a:	cc91                	beqz	s1,6a6 <vprintf+0x266>
        for(; *s; s++)
 68c:	0004c583          	lbu	a1,0(s1)
 690:	c195                	beqz	a1,6b4 <vprintf+0x274>
          putc(fd, *s);
 692:	855a                	mv	a0,s6
 694:	ce7ff0ef          	jal	37a <putc>
        for(; *s; s++)
 698:	0485                	addi	s1,s1,1
 69a:	0004c583          	lbu	a1,0(s1)
 69e:	f9f5                	bnez	a1,692 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 6a0:	8bce                	mv	s7,s3
      state = 0;
 6a2:	4981                	li	s3,0
 6a4:	b3c5                	j	484 <vprintf+0x44>
          s = "(null)";
 6a6:	00000497          	auipc	s1,0x0
 6aa:	43a48493          	addi	s1,s1,1082 # ae0 <thread_switch+0xa4>
        for(; *s; s++)
 6ae:	02800593          	li	a1,40
 6b2:	b7c5                	j	692 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 6b4:	8bce                	mv	s7,s3
      state = 0;
 6b6:	4981                	li	s3,0
 6b8:	b3f1                	j	484 <vprintf+0x44>
        putc(fd, '%');
 6ba:	85be                	mv	a1,a5
 6bc:	855a                	mv	a0,s6
 6be:	cbdff0ef          	jal	37a <putc>
 6c2:	bd49                	j	554 <vprintf+0x114>
 6c4:	6906                	ld	s2,64(sp)
 6c6:	79e2                	ld	s3,56(sp)
 6c8:	7a42                	ld	s4,48(sp)
 6ca:	7aa2                	ld	s5,40(sp)
 6cc:	7b02                	ld	s6,32(sp)
 6ce:	6be2                	ld	s7,24(sp)
 6d0:	6c42                	ld	s8,16(sp)
    }
  }
}
 6d2:	60e6                	ld	ra,88(sp)
 6d4:	6446                	ld	s0,80(sp)
 6d6:	64a6                	ld	s1,72(sp)
 6d8:	6125                	addi	sp,sp,96
 6da:	8082                	ret
      if(c0 == 'd'){
 6dc:	06400713          	li	a4,100
 6e0:	e6e78ce3          	beq	a5,a4,558 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 6e4:	f9478693          	addi	a3,a5,-108
 6e8:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 6ec:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 6ee:	4701                	li	a4,0
 6f0:	bbdd                	j	4e6 <vprintf+0xa6>

00000000000006f2 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 6f2:	715d                	addi	sp,sp,-80
 6f4:	ec06                	sd	ra,24(sp)
 6f6:	e822                	sd	s0,16(sp)
 6f8:	1000                	addi	s0,sp,32
 6fa:	e010                	sd	a2,0(s0)
 6fc:	e414                	sd	a3,8(s0)
 6fe:	e818                	sd	a4,16(s0)
 700:	ec1c                	sd	a5,24(s0)
 702:	03043023          	sd	a6,32(s0)
 706:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 70a:	8622                	mv	a2,s0
 70c:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 710:	d31ff0ef          	jal	440 <vprintf>
}
 714:	60e2                	ld	ra,24(sp)
 716:	6442                	ld	s0,16(sp)
 718:	6161                	addi	sp,sp,80
 71a:	8082                	ret

000000000000071c <printf>:

void
printf(const char *fmt, ...)
{
 71c:	711d                	addi	sp,sp,-96
 71e:	ec06                	sd	ra,24(sp)
 720:	e822                	sd	s0,16(sp)
 722:	1000                	addi	s0,sp,32
 724:	e40c                	sd	a1,8(s0)
 726:	e810                	sd	a2,16(s0)
 728:	ec14                	sd	a3,24(s0)
 72a:	f018                	sd	a4,32(s0)
 72c:	f41c                	sd	a5,40(s0)
 72e:	03043823          	sd	a6,48(s0)
 732:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 736:	00840613          	addi	a2,s0,8
 73a:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 73e:	85aa                	mv	a1,a0
 740:	4505                	li	a0,1
 742:	cffff0ef          	jal	440 <vprintf>
}
 746:	60e2                	ld	ra,24(sp)
 748:	6442                	ld	s0,16(sp)
 74a:	6125                	addi	sp,sp,96
 74c:	8082                	ret

000000000000074e <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 74e:	1141                	addi	sp,sp,-16
 750:	e406                	sd	ra,8(sp)
 752:	e022                	sd	s0,0(sp)
 754:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 756:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 75a:	00001797          	auipc	a5,0x1
 75e:	8a67b783          	ld	a5,-1882(a5) # 1000 <freep>
 762:	a095                	j	7c6 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 764:	ff852583          	lw	a1,-8(a0)
 768:	6390                	ld	a2,0(a5)
 76a:	02059813          	slli	a6,a1,0x20
 76e:	01c85693          	srli	a3,a6,0x1c
 772:	96ba                	add	a3,a3,a4
 774:	02d60563          	beq	a2,a3,79e <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 778:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 77c:	4790                	lw	a2,8(a5)
 77e:	02061593          	slli	a1,a2,0x20
 782:	01c5d693          	srli	a3,a1,0x1c
 786:	96be                	add	a3,a3,a5
 788:	02d70263          	beq	a4,a3,7ac <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 78c:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 78e:	00001717          	auipc	a4,0x1
 792:	86f73923          	sd	a5,-1934(a4) # 1000 <freep>
}
 796:	60a2                	ld	ra,8(sp)
 798:	6402                	ld	s0,0(sp)
 79a:	0141                	addi	sp,sp,16
 79c:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 79e:	4614                	lw	a3,8(a2)
 7a0:	9ead                	addw	a3,a3,a1
 7a2:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 7a6:	6394                	ld	a3,0(a5)
 7a8:	6290                	ld	a2,0(a3)
 7aa:	b7f9                	j	778 <free+0x2a>
    p->s.size += bp->s.size;
 7ac:	ff852703          	lw	a4,-8(a0)
 7b0:	9f31                	addw	a4,a4,a2
 7b2:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 7b4:	ff053703          	ld	a4,-16(a0)
 7b8:	bfd1                	j	78c <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 7ba:	6394                	ld	a3,0(a5)
 7bc:	00d7e463          	bltu	a5,a3,7c4 <free+0x76>
 7c0:	fad762e3          	bltu	a4,a3,764 <free+0x16>
 7c4:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 7c6:	fee7fae3          	bgeu	a5,a4,7ba <free+0x6c>
 7ca:	6394                	ld	a3,0(a5)
 7cc:	f8d76ce3          	bltu	a4,a3,764 <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 7d0:	f8d7fae3          	bgeu	a5,a3,764 <free+0x16>
 7d4:	87b6                	mv	a5,a3
 7d6:	bfc5                	j	7c6 <free+0x78>

00000000000007d8 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 7d8:	7139                	addi	sp,sp,-64
 7da:	fc06                	sd	ra,56(sp)
 7dc:	f822                	sd	s0,48(sp)
 7de:	f04a                	sd	s2,32(sp)
 7e0:	ec4e                	sd	s3,24(sp)
 7e2:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 7e4:	02051993          	slli	s3,a0,0x20
 7e8:	0209d993          	srli	s3,s3,0x20
 7ec:	09bd                	addi	s3,s3,15
 7ee:	0049d993          	srli	s3,s3,0x4
 7f2:	2985                	addiw	s3,s3,1
 7f4:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 7f6:	00001517          	auipc	a0,0x1
 7fa:	80a53503          	ld	a0,-2038(a0) # 1000 <freep>
 7fe:	c905                	beqz	a0,82e <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 800:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 802:	4798                	lw	a4,8(a5)
 804:	09377663          	bgeu	a4,s3,890 <malloc+0xb8>
 808:	f426                	sd	s1,40(sp)
 80a:	e852                	sd	s4,16(sp)
 80c:	e456                	sd	s5,8(sp)
 80e:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 810:	8a4e                	mv	s4,s3
 812:	6705                	lui	a4,0x1
 814:	00e9f363          	bgeu	s3,a4,81a <malloc+0x42>
 818:	6a05                	lui	s4,0x1
 81a:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 81e:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 822:	00000497          	auipc	s1,0x0
 826:	7de48493          	addi	s1,s1,2014 # 1000 <freep>
  if(p == (char*)-1)
 82a:	5afd                	li	s5,-1
 82c:	a83d                	j	86a <malloc+0x92>
 82e:	f426                	sd	s1,40(sp)
 830:	e852                	sd	s4,16(sp)
 832:	e456                	sd	s5,8(sp)
 834:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 836:	00000797          	auipc	a5,0x0
 83a:	7da78793          	addi	a5,a5,2010 # 1010 <base>
 83e:	00000717          	auipc	a4,0x0
 842:	7cf73123          	sd	a5,1986(a4) # 1000 <freep>
 846:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 848:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 84c:	b7d1                	j	810 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 84e:	6398                	ld	a4,0(a5)
 850:	e118                	sd	a4,0(a0)
 852:	a899                	j	8a8 <malloc+0xd0>
  hp->s.size = nu;
 854:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 858:	0541                	addi	a0,a0,16
 85a:	ef5ff0ef          	jal	74e <free>
  return freep;
 85e:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 860:	c125                	beqz	a0,8c0 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 862:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 864:	4798                	lw	a4,8(a5)
 866:	03277163          	bgeu	a4,s2,888 <malloc+0xb0>
    if(p == freep)
 86a:	6098                	ld	a4,0(s1)
 86c:	853e                	mv	a0,a5
 86e:	fef71ae3          	bne	a4,a5,862 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 872:	8552                	mv	a0,s4
 874:	aefff0ef          	jal	362 <sbrk>
  if(p == (char*)-1)
 878:	fd551ee3          	bne	a0,s5,854 <malloc+0x7c>
        return 0;
 87c:	4501                	li	a0,0
 87e:	74a2                	ld	s1,40(sp)
 880:	6a42                	ld	s4,16(sp)
 882:	6aa2                	ld	s5,8(sp)
 884:	6b02                	ld	s6,0(sp)
 886:	a03d                	j	8b4 <malloc+0xdc>
 888:	74a2                	ld	s1,40(sp)
 88a:	6a42                	ld	s4,16(sp)
 88c:	6aa2                	ld	s5,8(sp)
 88e:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 890:	fae90fe3          	beq	s2,a4,84e <malloc+0x76>
        p->s.size -= nunits;
 894:	4137073b          	subw	a4,a4,s3
 898:	c798                	sw	a4,8(a5)
        p += p->s.size;
 89a:	02071693          	slli	a3,a4,0x20
 89e:	01c6d713          	srli	a4,a3,0x1c
 8a2:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 8a4:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 8a8:	00000717          	auipc	a4,0x0
 8ac:	74a73c23          	sd	a0,1880(a4) # 1000 <freep>
      return (void*)(p + 1);
 8b0:	01078513          	addi	a0,a5,16
  }
}
 8b4:	70e2                	ld	ra,56(sp)
 8b6:	7442                	ld	s0,48(sp)
 8b8:	7902                	ld	s2,32(sp)
 8ba:	69e2                	ld	s3,24(sp)
 8bc:	6121                	addi	sp,sp,64
 8be:	8082                	ret
 8c0:	74a2                	ld	s1,40(sp)
 8c2:	6a42                	ld	s4,16(sp)
 8c4:	6aa2                	ld	s5,8(sp)
 8c6:	6b02                	ld	s6,0(sp)
 8c8:	b7f5                	j	8b4 <malloc+0xdc>

00000000000008ca <thread_init>:
struct thread *current_thread;
extern void thread_switch(uint64, uint64);
              
void 
thread_init(void)
{
 8ca:	1141                	addi	sp,sp,-16
 8cc:	e406                	sd	ra,8(sp)
 8ce:	e022                	sd	s0,0(sp)
 8d0:	0800                	addi	s0,sp,16
  // main() is thread 0, which will make the first invocation to
  // thread_schedule(). It needs a stack so that the first thread_switch() can
  // save thread 0's state.
  current_thread = &all_thread[0];
 8d2:	00000797          	auipc	a5,0x0
 8d6:	74e78793          	addi	a5,a5,1870 # 1020 <all_thread>
 8da:	00000717          	auipc	a4,0x0
 8de:	72f73723          	sd	a5,1838(a4) # 1008 <current_thread>
  current_thread->state = RUNNING;
 8e2:	00002717          	auipc	a4,0x2
 8e6:	73e70713          	addi	a4,a4,1854 # 3020 <all_thread+0x2000>
 8ea:	4785                	li	a5,1
 8ec:	c31c                	sw	a5,0(a4)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 8ee:	00002797          	auipc	a5,0x2
 8f2:	6c278793          	addi	a5,a5,1730 # 2fb0 <all_thread+0x1f90>
  return (struct context *)(top & ~(uint64)0xf);
 8f6:	9bc1                	andi	a5,a5,-16
  // Thread 0 runs on the process's own stack, but the first thread_switch()
  // still needs a writable place to save its context.
  current_thread->context = thread_context_slot(current_thread);
 8f8:	e71c                	sd	a5,8(a4)
}
 8fa:	60a2                	ld	ra,8(sp)
 8fc:	6402                	ld	s0,0(sp)
 8fe:	0141                	addi	sp,sp,16
 900:	8082                	ret

0000000000000902 <thread_schedule>:

void 
thread_schedule(void)
{
 902:	1141                	addi	sp,sp,-16
 904:	e406                	sd	ra,8(sp)
 906:	e022                	sd	s0,0(sp)
 908:	0800                	addi	s0,sp,16
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
 90a:	00000597          	auipc	a1,0x0
 90e:	6fe5b583          	ld	a1,1790(a1) # 1008 <current_thread>
 912:	6789                	lui	a5,0x2
 914:	07c1                	addi	a5,a5,16 # 2010 <all_thread+0xff0>
 916:	97ae                	add	a5,a5,a1
 918:	4711                	li	a4,4
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
 91a:	00008897          	auipc	a7,0x8
 91e:	74688893          	addi	a7,a7,1862 # 9060 <all_thread+0x8040>
      t = all_thread;
    if(t->state == RUNNABLE) {
 922:	6809                	lui	a6,0x2
 924:	4509                	li	a0,2
      next_thread = t;
      break;
    }
    t = t + 1;
 926:	01080613          	addi	a2,a6,16 # 2010 <all_thread+0xff0>
 92a:	a809                	j	93c <thread_schedule+0x3a>
    if(t->state == RUNNABLE) {
 92c:	010786b3          	add	a3,a5,a6
 930:	4294                	lw	a3,0(a3)
 932:	02a68563          	beq	a3,a0,95c <thread_schedule+0x5a>
    t = t + 1;
 936:	97b2                	add	a5,a5,a2
  for(int i = 0; i < MAX_THREAD; i++){
 938:	377d                	addiw	a4,a4,-1
 93a:	cb01                	beqz	a4,94a <thread_schedule+0x48>
    if(t >= all_thread + MAX_THREAD)
 93c:	ff17e8e3          	bltu	a5,a7,92c <thread_schedule+0x2a>
      t = all_thread;
 940:	00000797          	auipc	a5,0x0
 944:	6e078793          	addi	a5,a5,1760 # 1020 <all_thread>
 948:	b7d5                	j	92c <thread_schedule+0x2a>
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
 94a:	00000517          	auipc	a0,0x0
 94e:	19e50513          	addi	a0,a0,414 # ae8 <thread_switch+0xac>
 952:	dcbff0ef          	jal	71c <printf>
    exit(-1);
 956:	557d                	li	a0,-1
 958:	983ff0ef          	jal	2da <exit>
  }

  if (current_thread != next_thread) {         /* switch threads?  */
 95c:	02f58163          	beq	a1,a5,97e <thread_schedule+0x7c>
    next_thread->state = RUNNING;
 960:	6689                	lui	a3,0x2
 962:	00d78733          	add	a4,a5,a3
 966:	4605                	li	a2,1
 968:	c310                	sw	a2,0(a4)
    t = current_thread;
    current_thread = next_thread;
 96a:	00000617          	auipc	a2,0x0
 96e:	68f63f23          	sd	a5,1694(a2) # 1008 <current_thread>
    thread_switch((uint64)t->context, (uint64)next_thread->context);
 972:	00d587b3          	add	a5,a1,a3
 976:	670c                	ld	a1,8(a4)
 978:	6788                	ld	a0,8(a5)
 97a:	0c2000ef          	jal	a3c <thread_switch>
  } else
    next_thread = 0;
}
 97e:	60a2                	ld	ra,8(sp)
 980:	6402                	ld	s0,0(sp)
 982:	0141                	addi	sp,sp,16
 984:	8082                	ret

0000000000000986 <thread_create>:

void 
thread_create(void (*func)())
{
 986:	1101                	addi	sp,sp,-32
 988:	ec06                	sd	ra,24(sp)
 98a:	e822                	sd	s0,16(sp)
 98c:	e426                	sd	s1,8(sp)
 98e:	e04a                	sd	s2,0(sp)
 990:	1000                	addi	s0,sp,32
 992:	892a                	mv	s2,a0
  struct thread *t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 994:	00002797          	auipc	a5,0x2
 998:	69c78793          	addi	a5,a5,1692 # 3030 <all_thread+0x2010>
 99c:	0000a597          	auipc	a1,0xa
 9a0:	6d458593          	addi	a1,a1,1748 # b070 <all_thread+0xa050>
 9a4:	6609                	lui	a2,0x2
 9a6:	0641                	addi	a2,a2,16 # 2010 <all_thread+0xff0>
    if (t->state == FREE) break;
 9a8:	873e                	mv	a4,a5
 9aa:	ff07a683          	lw	a3,-16(a5)
 9ae:	ce9d                	beqz	a3,9ec <thread_create+0x66>
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 9b0:	97b2                	add	a5,a5,a2
 9b2:	feb79be3          	bne	a5,a1,9a8 <thread_create+0x22>
  }
  t->state = RUNNABLE;
 9b6:	6489                	lui	s1,0x2
 9b8:	94ba                	add	s1,s1,a4
 9ba:	4789                	li	a5,2
 9bc:	c09c                	sw	a5,0(s1)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 9be:	6789                	lui	a5,0x2
 9c0:	f9078793          	addi	a5,a5,-112 # 1f90 <all_thread+0xf70>
 9c4:	973e                	add	a4,a4,a5
  return (struct context *)(top & ~(uint64)0xf);
 9c6:	ff077513          	andi	a0,a4,-16
  // A never-run thread has no saved state, so construct one: thread_switch()
  // restores ra and sp, and `ret` then starts func on this thread's own stack.
  t->context = thread_context_slot(t);
 9ca:	e488                	sd	a0,8(s1)
  memset(t->context, 0, sizeof(struct context));
 9cc:	07000613          	li	a2,112
 9d0:	4581                	li	a1,0
 9d2:	f0aff0ef          	jal	dc <memset>
  t->context->ra = (uint64)func;
 9d6:	649c                	ld	a5,8(s1)
 9d8:	0127b023          	sd	s2,0(a5)
  t->context->sp = (uint64)t->context;   // 16-byte aligned, grows down
 9dc:	649c                	ld	a5,8(s1)
 9de:	e79c                	sd	a5,8(a5)
}
 9e0:	60e2                	ld	ra,24(sp)
 9e2:	6442                	ld	s0,16(sp)
 9e4:	64a2                	ld	s1,8(sp)
 9e6:	6902                	ld	s2,0(sp)
 9e8:	6105                	addi	sp,sp,32
 9ea:	8082                	ret
 9ec:	7779                	lui	a4,0xffffe
 9ee:	1741                	addi	a4,a4,-16 # ffffffffffffdff0 <all_thread+0xffffffffffffcfd0>
 9f0:	973e                	add	a4,a4,a5
 9f2:	b7d1                	j	9b6 <thread_create+0x30>

00000000000009f4 <thread_yield>:

void 
thread_yield(void)
{
 9f4:	1141                	addi	sp,sp,-16
 9f6:	e406                	sd	ra,8(sp)
 9f8:	e022                	sd	s0,0(sp)
 9fa:	0800                	addi	s0,sp,16
  current_thread->state = RUNNABLE;
 9fc:	00000797          	auipc	a5,0x0
 a00:	60c7b783          	ld	a5,1548(a5) # 1008 <current_thread>
 a04:	6709                	lui	a4,0x2
 a06:	97ba                	add	a5,a5,a4
 a08:	4709                	li	a4,2
 a0a:	c398                	sw	a4,0(a5)
  thread_schedule();
 a0c:	ef7ff0ef          	jal	902 <thread_schedule>
}
 a10:	60a2                	ld	ra,8(sp)
 a12:	6402                	ld	s0,0(sp)
 a14:	0141                	addi	sp,sp,16
 a16:	8082                	ret

0000000000000a18 <thread_exit>:

void thread_exit(void) {
 a18:	1141                	addi	sp,sp,-16
 a1a:	e406                	sd	ra,8(sp)
 a1c:	e022                	sd	s0,0(sp)
 a1e:	0800                	addi	s0,sp,16
  current_thread->state = FREE;
 a20:	00000797          	auipc	a5,0x0
 a24:	5e87b783          	ld	a5,1512(a5) # 1008 <current_thread>
 a28:	6709                	lui	a4,0x2
 a2a:	97ba                	add	a5,a5,a4
 a2c:	0007a023          	sw	zero,0(a5)
  thread_schedule();
 a30:	ed3ff0ef          	jal	902 <thread_schedule>
}
 a34:	60a2                	ld	ra,8(sp)
 a36:	6402                	ld	s0,0(sp)
 a38:	0141                	addi	sp,sp,16
 a3a:	8082                	ret

0000000000000a3c <thread_switch>:
 a3c:	00153023          	sd	ra,0(a0)
 a40:	00253423          	sd	sp,8(a0)
 a44:	e900                	sd	s0,16(a0)
 a46:	ed04                	sd	s1,24(a0)
 a48:	03253023          	sd	s2,32(a0)
 a4c:	03353423          	sd	s3,40(a0)
 a50:	03453823          	sd	s4,48(a0)
 a54:	03553c23          	sd	s5,56(a0)
 a58:	05653023          	sd	s6,64(a0)
 a5c:	05753423          	sd	s7,72(a0)
 a60:	05853823          	sd	s8,80(a0)
 a64:	05953c23          	sd	s9,88(a0)
 a68:	07a53023          	sd	s10,96(a0)
 a6c:	07b53423          	sd	s11,104(a0)
 a70:	0005b083          	ld	ra,0(a1)
 a74:	0085b103          	ld	sp,8(a1)
 a78:	6980                	ld	s0,16(a1)
 a7a:	6d84                	ld	s1,24(a1)
 a7c:	0205b903          	ld	s2,32(a1)
 a80:	0285b983          	ld	s3,40(a1)
 a84:	0305ba03          	ld	s4,48(a1)
 a88:	0385ba83          	ld	s5,56(a1)
 a8c:	0405bb03          	ld	s6,64(a1)
 a90:	0485bb83          	ld	s7,72(a1)
 a94:	0505bc03          	ld	s8,80(a1)
 a98:	0585bc83          	ld	s9,88(a1)
 a9c:	0605bd03          	ld	s10,96(a1)
 aa0:	0685bd83          	ld	s11,104(a1)
 aa4:	8082                	ret
