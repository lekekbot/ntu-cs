
user/_uthread_test:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <thread_a>:
volatile int a_started, b_started, c_started;
volatile int a_n, b_n, c_n;

void 
thread_a(void)
{
   0:	7179                	addi	sp,sp,-48
   2:	f406                	sd	ra,40(sp)
   4:	f022                	sd	s0,32(sp)
   6:	ec26                	sd	s1,24(sp)
   8:	e84a                	sd	s2,16(sp)
   a:	e44e                	sd	s3,8(sp)
   c:	e052                	sd	s4,0(sp)
   e:	1800                	addi	s0,sp,48
  int i;
  printf("thread_a started\n");
  10:	00001517          	auipc	a0,0x1
  14:	ca050513          	addi	a0,a0,-864 # cb0 <thread_switch+0x78>
  18:	101000ef          	jal	918 <printf>
  a_started = 1;
  1c:	4785                	li	a5,1
  1e:	00001717          	auipc	a4,0x1
  22:	fef72b23          	sw	a5,-10(a4) # 1014 <a_started>
  while(b_started == 0 || c_started == 0)
  26:	00001497          	auipc	s1,0x1
  2a:	fea48493          	addi	s1,s1,-22 # 1010 <b_started>
  2e:	00001917          	auipc	s2,0x1
  32:	fde90913          	addi	s2,s2,-34 # 100c <c_started>
  36:	a019                	j	3c <thread_a+0x3c>
    thread_yield();
  38:	3b9000ef          	jal	bf0 <thread_yield>
  while(b_started == 0 || c_started == 0)
  3c:	409c                	lw	a5,0(s1)
  3e:	dfed                	beqz	a5,38 <thread_a+0x38>
  40:	00092783          	lw	a5,0(s2)
  44:	dbf5                	beqz	a5,38 <thread_a+0x38>
  
  for (i = 0; i < 100; i++) {
  46:	4481                	li	s1,0
    printf("thread_a %d\n", i);
  48:	00001a17          	auipc	s4,0x1
  4c:	c80a0a13          	addi	s4,s4,-896 # cc8 <thread_switch+0x90>
    a_n += 1;
  50:	00001917          	auipc	s2,0x1
  54:	fb890913          	addi	s2,s2,-72 # 1008 <a_n>
  for (i = 0; i < 100; i++) {
  58:	06400993          	li	s3,100
    printf("thread_a %d\n", i);
  5c:	85a6                	mv	a1,s1
  5e:	8552                	mv	a0,s4
  60:	0b9000ef          	jal	918 <printf>
    a_n += 1;
  64:	00092783          	lw	a5,0(s2)
  68:	2785                	addiw	a5,a5,1
  6a:	00f92023          	sw	a5,0(s2)
    thread_yield();
  6e:	383000ef          	jal	bf0 <thread_yield>
  for (i = 0; i < 100; i++) {
  72:	2485                	addiw	s1,s1,1
  74:	ff3494e3          	bne	s1,s3,5c <thread_a+0x5c>
  }
  printf("thread_a: exit after %d\n", a_n);
  78:	00001597          	auipc	a1,0x1
  7c:	f905a583          	lw	a1,-112(a1) # 1008 <a_n>
  80:	00001517          	auipc	a0,0x1
  84:	c5850513          	addi	a0,a0,-936 # cd8 <thread_switch+0xa0>
  88:	091000ef          	jal	918 <printf>

  thread_exit();
  8c:	389000ef          	jal	c14 <thread_exit>
}
  90:	70a2                	ld	ra,40(sp)
  92:	7402                	ld	s0,32(sp)
  94:	64e2                	ld	s1,24(sp)
  96:	6942                	ld	s2,16(sp)
  98:	69a2                	ld	s3,8(sp)
  9a:	6a02                	ld	s4,0(sp)
  9c:	6145                	addi	sp,sp,48
  9e:	8082                	ret

00000000000000a0 <thread_b>:

void 
thread_b(void)
{
  a0:	7179                	addi	sp,sp,-48
  a2:	f406                	sd	ra,40(sp)
  a4:	f022                	sd	s0,32(sp)
  a6:	ec26                	sd	s1,24(sp)
  a8:	e84a                	sd	s2,16(sp)
  aa:	e44e                	sd	s3,8(sp)
  ac:	e052                	sd	s4,0(sp)
  ae:	1800                	addi	s0,sp,48
  int i;
  printf("thread_b started\n");
  b0:	00001517          	auipc	a0,0x1
  b4:	c4850513          	addi	a0,a0,-952 # cf8 <thread_switch+0xc0>
  b8:	061000ef          	jal	918 <printf>
  b_started = 1;
  bc:	4785                	li	a5,1
  be:	00001717          	auipc	a4,0x1
  c2:	f4f72923          	sw	a5,-174(a4) # 1010 <b_started>
  while(a_started == 0 || c_started == 0)
  c6:	00001497          	auipc	s1,0x1
  ca:	f4e48493          	addi	s1,s1,-178 # 1014 <a_started>
  ce:	00001917          	auipc	s2,0x1
  d2:	f3e90913          	addi	s2,s2,-194 # 100c <c_started>
  d6:	a019                	j	dc <thread_b+0x3c>
    thread_yield();
  d8:	319000ef          	jal	bf0 <thread_yield>
  while(a_started == 0 || c_started == 0)
  dc:	409c                	lw	a5,0(s1)
  de:	dfed                	beqz	a5,d8 <thread_b+0x38>
  e0:	00092783          	lw	a5,0(s2)
  e4:	dbf5                	beqz	a5,d8 <thread_b+0x38>
  
  for (i = 0; i < 100; i++) {
  e6:	4481                	li	s1,0
    printf("thread_b %d\n", i);
  e8:	00001a17          	auipc	s4,0x1
  ec:	c28a0a13          	addi	s4,s4,-984 # d10 <thread_switch+0xd8>
    b_n += 1;
  f0:	00001917          	auipc	s2,0x1
  f4:	f1490913          	addi	s2,s2,-236 # 1004 <b_n>
  for (i = 0; i < 100; i++) {
  f8:	06400993          	li	s3,100
    printf("thread_b %d\n", i);
  fc:	85a6                	mv	a1,s1
  fe:	8552                	mv	a0,s4
 100:	019000ef          	jal	918 <printf>
    b_n += 1;
 104:	00092783          	lw	a5,0(s2)
 108:	2785                	addiw	a5,a5,1
 10a:	00f92023          	sw	a5,0(s2)
    thread_yield();
 10e:	2e3000ef          	jal	bf0 <thread_yield>
  for (i = 0; i < 100; i++) {
 112:	2485                	addiw	s1,s1,1
 114:	ff3494e3          	bne	s1,s3,fc <thread_b+0x5c>
  }
  printf("thread_b: exit after %d\n", b_n);
 118:	00001597          	auipc	a1,0x1
 11c:	eec5a583          	lw	a1,-276(a1) # 1004 <b_n>
 120:	00001517          	auipc	a0,0x1
 124:	c0050513          	addi	a0,a0,-1024 # d20 <thread_switch+0xe8>
 128:	7f0000ef          	jal	918 <printf>

  thread_exit();
 12c:	2e9000ef          	jal	c14 <thread_exit>
}
 130:	70a2                	ld	ra,40(sp)
 132:	7402                	ld	s0,32(sp)
 134:	64e2                	ld	s1,24(sp)
 136:	6942                	ld	s2,16(sp)
 138:	69a2                	ld	s3,8(sp)
 13a:	6a02                	ld	s4,0(sp)
 13c:	6145                	addi	sp,sp,48
 13e:	8082                	ret

0000000000000140 <thread_c>:

void 
thread_c(void)
{
 140:	7179                	addi	sp,sp,-48
 142:	f406                	sd	ra,40(sp)
 144:	f022                	sd	s0,32(sp)
 146:	ec26                	sd	s1,24(sp)
 148:	e84a                	sd	s2,16(sp)
 14a:	e44e                	sd	s3,8(sp)
 14c:	e052                	sd	s4,0(sp)
 14e:	1800                	addi	s0,sp,48
  int i;
  printf("thread_c started\n");
 150:	00001517          	auipc	a0,0x1
 154:	bf050513          	addi	a0,a0,-1040 # d40 <thread_switch+0x108>
 158:	7c0000ef          	jal	918 <printf>
  c_started = 1;
 15c:	4785                	li	a5,1
 15e:	00001717          	auipc	a4,0x1
 162:	eaf72723          	sw	a5,-338(a4) # 100c <c_started>
  while(a_started == 0 || b_started == 0)
 166:	00001497          	auipc	s1,0x1
 16a:	eae48493          	addi	s1,s1,-338 # 1014 <a_started>
 16e:	00001917          	auipc	s2,0x1
 172:	ea290913          	addi	s2,s2,-350 # 1010 <b_started>
 176:	a019                	j	17c <thread_c+0x3c>
    thread_yield();
 178:	279000ef          	jal	bf0 <thread_yield>
  while(a_started == 0 || b_started == 0)
 17c:	409c                	lw	a5,0(s1)
 17e:	dfed                	beqz	a5,178 <thread_c+0x38>
 180:	00092783          	lw	a5,0(s2)
 184:	dbf5                	beqz	a5,178 <thread_c+0x38>
  
  for (i = 0; i < 100; i++) {
 186:	4481                	li	s1,0
    printf("thread_c %d\n", i);
 188:	00001a17          	auipc	s4,0x1
 18c:	bd0a0a13          	addi	s4,s4,-1072 # d58 <thread_switch+0x120>
    c_n += 1;
 190:	00001917          	auipc	s2,0x1
 194:	e7090913          	addi	s2,s2,-400 # 1000 <c_n>
  for (i = 0; i < 100; i++) {
 198:	06400993          	li	s3,100
    printf("thread_c %d\n", i);
 19c:	85a6                	mv	a1,s1
 19e:	8552                	mv	a0,s4
 1a0:	778000ef          	jal	918 <printf>
    c_n += 1;
 1a4:	00092783          	lw	a5,0(s2)
 1a8:	2785                	addiw	a5,a5,1
 1aa:	00f92023          	sw	a5,0(s2)
    thread_yield();
 1ae:	243000ef          	jal	bf0 <thread_yield>
  for (i = 0; i < 100; i++) {
 1b2:	2485                	addiw	s1,s1,1
 1b4:	ff3494e3          	bne	s1,s3,19c <thread_c+0x5c>
  }
  printf("thread_c: exit after %d\n", c_n);
 1b8:	00001597          	auipc	a1,0x1
 1bc:	e485a583          	lw	a1,-440(a1) # 1000 <c_n>
 1c0:	00001517          	auipc	a0,0x1
 1c4:	ba850513          	addi	a0,a0,-1112 # d68 <thread_switch+0x130>
 1c8:	750000ef          	jal	918 <printf>

  thread_exit();
 1cc:	249000ef          	jal	c14 <thread_exit>
}
 1d0:	70a2                	ld	ra,40(sp)
 1d2:	7402                	ld	s0,32(sp)
 1d4:	64e2                	ld	s1,24(sp)
 1d6:	6942                	ld	s2,16(sp)
 1d8:	69a2                	ld	s3,8(sp)
 1da:	6a02                	ld	s4,0(sp)
 1dc:	6145                	addi	sp,sp,48
 1de:	8082                	ret

00000000000001e0 <main>:

int 
main(int argc, char *argv[]) 
{
 1e0:	1141                	addi	sp,sp,-16
 1e2:	e406                	sd	ra,8(sp)
 1e4:	e022                	sd	s0,0(sp)
 1e6:	0800                	addi	s0,sp,16
  a_started = b_started = c_started = 0;
 1e8:	00001797          	auipc	a5,0x1
 1ec:	e207a223          	sw	zero,-476(a5) # 100c <c_started>
 1f0:	00001797          	auipc	a5,0x1
 1f4:	e207a023          	sw	zero,-480(a5) # 1010 <b_started>
 1f8:	00001797          	auipc	a5,0x1
 1fc:	e007ae23          	sw	zero,-484(a5) # 1014 <a_started>
  a_n = b_n = c_n = 0;
 200:	00001797          	auipc	a5,0x1
 204:	e007a023          	sw	zero,-512(a5) # 1000 <c_n>
 208:	00001797          	auipc	a5,0x1
 20c:	de07ae23          	sw	zero,-516(a5) # 1004 <b_n>
 210:	00001797          	auipc	a5,0x1
 214:	de07ac23          	sw	zero,-520(a5) # 1008 <a_n>
  thread_init();
 218:	0af000ef          	jal	ac6 <thread_init>
  thread_create(thread_a);
 21c:	00000517          	auipc	a0,0x0
 220:	de450513          	addi	a0,a0,-540 # 0 <thread_a>
 224:	15f000ef          	jal	b82 <thread_create>
  thread_create(thread_b);
 228:	00000517          	auipc	a0,0x0
 22c:	e7850513          	addi	a0,a0,-392 # a0 <thread_b>
 230:	153000ef          	jal	b82 <thread_create>
  thread_create(thread_c);
 234:	00000517          	auipc	a0,0x0
 238:	f0c50513          	addi	a0,a0,-244 # 140 <thread_c>
 23c:	147000ef          	jal	b82 <thread_create>
  thread_exit();
 240:	1d5000ef          	jal	c14 <thread_exit>
  exit(0);
 244:	4501                	li	a0,0
 246:	290000ef          	jal	4d6 <exit>

000000000000024a <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 24a:	1141                	addi	sp,sp,-16
 24c:	e406                	sd	ra,8(sp)
 24e:	e022                	sd	s0,0(sp)
 250:	0800                	addi	s0,sp,16
  extern int main();
  main();
 252:	f8fff0ef          	jal	1e0 <main>
  exit(0);
 256:	4501                	li	a0,0
 258:	27e000ef          	jal	4d6 <exit>

000000000000025c <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 25c:	1141                	addi	sp,sp,-16
 25e:	e406                	sd	ra,8(sp)
 260:	e022                	sd	s0,0(sp)
 262:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 264:	87aa                	mv	a5,a0
 266:	0585                	addi	a1,a1,1
 268:	0785                	addi	a5,a5,1
 26a:	fff5c703          	lbu	a4,-1(a1)
 26e:	fee78fa3          	sb	a4,-1(a5)
 272:	fb75                	bnez	a4,266 <strcpy+0xa>
    ;
  return os;
}
 274:	60a2                	ld	ra,8(sp)
 276:	6402                	ld	s0,0(sp)
 278:	0141                	addi	sp,sp,16
 27a:	8082                	ret

000000000000027c <strcmp>:

int
strcmp(const char *p, const char *q)
{
 27c:	1141                	addi	sp,sp,-16
 27e:	e406                	sd	ra,8(sp)
 280:	e022                	sd	s0,0(sp)
 282:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 284:	00054783          	lbu	a5,0(a0)
 288:	cb91                	beqz	a5,29c <strcmp+0x20>
 28a:	0005c703          	lbu	a4,0(a1)
 28e:	00f71763          	bne	a4,a5,29c <strcmp+0x20>
    p++, q++;
 292:	0505                	addi	a0,a0,1
 294:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 296:	00054783          	lbu	a5,0(a0)
 29a:	fbe5                	bnez	a5,28a <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 29c:	0005c503          	lbu	a0,0(a1)
}
 2a0:	40a7853b          	subw	a0,a5,a0
 2a4:	60a2                	ld	ra,8(sp)
 2a6:	6402                	ld	s0,0(sp)
 2a8:	0141                	addi	sp,sp,16
 2aa:	8082                	ret

00000000000002ac <strlen>:

uint
strlen(const char *s)
{
 2ac:	1141                	addi	sp,sp,-16
 2ae:	e406                	sd	ra,8(sp)
 2b0:	e022                	sd	s0,0(sp)
 2b2:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 2b4:	00054783          	lbu	a5,0(a0)
 2b8:	cf91                	beqz	a5,2d4 <strlen+0x28>
 2ba:	00150793          	addi	a5,a0,1
 2be:	86be                	mv	a3,a5
 2c0:	0785                	addi	a5,a5,1
 2c2:	fff7c703          	lbu	a4,-1(a5)
 2c6:	ff65                	bnez	a4,2be <strlen+0x12>
 2c8:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 2cc:	60a2                	ld	ra,8(sp)
 2ce:	6402                	ld	s0,0(sp)
 2d0:	0141                	addi	sp,sp,16
 2d2:	8082                	ret
  for(n = 0; s[n]; n++)
 2d4:	4501                	li	a0,0
 2d6:	bfdd                	j	2cc <strlen+0x20>

00000000000002d8 <memset>:

void*
memset(void *dst, int c, uint n)
{
 2d8:	1141                	addi	sp,sp,-16
 2da:	e406                	sd	ra,8(sp)
 2dc:	e022                	sd	s0,0(sp)
 2de:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 2e0:	ca19                	beqz	a2,2f6 <memset+0x1e>
 2e2:	87aa                	mv	a5,a0
 2e4:	1602                	slli	a2,a2,0x20
 2e6:	9201                	srli	a2,a2,0x20
 2e8:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 2ec:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 2f0:	0785                	addi	a5,a5,1
 2f2:	fee79de3          	bne	a5,a4,2ec <memset+0x14>
  }
  return dst;
}
 2f6:	60a2                	ld	ra,8(sp)
 2f8:	6402                	ld	s0,0(sp)
 2fa:	0141                	addi	sp,sp,16
 2fc:	8082                	ret

00000000000002fe <strchr>:

char*
strchr(const char *s, char c)
{
 2fe:	1141                	addi	sp,sp,-16
 300:	e406                	sd	ra,8(sp)
 302:	e022                	sd	s0,0(sp)
 304:	0800                	addi	s0,sp,16
  for(; *s; s++)
 306:	00054783          	lbu	a5,0(a0)
 30a:	c799                	beqz	a5,318 <strchr+0x1a>
    if(*s == c)
 30c:	00f58763          	beq	a1,a5,31a <strchr+0x1c>
  for(; *s; s++)
 310:	0505                	addi	a0,a0,1
 312:	00054783          	lbu	a5,0(a0)
 316:	fbfd                	bnez	a5,30c <strchr+0xe>
      return (char*)s;
  return 0;
 318:	4501                	li	a0,0
}
 31a:	60a2                	ld	ra,8(sp)
 31c:	6402                	ld	s0,0(sp)
 31e:	0141                	addi	sp,sp,16
 320:	8082                	ret

0000000000000322 <gets>:

char*
gets(char *buf, int max)
{
 322:	711d                	addi	sp,sp,-96
 324:	ec86                	sd	ra,88(sp)
 326:	e8a2                	sd	s0,80(sp)
 328:	e4a6                	sd	s1,72(sp)
 32a:	e0ca                	sd	s2,64(sp)
 32c:	fc4e                	sd	s3,56(sp)
 32e:	f852                	sd	s4,48(sp)
 330:	f456                	sd	s5,40(sp)
 332:	f05a                	sd	s6,32(sp)
 334:	ec5e                	sd	s7,24(sp)
 336:	e862                	sd	s8,16(sp)
 338:	1080                	addi	s0,sp,96
 33a:	8baa                	mv	s7,a0
 33c:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 33e:	892a                	mv	s2,a0
 340:	4481                	li	s1,0
    cc = read(0, &c, 1);
 342:	faf40b13          	addi	s6,s0,-81
 346:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 348:	8c26                	mv	s8,s1
 34a:	0014899b          	addiw	s3,s1,1
 34e:	84ce                	mv	s1,s3
 350:	0349d863          	bge	s3,s4,380 <gets+0x5e>
    cc = read(0, &c, 1);
 354:	8656                	mv	a2,s5
 356:	85da                	mv	a1,s6
 358:	4501                	li	a0,0
 35a:	194000ef          	jal	4ee <read>
    if(cc < 1)
 35e:	02a05163          	blez	a0,380 <gets+0x5e>
      break;
    buf[i++] = c;
 362:	faf44783          	lbu	a5,-81(s0)
 366:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 36a:	0905                	addi	s2,s2,1
 36c:	ff678713          	addi	a4,a5,-10
 370:	00173713          	seqz	a4,a4
 374:	17cd                	addi	a5,a5,-13
 376:	0017b793          	seqz	a5,a5
 37a:	8fd9                	or	a5,a5,a4
 37c:	d7f1                	beqz	a5,348 <gets+0x26>
    buf[i++] = c;
 37e:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 380:	9c5e                	add	s8,s8,s7
 382:	000c0023          	sb	zero,0(s8)
  return buf;
}
 386:	855e                	mv	a0,s7
 388:	60e6                	ld	ra,88(sp)
 38a:	6446                	ld	s0,80(sp)
 38c:	64a6                	ld	s1,72(sp)
 38e:	6906                	ld	s2,64(sp)
 390:	79e2                	ld	s3,56(sp)
 392:	7a42                	ld	s4,48(sp)
 394:	7aa2                	ld	s5,40(sp)
 396:	7b02                	ld	s6,32(sp)
 398:	6be2                	ld	s7,24(sp)
 39a:	6c42                	ld	s8,16(sp)
 39c:	6125                	addi	sp,sp,96
 39e:	8082                	ret

00000000000003a0 <stat>:

int
stat(const char *n, struct stat *st)
{
 3a0:	1101                	addi	sp,sp,-32
 3a2:	ec06                	sd	ra,24(sp)
 3a4:	e822                	sd	s0,16(sp)
 3a6:	e04a                	sd	s2,0(sp)
 3a8:	1000                	addi	s0,sp,32
 3aa:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 3ac:	4581                	li	a1,0
 3ae:	168000ef          	jal	516 <open>
  if(fd < 0)
 3b2:	02054263          	bltz	a0,3d6 <stat+0x36>
 3b6:	e426                	sd	s1,8(sp)
 3b8:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 3ba:	85ca                	mv	a1,s2
 3bc:	172000ef          	jal	52e <fstat>
 3c0:	892a                	mv	s2,a0
  close(fd);
 3c2:	8526                	mv	a0,s1
 3c4:	13a000ef          	jal	4fe <close>
  return r;
 3c8:	64a2                	ld	s1,8(sp)
}
 3ca:	854a                	mv	a0,s2
 3cc:	60e2                	ld	ra,24(sp)
 3ce:	6442                	ld	s0,16(sp)
 3d0:	6902                	ld	s2,0(sp)
 3d2:	6105                	addi	sp,sp,32
 3d4:	8082                	ret
    return -1;
 3d6:	57fd                	li	a5,-1
 3d8:	893e                	mv	s2,a5
 3da:	bfc5                	j	3ca <stat+0x2a>

00000000000003dc <atoi>:

int
atoi(const char *s)
{
 3dc:	1141                	addi	sp,sp,-16
 3de:	e406                	sd	ra,8(sp)
 3e0:	e022                	sd	s0,0(sp)
 3e2:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 3e4:	00054683          	lbu	a3,0(a0)
 3e8:	fd06879b          	addiw	a5,a3,-48
 3ec:	0ff7f793          	zext.b	a5,a5
 3f0:	4625                	li	a2,9
 3f2:	02f66963          	bltu	a2,a5,424 <atoi+0x48>
 3f6:	872a                	mv	a4,a0
  n = 0;
 3f8:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 3fa:	0705                	addi	a4,a4,1
 3fc:	0025179b          	slliw	a5,a0,0x2
 400:	9fa9                	addw	a5,a5,a0
 402:	0017979b          	slliw	a5,a5,0x1
 406:	9fb5                	addw	a5,a5,a3
 408:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 40c:	00074683          	lbu	a3,0(a4)
 410:	fd06879b          	addiw	a5,a3,-48
 414:	0ff7f793          	zext.b	a5,a5
 418:	fef671e3          	bgeu	a2,a5,3fa <atoi+0x1e>
  return n;
}
 41c:	60a2                	ld	ra,8(sp)
 41e:	6402                	ld	s0,0(sp)
 420:	0141                	addi	sp,sp,16
 422:	8082                	ret
  n = 0;
 424:	4501                	li	a0,0
 426:	bfdd                	j	41c <atoi+0x40>

0000000000000428 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 428:	1141                	addi	sp,sp,-16
 42a:	e406                	sd	ra,8(sp)
 42c:	e022                	sd	s0,0(sp)
 42e:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 430:	02b57563          	bgeu	a0,a1,45a <memmove+0x32>
    while(n-- > 0)
 434:	00c05f63          	blez	a2,452 <memmove+0x2a>
 438:	1602                	slli	a2,a2,0x20
 43a:	9201                	srli	a2,a2,0x20
 43c:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 440:	872a                	mv	a4,a0
      *dst++ = *src++;
 442:	0585                	addi	a1,a1,1
 444:	0705                	addi	a4,a4,1
 446:	fff5c683          	lbu	a3,-1(a1)
 44a:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 44e:	fee79ae3          	bne	a5,a4,442 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 452:	60a2                	ld	ra,8(sp)
 454:	6402                	ld	s0,0(sp)
 456:	0141                	addi	sp,sp,16
 458:	8082                	ret
    while(n-- > 0)
 45a:	fec05ce3          	blez	a2,452 <memmove+0x2a>
    dst += n;
 45e:	00c50733          	add	a4,a0,a2
    src += n;
 462:	95b2                	add	a1,a1,a2
 464:	fff6079b          	addiw	a5,a2,-1
 468:	1782                	slli	a5,a5,0x20
 46a:	9381                	srli	a5,a5,0x20
 46c:	fff7c793          	not	a5,a5
 470:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 472:	15fd                	addi	a1,a1,-1
 474:	177d                	addi	a4,a4,-1
 476:	0005c683          	lbu	a3,0(a1)
 47a:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 47e:	fef71ae3          	bne	a4,a5,472 <memmove+0x4a>
 482:	bfc1                	j	452 <memmove+0x2a>

0000000000000484 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 484:	1141                	addi	sp,sp,-16
 486:	e406                	sd	ra,8(sp)
 488:	e022                	sd	s0,0(sp)
 48a:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 48c:	ce19                	beqz	a2,4aa <memcmp+0x26>
 48e:	1602                	slli	a2,a2,0x20
 490:	9201                	srli	a2,a2,0x20
 492:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 496:	00054783          	lbu	a5,0(a0)
 49a:	0005c703          	lbu	a4,0(a1)
 49e:	00e79b63          	bne	a5,a4,4b4 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 4a2:	0505                	addi	a0,a0,1
    p2++;
 4a4:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 4a6:	fed518e3          	bne	a0,a3,496 <memcmp+0x12>
  }
  return 0;
 4aa:	4501                	li	a0,0
}
 4ac:	60a2                	ld	ra,8(sp)
 4ae:	6402                	ld	s0,0(sp)
 4b0:	0141                	addi	sp,sp,16
 4b2:	8082                	ret
      return *p1 - *p2;
 4b4:	40e7853b          	subw	a0,a5,a4
 4b8:	bfd5                	j	4ac <memcmp+0x28>

00000000000004ba <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 4ba:	1141                	addi	sp,sp,-16
 4bc:	e406                	sd	ra,8(sp)
 4be:	e022                	sd	s0,0(sp)
 4c0:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 4c2:	f67ff0ef          	jal	428 <memmove>
}
 4c6:	60a2                	ld	ra,8(sp)
 4c8:	6402                	ld	s0,0(sp)
 4ca:	0141                	addi	sp,sp,16
 4cc:	8082                	ret

00000000000004ce <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 4ce:	4885                	li	a7,1
 ecall
 4d0:	00000073          	ecall
 ret
 4d4:	8082                	ret

00000000000004d6 <exit>:
.global exit
exit:
 li a7, SYS_exit
 4d6:	4889                	li	a7,2
 ecall
 4d8:	00000073          	ecall
 ret
 4dc:	8082                	ret

00000000000004de <wait>:
.global wait
wait:
 li a7, SYS_wait
 4de:	488d                	li	a7,3
 ecall
 4e0:	00000073          	ecall
 ret
 4e4:	8082                	ret

00000000000004e6 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 4e6:	4891                	li	a7,4
 ecall
 4e8:	00000073          	ecall
 ret
 4ec:	8082                	ret

00000000000004ee <read>:
.global read
read:
 li a7, SYS_read
 4ee:	4895                	li	a7,5
 ecall
 4f0:	00000073          	ecall
 ret
 4f4:	8082                	ret

00000000000004f6 <write>:
.global write
write:
 li a7, SYS_write
 4f6:	48c1                	li	a7,16
 ecall
 4f8:	00000073          	ecall
 ret
 4fc:	8082                	ret

00000000000004fe <close>:
.global close
close:
 li a7, SYS_close
 4fe:	48d5                	li	a7,21
 ecall
 500:	00000073          	ecall
 ret
 504:	8082                	ret

0000000000000506 <kill>:
.global kill
kill:
 li a7, SYS_kill
 506:	4899                	li	a7,6
 ecall
 508:	00000073          	ecall
 ret
 50c:	8082                	ret

000000000000050e <exec>:
.global exec
exec:
 li a7, SYS_exec
 50e:	489d                	li	a7,7
 ecall
 510:	00000073          	ecall
 ret
 514:	8082                	ret

0000000000000516 <open>:
.global open
open:
 li a7, SYS_open
 516:	48bd                	li	a7,15
 ecall
 518:	00000073          	ecall
 ret
 51c:	8082                	ret

000000000000051e <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 51e:	48c5                	li	a7,17
 ecall
 520:	00000073          	ecall
 ret
 524:	8082                	ret

0000000000000526 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 526:	48c9                	li	a7,18
 ecall
 528:	00000073          	ecall
 ret
 52c:	8082                	ret

000000000000052e <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 52e:	48a1                	li	a7,8
 ecall
 530:	00000073          	ecall
 ret
 534:	8082                	ret

0000000000000536 <link>:
.global link
link:
 li a7, SYS_link
 536:	48cd                	li	a7,19
 ecall
 538:	00000073          	ecall
 ret
 53c:	8082                	ret

000000000000053e <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 53e:	48d1                	li	a7,20
 ecall
 540:	00000073          	ecall
 ret
 544:	8082                	ret

0000000000000546 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 546:	48a5                	li	a7,9
 ecall
 548:	00000073          	ecall
 ret
 54c:	8082                	ret

000000000000054e <dup>:
.global dup
dup:
 li a7, SYS_dup
 54e:	48a9                	li	a7,10
 ecall
 550:	00000073          	ecall
 ret
 554:	8082                	ret

0000000000000556 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 556:	48ad                	li	a7,11
 ecall
 558:	00000073          	ecall
 ret
 55c:	8082                	ret

000000000000055e <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 55e:	48b1                	li	a7,12
 ecall
 560:	00000073          	ecall
 ret
 564:	8082                	ret

0000000000000566 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 566:	48b5                	li	a7,13
 ecall
 568:	00000073          	ecall
 ret
 56c:	8082                	ret

000000000000056e <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 56e:	48b9                	li	a7,14
 ecall
 570:	00000073          	ecall
 ret
 574:	8082                	ret

0000000000000576 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 576:	1101                	addi	sp,sp,-32
 578:	ec06                	sd	ra,24(sp)
 57a:	e822                	sd	s0,16(sp)
 57c:	1000                	addi	s0,sp,32
 57e:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 582:	4605                	li	a2,1
 584:	fef40593          	addi	a1,s0,-17
 588:	f6fff0ef          	jal	4f6 <write>
}
 58c:	60e2                	ld	ra,24(sp)
 58e:	6442                	ld	s0,16(sp)
 590:	6105                	addi	sp,sp,32
 592:	8082                	ret

0000000000000594 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 594:	715d                	addi	sp,sp,-80
 596:	e486                	sd	ra,72(sp)
 598:	e0a2                	sd	s0,64(sp)
 59a:	f84a                	sd	s2,48(sp)
 59c:	f44e                	sd	s3,40(sp)
 59e:	0880                	addi	s0,sp,80
 5a0:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 5a2:	00d036b3          	snez	a3,a3
 5a6:	03f5d793          	srli	a5,a1,0x3f
 5aa:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 5ac:	0005871b          	sext.w	a4,a1
  neg = 0;
 5b0:	4301                	li	t1,0
  if(sgn && xx < 0){
 5b2:	c681                	beqz	a3,5ba <printint+0x26>
    x = -xx;
 5b4:	40b0073b          	negw	a4,a1
    neg = 1;
 5b8:	4305                	li	t1,1
  }

  i = 0;
 5ba:	fb840993          	addi	s3,s0,-72
  neg = 0;
 5be:	85ce                	mv	a1,s3
  i = 0;
 5c0:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 5c2:	00000817          	auipc	a6,0x0
 5c6:	7f680813          	addi	a6,a6,2038 # db8 <digits>
 5ca:	88b6                	mv	a7,a3
 5cc:	0016851b          	addiw	a0,a3,1
 5d0:	86aa                	mv	a3,a0
 5d2:	02c777bb          	remuw	a5,a4,a2
 5d6:	1782                	slli	a5,a5,0x20
 5d8:	9381                	srli	a5,a5,0x20
 5da:	97c2                	add	a5,a5,a6
 5dc:	0007c783          	lbu	a5,0(a5)
 5e0:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 5e4:	87ba                	mv	a5,a4
 5e6:	02c7573b          	divuw	a4,a4,a2
 5ea:	0585                	addi	a1,a1,1
 5ec:	fcc7ffe3          	bgeu	a5,a2,5ca <printint+0x36>
  if(neg)
 5f0:	00030b63          	beqz	t1,606 <printint+0x72>
    buf[i++] = '-';
 5f4:	fd040793          	addi	a5,s0,-48
 5f8:	953e                	add	a0,a0,a5
 5fa:	02d00793          	li	a5,45
 5fe:	fef50423          	sb	a5,-24(a0)
 602:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 606:	02d05563          	blez	a3,630 <printint+0x9c>
 60a:	fc26                	sd	s1,56(sp)
 60c:	36fd                	addiw	a3,a3,-1
 60e:	00d984b3          	add	s1,s3,a3
 612:	19fd                	addi	s3,s3,-1
 614:	99b6                	add	s3,s3,a3
 616:	1682                	slli	a3,a3,0x20
 618:	9281                	srli	a3,a3,0x20
 61a:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 61e:	0004c583          	lbu	a1,0(s1)
 622:	854a                	mv	a0,s2
 624:	f53ff0ef          	jal	576 <putc>
  while(--i >= 0)
 628:	14fd                	addi	s1,s1,-1
 62a:	ff349ae3          	bne	s1,s3,61e <printint+0x8a>
 62e:	74e2                	ld	s1,56(sp)
}
 630:	60a6                	ld	ra,72(sp)
 632:	6406                	ld	s0,64(sp)
 634:	7942                	ld	s2,48(sp)
 636:	79a2                	ld	s3,40(sp)
 638:	6161                	addi	sp,sp,80
 63a:	8082                	ret

000000000000063c <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 63c:	711d                	addi	sp,sp,-96
 63e:	ec86                	sd	ra,88(sp)
 640:	e8a2                	sd	s0,80(sp)
 642:	e4a6                	sd	s1,72(sp)
 644:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 646:	0005c483          	lbu	s1,0(a1)
 64a:	28048263          	beqz	s1,8ce <vprintf+0x292>
 64e:	e0ca                	sd	s2,64(sp)
 650:	fc4e                	sd	s3,56(sp)
 652:	f852                	sd	s4,48(sp)
 654:	f456                	sd	s5,40(sp)
 656:	f05a                	sd	s6,32(sp)
 658:	ec5e                	sd	s7,24(sp)
 65a:	e862                	sd	s8,16(sp)
 65c:	8b2a                	mv	s6,a0
 65e:	8a2e                	mv	s4,a1
 660:	8bb2                	mv	s7,a2
  state = 0;
 662:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 664:	4901                	li	s2,0
 666:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 668:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 66c:	06400c13          	li	s8,100
 670:	a00d                	j	692 <vprintf+0x56>
        putc(fd, c0);
 672:	85a6                	mv	a1,s1
 674:	855a                	mv	a0,s6
 676:	f01ff0ef          	jal	576 <putc>
 67a:	a019                	j	680 <vprintf+0x44>
    } else if(state == '%'){
 67c:	03598363          	beq	s3,s5,6a2 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 680:	0019079b          	addiw	a5,s2,1
 684:	893e                	mv	s2,a5
 686:	873e                	mv	a4,a5
 688:	97d2                	add	a5,a5,s4
 68a:	0007c483          	lbu	s1,0(a5)
 68e:	22048963          	beqz	s1,8c0 <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 692:	0004879b          	sext.w	a5,s1
    if(state == 0){
 696:	fe0993e3          	bnez	s3,67c <vprintf+0x40>
      if(c0 == '%'){
 69a:	fd579ce3          	bne	a5,s5,672 <vprintf+0x36>
        state = '%';
 69e:	89be                	mv	s3,a5
 6a0:	b7c5                	j	680 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 6a2:	00ea06b3          	add	a3,s4,a4
 6a6:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 6aa:	22060763          	beqz	a2,8d8 <vprintf+0x29c>
      if(c0 == 'd'){
 6ae:	0b878363          	beq	a5,s8,754 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 6b2:	f9478693          	addi	a3,a5,-108
 6b6:	0016b693          	seqz	a3,a3
 6ba:	f9c60593          	addi	a1,a2,-100
 6be:	0015b593          	seqz	a1,a1
 6c2:	8df5                	and	a1,a1,a3
 6c4:	e5c5                	bnez	a1,76c <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 6c6:	9752                	add	a4,a4,s4
 6c8:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 6cc:	f9460713          	addi	a4,a2,-108
 6d0:	00173713          	seqz	a4,a4
 6d4:	8f75                	and	a4,a4,a3
 6d6:	f9c50593          	addi	a1,a0,-100
 6da:	0015b593          	seqz	a1,a1
 6de:	8df9                	and	a1,a1,a4
 6e0:	e1dd                	bnez	a1,786 <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 6e2:	07500593          	li	a1,117
 6e6:	0ab78d63          	beq	a5,a1,7a0 <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 6ea:	f8b60593          	addi	a1,a2,-117
 6ee:	0015b593          	seqz	a1,a1
 6f2:	8df5                	and	a1,a1,a3
 6f4:	e1f1                	bnez	a1,7b8 <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 6f6:	f8b50593          	addi	a1,a0,-117
 6fa:	0015b593          	seqz	a1,a1
 6fe:	8df9                	and	a1,a1,a4
 700:	e9e9                	bnez	a1,7d2 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 702:	07800593          	li	a1,120
 706:	0eb78363          	beq	a5,a1,7ec <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 70a:	f8860613          	addi	a2,a2,-120
 70e:	00163613          	seqz	a2,a2
 712:	8ef1                	and	a3,a3,a2
 714:	0e069863          	bnez	a3,804 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 718:	f8850513          	addi	a0,a0,-120
 71c:	00153513          	seqz	a0,a0
 720:	8f69                	and	a4,a4,a0
 722:	0e071e63          	bnez	a4,81e <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 726:	07000713          	li	a4,112
 72a:	10e78663          	beq	a5,a4,836 <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 72e:	07300713          	li	a4,115
 732:	14e78663          	beq	a5,a4,87e <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 736:	02500713          	li	a4,37
 73a:	16e78e63          	beq	a5,a4,8b6 <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 73e:	02500593          	li	a1,37
 742:	855a                	mv	a0,s6
 744:	e33ff0ef          	jal	576 <putc>
        putc(fd, c0);
 748:	85a6                	mv	a1,s1
 74a:	855a                	mv	a0,s6
 74c:	e2bff0ef          	jal	576 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 750:	4981                	li	s3,0
 752:	b73d                	j	680 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 754:	008b8493          	addi	s1,s7,8
 758:	4685                	li	a3,1
 75a:	4629                	li	a2,10
 75c:	000ba583          	lw	a1,0(s7)
 760:	855a                	mv	a0,s6
 762:	e33ff0ef          	jal	594 <printint>
 766:	8ba6                	mv	s7,s1
      state = 0;
 768:	4981                	li	s3,0
 76a:	bf19                	j	680 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 76c:	008b8493          	addi	s1,s7,8
 770:	4685                	li	a3,1
 772:	4629                	li	a2,10
 774:	000bb583          	ld	a1,0(s7)
 778:	855a                	mv	a0,s6
 77a:	e1bff0ef          	jal	594 <printint>
        i += 1;
 77e:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 780:	8ba6                	mv	s7,s1
      state = 0;
 782:	4981                	li	s3,0
 784:	bdf5                	j	680 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 786:	008b8493          	addi	s1,s7,8
 78a:	4685                	li	a3,1
 78c:	4629                	li	a2,10
 78e:	000bb583          	ld	a1,0(s7)
 792:	855a                	mv	a0,s6
 794:	e01ff0ef          	jal	594 <printint>
        i += 2;
 798:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 79a:	8ba6                	mv	s7,s1
      state = 0;
 79c:	4981                	li	s3,0
        i += 2;
 79e:	b5cd                	j	680 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 7a0:	008b8493          	addi	s1,s7,8
 7a4:	4681                	li	a3,0
 7a6:	4629                	li	a2,10
 7a8:	000ba583          	lw	a1,0(s7)
 7ac:	855a                	mv	a0,s6
 7ae:	de7ff0ef          	jal	594 <printint>
 7b2:	8ba6                	mv	s7,s1
      state = 0;
 7b4:	4981                	li	s3,0
 7b6:	b5e9                	j	680 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7b8:	008b8493          	addi	s1,s7,8
 7bc:	4681                	li	a3,0
 7be:	4629                	li	a2,10
 7c0:	000bb583          	ld	a1,0(s7)
 7c4:	855a                	mv	a0,s6
 7c6:	dcfff0ef          	jal	594 <printint>
        i += 1;
 7ca:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 7cc:	8ba6                	mv	s7,s1
      state = 0;
 7ce:	4981                	li	s3,0
 7d0:	bd45                	j	680 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7d2:	008b8493          	addi	s1,s7,8
 7d6:	4681                	li	a3,0
 7d8:	4629                	li	a2,10
 7da:	000bb583          	ld	a1,0(s7)
 7de:	855a                	mv	a0,s6
 7e0:	db5ff0ef          	jal	594 <printint>
        i += 2;
 7e4:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 7e6:	8ba6                	mv	s7,s1
      state = 0;
 7e8:	4981                	li	s3,0
        i += 2;
 7ea:	bd59                	j	680 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 7ec:	008b8493          	addi	s1,s7,8
 7f0:	4681                	li	a3,0
 7f2:	4641                	li	a2,16
 7f4:	000ba583          	lw	a1,0(s7)
 7f8:	855a                	mv	a0,s6
 7fa:	d9bff0ef          	jal	594 <printint>
 7fe:	8ba6                	mv	s7,s1
      state = 0;
 800:	4981                	li	s3,0
 802:	bdbd                	j	680 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 804:	008b8493          	addi	s1,s7,8
 808:	4681                	li	a3,0
 80a:	4641                	li	a2,16
 80c:	000bb583          	ld	a1,0(s7)
 810:	855a                	mv	a0,s6
 812:	d83ff0ef          	jal	594 <printint>
        i += 1;
 816:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 818:	8ba6                	mv	s7,s1
      state = 0;
 81a:	4981                	li	s3,0
 81c:	b595                	j	680 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 81e:	008b8493          	addi	s1,s7,8
 822:	4641                	li	a2,16
 824:	000bb583          	ld	a1,0(s7)
 828:	855a                	mv	a0,s6
 82a:	d6bff0ef          	jal	594 <printint>
        i += 2;
 82e:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 830:	8ba6                	mv	s7,s1
      state = 0;
 832:	4981                	li	s3,0
        i += 2;
 834:	b5b1                	j	680 <vprintf+0x44>
 836:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 838:	008b8793          	addi	a5,s7,8
 83c:	8cbe                	mv	s9,a5
 83e:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 842:	03000593          	li	a1,48
 846:	855a                	mv	a0,s6
 848:	d2fff0ef          	jal	576 <putc>
  putc(fd, 'x');
 84c:	07800593          	li	a1,120
 850:	855a                	mv	a0,s6
 852:	d25ff0ef          	jal	576 <putc>
 856:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 858:	00000b97          	auipc	s7,0x0
 85c:	560b8b93          	addi	s7,s7,1376 # db8 <digits>
 860:	03c9d793          	srli	a5,s3,0x3c
 864:	97de                	add	a5,a5,s7
 866:	0007c583          	lbu	a1,0(a5)
 86a:	855a                	mv	a0,s6
 86c:	d0bff0ef          	jal	576 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 870:	0992                	slli	s3,s3,0x4
 872:	34fd                	addiw	s1,s1,-1
 874:	f4f5                	bnez	s1,860 <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 876:	8be6                	mv	s7,s9
      state = 0;
 878:	4981                	li	s3,0
 87a:	6ca2                	ld	s9,8(sp)
 87c:	b511                	j	680 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 87e:	008b8993          	addi	s3,s7,8
 882:	000bb483          	ld	s1,0(s7)
 886:	cc91                	beqz	s1,8a2 <vprintf+0x266>
        for(; *s; s++)
 888:	0004c583          	lbu	a1,0(s1)
 88c:	c195                	beqz	a1,8b0 <vprintf+0x274>
          putc(fd, *s);
 88e:	855a                	mv	a0,s6
 890:	ce7ff0ef          	jal	576 <putc>
        for(; *s; s++)
 894:	0485                	addi	s1,s1,1
 896:	0004c583          	lbu	a1,0(s1)
 89a:	f9f5                	bnez	a1,88e <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 89c:	8bce                	mv	s7,s3
      state = 0;
 89e:	4981                	li	s3,0
 8a0:	b3c5                	j	680 <vprintf+0x44>
          s = "(null)";
 8a2:	00000497          	auipc	s1,0x0
 8a6:	4e648493          	addi	s1,s1,1254 # d88 <thread_switch+0x150>
        for(; *s; s++)
 8aa:	02800593          	li	a1,40
 8ae:	b7c5                	j	88e <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 8b0:	8bce                	mv	s7,s3
      state = 0;
 8b2:	4981                	li	s3,0
 8b4:	b3f1                	j	680 <vprintf+0x44>
        putc(fd, '%');
 8b6:	85be                	mv	a1,a5
 8b8:	855a                	mv	a0,s6
 8ba:	cbdff0ef          	jal	576 <putc>
 8be:	bd49                	j	750 <vprintf+0x114>
 8c0:	6906                	ld	s2,64(sp)
 8c2:	79e2                	ld	s3,56(sp)
 8c4:	7a42                	ld	s4,48(sp)
 8c6:	7aa2                	ld	s5,40(sp)
 8c8:	7b02                	ld	s6,32(sp)
 8ca:	6be2                	ld	s7,24(sp)
 8cc:	6c42                	ld	s8,16(sp)
    }
  }
}
 8ce:	60e6                	ld	ra,88(sp)
 8d0:	6446                	ld	s0,80(sp)
 8d2:	64a6                	ld	s1,72(sp)
 8d4:	6125                	addi	sp,sp,96
 8d6:	8082                	ret
      if(c0 == 'd'){
 8d8:	06400713          	li	a4,100
 8dc:	e6e78ce3          	beq	a5,a4,754 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 8e0:	f9478693          	addi	a3,a5,-108
 8e4:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 8e8:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 8ea:	4701                	li	a4,0
 8ec:	bbdd                	j	6e2 <vprintf+0xa6>

00000000000008ee <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 8ee:	715d                	addi	sp,sp,-80
 8f0:	ec06                	sd	ra,24(sp)
 8f2:	e822                	sd	s0,16(sp)
 8f4:	1000                	addi	s0,sp,32
 8f6:	e010                	sd	a2,0(s0)
 8f8:	e414                	sd	a3,8(s0)
 8fa:	e818                	sd	a4,16(s0)
 8fc:	ec1c                	sd	a5,24(s0)
 8fe:	03043023          	sd	a6,32(s0)
 902:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 906:	8622                	mv	a2,s0
 908:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 90c:	d31ff0ef          	jal	63c <vprintf>
}
 910:	60e2                	ld	ra,24(sp)
 912:	6442                	ld	s0,16(sp)
 914:	6161                	addi	sp,sp,80
 916:	8082                	ret

0000000000000918 <printf>:

void
printf(const char *fmt, ...)
{
 918:	711d                	addi	sp,sp,-96
 91a:	ec06                	sd	ra,24(sp)
 91c:	e822                	sd	s0,16(sp)
 91e:	1000                	addi	s0,sp,32
 920:	e40c                	sd	a1,8(s0)
 922:	e810                	sd	a2,16(s0)
 924:	ec14                	sd	a3,24(s0)
 926:	f018                	sd	a4,32(s0)
 928:	f41c                	sd	a5,40(s0)
 92a:	03043823          	sd	a6,48(s0)
 92e:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 932:	00840613          	addi	a2,s0,8
 936:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 93a:	85aa                	mv	a1,a0
 93c:	4505                	li	a0,1
 93e:	cffff0ef          	jal	63c <vprintf>
}
 942:	60e2                	ld	ra,24(sp)
 944:	6442                	ld	s0,16(sp)
 946:	6125                	addi	sp,sp,96
 948:	8082                	ret

000000000000094a <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 94a:	1141                	addi	sp,sp,-16
 94c:	e406                	sd	ra,8(sp)
 94e:	e022                	sd	s0,0(sp)
 950:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 952:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 956:	00000797          	auipc	a5,0x0
 95a:	6c27b783          	ld	a5,1730(a5) # 1018 <freep>
 95e:	a095                	j	9c2 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 960:	ff852583          	lw	a1,-8(a0)
 964:	6390                	ld	a2,0(a5)
 966:	02059813          	slli	a6,a1,0x20
 96a:	01c85693          	srli	a3,a6,0x1c
 96e:	96ba                	add	a3,a3,a4
 970:	02d60563          	beq	a2,a3,99a <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 974:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 978:	4790                	lw	a2,8(a5)
 97a:	02061593          	slli	a1,a2,0x20
 97e:	01c5d693          	srli	a3,a1,0x1c
 982:	96be                	add	a3,a3,a5
 984:	02d70263          	beq	a4,a3,9a8 <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 988:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 98a:	00000717          	auipc	a4,0x0
 98e:	68f73723          	sd	a5,1678(a4) # 1018 <freep>
}
 992:	60a2                	ld	ra,8(sp)
 994:	6402                	ld	s0,0(sp)
 996:	0141                	addi	sp,sp,16
 998:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 99a:	4614                	lw	a3,8(a2)
 99c:	9ead                	addw	a3,a3,a1
 99e:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 9a2:	6394                	ld	a3,0(a5)
 9a4:	6290                	ld	a2,0(a3)
 9a6:	b7f9                	j	974 <free+0x2a>
    p->s.size += bp->s.size;
 9a8:	ff852703          	lw	a4,-8(a0)
 9ac:	9f31                	addw	a4,a4,a2
 9ae:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 9b0:	ff053703          	ld	a4,-16(a0)
 9b4:	bfd1                	j	988 <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9b6:	6394                	ld	a3,0(a5)
 9b8:	00d7e463          	bltu	a5,a3,9c0 <free+0x76>
 9bc:	fad762e3          	bltu	a4,a3,960 <free+0x16>
 9c0:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9c2:	fee7fae3          	bgeu	a5,a4,9b6 <free+0x6c>
 9c6:	6394                	ld	a3,0(a5)
 9c8:	f8d76ce3          	bltu	a4,a3,960 <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9cc:	f8d7fae3          	bgeu	a5,a3,960 <free+0x16>
 9d0:	87b6                	mv	a5,a3
 9d2:	bfc5                	j	9c2 <free+0x78>

00000000000009d4 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 9d4:	7139                	addi	sp,sp,-64
 9d6:	fc06                	sd	ra,56(sp)
 9d8:	f822                	sd	s0,48(sp)
 9da:	f04a                	sd	s2,32(sp)
 9dc:	ec4e                	sd	s3,24(sp)
 9de:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 9e0:	02051993          	slli	s3,a0,0x20
 9e4:	0209d993          	srli	s3,s3,0x20
 9e8:	09bd                	addi	s3,s3,15
 9ea:	0049d993          	srli	s3,s3,0x4
 9ee:	2985                	addiw	s3,s3,1
 9f0:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 9f2:	00000517          	auipc	a0,0x0
 9f6:	62653503          	ld	a0,1574(a0) # 1018 <freep>
 9fa:	c905                	beqz	a0,a2a <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 9fc:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 9fe:	4798                	lw	a4,8(a5)
 a00:	09377663          	bgeu	a4,s3,a8c <malloc+0xb8>
 a04:	f426                	sd	s1,40(sp)
 a06:	e852                	sd	s4,16(sp)
 a08:	e456                	sd	s5,8(sp)
 a0a:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 a0c:	8a4e                	mv	s4,s3
 a0e:	6705                	lui	a4,0x1
 a10:	00e9f363          	bgeu	s3,a4,a16 <malloc+0x42>
 a14:	6a05                	lui	s4,0x1
 a16:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 a1a:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 a1e:	00000497          	auipc	s1,0x0
 a22:	5fa48493          	addi	s1,s1,1530 # 1018 <freep>
  if(p == (char*)-1)
 a26:	5afd                	li	s5,-1
 a28:	a83d                	j	a66 <malloc+0x92>
 a2a:	f426                	sd	s1,40(sp)
 a2c:	e852                	sd	s4,16(sp)
 a2e:	e456                	sd	s5,8(sp)
 a30:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 a32:	00000797          	auipc	a5,0x0
 a36:	5fe78793          	addi	a5,a5,1534 # 1030 <base>
 a3a:	00000717          	auipc	a4,0x0
 a3e:	5cf73f23          	sd	a5,1502(a4) # 1018 <freep>
 a42:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 a44:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 a48:	b7d1                	j	a0c <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 a4a:	6398                	ld	a4,0(a5)
 a4c:	e118                	sd	a4,0(a0)
 a4e:	a899                	j	aa4 <malloc+0xd0>
  hp->s.size = nu;
 a50:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 a54:	0541                	addi	a0,a0,16
 a56:	ef5ff0ef          	jal	94a <free>
  return freep;
 a5a:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 a5c:	c125                	beqz	a0,abc <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a5e:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a60:	4798                	lw	a4,8(a5)
 a62:	03277163          	bgeu	a4,s2,a84 <malloc+0xb0>
    if(p == freep)
 a66:	6098                	ld	a4,0(s1)
 a68:	853e                	mv	a0,a5
 a6a:	fef71ae3          	bne	a4,a5,a5e <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 a6e:	8552                	mv	a0,s4
 a70:	aefff0ef          	jal	55e <sbrk>
  if(p == (char*)-1)
 a74:	fd551ee3          	bne	a0,s5,a50 <malloc+0x7c>
        return 0;
 a78:	4501                	li	a0,0
 a7a:	74a2                	ld	s1,40(sp)
 a7c:	6a42                	ld	s4,16(sp)
 a7e:	6aa2                	ld	s5,8(sp)
 a80:	6b02                	ld	s6,0(sp)
 a82:	a03d                	j	ab0 <malloc+0xdc>
 a84:	74a2                	ld	s1,40(sp)
 a86:	6a42                	ld	s4,16(sp)
 a88:	6aa2                	ld	s5,8(sp)
 a8a:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 a8c:	fae90fe3          	beq	s2,a4,a4a <malloc+0x76>
        p->s.size -= nunits;
 a90:	4137073b          	subw	a4,a4,s3
 a94:	c798                	sw	a4,8(a5)
        p += p->s.size;
 a96:	02071693          	slli	a3,a4,0x20
 a9a:	01c6d713          	srli	a4,a3,0x1c
 a9e:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 aa0:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 aa4:	00000717          	auipc	a4,0x0
 aa8:	56a73a23          	sd	a0,1396(a4) # 1018 <freep>
      return (void*)(p + 1);
 aac:	01078513          	addi	a0,a5,16
  }
}
 ab0:	70e2                	ld	ra,56(sp)
 ab2:	7442                	ld	s0,48(sp)
 ab4:	7902                	ld	s2,32(sp)
 ab6:	69e2                	ld	s3,24(sp)
 ab8:	6121                	addi	sp,sp,64
 aba:	8082                	ret
 abc:	74a2                	ld	s1,40(sp)
 abe:	6a42                	ld	s4,16(sp)
 ac0:	6aa2                	ld	s5,8(sp)
 ac2:	6b02                	ld	s6,0(sp)
 ac4:	b7f5                	j	ab0 <malloc+0xdc>

0000000000000ac6 <thread_init>:
struct thread *current_thread;
extern void thread_switch(uint64, uint64);
              
void 
thread_init(void)
{
 ac6:	1141                	addi	sp,sp,-16
 ac8:	e406                	sd	ra,8(sp)
 aca:	e022                	sd	s0,0(sp)
 acc:	0800                	addi	s0,sp,16
  // main() is thread 0, which will make the first invocation to
  // thread_schedule(). It needs a stack so that the first thread_switch() can
  // save thread 0's state.
  current_thread = &all_thread[0];
 ace:	00000797          	auipc	a5,0x0
 ad2:	57278793          	addi	a5,a5,1394 # 1040 <all_thread>
 ad6:	00000717          	auipc	a4,0x0
 ada:	54f73523          	sd	a5,1354(a4) # 1020 <current_thread>
  current_thread->state = RUNNING;
 ade:	00002717          	auipc	a4,0x2
 ae2:	56270713          	addi	a4,a4,1378 # 3040 <all_thread+0x2000>
 ae6:	4785                	li	a5,1
 ae8:	c31c                	sw	a5,0(a4)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 aea:	00002797          	auipc	a5,0x2
 aee:	4e678793          	addi	a5,a5,1254 # 2fd0 <all_thread+0x1f90>
  return (struct context *)(top & ~(uint64)0xf);
 af2:	9bc1                	andi	a5,a5,-16
  // Thread 0 runs on the process's own stack, but the first thread_switch()
  // still needs a writable place to save its context.
  current_thread->context = thread_context_slot(current_thread);
 af4:	e71c                	sd	a5,8(a4)
}
 af6:	60a2                	ld	ra,8(sp)
 af8:	6402                	ld	s0,0(sp)
 afa:	0141                	addi	sp,sp,16
 afc:	8082                	ret

0000000000000afe <thread_schedule>:

void 
thread_schedule(void)
{
 afe:	1141                	addi	sp,sp,-16
 b00:	e406                	sd	ra,8(sp)
 b02:	e022                	sd	s0,0(sp)
 b04:	0800                	addi	s0,sp,16
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
 b06:	00000597          	auipc	a1,0x0
 b0a:	51a5b583          	ld	a1,1306(a1) # 1020 <current_thread>
 b0e:	6789                	lui	a5,0x2
 b10:	07c1                	addi	a5,a5,16 # 2010 <all_thread+0xfd0>
 b12:	97ae                	add	a5,a5,a1
 b14:	4711                	li	a4,4
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
 b16:	00008897          	auipc	a7,0x8
 b1a:	56a88893          	addi	a7,a7,1386 # 9080 <all_thread+0x8040>
      t = all_thread;
    if(t->state == RUNNABLE) {
 b1e:	6809                	lui	a6,0x2
 b20:	4509                	li	a0,2
      next_thread = t;
      break;
    }
    t = t + 1;
 b22:	01080613          	addi	a2,a6,16 # 2010 <all_thread+0xfd0>
 b26:	a809                	j	b38 <thread_schedule+0x3a>
    if(t->state == RUNNABLE) {
 b28:	010786b3          	add	a3,a5,a6
 b2c:	4294                	lw	a3,0(a3)
 b2e:	02a68563          	beq	a3,a0,b58 <thread_schedule+0x5a>
    t = t + 1;
 b32:	97b2                	add	a5,a5,a2
  for(int i = 0; i < MAX_THREAD; i++){
 b34:	377d                	addiw	a4,a4,-1
 b36:	cb01                	beqz	a4,b46 <thread_schedule+0x48>
    if(t >= all_thread + MAX_THREAD)
 b38:	ff17e8e3          	bltu	a5,a7,b28 <thread_schedule+0x2a>
      t = all_thread;
 b3c:	00000797          	auipc	a5,0x0
 b40:	50478793          	addi	a5,a5,1284 # 1040 <all_thread>
 b44:	b7d5                	j	b28 <thread_schedule+0x2a>
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
 b46:	00000517          	auipc	a0,0x0
 b4a:	24a50513          	addi	a0,a0,586 # d90 <thread_switch+0x158>
 b4e:	dcbff0ef          	jal	918 <printf>
    exit(-1);
 b52:	557d                	li	a0,-1
 b54:	983ff0ef          	jal	4d6 <exit>
  }

  if (current_thread != next_thread) {         /* switch threads?  */
 b58:	02f58163          	beq	a1,a5,b7a <thread_schedule+0x7c>
    next_thread->state = RUNNING;
 b5c:	6689                	lui	a3,0x2
 b5e:	00d78733          	add	a4,a5,a3
 b62:	4605                	li	a2,1
 b64:	c310                	sw	a2,0(a4)
    t = current_thread;
    current_thread = next_thread;
 b66:	00000617          	auipc	a2,0x0
 b6a:	4af63d23          	sd	a5,1210(a2) # 1020 <current_thread>
    thread_switch((uint64)t->context, (uint64)next_thread->context);
 b6e:	00d587b3          	add	a5,a1,a3
 b72:	670c                	ld	a1,8(a4)
 b74:	6788                	ld	a0,8(a5)
 b76:	0c2000ef          	jal	c38 <thread_switch>
  } else
    next_thread = 0;
}
 b7a:	60a2                	ld	ra,8(sp)
 b7c:	6402                	ld	s0,0(sp)
 b7e:	0141                	addi	sp,sp,16
 b80:	8082                	ret

0000000000000b82 <thread_create>:

void 
thread_create(void (*func)())
{
 b82:	1101                	addi	sp,sp,-32
 b84:	ec06                	sd	ra,24(sp)
 b86:	e822                	sd	s0,16(sp)
 b88:	e426                	sd	s1,8(sp)
 b8a:	e04a                	sd	s2,0(sp)
 b8c:	1000                	addi	s0,sp,32
 b8e:	892a                	mv	s2,a0
  struct thread *t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 b90:	00002797          	auipc	a5,0x2
 b94:	4c078793          	addi	a5,a5,1216 # 3050 <all_thread+0x2010>
 b98:	0000a597          	auipc	a1,0xa
 b9c:	4f858593          	addi	a1,a1,1272 # b090 <all_thread+0xa050>
 ba0:	6609                	lui	a2,0x2
 ba2:	0641                	addi	a2,a2,16 # 2010 <all_thread+0xfd0>
    if (t->state == FREE) break;
 ba4:	873e                	mv	a4,a5
 ba6:	ff07a683          	lw	a3,-16(a5)
 baa:	ce9d                	beqz	a3,be8 <thread_create+0x66>
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 bac:	97b2                	add	a5,a5,a2
 bae:	feb79be3          	bne	a5,a1,ba4 <thread_create+0x22>
  }
  t->state = RUNNABLE;
 bb2:	6489                	lui	s1,0x2
 bb4:	94ba                	add	s1,s1,a4
 bb6:	4789                	li	a5,2
 bb8:	c09c                	sw	a5,0(s1)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 bba:	6789                	lui	a5,0x2
 bbc:	f9078793          	addi	a5,a5,-112 # 1f90 <all_thread+0xf50>
 bc0:	973e                	add	a4,a4,a5
  return (struct context *)(top & ~(uint64)0xf);
 bc2:	ff077513          	andi	a0,a4,-16
  // A never-run thread has no saved state, so construct one: thread_switch()
  // restores ra and sp, and `ret` then starts func on this thread's own stack.
  t->context = thread_context_slot(t);
 bc6:	e488                	sd	a0,8(s1)
  memset(t->context, 0, sizeof(struct context));
 bc8:	07000613          	li	a2,112
 bcc:	4581                	li	a1,0
 bce:	f0aff0ef          	jal	2d8 <memset>
  t->context->ra = (uint64)func;
 bd2:	649c                	ld	a5,8(s1)
 bd4:	0127b023          	sd	s2,0(a5)
  t->context->sp = (uint64)t->context;   // 16-byte aligned, grows down
 bd8:	649c                	ld	a5,8(s1)
 bda:	e79c                	sd	a5,8(a5)
}
 bdc:	60e2                	ld	ra,24(sp)
 bde:	6442                	ld	s0,16(sp)
 be0:	64a2                	ld	s1,8(sp)
 be2:	6902                	ld	s2,0(sp)
 be4:	6105                	addi	sp,sp,32
 be6:	8082                	ret
 be8:	7779                	lui	a4,0xffffe
 bea:	1741                	addi	a4,a4,-16 # ffffffffffffdff0 <all_thread+0xffffffffffffcfb0>
 bec:	973e                	add	a4,a4,a5
 bee:	b7d1                	j	bb2 <thread_create+0x30>

0000000000000bf0 <thread_yield>:

void 
thread_yield(void)
{
 bf0:	1141                	addi	sp,sp,-16
 bf2:	e406                	sd	ra,8(sp)
 bf4:	e022                	sd	s0,0(sp)
 bf6:	0800                	addi	s0,sp,16
  current_thread->state = RUNNABLE;
 bf8:	00000797          	auipc	a5,0x0
 bfc:	4287b783          	ld	a5,1064(a5) # 1020 <current_thread>
 c00:	6709                	lui	a4,0x2
 c02:	97ba                	add	a5,a5,a4
 c04:	4709                	li	a4,2
 c06:	c398                	sw	a4,0(a5)
  thread_schedule();
 c08:	ef7ff0ef          	jal	afe <thread_schedule>
}
 c0c:	60a2                	ld	ra,8(sp)
 c0e:	6402                	ld	s0,0(sp)
 c10:	0141                	addi	sp,sp,16
 c12:	8082                	ret

0000000000000c14 <thread_exit>:

void thread_exit(void) {
 c14:	1141                	addi	sp,sp,-16
 c16:	e406                	sd	ra,8(sp)
 c18:	e022                	sd	s0,0(sp)
 c1a:	0800                	addi	s0,sp,16
  current_thread->state = FREE;
 c1c:	00000797          	auipc	a5,0x0
 c20:	4047b783          	ld	a5,1028(a5) # 1020 <current_thread>
 c24:	6709                	lui	a4,0x2
 c26:	97ba                	add	a5,a5,a4
 c28:	0007a023          	sw	zero,0(a5)
  thread_schedule();
 c2c:	ed3ff0ef          	jal	afe <thread_schedule>
}
 c30:	60a2                	ld	ra,8(sp)
 c32:	6402                	ld	s0,0(sp)
 c34:	0141                	addi	sp,sp,16
 c36:	8082                	ret

0000000000000c38 <thread_switch>:
 c38:	00153023          	sd	ra,0(a0)
 c3c:	00253423          	sd	sp,8(a0)
 c40:	e900                	sd	s0,16(a0)
 c42:	ed04                	sd	s1,24(a0)
 c44:	03253023          	sd	s2,32(a0)
 c48:	03353423          	sd	s3,40(a0)
 c4c:	03453823          	sd	s4,48(a0)
 c50:	03553c23          	sd	s5,56(a0)
 c54:	05653023          	sd	s6,64(a0)
 c58:	05753423          	sd	s7,72(a0)
 c5c:	05853823          	sd	s8,80(a0)
 c60:	05953c23          	sd	s9,88(a0)
 c64:	07a53023          	sd	s10,96(a0)
 c68:	07b53423          	sd	s11,104(a0)
 c6c:	0005b083          	ld	ra,0(a1)
 c70:	0085b103          	ld	sp,8(a1)
 c74:	6980                	ld	s0,16(a1)
 c76:	6d84                	ld	s1,24(a1)
 c78:	0205b903          	ld	s2,32(a1)
 c7c:	0285b983          	ld	s3,40(a1)
 c80:	0305ba03          	ld	s4,48(a1)
 c84:	0385ba83          	ld	s5,56(a1)
 c88:	0405bb03          	ld	s6,64(a1)
 c8c:	0485bb83          	ld	s7,72(a1)
 c90:	0505bc03          	ld	s8,80(a1)
 c94:	0585bc83          	ld	s9,88(a1)
 c98:	0605bd03          	ld	s10,96(a1)
 c9c:	0685bd83          	ld	s11,104(a1)
 ca0:	8082                	ret
