
user/_echo:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
   0:	7139                	addi	sp,sp,-64
   2:	fc06                	sd	ra,56(sp)
   4:	f822                	sd	s0,48(sp)
   6:	f426                	sd	s1,40(sp)
   8:	f04a                	sd	s2,32(sp)
   a:	ec4e                	sd	s3,24(sp)
   c:	e852                	sd	s4,16(sp)
   e:	e456                	sd	s5,8(sp)
  10:	e05a                	sd	s6,0(sp)
  12:	0080                	addi	s0,sp,64
  int i;

  for(i = 1; i < argc; i++){
  14:	4785                	li	a5,1
  16:	06a7d063          	bge	a5,a0,76 <main+0x76>
  1a:	00858493          	addi	s1,a1,8
  1e:	3579                	addiw	a0,a0,-2
  20:	02051793          	slli	a5,a0,0x20
  24:	01d7d513          	srli	a0,a5,0x1d
  28:	00a48ab3          	add	s5,s1,a0
  2c:	05c1                	addi	a1,a1,16
  2e:	00a58a33          	add	s4,a1,a0
    write(1, argv[i], strlen(argv[i]));
  32:	4985                	li	s3,1
    if(i + 1 < argc){
      write(1, " ", 1);
  34:	00001b17          	auipc	s6,0x1
  38:	aacb0b13          	addi	s6,s6,-1364 # ae0 <thread_switch+0x76>
  3c:	a809                	j	4e <main+0x4e>
  3e:	864e                	mv	a2,s3
  40:	85da                	mv	a1,s6
  42:	854e                	mv	a0,s3
  44:	2e4000ef          	jal	328 <write>
  for(i = 1; i < argc; i++){
  48:	04a1                	addi	s1,s1,8
  4a:	03448663          	beq	s1,s4,76 <main+0x76>
    write(1, argv[i], strlen(argv[i]));
  4e:	0004b903          	ld	s2,0(s1)
  52:	854a                	mv	a0,s2
  54:	08a000ef          	jal	de <strlen>
  58:	862a                	mv	a2,a0
  5a:	85ca                	mv	a1,s2
  5c:	854e                	mv	a0,s3
  5e:	2ca000ef          	jal	328 <write>
    if(i + 1 < argc){
  62:	fd549ee3          	bne	s1,s5,3e <main+0x3e>
    } else {
      write(1, "\n", 1);
  66:	4605                	li	a2,1
  68:	00001597          	auipc	a1,0x1
  6c:	a8058593          	addi	a1,a1,-1408 # ae8 <thread_switch+0x7e>
  70:	8532                	mv	a0,a2
  72:	2b6000ef          	jal	328 <write>
    }
  }
  exit(0);
  76:	4501                	li	a0,0
  78:	290000ef          	jal	308 <exit>

000000000000007c <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  7c:	1141                	addi	sp,sp,-16
  7e:	e406                	sd	ra,8(sp)
  80:	e022                	sd	s0,0(sp)
  82:	0800                	addi	s0,sp,16
  extern int main();
  main();
  84:	f7dff0ef          	jal	0 <main>
  exit(0);
  88:	4501                	li	a0,0
  8a:	27e000ef          	jal	308 <exit>

000000000000008e <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  8e:	1141                	addi	sp,sp,-16
  90:	e406                	sd	ra,8(sp)
  92:	e022                	sd	s0,0(sp)
  94:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  96:	87aa                	mv	a5,a0
  98:	0585                	addi	a1,a1,1
  9a:	0785                	addi	a5,a5,1
  9c:	fff5c703          	lbu	a4,-1(a1)
  a0:	fee78fa3          	sb	a4,-1(a5)
  a4:	fb75                	bnez	a4,98 <strcpy+0xa>
    ;
  return os;
}
  a6:	60a2                	ld	ra,8(sp)
  a8:	6402                	ld	s0,0(sp)
  aa:	0141                	addi	sp,sp,16
  ac:	8082                	ret

00000000000000ae <strcmp>:

int
strcmp(const char *p, const char *q)
{
  ae:	1141                	addi	sp,sp,-16
  b0:	e406                	sd	ra,8(sp)
  b2:	e022                	sd	s0,0(sp)
  b4:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  b6:	00054783          	lbu	a5,0(a0)
  ba:	cb91                	beqz	a5,ce <strcmp+0x20>
  bc:	0005c703          	lbu	a4,0(a1)
  c0:	00f71763          	bne	a4,a5,ce <strcmp+0x20>
    p++, q++;
  c4:	0505                	addi	a0,a0,1
  c6:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
  c8:	00054783          	lbu	a5,0(a0)
  cc:	fbe5                	bnez	a5,bc <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
  ce:	0005c503          	lbu	a0,0(a1)
}
  d2:	40a7853b          	subw	a0,a5,a0
  d6:	60a2                	ld	ra,8(sp)
  d8:	6402                	ld	s0,0(sp)
  da:	0141                	addi	sp,sp,16
  dc:	8082                	ret

00000000000000de <strlen>:

uint
strlen(const char *s)
{
  de:	1141                	addi	sp,sp,-16
  e0:	e406                	sd	ra,8(sp)
  e2:	e022                	sd	s0,0(sp)
  e4:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
  e6:	00054783          	lbu	a5,0(a0)
  ea:	cf91                	beqz	a5,106 <strlen+0x28>
  ec:	00150793          	addi	a5,a0,1
  f0:	86be                	mv	a3,a5
  f2:	0785                	addi	a5,a5,1
  f4:	fff7c703          	lbu	a4,-1(a5)
  f8:	ff65                	bnez	a4,f0 <strlen+0x12>
  fa:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
  fe:	60a2                	ld	ra,8(sp)
 100:	6402                	ld	s0,0(sp)
 102:	0141                	addi	sp,sp,16
 104:	8082                	ret
  for(n = 0; s[n]; n++)
 106:	4501                	li	a0,0
 108:	bfdd                	j	fe <strlen+0x20>

000000000000010a <memset>:

void*
memset(void *dst, int c, uint n)
{
 10a:	1141                	addi	sp,sp,-16
 10c:	e406                	sd	ra,8(sp)
 10e:	e022                	sd	s0,0(sp)
 110:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 112:	ca19                	beqz	a2,128 <memset+0x1e>
 114:	87aa                	mv	a5,a0
 116:	1602                	slli	a2,a2,0x20
 118:	9201                	srli	a2,a2,0x20
 11a:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 11e:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 122:	0785                	addi	a5,a5,1
 124:	fee79de3          	bne	a5,a4,11e <memset+0x14>
  }
  return dst;
}
 128:	60a2                	ld	ra,8(sp)
 12a:	6402                	ld	s0,0(sp)
 12c:	0141                	addi	sp,sp,16
 12e:	8082                	ret

0000000000000130 <strchr>:

char*
strchr(const char *s, char c)
{
 130:	1141                	addi	sp,sp,-16
 132:	e406                	sd	ra,8(sp)
 134:	e022                	sd	s0,0(sp)
 136:	0800                	addi	s0,sp,16
  for(; *s; s++)
 138:	00054783          	lbu	a5,0(a0)
 13c:	c799                	beqz	a5,14a <strchr+0x1a>
    if(*s == c)
 13e:	00f58763          	beq	a1,a5,14c <strchr+0x1c>
  for(; *s; s++)
 142:	0505                	addi	a0,a0,1
 144:	00054783          	lbu	a5,0(a0)
 148:	fbfd                	bnez	a5,13e <strchr+0xe>
      return (char*)s;
  return 0;
 14a:	4501                	li	a0,0
}
 14c:	60a2                	ld	ra,8(sp)
 14e:	6402                	ld	s0,0(sp)
 150:	0141                	addi	sp,sp,16
 152:	8082                	ret

0000000000000154 <gets>:

char*
gets(char *buf, int max)
{
 154:	711d                	addi	sp,sp,-96
 156:	ec86                	sd	ra,88(sp)
 158:	e8a2                	sd	s0,80(sp)
 15a:	e4a6                	sd	s1,72(sp)
 15c:	e0ca                	sd	s2,64(sp)
 15e:	fc4e                	sd	s3,56(sp)
 160:	f852                	sd	s4,48(sp)
 162:	f456                	sd	s5,40(sp)
 164:	f05a                	sd	s6,32(sp)
 166:	ec5e                	sd	s7,24(sp)
 168:	e862                	sd	s8,16(sp)
 16a:	1080                	addi	s0,sp,96
 16c:	8baa                	mv	s7,a0
 16e:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 170:	892a                	mv	s2,a0
 172:	4481                	li	s1,0
    cc = read(0, &c, 1);
 174:	faf40b13          	addi	s6,s0,-81
 178:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 17a:	8c26                	mv	s8,s1
 17c:	0014899b          	addiw	s3,s1,1
 180:	84ce                	mv	s1,s3
 182:	0349d863          	bge	s3,s4,1b2 <gets+0x5e>
    cc = read(0, &c, 1);
 186:	8656                	mv	a2,s5
 188:	85da                	mv	a1,s6
 18a:	4501                	li	a0,0
 18c:	194000ef          	jal	320 <read>
    if(cc < 1)
 190:	02a05163          	blez	a0,1b2 <gets+0x5e>
      break;
    buf[i++] = c;
 194:	faf44783          	lbu	a5,-81(s0)
 198:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 19c:	0905                	addi	s2,s2,1
 19e:	ff678713          	addi	a4,a5,-10
 1a2:	00173713          	seqz	a4,a4
 1a6:	17cd                	addi	a5,a5,-13
 1a8:	0017b793          	seqz	a5,a5
 1ac:	8fd9                	or	a5,a5,a4
 1ae:	d7f1                	beqz	a5,17a <gets+0x26>
    buf[i++] = c;
 1b0:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 1b2:	9c5e                	add	s8,s8,s7
 1b4:	000c0023          	sb	zero,0(s8)
  return buf;
}
 1b8:	855e                	mv	a0,s7
 1ba:	60e6                	ld	ra,88(sp)
 1bc:	6446                	ld	s0,80(sp)
 1be:	64a6                	ld	s1,72(sp)
 1c0:	6906                	ld	s2,64(sp)
 1c2:	79e2                	ld	s3,56(sp)
 1c4:	7a42                	ld	s4,48(sp)
 1c6:	7aa2                	ld	s5,40(sp)
 1c8:	7b02                	ld	s6,32(sp)
 1ca:	6be2                	ld	s7,24(sp)
 1cc:	6c42                	ld	s8,16(sp)
 1ce:	6125                	addi	sp,sp,96
 1d0:	8082                	ret

00000000000001d2 <stat>:

int
stat(const char *n, struct stat *st)
{
 1d2:	1101                	addi	sp,sp,-32
 1d4:	ec06                	sd	ra,24(sp)
 1d6:	e822                	sd	s0,16(sp)
 1d8:	e04a                	sd	s2,0(sp)
 1da:	1000                	addi	s0,sp,32
 1dc:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 1de:	4581                	li	a1,0
 1e0:	168000ef          	jal	348 <open>
  if(fd < 0)
 1e4:	02054263          	bltz	a0,208 <stat+0x36>
 1e8:	e426                	sd	s1,8(sp)
 1ea:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 1ec:	85ca                	mv	a1,s2
 1ee:	172000ef          	jal	360 <fstat>
 1f2:	892a                	mv	s2,a0
  close(fd);
 1f4:	8526                	mv	a0,s1
 1f6:	13a000ef          	jal	330 <close>
  return r;
 1fa:	64a2                	ld	s1,8(sp)
}
 1fc:	854a                	mv	a0,s2
 1fe:	60e2                	ld	ra,24(sp)
 200:	6442                	ld	s0,16(sp)
 202:	6902                	ld	s2,0(sp)
 204:	6105                	addi	sp,sp,32
 206:	8082                	ret
    return -1;
 208:	57fd                	li	a5,-1
 20a:	893e                	mv	s2,a5
 20c:	bfc5                	j	1fc <stat+0x2a>

000000000000020e <atoi>:

int
atoi(const char *s)
{
 20e:	1141                	addi	sp,sp,-16
 210:	e406                	sd	ra,8(sp)
 212:	e022                	sd	s0,0(sp)
 214:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 216:	00054683          	lbu	a3,0(a0)
 21a:	fd06879b          	addiw	a5,a3,-48
 21e:	0ff7f793          	zext.b	a5,a5
 222:	4625                	li	a2,9
 224:	02f66963          	bltu	a2,a5,256 <atoi+0x48>
 228:	872a                	mv	a4,a0
  n = 0;
 22a:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 22c:	0705                	addi	a4,a4,1
 22e:	0025179b          	slliw	a5,a0,0x2
 232:	9fa9                	addw	a5,a5,a0
 234:	0017979b          	slliw	a5,a5,0x1
 238:	9fb5                	addw	a5,a5,a3
 23a:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 23e:	00074683          	lbu	a3,0(a4)
 242:	fd06879b          	addiw	a5,a3,-48
 246:	0ff7f793          	zext.b	a5,a5
 24a:	fef671e3          	bgeu	a2,a5,22c <atoi+0x1e>
  return n;
}
 24e:	60a2                	ld	ra,8(sp)
 250:	6402                	ld	s0,0(sp)
 252:	0141                	addi	sp,sp,16
 254:	8082                	ret
  n = 0;
 256:	4501                	li	a0,0
 258:	bfdd                	j	24e <atoi+0x40>

000000000000025a <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 25a:	1141                	addi	sp,sp,-16
 25c:	e406                	sd	ra,8(sp)
 25e:	e022                	sd	s0,0(sp)
 260:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 262:	02b57563          	bgeu	a0,a1,28c <memmove+0x32>
    while(n-- > 0)
 266:	00c05f63          	blez	a2,284 <memmove+0x2a>
 26a:	1602                	slli	a2,a2,0x20
 26c:	9201                	srli	a2,a2,0x20
 26e:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 272:	872a                	mv	a4,a0
      *dst++ = *src++;
 274:	0585                	addi	a1,a1,1
 276:	0705                	addi	a4,a4,1
 278:	fff5c683          	lbu	a3,-1(a1)
 27c:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 280:	fee79ae3          	bne	a5,a4,274 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 284:	60a2                	ld	ra,8(sp)
 286:	6402                	ld	s0,0(sp)
 288:	0141                	addi	sp,sp,16
 28a:	8082                	ret
    while(n-- > 0)
 28c:	fec05ce3          	blez	a2,284 <memmove+0x2a>
    dst += n;
 290:	00c50733          	add	a4,a0,a2
    src += n;
 294:	95b2                	add	a1,a1,a2
 296:	fff6079b          	addiw	a5,a2,-1
 29a:	1782                	slli	a5,a5,0x20
 29c:	9381                	srli	a5,a5,0x20
 29e:	fff7c793          	not	a5,a5
 2a2:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 2a4:	15fd                	addi	a1,a1,-1
 2a6:	177d                	addi	a4,a4,-1
 2a8:	0005c683          	lbu	a3,0(a1)
 2ac:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 2b0:	fef71ae3          	bne	a4,a5,2a4 <memmove+0x4a>
 2b4:	bfc1                	j	284 <memmove+0x2a>

00000000000002b6 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 2b6:	1141                	addi	sp,sp,-16
 2b8:	e406                	sd	ra,8(sp)
 2ba:	e022                	sd	s0,0(sp)
 2bc:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 2be:	ce19                	beqz	a2,2dc <memcmp+0x26>
 2c0:	1602                	slli	a2,a2,0x20
 2c2:	9201                	srli	a2,a2,0x20
 2c4:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 2c8:	00054783          	lbu	a5,0(a0)
 2cc:	0005c703          	lbu	a4,0(a1)
 2d0:	00e79b63          	bne	a5,a4,2e6 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 2d4:	0505                	addi	a0,a0,1
    p2++;
 2d6:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 2d8:	fed518e3          	bne	a0,a3,2c8 <memcmp+0x12>
  }
  return 0;
 2dc:	4501                	li	a0,0
}
 2de:	60a2                	ld	ra,8(sp)
 2e0:	6402                	ld	s0,0(sp)
 2e2:	0141                	addi	sp,sp,16
 2e4:	8082                	ret
      return *p1 - *p2;
 2e6:	40e7853b          	subw	a0,a5,a4
 2ea:	bfd5                	j	2de <memcmp+0x28>

00000000000002ec <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 2ec:	1141                	addi	sp,sp,-16
 2ee:	e406                	sd	ra,8(sp)
 2f0:	e022                	sd	s0,0(sp)
 2f2:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 2f4:	f67ff0ef          	jal	25a <memmove>
}
 2f8:	60a2                	ld	ra,8(sp)
 2fa:	6402                	ld	s0,0(sp)
 2fc:	0141                	addi	sp,sp,16
 2fe:	8082                	ret

0000000000000300 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 300:	4885                	li	a7,1
 ecall
 302:	00000073          	ecall
 ret
 306:	8082                	ret

0000000000000308 <exit>:
.global exit
exit:
 li a7, SYS_exit
 308:	4889                	li	a7,2
 ecall
 30a:	00000073          	ecall
 ret
 30e:	8082                	ret

0000000000000310 <wait>:
.global wait
wait:
 li a7, SYS_wait
 310:	488d                	li	a7,3
 ecall
 312:	00000073          	ecall
 ret
 316:	8082                	ret

0000000000000318 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 318:	4891                	li	a7,4
 ecall
 31a:	00000073          	ecall
 ret
 31e:	8082                	ret

0000000000000320 <read>:
.global read
read:
 li a7, SYS_read
 320:	4895                	li	a7,5
 ecall
 322:	00000073          	ecall
 ret
 326:	8082                	ret

0000000000000328 <write>:
.global write
write:
 li a7, SYS_write
 328:	48c1                	li	a7,16
 ecall
 32a:	00000073          	ecall
 ret
 32e:	8082                	ret

0000000000000330 <close>:
.global close
close:
 li a7, SYS_close
 330:	48d5                	li	a7,21
 ecall
 332:	00000073          	ecall
 ret
 336:	8082                	ret

0000000000000338 <kill>:
.global kill
kill:
 li a7, SYS_kill
 338:	4899                	li	a7,6
 ecall
 33a:	00000073          	ecall
 ret
 33e:	8082                	ret

0000000000000340 <exec>:
.global exec
exec:
 li a7, SYS_exec
 340:	489d                	li	a7,7
 ecall
 342:	00000073          	ecall
 ret
 346:	8082                	ret

0000000000000348 <open>:
.global open
open:
 li a7, SYS_open
 348:	48bd                	li	a7,15
 ecall
 34a:	00000073          	ecall
 ret
 34e:	8082                	ret

0000000000000350 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 350:	48c5                	li	a7,17
 ecall
 352:	00000073          	ecall
 ret
 356:	8082                	ret

0000000000000358 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 358:	48c9                	li	a7,18
 ecall
 35a:	00000073          	ecall
 ret
 35e:	8082                	ret

0000000000000360 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 360:	48a1                	li	a7,8
 ecall
 362:	00000073          	ecall
 ret
 366:	8082                	ret

0000000000000368 <link>:
.global link
link:
 li a7, SYS_link
 368:	48cd                	li	a7,19
 ecall
 36a:	00000073          	ecall
 ret
 36e:	8082                	ret

0000000000000370 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 370:	48d1                	li	a7,20
 ecall
 372:	00000073          	ecall
 ret
 376:	8082                	ret

0000000000000378 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 378:	48a5                	li	a7,9
 ecall
 37a:	00000073          	ecall
 ret
 37e:	8082                	ret

0000000000000380 <dup>:
.global dup
dup:
 li a7, SYS_dup
 380:	48a9                	li	a7,10
 ecall
 382:	00000073          	ecall
 ret
 386:	8082                	ret

0000000000000388 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 388:	48ad                	li	a7,11
 ecall
 38a:	00000073          	ecall
 ret
 38e:	8082                	ret

0000000000000390 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 390:	48b1                	li	a7,12
 ecall
 392:	00000073          	ecall
 ret
 396:	8082                	ret

0000000000000398 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 398:	48b5                	li	a7,13
 ecall
 39a:	00000073          	ecall
 ret
 39e:	8082                	ret

00000000000003a0 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 3a0:	48b9                	li	a7,14
 ecall
 3a2:	00000073          	ecall
 ret
 3a6:	8082                	ret

00000000000003a8 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 3a8:	1101                	addi	sp,sp,-32
 3aa:	ec06                	sd	ra,24(sp)
 3ac:	e822                	sd	s0,16(sp)
 3ae:	1000                	addi	s0,sp,32
 3b0:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 3b4:	4605                	li	a2,1
 3b6:	fef40593          	addi	a1,s0,-17
 3ba:	f6fff0ef          	jal	328 <write>
}
 3be:	60e2                	ld	ra,24(sp)
 3c0:	6442                	ld	s0,16(sp)
 3c2:	6105                	addi	sp,sp,32
 3c4:	8082                	ret

00000000000003c6 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 3c6:	715d                	addi	sp,sp,-80
 3c8:	e486                	sd	ra,72(sp)
 3ca:	e0a2                	sd	s0,64(sp)
 3cc:	f84a                	sd	s2,48(sp)
 3ce:	f44e                	sd	s3,40(sp)
 3d0:	0880                	addi	s0,sp,80
 3d2:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 3d4:	00d036b3          	snez	a3,a3
 3d8:	03f5d793          	srli	a5,a1,0x3f
 3dc:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 3de:	0005871b          	sext.w	a4,a1
  neg = 0;
 3e2:	4301                	li	t1,0
  if(sgn && xx < 0){
 3e4:	c681                	beqz	a3,3ec <printint+0x26>
    x = -xx;
 3e6:	40b0073b          	negw	a4,a1
    neg = 1;
 3ea:	4305                	li	t1,1
  }

  i = 0;
 3ec:	fb840993          	addi	s3,s0,-72
  neg = 0;
 3f0:	85ce                	mv	a1,s3
  i = 0;
 3f2:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 3f4:	00000817          	auipc	a6,0x0
 3f8:	72c80813          	addi	a6,a6,1836 # b20 <digits>
 3fc:	88b6                	mv	a7,a3
 3fe:	0016851b          	addiw	a0,a3,1
 402:	86aa                	mv	a3,a0
 404:	02c777bb          	remuw	a5,a4,a2
 408:	1782                	slli	a5,a5,0x20
 40a:	9381                	srli	a5,a5,0x20
 40c:	97c2                	add	a5,a5,a6
 40e:	0007c783          	lbu	a5,0(a5)
 412:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 416:	87ba                	mv	a5,a4
 418:	02c7573b          	divuw	a4,a4,a2
 41c:	0585                	addi	a1,a1,1
 41e:	fcc7ffe3          	bgeu	a5,a2,3fc <printint+0x36>
  if(neg)
 422:	00030b63          	beqz	t1,438 <printint+0x72>
    buf[i++] = '-';
 426:	fd040793          	addi	a5,s0,-48
 42a:	953e                	add	a0,a0,a5
 42c:	02d00793          	li	a5,45
 430:	fef50423          	sb	a5,-24(a0)
 434:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 438:	02d05563          	blez	a3,462 <printint+0x9c>
 43c:	fc26                	sd	s1,56(sp)
 43e:	36fd                	addiw	a3,a3,-1
 440:	00d984b3          	add	s1,s3,a3
 444:	19fd                	addi	s3,s3,-1
 446:	99b6                	add	s3,s3,a3
 448:	1682                	slli	a3,a3,0x20
 44a:	9281                	srli	a3,a3,0x20
 44c:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 450:	0004c583          	lbu	a1,0(s1)
 454:	854a                	mv	a0,s2
 456:	f53ff0ef          	jal	3a8 <putc>
  while(--i >= 0)
 45a:	14fd                	addi	s1,s1,-1
 45c:	ff349ae3          	bne	s1,s3,450 <printint+0x8a>
 460:	74e2                	ld	s1,56(sp)
}
 462:	60a6                	ld	ra,72(sp)
 464:	6406                	ld	s0,64(sp)
 466:	7942                	ld	s2,48(sp)
 468:	79a2                	ld	s3,40(sp)
 46a:	6161                	addi	sp,sp,80
 46c:	8082                	ret

000000000000046e <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 46e:	711d                	addi	sp,sp,-96
 470:	ec86                	sd	ra,88(sp)
 472:	e8a2                	sd	s0,80(sp)
 474:	e4a6                	sd	s1,72(sp)
 476:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 478:	0005c483          	lbu	s1,0(a1)
 47c:	28048263          	beqz	s1,700 <vprintf+0x292>
 480:	e0ca                	sd	s2,64(sp)
 482:	fc4e                	sd	s3,56(sp)
 484:	f852                	sd	s4,48(sp)
 486:	f456                	sd	s5,40(sp)
 488:	f05a                	sd	s6,32(sp)
 48a:	ec5e                	sd	s7,24(sp)
 48c:	e862                	sd	s8,16(sp)
 48e:	8b2a                	mv	s6,a0
 490:	8a2e                	mv	s4,a1
 492:	8bb2                	mv	s7,a2
  state = 0;
 494:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 496:	4901                	li	s2,0
 498:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 49a:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 49e:	06400c13          	li	s8,100
 4a2:	a00d                	j	4c4 <vprintf+0x56>
        putc(fd, c0);
 4a4:	85a6                	mv	a1,s1
 4a6:	855a                	mv	a0,s6
 4a8:	f01ff0ef          	jal	3a8 <putc>
 4ac:	a019                	j	4b2 <vprintf+0x44>
    } else if(state == '%'){
 4ae:	03598363          	beq	s3,s5,4d4 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 4b2:	0019079b          	addiw	a5,s2,1
 4b6:	893e                	mv	s2,a5
 4b8:	873e                	mv	a4,a5
 4ba:	97d2                	add	a5,a5,s4
 4bc:	0007c483          	lbu	s1,0(a5)
 4c0:	22048963          	beqz	s1,6f2 <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 4c4:	0004879b          	sext.w	a5,s1
    if(state == 0){
 4c8:	fe0993e3          	bnez	s3,4ae <vprintf+0x40>
      if(c0 == '%'){
 4cc:	fd579ce3          	bne	a5,s5,4a4 <vprintf+0x36>
        state = '%';
 4d0:	89be                	mv	s3,a5
 4d2:	b7c5                	j	4b2 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 4d4:	00ea06b3          	add	a3,s4,a4
 4d8:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 4dc:	22060763          	beqz	a2,70a <vprintf+0x29c>
      if(c0 == 'd'){
 4e0:	0b878363          	beq	a5,s8,586 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 4e4:	f9478693          	addi	a3,a5,-108
 4e8:	0016b693          	seqz	a3,a3
 4ec:	f9c60593          	addi	a1,a2,-100
 4f0:	0015b593          	seqz	a1,a1
 4f4:	8df5                	and	a1,a1,a3
 4f6:	e5c5                	bnez	a1,59e <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 4f8:	9752                	add	a4,a4,s4
 4fa:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 4fe:	f9460713          	addi	a4,a2,-108
 502:	00173713          	seqz	a4,a4
 506:	8f75                	and	a4,a4,a3
 508:	f9c50593          	addi	a1,a0,-100
 50c:	0015b593          	seqz	a1,a1
 510:	8df9                	and	a1,a1,a4
 512:	e1dd                	bnez	a1,5b8 <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 514:	07500593          	li	a1,117
 518:	0ab78d63          	beq	a5,a1,5d2 <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 51c:	f8b60593          	addi	a1,a2,-117
 520:	0015b593          	seqz	a1,a1
 524:	8df5                	and	a1,a1,a3
 526:	e1f1                	bnez	a1,5ea <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 528:	f8b50593          	addi	a1,a0,-117
 52c:	0015b593          	seqz	a1,a1
 530:	8df9                	and	a1,a1,a4
 532:	e9e9                	bnez	a1,604 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 534:	07800593          	li	a1,120
 538:	0eb78363          	beq	a5,a1,61e <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 53c:	f8860613          	addi	a2,a2,-120
 540:	00163613          	seqz	a2,a2
 544:	8ef1                	and	a3,a3,a2
 546:	0e069863          	bnez	a3,636 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 54a:	f8850513          	addi	a0,a0,-120
 54e:	00153513          	seqz	a0,a0
 552:	8f69                	and	a4,a4,a0
 554:	0e071e63          	bnez	a4,650 <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 558:	07000713          	li	a4,112
 55c:	10e78663          	beq	a5,a4,668 <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 560:	07300713          	li	a4,115
 564:	14e78663          	beq	a5,a4,6b0 <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 568:	02500713          	li	a4,37
 56c:	16e78e63          	beq	a5,a4,6e8 <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 570:	02500593          	li	a1,37
 574:	855a                	mv	a0,s6
 576:	e33ff0ef          	jal	3a8 <putc>
        putc(fd, c0);
 57a:	85a6                	mv	a1,s1
 57c:	855a                	mv	a0,s6
 57e:	e2bff0ef          	jal	3a8 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 582:	4981                	li	s3,0
 584:	b73d                	j	4b2 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 586:	008b8493          	addi	s1,s7,8
 58a:	4685                	li	a3,1
 58c:	4629                	li	a2,10
 58e:	000ba583          	lw	a1,0(s7)
 592:	855a                	mv	a0,s6
 594:	e33ff0ef          	jal	3c6 <printint>
 598:	8ba6                	mv	s7,s1
      state = 0;
 59a:	4981                	li	s3,0
 59c:	bf19                	j	4b2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 59e:	008b8493          	addi	s1,s7,8
 5a2:	4685                	li	a3,1
 5a4:	4629                	li	a2,10
 5a6:	000bb583          	ld	a1,0(s7)
 5aa:	855a                	mv	a0,s6
 5ac:	e1bff0ef          	jal	3c6 <printint>
        i += 1;
 5b0:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 5b2:	8ba6                	mv	s7,s1
      state = 0;
 5b4:	4981                	li	s3,0
 5b6:	bdf5                	j	4b2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 5b8:	008b8493          	addi	s1,s7,8
 5bc:	4685                	li	a3,1
 5be:	4629                	li	a2,10
 5c0:	000bb583          	ld	a1,0(s7)
 5c4:	855a                	mv	a0,s6
 5c6:	e01ff0ef          	jal	3c6 <printint>
        i += 2;
 5ca:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 5cc:	8ba6                	mv	s7,s1
      state = 0;
 5ce:	4981                	li	s3,0
        i += 2;
 5d0:	b5cd                	j	4b2 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 5d2:	008b8493          	addi	s1,s7,8
 5d6:	4681                	li	a3,0
 5d8:	4629                	li	a2,10
 5da:	000ba583          	lw	a1,0(s7)
 5de:	855a                	mv	a0,s6
 5e0:	de7ff0ef          	jal	3c6 <printint>
 5e4:	8ba6                	mv	s7,s1
      state = 0;
 5e6:	4981                	li	s3,0
 5e8:	b5e9                	j	4b2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 5ea:	008b8493          	addi	s1,s7,8
 5ee:	4681                	li	a3,0
 5f0:	4629                	li	a2,10
 5f2:	000bb583          	ld	a1,0(s7)
 5f6:	855a                	mv	a0,s6
 5f8:	dcfff0ef          	jal	3c6 <printint>
        i += 1;
 5fc:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 5fe:	8ba6                	mv	s7,s1
      state = 0;
 600:	4981                	li	s3,0
 602:	bd45                	j	4b2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 604:	008b8493          	addi	s1,s7,8
 608:	4681                	li	a3,0
 60a:	4629                	li	a2,10
 60c:	000bb583          	ld	a1,0(s7)
 610:	855a                	mv	a0,s6
 612:	db5ff0ef          	jal	3c6 <printint>
        i += 2;
 616:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 618:	8ba6                	mv	s7,s1
      state = 0;
 61a:	4981                	li	s3,0
        i += 2;
 61c:	bd59                	j	4b2 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 61e:	008b8493          	addi	s1,s7,8
 622:	4681                	li	a3,0
 624:	4641                	li	a2,16
 626:	000ba583          	lw	a1,0(s7)
 62a:	855a                	mv	a0,s6
 62c:	d9bff0ef          	jal	3c6 <printint>
 630:	8ba6                	mv	s7,s1
      state = 0;
 632:	4981                	li	s3,0
 634:	bdbd                	j	4b2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 636:	008b8493          	addi	s1,s7,8
 63a:	4681                	li	a3,0
 63c:	4641                	li	a2,16
 63e:	000bb583          	ld	a1,0(s7)
 642:	855a                	mv	a0,s6
 644:	d83ff0ef          	jal	3c6 <printint>
        i += 1;
 648:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 64a:	8ba6                	mv	s7,s1
      state = 0;
 64c:	4981                	li	s3,0
 64e:	b595                	j	4b2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 650:	008b8493          	addi	s1,s7,8
 654:	4641                	li	a2,16
 656:	000bb583          	ld	a1,0(s7)
 65a:	855a                	mv	a0,s6
 65c:	d6bff0ef          	jal	3c6 <printint>
        i += 2;
 660:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 662:	8ba6                	mv	s7,s1
      state = 0;
 664:	4981                	li	s3,0
        i += 2;
 666:	b5b1                	j	4b2 <vprintf+0x44>
 668:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 66a:	008b8793          	addi	a5,s7,8
 66e:	8cbe                	mv	s9,a5
 670:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 674:	03000593          	li	a1,48
 678:	855a                	mv	a0,s6
 67a:	d2fff0ef          	jal	3a8 <putc>
  putc(fd, 'x');
 67e:	07800593          	li	a1,120
 682:	855a                	mv	a0,s6
 684:	d25ff0ef          	jal	3a8 <putc>
 688:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 68a:	00000b97          	auipc	s7,0x0
 68e:	496b8b93          	addi	s7,s7,1174 # b20 <digits>
 692:	03c9d793          	srli	a5,s3,0x3c
 696:	97de                	add	a5,a5,s7
 698:	0007c583          	lbu	a1,0(a5)
 69c:	855a                	mv	a0,s6
 69e:	d0bff0ef          	jal	3a8 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 6a2:	0992                	slli	s3,s3,0x4
 6a4:	34fd                	addiw	s1,s1,-1
 6a6:	f4f5                	bnez	s1,692 <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 6a8:	8be6                	mv	s7,s9
      state = 0;
 6aa:	4981                	li	s3,0
 6ac:	6ca2                	ld	s9,8(sp)
 6ae:	b511                	j	4b2 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 6b0:	008b8993          	addi	s3,s7,8
 6b4:	000bb483          	ld	s1,0(s7)
 6b8:	cc91                	beqz	s1,6d4 <vprintf+0x266>
        for(; *s; s++)
 6ba:	0004c583          	lbu	a1,0(s1)
 6be:	c195                	beqz	a1,6e2 <vprintf+0x274>
          putc(fd, *s);
 6c0:	855a                	mv	a0,s6
 6c2:	ce7ff0ef          	jal	3a8 <putc>
        for(; *s; s++)
 6c6:	0485                	addi	s1,s1,1
 6c8:	0004c583          	lbu	a1,0(s1)
 6cc:	f9f5                	bnez	a1,6c0 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 6ce:	8bce                	mv	s7,s3
      state = 0;
 6d0:	4981                	li	s3,0
 6d2:	b3c5                	j	4b2 <vprintf+0x44>
          s = "(null)";
 6d4:	00000497          	auipc	s1,0x0
 6d8:	41c48493          	addi	s1,s1,1052 # af0 <thread_switch+0x86>
        for(; *s; s++)
 6dc:	02800593          	li	a1,40
 6e0:	b7c5                	j	6c0 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 6e2:	8bce                	mv	s7,s3
      state = 0;
 6e4:	4981                	li	s3,0
 6e6:	b3f1                	j	4b2 <vprintf+0x44>
        putc(fd, '%');
 6e8:	85be                	mv	a1,a5
 6ea:	855a                	mv	a0,s6
 6ec:	cbdff0ef          	jal	3a8 <putc>
 6f0:	bd49                	j	582 <vprintf+0x114>
 6f2:	6906                	ld	s2,64(sp)
 6f4:	79e2                	ld	s3,56(sp)
 6f6:	7a42                	ld	s4,48(sp)
 6f8:	7aa2                	ld	s5,40(sp)
 6fa:	7b02                	ld	s6,32(sp)
 6fc:	6be2                	ld	s7,24(sp)
 6fe:	6c42                	ld	s8,16(sp)
    }
  }
}
 700:	60e6                	ld	ra,88(sp)
 702:	6446                	ld	s0,80(sp)
 704:	64a6                	ld	s1,72(sp)
 706:	6125                	addi	sp,sp,96
 708:	8082                	ret
      if(c0 == 'd'){
 70a:	06400713          	li	a4,100
 70e:	e6e78ce3          	beq	a5,a4,586 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 712:	f9478693          	addi	a3,a5,-108
 716:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 71a:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 71c:	4701                	li	a4,0
 71e:	bbdd                	j	514 <vprintf+0xa6>

0000000000000720 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 720:	715d                	addi	sp,sp,-80
 722:	ec06                	sd	ra,24(sp)
 724:	e822                	sd	s0,16(sp)
 726:	1000                	addi	s0,sp,32
 728:	e010                	sd	a2,0(s0)
 72a:	e414                	sd	a3,8(s0)
 72c:	e818                	sd	a4,16(s0)
 72e:	ec1c                	sd	a5,24(s0)
 730:	03043023          	sd	a6,32(s0)
 734:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 738:	8622                	mv	a2,s0
 73a:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 73e:	d31ff0ef          	jal	46e <vprintf>
}
 742:	60e2                	ld	ra,24(sp)
 744:	6442                	ld	s0,16(sp)
 746:	6161                	addi	sp,sp,80
 748:	8082                	ret

000000000000074a <printf>:

void
printf(const char *fmt, ...)
{
 74a:	711d                	addi	sp,sp,-96
 74c:	ec06                	sd	ra,24(sp)
 74e:	e822                	sd	s0,16(sp)
 750:	1000                	addi	s0,sp,32
 752:	e40c                	sd	a1,8(s0)
 754:	e810                	sd	a2,16(s0)
 756:	ec14                	sd	a3,24(s0)
 758:	f018                	sd	a4,32(s0)
 75a:	f41c                	sd	a5,40(s0)
 75c:	03043823          	sd	a6,48(s0)
 760:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 764:	00840613          	addi	a2,s0,8
 768:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 76c:	85aa                	mv	a1,a0
 76e:	4505                	li	a0,1
 770:	cffff0ef          	jal	46e <vprintf>
}
 774:	60e2                	ld	ra,24(sp)
 776:	6442                	ld	s0,16(sp)
 778:	6125                	addi	sp,sp,96
 77a:	8082                	ret

000000000000077c <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 77c:	1141                	addi	sp,sp,-16
 77e:	e406                	sd	ra,8(sp)
 780:	e022                	sd	s0,0(sp)
 782:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 784:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 788:	00001797          	auipc	a5,0x1
 78c:	8787b783          	ld	a5,-1928(a5) # 1000 <freep>
 790:	a095                	j	7f4 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 792:	ff852583          	lw	a1,-8(a0)
 796:	6390                	ld	a2,0(a5)
 798:	02059813          	slli	a6,a1,0x20
 79c:	01c85693          	srli	a3,a6,0x1c
 7a0:	96ba                	add	a3,a3,a4
 7a2:	02d60563          	beq	a2,a3,7cc <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 7a6:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 7aa:	4790                	lw	a2,8(a5)
 7ac:	02061593          	slli	a1,a2,0x20
 7b0:	01c5d693          	srli	a3,a1,0x1c
 7b4:	96be                	add	a3,a3,a5
 7b6:	02d70263          	beq	a4,a3,7da <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 7ba:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 7bc:	00001717          	auipc	a4,0x1
 7c0:	84f73223          	sd	a5,-1980(a4) # 1000 <freep>
}
 7c4:	60a2                	ld	ra,8(sp)
 7c6:	6402                	ld	s0,0(sp)
 7c8:	0141                	addi	sp,sp,16
 7ca:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 7cc:	4614                	lw	a3,8(a2)
 7ce:	9ead                	addw	a3,a3,a1
 7d0:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 7d4:	6394                	ld	a3,0(a5)
 7d6:	6290                	ld	a2,0(a3)
 7d8:	b7f9                	j	7a6 <free+0x2a>
    p->s.size += bp->s.size;
 7da:	ff852703          	lw	a4,-8(a0)
 7de:	9f31                	addw	a4,a4,a2
 7e0:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 7e2:	ff053703          	ld	a4,-16(a0)
 7e6:	bfd1                	j	7ba <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 7e8:	6394                	ld	a3,0(a5)
 7ea:	00d7e463          	bltu	a5,a3,7f2 <free+0x76>
 7ee:	fad762e3          	bltu	a4,a3,792 <free+0x16>
 7f2:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 7f4:	fee7fae3          	bgeu	a5,a4,7e8 <free+0x6c>
 7f8:	6394                	ld	a3,0(a5)
 7fa:	f8d76ce3          	bltu	a4,a3,792 <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 7fe:	f8d7fae3          	bgeu	a5,a3,792 <free+0x16>
 802:	87b6                	mv	a5,a3
 804:	bfc5                	j	7f4 <free+0x78>

0000000000000806 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 806:	7139                	addi	sp,sp,-64
 808:	fc06                	sd	ra,56(sp)
 80a:	f822                	sd	s0,48(sp)
 80c:	f04a                	sd	s2,32(sp)
 80e:	ec4e                	sd	s3,24(sp)
 810:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 812:	02051993          	slli	s3,a0,0x20
 816:	0209d993          	srli	s3,s3,0x20
 81a:	09bd                	addi	s3,s3,15
 81c:	0049d993          	srli	s3,s3,0x4
 820:	2985                	addiw	s3,s3,1
 822:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 824:	00000517          	auipc	a0,0x0
 828:	7dc53503          	ld	a0,2012(a0) # 1000 <freep>
 82c:	c905                	beqz	a0,85c <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 82e:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 830:	4798                	lw	a4,8(a5)
 832:	09377663          	bgeu	a4,s3,8be <malloc+0xb8>
 836:	f426                	sd	s1,40(sp)
 838:	e852                	sd	s4,16(sp)
 83a:	e456                	sd	s5,8(sp)
 83c:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 83e:	8a4e                	mv	s4,s3
 840:	6705                	lui	a4,0x1
 842:	00e9f363          	bgeu	s3,a4,848 <malloc+0x42>
 846:	6a05                	lui	s4,0x1
 848:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 84c:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 850:	00000497          	auipc	s1,0x0
 854:	7b048493          	addi	s1,s1,1968 # 1000 <freep>
  if(p == (char*)-1)
 858:	5afd                	li	s5,-1
 85a:	a83d                	j	898 <malloc+0x92>
 85c:	f426                	sd	s1,40(sp)
 85e:	e852                	sd	s4,16(sp)
 860:	e456                	sd	s5,8(sp)
 862:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 864:	00000797          	auipc	a5,0x0
 868:	7ac78793          	addi	a5,a5,1964 # 1010 <base>
 86c:	00000717          	auipc	a4,0x0
 870:	78f73a23          	sd	a5,1940(a4) # 1000 <freep>
 874:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 876:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 87a:	b7d1                	j	83e <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 87c:	6398                	ld	a4,0(a5)
 87e:	e118                	sd	a4,0(a0)
 880:	a899                	j	8d6 <malloc+0xd0>
  hp->s.size = nu;
 882:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 886:	0541                	addi	a0,a0,16
 888:	ef5ff0ef          	jal	77c <free>
  return freep;
 88c:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 88e:	c125                	beqz	a0,8ee <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 890:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 892:	4798                	lw	a4,8(a5)
 894:	03277163          	bgeu	a4,s2,8b6 <malloc+0xb0>
    if(p == freep)
 898:	6098                	ld	a4,0(s1)
 89a:	853e                	mv	a0,a5
 89c:	fef71ae3          	bne	a4,a5,890 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 8a0:	8552                	mv	a0,s4
 8a2:	aefff0ef          	jal	390 <sbrk>
  if(p == (char*)-1)
 8a6:	fd551ee3          	bne	a0,s5,882 <malloc+0x7c>
        return 0;
 8aa:	4501                	li	a0,0
 8ac:	74a2                	ld	s1,40(sp)
 8ae:	6a42                	ld	s4,16(sp)
 8b0:	6aa2                	ld	s5,8(sp)
 8b2:	6b02                	ld	s6,0(sp)
 8b4:	a03d                	j	8e2 <malloc+0xdc>
 8b6:	74a2                	ld	s1,40(sp)
 8b8:	6a42                	ld	s4,16(sp)
 8ba:	6aa2                	ld	s5,8(sp)
 8bc:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 8be:	fae90fe3          	beq	s2,a4,87c <malloc+0x76>
        p->s.size -= nunits;
 8c2:	4137073b          	subw	a4,a4,s3
 8c6:	c798                	sw	a4,8(a5)
        p += p->s.size;
 8c8:	02071693          	slli	a3,a4,0x20
 8cc:	01c6d713          	srli	a4,a3,0x1c
 8d0:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 8d2:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 8d6:	00000717          	auipc	a4,0x0
 8da:	72a73523          	sd	a0,1834(a4) # 1000 <freep>
      return (void*)(p + 1);
 8de:	01078513          	addi	a0,a5,16
  }
}
 8e2:	70e2                	ld	ra,56(sp)
 8e4:	7442                	ld	s0,48(sp)
 8e6:	7902                	ld	s2,32(sp)
 8e8:	69e2                	ld	s3,24(sp)
 8ea:	6121                	addi	sp,sp,64
 8ec:	8082                	ret
 8ee:	74a2                	ld	s1,40(sp)
 8f0:	6a42                	ld	s4,16(sp)
 8f2:	6aa2                	ld	s5,8(sp)
 8f4:	6b02                	ld	s6,0(sp)
 8f6:	b7f5                	j	8e2 <malloc+0xdc>

00000000000008f8 <thread_init>:
struct thread *current_thread;
extern void thread_switch(uint64, uint64);
              
void 
thread_init(void)
{
 8f8:	1141                	addi	sp,sp,-16
 8fa:	e406                	sd	ra,8(sp)
 8fc:	e022                	sd	s0,0(sp)
 8fe:	0800                	addi	s0,sp,16
  // main() is thread 0, which will make the first invocation to
  // thread_schedule(). It needs a stack so that the first thread_switch() can
  // save thread 0's state.
  current_thread = &all_thread[0];
 900:	00000797          	auipc	a5,0x0
 904:	72078793          	addi	a5,a5,1824 # 1020 <all_thread>
 908:	00000717          	auipc	a4,0x0
 90c:	70f73023          	sd	a5,1792(a4) # 1008 <current_thread>
  current_thread->state = RUNNING;
 910:	00002717          	auipc	a4,0x2
 914:	71070713          	addi	a4,a4,1808 # 3020 <all_thread+0x2000>
 918:	4785                	li	a5,1
 91a:	c31c                	sw	a5,0(a4)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 91c:	00002797          	auipc	a5,0x2
 920:	69478793          	addi	a5,a5,1684 # 2fb0 <all_thread+0x1f90>
  return (struct context *)(top & ~(uint64)0xf);
 924:	9bc1                	andi	a5,a5,-16
  // Thread 0 runs on the process's own stack, but the first thread_switch()
  // still needs a writable place to save its context.
  current_thread->context = thread_context_slot(current_thread);
 926:	e71c                	sd	a5,8(a4)
}
 928:	60a2                	ld	ra,8(sp)
 92a:	6402                	ld	s0,0(sp)
 92c:	0141                	addi	sp,sp,16
 92e:	8082                	ret

0000000000000930 <thread_schedule>:

void 
thread_schedule(void)
{
 930:	1141                	addi	sp,sp,-16
 932:	e406                	sd	ra,8(sp)
 934:	e022                	sd	s0,0(sp)
 936:	0800                	addi	s0,sp,16
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
 938:	00000597          	auipc	a1,0x0
 93c:	6d05b583          	ld	a1,1744(a1) # 1008 <current_thread>
 940:	6789                	lui	a5,0x2
 942:	07c1                	addi	a5,a5,16 # 2010 <all_thread+0xff0>
 944:	97ae                	add	a5,a5,a1
 946:	4711                	li	a4,4
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
 948:	00008897          	auipc	a7,0x8
 94c:	71888893          	addi	a7,a7,1816 # 9060 <all_thread+0x8040>
      t = all_thread;
    if(t->state == RUNNABLE) {
 950:	6809                	lui	a6,0x2
 952:	4509                	li	a0,2
      next_thread = t;
      break;
    }
    t = t + 1;
 954:	01080613          	addi	a2,a6,16 # 2010 <all_thread+0xff0>
 958:	a809                	j	96a <thread_schedule+0x3a>
    if(t->state == RUNNABLE) {
 95a:	010786b3          	add	a3,a5,a6
 95e:	4294                	lw	a3,0(a3)
 960:	02a68563          	beq	a3,a0,98a <thread_schedule+0x5a>
    t = t + 1;
 964:	97b2                	add	a5,a5,a2
  for(int i = 0; i < MAX_THREAD; i++){
 966:	377d                	addiw	a4,a4,-1
 968:	cb01                	beqz	a4,978 <thread_schedule+0x48>
    if(t >= all_thread + MAX_THREAD)
 96a:	ff17e8e3          	bltu	a5,a7,95a <thread_schedule+0x2a>
      t = all_thread;
 96e:	00000797          	auipc	a5,0x0
 972:	6b278793          	addi	a5,a5,1714 # 1020 <all_thread>
 976:	b7d5                	j	95a <thread_schedule+0x2a>
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
 978:	00000517          	auipc	a0,0x0
 97c:	18050513          	addi	a0,a0,384 # af8 <thread_switch+0x8e>
 980:	dcbff0ef          	jal	74a <printf>
    exit(-1);
 984:	557d                	li	a0,-1
 986:	983ff0ef          	jal	308 <exit>
  }

  if (current_thread != next_thread) {         /* switch threads?  */
 98a:	02f58163          	beq	a1,a5,9ac <thread_schedule+0x7c>
    next_thread->state = RUNNING;
 98e:	6689                	lui	a3,0x2
 990:	00d78733          	add	a4,a5,a3
 994:	4605                	li	a2,1
 996:	c310                	sw	a2,0(a4)
    t = current_thread;
    current_thread = next_thread;
 998:	00000617          	auipc	a2,0x0
 99c:	66f63823          	sd	a5,1648(a2) # 1008 <current_thread>
    thread_switch((uint64)t->context, (uint64)next_thread->context);
 9a0:	00d587b3          	add	a5,a1,a3
 9a4:	670c                	ld	a1,8(a4)
 9a6:	6788                	ld	a0,8(a5)
 9a8:	0c2000ef          	jal	a6a <thread_switch>
  } else
    next_thread = 0;
}
 9ac:	60a2                	ld	ra,8(sp)
 9ae:	6402                	ld	s0,0(sp)
 9b0:	0141                	addi	sp,sp,16
 9b2:	8082                	ret

00000000000009b4 <thread_create>:

void 
thread_create(void (*func)())
{
 9b4:	1101                	addi	sp,sp,-32
 9b6:	ec06                	sd	ra,24(sp)
 9b8:	e822                	sd	s0,16(sp)
 9ba:	e426                	sd	s1,8(sp)
 9bc:	e04a                	sd	s2,0(sp)
 9be:	1000                	addi	s0,sp,32
 9c0:	892a                	mv	s2,a0
  struct thread *t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 9c2:	00002797          	auipc	a5,0x2
 9c6:	66e78793          	addi	a5,a5,1646 # 3030 <all_thread+0x2010>
 9ca:	0000a597          	auipc	a1,0xa
 9ce:	6a658593          	addi	a1,a1,1702 # b070 <all_thread+0xa050>
 9d2:	6609                	lui	a2,0x2
 9d4:	0641                	addi	a2,a2,16 # 2010 <all_thread+0xff0>
    if (t->state == FREE) break;
 9d6:	873e                	mv	a4,a5
 9d8:	ff07a683          	lw	a3,-16(a5)
 9dc:	ce9d                	beqz	a3,a1a <thread_create+0x66>
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 9de:	97b2                	add	a5,a5,a2
 9e0:	feb79be3          	bne	a5,a1,9d6 <thread_create+0x22>
  }
  t->state = RUNNABLE;
 9e4:	6489                	lui	s1,0x2
 9e6:	94ba                	add	s1,s1,a4
 9e8:	4789                	li	a5,2
 9ea:	c09c                	sw	a5,0(s1)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 9ec:	6789                	lui	a5,0x2
 9ee:	f9078793          	addi	a5,a5,-112 # 1f90 <all_thread+0xf70>
 9f2:	973e                	add	a4,a4,a5
  return (struct context *)(top & ~(uint64)0xf);
 9f4:	ff077513          	andi	a0,a4,-16
  // A never-run thread has no saved state, so construct one: thread_switch()
  // restores ra and sp, and `ret` then starts func on this thread's own stack.
  t->context = thread_context_slot(t);
 9f8:	e488                	sd	a0,8(s1)
  memset(t->context, 0, sizeof(struct context));
 9fa:	07000613          	li	a2,112
 9fe:	4581                	li	a1,0
 a00:	f0aff0ef          	jal	10a <memset>
  t->context->ra = (uint64)func;
 a04:	649c                	ld	a5,8(s1)
 a06:	0127b023          	sd	s2,0(a5)
  t->context->sp = (uint64)t->context;   // 16-byte aligned, grows down
 a0a:	649c                	ld	a5,8(s1)
 a0c:	e79c                	sd	a5,8(a5)
}
 a0e:	60e2                	ld	ra,24(sp)
 a10:	6442                	ld	s0,16(sp)
 a12:	64a2                	ld	s1,8(sp)
 a14:	6902                	ld	s2,0(sp)
 a16:	6105                	addi	sp,sp,32
 a18:	8082                	ret
 a1a:	7779                	lui	a4,0xffffe
 a1c:	1741                	addi	a4,a4,-16 # ffffffffffffdff0 <all_thread+0xffffffffffffcfd0>
 a1e:	973e                	add	a4,a4,a5
 a20:	b7d1                	j	9e4 <thread_create+0x30>

0000000000000a22 <thread_yield>:

void 
thread_yield(void)
{
 a22:	1141                	addi	sp,sp,-16
 a24:	e406                	sd	ra,8(sp)
 a26:	e022                	sd	s0,0(sp)
 a28:	0800                	addi	s0,sp,16
  current_thread->state = RUNNABLE;
 a2a:	00000797          	auipc	a5,0x0
 a2e:	5de7b783          	ld	a5,1502(a5) # 1008 <current_thread>
 a32:	6709                	lui	a4,0x2
 a34:	97ba                	add	a5,a5,a4
 a36:	4709                	li	a4,2
 a38:	c398                	sw	a4,0(a5)
  thread_schedule();
 a3a:	ef7ff0ef          	jal	930 <thread_schedule>
}
 a3e:	60a2                	ld	ra,8(sp)
 a40:	6402                	ld	s0,0(sp)
 a42:	0141                	addi	sp,sp,16
 a44:	8082                	ret

0000000000000a46 <thread_exit>:

void thread_exit(void) {
 a46:	1141                	addi	sp,sp,-16
 a48:	e406                	sd	ra,8(sp)
 a4a:	e022                	sd	s0,0(sp)
 a4c:	0800                	addi	s0,sp,16
  current_thread->state = FREE;
 a4e:	00000797          	auipc	a5,0x0
 a52:	5ba7b783          	ld	a5,1466(a5) # 1008 <current_thread>
 a56:	6709                	lui	a4,0x2
 a58:	97ba                	add	a5,a5,a4
 a5a:	0007a023          	sw	zero,0(a5)
  thread_schedule();
 a5e:	ed3ff0ef          	jal	930 <thread_schedule>
}
 a62:	60a2                	ld	ra,8(sp)
 a64:	6402                	ld	s0,0(sp)
 a66:	0141                	addi	sp,sp,16
 a68:	8082                	ret

0000000000000a6a <thread_switch>:
 a6a:	00153023          	sd	ra,0(a0)
 a6e:	00253423          	sd	sp,8(a0)
 a72:	e900                	sd	s0,16(a0)
 a74:	ed04                	sd	s1,24(a0)
 a76:	03253023          	sd	s2,32(a0)
 a7a:	03353423          	sd	s3,40(a0)
 a7e:	03453823          	sd	s4,48(a0)
 a82:	03553c23          	sd	s5,56(a0)
 a86:	05653023          	sd	s6,64(a0)
 a8a:	05753423          	sd	s7,72(a0)
 a8e:	05853823          	sd	s8,80(a0)
 a92:	05953c23          	sd	s9,88(a0)
 a96:	07a53023          	sd	s10,96(a0)
 a9a:	07b53423          	sd	s11,104(a0)
 a9e:	0005b083          	ld	ra,0(a1)
 aa2:	0085b103          	ld	sp,8(a1)
 aa6:	6980                	ld	s0,16(a1)
 aa8:	6d84                	ld	s1,24(a1)
 aaa:	0205b903          	ld	s2,32(a1)
 aae:	0285b983          	ld	s3,40(a1)
 ab2:	0305ba03          	ld	s4,48(a1)
 ab6:	0385ba83          	ld	s5,56(a1)
 aba:	0405bb03          	ld	s6,64(a1)
 abe:	0485bb83          	ld	s7,72(a1)
 ac2:	0505bc03          	ld	s8,80(a1)
 ac6:	0585bc83          	ld	s9,88(a1)
 aca:	0605bd03          	ld	s10,96(a1)
 ace:	0685bd83          	ld	s11,104(a1)
 ad2:	8082                	ret
