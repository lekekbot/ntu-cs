
user/_mkdir:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	1000                	addi	s0,sp,32
  int i;

  if(argc < 2){
   8:	4785                	li	a5,1
   a:	02a7d963          	bge	a5,a0,3c <main+0x3c>
   e:	e426                	sd	s1,8(sp)
  10:	e04a                	sd	s2,0(sp)
  12:	00858493          	addi	s1,a1,8
  16:	ffe5091b          	addiw	s2,a0,-2
  1a:	02091793          	slli	a5,s2,0x20
  1e:	01d7d913          	srli	s2,a5,0x1d
  22:	05c1                	addi	a1,a1,16
  24:	992e                	add	s2,s2,a1
    fprintf(2, "Usage: mkdir files...\n");
    exit(1);
  }

  for(i = 1; i < argc; i++){
    if(mkdir(argv[i]) < 0){
  26:	6088                	ld	a0,0(s1)
  28:	332000ef          	jal	35a <mkdir>
  2c:	02054463          	bltz	a0,54 <main+0x54>
  for(i = 1; i < argc; i++){
  30:	04a1                	addi	s1,s1,8
  32:	ff249ae3          	bne	s1,s2,26 <main+0x26>
      fprintf(2, "mkdir: %s failed to create\n", argv[i]);
      break;
    }
  }

  exit(0);
  36:	4501                	li	a0,0
  38:	2ba000ef          	jal	2f2 <exit>
  3c:	e426                	sd	s1,8(sp)
  3e:	e04a                	sd	s2,0(sp)
    fprintf(2, "Usage: mkdir files...\n");
  40:	00001597          	auipc	a1,0x1
  44:	a8058593          	addi	a1,a1,-1408 # ac0 <thread_switch+0x6c>
  48:	4509                	li	a0,2
  4a:	6c0000ef          	jal	70a <fprintf>
    exit(1);
  4e:	4505                	li	a0,1
  50:	2a2000ef          	jal	2f2 <exit>
      fprintf(2, "mkdir: %s failed to create\n", argv[i]);
  54:	6090                	ld	a2,0(s1)
  56:	00001597          	auipc	a1,0x1
  5a:	a8258593          	addi	a1,a1,-1406 # ad8 <thread_switch+0x84>
  5e:	4509                	li	a0,2
  60:	6aa000ef          	jal	70a <fprintf>
      break;
  64:	bfc9                	j	36 <main+0x36>

0000000000000066 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  66:	1141                	addi	sp,sp,-16
  68:	e406                	sd	ra,8(sp)
  6a:	e022                	sd	s0,0(sp)
  6c:	0800                	addi	s0,sp,16
  extern int main();
  main();
  6e:	f93ff0ef          	jal	0 <main>
  exit(0);
  72:	4501                	li	a0,0
  74:	27e000ef          	jal	2f2 <exit>

0000000000000078 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  78:	1141                	addi	sp,sp,-16
  7a:	e406                	sd	ra,8(sp)
  7c:	e022                	sd	s0,0(sp)
  7e:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  80:	87aa                	mv	a5,a0
  82:	0585                	addi	a1,a1,1
  84:	0785                	addi	a5,a5,1
  86:	fff5c703          	lbu	a4,-1(a1)
  8a:	fee78fa3          	sb	a4,-1(a5)
  8e:	fb75                	bnez	a4,82 <strcpy+0xa>
    ;
  return os;
}
  90:	60a2                	ld	ra,8(sp)
  92:	6402                	ld	s0,0(sp)
  94:	0141                	addi	sp,sp,16
  96:	8082                	ret

0000000000000098 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  98:	1141                	addi	sp,sp,-16
  9a:	e406                	sd	ra,8(sp)
  9c:	e022                	sd	s0,0(sp)
  9e:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  a0:	00054783          	lbu	a5,0(a0)
  a4:	cb91                	beqz	a5,b8 <strcmp+0x20>
  a6:	0005c703          	lbu	a4,0(a1)
  aa:	00f71763          	bne	a4,a5,b8 <strcmp+0x20>
    p++, q++;
  ae:	0505                	addi	a0,a0,1
  b0:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
  b2:	00054783          	lbu	a5,0(a0)
  b6:	fbe5                	bnez	a5,a6 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
  b8:	0005c503          	lbu	a0,0(a1)
}
  bc:	40a7853b          	subw	a0,a5,a0
  c0:	60a2                	ld	ra,8(sp)
  c2:	6402                	ld	s0,0(sp)
  c4:	0141                	addi	sp,sp,16
  c6:	8082                	ret

00000000000000c8 <strlen>:

uint
strlen(const char *s)
{
  c8:	1141                	addi	sp,sp,-16
  ca:	e406                	sd	ra,8(sp)
  cc:	e022                	sd	s0,0(sp)
  ce:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
  d0:	00054783          	lbu	a5,0(a0)
  d4:	cf91                	beqz	a5,f0 <strlen+0x28>
  d6:	00150793          	addi	a5,a0,1
  da:	86be                	mv	a3,a5
  dc:	0785                	addi	a5,a5,1
  de:	fff7c703          	lbu	a4,-1(a5)
  e2:	ff65                	bnez	a4,da <strlen+0x12>
  e4:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
  e8:	60a2                	ld	ra,8(sp)
  ea:	6402                	ld	s0,0(sp)
  ec:	0141                	addi	sp,sp,16
  ee:	8082                	ret
  for(n = 0; s[n]; n++)
  f0:	4501                	li	a0,0
  f2:	bfdd                	j	e8 <strlen+0x20>

00000000000000f4 <memset>:

void*
memset(void *dst, int c, uint n)
{
  f4:	1141                	addi	sp,sp,-16
  f6:	e406                	sd	ra,8(sp)
  f8:	e022                	sd	s0,0(sp)
  fa:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
  fc:	ca19                	beqz	a2,112 <memset+0x1e>
  fe:	87aa                	mv	a5,a0
 100:	1602                	slli	a2,a2,0x20
 102:	9201                	srli	a2,a2,0x20
 104:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 108:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 10c:	0785                	addi	a5,a5,1
 10e:	fee79de3          	bne	a5,a4,108 <memset+0x14>
  }
  return dst;
}
 112:	60a2                	ld	ra,8(sp)
 114:	6402                	ld	s0,0(sp)
 116:	0141                	addi	sp,sp,16
 118:	8082                	ret

000000000000011a <strchr>:

char*
strchr(const char *s, char c)
{
 11a:	1141                	addi	sp,sp,-16
 11c:	e406                	sd	ra,8(sp)
 11e:	e022                	sd	s0,0(sp)
 120:	0800                	addi	s0,sp,16
  for(; *s; s++)
 122:	00054783          	lbu	a5,0(a0)
 126:	c799                	beqz	a5,134 <strchr+0x1a>
    if(*s == c)
 128:	00f58763          	beq	a1,a5,136 <strchr+0x1c>
  for(; *s; s++)
 12c:	0505                	addi	a0,a0,1
 12e:	00054783          	lbu	a5,0(a0)
 132:	fbfd                	bnez	a5,128 <strchr+0xe>
      return (char*)s;
  return 0;
 134:	4501                	li	a0,0
}
 136:	60a2                	ld	ra,8(sp)
 138:	6402                	ld	s0,0(sp)
 13a:	0141                	addi	sp,sp,16
 13c:	8082                	ret

000000000000013e <gets>:

char*
gets(char *buf, int max)
{
 13e:	711d                	addi	sp,sp,-96
 140:	ec86                	sd	ra,88(sp)
 142:	e8a2                	sd	s0,80(sp)
 144:	e4a6                	sd	s1,72(sp)
 146:	e0ca                	sd	s2,64(sp)
 148:	fc4e                	sd	s3,56(sp)
 14a:	f852                	sd	s4,48(sp)
 14c:	f456                	sd	s5,40(sp)
 14e:	f05a                	sd	s6,32(sp)
 150:	ec5e                	sd	s7,24(sp)
 152:	e862                	sd	s8,16(sp)
 154:	1080                	addi	s0,sp,96
 156:	8baa                	mv	s7,a0
 158:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 15a:	892a                	mv	s2,a0
 15c:	4481                	li	s1,0
    cc = read(0, &c, 1);
 15e:	faf40b13          	addi	s6,s0,-81
 162:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 164:	8c26                	mv	s8,s1
 166:	0014899b          	addiw	s3,s1,1
 16a:	84ce                	mv	s1,s3
 16c:	0349d863          	bge	s3,s4,19c <gets+0x5e>
    cc = read(0, &c, 1);
 170:	8656                	mv	a2,s5
 172:	85da                	mv	a1,s6
 174:	4501                	li	a0,0
 176:	194000ef          	jal	30a <read>
    if(cc < 1)
 17a:	02a05163          	blez	a0,19c <gets+0x5e>
      break;
    buf[i++] = c;
 17e:	faf44783          	lbu	a5,-81(s0)
 182:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 186:	0905                	addi	s2,s2,1
 188:	ff678713          	addi	a4,a5,-10
 18c:	00173713          	seqz	a4,a4
 190:	17cd                	addi	a5,a5,-13
 192:	0017b793          	seqz	a5,a5
 196:	8fd9                	or	a5,a5,a4
 198:	d7f1                	beqz	a5,164 <gets+0x26>
    buf[i++] = c;
 19a:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 19c:	9c5e                	add	s8,s8,s7
 19e:	000c0023          	sb	zero,0(s8)
  return buf;
}
 1a2:	855e                	mv	a0,s7
 1a4:	60e6                	ld	ra,88(sp)
 1a6:	6446                	ld	s0,80(sp)
 1a8:	64a6                	ld	s1,72(sp)
 1aa:	6906                	ld	s2,64(sp)
 1ac:	79e2                	ld	s3,56(sp)
 1ae:	7a42                	ld	s4,48(sp)
 1b0:	7aa2                	ld	s5,40(sp)
 1b2:	7b02                	ld	s6,32(sp)
 1b4:	6be2                	ld	s7,24(sp)
 1b6:	6c42                	ld	s8,16(sp)
 1b8:	6125                	addi	sp,sp,96
 1ba:	8082                	ret

00000000000001bc <stat>:

int
stat(const char *n, struct stat *st)
{
 1bc:	1101                	addi	sp,sp,-32
 1be:	ec06                	sd	ra,24(sp)
 1c0:	e822                	sd	s0,16(sp)
 1c2:	e04a                	sd	s2,0(sp)
 1c4:	1000                	addi	s0,sp,32
 1c6:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 1c8:	4581                	li	a1,0
 1ca:	168000ef          	jal	332 <open>
  if(fd < 0)
 1ce:	02054263          	bltz	a0,1f2 <stat+0x36>
 1d2:	e426                	sd	s1,8(sp)
 1d4:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 1d6:	85ca                	mv	a1,s2
 1d8:	172000ef          	jal	34a <fstat>
 1dc:	892a                	mv	s2,a0
  close(fd);
 1de:	8526                	mv	a0,s1
 1e0:	13a000ef          	jal	31a <close>
  return r;
 1e4:	64a2                	ld	s1,8(sp)
}
 1e6:	854a                	mv	a0,s2
 1e8:	60e2                	ld	ra,24(sp)
 1ea:	6442                	ld	s0,16(sp)
 1ec:	6902                	ld	s2,0(sp)
 1ee:	6105                	addi	sp,sp,32
 1f0:	8082                	ret
    return -1;
 1f2:	57fd                	li	a5,-1
 1f4:	893e                	mv	s2,a5
 1f6:	bfc5                	j	1e6 <stat+0x2a>

00000000000001f8 <atoi>:

int
atoi(const char *s)
{
 1f8:	1141                	addi	sp,sp,-16
 1fa:	e406                	sd	ra,8(sp)
 1fc:	e022                	sd	s0,0(sp)
 1fe:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 200:	00054683          	lbu	a3,0(a0)
 204:	fd06879b          	addiw	a5,a3,-48
 208:	0ff7f793          	zext.b	a5,a5
 20c:	4625                	li	a2,9
 20e:	02f66963          	bltu	a2,a5,240 <atoi+0x48>
 212:	872a                	mv	a4,a0
  n = 0;
 214:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 216:	0705                	addi	a4,a4,1
 218:	0025179b          	slliw	a5,a0,0x2
 21c:	9fa9                	addw	a5,a5,a0
 21e:	0017979b          	slliw	a5,a5,0x1
 222:	9fb5                	addw	a5,a5,a3
 224:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 228:	00074683          	lbu	a3,0(a4)
 22c:	fd06879b          	addiw	a5,a3,-48
 230:	0ff7f793          	zext.b	a5,a5
 234:	fef671e3          	bgeu	a2,a5,216 <atoi+0x1e>
  return n;
}
 238:	60a2                	ld	ra,8(sp)
 23a:	6402                	ld	s0,0(sp)
 23c:	0141                	addi	sp,sp,16
 23e:	8082                	ret
  n = 0;
 240:	4501                	li	a0,0
 242:	bfdd                	j	238 <atoi+0x40>

0000000000000244 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 244:	1141                	addi	sp,sp,-16
 246:	e406                	sd	ra,8(sp)
 248:	e022                	sd	s0,0(sp)
 24a:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 24c:	02b57563          	bgeu	a0,a1,276 <memmove+0x32>
    while(n-- > 0)
 250:	00c05f63          	blez	a2,26e <memmove+0x2a>
 254:	1602                	slli	a2,a2,0x20
 256:	9201                	srli	a2,a2,0x20
 258:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 25c:	872a                	mv	a4,a0
      *dst++ = *src++;
 25e:	0585                	addi	a1,a1,1
 260:	0705                	addi	a4,a4,1
 262:	fff5c683          	lbu	a3,-1(a1)
 266:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 26a:	fee79ae3          	bne	a5,a4,25e <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 26e:	60a2                	ld	ra,8(sp)
 270:	6402                	ld	s0,0(sp)
 272:	0141                	addi	sp,sp,16
 274:	8082                	ret
    while(n-- > 0)
 276:	fec05ce3          	blez	a2,26e <memmove+0x2a>
    dst += n;
 27a:	00c50733          	add	a4,a0,a2
    src += n;
 27e:	95b2                	add	a1,a1,a2
 280:	fff6079b          	addiw	a5,a2,-1
 284:	1782                	slli	a5,a5,0x20
 286:	9381                	srli	a5,a5,0x20
 288:	fff7c793          	not	a5,a5
 28c:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 28e:	15fd                	addi	a1,a1,-1
 290:	177d                	addi	a4,a4,-1
 292:	0005c683          	lbu	a3,0(a1)
 296:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 29a:	fef71ae3          	bne	a4,a5,28e <memmove+0x4a>
 29e:	bfc1                	j	26e <memmove+0x2a>

00000000000002a0 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 2a0:	1141                	addi	sp,sp,-16
 2a2:	e406                	sd	ra,8(sp)
 2a4:	e022                	sd	s0,0(sp)
 2a6:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 2a8:	ce19                	beqz	a2,2c6 <memcmp+0x26>
 2aa:	1602                	slli	a2,a2,0x20
 2ac:	9201                	srli	a2,a2,0x20
 2ae:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 2b2:	00054783          	lbu	a5,0(a0)
 2b6:	0005c703          	lbu	a4,0(a1)
 2ba:	00e79b63          	bne	a5,a4,2d0 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 2be:	0505                	addi	a0,a0,1
    p2++;
 2c0:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 2c2:	fed518e3          	bne	a0,a3,2b2 <memcmp+0x12>
  }
  return 0;
 2c6:	4501                	li	a0,0
}
 2c8:	60a2                	ld	ra,8(sp)
 2ca:	6402                	ld	s0,0(sp)
 2cc:	0141                	addi	sp,sp,16
 2ce:	8082                	ret
      return *p1 - *p2;
 2d0:	40e7853b          	subw	a0,a5,a4
 2d4:	bfd5                	j	2c8 <memcmp+0x28>

00000000000002d6 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 2d6:	1141                	addi	sp,sp,-16
 2d8:	e406                	sd	ra,8(sp)
 2da:	e022                	sd	s0,0(sp)
 2dc:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 2de:	f67ff0ef          	jal	244 <memmove>
}
 2e2:	60a2                	ld	ra,8(sp)
 2e4:	6402                	ld	s0,0(sp)
 2e6:	0141                	addi	sp,sp,16
 2e8:	8082                	ret

00000000000002ea <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 2ea:	4885                	li	a7,1
 ecall
 2ec:	00000073          	ecall
 ret
 2f0:	8082                	ret

00000000000002f2 <exit>:
.global exit
exit:
 li a7, SYS_exit
 2f2:	4889                	li	a7,2
 ecall
 2f4:	00000073          	ecall
 ret
 2f8:	8082                	ret

00000000000002fa <wait>:
.global wait
wait:
 li a7, SYS_wait
 2fa:	488d                	li	a7,3
 ecall
 2fc:	00000073          	ecall
 ret
 300:	8082                	ret

0000000000000302 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 302:	4891                	li	a7,4
 ecall
 304:	00000073          	ecall
 ret
 308:	8082                	ret

000000000000030a <read>:
.global read
read:
 li a7, SYS_read
 30a:	4895                	li	a7,5
 ecall
 30c:	00000073          	ecall
 ret
 310:	8082                	ret

0000000000000312 <write>:
.global write
write:
 li a7, SYS_write
 312:	48c1                	li	a7,16
 ecall
 314:	00000073          	ecall
 ret
 318:	8082                	ret

000000000000031a <close>:
.global close
close:
 li a7, SYS_close
 31a:	48d5                	li	a7,21
 ecall
 31c:	00000073          	ecall
 ret
 320:	8082                	ret

0000000000000322 <kill>:
.global kill
kill:
 li a7, SYS_kill
 322:	4899                	li	a7,6
 ecall
 324:	00000073          	ecall
 ret
 328:	8082                	ret

000000000000032a <exec>:
.global exec
exec:
 li a7, SYS_exec
 32a:	489d                	li	a7,7
 ecall
 32c:	00000073          	ecall
 ret
 330:	8082                	ret

0000000000000332 <open>:
.global open
open:
 li a7, SYS_open
 332:	48bd                	li	a7,15
 ecall
 334:	00000073          	ecall
 ret
 338:	8082                	ret

000000000000033a <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 33a:	48c5                	li	a7,17
 ecall
 33c:	00000073          	ecall
 ret
 340:	8082                	ret

0000000000000342 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 342:	48c9                	li	a7,18
 ecall
 344:	00000073          	ecall
 ret
 348:	8082                	ret

000000000000034a <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 34a:	48a1                	li	a7,8
 ecall
 34c:	00000073          	ecall
 ret
 350:	8082                	ret

0000000000000352 <link>:
.global link
link:
 li a7, SYS_link
 352:	48cd                	li	a7,19
 ecall
 354:	00000073          	ecall
 ret
 358:	8082                	ret

000000000000035a <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 35a:	48d1                	li	a7,20
 ecall
 35c:	00000073          	ecall
 ret
 360:	8082                	ret

0000000000000362 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 362:	48a5                	li	a7,9
 ecall
 364:	00000073          	ecall
 ret
 368:	8082                	ret

000000000000036a <dup>:
.global dup
dup:
 li a7, SYS_dup
 36a:	48a9                	li	a7,10
 ecall
 36c:	00000073          	ecall
 ret
 370:	8082                	ret

0000000000000372 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 372:	48ad                	li	a7,11
 ecall
 374:	00000073          	ecall
 ret
 378:	8082                	ret

000000000000037a <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 37a:	48b1                	li	a7,12
 ecall
 37c:	00000073          	ecall
 ret
 380:	8082                	ret

0000000000000382 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 382:	48b5                	li	a7,13
 ecall
 384:	00000073          	ecall
 ret
 388:	8082                	ret

000000000000038a <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 38a:	48b9                	li	a7,14
 ecall
 38c:	00000073          	ecall
 ret
 390:	8082                	ret

0000000000000392 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 392:	1101                	addi	sp,sp,-32
 394:	ec06                	sd	ra,24(sp)
 396:	e822                	sd	s0,16(sp)
 398:	1000                	addi	s0,sp,32
 39a:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 39e:	4605                	li	a2,1
 3a0:	fef40593          	addi	a1,s0,-17
 3a4:	f6fff0ef          	jal	312 <write>
}
 3a8:	60e2                	ld	ra,24(sp)
 3aa:	6442                	ld	s0,16(sp)
 3ac:	6105                	addi	sp,sp,32
 3ae:	8082                	ret

00000000000003b0 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 3b0:	715d                	addi	sp,sp,-80
 3b2:	e486                	sd	ra,72(sp)
 3b4:	e0a2                	sd	s0,64(sp)
 3b6:	f84a                	sd	s2,48(sp)
 3b8:	f44e                	sd	s3,40(sp)
 3ba:	0880                	addi	s0,sp,80
 3bc:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 3be:	00d036b3          	snez	a3,a3
 3c2:	03f5d793          	srli	a5,a1,0x3f
 3c6:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 3c8:	0005871b          	sext.w	a4,a1
  neg = 0;
 3cc:	4301                	li	t1,0
  if(sgn && xx < 0){
 3ce:	c681                	beqz	a3,3d6 <printint+0x26>
    x = -xx;
 3d0:	40b0073b          	negw	a4,a1
    neg = 1;
 3d4:	4305                	li	t1,1
  }

  i = 0;
 3d6:	fb840993          	addi	s3,s0,-72
  neg = 0;
 3da:	85ce                	mv	a1,s3
  i = 0;
 3dc:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 3de:	00000817          	auipc	a6,0x0
 3e2:	74a80813          	addi	a6,a6,1866 # b28 <digits>
 3e6:	88b6                	mv	a7,a3
 3e8:	0016851b          	addiw	a0,a3,1
 3ec:	86aa                	mv	a3,a0
 3ee:	02c777bb          	remuw	a5,a4,a2
 3f2:	1782                	slli	a5,a5,0x20
 3f4:	9381                	srli	a5,a5,0x20
 3f6:	97c2                	add	a5,a5,a6
 3f8:	0007c783          	lbu	a5,0(a5)
 3fc:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 400:	87ba                	mv	a5,a4
 402:	02c7573b          	divuw	a4,a4,a2
 406:	0585                	addi	a1,a1,1
 408:	fcc7ffe3          	bgeu	a5,a2,3e6 <printint+0x36>
  if(neg)
 40c:	00030b63          	beqz	t1,422 <printint+0x72>
    buf[i++] = '-';
 410:	fd040793          	addi	a5,s0,-48
 414:	953e                	add	a0,a0,a5
 416:	02d00793          	li	a5,45
 41a:	fef50423          	sb	a5,-24(a0)
 41e:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 422:	02d05563          	blez	a3,44c <printint+0x9c>
 426:	fc26                	sd	s1,56(sp)
 428:	36fd                	addiw	a3,a3,-1
 42a:	00d984b3          	add	s1,s3,a3
 42e:	19fd                	addi	s3,s3,-1
 430:	99b6                	add	s3,s3,a3
 432:	1682                	slli	a3,a3,0x20
 434:	9281                	srli	a3,a3,0x20
 436:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 43a:	0004c583          	lbu	a1,0(s1)
 43e:	854a                	mv	a0,s2
 440:	f53ff0ef          	jal	392 <putc>
  while(--i >= 0)
 444:	14fd                	addi	s1,s1,-1
 446:	ff349ae3          	bne	s1,s3,43a <printint+0x8a>
 44a:	74e2                	ld	s1,56(sp)
}
 44c:	60a6                	ld	ra,72(sp)
 44e:	6406                	ld	s0,64(sp)
 450:	7942                	ld	s2,48(sp)
 452:	79a2                	ld	s3,40(sp)
 454:	6161                	addi	sp,sp,80
 456:	8082                	ret

0000000000000458 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 458:	711d                	addi	sp,sp,-96
 45a:	ec86                	sd	ra,88(sp)
 45c:	e8a2                	sd	s0,80(sp)
 45e:	e4a6                	sd	s1,72(sp)
 460:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 462:	0005c483          	lbu	s1,0(a1)
 466:	28048263          	beqz	s1,6ea <vprintf+0x292>
 46a:	e0ca                	sd	s2,64(sp)
 46c:	fc4e                	sd	s3,56(sp)
 46e:	f852                	sd	s4,48(sp)
 470:	f456                	sd	s5,40(sp)
 472:	f05a                	sd	s6,32(sp)
 474:	ec5e                	sd	s7,24(sp)
 476:	e862                	sd	s8,16(sp)
 478:	8b2a                	mv	s6,a0
 47a:	8a2e                	mv	s4,a1
 47c:	8bb2                	mv	s7,a2
  state = 0;
 47e:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 480:	4901                	li	s2,0
 482:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 484:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 488:	06400c13          	li	s8,100
 48c:	a00d                	j	4ae <vprintf+0x56>
        putc(fd, c0);
 48e:	85a6                	mv	a1,s1
 490:	855a                	mv	a0,s6
 492:	f01ff0ef          	jal	392 <putc>
 496:	a019                	j	49c <vprintf+0x44>
    } else if(state == '%'){
 498:	03598363          	beq	s3,s5,4be <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 49c:	0019079b          	addiw	a5,s2,1
 4a0:	893e                	mv	s2,a5
 4a2:	873e                	mv	a4,a5
 4a4:	97d2                	add	a5,a5,s4
 4a6:	0007c483          	lbu	s1,0(a5)
 4aa:	22048963          	beqz	s1,6dc <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 4ae:	0004879b          	sext.w	a5,s1
    if(state == 0){
 4b2:	fe0993e3          	bnez	s3,498 <vprintf+0x40>
      if(c0 == '%'){
 4b6:	fd579ce3          	bne	a5,s5,48e <vprintf+0x36>
        state = '%';
 4ba:	89be                	mv	s3,a5
 4bc:	b7c5                	j	49c <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 4be:	00ea06b3          	add	a3,s4,a4
 4c2:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 4c6:	22060763          	beqz	a2,6f4 <vprintf+0x29c>
      if(c0 == 'd'){
 4ca:	0b878363          	beq	a5,s8,570 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 4ce:	f9478693          	addi	a3,a5,-108
 4d2:	0016b693          	seqz	a3,a3
 4d6:	f9c60593          	addi	a1,a2,-100
 4da:	0015b593          	seqz	a1,a1
 4de:	8df5                	and	a1,a1,a3
 4e0:	e5c5                	bnez	a1,588 <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 4e2:	9752                	add	a4,a4,s4
 4e4:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 4e8:	f9460713          	addi	a4,a2,-108
 4ec:	00173713          	seqz	a4,a4
 4f0:	8f75                	and	a4,a4,a3
 4f2:	f9c50593          	addi	a1,a0,-100
 4f6:	0015b593          	seqz	a1,a1
 4fa:	8df9                	and	a1,a1,a4
 4fc:	e1dd                	bnez	a1,5a2 <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 4fe:	07500593          	li	a1,117
 502:	0ab78d63          	beq	a5,a1,5bc <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 506:	f8b60593          	addi	a1,a2,-117
 50a:	0015b593          	seqz	a1,a1
 50e:	8df5                	and	a1,a1,a3
 510:	e1f1                	bnez	a1,5d4 <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 512:	f8b50593          	addi	a1,a0,-117
 516:	0015b593          	seqz	a1,a1
 51a:	8df9                	and	a1,a1,a4
 51c:	e9e9                	bnez	a1,5ee <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 51e:	07800593          	li	a1,120
 522:	0eb78363          	beq	a5,a1,608 <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 526:	f8860613          	addi	a2,a2,-120
 52a:	00163613          	seqz	a2,a2
 52e:	8ef1                	and	a3,a3,a2
 530:	0e069863          	bnez	a3,620 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 534:	f8850513          	addi	a0,a0,-120
 538:	00153513          	seqz	a0,a0
 53c:	8f69                	and	a4,a4,a0
 53e:	0e071e63          	bnez	a4,63a <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 542:	07000713          	li	a4,112
 546:	10e78663          	beq	a5,a4,652 <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 54a:	07300713          	li	a4,115
 54e:	14e78663          	beq	a5,a4,69a <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 552:	02500713          	li	a4,37
 556:	16e78e63          	beq	a5,a4,6d2 <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 55a:	02500593          	li	a1,37
 55e:	855a                	mv	a0,s6
 560:	e33ff0ef          	jal	392 <putc>
        putc(fd, c0);
 564:	85a6                	mv	a1,s1
 566:	855a                	mv	a0,s6
 568:	e2bff0ef          	jal	392 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 56c:	4981                	li	s3,0
 56e:	b73d                	j	49c <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 570:	008b8493          	addi	s1,s7,8
 574:	4685                	li	a3,1
 576:	4629                	li	a2,10
 578:	000ba583          	lw	a1,0(s7)
 57c:	855a                	mv	a0,s6
 57e:	e33ff0ef          	jal	3b0 <printint>
 582:	8ba6                	mv	s7,s1
      state = 0;
 584:	4981                	li	s3,0
 586:	bf19                	j	49c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 588:	008b8493          	addi	s1,s7,8
 58c:	4685                	li	a3,1
 58e:	4629                	li	a2,10
 590:	000bb583          	ld	a1,0(s7)
 594:	855a                	mv	a0,s6
 596:	e1bff0ef          	jal	3b0 <printint>
        i += 1;
 59a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 59c:	8ba6                	mv	s7,s1
      state = 0;
 59e:	4981                	li	s3,0
 5a0:	bdf5                	j	49c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 5a2:	008b8493          	addi	s1,s7,8
 5a6:	4685                	li	a3,1
 5a8:	4629                	li	a2,10
 5aa:	000bb583          	ld	a1,0(s7)
 5ae:	855a                	mv	a0,s6
 5b0:	e01ff0ef          	jal	3b0 <printint>
        i += 2;
 5b4:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 5b6:	8ba6                	mv	s7,s1
      state = 0;
 5b8:	4981                	li	s3,0
        i += 2;
 5ba:	b5cd                	j	49c <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 5bc:	008b8493          	addi	s1,s7,8
 5c0:	4681                	li	a3,0
 5c2:	4629                	li	a2,10
 5c4:	000ba583          	lw	a1,0(s7)
 5c8:	855a                	mv	a0,s6
 5ca:	de7ff0ef          	jal	3b0 <printint>
 5ce:	8ba6                	mv	s7,s1
      state = 0;
 5d0:	4981                	li	s3,0
 5d2:	b5e9                	j	49c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 5d4:	008b8493          	addi	s1,s7,8
 5d8:	4681                	li	a3,0
 5da:	4629                	li	a2,10
 5dc:	000bb583          	ld	a1,0(s7)
 5e0:	855a                	mv	a0,s6
 5e2:	dcfff0ef          	jal	3b0 <printint>
        i += 1;
 5e6:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 5e8:	8ba6                	mv	s7,s1
      state = 0;
 5ea:	4981                	li	s3,0
 5ec:	bd45                	j	49c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 5ee:	008b8493          	addi	s1,s7,8
 5f2:	4681                	li	a3,0
 5f4:	4629                	li	a2,10
 5f6:	000bb583          	ld	a1,0(s7)
 5fa:	855a                	mv	a0,s6
 5fc:	db5ff0ef          	jal	3b0 <printint>
        i += 2;
 600:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 602:	8ba6                	mv	s7,s1
      state = 0;
 604:	4981                	li	s3,0
        i += 2;
 606:	bd59                	j	49c <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 608:	008b8493          	addi	s1,s7,8
 60c:	4681                	li	a3,0
 60e:	4641                	li	a2,16
 610:	000ba583          	lw	a1,0(s7)
 614:	855a                	mv	a0,s6
 616:	d9bff0ef          	jal	3b0 <printint>
 61a:	8ba6                	mv	s7,s1
      state = 0;
 61c:	4981                	li	s3,0
 61e:	bdbd                	j	49c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 620:	008b8493          	addi	s1,s7,8
 624:	4681                	li	a3,0
 626:	4641                	li	a2,16
 628:	000bb583          	ld	a1,0(s7)
 62c:	855a                	mv	a0,s6
 62e:	d83ff0ef          	jal	3b0 <printint>
        i += 1;
 632:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 634:	8ba6                	mv	s7,s1
      state = 0;
 636:	4981                	li	s3,0
 638:	b595                	j	49c <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 63a:	008b8493          	addi	s1,s7,8
 63e:	4641                	li	a2,16
 640:	000bb583          	ld	a1,0(s7)
 644:	855a                	mv	a0,s6
 646:	d6bff0ef          	jal	3b0 <printint>
        i += 2;
 64a:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 64c:	8ba6                	mv	s7,s1
      state = 0;
 64e:	4981                	li	s3,0
        i += 2;
 650:	b5b1                	j	49c <vprintf+0x44>
 652:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 654:	008b8793          	addi	a5,s7,8
 658:	8cbe                	mv	s9,a5
 65a:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 65e:	03000593          	li	a1,48
 662:	855a                	mv	a0,s6
 664:	d2fff0ef          	jal	392 <putc>
  putc(fd, 'x');
 668:	07800593          	li	a1,120
 66c:	855a                	mv	a0,s6
 66e:	d25ff0ef          	jal	392 <putc>
 672:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 674:	00000b97          	auipc	s7,0x0
 678:	4b4b8b93          	addi	s7,s7,1204 # b28 <digits>
 67c:	03c9d793          	srli	a5,s3,0x3c
 680:	97de                	add	a5,a5,s7
 682:	0007c583          	lbu	a1,0(a5)
 686:	855a                	mv	a0,s6
 688:	d0bff0ef          	jal	392 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 68c:	0992                	slli	s3,s3,0x4
 68e:	34fd                	addiw	s1,s1,-1
 690:	f4f5                	bnez	s1,67c <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 692:	8be6                	mv	s7,s9
      state = 0;
 694:	4981                	li	s3,0
 696:	6ca2                	ld	s9,8(sp)
 698:	b511                	j	49c <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 69a:	008b8993          	addi	s3,s7,8
 69e:	000bb483          	ld	s1,0(s7)
 6a2:	cc91                	beqz	s1,6be <vprintf+0x266>
        for(; *s; s++)
 6a4:	0004c583          	lbu	a1,0(s1)
 6a8:	c195                	beqz	a1,6cc <vprintf+0x274>
          putc(fd, *s);
 6aa:	855a                	mv	a0,s6
 6ac:	ce7ff0ef          	jal	392 <putc>
        for(; *s; s++)
 6b0:	0485                	addi	s1,s1,1
 6b2:	0004c583          	lbu	a1,0(s1)
 6b6:	f9f5                	bnez	a1,6aa <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 6b8:	8bce                	mv	s7,s3
      state = 0;
 6ba:	4981                	li	s3,0
 6bc:	b3c5                	j	49c <vprintf+0x44>
          s = "(null)";
 6be:	00000497          	auipc	s1,0x0
 6c2:	43a48493          	addi	s1,s1,1082 # af8 <thread_switch+0xa4>
        for(; *s; s++)
 6c6:	02800593          	li	a1,40
 6ca:	b7c5                	j	6aa <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 6cc:	8bce                	mv	s7,s3
      state = 0;
 6ce:	4981                	li	s3,0
 6d0:	b3f1                	j	49c <vprintf+0x44>
        putc(fd, '%');
 6d2:	85be                	mv	a1,a5
 6d4:	855a                	mv	a0,s6
 6d6:	cbdff0ef          	jal	392 <putc>
 6da:	bd49                	j	56c <vprintf+0x114>
 6dc:	6906                	ld	s2,64(sp)
 6de:	79e2                	ld	s3,56(sp)
 6e0:	7a42                	ld	s4,48(sp)
 6e2:	7aa2                	ld	s5,40(sp)
 6e4:	7b02                	ld	s6,32(sp)
 6e6:	6be2                	ld	s7,24(sp)
 6e8:	6c42                	ld	s8,16(sp)
    }
  }
}
 6ea:	60e6                	ld	ra,88(sp)
 6ec:	6446                	ld	s0,80(sp)
 6ee:	64a6                	ld	s1,72(sp)
 6f0:	6125                	addi	sp,sp,96
 6f2:	8082                	ret
      if(c0 == 'd'){
 6f4:	06400713          	li	a4,100
 6f8:	e6e78ce3          	beq	a5,a4,570 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 6fc:	f9478693          	addi	a3,a5,-108
 700:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 704:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 706:	4701                	li	a4,0
 708:	bbdd                	j	4fe <vprintf+0xa6>

000000000000070a <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 70a:	715d                	addi	sp,sp,-80
 70c:	ec06                	sd	ra,24(sp)
 70e:	e822                	sd	s0,16(sp)
 710:	1000                	addi	s0,sp,32
 712:	e010                	sd	a2,0(s0)
 714:	e414                	sd	a3,8(s0)
 716:	e818                	sd	a4,16(s0)
 718:	ec1c                	sd	a5,24(s0)
 71a:	03043023          	sd	a6,32(s0)
 71e:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 722:	8622                	mv	a2,s0
 724:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 728:	d31ff0ef          	jal	458 <vprintf>
}
 72c:	60e2                	ld	ra,24(sp)
 72e:	6442                	ld	s0,16(sp)
 730:	6161                	addi	sp,sp,80
 732:	8082                	ret

0000000000000734 <printf>:

void
printf(const char *fmt, ...)
{
 734:	711d                	addi	sp,sp,-96
 736:	ec06                	sd	ra,24(sp)
 738:	e822                	sd	s0,16(sp)
 73a:	1000                	addi	s0,sp,32
 73c:	e40c                	sd	a1,8(s0)
 73e:	e810                	sd	a2,16(s0)
 740:	ec14                	sd	a3,24(s0)
 742:	f018                	sd	a4,32(s0)
 744:	f41c                	sd	a5,40(s0)
 746:	03043823          	sd	a6,48(s0)
 74a:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 74e:	00840613          	addi	a2,s0,8
 752:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 756:	85aa                	mv	a1,a0
 758:	4505                	li	a0,1
 75a:	cffff0ef          	jal	458 <vprintf>
}
 75e:	60e2                	ld	ra,24(sp)
 760:	6442                	ld	s0,16(sp)
 762:	6125                	addi	sp,sp,96
 764:	8082                	ret

0000000000000766 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 766:	1141                	addi	sp,sp,-16
 768:	e406                	sd	ra,8(sp)
 76a:	e022                	sd	s0,0(sp)
 76c:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 76e:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 772:	00001797          	auipc	a5,0x1
 776:	88e7b783          	ld	a5,-1906(a5) # 1000 <freep>
 77a:	a095                	j	7de <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 77c:	ff852583          	lw	a1,-8(a0)
 780:	6390                	ld	a2,0(a5)
 782:	02059813          	slli	a6,a1,0x20
 786:	01c85693          	srli	a3,a6,0x1c
 78a:	96ba                	add	a3,a3,a4
 78c:	02d60563          	beq	a2,a3,7b6 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 790:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 794:	4790                	lw	a2,8(a5)
 796:	02061593          	slli	a1,a2,0x20
 79a:	01c5d693          	srli	a3,a1,0x1c
 79e:	96be                	add	a3,a3,a5
 7a0:	02d70263          	beq	a4,a3,7c4 <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 7a4:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 7a6:	00001717          	auipc	a4,0x1
 7aa:	84f73d23          	sd	a5,-1958(a4) # 1000 <freep>
}
 7ae:	60a2                	ld	ra,8(sp)
 7b0:	6402                	ld	s0,0(sp)
 7b2:	0141                	addi	sp,sp,16
 7b4:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 7b6:	4614                	lw	a3,8(a2)
 7b8:	9ead                	addw	a3,a3,a1
 7ba:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 7be:	6394                	ld	a3,0(a5)
 7c0:	6290                	ld	a2,0(a3)
 7c2:	b7f9                	j	790 <free+0x2a>
    p->s.size += bp->s.size;
 7c4:	ff852703          	lw	a4,-8(a0)
 7c8:	9f31                	addw	a4,a4,a2
 7ca:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 7cc:	ff053703          	ld	a4,-16(a0)
 7d0:	bfd1                	j	7a4 <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 7d2:	6394                	ld	a3,0(a5)
 7d4:	00d7e463          	bltu	a5,a3,7dc <free+0x76>
 7d8:	fad762e3          	bltu	a4,a3,77c <free+0x16>
 7dc:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 7de:	fee7fae3          	bgeu	a5,a4,7d2 <free+0x6c>
 7e2:	6394                	ld	a3,0(a5)
 7e4:	f8d76ce3          	bltu	a4,a3,77c <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 7e8:	f8d7fae3          	bgeu	a5,a3,77c <free+0x16>
 7ec:	87b6                	mv	a5,a3
 7ee:	bfc5                	j	7de <free+0x78>

00000000000007f0 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 7f0:	7139                	addi	sp,sp,-64
 7f2:	fc06                	sd	ra,56(sp)
 7f4:	f822                	sd	s0,48(sp)
 7f6:	f04a                	sd	s2,32(sp)
 7f8:	ec4e                	sd	s3,24(sp)
 7fa:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 7fc:	02051993          	slli	s3,a0,0x20
 800:	0209d993          	srli	s3,s3,0x20
 804:	09bd                	addi	s3,s3,15
 806:	0049d993          	srli	s3,s3,0x4
 80a:	2985                	addiw	s3,s3,1
 80c:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 80e:	00000517          	auipc	a0,0x0
 812:	7f253503          	ld	a0,2034(a0) # 1000 <freep>
 816:	c905                	beqz	a0,846 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 818:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 81a:	4798                	lw	a4,8(a5)
 81c:	09377663          	bgeu	a4,s3,8a8 <malloc+0xb8>
 820:	f426                	sd	s1,40(sp)
 822:	e852                	sd	s4,16(sp)
 824:	e456                	sd	s5,8(sp)
 826:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 828:	8a4e                	mv	s4,s3
 82a:	6705                	lui	a4,0x1
 82c:	00e9f363          	bgeu	s3,a4,832 <malloc+0x42>
 830:	6a05                	lui	s4,0x1
 832:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 836:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 83a:	00000497          	auipc	s1,0x0
 83e:	7c648493          	addi	s1,s1,1990 # 1000 <freep>
  if(p == (char*)-1)
 842:	5afd                	li	s5,-1
 844:	a83d                	j	882 <malloc+0x92>
 846:	f426                	sd	s1,40(sp)
 848:	e852                	sd	s4,16(sp)
 84a:	e456                	sd	s5,8(sp)
 84c:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 84e:	00000797          	auipc	a5,0x0
 852:	7c278793          	addi	a5,a5,1986 # 1010 <base>
 856:	00000717          	auipc	a4,0x0
 85a:	7af73523          	sd	a5,1962(a4) # 1000 <freep>
 85e:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 860:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 864:	b7d1                	j	828 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 866:	6398                	ld	a4,0(a5)
 868:	e118                	sd	a4,0(a0)
 86a:	a899                	j	8c0 <malloc+0xd0>
  hp->s.size = nu;
 86c:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 870:	0541                	addi	a0,a0,16
 872:	ef5ff0ef          	jal	766 <free>
  return freep;
 876:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 878:	c125                	beqz	a0,8d8 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 87a:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 87c:	4798                	lw	a4,8(a5)
 87e:	03277163          	bgeu	a4,s2,8a0 <malloc+0xb0>
    if(p == freep)
 882:	6098                	ld	a4,0(s1)
 884:	853e                	mv	a0,a5
 886:	fef71ae3          	bne	a4,a5,87a <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 88a:	8552                	mv	a0,s4
 88c:	aefff0ef          	jal	37a <sbrk>
  if(p == (char*)-1)
 890:	fd551ee3          	bne	a0,s5,86c <malloc+0x7c>
        return 0;
 894:	4501                	li	a0,0
 896:	74a2                	ld	s1,40(sp)
 898:	6a42                	ld	s4,16(sp)
 89a:	6aa2                	ld	s5,8(sp)
 89c:	6b02                	ld	s6,0(sp)
 89e:	a03d                	j	8cc <malloc+0xdc>
 8a0:	74a2                	ld	s1,40(sp)
 8a2:	6a42                	ld	s4,16(sp)
 8a4:	6aa2                	ld	s5,8(sp)
 8a6:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 8a8:	fae90fe3          	beq	s2,a4,866 <malloc+0x76>
        p->s.size -= nunits;
 8ac:	4137073b          	subw	a4,a4,s3
 8b0:	c798                	sw	a4,8(a5)
        p += p->s.size;
 8b2:	02071693          	slli	a3,a4,0x20
 8b6:	01c6d713          	srli	a4,a3,0x1c
 8ba:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 8bc:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 8c0:	00000717          	auipc	a4,0x0
 8c4:	74a73023          	sd	a0,1856(a4) # 1000 <freep>
      return (void*)(p + 1);
 8c8:	01078513          	addi	a0,a5,16
  }
}
 8cc:	70e2                	ld	ra,56(sp)
 8ce:	7442                	ld	s0,48(sp)
 8d0:	7902                	ld	s2,32(sp)
 8d2:	69e2                	ld	s3,24(sp)
 8d4:	6121                	addi	sp,sp,64
 8d6:	8082                	ret
 8d8:	74a2                	ld	s1,40(sp)
 8da:	6a42                	ld	s4,16(sp)
 8dc:	6aa2                	ld	s5,8(sp)
 8de:	6b02                	ld	s6,0(sp)
 8e0:	b7f5                	j	8cc <malloc+0xdc>

00000000000008e2 <thread_init>:
struct thread *current_thread;
extern void thread_switch(uint64, uint64);
              
void 
thread_init(void)
{
 8e2:	1141                	addi	sp,sp,-16
 8e4:	e406                	sd	ra,8(sp)
 8e6:	e022                	sd	s0,0(sp)
 8e8:	0800                	addi	s0,sp,16
  // main() is thread 0, which will make the first invocation to
  // thread_schedule(). It needs a stack so that the first thread_switch() can
  // save thread 0's state.
  current_thread = &all_thread[0];
 8ea:	00000797          	auipc	a5,0x0
 8ee:	73678793          	addi	a5,a5,1846 # 1020 <all_thread>
 8f2:	00000717          	auipc	a4,0x0
 8f6:	70f73b23          	sd	a5,1814(a4) # 1008 <current_thread>
  current_thread->state = RUNNING;
 8fa:	00002717          	auipc	a4,0x2
 8fe:	72670713          	addi	a4,a4,1830 # 3020 <all_thread+0x2000>
 902:	4785                	li	a5,1
 904:	c31c                	sw	a5,0(a4)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 906:	00002797          	auipc	a5,0x2
 90a:	6aa78793          	addi	a5,a5,1706 # 2fb0 <all_thread+0x1f90>
  return (struct context *)(top & ~(uint64)0xf);
 90e:	9bc1                	andi	a5,a5,-16
  // Thread 0 runs on the process's own stack, but the first thread_switch()
  // still needs a writable place to save its context.
  current_thread->context = thread_context_slot(current_thread);
 910:	e71c                	sd	a5,8(a4)
}
 912:	60a2                	ld	ra,8(sp)
 914:	6402                	ld	s0,0(sp)
 916:	0141                	addi	sp,sp,16
 918:	8082                	ret

000000000000091a <thread_schedule>:

void 
thread_schedule(void)
{
 91a:	1141                	addi	sp,sp,-16
 91c:	e406                	sd	ra,8(sp)
 91e:	e022                	sd	s0,0(sp)
 920:	0800                	addi	s0,sp,16
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
 922:	00000597          	auipc	a1,0x0
 926:	6e65b583          	ld	a1,1766(a1) # 1008 <current_thread>
 92a:	6789                	lui	a5,0x2
 92c:	07c1                	addi	a5,a5,16 # 2010 <all_thread+0xff0>
 92e:	97ae                	add	a5,a5,a1
 930:	4711                	li	a4,4
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
 932:	00008897          	auipc	a7,0x8
 936:	72e88893          	addi	a7,a7,1838 # 9060 <all_thread+0x8040>
      t = all_thread;
    if(t->state == RUNNABLE) {
 93a:	6809                	lui	a6,0x2
 93c:	4509                	li	a0,2
      next_thread = t;
      break;
    }
    t = t + 1;
 93e:	01080613          	addi	a2,a6,16 # 2010 <all_thread+0xff0>
 942:	a809                	j	954 <thread_schedule+0x3a>
    if(t->state == RUNNABLE) {
 944:	010786b3          	add	a3,a5,a6
 948:	4294                	lw	a3,0(a3)
 94a:	02a68563          	beq	a3,a0,974 <thread_schedule+0x5a>
    t = t + 1;
 94e:	97b2                	add	a5,a5,a2
  for(int i = 0; i < MAX_THREAD; i++){
 950:	377d                	addiw	a4,a4,-1
 952:	cb01                	beqz	a4,962 <thread_schedule+0x48>
    if(t >= all_thread + MAX_THREAD)
 954:	ff17e8e3          	bltu	a5,a7,944 <thread_schedule+0x2a>
      t = all_thread;
 958:	00000797          	auipc	a5,0x0
 95c:	6c878793          	addi	a5,a5,1736 # 1020 <all_thread>
 960:	b7d5                	j	944 <thread_schedule+0x2a>
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
 962:	00000517          	auipc	a0,0x0
 966:	19e50513          	addi	a0,a0,414 # b00 <thread_switch+0xac>
 96a:	dcbff0ef          	jal	734 <printf>
    exit(-1);
 96e:	557d                	li	a0,-1
 970:	983ff0ef          	jal	2f2 <exit>
  }

  if (current_thread != next_thread) {         /* switch threads?  */
 974:	02f58163          	beq	a1,a5,996 <thread_schedule+0x7c>
    next_thread->state = RUNNING;
 978:	6689                	lui	a3,0x2
 97a:	00d78733          	add	a4,a5,a3
 97e:	4605                	li	a2,1
 980:	c310                	sw	a2,0(a4)
    t = current_thread;
    current_thread = next_thread;
 982:	00000617          	auipc	a2,0x0
 986:	68f63323          	sd	a5,1670(a2) # 1008 <current_thread>
    thread_switch((uint64)t->context, (uint64)next_thread->context);
 98a:	00d587b3          	add	a5,a1,a3
 98e:	670c                	ld	a1,8(a4)
 990:	6788                	ld	a0,8(a5)
 992:	0c2000ef          	jal	a54 <thread_switch>
  } else
    next_thread = 0;
}
 996:	60a2                	ld	ra,8(sp)
 998:	6402                	ld	s0,0(sp)
 99a:	0141                	addi	sp,sp,16
 99c:	8082                	ret

000000000000099e <thread_create>:

void 
thread_create(void (*func)())
{
 99e:	1101                	addi	sp,sp,-32
 9a0:	ec06                	sd	ra,24(sp)
 9a2:	e822                	sd	s0,16(sp)
 9a4:	e426                	sd	s1,8(sp)
 9a6:	e04a                	sd	s2,0(sp)
 9a8:	1000                	addi	s0,sp,32
 9aa:	892a                	mv	s2,a0
  struct thread *t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 9ac:	00002797          	auipc	a5,0x2
 9b0:	68478793          	addi	a5,a5,1668 # 3030 <all_thread+0x2010>
 9b4:	0000a597          	auipc	a1,0xa
 9b8:	6bc58593          	addi	a1,a1,1724 # b070 <all_thread+0xa050>
 9bc:	6609                	lui	a2,0x2
 9be:	0641                	addi	a2,a2,16 # 2010 <all_thread+0xff0>
    if (t->state == FREE) break;
 9c0:	873e                	mv	a4,a5
 9c2:	ff07a683          	lw	a3,-16(a5)
 9c6:	ce9d                	beqz	a3,a04 <thread_create+0x66>
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 9c8:	97b2                	add	a5,a5,a2
 9ca:	feb79be3          	bne	a5,a1,9c0 <thread_create+0x22>
  }
  t->state = RUNNABLE;
 9ce:	6489                	lui	s1,0x2
 9d0:	94ba                	add	s1,s1,a4
 9d2:	4789                	li	a5,2
 9d4:	c09c                	sw	a5,0(s1)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 9d6:	6789                	lui	a5,0x2
 9d8:	f9078793          	addi	a5,a5,-112 # 1f90 <all_thread+0xf70>
 9dc:	973e                	add	a4,a4,a5
  return (struct context *)(top & ~(uint64)0xf);
 9de:	ff077513          	andi	a0,a4,-16
  // A never-run thread has no saved state, so construct one: thread_switch()
  // restores ra and sp, and `ret` then starts func on this thread's own stack.
  t->context = thread_context_slot(t);
 9e2:	e488                	sd	a0,8(s1)
  memset(t->context, 0, sizeof(struct context));
 9e4:	07000613          	li	a2,112
 9e8:	4581                	li	a1,0
 9ea:	f0aff0ef          	jal	f4 <memset>
  t->context->ra = (uint64)func;
 9ee:	649c                	ld	a5,8(s1)
 9f0:	0127b023          	sd	s2,0(a5)
  t->context->sp = (uint64)t->context;   // 16-byte aligned, grows down
 9f4:	649c                	ld	a5,8(s1)
 9f6:	e79c                	sd	a5,8(a5)
}
 9f8:	60e2                	ld	ra,24(sp)
 9fa:	6442                	ld	s0,16(sp)
 9fc:	64a2                	ld	s1,8(sp)
 9fe:	6902                	ld	s2,0(sp)
 a00:	6105                	addi	sp,sp,32
 a02:	8082                	ret
 a04:	7779                	lui	a4,0xffffe
 a06:	1741                	addi	a4,a4,-16 # ffffffffffffdff0 <all_thread+0xffffffffffffcfd0>
 a08:	973e                	add	a4,a4,a5
 a0a:	b7d1                	j	9ce <thread_create+0x30>

0000000000000a0c <thread_yield>:

void 
thread_yield(void)
{
 a0c:	1141                	addi	sp,sp,-16
 a0e:	e406                	sd	ra,8(sp)
 a10:	e022                	sd	s0,0(sp)
 a12:	0800                	addi	s0,sp,16
  current_thread->state = RUNNABLE;
 a14:	00000797          	auipc	a5,0x0
 a18:	5f47b783          	ld	a5,1524(a5) # 1008 <current_thread>
 a1c:	6709                	lui	a4,0x2
 a1e:	97ba                	add	a5,a5,a4
 a20:	4709                	li	a4,2
 a22:	c398                	sw	a4,0(a5)
  thread_schedule();
 a24:	ef7ff0ef          	jal	91a <thread_schedule>
}
 a28:	60a2                	ld	ra,8(sp)
 a2a:	6402                	ld	s0,0(sp)
 a2c:	0141                	addi	sp,sp,16
 a2e:	8082                	ret

0000000000000a30 <thread_exit>:

void thread_exit(void) {
 a30:	1141                	addi	sp,sp,-16
 a32:	e406                	sd	ra,8(sp)
 a34:	e022                	sd	s0,0(sp)
 a36:	0800                	addi	s0,sp,16
  current_thread->state = FREE;
 a38:	00000797          	auipc	a5,0x0
 a3c:	5d07b783          	ld	a5,1488(a5) # 1008 <current_thread>
 a40:	6709                	lui	a4,0x2
 a42:	97ba                	add	a5,a5,a4
 a44:	0007a023          	sw	zero,0(a5)
  thread_schedule();
 a48:	ed3ff0ef          	jal	91a <thread_schedule>
}
 a4c:	60a2                	ld	ra,8(sp)
 a4e:	6402                	ld	s0,0(sp)
 a50:	0141                	addi	sp,sp,16
 a52:	8082                	ret

0000000000000a54 <thread_switch>:
 a54:	00153023          	sd	ra,0(a0)
 a58:	00253423          	sd	sp,8(a0)
 a5c:	e900                	sd	s0,16(a0)
 a5e:	ed04                	sd	s1,24(a0)
 a60:	03253023          	sd	s2,32(a0)
 a64:	03353423          	sd	s3,40(a0)
 a68:	03453823          	sd	s4,48(a0)
 a6c:	03553c23          	sd	s5,56(a0)
 a70:	05653023          	sd	s6,64(a0)
 a74:	05753423          	sd	s7,72(a0)
 a78:	05853823          	sd	s8,80(a0)
 a7c:	05953c23          	sd	s9,88(a0)
 a80:	07a53023          	sd	s10,96(a0)
 a84:	07b53423          	sd	s11,104(a0)
 a88:	0005b083          	ld	ra,0(a1)
 a8c:	0085b103          	ld	sp,8(a1)
 a90:	6980                	ld	s0,16(a1)
 a92:	6d84                	ld	s1,24(a1)
 a94:	0205b903          	ld	s2,32(a1)
 a98:	0285b983          	ld	s3,40(a1)
 a9c:	0305ba03          	ld	s4,48(a1)
 aa0:	0385ba83          	ld	s5,56(a1)
 aa4:	0405bb03          	ld	s6,64(a1)
 aa8:	0485bb83          	ld	s7,72(a1)
 aac:	0505bc03          	ld	s8,80(a1)
 ab0:	0585bc83          	ld	s9,88(a1)
 ab4:	0605bd03          	ld	s10,96(a1)
 ab8:	0685bd83          	ld	s11,104(a1)
 abc:	8082                	ret
