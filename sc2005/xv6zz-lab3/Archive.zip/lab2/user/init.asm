
user/_init:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:

char *argv[] = { "sh", 0 };

int
main(void)
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	e426                	sd	s1,8(sp)
   8:	e04a                	sd	s2,0(sp)
   a:	1000                	addi	s0,sp,32
  int pid, wpid;

  if(open("console", O_RDWR) < 0){
   c:	4589                	li	a1,2
   e:	00001517          	auipc	a0,0x1
  12:	b1250513          	addi	a0,a0,-1262 # b20 <thread_switch+0x76>
  16:	372000ef          	jal	388 <open>
  1a:	04054563          	bltz	a0,64 <main+0x64>
    mknod("console", CONSOLE, 0);
    open("console", O_RDWR);
  }
  dup(0);  // stdout
  1e:	4501                	li	a0,0
  20:	3a0000ef          	jal	3c0 <dup>
  dup(0);  // stderr
  24:	4501                	li	a0,0
  26:	39a000ef          	jal	3c0 <dup>

  for(;;){
    printf("init: starting sh\n");
  2a:	00001917          	auipc	s2,0x1
  2e:	afe90913          	addi	s2,s2,-1282 # b28 <thread_switch+0x7e>
  32:	854a                	mv	a0,s2
  34:	756000ef          	jal	78a <printf>
    pid = fork();
  38:	308000ef          	jal	340 <fork>
  3c:	84aa                	mv	s1,a0
    if(pid < 0){
  3e:	04054363          	bltz	a0,84 <main+0x84>
      printf("init: fork failed\n");
      exit(1);
    }
    if(pid == 0){
  42:	c931                	beqz	a0,96 <main+0x96>
    }

    for(;;){
      // this call to wait() returns if the shell exits,
      // or if a parentless process exits.
      wpid = wait((int *) 0);
  44:	4501                	li	a0,0
  46:	30a000ef          	jal	350 <wait>
      if(wpid == pid){
  4a:	fea484e3          	beq	s1,a0,32 <main+0x32>
        // the shell exited; restart it.
        break;
      } else if(wpid < 0){
  4e:	fe055be3          	bgez	a0,44 <main+0x44>
        printf("init: wait returned an error\n");
  52:	00001517          	auipc	a0,0x1
  56:	b2650513          	addi	a0,a0,-1242 # b78 <thread_switch+0xce>
  5a:	730000ef          	jal	78a <printf>
        exit(1);
  5e:	4505                	li	a0,1
  60:	2e8000ef          	jal	348 <exit>
    mknod("console", CONSOLE, 0);
  64:	4601                	li	a2,0
  66:	4585                	li	a1,1
  68:	00001517          	auipc	a0,0x1
  6c:	ab850513          	addi	a0,a0,-1352 # b20 <thread_switch+0x76>
  70:	320000ef          	jal	390 <mknod>
    open("console", O_RDWR);
  74:	4589                	li	a1,2
  76:	00001517          	auipc	a0,0x1
  7a:	aaa50513          	addi	a0,a0,-1366 # b20 <thread_switch+0x76>
  7e:	30a000ef          	jal	388 <open>
  82:	bf71                	j	1e <main+0x1e>
      printf("init: fork failed\n");
  84:	00001517          	auipc	a0,0x1
  88:	abc50513          	addi	a0,a0,-1348 # b40 <thread_switch+0x96>
  8c:	6fe000ef          	jal	78a <printf>
      exit(1);
  90:	4505                	li	a0,1
  92:	2b6000ef          	jal	348 <exit>
      exec("sh", argv);
  96:	00001597          	auipc	a1,0x1
  9a:	f6a58593          	addi	a1,a1,-150 # 1000 <argv>
  9e:	00001517          	auipc	a0,0x1
  a2:	aba50513          	addi	a0,a0,-1350 # b58 <thread_switch+0xae>
  a6:	2da000ef          	jal	380 <exec>
      printf("init: exec sh failed\n");
  aa:	00001517          	auipc	a0,0x1
  ae:	ab650513          	addi	a0,a0,-1354 # b60 <thread_switch+0xb6>
  b2:	6d8000ef          	jal	78a <printf>
      exit(1);
  b6:	4505                	li	a0,1
  b8:	290000ef          	jal	348 <exit>

00000000000000bc <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  bc:	1141                	addi	sp,sp,-16
  be:	e406                	sd	ra,8(sp)
  c0:	e022                	sd	s0,0(sp)
  c2:	0800                	addi	s0,sp,16
  extern int main();
  main();
  c4:	f3dff0ef          	jal	0 <main>
  exit(0);
  c8:	4501                	li	a0,0
  ca:	27e000ef          	jal	348 <exit>

00000000000000ce <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  ce:	1141                	addi	sp,sp,-16
  d0:	e406                	sd	ra,8(sp)
  d2:	e022                	sd	s0,0(sp)
  d4:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  d6:	87aa                	mv	a5,a0
  d8:	0585                	addi	a1,a1,1
  da:	0785                	addi	a5,a5,1
  dc:	fff5c703          	lbu	a4,-1(a1)
  e0:	fee78fa3          	sb	a4,-1(a5)
  e4:	fb75                	bnez	a4,d8 <strcpy+0xa>
    ;
  return os;
}
  e6:	60a2                	ld	ra,8(sp)
  e8:	6402                	ld	s0,0(sp)
  ea:	0141                	addi	sp,sp,16
  ec:	8082                	ret

00000000000000ee <strcmp>:

int
strcmp(const char *p, const char *q)
{
  ee:	1141                	addi	sp,sp,-16
  f0:	e406                	sd	ra,8(sp)
  f2:	e022                	sd	s0,0(sp)
  f4:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  f6:	00054783          	lbu	a5,0(a0)
  fa:	cb91                	beqz	a5,10e <strcmp+0x20>
  fc:	0005c703          	lbu	a4,0(a1)
 100:	00f71763          	bne	a4,a5,10e <strcmp+0x20>
    p++, q++;
 104:	0505                	addi	a0,a0,1
 106:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 108:	00054783          	lbu	a5,0(a0)
 10c:	fbe5                	bnez	a5,fc <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 10e:	0005c503          	lbu	a0,0(a1)
}
 112:	40a7853b          	subw	a0,a5,a0
 116:	60a2                	ld	ra,8(sp)
 118:	6402                	ld	s0,0(sp)
 11a:	0141                	addi	sp,sp,16
 11c:	8082                	ret

000000000000011e <strlen>:

uint
strlen(const char *s)
{
 11e:	1141                	addi	sp,sp,-16
 120:	e406                	sd	ra,8(sp)
 122:	e022                	sd	s0,0(sp)
 124:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 126:	00054783          	lbu	a5,0(a0)
 12a:	cf91                	beqz	a5,146 <strlen+0x28>
 12c:	00150793          	addi	a5,a0,1
 130:	86be                	mv	a3,a5
 132:	0785                	addi	a5,a5,1
 134:	fff7c703          	lbu	a4,-1(a5)
 138:	ff65                	bnez	a4,130 <strlen+0x12>
 13a:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 13e:	60a2                	ld	ra,8(sp)
 140:	6402                	ld	s0,0(sp)
 142:	0141                	addi	sp,sp,16
 144:	8082                	ret
  for(n = 0; s[n]; n++)
 146:	4501                	li	a0,0
 148:	bfdd                	j	13e <strlen+0x20>

000000000000014a <memset>:

void*
memset(void *dst, int c, uint n)
{
 14a:	1141                	addi	sp,sp,-16
 14c:	e406                	sd	ra,8(sp)
 14e:	e022                	sd	s0,0(sp)
 150:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 152:	ca19                	beqz	a2,168 <memset+0x1e>
 154:	87aa                	mv	a5,a0
 156:	1602                	slli	a2,a2,0x20
 158:	9201                	srli	a2,a2,0x20
 15a:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 15e:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 162:	0785                	addi	a5,a5,1
 164:	fee79de3          	bne	a5,a4,15e <memset+0x14>
  }
  return dst;
}
 168:	60a2                	ld	ra,8(sp)
 16a:	6402                	ld	s0,0(sp)
 16c:	0141                	addi	sp,sp,16
 16e:	8082                	ret

0000000000000170 <strchr>:

char*
strchr(const char *s, char c)
{
 170:	1141                	addi	sp,sp,-16
 172:	e406                	sd	ra,8(sp)
 174:	e022                	sd	s0,0(sp)
 176:	0800                	addi	s0,sp,16
  for(; *s; s++)
 178:	00054783          	lbu	a5,0(a0)
 17c:	c799                	beqz	a5,18a <strchr+0x1a>
    if(*s == c)
 17e:	00f58763          	beq	a1,a5,18c <strchr+0x1c>
  for(; *s; s++)
 182:	0505                	addi	a0,a0,1
 184:	00054783          	lbu	a5,0(a0)
 188:	fbfd                	bnez	a5,17e <strchr+0xe>
      return (char*)s;
  return 0;
 18a:	4501                	li	a0,0
}
 18c:	60a2                	ld	ra,8(sp)
 18e:	6402                	ld	s0,0(sp)
 190:	0141                	addi	sp,sp,16
 192:	8082                	ret

0000000000000194 <gets>:

char*
gets(char *buf, int max)
{
 194:	711d                	addi	sp,sp,-96
 196:	ec86                	sd	ra,88(sp)
 198:	e8a2                	sd	s0,80(sp)
 19a:	e4a6                	sd	s1,72(sp)
 19c:	e0ca                	sd	s2,64(sp)
 19e:	fc4e                	sd	s3,56(sp)
 1a0:	f852                	sd	s4,48(sp)
 1a2:	f456                	sd	s5,40(sp)
 1a4:	f05a                	sd	s6,32(sp)
 1a6:	ec5e                	sd	s7,24(sp)
 1a8:	e862                	sd	s8,16(sp)
 1aa:	1080                	addi	s0,sp,96
 1ac:	8baa                	mv	s7,a0
 1ae:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 1b0:	892a                	mv	s2,a0
 1b2:	4481                	li	s1,0
    cc = read(0, &c, 1);
 1b4:	faf40b13          	addi	s6,s0,-81
 1b8:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 1ba:	8c26                	mv	s8,s1
 1bc:	0014899b          	addiw	s3,s1,1
 1c0:	84ce                	mv	s1,s3
 1c2:	0349d863          	bge	s3,s4,1f2 <gets+0x5e>
    cc = read(0, &c, 1);
 1c6:	8656                	mv	a2,s5
 1c8:	85da                	mv	a1,s6
 1ca:	4501                	li	a0,0
 1cc:	194000ef          	jal	360 <read>
    if(cc < 1)
 1d0:	02a05163          	blez	a0,1f2 <gets+0x5e>
      break;
    buf[i++] = c;
 1d4:	faf44783          	lbu	a5,-81(s0)
 1d8:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 1dc:	0905                	addi	s2,s2,1
 1de:	ff678713          	addi	a4,a5,-10
 1e2:	00173713          	seqz	a4,a4
 1e6:	17cd                	addi	a5,a5,-13
 1e8:	0017b793          	seqz	a5,a5
 1ec:	8fd9                	or	a5,a5,a4
 1ee:	d7f1                	beqz	a5,1ba <gets+0x26>
    buf[i++] = c;
 1f0:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 1f2:	9c5e                	add	s8,s8,s7
 1f4:	000c0023          	sb	zero,0(s8)
  return buf;
}
 1f8:	855e                	mv	a0,s7
 1fa:	60e6                	ld	ra,88(sp)
 1fc:	6446                	ld	s0,80(sp)
 1fe:	64a6                	ld	s1,72(sp)
 200:	6906                	ld	s2,64(sp)
 202:	79e2                	ld	s3,56(sp)
 204:	7a42                	ld	s4,48(sp)
 206:	7aa2                	ld	s5,40(sp)
 208:	7b02                	ld	s6,32(sp)
 20a:	6be2                	ld	s7,24(sp)
 20c:	6c42                	ld	s8,16(sp)
 20e:	6125                	addi	sp,sp,96
 210:	8082                	ret

0000000000000212 <stat>:

int
stat(const char *n, struct stat *st)
{
 212:	1101                	addi	sp,sp,-32
 214:	ec06                	sd	ra,24(sp)
 216:	e822                	sd	s0,16(sp)
 218:	e04a                	sd	s2,0(sp)
 21a:	1000                	addi	s0,sp,32
 21c:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 21e:	4581                	li	a1,0
 220:	168000ef          	jal	388 <open>
  if(fd < 0)
 224:	02054263          	bltz	a0,248 <stat+0x36>
 228:	e426                	sd	s1,8(sp)
 22a:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 22c:	85ca                	mv	a1,s2
 22e:	172000ef          	jal	3a0 <fstat>
 232:	892a                	mv	s2,a0
  close(fd);
 234:	8526                	mv	a0,s1
 236:	13a000ef          	jal	370 <close>
  return r;
 23a:	64a2                	ld	s1,8(sp)
}
 23c:	854a                	mv	a0,s2
 23e:	60e2                	ld	ra,24(sp)
 240:	6442                	ld	s0,16(sp)
 242:	6902                	ld	s2,0(sp)
 244:	6105                	addi	sp,sp,32
 246:	8082                	ret
    return -1;
 248:	57fd                	li	a5,-1
 24a:	893e                	mv	s2,a5
 24c:	bfc5                	j	23c <stat+0x2a>

000000000000024e <atoi>:

int
atoi(const char *s)
{
 24e:	1141                	addi	sp,sp,-16
 250:	e406                	sd	ra,8(sp)
 252:	e022                	sd	s0,0(sp)
 254:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 256:	00054683          	lbu	a3,0(a0)
 25a:	fd06879b          	addiw	a5,a3,-48
 25e:	0ff7f793          	zext.b	a5,a5
 262:	4625                	li	a2,9
 264:	02f66963          	bltu	a2,a5,296 <atoi+0x48>
 268:	872a                	mv	a4,a0
  n = 0;
 26a:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 26c:	0705                	addi	a4,a4,1
 26e:	0025179b          	slliw	a5,a0,0x2
 272:	9fa9                	addw	a5,a5,a0
 274:	0017979b          	slliw	a5,a5,0x1
 278:	9fb5                	addw	a5,a5,a3
 27a:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 27e:	00074683          	lbu	a3,0(a4)
 282:	fd06879b          	addiw	a5,a3,-48
 286:	0ff7f793          	zext.b	a5,a5
 28a:	fef671e3          	bgeu	a2,a5,26c <atoi+0x1e>
  return n;
}
 28e:	60a2                	ld	ra,8(sp)
 290:	6402                	ld	s0,0(sp)
 292:	0141                	addi	sp,sp,16
 294:	8082                	ret
  n = 0;
 296:	4501                	li	a0,0
 298:	bfdd                	j	28e <atoi+0x40>

000000000000029a <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 29a:	1141                	addi	sp,sp,-16
 29c:	e406                	sd	ra,8(sp)
 29e:	e022                	sd	s0,0(sp)
 2a0:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 2a2:	02b57563          	bgeu	a0,a1,2cc <memmove+0x32>
    while(n-- > 0)
 2a6:	00c05f63          	blez	a2,2c4 <memmove+0x2a>
 2aa:	1602                	slli	a2,a2,0x20
 2ac:	9201                	srli	a2,a2,0x20
 2ae:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 2b2:	872a                	mv	a4,a0
      *dst++ = *src++;
 2b4:	0585                	addi	a1,a1,1
 2b6:	0705                	addi	a4,a4,1
 2b8:	fff5c683          	lbu	a3,-1(a1)
 2bc:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 2c0:	fee79ae3          	bne	a5,a4,2b4 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 2c4:	60a2                	ld	ra,8(sp)
 2c6:	6402                	ld	s0,0(sp)
 2c8:	0141                	addi	sp,sp,16
 2ca:	8082                	ret
    while(n-- > 0)
 2cc:	fec05ce3          	blez	a2,2c4 <memmove+0x2a>
    dst += n;
 2d0:	00c50733          	add	a4,a0,a2
    src += n;
 2d4:	95b2                	add	a1,a1,a2
 2d6:	fff6079b          	addiw	a5,a2,-1
 2da:	1782                	slli	a5,a5,0x20
 2dc:	9381                	srli	a5,a5,0x20
 2de:	fff7c793          	not	a5,a5
 2e2:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 2e4:	15fd                	addi	a1,a1,-1
 2e6:	177d                	addi	a4,a4,-1
 2e8:	0005c683          	lbu	a3,0(a1)
 2ec:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 2f0:	fef71ae3          	bne	a4,a5,2e4 <memmove+0x4a>
 2f4:	bfc1                	j	2c4 <memmove+0x2a>

00000000000002f6 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 2f6:	1141                	addi	sp,sp,-16
 2f8:	e406                	sd	ra,8(sp)
 2fa:	e022                	sd	s0,0(sp)
 2fc:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 2fe:	ce19                	beqz	a2,31c <memcmp+0x26>
 300:	1602                	slli	a2,a2,0x20
 302:	9201                	srli	a2,a2,0x20
 304:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 308:	00054783          	lbu	a5,0(a0)
 30c:	0005c703          	lbu	a4,0(a1)
 310:	00e79b63          	bne	a5,a4,326 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 314:	0505                	addi	a0,a0,1
    p2++;
 316:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 318:	fed518e3          	bne	a0,a3,308 <memcmp+0x12>
  }
  return 0;
 31c:	4501                	li	a0,0
}
 31e:	60a2                	ld	ra,8(sp)
 320:	6402                	ld	s0,0(sp)
 322:	0141                	addi	sp,sp,16
 324:	8082                	ret
      return *p1 - *p2;
 326:	40e7853b          	subw	a0,a5,a4
 32a:	bfd5                	j	31e <memcmp+0x28>

000000000000032c <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 32c:	1141                	addi	sp,sp,-16
 32e:	e406                	sd	ra,8(sp)
 330:	e022                	sd	s0,0(sp)
 332:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 334:	f67ff0ef          	jal	29a <memmove>
}
 338:	60a2                	ld	ra,8(sp)
 33a:	6402                	ld	s0,0(sp)
 33c:	0141                	addi	sp,sp,16
 33e:	8082                	ret

0000000000000340 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 340:	4885                	li	a7,1
 ecall
 342:	00000073          	ecall
 ret
 346:	8082                	ret

0000000000000348 <exit>:
.global exit
exit:
 li a7, SYS_exit
 348:	4889                	li	a7,2
 ecall
 34a:	00000073          	ecall
 ret
 34e:	8082                	ret

0000000000000350 <wait>:
.global wait
wait:
 li a7, SYS_wait
 350:	488d                	li	a7,3
 ecall
 352:	00000073          	ecall
 ret
 356:	8082                	ret

0000000000000358 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 358:	4891                	li	a7,4
 ecall
 35a:	00000073          	ecall
 ret
 35e:	8082                	ret

0000000000000360 <read>:
.global read
read:
 li a7, SYS_read
 360:	4895                	li	a7,5
 ecall
 362:	00000073          	ecall
 ret
 366:	8082                	ret

0000000000000368 <write>:
.global write
write:
 li a7, SYS_write
 368:	48c1                	li	a7,16
 ecall
 36a:	00000073          	ecall
 ret
 36e:	8082                	ret

0000000000000370 <close>:
.global close
close:
 li a7, SYS_close
 370:	48d5                	li	a7,21
 ecall
 372:	00000073          	ecall
 ret
 376:	8082                	ret

0000000000000378 <kill>:
.global kill
kill:
 li a7, SYS_kill
 378:	4899                	li	a7,6
 ecall
 37a:	00000073          	ecall
 ret
 37e:	8082                	ret

0000000000000380 <exec>:
.global exec
exec:
 li a7, SYS_exec
 380:	489d                	li	a7,7
 ecall
 382:	00000073          	ecall
 ret
 386:	8082                	ret

0000000000000388 <open>:
.global open
open:
 li a7, SYS_open
 388:	48bd                	li	a7,15
 ecall
 38a:	00000073          	ecall
 ret
 38e:	8082                	ret

0000000000000390 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 390:	48c5                	li	a7,17
 ecall
 392:	00000073          	ecall
 ret
 396:	8082                	ret

0000000000000398 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 398:	48c9                	li	a7,18
 ecall
 39a:	00000073          	ecall
 ret
 39e:	8082                	ret

00000000000003a0 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 3a0:	48a1                	li	a7,8
 ecall
 3a2:	00000073          	ecall
 ret
 3a6:	8082                	ret

00000000000003a8 <link>:
.global link
link:
 li a7, SYS_link
 3a8:	48cd                	li	a7,19
 ecall
 3aa:	00000073          	ecall
 ret
 3ae:	8082                	ret

00000000000003b0 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 3b0:	48d1                	li	a7,20
 ecall
 3b2:	00000073          	ecall
 ret
 3b6:	8082                	ret

00000000000003b8 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 3b8:	48a5                	li	a7,9
 ecall
 3ba:	00000073          	ecall
 ret
 3be:	8082                	ret

00000000000003c0 <dup>:
.global dup
dup:
 li a7, SYS_dup
 3c0:	48a9                	li	a7,10
 ecall
 3c2:	00000073          	ecall
 ret
 3c6:	8082                	ret

00000000000003c8 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 3c8:	48ad                	li	a7,11
 ecall
 3ca:	00000073          	ecall
 ret
 3ce:	8082                	ret

00000000000003d0 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 3d0:	48b1                	li	a7,12
 ecall
 3d2:	00000073          	ecall
 ret
 3d6:	8082                	ret

00000000000003d8 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 3d8:	48b5                	li	a7,13
 ecall
 3da:	00000073          	ecall
 ret
 3de:	8082                	ret

00000000000003e0 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 3e0:	48b9                	li	a7,14
 ecall
 3e2:	00000073          	ecall
 ret
 3e6:	8082                	ret

00000000000003e8 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 3e8:	1101                	addi	sp,sp,-32
 3ea:	ec06                	sd	ra,24(sp)
 3ec:	e822                	sd	s0,16(sp)
 3ee:	1000                	addi	s0,sp,32
 3f0:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 3f4:	4605                	li	a2,1
 3f6:	fef40593          	addi	a1,s0,-17
 3fa:	f6fff0ef          	jal	368 <write>
}
 3fe:	60e2                	ld	ra,24(sp)
 400:	6442                	ld	s0,16(sp)
 402:	6105                	addi	sp,sp,32
 404:	8082                	ret

0000000000000406 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 406:	715d                	addi	sp,sp,-80
 408:	e486                	sd	ra,72(sp)
 40a:	e0a2                	sd	s0,64(sp)
 40c:	f84a                	sd	s2,48(sp)
 40e:	f44e                	sd	s3,40(sp)
 410:	0880                	addi	s0,sp,80
 412:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 414:	00d036b3          	snez	a3,a3
 418:	03f5d793          	srli	a5,a1,0x3f
 41c:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 41e:	0005871b          	sext.w	a4,a1
  neg = 0;
 422:	4301                	li	t1,0
  if(sgn && xx < 0){
 424:	c681                	beqz	a3,42c <printint+0x26>
    x = -xx;
 426:	40b0073b          	negw	a4,a1
    neg = 1;
 42a:	4305                	li	t1,1
  }

  i = 0;
 42c:	fb840993          	addi	s3,s0,-72
  neg = 0;
 430:	85ce                	mv	a1,s3
  i = 0;
 432:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 434:	00000817          	auipc	a6,0x0
 438:	79480813          	addi	a6,a6,1940 # bc8 <digits>
 43c:	88b6                	mv	a7,a3
 43e:	0016851b          	addiw	a0,a3,1
 442:	86aa                	mv	a3,a0
 444:	02c777bb          	remuw	a5,a4,a2
 448:	1782                	slli	a5,a5,0x20
 44a:	9381                	srli	a5,a5,0x20
 44c:	97c2                	add	a5,a5,a6
 44e:	0007c783          	lbu	a5,0(a5)
 452:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 456:	87ba                	mv	a5,a4
 458:	02c7573b          	divuw	a4,a4,a2
 45c:	0585                	addi	a1,a1,1
 45e:	fcc7ffe3          	bgeu	a5,a2,43c <printint+0x36>
  if(neg)
 462:	00030b63          	beqz	t1,478 <printint+0x72>
    buf[i++] = '-';
 466:	fd040793          	addi	a5,s0,-48
 46a:	953e                	add	a0,a0,a5
 46c:	02d00793          	li	a5,45
 470:	fef50423          	sb	a5,-24(a0)
 474:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 478:	02d05563          	blez	a3,4a2 <printint+0x9c>
 47c:	fc26                	sd	s1,56(sp)
 47e:	36fd                	addiw	a3,a3,-1
 480:	00d984b3          	add	s1,s3,a3
 484:	19fd                	addi	s3,s3,-1
 486:	99b6                	add	s3,s3,a3
 488:	1682                	slli	a3,a3,0x20
 48a:	9281                	srli	a3,a3,0x20
 48c:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 490:	0004c583          	lbu	a1,0(s1)
 494:	854a                	mv	a0,s2
 496:	f53ff0ef          	jal	3e8 <putc>
  while(--i >= 0)
 49a:	14fd                	addi	s1,s1,-1
 49c:	ff349ae3          	bne	s1,s3,490 <printint+0x8a>
 4a0:	74e2                	ld	s1,56(sp)
}
 4a2:	60a6                	ld	ra,72(sp)
 4a4:	6406                	ld	s0,64(sp)
 4a6:	7942                	ld	s2,48(sp)
 4a8:	79a2                	ld	s3,40(sp)
 4aa:	6161                	addi	sp,sp,80
 4ac:	8082                	ret

00000000000004ae <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 4ae:	711d                	addi	sp,sp,-96
 4b0:	ec86                	sd	ra,88(sp)
 4b2:	e8a2                	sd	s0,80(sp)
 4b4:	e4a6                	sd	s1,72(sp)
 4b6:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 4b8:	0005c483          	lbu	s1,0(a1)
 4bc:	28048263          	beqz	s1,740 <vprintf+0x292>
 4c0:	e0ca                	sd	s2,64(sp)
 4c2:	fc4e                	sd	s3,56(sp)
 4c4:	f852                	sd	s4,48(sp)
 4c6:	f456                	sd	s5,40(sp)
 4c8:	f05a                	sd	s6,32(sp)
 4ca:	ec5e                	sd	s7,24(sp)
 4cc:	e862                	sd	s8,16(sp)
 4ce:	8b2a                	mv	s6,a0
 4d0:	8a2e                	mv	s4,a1
 4d2:	8bb2                	mv	s7,a2
  state = 0;
 4d4:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 4d6:	4901                	li	s2,0
 4d8:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 4da:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 4de:	06400c13          	li	s8,100
 4e2:	a00d                	j	504 <vprintf+0x56>
        putc(fd, c0);
 4e4:	85a6                	mv	a1,s1
 4e6:	855a                	mv	a0,s6
 4e8:	f01ff0ef          	jal	3e8 <putc>
 4ec:	a019                	j	4f2 <vprintf+0x44>
    } else if(state == '%'){
 4ee:	03598363          	beq	s3,s5,514 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 4f2:	0019079b          	addiw	a5,s2,1
 4f6:	893e                	mv	s2,a5
 4f8:	873e                	mv	a4,a5
 4fa:	97d2                	add	a5,a5,s4
 4fc:	0007c483          	lbu	s1,0(a5)
 500:	22048963          	beqz	s1,732 <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 504:	0004879b          	sext.w	a5,s1
    if(state == 0){
 508:	fe0993e3          	bnez	s3,4ee <vprintf+0x40>
      if(c0 == '%'){
 50c:	fd579ce3          	bne	a5,s5,4e4 <vprintf+0x36>
        state = '%';
 510:	89be                	mv	s3,a5
 512:	b7c5                	j	4f2 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 514:	00ea06b3          	add	a3,s4,a4
 518:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 51c:	22060763          	beqz	a2,74a <vprintf+0x29c>
      if(c0 == 'd'){
 520:	0b878363          	beq	a5,s8,5c6 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 524:	f9478693          	addi	a3,a5,-108
 528:	0016b693          	seqz	a3,a3
 52c:	f9c60593          	addi	a1,a2,-100
 530:	0015b593          	seqz	a1,a1
 534:	8df5                	and	a1,a1,a3
 536:	e5c5                	bnez	a1,5de <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 538:	9752                	add	a4,a4,s4
 53a:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 53e:	f9460713          	addi	a4,a2,-108
 542:	00173713          	seqz	a4,a4
 546:	8f75                	and	a4,a4,a3
 548:	f9c50593          	addi	a1,a0,-100
 54c:	0015b593          	seqz	a1,a1
 550:	8df9                	and	a1,a1,a4
 552:	e1dd                	bnez	a1,5f8 <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 554:	07500593          	li	a1,117
 558:	0ab78d63          	beq	a5,a1,612 <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 55c:	f8b60593          	addi	a1,a2,-117
 560:	0015b593          	seqz	a1,a1
 564:	8df5                	and	a1,a1,a3
 566:	e1f1                	bnez	a1,62a <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 568:	f8b50593          	addi	a1,a0,-117
 56c:	0015b593          	seqz	a1,a1
 570:	8df9                	and	a1,a1,a4
 572:	e9e9                	bnez	a1,644 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 574:	07800593          	li	a1,120
 578:	0eb78363          	beq	a5,a1,65e <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 57c:	f8860613          	addi	a2,a2,-120
 580:	00163613          	seqz	a2,a2
 584:	8ef1                	and	a3,a3,a2
 586:	0e069863          	bnez	a3,676 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 58a:	f8850513          	addi	a0,a0,-120
 58e:	00153513          	seqz	a0,a0
 592:	8f69                	and	a4,a4,a0
 594:	0e071e63          	bnez	a4,690 <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 598:	07000713          	li	a4,112
 59c:	10e78663          	beq	a5,a4,6a8 <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 5a0:	07300713          	li	a4,115
 5a4:	14e78663          	beq	a5,a4,6f0 <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 5a8:	02500713          	li	a4,37
 5ac:	16e78e63          	beq	a5,a4,728 <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 5b0:	02500593          	li	a1,37
 5b4:	855a                	mv	a0,s6
 5b6:	e33ff0ef          	jal	3e8 <putc>
        putc(fd, c0);
 5ba:	85a6                	mv	a1,s1
 5bc:	855a                	mv	a0,s6
 5be:	e2bff0ef          	jal	3e8 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 5c2:	4981                	li	s3,0
 5c4:	b73d                	j	4f2 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 5c6:	008b8493          	addi	s1,s7,8
 5ca:	4685                	li	a3,1
 5cc:	4629                	li	a2,10
 5ce:	000ba583          	lw	a1,0(s7)
 5d2:	855a                	mv	a0,s6
 5d4:	e33ff0ef          	jal	406 <printint>
 5d8:	8ba6                	mv	s7,s1
      state = 0;
 5da:	4981                	li	s3,0
 5dc:	bf19                	j	4f2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 5de:	008b8493          	addi	s1,s7,8
 5e2:	4685                	li	a3,1
 5e4:	4629                	li	a2,10
 5e6:	000bb583          	ld	a1,0(s7)
 5ea:	855a                	mv	a0,s6
 5ec:	e1bff0ef          	jal	406 <printint>
        i += 1;
 5f0:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 5f2:	8ba6                	mv	s7,s1
      state = 0;
 5f4:	4981                	li	s3,0
 5f6:	bdf5                	j	4f2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 5f8:	008b8493          	addi	s1,s7,8
 5fc:	4685                	li	a3,1
 5fe:	4629                	li	a2,10
 600:	000bb583          	ld	a1,0(s7)
 604:	855a                	mv	a0,s6
 606:	e01ff0ef          	jal	406 <printint>
        i += 2;
 60a:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 60c:	8ba6                	mv	s7,s1
      state = 0;
 60e:	4981                	li	s3,0
        i += 2;
 610:	b5cd                	j	4f2 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 612:	008b8493          	addi	s1,s7,8
 616:	4681                	li	a3,0
 618:	4629                	li	a2,10
 61a:	000ba583          	lw	a1,0(s7)
 61e:	855a                	mv	a0,s6
 620:	de7ff0ef          	jal	406 <printint>
 624:	8ba6                	mv	s7,s1
      state = 0;
 626:	4981                	li	s3,0
 628:	b5e9                	j	4f2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 62a:	008b8493          	addi	s1,s7,8
 62e:	4681                	li	a3,0
 630:	4629                	li	a2,10
 632:	000bb583          	ld	a1,0(s7)
 636:	855a                	mv	a0,s6
 638:	dcfff0ef          	jal	406 <printint>
        i += 1;
 63c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 63e:	8ba6                	mv	s7,s1
      state = 0;
 640:	4981                	li	s3,0
 642:	bd45                	j	4f2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 644:	008b8493          	addi	s1,s7,8
 648:	4681                	li	a3,0
 64a:	4629                	li	a2,10
 64c:	000bb583          	ld	a1,0(s7)
 650:	855a                	mv	a0,s6
 652:	db5ff0ef          	jal	406 <printint>
        i += 2;
 656:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 658:	8ba6                	mv	s7,s1
      state = 0;
 65a:	4981                	li	s3,0
        i += 2;
 65c:	bd59                	j	4f2 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 65e:	008b8493          	addi	s1,s7,8
 662:	4681                	li	a3,0
 664:	4641                	li	a2,16
 666:	000ba583          	lw	a1,0(s7)
 66a:	855a                	mv	a0,s6
 66c:	d9bff0ef          	jal	406 <printint>
 670:	8ba6                	mv	s7,s1
      state = 0;
 672:	4981                	li	s3,0
 674:	bdbd                	j	4f2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 676:	008b8493          	addi	s1,s7,8
 67a:	4681                	li	a3,0
 67c:	4641                	li	a2,16
 67e:	000bb583          	ld	a1,0(s7)
 682:	855a                	mv	a0,s6
 684:	d83ff0ef          	jal	406 <printint>
        i += 1;
 688:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 68a:	8ba6                	mv	s7,s1
      state = 0;
 68c:	4981                	li	s3,0
 68e:	b595                	j	4f2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 690:	008b8493          	addi	s1,s7,8
 694:	4641                	li	a2,16
 696:	000bb583          	ld	a1,0(s7)
 69a:	855a                	mv	a0,s6
 69c:	d6bff0ef          	jal	406 <printint>
        i += 2;
 6a0:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 6a2:	8ba6                	mv	s7,s1
      state = 0;
 6a4:	4981                	li	s3,0
        i += 2;
 6a6:	b5b1                	j	4f2 <vprintf+0x44>
 6a8:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 6aa:	008b8793          	addi	a5,s7,8
 6ae:	8cbe                	mv	s9,a5
 6b0:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 6b4:	03000593          	li	a1,48
 6b8:	855a                	mv	a0,s6
 6ba:	d2fff0ef          	jal	3e8 <putc>
  putc(fd, 'x');
 6be:	07800593          	li	a1,120
 6c2:	855a                	mv	a0,s6
 6c4:	d25ff0ef          	jal	3e8 <putc>
 6c8:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 6ca:	00000b97          	auipc	s7,0x0
 6ce:	4feb8b93          	addi	s7,s7,1278 # bc8 <digits>
 6d2:	03c9d793          	srli	a5,s3,0x3c
 6d6:	97de                	add	a5,a5,s7
 6d8:	0007c583          	lbu	a1,0(a5)
 6dc:	855a                	mv	a0,s6
 6de:	d0bff0ef          	jal	3e8 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 6e2:	0992                	slli	s3,s3,0x4
 6e4:	34fd                	addiw	s1,s1,-1
 6e6:	f4f5                	bnez	s1,6d2 <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 6e8:	8be6                	mv	s7,s9
      state = 0;
 6ea:	4981                	li	s3,0
 6ec:	6ca2                	ld	s9,8(sp)
 6ee:	b511                	j	4f2 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 6f0:	008b8993          	addi	s3,s7,8
 6f4:	000bb483          	ld	s1,0(s7)
 6f8:	cc91                	beqz	s1,714 <vprintf+0x266>
        for(; *s; s++)
 6fa:	0004c583          	lbu	a1,0(s1)
 6fe:	c195                	beqz	a1,722 <vprintf+0x274>
          putc(fd, *s);
 700:	855a                	mv	a0,s6
 702:	ce7ff0ef          	jal	3e8 <putc>
        for(; *s; s++)
 706:	0485                	addi	s1,s1,1
 708:	0004c583          	lbu	a1,0(s1)
 70c:	f9f5                	bnez	a1,700 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 70e:	8bce                	mv	s7,s3
      state = 0;
 710:	4981                	li	s3,0
 712:	b3c5                	j	4f2 <vprintf+0x44>
          s = "(null)";
 714:	00000497          	auipc	s1,0x0
 718:	48448493          	addi	s1,s1,1156 # b98 <thread_switch+0xee>
        for(; *s; s++)
 71c:	02800593          	li	a1,40
 720:	b7c5                	j	700 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 722:	8bce                	mv	s7,s3
      state = 0;
 724:	4981                	li	s3,0
 726:	b3f1                	j	4f2 <vprintf+0x44>
        putc(fd, '%');
 728:	85be                	mv	a1,a5
 72a:	855a                	mv	a0,s6
 72c:	cbdff0ef          	jal	3e8 <putc>
 730:	bd49                	j	5c2 <vprintf+0x114>
 732:	6906                	ld	s2,64(sp)
 734:	79e2                	ld	s3,56(sp)
 736:	7a42                	ld	s4,48(sp)
 738:	7aa2                	ld	s5,40(sp)
 73a:	7b02                	ld	s6,32(sp)
 73c:	6be2                	ld	s7,24(sp)
 73e:	6c42                	ld	s8,16(sp)
    }
  }
}
 740:	60e6                	ld	ra,88(sp)
 742:	6446                	ld	s0,80(sp)
 744:	64a6                	ld	s1,72(sp)
 746:	6125                	addi	sp,sp,96
 748:	8082                	ret
      if(c0 == 'd'){
 74a:	06400713          	li	a4,100
 74e:	e6e78ce3          	beq	a5,a4,5c6 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 752:	f9478693          	addi	a3,a5,-108
 756:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 75a:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 75c:	4701                	li	a4,0
 75e:	bbdd                	j	554 <vprintf+0xa6>

0000000000000760 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 760:	715d                	addi	sp,sp,-80
 762:	ec06                	sd	ra,24(sp)
 764:	e822                	sd	s0,16(sp)
 766:	1000                	addi	s0,sp,32
 768:	e010                	sd	a2,0(s0)
 76a:	e414                	sd	a3,8(s0)
 76c:	e818                	sd	a4,16(s0)
 76e:	ec1c                	sd	a5,24(s0)
 770:	03043023          	sd	a6,32(s0)
 774:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 778:	8622                	mv	a2,s0
 77a:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 77e:	d31ff0ef          	jal	4ae <vprintf>
}
 782:	60e2                	ld	ra,24(sp)
 784:	6442                	ld	s0,16(sp)
 786:	6161                	addi	sp,sp,80
 788:	8082                	ret

000000000000078a <printf>:

void
printf(const char *fmt, ...)
{
 78a:	711d                	addi	sp,sp,-96
 78c:	ec06                	sd	ra,24(sp)
 78e:	e822                	sd	s0,16(sp)
 790:	1000                	addi	s0,sp,32
 792:	e40c                	sd	a1,8(s0)
 794:	e810                	sd	a2,16(s0)
 796:	ec14                	sd	a3,24(s0)
 798:	f018                	sd	a4,32(s0)
 79a:	f41c                	sd	a5,40(s0)
 79c:	03043823          	sd	a6,48(s0)
 7a0:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 7a4:	00840613          	addi	a2,s0,8
 7a8:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 7ac:	85aa                	mv	a1,a0
 7ae:	4505                	li	a0,1
 7b0:	cffff0ef          	jal	4ae <vprintf>
}
 7b4:	60e2                	ld	ra,24(sp)
 7b6:	6442                	ld	s0,16(sp)
 7b8:	6125                	addi	sp,sp,96
 7ba:	8082                	ret

00000000000007bc <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 7bc:	1141                	addi	sp,sp,-16
 7be:	e406                	sd	ra,8(sp)
 7c0:	e022                	sd	s0,0(sp)
 7c2:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 7c4:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 7c8:	00001797          	auipc	a5,0x1
 7cc:	8487b783          	ld	a5,-1976(a5) # 1010 <freep>
 7d0:	a095                	j	834 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 7d2:	ff852583          	lw	a1,-8(a0)
 7d6:	6390                	ld	a2,0(a5)
 7d8:	02059813          	slli	a6,a1,0x20
 7dc:	01c85693          	srli	a3,a6,0x1c
 7e0:	96ba                	add	a3,a3,a4
 7e2:	02d60563          	beq	a2,a3,80c <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 7e6:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 7ea:	4790                	lw	a2,8(a5)
 7ec:	02061593          	slli	a1,a2,0x20
 7f0:	01c5d693          	srli	a3,a1,0x1c
 7f4:	96be                	add	a3,a3,a5
 7f6:	02d70263          	beq	a4,a3,81a <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 7fa:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 7fc:	00001717          	auipc	a4,0x1
 800:	80f73a23          	sd	a5,-2028(a4) # 1010 <freep>
}
 804:	60a2                	ld	ra,8(sp)
 806:	6402                	ld	s0,0(sp)
 808:	0141                	addi	sp,sp,16
 80a:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 80c:	4614                	lw	a3,8(a2)
 80e:	9ead                	addw	a3,a3,a1
 810:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 814:	6394                	ld	a3,0(a5)
 816:	6290                	ld	a2,0(a3)
 818:	b7f9                	j	7e6 <free+0x2a>
    p->s.size += bp->s.size;
 81a:	ff852703          	lw	a4,-8(a0)
 81e:	9f31                	addw	a4,a4,a2
 820:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 822:	ff053703          	ld	a4,-16(a0)
 826:	bfd1                	j	7fa <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 828:	6394                	ld	a3,0(a5)
 82a:	00d7e463          	bltu	a5,a3,832 <free+0x76>
 82e:	fad762e3          	bltu	a4,a3,7d2 <free+0x16>
 832:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 834:	fee7fae3          	bgeu	a5,a4,828 <free+0x6c>
 838:	6394                	ld	a3,0(a5)
 83a:	f8d76ce3          	bltu	a4,a3,7d2 <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 83e:	f8d7fae3          	bgeu	a5,a3,7d2 <free+0x16>
 842:	87b6                	mv	a5,a3
 844:	bfc5                	j	834 <free+0x78>

0000000000000846 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 846:	7139                	addi	sp,sp,-64
 848:	fc06                	sd	ra,56(sp)
 84a:	f822                	sd	s0,48(sp)
 84c:	f04a                	sd	s2,32(sp)
 84e:	ec4e                	sd	s3,24(sp)
 850:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 852:	02051993          	slli	s3,a0,0x20
 856:	0209d993          	srli	s3,s3,0x20
 85a:	09bd                	addi	s3,s3,15
 85c:	0049d993          	srli	s3,s3,0x4
 860:	2985                	addiw	s3,s3,1
 862:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 864:	00000517          	auipc	a0,0x0
 868:	7ac53503          	ld	a0,1964(a0) # 1010 <freep>
 86c:	c905                	beqz	a0,89c <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 86e:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 870:	4798                	lw	a4,8(a5)
 872:	09377663          	bgeu	a4,s3,8fe <malloc+0xb8>
 876:	f426                	sd	s1,40(sp)
 878:	e852                	sd	s4,16(sp)
 87a:	e456                	sd	s5,8(sp)
 87c:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 87e:	8a4e                	mv	s4,s3
 880:	6705                	lui	a4,0x1
 882:	00e9f363          	bgeu	s3,a4,888 <malloc+0x42>
 886:	6a05                	lui	s4,0x1
 888:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 88c:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 890:	00000497          	auipc	s1,0x0
 894:	78048493          	addi	s1,s1,1920 # 1010 <freep>
  if(p == (char*)-1)
 898:	5afd                	li	s5,-1
 89a:	a83d                	j	8d8 <malloc+0x92>
 89c:	f426                	sd	s1,40(sp)
 89e:	e852                	sd	s4,16(sp)
 8a0:	e456                	sd	s5,8(sp)
 8a2:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 8a4:	00000797          	auipc	a5,0x0
 8a8:	77c78793          	addi	a5,a5,1916 # 1020 <base>
 8ac:	00000717          	auipc	a4,0x0
 8b0:	76f73223          	sd	a5,1892(a4) # 1010 <freep>
 8b4:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 8b6:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 8ba:	b7d1                	j	87e <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 8bc:	6398                	ld	a4,0(a5)
 8be:	e118                	sd	a4,0(a0)
 8c0:	a899                	j	916 <malloc+0xd0>
  hp->s.size = nu;
 8c2:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 8c6:	0541                	addi	a0,a0,16
 8c8:	ef5ff0ef          	jal	7bc <free>
  return freep;
 8cc:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 8ce:	c125                	beqz	a0,92e <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 8d0:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 8d2:	4798                	lw	a4,8(a5)
 8d4:	03277163          	bgeu	a4,s2,8f6 <malloc+0xb0>
    if(p == freep)
 8d8:	6098                	ld	a4,0(s1)
 8da:	853e                	mv	a0,a5
 8dc:	fef71ae3          	bne	a4,a5,8d0 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 8e0:	8552                	mv	a0,s4
 8e2:	aefff0ef          	jal	3d0 <sbrk>
  if(p == (char*)-1)
 8e6:	fd551ee3          	bne	a0,s5,8c2 <malloc+0x7c>
        return 0;
 8ea:	4501                	li	a0,0
 8ec:	74a2                	ld	s1,40(sp)
 8ee:	6a42                	ld	s4,16(sp)
 8f0:	6aa2                	ld	s5,8(sp)
 8f2:	6b02                	ld	s6,0(sp)
 8f4:	a03d                	j	922 <malloc+0xdc>
 8f6:	74a2                	ld	s1,40(sp)
 8f8:	6a42                	ld	s4,16(sp)
 8fa:	6aa2                	ld	s5,8(sp)
 8fc:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 8fe:	fae90fe3          	beq	s2,a4,8bc <malloc+0x76>
        p->s.size -= nunits;
 902:	4137073b          	subw	a4,a4,s3
 906:	c798                	sw	a4,8(a5)
        p += p->s.size;
 908:	02071693          	slli	a3,a4,0x20
 90c:	01c6d713          	srli	a4,a3,0x1c
 910:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 912:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 916:	00000717          	auipc	a4,0x0
 91a:	6ea73d23          	sd	a0,1786(a4) # 1010 <freep>
      return (void*)(p + 1);
 91e:	01078513          	addi	a0,a5,16
  }
}
 922:	70e2                	ld	ra,56(sp)
 924:	7442                	ld	s0,48(sp)
 926:	7902                	ld	s2,32(sp)
 928:	69e2                	ld	s3,24(sp)
 92a:	6121                	addi	sp,sp,64
 92c:	8082                	ret
 92e:	74a2                	ld	s1,40(sp)
 930:	6a42                	ld	s4,16(sp)
 932:	6aa2                	ld	s5,8(sp)
 934:	6b02                	ld	s6,0(sp)
 936:	b7f5                	j	922 <malloc+0xdc>

0000000000000938 <thread_init>:
struct thread *current_thread;
extern void thread_switch(uint64, uint64);
              
void 
thread_init(void)
{
 938:	1141                	addi	sp,sp,-16
 93a:	e406                	sd	ra,8(sp)
 93c:	e022                	sd	s0,0(sp)
 93e:	0800                	addi	s0,sp,16
  // main() is thread 0, which will make the first invocation to
  // thread_schedule(). It needs a stack so that the first thread_switch() can
  // save thread 0's state.
  current_thread = &all_thread[0];
 940:	00000797          	auipc	a5,0x0
 944:	6f078793          	addi	a5,a5,1776 # 1030 <all_thread>
 948:	00000717          	auipc	a4,0x0
 94c:	6cf73823          	sd	a5,1744(a4) # 1018 <current_thread>
  current_thread->state = RUNNING;
 950:	00002717          	auipc	a4,0x2
 954:	6e070713          	addi	a4,a4,1760 # 3030 <all_thread+0x2000>
 958:	4785                	li	a5,1
 95a:	c31c                	sw	a5,0(a4)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 95c:	00002797          	auipc	a5,0x2
 960:	66478793          	addi	a5,a5,1636 # 2fc0 <all_thread+0x1f90>
  return (struct context *)(top & ~(uint64)0xf);
 964:	9bc1                	andi	a5,a5,-16
  // Thread 0 runs on the process's own stack, but the first thread_switch()
  // still needs a writable place to save its context.
  current_thread->context = thread_context_slot(current_thread);
 966:	e71c                	sd	a5,8(a4)
}
 968:	60a2                	ld	ra,8(sp)
 96a:	6402                	ld	s0,0(sp)
 96c:	0141                	addi	sp,sp,16
 96e:	8082                	ret

0000000000000970 <thread_schedule>:

void 
thread_schedule(void)
{
 970:	1141                	addi	sp,sp,-16
 972:	e406                	sd	ra,8(sp)
 974:	e022                	sd	s0,0(sp)
 976:	0800                	addi	s0,sp,16
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
 978:	00000597          	auipc	a1,0x0
 97c:	6a05b583          	ld	a1,1696(a1) # 1018 <current_thread>
 980:	6789                	lui	a5,0x2
 982:	07c1                	addi	a5,a5,16 # 2010 <all_thread+0xfe0>
 984:	97ae                	add	a5,a5,a1
 986:	4711                	li	a4,4
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
 988:	00008897          	auipc	a7,0x8
 98c:	6e888893          	addi	a7,a7,1768 # 9070 <all_thread+0x8040>
      t = all_thread;
    if(t->state == RUNNABLE) {
 990:	6809                	lui	a6,0x2
 992:	4509                	li	a0,2
      next_thread = t;
      break;
    }
    t = t + 1;
 994:	01080613          	addi	a2,a6,16 # 2010 <all_thread+0xfe0>
 998:	a809                	j	9aa <thread_schedule+0x3a>
    if(t->state == RUNNABLE) {
 99a:	010786b3          	add	a3,a5,a6
 99e:	4294                	lw	a3,0(a3)
 9a0:	02a68563          	beq	a3,a0,9ca <thread_schedule+0x5a>
    t = t + 1;
 9a4:	97b2                	add	a5,a5,a2
  for(int i = 0; i < MAX_THREAD; i++){
 9a6:	377d                	addiw	a4,a4,-1
 9a8:	cb01                	beqz	a4,9b8 <thread_schedule+0x48>
    if(t >= all_thread + MAX_THREAD)
 9aa:	ff17e8e3          	bltu	a5,a7,99a <thread_schedule+0x2a>
      t = all_thread;
 9ae:	00000797          	auipc	a5,0x0
 9b2:	68278793          	addi	a5,a5,1666 # 1030 <all_thread>
 9b6:	b7d5                	j	99a <thread_schedule+0x2a>
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
 9b8:	00000517          	auipc	a0,0x0
 9bc:	1e850513          	addi	a0,a0,488 # ba0 <thread_switch+0xf6>
 9c0:	dcbff0ef          	jal	78a <printf>
    exit(-1);
 9c4:	557d                	li	a0,-1
 9c6:	983ff0ef          	jal	348 <exit>
  }

  if (current_thread != next_thread) {         /* switch threads?  */
 9ca:	02f58163          	beq	a1,a5,9ec <thread_schedule+0x7c>
    next_thread->state = RUNNING;
 9ce:	6689                	lui	a3,0x2
 9d0:	00d78733          	add	a4,a5,a3
 9d4:	4605                	li	a2,1
 9d6:	c310                	sw	a2,0(a4)
    t = current_thread;
    current_thread = next_thread;
 9d8:	00000617          	auipc	a2,0x0
 9dc:	64f63023          	sd	a5,1600(a2) # 1018 <current_thread>
    thread_switch((uint64)t->context, (uint64)next_thread->context);
 9e0:	00d587b3          	add	a5,a1,a3
 9e4:	670c                	ld	a1,8(a4)
 9e6:	6788                	ld	a0,8(a5)
 9e8:	0c2000ef          	jal	aaa <thread_switch>
  } else
    next_thread = 0;
}
 9ec:	60a2                	ld	ra,8(sp)
 9ee:	6402                	ld	s0,0(sp)
 9f0:	0141                	addi	sp,sp,16
 9f2:	8082                	ret

00000000000009f4 <thread_create>:

void 
thread_create(void (*func)())
{
 9f4:	1101                	addi	sp,sp,-32
 9f6:	ec06                	sd	ra,24(sp)
 9f8:	e822                	sd	s0,16(sp)
 9fa:	e426                	sd	s1,8(sp)
 9fc:	e04a                	sd	s2,0(sp)
 9fe:	1000                	addi	s0,sp,32
 a00:	892a                	mv	s2,a0
  struct thread *t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 a02:	00002797          	auipc	a5,0x2
 a06:	63e78793          	addi	a5,a5,1598 # 3040 <all_thread+0x2010>
 a0a:	0000a597          	auipc	a1,0xa
 a0e:	67658593          	addi	a1,a1,1654 # b080 <all_thread+0xa050>
 a12:	6609                	lui	a2,0x2
 a14:	0641                	addi	a2,a2,16 # 2010 <all_thread+0xfe0>
    if (t->state == FREE) break;
 a16:	873e                	mv	a4,a5
 a18:	ff07a683          	lw	a3,-16(a5)
 a1c:	ce9d                	beqz	a3,a5a <thread_create+0x66>
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 a1e:	97b2                	add	a5,a5,a2
 a20:	feb79be3          	bne	a5,a1,a16 <thread_create+0x22>
  }
  t->state = RUNNABLE;
 a24:	6489                	lui	s1,0x2
 a26:	94ba                	add	s1,s1,a4
 a28:	4789                	li	a5,2
 a2a:	c09c                	sw	a5,0(s1)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 a2c:	6789                	lui	a5,0x2
 a2e:	f9078793          	addi	a5,a5,-112 # 1f90 <all_thread+0xf60>
 a32:	973e                	add	a4,a4,a5
  return (struct context *)(top & ~(uint64)0xf);
 a34:	ff077513          	andi	a0,a4,-16
  // A never-run thread has no saved state, so construct one: thread_switch()
  // restores ra and sp, and `ret` then starts func on this thread's own stack.
  t->context = thread_context_slot(t);
 a38:	e488                	sd	a0,8(s1)
  memset(t->context, 0, sizeof(struct context));
 a3a:	07000613          	li	a2,112
 a3e:	4581                	li	a1,0
 a40:	f0aff0ef          	jal	14a <memset>
  t->context->ra = (uint64)func;
 a44:	649c                	ld	a5,8(s1)
 a46:	0127b023          	sd	s2,0(a5)
  t->context->sp = (uint64)t->context;   // 16-byte aligned, grows down
 a4a:	649c                	ld	a5,8(s1)
 a4c:	e79c                	sd	a5,8(a5)
}
 a4e:	60e2                	ld	ra,24(sp)
 a50:	6442                	ld	s0,16(sp)
 a52:	64a2                	ld	s1,8(sp)
 a54:	6902                	ld	s2,0(sp)
 a56:	6105                	addi	sp,sp,32
 a58:	8082                	ret
 a5a:	7779                	lui	a4,0xffffe
 a5c:	1741                	addi	a4,a4,-16 # ffffffffffffdff0 <all_thread+0xffffffffffffcfc0>
 a5e:	973e                	add	a4,a4,a5
 a60:	b7d1                	j	a24 <thread_create+0x30>

0000000000000a62 <thread_yield>:

void 
thread_yield(void)
{
 a62:	1141                	addi	sp,sp,-16
 a64:	e406                	sd	ra,8(sp)
 a66:	e022                	sd	s0,0(sp)
 a68:	0800                	addi	s0,sp,16
  current_thread->state = RUNNABLE;
 a6a:	00000797          	auipc	a5,0x0
 a6e:	5ae7b783          	ld	a5,1454(a5) # 1018 <current_thread>
 a72:	6709                	lui	a4,0x2
 a74:	97ba                	add	a5,a5,a4
 a76:	4709                	li	a4,2
 a78:	c398                	sw	a4,0(a5)
  thread_schedule();
 a7a:	ef7ff0ef          	jal	970 <thread_schedule>
}
 a7e:	60a2                	ld	ra,8(sp)
 a80:	6402                	ld	s0,0(sp)
 a82:	0141                	addi	sp,sp,16
 a84:	8082                	ret

0000000000000a86 <thread_exit>:

void thread_exit(void) {
 a86:	1141                	addi	sp,sp,-16
 a88:	e406                	sd	ra,8(sp)
 a8a:	e022                	sd	s0,0(sp)
 a8c:	0800                	addi	s0,sp,16
  current_thread->state = FREE;
 a8e:	00000797          	auipc	a5,0x0
 a92:	58a7b783          	ld	a5,1418(a5) # 1018 <current_thread>
 a96:	6709                	lui	a4,0x2
 a98:	97ba                	add	a5,a5,a4
 a9a:	0007a023          	sw	zero,0(a5)
  thread_schedule();
 a9e:	ed3ff0ef          	jal	970 <thread_schedule>
}
 aa2:	60a2                	ld	ra,8(sp)
 aa4:	6402                	ld	s0,0(sp)
 aa6:	0141                	addi	sp,sp,16
 aa8:	8082                	ret

0000000000000aaa <thread_switch>:
 aaa:	00153023          	sd	ra,0(a0)
 aae:	00253423          	sd	sp,8(a0)
 ab2:	e900                	sd	s0,16(a0)
 ab4:	ed04                	sd	s1,24(a0)
 ab6:	03253023          	sd	s2,32(a0)
 aba:	03353423          	sd	s3,40(a0)
 abe:	03453823          	sd	s4,48(a0)
 ac2:	03553c23          	sd	s5,56(a0)
 ac6:	05653023          	sd	s6,64(a0)
 aca:	05753423          	sd	s7,72(a0)
 ace:	05853823          	sd	s8,80(a0)
 ad2:	05953c23          	sd	s9,88(a0)
 ad6:	07a53023          	sd	s10,96(a0)
 ada:	07b53423          	sd	s11,104(a0)
 ade:	0005b083          	ld	ra,0(a1)
 ae2:	0085b103          	ld	sp,8(a1)
 ae6:	6980                	ld	s0,16(a1)
 ae8:	6d84                	ld	s1,24(a1)
 aea:	0205b903          	ld	s2,32(a1)
 aee:	0285b983          	ld	s3,40(a1)
 af2:	0305ba03          	ld	s4,48(a1)
 af6:	0385ba83          	ld	s5,56(a1)
 afa:	0405bb03          	ld	s6,64(a1)
 afe:	0485bb83          	ld	s7,72(a1)
 b02:	0505bc03          	ld	s8,80(a1)
 b06:	0585bc83          	ld	s9,88(a1)
 b0a:	0605bd03          	ld	s10,96(a1)
 b0e:	0685bd83          	ld	s11,104(a1)
 b12:	8082                	ret
