
user/_schedtest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
    value = value * 1664525 + i + 1013904223;
}

int
main(void)
{
   0:	7159                	addi	sp,sp,-112
   2:	f486                	sd	ra,104(sp)
   4:	f0a2                	sd	s0,96(sp)
   6:	1880                	addi	s0,sp,112
  int gate[2];
  int created = 0;

  if(pipe(gate) < 0){
   8:	fa840513          	addi	a0,s0,-88
   c:	4a8000ef          	jal	4b4 <pipe>
  10:	02054a63          	bltz	a0,44 <main+0x44>
  14:	eca6                	sd	s1,88(sp)
  16:	e8ca                	sd	s2,80(sp)
  18:	e4ce                	sd	s3,72(sp)
  1a:	e0d2                	sd	s4,64(sp)
  1c:	fc56                	sd	s5,56(sp)
  1e:	f85a                	sd	s6,48(sp)
  20:	f45e                	sd	s7,40(sp)
  22:	f062                	sd	s8,32(sp)
  24:	4481                	li	s1,0
  return (pid % 2 == 0) ? "even" : "odd";
  26:	00001a17          	auipc	s4,0x1
  2a:	c52a0a13          	addi	s4,s4,-942 # c78 <thread_switch+0x72>
  2e:	00001b17          	auipc	s6,0x1
  32:	c42b0b13          	addi	s6,s6,-958 # c70 <thread_switch+0x6a>
      printf("child %d: pid %d (%s) done\n",
             child, me, parity(me));
      exit(0);
    }

    printf("parent: created child %d as pid %d (%s)\n",
  36:	00001997          	auipc	s3,0x1
  3a:	d0298993          	addi	s3,s3,-766 # d38 <thread_switch+0x132>

    /*
     * Give an optional FCFS implementation distinguishable
     * creation times.
     */
    if(child + 1 < NCHILD)
  3e:	4911                	li	s2,4
      sleep(1);
  40:	4a85                	li	s5,1
  42:	a291                	j	186 <main+0x186>
  44:	eca6                	sd	s1,88(sp)
  46:	e8ca                	sd	s2,80(sp)
  48:	e4ce                	sd	s3,72(sp)
  4a:	e0d2                	sd	s4,64(sp)
  4c:	fc56                	sd	s5,56(sp)
  4e:	f85a                	sd	s6,48(sp)
  50:	f45e                	sd	s7,40(sp)
  52:	f062                	sd	s8,32(sp)
    printf("schedtest: pipe failed\n");
  54:	00001517          	auipc	a0,0x1
  58:	c2c50513          	addi	a0,a0,-980 # c80 <thread_switch+0x7a>
  5c:	08b000ef          	jal	8e6 <printf>
    exit(1);
  60:	4505                	li	a0,1
  62:	442000ef          	jal	4a4 <exit>
      printf("schedtest: fork failed\n");
  66:	00001517          	auipc	a0,0x1
  6a:	c3250513          	addi	a0,a0,-974 # c98 <thread_switch+0x92>
  6e:	079000ef          	jal	8e6 <printf>
  }

  close(gate[0]);
  72:	fa842503          	lw	a0,-88(s0)
  76:	456000ef          	jal	4cc <close>
  /*
   * Release every child with one write. This makes the children
   * compete as runnable processes at approximately the same time.
   */
  char tokens[NCHILD];
  for(int i = 0; i < created; i++)
  7a:	16904663          	bgtz	s1,1e6 <main+0x1e6>
    tokens[i] = 'g';

  if(write(gate[1], tokens, created) != created)
  7e:	8626                	mv	a2,s1
  80:	fa040593          	addi	a1,s0,-96
  84:	fac42503          	lw	a0,-84(s0)
  88:	43c000ef          	jal	4c4 <write>
  8c:	10951a63          	bne	a0,s1,1a0 <main+0x1a0>
    printf("schedtest: gate write failed\n");

  close(gate[1]);
  90:	fac42503          	lw	a0,-84(s0)
  94:	438000ef          	jal	4cc <close>

  for(int i = 0; i < created; i++)
  98:	a23d                	j	1c6 <main+0x1c6>
      int me = getpid();
  9a:	48a000ef          	jal	524 <getpid>
  9e:	8baa                	mv	s7,a0
      close(gate[1]);
  a0:	fac42503          	lw	a0,-84(s0)
  a4:	428000ef          	jal	4cc <close>
      if(read(gate[0], &token, 1) != 1){
  a8:	4605                	li	a2,1
  aa:	f9740593          	addi	a1,s0,-105
  ae:	fa842503          	lw	a0,-88(s0)
  b2:	40a000ef          	jal	4bc <read>
  b6:	8aaa                	mv	s5,a0
  b8:	4785                	li	a5,1
  ba:	00f50c63          	beq	a0,a5,d2 <main+0xd2>
        printf("child %d: gate read failed\n", child);
  be:	85a6                	mv	a1,s1
  c0:	00001517          	auipc	a0,0x1
  c4:	bf050513          	addi	a0,a0,-1040 # cb0 <thread_switch+0xaa>
  c8:	01f000ef          	jal	8e6 <printf>
        exit(1);
  cc:	4505                	li	a0,1
  ce:	3d6000ef          	jal	4a4 <exit>
      close(gate[0]);
  d2:	fa842503          	lw	a0,-88(s0)
  d6:	3f6000ef          	jal	4cc <close>
  return (pid % 2 == 0) ? "even" : "odd";
  da:	001bf793          	andi	a5,s7,1
  de:	00001717          	auipc	a4,0x1
  e2:	b9a70713          	addi	a4,a4,-1126 # c78 <thread_switch+0x72>
  e6:	8c3a                	mv	s8,a4
  e8:	e791                	bnez	a5,f4 <main+0xf4>
  ea:	00001797          	auipc	a5,0x1
  ee:	b8678793          	addi	a5,a5,-1146 # c70 <thread_switch+0x6a>
  f2:	8c3e                	mv	s8,a5
      printf("child %d: pid %d (%s) start\n",
  f4:	86e2                	mv	a3,s8
  f6:	865e                	mv	a2,s7
  f8:	85a6                	mv	a1,s1
  fa:	00001517          	auipc	a0,0x1
  fe:	bd650513          	addi	a0,a0,-1066 # cd0 <thread_switch+0xca>
 102:	7e4000ef          	jal	8e6 <printf>
    value = value * 1664525 + i + 1013904223;
 106:	00196a37          	lui	s4,0x196
 10a:	60da0a13          	addi	s4,s4,1549 # 19660d <all_thread+0x1955ed>
 10e:	3c6ef9b7          	lui	s3,0x3c6ef
 112:	35f98993          	addi	s3,s3,863 # 3c6ef35f <all_thread+0x3c6ee33f>
  for(uint64 i = 0; i < WORK; i++)
 116:	02626937          	lui	s2,0x2626
 11a:	a0090913          	addi	s2,s2,-1536 # 2625a00 <all_thread+0x26249e0>
      for(int round = 1; round <= ROUNDS; round++){
 11e:	4b15                	li	s6,5
  volatile uint64 value = 1;
 120:	4785                	li	a5,1
 122:	f8f43c23          	sd	a5,-104(s0)
  for(uint64 i = 0; i < WORK; i++)
 126:	4701                	li	a4,0
    value = value * 1664525 + i + 1013904223;
 128:	f9843783          	ld	a5,-104(s0)
 12c:	034787b3          	mul	a5,a5,s4
 130:	97ce                	add	a5,a5,s3
 132:	97ba                	add	a5,a5,a4
 134:	f8f43c23          	sd	a5,-104(s0)
  for(uint64 i = 0; i < WORK; i++)
 138:	0705                	addi	a4,a4,1
 13a:	ff2717e3          	bne	a4,s2,128 <main+0x128>
        printf("child %d: pid %d (%s) round %d/%d\n",
 13e:	4791                	li	a5,4
 140:	8756                	mv	a4,s5
 142:	86e2                	mv	a3,s8
 144:	865e                	mv	a2,s7
 146:	85a6                	mv	a1,s1
 148:	00001517          	auipc	a0,0x1
 14c:	ba850513          	addi	a0,a0,-1112 # cf0 <thread_switch+0xea>
 150:	796000ef          	jal	8e6 <printf>
      for(int round = 1; round <= ROUNDS; round++){
 154:	2a85                	addiw	s5,s5,1
 156:	fd6a95e3          	bne	s5,s6,120 <main+0x120>
      printf("child %d: pid %d (%s) done\n",
 15a:	86e2                	mv	a3,s8
 15c:	865e                	mv	a2,s7
 15e:	85a6                	mv	a1,s1
 160:	00001517          	auipc	a0,0x1
 164:	bb850513          	addi	a0,a0,-1096 # d18 <thread_switch+0x112>
 168:	77e000ef          	jal	8e6 <printf>
      exit(0);
 16c:	4501                	li	a0,0
 16e:	336000ef          	jal	4a4 <exit>
    printf("parent: created child %d as pid %d (%s)\n",
 172:	85a6                	mv	a1,s1
 174:	854e                	mv	a0,s3
 176:	770000ef          	jal	8e6 <printf>
    created++;
 17a:	2485                	addiw	s1,s1,1
    if(child + 1 < NCHILD)
 17c:	07248163          	beq	s1,s2,1de <main+0x1de>
      sleep(1);
 180:	8556                	mv	a0,s5
 182:	3b2000ef          	jal	534 <sleep>
    int pid = fork();
 186:	316000ef          	jal	49c <fork>
 18a:	862a                	mv	a2,a0
    if(pid < 0){
 18c:	ec054de3          	bltz	a0,66 <main+0x66>
    if(pid == 0){
 190:	f00505e3          	beqz	a0,9a <main+0x9a>
  return (pid % 2 == 0) ? "even" : "odd";
 194:	00157793          	andi	a5,a0,1
 198:	86d2                	mv	a3,s4
 19a:	ffe1                	bnez	a5,172 <main+0x172>
 19c:	86da                	mv	a3,s6
 19e:	bfd1                	j	172 <main+0x172>
    printf("schedtest: gate write failed\n");
 1a0:	00001517          	auipc	a0,0x1
 1a4:	bc850513          	addi	a0,a0,-1080 # d68 <thread_switch+0x162>
 1a8:	73e000ef          	jal	8e6 <printf>
  close(gate[1]);
 1ac:	fac42503          	lw	a0,-84(s0)
 1b0:	31c000ef          	jal	4cc <close>
  for(int i = 0; i < created; i++)
 1b4:	00905963          	blez	s1,1c6 <main+0x1c6>
  return (pid % 2 == 0) ? "even" : "odd";
 1b8:	4901                	li	s2,0
    wait(0);
 1ba:	4501                	li	a0,0
 1bc:	2f0000ef          	jal	4ac <wait>
  for(int i = 0; i < created; i++)
 1c0:	2905                	addiw	s2,s2,1
 1c2:	fe991ce3          	bne	s2,s1,1ba <main+0x1ba>

  printf("schedtest: all children finished\n");
 1c6:	00001517          	auipc	a0,0x1
 1ca:	bc250513          	addi	a0,a0,-1086 # d88 <thread_switch+0x182>
 1ce:	718000ef          	jal	8e6 <printf>
  exit(created == NCHILD ? 0 : 1);
 1d2:	ffc48513          	addi	a0,s1,-4
 1d6:	00a03533          	snez	a0,a0
 1da:	2ca000ef          	jal	4a4 <exit>
  close(gate[0]);
 1de:	fa842503          	lw	a0,-88(s0)
 1e2:	2ea000ef          	jal	4cc <close>
  for(int i = 0; i < created; i++)
 1e6:	fa040793          	addi	a5,s0,-96
 1ea:	00f486b3          	add	a3,s1,a5
    tokens[i] = 'g';
 1ee:	06700713          	li	a4,103
 1f2:	00e78023          	sb	a4,0(a5)
  for(int i = 0; i < created; i++)
 1f6:	0785                	addi	a5,a5,1
 1f8:	fed79de3          	bne	a5,a3,1f2 <main+0x1f2>
  if(write(gate[1], tokens, created) != created)
 1fc:	8626                	mv	a2,s1
 1fe:	fa040593          	addi	a1,s0,-96
 202:	fac42503          	lw	a0,-84(s0)
 206:	2be000ef          	jal	4c4 <write>
 20a:	f8951be3          	bne	a0,s1,1a0 <main+0x1a0>
  close(gate[1]);
 20e:	fac42503          	lw	a0,-84(s0)
 212:	2ba000ef          	jal	4cc <close>
  for(int i = 0; i < created; i++)
 216:	b74d                	j	1b8 <main+0x1b8>

0000000000000218 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 218:	1141                	addi	sp,sp,-16
 21a:	e406                	sd	ra,8(sp)
 21c:	e022                	sd	s0,0(sp)
 21e:	0800                	addi	s0,sp,16
  extern int main();
  main();
 220:	de1ff0ef          	jal	0 <main>
  exit(0);
 224:	4501                	li	a0,0
 226:	27e000ef          	jal	4a4 <exit>

000000000000022a <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 22a:	1141                	addi	sp,sp,-16
 22c:	e406                	sd	ra,8(sp)
 22e:	e022                	sd	s0,0(sp)
 230:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 232:	87aa                	mv	a5,a0
 234:	0585                	addi	a1,a1,1
 236:	0785                	addi	a5,a5,1
 238:	fff5c703          	lbu	a4,-1(a1)
 23c:	fee78fa3          	sb	a4,-1(a5)
 240:	fb75                	bnez	a4,234 <strcpy+0xa>
    ;
  return os;
}
 242:	60a2                	ld	ra,8(sp)
 244:	6402                	ld	s0,0(sp)
 246:	0141                	addi	sp,sp,16
 248:	8082                	ret

000000000000024a <strcmp>:

int
strcmp(const char *p, const char *q)
{
 24a:	1141                	addi	sp,sp,-16
 24c:	e406                	sd	ra,8(sp)
 24e:	e022                	sd	s0,0(sp)
 250:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 252:	00054783          	lbu	a5,0(a0)
 256:	cb91                	beqz	a5,26a <strcmp+0x20>
 258:	0005c703          	lbu	a4,0(a1)
 25c:	00f71763          	bne	a4,a5,26a <strcmp+0x20>
    p++, q++;
 260:	0505                	addi	a0,a0,1
 262:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 264:	00054783          	lbu	a5,0(a0)
 268:	fbe5                	bnez	a5,258 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 26a:	0005c503          	lbu	a0,0(a1)
}
 26e:	40a7853b          	subw	a0,a5,a0
 272:	60a2                	ld	ra,8(sp)
 274:	6402                	ld	s0,0(sp)
 276:	0141                	addi	sp,sp,16
 278:	8082                	ret

000000000000027a <strlen>:

uint
strlen(const char *s)
{
 27a:	1141                	addi	sp,sp,-16
 27c:	e406                	sd	ra,8(sp)
 27e:	e022                	sd	s0,0(sp)
 280:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 282:	00054783          	lbu	a5,0(a0)
 286:	cf91                	beqz	a5,2a2 <strlen+0x28>
 288:	00150793          	addi	a5,a0,1
 28c:	86be                	mv	a3,a5
 28e:	0785                	addi	a5,a5,1
 290:	fff7c703          	lbu	a4,-1(a5)
 294:	ff65                	bnez	a4,28c <strlen+0x12>
 296:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 29a:	60a2                	ld	ra,8(sp)
 29c:	6402                	ld	s0,0(sp)
 29e:	0141                	addi	sp,sp,16
 2a0:	8082                	ret
  for(n = 0; s[n]; n++)
 2a2:	4501                	li	a0,0
 2a4:	bfdd                	j	29a <strlen+0x20>

00000000000002a6 <memset>:

void*
memset(void *dst, int c, uint n)
{
 2a6:	1141                	addi	sp,sp,-16
 2a8:	e406                	sd	ra,8(sp)
 2aa:	e022                	sd	s0,0(sp)
 2ac:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 2ae:	ca19                	beqz	a2,2c4 <memset+0x1e>
 2b0:	87aa                	mv	a5,a0
 2b2:	1602                	slli	a2,a2,0x20
 2b4:	9201                	srli	a2,a2,0x20
 2b6:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 2ba:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 2be:	0785                	addi	a5,a5,1
 2c0:	fee79de3          	bne	a5,a4,2ba <memset+0x14>
  }
  return dst;
}
 2c4:	60a2                	ld	ra,8(sp)
 2c6:	6402                	ld	s0,0(sp)
 2c8:	0141                	addi	sp,sp,16
 2ca:	8082                	ret

00000000000002cc <strchr>:

char*
strchr(const char *s, char c)
{
 2cc:	1141                	addi	sp,sp,-16
 2ce:	e406                	sd	ra,8(sp)
 2d0:	e022                	sd	s0,0(sp)
 2d2:	0800                	addi	s0,sp,16
  for(; *s; s++)
 2d4:	00054783          	lbu	a5,0(a0)
 2d8:	c799                	beqz	a5,2e6 <strchr+0x1a>
    if(*s == c)
 2da:	00f58763          	beq	a1,a5,2e8 <strchr+0x1c>
  for(; *s; s++)
 2de:	0505                	addi	a0,a0,1
 2e0:	00054783          	lbu	a5,0(a0)
 2e4:	fbfd                	bnez	a5,2da <strchr+0xe>
      return (char*)s;
  return 0;
 2e6:	4501                	li	a0,0
}
 2e8:	60a2                	ld	ra,8(sp)
 2ea:	6402                	ld	s0,0(sp)
 2ec:	0141                	addi	sp,sp,16
 2ee:	8082                	ret

00000000000002f0 <gets>:

char*
gets(char *buf, int max)
{
 2f0:	711d                	addi	sp,sp,-96
 2f2:	ec86                	sd	ra,88(sp)
 2f4:	e8a2                	sd	s0,80(sp)
 2f6:	e4a6                	sd	s1,72(sp)
 2f8:	e0ca                	sd	s2,64(sp)
 2fa:	fc4e                	sd	s3,56(sp)
 2fc:	f852                	sd	s4,48(sp)
 2fe:	f456                	sd	s5,40(sp)
 300:	f05a                	sd	s6,32(sp)
 302:	ec5e                	sd	s7,24(sp)
 304:	e862                	sd	s8,16(sp)
 306:	1080                	addi	s0,sp,96
 308:	8baa                	mv	s7,a0
 30a:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 30c:	892a                	mv	s2,a0
 30e:	4481                	li	s1,0
    cc = read(0, &c, 1);
 310:	faf40b13          	addi	s6,s0,-81
 314:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 316:	8c26                	mv	s8,s1
 318:	0014899b          	addiw	s3,s1,1
 31c:	84ce                	mv	s1,s3
 31e:	0349d863          	bge	s3,s4,34e <gets+0x5e>
    cc = read(0, &c, 1);
 322:	8656                	mv	a2,s5
 324:	85da                	mv	a1,s6
 326:	4501                	li	a0,0
 328:	194000ef          	jal	4bc <read>
    if(cc < 1)
 32c:	02a05163          	blez	a0,34e <gets+0x5e>
      break;
    buf[i++] = c;
 330:	faf44783          	lbu	a5,-81(s0)
 334:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 338:	0905                	addi	s2,s2,1
 33a:	ff678713          	addi	a4,a5,-10
 33e:	00173713          	seqz	a4,a4
 342:	17cd                	addi	a5,a5,-13
 344:	0017b793          	seqz	a5,a5
 348:	8fd9                	or	a5,a5,a4
 34a:	d7f1                	beqz	a5,316 <gets+0x26>
    buf[i++] = c;
 34c:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 34e:	9c5e                	add	s8,s8,s7
 350:	000c0023          	sb	zero,0(s8)
  return buf;
}
 354:	855e                	mv	a0,s7
 356:	60e6                	ld	ra,88(sp)
 358:	6446                	ld	s0,80(sp)
 35a:	64a6                	ld	s1,72(sp)
 35c:	6906                	ld	s2,64(sp)
 35e:	79e2                	ld	s3,56(sp)
 360:	7a42                	ld	s4,48(sp)
 362:	7aa2                	ld	s5,40(sp)
 364:	7b02                	ld	s6,32(sp)
 366:	6be2                	ld	s7,24(sp)
 368:	6c42                	ld	s8,16(sp)
 36a:	6125                	addi	sp,sp,96
 36c:	8082                	ret

000000000000036e <stat>:

int
stat(const char *n, struct stat *st)
{
 36e:	1101                	addi	sp,sp,-32
 370:	ec06                	sd	ra,24(sp)
 372:	e822                	sd	s0,16(sp)
 374:	e04a                	sd	s2,0(sp)
 376:	1000                	addi	s0,sp,32
 378:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 37a:	4581                	li	a1,0
 37c:	168000ef          	jal	4e4 <open>
  if(fd < 0)
 380:	02054263          	bltz	a0,3a4 <stat+0x36>
 384:	e426                	sd	s1,8(sp)
 386:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 388:	85ca                	mv	a1,s2
 38a:	172000ef          	jal	4fc <fstat>
 38e:	892a                	mv	s2,a0
  close(fd);
 390:	8526                	mv	a0,s1
 392:	13a000ef          	jal	4cc <close>
  return r;
 396:	64a2                	ld	s1,8(sp)
}
 398:	854a                	mv	a0,s2
 39a:	60e2                	ld	ra,24(sp)
 39c:	6442                	ld	s0,16(sp)
 39e:	6902                	ld	s2,0(sp)
 3a0:	6105                	addi	sp,sp,32
 3a2:	8082                	ret
    return -1;
 3a4:	57fd                	li	a5,-1
 3a6:	893e                	mv	s2,a5
 3a8:	bfc5                	j	398 <stat+0x2a>

00000000000003aa <atoi>:

int
atoi(const char *s)
{
 3aa:	1141                	addi	sp,sp,-16
 3ac:	e406                	sd	ra,8(sp)
 3ae:	e022                	sd	s0,0(sp)
 3b0:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 3b2:	00054683          	lbu	a3,0(a0)
 3b6:	fd06879b          	addiw	a5,a3,-48
 3ba:	0ff7f793          	zext.b	a5,a5
 3be:	4625                	li	a2,9
 3c0:	02f66963          	bltu	a2,a5,3f2 <atoi+0x48>
 3c4:	872a                	mv	a4,a0
  n = 0;
 3c6:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 3c8:	0705                	addi	a4,a4,1
 3ca:	0025179b          	slliw	a5,a0,0x2
 3ce:	9fa9                	addw	a5,a5,a0
 3d0:	0017979b          	slliw	a5,a5,0x1
 3d4:	9fb5                	addw	a5,a5,a3
 3d6:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 3da:	00074683          	lbu	a3,0(a4)
 3de:	fd06879b          	addiw	a5,a3,-48
 3e2:	0ff7f793          	zext.b	a5,a5
 3e6:	fef671e3          	bgeu	a2,a5,3c8 <atoi+0x1e>
  return n;
}
 3ea:	60a2                	ld	ra,8(sp)
 3ec:	6402                	ld	s0,0(sp)
 3ee:	0141                	addi	sp,sp,16
 3f0:	8082                	ret
  n = 0;
 3f2:	4501                	li	a0,0
 3f4:	bfdd                	j	3ea <atoi+0x40>

00000000000003f6 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 3f6:	1141                	addi	sp,sp,-16
 3f8:	e406                	sd	ra,8(sp)
 3fa:	e022                	sd	s0,0(sp)
 3fc:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 3fe:	02b57563          	bgeu	a0,a1,428 <memmove+0x32>
    while(n-- > 0)
 402:	00c05f63          	blez	a2,420 <memmove+0x2a>
 406:	1602                	slli	a2,a2,0x20
 408:	9201                	srli	a2,a2,0x20
 40a:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 40e:	872a                	mv	a4,a0
      *dst++ = *src++;
 410:	0585                	addi	a1,a1,1
 412:	0705                	addi	a4,a4,1
 414:	fff5c683          	lbu	a3,-1(a1)
 418:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 41c:	fee79ae3          	bne	a5,a4,410 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 420:	60a2                	ld	ra,8(sp)
 422:	6402                	ld	s0,0(sp)
 424:	0141                	addi	sp,sp,16
 426:	8082                	ret
    while(n-- > 0)
 428:	fec05ce3          	blez	a2,420 <memmove+0x2a>
    dst += n;
 42c:	00c50733          	add	a4,a0,a2
    src += n;
 430:	95b2                	add	a1,a1,a2
 432:	fff6079b          	addiw	a5,a2,-1
 436:	1782                	slli	a5,a5,0x20
 438:	9381                	srli	a5,a5,0x20
 43a:	fff7c793          	not	a5,a5
 43e:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 440:	15fd                	addi	a1,a1,-1
 442:	177d                	addi	a4,a4,-1
 444:	0005c683          	lbu	a3,0(a1)
 448:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 44c:	fef71ae3          	bne	a4,a5,440 <memmove+0x4a>
 450:	bfc1                	j	420 <memmove+0x2a>

0000000000000452 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 452:	1141                	addi	sp,sp,-16
 454:	e406                	sd	ra,8(sp)
 456:	e022                	sd	s0,0(sp)
 458:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 45a:	ce19                	beqz	a2,478 <memcmp+0x26>
 45c:	1602                	slli	a2,a2,0x20
 45e:	9201                	srli	a2,a2,0x20
 460:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 464:	00054783          	lbu	a5,0(a0)
 468:	0005c703          	lbu	a4,0(a1)
 46c:	00e79b63          	bne	a5,a4,482 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 470:	0505                	addi	a0,a0,1
    p2++;
 472:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 474:	fed518e3          	bne	a0,a3,464 <memcmp+0x12>
  }
  return 0;
 478:	4501                	li	a0,0
}
 47a:	60a2                	ld	ra,8(sp)
 47c:	6402                	ld	s0,0(sp)
 47e:	0141                	addi	sp,sp,16
 480:	8082                	ret
      return *p1 - *p2;
 482:	40e7853b          	subw	a0,a5,a4
 486:	bfd5                	j	47a <memcmp+0x28>

0000000000000488 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 488:	1141                	addi	sp,sp,-16
 48a:	e406                	sd	ra,8(sp)
 48c:	e022                	sd	s0,0(sp)
 48e:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 490:	f67ff0ef          	jal	3f6 <memmove>
}
 494:	60a2                	ld	ra,8(sp)
 496:	6402                	ld	s0,0(sp)
 498:	0141                	addi	sp,sp,16
 49a:	8082                	ret

000000000000049c <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 49c:	4885                	li	a7,1
 ecall
 49e:	00000073          	ecall
 ret
 4a2:	8082                	ret

00000000000004a4 <exit>:
.global exit
exit:
 li a7, SYS_exit
 4a4:	4889                	li	a7,2
 ecall
 4a6:	00000073          	ecall
 ret
 4aa:	8082                	ret

00000000000004ac <wait>:
.global wait
wait:
 li a7, SYS_wait
 4ac:	488d                	li	a7,3
 ecall
 4ae:	00000073          	ecall
 ret
 4b2:	8082                	ret

00000000000004b4 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 4b4:	4891                	li	a7,4
 ecall
 4b6:	00000073          	ecall
 ret
 4ba:	8082                	ret

00000000000004bc <read>:
.global read
read:
 li a7, SYS_read
 4bc:	4895                	li	a7,5
 ecall
 4be:	00000073          	ecall
 ret
 4c2:	8082                	ret

00000000000004c4 <write>:
.global write
write:
 li a7, SYS_write
 4c4:	48c1                	li	a7,16
 ecall
 4c6:	00000073          	ecall
 ret
 4ca:	8082                	ret

00000000000004cc <close>:
.global close
close:
 li a7, SYS_close
 4cc:	48d5                	li	a7,21
 ecall
 4ce:	00000073          	ecall
 ret
 4d2:	8082                	ret

00000000000004d4 <kill>:
.global kill
kill:
 li a7, SYS_kill
 4d4:	4899                	li	a7,6
 ecall
 4d6:	00000073          	ecall
 ret
 4da:	8082                	ret

00000000000004dc <exec>:
.global exec
exec:
 li a7, SYS_exec
 4dc:	489d                	li	a7,7
 ecall
 4de:	00000073          	ecall
 ret
 4e2:	8082                	ret

00000000000004e4 <open>:
.global open
open:
 li a7, SYS_open
 4e4:	48bd                	li	a7,15
 ecall
 4e6:	00000073          	ecall
 ret
 4ea:	8082                	ret

00000000000004ec <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 4ec:	48c5                	li	a7,17
 ecall
 4ee:	00000073          	ecall
 ret
 4f2:	8082                	ret

00000000000004f4 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 4f4:	48c9                	li	a7,18
 ecall
 4f6:	00000073          	ecall
 ret
 4fa:	8082                	ret

00000000000004fc <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 4fc:	48a1                	li	a7,8
 ecall
 4fe:	00000073          	ecall
 ret
 502:	8082                	ret

0000000000000504 <link>:
.global link
link:
 li a7, SYS_link
 504:	48cd                	li	a7,19
 ecall
 506:	00000073          	ecall
 ret
 50a:	8082                	ret

000000000000050c <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 50c:	48d1                	li	a7,20
 ecall
 50e:	00000073          	ecall
 ret
 512:	8082                	ret

0000000000000514 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 514:	48a5                	li	a7,9
 ecall
 516:	00000073          	ecall
 ret
 51a:	8082                	ret

000000000000051c <dup>:
.global dup
dup:
 li a7, SYS_dup
 51c:	48a9                	li	a7,10
 ecall
 51e:	00000073          	ecall
 ret
 522:	8082                	ret

0000000000000524 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 524:	48ad                	li	a7,11
 ecall
 526:	00000073          	ecall
 ret
 52a:	8082                	ret

000000000000052c <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 52c:	48b1                	li	a7,12
 ecall
 52e:	00000073          	ecall
 ret
 532:	8082                	ret

0000000000000534 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 534:	48b5                	li	a7,13
 ecall
 536:	00000073          	ecall
 ret
 53a:	8082                	ret

000000000000053c <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 53c:	48b9                	li	a7,14
 ecall
 53e:	00000073          	ecall
 ret
 542:	8082                	ret

0000000000000544 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 544:	1101                	addi	sp,sp,-32
 546:	ec06                	sd	ra,24(sp)
 548:	e822                	sd	s0,16(sp)
 54a:	1000                	addi	s0,sp,32
 54c:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 550:	4605                	li	a2,1
 552:	fef40593          	addi	a1,s0,-17
 556:	f6fff0ef          	jal	4c4 <write>
}
 55a:	60e2                	ld	ra,24(sp)
 55c:	6442                	ld	s0,16(sp)
 55e:	6105                	addi	sp,sp,32
 560:	8082                	ret

0000000000000562 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 562:	715d                	addi	sp,sp,-80
 564:	e486                	sd	ra,72(sp)
 566:	e0a2                	sd	s0,64(sp)
 568:	f84a                	sd	s2,48(sp)
 56a:	f44e                	sd	s3,40(sp)
 56c:	0880                	addi	s0,sp,80
 56e:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 570:	00d036b3          	snez	a3,a3
 574:	03f5d793          	srli	a5,a1,0x3f
 578:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 57a:	0005871b          	sext.w	a4,a1
  neg = 0;
 57e:	4301                	li	t1,0
  if(sgn && xx < 0){
 580:	c681                	beqz	a3,588 <printint+0x26>
    x = -xx;
 582:	40b0073b          	negw	a4,a1
    neg = 1;
 586:	4305                	li	t1,1
  }

  i = 0;
 588:	fb840993          	addi	s3,s0,-72
  neg = 0;
 58c:	85ce                	mv	a1,s3
  i = 0;
 58e:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 590:	00001817          	auipc	a6,0x1
 594:	85080813          	addi	a6,a6,-1968 # de0 <digits>
 598:	88b6                	mv	a7,a3
 59a:	0016851b          	addiw	a0,a3,1
 59e:	86aa                	mv	a3,a0
 5a0:	02c777bb          	remuw	a5,a4,a2
 5a4:	1782                	slli	a5,a5,0x20
 5a6:	9381                	srli	a5,a5,0x20
 5a8:	97c2                	add	a5,a5,a6
 5aa:	0007c783          	lbu	a5,0(a5)
 5ae:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 5b2:	87ba                	mv	a5,a4
 5b4:	02c7573b          	divuw	a4,a4,a2
 5b8:	0585                	addi	a1,a1,1
 5ba:	fcc7ffe3          	bgeu	a5,a2,598 <printint+0x36>
  if(neg)
 5be:	00030b63          	beqz	t1,5d4 <printint+0x72>
    buf[i++] = '-';
 5c2:	fd040793          	addi	a5,s0,-48
 5c6:	953e                	add	a0,a0,a5
 5c8:	02d00793          	li	a5,45
 5cc:	fef50423          	sb	a5,-24(a0)
 5d0:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 5d4:	02d05563          	blez	a3,5fe <printint+0x9c>
 5d8:	fc26                	sd	s1,56(sp)
 5da:	36fd                	addiw	a3,a3,-1
 5dc:	00d984b3          	add	s1,s3,a3
 5e0:	19fd                	addi	s3,s3,-1
 5e2:	99b6                	add	s3,s3,a3
 5e4:	1682                	slli	a3,a3,0x20
 5e6:	9281                	srli	a3,a3,0x20
 5e8:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 5ec:	0004c583          	lbu	a1,0(s1)
 5f0:	854a                	mv	a0,s2
 5f2:	f53ff0ef          	jal	544 <putc>
  while(--i >= 0)
 5f6:	14fd                	addi	s1,s1,-1
 5f8:	ff349ae3          	bne	s1,s3,5ec <printint+0x8a>
 5fc:	74e2                	ld	s1,56(sp)
}
 5fe:	60a6                	ld	ra,72(sp)
 600:	6406                	ld	s0,64(sp)
 602:	7942                	ld	s2,48(sp)
 604:	79a2                	ld	s3,40(sp)
 606:	6161                	addi	sp,sp,80
 608:	8082                	ret

000000000000060a <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 60a:	711d                	addi	sp,sp,-96
 60c:	ec86                	sd	ra,88(sp)
 60e:	e8a2                	sd	s0,80(sp)
 610:	e4a6                	sd	s1,72(sp)
 612:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 614:	0005c483          	lbu	s1,0(a1)
 618:	28048263          	beqz	s1,89c <vprintf+0x292>
 61c:	e0ca                	sd	s2,64(sp)
 61e:	fc4e                	sd	s3,56(sp)
 620:	f852                	sd	s4,48(sp)
 622:	f456                	sd	s5,40(sp)
 624:	f05a                	sd	s6,32(sp)
 626:	ec5e                	sd	s7,24(sp)
 628:	e862                	sd	s8,16(sp)
 62a:	8b2a                	mv	s6,a0
 62c:	8a2e                	mv	s4,a1
 62e:	8bb2                	mv	s7,a2
  state = 0;
 630:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 632:	4901                	li	s2,0
 634:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 636:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 63a:	06400c13          	li	s8,100
 63e:	a00d                	j	660 <vprintf+0x56>
        putc(fd, c0);
 640:	85a6                	mv	a1,s1
 642:	855a                	mv	a0,s6
 644:	f01ff0ef          	jal	544 <putc>
 648:	a019                	j	64e <vprintf+0x44>
    } else if(state == '%'){
 64a:	03598363          	beq	s3,s5,670 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 64e:	0019079b          	addiw	a5,s2,1
 652:	893e                	mv	s2,a5
 654:	873e                	mv	a4,a5
 656:	97d2                	add	a5,a5,s4
 658:	0007c483          	lbu	s1,0(a5)
 65c:	22048963          	beqz	s1,88e <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 660:	0004879b          	sext.w	a5,s1
    if(state == 0){
 664:	fe0993e3          	bnez	s3,64a <vprintf+0x40>
      if(c0 == '%'){
 668:	fd579ce3          	bne	a5,s5,640 <vprintf+0x36>
        state = '%';
 66c:	89be                	mv	s3,a5
 66e:	b7c5                	j	64e <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 670:	00ea06b3          	add	a3,s4,a4
 674:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 678:	22060763          	beqz	a2,8a6 <vprintf+0x29c>
      if(c0 == 'd'){
 67c:	0b878363          	beq	a5,s8,722 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 680:	f9478693          	addi	a3,a5,-108
 684:	0016b693          	seqz	a3,a3
 688:	f9c60593          	addi	a1,a2,-100
 68c:	0015b593          	seqz	a1,a1
 690:	8df5                	and	a1,a1,a3
 692:	e5c5                	bnez	a1,73a <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 694:	9752                	add	a4,a4,s4
 696:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 69a:	f9460713          	addi	a4,a2,-108
 69e:	00173713          	seqz	a4,a4
 6a2:	8f75                	and	a4,a4,a3
 6a4:	f9c50593          	addi	a1,a0,-100
 6a8:	0015b593          	seqz	a1,a1
 6ac:	8df9                	and	a1,a1,a4
 6ae:	e1dd                	bnez	a1,754 <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 6b0:	07500593          	li	a1,117
 6b4:	0ab78d63          	beq	a5,a1,76e <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 6b8:	f8b60593          	addi	a1,a2,-117
 6bc:	0015b593          	seqz	a1,a1
 6c0:	8df5                	and	a1,a1,a3
 6c2:	e1f1                	bnez	a1,786 <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 6c4:	f8b50593          	addi	a1,a0,-117
 6c8:	0015b593          	seqz	a1,a1
 6cc:	8df9                	and	a1,a1,a4
 6ce:	e9e9                	bnez	a1,7a0 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 6d0:	07800593          	li	a1,120
 6d4:	0eb78363          	beq	a5,a1,7ba <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 6d8:	f8860613          	addi	a2,a2,-120
 6dc:	00163613          	seqz	a2,a2
 6e0:	8ef1                	and	a3,a3,a2
 6e2:	0e069863          	bnez	a3,7d2 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 6e6:	f8850513          	addi	a0,a0,-120
 6ea:	00153513          	seqz	a0,a0
 6ee:	8f69                	and	a4,a4,a0
 6f0:	0e071e63          	bnez	a4,7ec <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 6f4:	07000713          	li	a4,112
 6f8:	10e78663          	beq	a5,a4,804 <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 6fc:	07300713          	li	a4,115
 700:	14e78663          	beq	a5,a4,84c <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 704:	02500713          	li	a4,37
 708:	16e78e63          	beq	a5,a4,884 <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 70c:	02500593          	li	a1,37
 710:	855a                	mv	a0,s6
 712:	e33ff0ef          	jal	544 <putc>
        putc(fd, c0);
 716:	85a6                	mv	a1,s1
 718:	855a                	mv	a0,s6
 71a:	e2bff0ef          	jal	544 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 71e:	4981                	li	s3,0
 720:	b73d                	j	64e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 722:	008b8493          	addi	s1,s7,8
 726:	4685                	li	a3,1
 728:	4629                	li	a2,10
 72a:	000ba583          	lw	a1,0(s7)
 72e:	855a                	mv	a0,s6
 730:	e33ff0ef          	jal	562 <printint>
 734:	8ba6                	mv	s7,s1
      state = 0;
 736:	4981                	li	s3,0
 738:	bf19                	j	64e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 73a:	008b8493          	addi	s1,s7,8
 73e:	4685                	li	a3,1
 740:	4629                	li	a2,10
 742:	000bb583          	ld	a1,0(s7)
 746:	855a                	mv	a0,s6
 748:	e1bff0ef          	jal	562 <printint>
        i += 1;
 74c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 74e:	8ba6                	mv	s7,s1
      state = 0;
 750:	4981                	li	s3,0
 752:	bdf5                	j	64e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 754:	008b8493          	addi	s1,s7,8
 758:	4685                	li	a3,1
 75a:	4629                	li	a2,10
 75c:	000bb583          	ld	a1,0(s7)
 760:	855a                	mv	a0,s6
 762:	e01ff0ef          	jal	562 <printint>
        i += 2;
 766:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 768:	8ba6                	mv	s7,s1
      state = 0;
 76a:	4981                	li	s3,0
        i += 2;
 76c:	b5cd                	j	64e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 76e:	008b8493          	addi	s1,s7,8
 772:	4681                	li	a3,0
 774:	4629                	li	a2,10
 776:	000ba583          	lw	a1,0(s7)
 77a:	855a                	mv	a0,s6
 77c:	de7ff0ef          	jal	562 <printint>
 780:	8ba6                	mv	s7,s1
      state = 0;
 782:	4981                	li	s3,0
 784:	b5e9                	j	64e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 786:	008b8493          	addi	s1,s7,8
 78a:	4681                	li	a3,0
 78c:	4629                	li	a2,10
 78e:	000bb583          	ld	a1,0(s7)
 792:	855a                	mv	a0,s6
 794:	dcfff0ef          	jal	562 <printint>
        i += 1;
 798:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 79a:	8ba6                	mv	s7,s1
      state = 0;
 79c:	4981                	li	s3,0
 79e:	bd45                	j	64e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7a0:	008b8493          	addi	s1,s7,8
 7a4:	4681                	li	a3,0
 7a6:	4629                	li	a2,10
 7a8:	000bb583          	ld	a1,0(s7)
 7ac:	855a                	mv	a0,s6
 7ae:	db5ff0ef          	jal	562 <printint>
        i += 2;
 7b2:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 7b4:	8ba6                	mv	s7,s1
      state = 0;
 7b6:	4981                	li	s3,0
        i += 2;
 7b8:	bd59                	j	64e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 7ba:	008b8493          	addi	s1,s7,8
 7be:	4681                	li	a3,0
 7c0:	4641                	li	a2,16
 7c2:	000ba583          	lw	a1,0(s7)
 7c6:	855a                	mv	a0,s6
 7c8:	d9bff0ef          	jal	562 <printint>
 7cc:	8ba6                	mv	s7,s1
      state = 0;
 7ce:	4981                	li	s3,0
 7d0:	bdbd                	j	64e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 7d2:	008b8493          	addi	s1,s7,8
 7d6:	4681                	li	a3,0
 7d8:	4641                	li	a2,16
 7da:	000bb583          	ld	a1,0(s7)
 7de:	855a                	mv	a0,s6
 7e0:	d83ff0ef          	jal	562 <printint>
        i += 1;
 7e4:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 7e6:	8ba6                	mv	s7,s1
      state = 0;
 7e8:	4981                	li	s3,0
 7ea:	b595                	j	64e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 7ec:	008b8493          	addi	s1,s7,8
 7f0:	4641                	li	a2,16
 7f2:	000bb583          	ld	a1,0(s7)
 7f6:	855a                	mv	a0,s6
 7f8:	d6bff0ef          	jal	562 <printint>
        i += 2;
 7fc:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 7fe:	8ba6                	mv	s7,s1
      state = 0;
 800:	4981                	li	s3,0
        i += 2;
 802:	b5b1                	j	64e <vprintf+0x44>
 804:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 806:	008b8793          	addi	a5,s7,8
 80a:	8cbe                	mv	s9,a5
 80c:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 810:	03000593          	li	a1,48
 814:	855a                	mv	a0,s6
 816:	d2fff0ef          	jal	544 <putc>
  putc(fd, 'x');
 81a:	07800593          	li	a1,120
 81e:	855a                	mv	a0,s6
 820:	d25ff0ef          	jal	544 <putc>
 824:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 826:	00000b97          	auipc	s7,0x0
 82a:	5bab8b93          	addi	s7,s7,1466 # de0 <digits>
 82e:	03c9d793          	srli	a5,s3,0x3c
 832:	97de                	add	a5,a5,s7
 834:	0007c583          	lbu	a1,0(a5)
 838:	855a                	mv	a0,s6
 83a:	d0bff0ef          	jal	544 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 83e:	0992                	slli	s3,s3,0x4
 840:	34fd                	addiw	s1,s1,-1
 842:	f4f5                	bnez	s1,82e <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 844:	8be6                	mv	s7,s9
      state = 0;
 846:	4981                	li	s3,0
 848:	6ca2                	ld	s9,8(sp)
 84a:	b511                	j	64e <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 84c:	008b8993          	addi	s3,s7,8
 850:	000bb483          	ld	s1,0(s7)
 854:	cc91                	beqz	s1,870 <vprintf+0x266>
        for(; *s; s++)
 856:	0004c583          	lbu	a1,0(s1)
 85a:	c195                	beqz	a1,87e <vprintf+0x274>
          putc(fd, *s);
 85c:	855a                	mv	a0,s6
 85e:	ce7ff0ef          	jal	544 <putc>
        for(; *s; s++)
 862:	0485                	addi	s1,s1,1
 864:	0004c583          	lbu	a1,0(s1)
 868:	f9f5                	bnez	a1,85c <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 86a:	8bce                	mv	s7,s3
      state = 0;
 86c:	4981                	li	s3,0
 86e:	b3c5                	j	64e <vprintf+0x44>
          s = "(null)";
 870:	00000497          	auipc	s1,0x0
 874:	54048493          	addi	s1,s1,1344 # db0 <thread_switch+0x1aa>
        for(; *s; s++)
 878:	02800593          	li	a1,40
 87c:	b7c5                	j	85c <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 87e:	8bce                	mv	s7,s3
      state = 0;
 880:	4981                	li	s3,0
 882:	b3f1                	j	64e <vprintf+0x44>
        putc(fd, '%');
 884:	85be                	mv	a1,a5
 886:	855a                	mv	a0,s6
 888:	cbdff0ef          	jal	544 <putc>
 88c:	bd49                	j	71e <vprintf+0x114>
 88e:	6906                	ld	s2,64(sp)
 890:	79e2                	ld	s3,56(sp)
 892:	7a42                	ld	s4,48(sp)
 894:	7aa2                	ld	s5,40(sp)
 896:	7b02                	ld	s6,32(sp)
 898:	6be2                	ld	s7,24(sp)
 89a:	6c42                	ld	s8,16(sp)
    }
  }
}
 89c:	60e6                	ld	ra,88(sp)
 89e:	6446                	ld	s0,80(sp)
 8a0:	64a6                	ld	s1,72(sp)
 8a2:	6125                	addi	sp,sp,96
 8a4:	8082                	ret
      if(c0 == 'd'){
 8a6:	06400713          	li	a4,100
 8aa:	e6e78ce3          	beq	a5,a4,722 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 8ae:	f9478693          	addi	a3,a5,-108
 8b2:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 8b6:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 8b8:	4701                	li	a4,0
 8ba:	bbdd                	j	6b0 <vprintf+0xa6>

00000000000008bc <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 8bc:	715d                	addi	sp,sp,-80
 8be:	ec06                	sd	ra,24(sp)
 8c0:	e822                	sd	s0,16(sp)
 8c2:	1000                	addi	s0,sp,32
 8c4:	e010                	sd	a2,0(s0)
 8c6:	e414                	sd	a3,8(s0)
 8c8:	e818                	sd	a4,16(s0)
 8ca:	ec1c                	sd	a5,24(s0)
 8cc:	03043023          	sd	a6,32(s0)
 8d0:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 8d4:	8622                	mv	a2,s0
 8d6:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 8da:	d31ff0ef          	jal	60a <vprintf>
}
 8de:	60e2                	ld	ra,24(sp)
 8e0:	6442                	ld	s0,16(sp)
 8e2:	6161                	addi	sp,sp,80
 8e4:	8082                	ret

00000000000008e6 <printf>:

void
printf(const char *fmt, ...)
{
 8e6:	711d                	addi	sp,sp,-96
 8e8:	ec06                	sd	ra,24(sp)
 8ea:	e822                	sd	s0,16(sp)
 8ec:	1000                	addi	s0,sp,32
 8ee:	e40c                	sd	a1,8(s0)
 8f0:	e810                	sd	a2,16(s0)
 8f2:	ec14                	sd	a3,24(s0)
 8f4:	f018                	sd	a4,32(s0)
 8f6:	f41c                	sd	a5,40(s0)
 8f8:	03043823          	sd	a6,48(s0)
 8fc:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 900:	00840613          	addi	a2,s0,8
 904:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 908:	85aa                	mv	a1,a0
 90a:	4505                	li	a0,1
 90c:	cffff0ef          	jal	60a <vprintf>
}
 910:	60e2                	ld	ra,24(sp)
 912:	6442                	ld	s0,16(sp)
 914:	6125                	addi	sp,sp,96
 916:	8082                	ret

0000000000000918 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 918:	1141                	addi	sp,sp,-16
 91a:	e406                	sd	ra,8(sp)
 91c:	e022                	sd	s0,0(sp)
 91e:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 920:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 924:	00000797          	auipc	a5,0x0
 928:	6dc7b783          	ld	a5,1756(a5) # 1000 <freep>
 92c:	a095                	j	990 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 92e:	ff852583          	lw	a1,-8(a0)
 932:	6390                	ld	a2,0(a5)
 934:	02059813          	slli	a6,a1,0x20
 938:	01c85693          	srli	a3,a6,0x1c
 93c:	96ba                	add	a3,a3,a4
 93e:	02d60563          	beq	a2,a3,968 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 942:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 946:	4790                	lw	a2,8(a5)
 948:	02061593          	slli	a1,a2,0x20
 94c:	01c5d693          	srli	a3,a1,0x1c
 950:	96be                	add	a3,a3,a5
 952:	02d70263          	beq	a4,a3,976 <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 956:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 958:	00000717          	auipc	a4,0x0
 95c:	6af73423          	sd	a5,1704(a4) # 1000 <freep>
}
 960:	60a2                	ld	ra,8(sp)
 962:	6402                	ld	s0,0(sp)
 964:	0141                	addi	sp,sp,16
 966:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 968:	4614                	lw	a3,8(a2)
 96a:	9ead                	addw	a3,a3,a1
 96c:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 970:	6394                	ld	a3,0(a5)
 972:	6290                	ld	a2,0(a3)
 974:	b7f9                	j	942 <free+0x2a>
    p->s.size += bp->s.size;
 976:	ff852703          	lw	a4,-8(a0)
 97a:	9f31                	addw	a4,a4,a2
 97c:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 97e:	ff053703          	ld	a4,-16(a0)
 982:	bfd1                	j	956 <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 984:	6394                	ld	a3,0(a5)
 986:	00d7e463          	bltu	a5,a3,98e <free+0x76>
 98a:	fad762e3          	bltu	a4,a3,92e <free+0x16>
 98e:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 990:	fee7fae3          	bgeu	a5,a4,984 <free+0x6c>
 994:	6394                	ld	a3,0(a5)
 996:	f8d76ce3          	bltu	a4,a3,92e <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 99a:	f8d7fae3          	bgeu	a5,a3,92e <free+0x16>
 99e:	87b6                	mv	a5,a3
 9a0:	bfc5                	j	990 <free+0x78>

00000000000009a2 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 9a2:	7139                	addi	sp,sp,-64
 9a4:	fc06                	sd	ra,56(sp)
 9a6:	f822                	sd	s0,48(sp)
 9a8:	f04a                	sd	s2,32(sp)
 9aa:	ec4e                	sd	s3,24(sp)
 9ac:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 9ae:	02051993          	slli	s3,a0,0x20
 9b2:	0209d993          	srli	s3,s3,0x20
 9b6:	09bd                	addi	s3,s3,15
 9b8:	0049d993          	srli	s3,s3,0x4
 9bc:	2985                	addiw	s3,s3,1
 9be:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 9c0:	00000517          	auipc	a0,0x0
 9c4:	64053503          	ld	a0,1600(a0) # 1000 <freep>
 9c8:	c905                	beqz	a0,9f8 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 9ca:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 9cc:	4798                	lw	a4,8(a5)
 9ce:	09377663          	bgeu	a4,s3,a5a <malloc+0xb8>
 9d2:	f426                	sd	s1,40(sp)
 9d4:	e852                	sd	s4,16(sp)
 9d6:	e456                	sd	s5,8(sp)
 9d8:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 9da:	8a4e                	mv	s4,s3
 9dc:	6705                	lui	a4,0x1
 9de:	00e9f363          	bgeu	s3,a4,9e4 <malloc+0x42>
 9e2:	6a05                	lui	s4,0x1
 9e4:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 9e8:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 9ec:	00000497          	auipc	s1,0x0
 9f0:	61448493          	addi	s1,s1,1556 # 1000 <freep>
  if(p == (char*)-1)
 9f4:	5afd                	li	s5,-1
 9f6:	a83d                	j	a34 <malloc+0x92>
 9f8:	f426                	sd	s1,40(sp)
 9fa:	e852                	sd	s4,16(sp)
 9fc:	e456                	sd	s5,8(sp)
 9fe:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 a00:	00000797          	auipc	a5,0x0
 a04:	61078793          	addi	a5,a5,1552 # 1010 <base>
 a08:	00000717          	auipc	a4,0x0
 a0c:	5ef73c23          	sd	a5,1528(a4) # 1000 <freep>
 a10:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 a12:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 a16:	b7d1                	j	9da <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 a18:	6398                	ld	a4,0(a5)
 a1a:	e118                	sd	a4,0(a0)
 a1c:	a899                	j	a72 <malloc+0xd0>
  hp->s.size = nu;
 a1e:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 a22:	0541                	addi	a0,a0,16
 a24:	ef5ff0ef          	jal	918 <free>
  return freep;
 a28:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 a2a:	c125                	beqz	a0,a8a <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a2c:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a2e:	4798                	lw	a4,8(a5)
 a30:	03277163          	bgeu	a4,s2,a52 <malloc+0xb0>
    if(p == freep)
 a34:	6098                	ld	a4,0(s1)
 a36:	853e                	mv	a0,a5
 a38:	fef71ae3          	bne	a4,a5,a2c <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 a3c:	8552                	mv	a0,s4
 a3e:	aefff0ef          	jal	52c <sbrk>
  if(p == (char*)-1)
 a42:	fd551ee3          	bne	a0,s5,a1e <malloc+0x7c>
        return 0;
 a46:	4501                	li	a0,0
 a48:	74a2                	ld	s1,40(sp)
 a4a:	6a42                	ld	s4,16(sp)
 a4c:	6aa2                	ld	s5,8(sp)
 a4e:	6b02                	ld	s6,0(sp)
 a50:	a03d                	j	a7e <malloc+0xdc>
 a52:	74a2                	ld	s1,40(sp)
 a54:	6a42                	ld	s4,16(sp)
 a56:	6aa2                	ld	s5,8(sp)
 a58:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 a5a:	fae90fe3          	beq	s2,a4,a18 <malloc+0x76>
        p->s.size -= nunits;
 a5e:	4137073b          	subw	a4,a4,s3
 a62:	c798                	sw	a4,8(a5)
        p += p->s.size;
 a64:	02071693          	slli	a3,a4,0x20
 a68:	01c6d713          	srli	a4,a3,0x1c
 a6c:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 a6e:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 a72:	00000717          	auipc	a4,0x0
 a76:	58a73723          	sd	a0,1422(a4) # 1000 <freep>
      return (void*)(p + 1);
 a7a:	01078513          	addi	a0,a5,16
  }
}
 a7e:	70e2                	ld	ra,56(sp)
 a80:	7442                	ld	s0,48(sp)
 a82:	7902                	ld	s2,32(sp)
 a84:	69e2                	ld	s3,24(sp)
 a86:	6121                	addi	sp,sp,64
 a88:	8082                	ret
 a8a:	74a2                	ld	s1,40(sp)
 a8c:	6a42                	ld	s4,16(sp)
 a8e:	6aa2                	ld	s5,8(sp)
 a90:	6b02                	ld	s6,0(sp)
 a92:	b7f5                	j	a7e <malloc+0xdc>

0000000000000a94 <thread_init>:
struct thread *current_thread;
extern void thread_switch(uint64, uint64);
              
void 
thread_init(void)
{
 a94:	1141                	addi	sp,sp,-16
 a96:	e406                	sd	ra,8(sp)
 a98:	e022                	sd	s0,0(sp)
 a9a:	0800                	addi	s0,sp,16
  // main() is thread 0, which will make the first invocation to
  // thread_schedule(). It needs a stack so that the first thread_switch() can
  // save thread 0's state.
  current_thread = &all_thread[0];
 a9c:	00000797          	auipc	a5,0x0
 aa0:	58478793          	addi	a5,a5,1412 # 1020 <all_thread>
 aa4:	00000717          	auipc	a4,0x0
 aa8:	56f73223          	sd	a5,1380(a4) # 1008 <current_thread>
  current_thread->state = RUNNING;
 aac:	00002717          	auipc	a4,0x2
 ab0:	57470713          	addi	a4,a4,1396 # 3020 <all_thread+0x2000>
 ab4:	4785                	li	a5,1
 ab6:	c31c                	sw	a5,0(a4)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 ab8:	00002797          	auipc	a5,0x2
 abc:	4f878793          	addi	a5,a5,1272 # 2fb0 <all_thread+0x1f90>
  return (struct context *)(top & ~(uint64)0xf);
 ac0:	9bc1                	andi	a5,a5,-16
  // Thread 0 runs on the process's own stack, but the first thread_switch()
  // still needs a writable place to save its context.
  current_thread->context = thread_context_slot(current_thread);
 ac2:	e71c                	sd	a5,8(a4)
}
 ac4:	60a2                	ld	ra,8(sp)
 ac6:	6402                	ld	s0,0(sp)
 ac8:	0141                	addi	sp,sp,16
 aca:	8082                	ret

0000000000000acc <thread_schedule>:

void 
thread_schedule(void)
{
 acc:	1141                	addi	sp,sp,-16
 ace:	e406                	sd	ra,8(sp)
 ad0:	e022                	sd	s0,0(sp)
 ad2:	0800                	addi	s0,sp,16
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
 ad4:	00000597          	auipc	a1,0x0
 ad8:	5345b583          	ld	a1,1332(a1) # 1008 <current_thread>
 adc:	6789                	lui	a5,0x2
 ade:	07c1                	addi	a5,a5,16 # 2010 <all_thread+0xff0>
 ae0:	97ae                	add	a5,a5,a1
 ae2:	4711                	li	a4,4
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
 ae4:	00008897          	auipc	a7,0x8
 ae8:	57c88893          	addi	a7,a7,1404 # 9060 <all_thread+0x8040>
      t = all_thread;
    if(t->state == RUNNABLE) {
 aec:	6809                	lui	a6,0x2
 aee:	4509                	li	a0,2
      next_thread = t;
      break;
    }
    t = t + 1;
 af0:	01080613          	addi	a2,a6,16 # 2010 <all_thread+0xff0>
 af4:	a809                	j	b06 <thread_schedule+0x3a>
    if(t->state == RUNNABLE) {
 af6:	010786b3          	add	a3,a5,a6
 afa:	4294                	lw	a3,0(a3)
 afc:	02a68563          	beq	a3,a0,b26 <thread_schedule+0x5a>
    t = t + 1;
 b00:	97b2                	add	a5,a5,a2
  for(int i = 0; i < MAX_THREAD; i++){
 b02:	377d                	addiw	a4,a4,-1
 b04:	cb01                	beqz	a4,b14 <thread_schedule+0x48>
    if(t >= all_thread + MAX_THREAD)
 b06:	ff17e8e3          	bltu	a5,a7,af6 <thread_schedule+0x2a>
      t = all_thread;
 b0a:	00000797          	auipc	a5,0x0
 b0e:	51678793          	addi	a5,a5,1302 # 1020 <all_thread>
 b12:	b7d5                	j	af6 <thread_schedule+0x2a>
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
 b14:	00000517          	auipc	a0,0x0
 b18:	2a450513          	addi	a0,a0,676 # db8 <thread_switch+0x1b2>
 b1c:	dcbff0ef          	jal	8e6 <printf>
    exit(-1);
 b20:	557d                	li	a0,-1
 b22:	983ff0ef          	jal	4a4 <exit>
  }

  if (current_thread != next_thread) {         /* switch threads?  */
 b26:	02f58163          	beq	a1,a5,b48 <thread_schedule+0x7c>
    next_thread->state = RUNNING;
 b2a:	6689                	lui	a3,0x2
 b2c:	00d78733          	add	a4,a5,a3
 b30:	4605                	li	a2,1
 b32:	c310                	sw	a2,0(a4)
    t = current_thread;
    current_thread = next_thread;
 b34:	00000617          	auipc	a2,0x0
 b38:	4cf63a23          	sd	a5,1236(a2) # 1008 <current_thread>
    thread_switch((uint64)t->context, (uint64)next_thread->context);
 b3c:	00d587b3          	add	a5,a1,a3
 b40:	670c                	ld	a1,8(a4)
 b42:	6788                	ld	a0,8(a5)
 b44:	0c2000ef          	jal	c06 <thread_switch>
  } else
    next_thread = 0;
}
 b48:	60a2                	ld	ra,8(sp)
 b4a:	6402                	ld	s0,0(sp)
 b4c:	0141                	addi	sp,sp,16
 b4e:	8082                	ret

0000000000000b50 <thread_create>:

void 
thread_create(void (*func)())
{
 b50:	1101                	addi	sp,sp,-32
 b52:	ec06                	sd	ra,24(sp)
 b54:	e822                	sd	s0,16(sp)
 b56:	e426                	sd	s1,8(sp)
 b58:	e04a                	sd	s2,0(sp)
 b5a:	1000                	addi	s0,sp,32
 b5c:	892a                	mv	s2,a0
  struct thread *t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 b5e:	00002797          	auipc	a5,0x2
 b62:	4d278793          	addi	a5,a5,1234 # 3030 <all_thread+0x2010>
 b66:	0000a597          	auipc	a1,0xa
 b6a:	50a58593          	addi	a1,a1,1290 # b070 <all_thread+0xa050>
 b6e:	6609                	lui	a2,0x2
 b70:	0641                	addi	a2,a2,16 # 2010 <all_thread+0xff0>
    if (t->state == FREE) break;
 b72:	873e                	mv	a4,a5
 b74:	ff07a683          	lw	a3,-16(a5)
 b78:	ce9d                	beqz	a3,bb6 <thread_create+0x66>
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 b7a:	97b2                	add	a5,a5,a2
 b7c:	feb79be3          	bne	a5,a1,b72 <thread_create+0x22>
  }
  t->state = RUNNABLE;
 b80:	6489                	lui	s1,0x2
 b82:	94ba                	add	s1,s1,a4
 b84:	4789                	li	a5,2
 b86:	c09c                	sw	a5,0(s1)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 b88:	6789                	lui	a5,0x2
 b8a:	f9078793          	addi	a5,a5,-112 # 1f90 <all_thread+0xf70>
 b8e:	973e                	add	a4,a4,a5
  return (struct context *)(top & ~(uint64)0xf);
 b90:	ff077513          	andi	a0,a4,-16
  // A never-run thread has no saved state, so construct one: thread_switch()
  // restores ra and sp, and `ret` then starts func on this thread's own stack.
  t->context = thread_context_slot(t);
 b94:	e488                	sd	a0,8(s1)
  memset(t->context, 0, sizeof(struct context));
 b96:	07000613          	li	a2,112
 b9a:	4581                	li	a1,0
 b9c:	f0aff0ef          	jal	2a6 <memset>
  t->context->ra = (uint64)func;
 ba0:	649c                	ld	a5,8(s1)
 ba2:	0127b023          	sd	s2,0(a5)
  t->context->sp = (uint64)t->context;   // 16-byte aligned, grows down
 ba6:	649c                	ld	a5,8(s1)
 ba8:	e79c                	sd	a5,8(a5)
}
 baa:	60e2                	ld	ra,24(sp)
 bac:	6442                	ld	s0,16(sp)
 bae:	64a2                	ld	s1,8(sp)
 bb0:	6902                	ld	s2,0(sp)
 bb2:	6105                	addi	sp,sp,32
 bb4:	8082                	ret
 bb6:	7779                	lui	a4,0xffffe
 bb8:	1741                	addi	a4,a4,-16 # ffffffffffffdff0 <all_thread+0xffffffffffffcfd0>
 bba:	973e                	add	a4,a4,a5
 bbc:	b7d1                	j	b80 <thread_create+0x30>

0000000000000bbe <thread_yield>:

void 
thread_yield(void)
{
 bbe:	1141                	addi	sp,sp,-16
 bc0:	e406                	sd	ra,8(sp)
 bc2:	e022                	sd	s0,0(sp)
 bc4:	0800                	addi	s0,sp,16
  current_thread->state = RUNNABLE;
 bc6:	00000797          	auipc	a5,0x0
 bca:	4427b783          	ld	a5,1090(a5) # 1008 <current_thread>
 bce:	6709                	lui	a4,0x2
 bd0:	97ba                	add	a5,a5,a4
 bd2:	4709                	li	a4,2
 bd4:	c398                	sw	a4,0(a5)
  thread_schedule();
 bd6:	ef7ff0ef          	jal	acc <thread_schedule>
}
 bda:	60a2                	ld	ra,8(sp)
 bdc:	6402                	ld	s0,0(sp)
 bde:	0141                	addi	sp,sp,16
 be0:	8082                	ret

0000000000000be2 <thread_exit>:

void thread_exit(void) {
 be2:	1141                	addi	sp,sp,-16
 be4:	e406                	sd	ra,8(sp)
 be6:	e022                	sd	s0,0(sp)
 be8:	0800                	addi	s0,sp,16
  current_thread->state = FREE;
 bea:	00000797          	auipc	a5,0x0
 bee:	41e7b783          	ld	a5,1054(a5) # 1008 <current_thread>
 bf2:	6709                	lui	a4,0x2
 bf4:	97ba                	add	a5,a5,a4
 bf6:	0007a023          	sw	zero,0(a5)
  thread_schedule();
 bfa:	ed3ff0ef          	jal	acc <thread_schedule>
}
 bfe:	60a2                	ld	ra,8(sp)
 c00:	6402                	ld	s0,0(sp)
 c02:	0141                	addi	sp,sp,16
 c04:	8082                	ret

0000000000000c06 <thread_switch>:
 c06:	00153023          	sd	ra,0(a0)
 c0a:	00253423          	sd	sp,8(a0)
 c0e:	e900                	sd	s0,16(a0)
 c10:	ed04                	sd	s1,24(a0)
 c12:	03253023          	sd	s2,32(a0)
 c16:	03353423          	sd	s3,40(a0)
 c1a:	03453823          	sd	s4,48(a0)
 c1e:	03553c23          	sd	s5,56(a0)
 c22:	05653023          	sd	s6,64(a0)
 c26:	05753423          	sd	s7,72(a0)
 c2a:	05853823          	sd	s8,80(a0)
 c2e:	05953c23          	sd	s9,88(a0)
 c32:	07a53023          	sd	s10,96(a0)
 c36:	07b53423          	sd	s11,104(a0)
 c3a:	0005b083          	ld	ra,0(a1)
 c3e:	0085b103          	ld	sp,8(a1)
 c42:	6980                	ld	s0,16(a1)
 c44:	6d84                	ld	s1,24(a1)
 c46:	0205b903          	ld	s2,32(a1)
 c4a:	0285b983          	ld	s3,40(a1)
 c4e:	0305ba03          	ld	s4,48(a1)
 c52:	0385ba83          	ld	s5,56(a1)
 c56:	0405bb03          	ld	s6,64(a1)
 c5a:	0485bb83          	ld	s7,72(a1)
 c5e:	0505bc03          	ld	s8,80(a1)
 c62:	0585bc83          	ld	s9,88(a1)
 c66:	0605bd03          	ld	s10,96(a1)
 c6a:	0685bd83          	ld	s11,104(a1)
 c6e:	8082                	ret
