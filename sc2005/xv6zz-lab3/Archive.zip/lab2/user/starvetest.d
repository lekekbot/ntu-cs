user/starvetest.o: user/starvetest.c kernel/types.h user/user.h
