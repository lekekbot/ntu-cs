
user/_grep:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <matchstar>:
  return 0;
}

// matchstar: search for c*re at beginning of text
int matchstar(int c, char *re, char *text)
{
   0:	7179                	addi	sp,sp,-48
   2:	f406                	sd	ra,40(sp)
   4:	f022                	sd	s0,32(sp)
   6:	ec26                	sd	s1,24(sp)
   8:	e84a                	sd	s2,16(sp)
   a:	e44e                	sd	s3,8(sp)
   c:	e052                	sd	s4,0(sp)
   e:	1800                	addi	s0,sp,48
  10:	892a                	mv	s2,a0
  12:	89ae                	mv	s3,a1
  14:	84b2                	mv	s1,a2
  do{  // a * matches zero or more instances
    if(matchhere(re, text))
      return 1;
  }while(*text!='\0' && (*text++==c || c=='.'));
  16:	fd250a13          	addi	s4,a0,-46
  1a:	001a3a13          	seqz	s4,s4
    if(matchhere(re, text))
  1e:	85a6                	mv	a1,s1
  20:	854e                	mv	a0,s3
  22:	030000ef          	jal	52 <matchhere>
  26:	ed09                	bnez	a0,40 <matchstar+0x40>
  }while(*text!='\0' && (*text++==c || c=='.'));
  28:	0004c783          	lbu	a5,0(s1)
  2c:	cb99                	beqz	a5,42 <matchstar+0x42>
  2e:	0485                	addi	s1,s1,1
  30:	412787b3          	sub	a5,a5,s2
  34:	0017b793          	seqz	a5,a5
  38:	00fa67b3          	or	a5,s4,a5
  3c:	f3ed                	bnez	a5,1e <matchstar+0x1e>
  3e:	a011                	j	42 <matchstar+0x42>
      return 1;
  40:	4505                	li	a0,1
  return 0;
}
  42:	70a2                	ld	ra,40(sp)
  44:	7402                	ld	s0,32(sp)
  46:	64e2                	ld	s1,24(sp)
  48:	6942                	ld	s2,16(sp)
  4a:	69a2                	ld	s3,8(sp)
  4c:	6a02                	ld	s4,0(sp)
  4e:	6145                	addi	sp,sp,48
  50:	8082                	ret

0000000000000052 <matchhere>:
  if(re[0] == '\0')
  52:	00054703          	lbu	a4,0(a0)
  56:	c735                	beqz	a4,c2 <matchhere+0x70>
{
  58:	1141                	addi	sp,sp,-16
  5a:	e406                	sd	ra,8(sp)
  5c:	e022                	sd	s0,0(sp)
  5e:	0800                	addi	s0,sp,16
  if(re[1] == '*')
  60:	00154783          	lbu	a5,1(a0)
  64:	02a00693          	li	a3,42
  68:	02d78c63          	beq	a5,a3,a0 <matchhere+0x4e>
  if(re[0] == '$' && re[1] == '\0')
  6c:	0017b793          	seqz	a5,a5
  70:	fdc70693          	addi	a3,a4,-36
  74:	0016b693          	seqz	a3,a3
  78:	8ff5                	and	a5,a5,a3
  7a:	eb95                	bnez	a5,ae <matchhere+0x5c>
  if(*text!='\0' && (re[0]=='.' || re[0]==*text))
  7c:	0005c783          	lbu	a5,0(a1)
  80:	cb99                	beqz	a5,96 <matchhere+0x44>
  82:	40f707b3          	sub	a5,a4,a5
  86:	0017b793          	seqz	a5,a5
  8a:	fd270713          	addi	a4,a4,-46
  8e:	00173713          	seqz	a4,a4
  92:	8fd9                	or	a5,a5,a4
  94:	e395                	bnez	a5,b8 <matchhere+0x66>
  return 0;
  96:	4501                	li	a0,0
}
  98:	60a2                	ld	ra,8(sp)
  9a:	6402                	ld	s0,0(sp)
  9c:	0141                	addi	sp,sp,16
  9e:	8082                	ret
    return matchstar(re[0], re+2, text);
  a0:	862e                	mv	a2,a1
  a2:	00250593          	addi	a1,a0,2
  a6:	853a                	mv	a0,a4
  a8:	f59ff0ef          	jal	0 <matchstar>
  ac:	b7f5                	j	98 <matchhere+0x46>
    return *text == '\0';
  ae:	0005c503          	lbu	a0,0(a1)
  b2:	00153513          	seqz	a0,a0
  b6:	b7cd                	j	98 <matchhere+0x46>
    return matchhere(re+1, text+1);
  b8:	0585                	addi	a1,a1,1
  ba:	0505                	addi	a0,a0,1
  bc:	f97ff0ef          	jal	52 <matchhere>
  c0:	bfe1                	j	98 <matchhere+0x46>
    return 1;
  c2:	4505                	li	a0,1
}
  c4:	8082                	ret

00000000000000c6 <match>:
{
  c6:	1101                	addi	sp,sp,-32
  c8:	ec06                	sd	ra,24(sp)
  ca:	e822                	sd	s0,16(sp)
  cc:	e426                	sd	s1,8(sp)
  ce:	e04a                	sd	s2,0(sp)
  d0:	1000                	addi	s0,sp,32
  d2:	892a                	mv	s2,a0
  d4:	84ae                	mv	s1,a1
  if(re[0] == '^')
  d6:	00054703          	lbu	a4,0(a0)
  da:	05e00793          	li	a5,94
  de:	00f70c63          	beq	a4,a5,f6 <match+0x30>
    if(matchhere(re, text))
  e2:	85a6                	mv	a1,s1
  e4:	854a                	mv	a0,s2
  e6:	f6dff0ef          	jal	52 <matchhere>
  ea:	e911                	bnez	a0,fe <match+0x38>
  }while(*text++ != '\0');
  ec:	0485                	addi	s1,s1,1
  ee:	fff4c783          	lbu	a5,-1(s1)
  f2:	fbe5                	bnez	a5,e2 <match+0x1c>
  f4:	a031                	j	100 <match+0x3a>
    return matchhere(re+1, text);
  f6:	0505                	addi	a0,a0,1
  f8:	f5bff0ef          	jal	52 <matchhere>
  fc:	a011                	j	100 <match+0x3a>
      return 1;
  fe:	4505                	li	a0,1
}
 100:	60e2                	ld	ra,24(sp)
 102:	6442                	ld	s0,16(sp)
 104:	64a2                	ld	s1,8(sp)
 106:	6902                	ld	s2,0(sp)
 108:	6105                	addi	sp,sp,32
 10a:	8082                	ret

000000000000010c <grep>:
{
 10c:	711d                	addi	sp,sp,-96
 10e:	ec86                	sd	ra,88(sp)
 110:	e8a2                	sd	s0,80(sp)
 112:	e4a6                	sd	s1,72(sp)
 114:	e0ca                	sd	s2,64(sp)
 116:	fc4e                	sd	s3,56(sp)
 118:	f852                	sd	s4,48(sp)
 11a:	f456                	sd	s5,40(sp)
 11c:	f05a                	sd	s6,32(sp)
 11e:	ec5e                	sd	s7,24(sp)
 120:	e862                	sd	s8,16(sp)
 122:	e466                	sd	s9,8(sp)
 124:	e06a                	sd	s10,0(sp)
 126:	1080                	addi	s0,sp,96
 128:	8aaa                	mv	s5,a0
 12a:	8cae                	mv	s9,a1
  m = 0;
 12c:	4b01                	li	s6,0
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0){
 12e:	3ff00d13          	li	s10,1023
 132:	00001b97          	auipc	s7,0x1
 136:	edeb8b93          	addi	s7,s7,-290 # 1010 <buf>
    while((q = strchr(p, '\n')) != 0){
 13a:	49a9                	li	s3,10
        write(1, p, q+1 - p);
 13c:	4c05                	li	s8,1
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0){
 13e:	a82d                	j	178 <grep+0x6c>
      p = q+1;
 140:	00148913          	addi	s2,s1,1
    while((q = strchr(p, '\n')) != 0){
 144:	85ce                	mv	a1,s3
 146:	854a                	mv	a0,s2
 148:	1dc000ef          	jal	324 <strchr>
 14c:	84aa                	mv	s1,a0
 14e:	c11d                	beqz	a0,174 <grep+0x68>
      *q = 0;
 150:	00048023          	sb	zero,0(s1)
      if(match(pattern, p)){
 154:	85ca                	mv	a1,s2
 156:	8556                	mv	a0,s5
 158:	f6fff0ef          	jal	c6 <match>
 15c:	d175                	beqz	a0,140 <grep+0x34>
        *q = '\n';
 15e:	01348023          	sb	s3,0(s1)
        write(1, p, q+1 - p);
 162:	00148613          	addi	a2,s1,1
 166:	4126063b          	subw	a2,a2,s2
 16a:	85ca                	mv	a1,s2
 16c:	8562                	mv	a0,s8
 16e:	3ae000ef          	jal	51c <write>
 172:	b7f9                	j	140 <grep+0x34>
    if(m > 0){
 174:	03604463          	bgtz	s6,19c <grep+0x90>
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0){
 178:	416d063b          	subw	a2,s10,s6
 17c:	016b85b3          	add	a1,s7,s6
 180:	8566                	mv	a0,s9
 182:	392000ef          	jal	514 <read>
 186:	02a05c63          	blez	a0,1be <grep+0xb2>
    m += n;
 18a:	00ab0a3b          	addw	s4,s6,a0
 18e:	8b52                	mv	s6,s4
    buf[m] = '\0';
 190:	014b87b3          	add	a5,s7,s4
 194:	00078023          	sb	zero,0(a5)
    p = buf;
 198:	895e                	mv	s2,s7
    while((q = strchr(p, '\n')) != 0){
 19a:	b76d                	j	144 <grep+0x38>
      m -= p - buf;
 19c:	00001797          	auipc	a5,0x1
 1a0:	e7478793          	addi	a5,a5,-396 # 1010 <buf>
 1a4:	40f907b3          	sub	a5,s2,a5
 1a8:	40fa063b          	subw	a2,s4,a5
 1ac:	8b32                	mv	s6,a2
      memmove(buf, p, m);
 1ae:	85ca                	mv	a1,s2
 1b0:	00001517          	auipc	a0,0x1
 1b4:	e6050513          	addi	a0,a0,-416 # 1010 <buf>
 1b8:	296000ef          	jal	44e <memmove>
 1bc:	bf75                	j	178 <grep+0x6c>
}
 1be:	60e6                	ld	ra,88(sp)
 1c0:	6446                	ld	s0,80(sp)
 1c2:	64a6                	ld	s1,72(sp)
 1c4:	6906                	ld	s2,64(sp)
 1c6:	79e2                	ld	s3,56(sp)
 1c8:	7a42                	ld	s4,48(sp)
 1ca:	7aa2                	ld	s5,40(sp)
 1cc:	7b02                	ld	s6,32(sp)
 1ce:	6be2                	ld	s7,24(sp)
 1d0:	6c42                	ld	s8,16(sp)
 1d2:	6ca2                	ld	s9,8(sp)
 1d4:	6d02                	ld	s10,0(sp)
 1d6:	6125                	addi	sp,sp,96
 1d8:	8082                	ret

00000000000001da <main>:
{
 1da:	7179                	addi	sp,sp,-48
 1dc:	f406                	sd	ra,40(sp)
 1de:	f022                	sd	s0,32(sp)
 1e0:	ec26                	sd	s1,24(sp)
 1e2:	e84a                	sd	s2,16(sp)
 1e4:	e44e                	sd	s3,8(sp)
 1e6:	e052                	sd	s4,0(sp)
 1e8:	1800                	addi	s0,sp,48
  if(argc <= 1){
 1ea:	4785                	li	a5,1
 1ec:	04a7d663          	bge	a5,a0,238 <main+0x5e>
  pattern = argv[1];
 1f0:	0085ba03          	ld	s4,8(a1)
  if(argc <= 2){
 1f4:	4789                	li	a5,2
 1f6:	04a7db63          	bge	a5,a0,24c <main+0x72>
 1fa:	01058913          	addi	s2,a1,16
 1fe:	ffd5099b          	addiw	s3,a0,-3
 202:	02099793          	slli	a5,s3,0x20
 206:	01d7d993          	srli	s3,a5,0x1d
 20a:	05e1                	addi	a1,a1,24
 20c:	99ae                	add	s3,s3,a1
    if((fd = open(argv[i], O_RDONLY)) < 0){
 20e:	4581                	li	a1,0
 210:	00093503          	ld	a0,0(s2)
 214:	328000ef          	jal	53c <open>
 218:	84aa                	mv	s1,a0
 21a:	04054063          	bltz	a0,25a <main+0x80>
    grep(pattern, fd);
 21e:	85aa                	mv	a1,a0
 220:	8552                	mv	a0,s4
 222:	eebff0ef          	jal	10c <grep>
    close(fd);
 226:	8526                	mv	a0,s1
 228:	2fc000ef          	jal	524 <close>
  for(i = 2; i < argc; i++){
 22c:	0921                	addi	s2,s2,8
 22e:	ff3910e3          	bne	s2,s3,20e <main+0x34>
  exit(0);
 232:	4501                	li	a0,0
 234:	2c8000ef          	jal	4fc <exit>
    fprintf(2, "usage: grep pattern [file ...]\n");
 238:	00001597          	auipc	a1,0x1
 23c:	a9858593          	addi	a1,a1,-1384 # cd0 <thread_switch+0x72>
 240:	4509                	li	a0,2
 242:	6d2000ef          	jal	914 <fprintf>
    exit(1);
 246:	4505                	li	a0,1
 248:	2b4000ef          	jal	4fc <exit>
    grep(pattern, 0);
 24c:	4581                	li	a1,0
 24e:	8552                	mv	a0,s4
 250:	ebdff0ef          	jal	10c <grep>
    exit(0);
 254:	4501                	li	a0,0
 256:	2a6000ef          	jal	4fc <exit>
      printf("grep: cannot open %s\n", argv[i]);
 25a:	00093583          	ld	a1,0(s2)
 25e:	00001517          	auipc	a0,0x1
 262:	a9250513          	addi	a0,a0,-1390 # cf0 <thread_switch+0x92>
 266:	6d8000ef          	jal	93e <printf>
      exit(1);
 26a:	4505                	li	a0,1
 26c:	290000ef          	jal	4fc <exit>

0000000000000270 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 270:	1141                	addi	sp,sp,-16
 272:	e406                	sd	ra,8(sp)
 274:	e022                	sd	s0,0(sp)
 276:	0800                	addi	s0,sp,16
  extern int main();
  main();
 278:	f63ff0ef          	jal	1da <main>
  exit(0);
 27c:	4501                	li	a0,0
 27e:	27e000ef          	jal	4fc <exit>

0000000000000282 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 282:	1141                	addi	sp,sp,-16
 284:	e406                	sd	ra,8(sp)
 286:	e022                	sd	s0,0(sp)
 288:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 28a:	87aa                	mv	a5,a0
 28c:	0585                	addi	a1,a1,1
 28e:	0785                	addi	a5,a5,1
 290:	fff5c703          	lbu	a4,-1(a1)
 294:	fee78fa3          	sb	a4,-1(a5)
 298:	fb75                	bnez	a4,28c <strcpy+0xa>
    ;
  return os;
}
 29a:	60a2                	ld	ra,8(sp)
 29c:	6402                	ld	s0,0(sp)
 29e:	0141                	addi	sp,sp,16
 2a0:	8082                	ret

00000000000002a2 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 2a2:	1141                	addi	sp,sp,-16
 2a4:	e406                	sd	ra,8(sp)
 2a6:	e022                	sd	s0,0(sp)
 2a8:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 2aa:	00054783          	lbu	a5,0(a0)
 2ae:	cb91                	beqz	a5,2c2 <strcmp+0x20>
 2b0:	0005c703          	lbu	a4,0(a1)
 2b4:	00f71763          	bne	a4,a5,2c2 <strcmp+0x20>
    p++, q++;
 2b8:	0505                	addi	a0,a0,1
 2ba:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 2bc:	00054783          	lbu	a5,0(a0)
 2c0:	fbe5                	bnez	a5,2b0 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 2c2:	0005c503          	lbu	a0,0(a1)
}
 2c6:	40a7853b          	subw	a0,a5,a0
 2ca:	60a2                	ld	ra,8(sp)
 2cc:	6402                	ld	s0,0(sp)
 2ce:	0141                	addi	sp,sp,16
 2d0:	8082                	ret

00000000000002d2 <strlen>:

uint
strlen(const char *s)
{
 2d2:	1141                	addi	sp,sp,-16
 2d4:	e406                	sd	ra,8(sp)
 2d6:	e022                	sd	s0,0(sp)
 2d8:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 2da:	00054783          	lbu	a5,0(a0)
 2de:	cf91                	beqz	a5,2fa <strlen+0x28>
 2e0:	00150793          	addi	a5,a0,1
 2e4:	86be                	mv	a3,a5
 2e6:	0785                	addi	a5,a5,1
 2e8:	fff7c703          	lbu	a4,-1(a5)
 2ec:	ff65                	bnez	a4,2e4 <strlen+0x12>
 2ee:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 2f2:	60a2                	ld	ra,8(sp)
 2f4:	6402                	ld	s0,0(sp)
 2f6:	0141                	addi	sp,sp,16
 2f8:	8082                	ret
  for(n = 0; s[n]; n++)
 2fa:	4501                	li	a0,0
 2fc:	bfdd                	j	2f2 <strlen+0x20>

00000000000002fe <memset>:

void*
memset(void *dst, int c, uint n)
{
 2fe:	1141                	addi	sp,sp,-16
 300:	e406                	sd	ra,8(sp)
 302:	e022                	sd	s0,0(sp)
 304:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 306:	ca19                	beqz	a2,31c <memset+0x1e>
 308:	87aa                	mv	a5,a0
 30a:	1602                	slli	a2,a2,0x20
 30c:	9201                	srli	a2,a2,0x20
 30e:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 312:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 316:	0785                	addi	a5,a5,1
 318:	fee79de3          	bne	a5,a4,312 <memset+0x14>
  }
  return dst;
}
 31c:	60a2                	ld	ra,8(sp)
 31e:	6402                	ld	s0,0(sp)
 320:	0141                	addi	sp,sp,16
 322:	8082                	ret

0000000000000324 <strchr>:

char*
strchr(const char *s, char c)
{
 324:	1141                	addi	sp,sp,-16
 326:	e406                	sd	ra,8(sp)
 328:	e022                	sd	s0,0(sp)
 32a:	0800                	addi	s0,sp,16
  for(; *s; s++)
 32c:	00054783          	lbu	a5,0(a0)
 330:	c799                	beqz	a5,33e <strchr+0x1a>
    if(*s == c)
 332:	00f58763          	beq	a1,a5,340 <strchr+0x1c>
  for(; *s; s++)
 336:	0505                	addi	a0,a0,1
 338:	00054783          	lbu	a5,0(a0)
 33c:	fbfd                	bnez	a5,332 <strchr+0xe>
      return (char*)s;
  return 0;
 33e:	4501                	li	a0,0
}
 340:	60a2                	ld	ra,8(sp)
 342:	6402                	ld	s0,0(sp)
 344:	0141                	addi	sp,sp,16
 346:	8082                	ret

0000000000000348 <gets>:

char*
gets(char *buf, int max)
{
 348:	711d                	addi	sp,sp,-96
 34a:	ec86                	sd	ra,88(sp)
 34c:	e8a2                	sd	s0,80(sp)
 34e:	e4a6                	sd	s1,72(sp)
 350:	e0ca                	sd	s2,64(sp)
 352:	fc4e                	sd	s3,56(sp)
 354:	f852                	sd	s4,48(sp)
 356:	f456                	sd	s5,40(sp)
 358:	f05a                	sd	s6,32(sp)
 35a:	ec5e                	sd	s7,24(sp)
 35c:	e862                	sd	s8,16(sp)
 35e:	1080                	addi	s0,sp,96
 360:	8baa                	mv	s7,a0
 362:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 364:	892a                	mv	s2,a0
 366:	4481                	li	s1,0
    cc = read(0, &c, 1);
 368:	faf40b13          	addi	s6,s0,-81
 36c:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 36e:	8c26                	mv	s8,s1
 370:	0014899b          	addiw	s3,s1,1
 374:	84ce                	mv	s1,s3
 376:	0349d863          	bge	s3,s4,3a6 <gets+0x5e>
    cc = read(0, &c, 1);
 37a:	8656                	mv	a2,s5
 37c:	85da                	mv	a1,s6
 37e:	4501                	li	a0,0
 380:	194000ef          	jal	514 <read>
    if(cc < 1)
 384:	02a05163          	blez	a0,3a6 <gets+0x5e>
      break;
    buf[i++] = c;
 388:	faf44783          	lbu	a5,-81(s0)
 38c:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 390:	0905                	addi	s2,s2,1
 392:	ff678713          	addi	a4,a5,-10
 396:	00173713          	seqz	a4,a4
 39a:	17cd                	addi	a5,a5,-13
 39c:	0017b793          	seqz	a5,a5
 3a0:	8fd9                	or	a5,a5,a4
 3a2:	d7f1                	beqz	a5,36e <gets+0x26>
    buf[i++] = c;
 3a4:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 3a6:	9c5e                	add	s8,s8,s7
 3a8:	000c0023          	sb	zero,0(s8)
  return buf;
}
 3ac:	855e                	mv	a0,s7
 3ae:	60e6                	ld	ra,88(sp)
 3b0:	6446                	ld	s0,80(sp)
 3b2:	64a6                	ld	s1,72(sp)
 3b4:	6906                	ld	s2,64(sp)
 3b6:	79e2                	ld	s3,56(sp)
 3b8:	7a42                	ld	s4,48(sp)
 3ba:	7aa2                	ld	s5,40(sp)
 3bc:	7b02                	ld	s6,32(sp)
 3be:	6be2                	ld	s7,24(sp)
 3c0:	6c42                	ld	s8,16(sp)
 3c2:	6125                	addi	sp,sp,96
 3c4:	8082                	ret

00000000000003c6 <stat>:

int
stat(const char *n, struct stat *st)
{
 3c6:	1101                	addi	sp,sp,-32
 3c8:	ec06                	sd	ra,24(sp)
 3ca:	e822                	sd	s0,16(sp)
 3cc:	e04a                	sd	s2,0(sp)
 3ce:	1000                	addi	s0,sp,32
 3d0:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 3d2:	4581                	li	a1,0
 3d4:	168000ef          	jal	53c <open>
  if(fd < 0)
 3d8:	02054263          	bltz	a0,3fc <stat+0x36>
 3dc:	e426                	sd	s1,8(sp)
 3de:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 3e0:	85ca                	mv	a1,s2
 3e2:	172000ef          	jal	554 <fstat>
 3e6:	892a                	mv	s2,a0
  close(fd);
 3e8:	8526                	mv	a0,s1
 3ea:	13a000ef          	jal	524 <close>
  return r;
 3ee:	64a2                	ld	s1,8(sp)
}
 3f0:	854a                	mv	a0,s2
 3f2:	60e2                	ld	ra,24(sp)
 3f4:	6442                	ld	s0,16(sp)
 3f6:	6902                	ld	s2,0(sp)
 3f8:	6105                	addi	sp,sp,32
 3fa:	8082                	ret
    return -1;
 3fc:	57fd                	li	a5,-1
 3fe:	893e                	mv	s2,a5
 400:	bfc5                	j	3f0 <stat+0x2a>

0000000000000402 <atoi>:

int
atoi(const char *s)
{
 402:	1141                	addi	sp,sp,-16
 404:	e406                	sd	ra,8(sp)
 406:	e022                	sd	s0,0(sp)
 408:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 40a:	00054683          	lbu	a3,0(a0)
 40e:	fd06879b          	addiw	a5,a3,-48
 412:	0ff7f793          	zext.b	a5,a5
 416:	4625                	li	a2,9
 418:	02f66963          	bltu	a2,a5,44a <atoi+0x48>
 41c:	872a                	mv	a4,a0
  n = 0;
 41e:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 420:	0705                	addi	a4,a4,1
 422:	0025179b          	slliw	a5,a0,0x2
 426:	9fa9                	addw	a5,a5,a0
 428:	0017979b          	slliw	a5,a5,0x1
 42c:	9fb5                	addw	a5,a5,a3
 42e:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 432:	00074683          	lbu	a3,0(a4)
 436:	fd06879b          	addiw	a5,a3,-48
 43a:	0ff7f793          	zext.b	a5,a5
 43e:	fef671e3          	bgeu	a2,a5,420 <atoi+0x1e>
  return n;
}
 442:	60a2                	ld	ra,8(sp)
 444:	6402                	ld	s0,0(sp)
 446:	0141                	addi	sp,sp,16
 448:	8082                	ret
  n = 0;
 44a:	4501                	li	a0,0
 44c:	bfdd                	j	442 <atoi+0x40>

000000000000044e <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 44e:	1141                	addi	sp,sp,-16
 450:	e406                	sd	ra,8(sp)
 452:	e022                	sd	s0,0(sp)
 454:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 456:	02b57563          	bgeu	a0,a1,480 <memmove+0x32>
    while(n-- > 0)
 45a:	00c05f63          	blez	a2,478 <memmove+0x2a>
 45e:	1602                	slli	a2,a2,0x20
 460:	9201                	srli	a2,a2,0x20
 462:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 466:	872a                	mv	a4,a0
      *dst++ = *src++;
 468:	0585                	addi	a1,a1,1
 46a:	0705                	addi	a4,a4,1
 46c:	fff5c683          	lbu	a3,-1(a1)
 470:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 474:	fee79ae3          	bne	a5,a4,468 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 478:	60a2                	ld	ra,8(sp)
 47a:	6402                	ld	s0,0(sp)
 47c:	0141                	addi	sp,sp,16
 47e:	8082                	ret
    while(n-- > 0)
 480:	fec05ce3          	blez	a2,478 <memmove+0x2a>
    dst += n;
 484:	00c50733          	add	a4,a0,a2
    src += n;
 488:	95b2                	add	a1,a1,a2
 48a:	fff6079b          	addiw	a5,a2,-1
 48e:	1782                	slli	a5,a5,0x20
 490:	9381                	srli	a5,a5,0x20
 492:	fff7c793          	not	a5,a5
 496:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 498:	15fd                	addi	a1,a1,-1
 49a:	177d                	addi	a4,a4,-1
 49c:	0005c683          	lbu	a3,0(a1)
 4a0:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 4a4:	fef71ae3          	bne	a4,a5,498 <memmove+0x4a>
 4a8:	bfc1                	j	478 <memmove+0x2a>

00000000000004aa <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 4aa:	1141                	addi	sp,sp,-16
 4ac:	e406                	sd	ra,8(sp)
 4ae:	e022                	sd	s0,0(sp)
 4b0:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 4b2:	ce19                	beqz	a2,4d0 <memcmp+0x26>
 4b4:	1602                	slli	a2,a2,0x20
 4b6:	9201                	srli	a2,a2,0x20
 4b8:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 4bc:	00054783          	lbu	a5,0(a0)
 4c0:	0005c703          	lbu	a4,0(a1)
 4c4:	00e79b63          	bne	a5,a4,4da <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 4c8:	0505                	addi	a0,a0,1
    p2++;
 4ca:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 4cc:	fed518e3          	bne	a0,a3,4bc <memcmp+0x12>
  }
  return 0;
 4d0:	4501                	li	a0,0
}
 4d2:	60a2                	ld	ra,8(sp)
 4d4:	6402                	ld	s0,0(sp)
 4d6:	0141                	addi	sp,sp,16
 4d8:	8082                	ret
      return *p1 - *p2;
 4da:	40e7853b          	subw	a0,a5,a4
 4de:	bfd5                	j	4d2 <memcmp+0x28>

00000000000004e0 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 4e0:	1141                	addi	sp,sp,-16
 4e2:	e406                	sd	ra,8(sp)
 4e4:	e022                	sd	s0,0(sp)
 4e6:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 4e8:	f67ff0ef          	jal	44e <memmove>
}
 4ec:	60a2                	ld	ra,8(sp)
 4ee:	6402                	ld	s0,0(sp)
 4f0:	0141                	addi	sp,sp,16
 4f2:	8082                	ret

00000000000004f4 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 4f4:	4885                	li	a7,1
 ecall
 4f6:	00000073          	ecall
 ret
 4fa:	8082                	ret

00000000000004fc <exit>:
.global exit
exit:
 li a7, SYS_exit
 4fc:	4889                	li	a7,2
 ecall
 4fe:	00000073          	ecall
 ret
 502:	8082                	ret

0000000000000504 <wait>:
.global wait
wait:
 li a7, SYS_wait
 504:	488d                	li	a7,3
 ecall
 506:	00000073          	ecall
 ret
 50a:	8082                	ret

000000000000050c <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 50c:	4891                	li	a7,4
 ecall
 50e:	00000073          	ecall
 ret
 512:	8082                	ret

0000000000000514 <read>:
.global read
read:
 li a7, SYS_read
 514:	4895                	li	a7,5
 ecall
 516:	00000073          	ecall
 ret
 51a:	8082                	ret

000000000000051c <write>:
.global write
write:
 li a7, SYS_write
 51c:	48c1                	li	a7,16
 ecall
 51e:	00000073          	ecall
 ret
 522:	8082                	ret

0000000000000524 <close>:
.global close
close:
 li a7, SYS_close
 524:	48d5                	li	a7,21
 ecall
 526:	00000073          	ecall
 ret
 52a:	8082                	ret

000000000000052c <kill>:
.global kill
kill:
 li a7, SYS_kill
 52c:	4899                	li	a7,6
 ecall
 52e:	00000073          	ecall
 ret
 532:	8082                	ret

0000000000000534 <exec>:
.global exec
exec:
 li a7, SYS_exec
 534:	489d                	li	a7,7
 ecall
 536:	00000073          	ecall
 ret
 53a:	8082                	ret

000000000000053c <open>:
.global open
open:
 li a7, SYS_open
 53c:	48bd                	li	a7,15
 ecall
 53e:	00000073          	ecall
 ret
 542:	8082                	ret

0000000000000544 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 544:	48c5                	li	a7,17
 ecall
 546:	00000073          	ecall
 ret
 54a:	8082                	ret

000000000000054c <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 54c:	48c9                	li	a7,18
 ecall
 54e:	00000073          	ecall
 ret
 552:	8082                	ret

0000000000000554 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 554:	48a1                	li	a7,8
 ecall
 556:	00000073          	ecall
 ret
 55a:	8082                	ret

000000000000055c <link>:
.global link
link:
 li a7, SYS_link
 55c:	48cd                	li	a7,19
 ecall
 55e:	00000073          	ecall
 ret
 562:	8082                	ret

0000000000000564 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 564:	48d1                	li	a7,20
 ecall
 566:	00000073          	ecall
 ret
 56a:	8082                	ret

000000000000056c <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 56c:	48a5                	li	a7,9
 ecall
 56e:	00000073          	ecall
 ret
 572:	8082                	ret

0000000000000574 <dup>:
.global dup
dup:
 li a7, SYS_dup
 574:	48a9                	li	a7,10
 ecall
 576:	00000073          	ecall
 ret
 57a:	8082                	ret

000000000000057c <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 57c:	48ad                	li	a7,11
 ecall
 57e:	00000073          	ecall
 ret
 582:	8082                	ret

0000000000000584 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 584:	48b1                	li	a7,12
 ecall
 586:	00000073          	ecall
 ret
 58a:	8082                	ret

000000000000058c <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 58c:	48b5                	li	a7,13
 ecall
 58e:	00000073          	ecall
 ret
 592:	8082                	ret

0000000000000594 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 594:	48b9                	li	a7,14
 ecall
 596:	00000073          	ecall
 ret
 59a:	8082                	ret

000000000000059c <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 59c:	1101                	addi	sp,sp,-32
 59e:	ec06                	sd	ra,24(sp)
 5a0:	e822                	sd	s0,16(sp)
 5a2:	1000                	addi	s0,sp,32
 5a4:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 5a8:	4605                	li	a2,1
 5aa:	fef40593          	addi	a1,s0,-17
 5ae:	f6fff0ef          	jal	51c <write>
}
 5b2:	60e2                	ld	ra,24(sp)
 5b4:	6442                	ld	s0,16(sp)
 5b6:	6105                	addi	sp,sp,32
 5b8:	8082                	ret

00000000000005ba <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 5ba:	715d                	addi	sp,sp,-80
 5bc:	e486                	sd	ra,72(sp)
 5be:	e0a2                	sd	s0,64(sp)
 5c0:	f84a                	sd	s2,48(sp)
 5c2:	f44e                	sd	s3,40(sp)
 5c4:	0880                	addi	s0,sp,80
 5c6:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 5c8:	00d036b3          	snez	a3,a3
 5cc:	03f5d793          	srli	a5,a1,0x3f
 5d0:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 5d2:	0005871b          	sext.w	a4,a1
  neg = 0;
 5d6:	4301                	li	t1,0
  if(sgn && xx < 0){
 5d8:	c681                	beqz	a3,5e0 <printint+0x26>
    x = -xx;
 5da:	40b0073b          	negw	a4,a1
    neg = 1;
 5de:	4305                	li	t1,1
  }

  i = 0;
 5e0:	fb840993          	addi	s3,s0,-72
  neg = 0;
 5e4:	85ce                	mv	a1,s3
  i = 0;
 5e6:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 5e8:	00000817          	auipc	a6,0x0
 5ec:	75080813          	addi	a6,a6,1872 # d38 <digits>
 5f0:	88b6                	mv	a7,a3
 5f2:	0016851b          	addiw	a0,a3,1
 5f6:	86aa                	mv	a3,a0
 5f8:	02c777bb          	remuw	a5,a4,a2
 5fc:	1782                	slli	a5,a5,0x20
 5fe:	9381                	srli	a5,a5,0x20
 600:	97c2                	add	a5,a5,a6
 602:	0007c783          	lbu	a5,0(a5)
 606:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 60a:	87ba                	mv	a5,a4
 60c:	02c7573b          	divuw	a4,a4,a2
 610:	0585                	addi	a1,a1,1
 612:	fcc7ffe3          	bgeu	a5,a2,5f0 <printint+0x36>
  if(neg)
 616:	00030b63          	beqz	t1,62c <printint+0x72>
    buf[i++] = '-';
 61a:	fd040793          	addi	a5,s0,-48
 61e:	953e                	add	a0,a0,a5
 620:	02d00793          	li	a5,45
 624:	fef50423          	sb	a5,-24(a0)
 628:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 62c:	02d05563          	blez	a3,656 <printint+0x9c>
 630:	fc26                	sd	s1,56(sp)
 632:	36fd                	addiw	a3,a3,-1
 634:	00d984b3          	add	s1,s3,a3
 638:	19fd                	addi	s3,s3,-1
 63a:	99b6                	add	s3,s3,a3
 63c:	1682                	slli	a3,a3,0x20
 63e:	9281                	srli	a3,a3,0x20
 640:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 644:	0004c583          	lbu	a1,0(s1)
 648:	854a                	mv	a0,s2
 64a:	f53ff0ef          	jal	59c <putc>
  while(--i >= 0)
 64e:	14fd                	addi	s1,s1,-1
 650:	ff349ae3          	bne	s1,s3,644 <printint+0x8a>
 654:	74e2                	ld	s1,56(sp)
}
 656:	60a6                	ld	ra,72(sp)
 658:	6406                	ld	s0,64(sp)
 65a:	7942                	ld	s2,48(sp)
 65c:	79a2                	ld	s3,40(sp)
 65e:	6161                	addi	sp,sp,80
 660:	8082                	ret

0000000000000662 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 662:	711d                	addi	sp,sp,-96
 664:	ec86                	sd	ra,88(sp)
 666:	e8a2                	sd	s0,80(sp)
 668:	e4a6                	sd	s1,72(sp)
 66a:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 66c:	0005c483          	lbu	s1,0(a1)
 670:	28048263          	beqz	s1,8f4 <vprintf+0x292>
 674:	e0ca                	sd	s2,64(sp)
 676:	fc4e                	sd	s3,56(sp)
 678:	f852                	sd	s4,48(sp)
 67a:	f456                	sd	s5,40(sp)
 67c:	f05a                	sd	s6,32(sp)
 67e:	ec5e                	sd	s7,24(sp)
 680:	e862                	sd	s8,16(sp)
 682:	8b2a                	mv	s6,a0
 684:	8a2e                	mv	s4,a1
 686:	8bb2                	mv	s7,a2
  state = 0;
 688:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 68a:	4901                	li	s2,0
 68c:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 68e:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 692:	06400c13          	li	s8,100
 696:	a00d                	j	6b8 <vprintf+0x56>
        putc(fd, c0);
 698:	85a6                	mv	a1,s1
 69a:	855a                	mv	a0,s6
 69c:	f01ff0ef          	jal	59c <putc>
 6a0:	a019                	j	6a6 <vprintf+0x44>
    } else if(state == '%'){
 6a2:	03598363          	beq	s3,s5,6c8 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 6a6:	0019079b          	addiw	a5,s2,1
 6aa:	893e                	mv	s2,a5
 6ac:	873e                	mv	a4,a5
 6ae:	97d2                	add	a5,a5,s4
 6b0:	0007c483          	lbu	s1,0(a5)
 6b4:	22048963          	beqz	s1,8e6 <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 6b8:	0004879b          	sext.w	a5,s1
    if(state == 0){
 6bc:	fe0993e3          	bnez	s3,6a2 <vprintf+0x40>
      if(c0 == '%'){
 6c0:	fd579ce3          	bne	a5,s5,698 <vprintf+0x36>
        state = '%';
 6c4:	89be                	mv	s3,a5
 6c6:	b7c5                	j	6a6 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 6c8:	00ea06b3          	add	a3,s4,a4
 6cc:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 6d0:	22060763          	beqz	a2,8fe <vprintf+0x29c>
      if(c0 == 'd'){
 6d4:	0b878363          	beq	a5,s8,77a <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 6d8:	f9478693          	addi	a3,a5,-108
 6dc:	0016b693          	seqz	a3,a3
 6e0:	f9c60593          	addi	a1,a2,-100
 6e4:	0015b593          	seqz	a1,a1
 6e8:	8df5                	and	a1,a1,a3
 6ea:	e5c5                	bnez	a1,792 <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 6ec:	9752                	add	a4,a4,s4
 6ee:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 6f2:	f9460713          	addi	a4,a2,-108
 6f6:	00173713          	seqz	a4,a4
 6fa:	8f75                	and	a4,a4,a3
 6fc:	f9c50593          	addi	a1,a0,-100
 700:	0015b593          	seqz	a1,a1
 704:	8df9                	and	a1,a1,a4
 706:	e1dd                	bnez	a1,7ac <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 708:	07500593          	li	a1,117
 70c:	0ab78d63          	beq	a5,a1,7c6 <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 710:	f8b60593          	addi	a1,a2,-117
 714:	0015b593          	seqz	a1,a1
 718:	8df5                	and	a1,a1,a3
 71a:	e1f1                	bnez	a1,7de <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 71c:	f8b50593          	addi	a1,a0,-117
 720:	0015b593          	seqz	a1,a1
 724:	8df9                	and	a1,a1,a4
 726:	e9e9                	bnez	a1,7f8 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 728:	07800593          	li	a1,120
 72c:	0eb78363          	beq	a5,a1,812 <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 730:	f8860613          	addi	a2,a2,-120
 734:	00163613          	seqz	a2,a2
 738:	8ef1                	and	a3,a3,a2
 73a:	0e069863          	bnez	a3,82a <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 73e:	f8850513          	addi	a0,a0,-120
 742:	00153513          	seqz	a0,a0
 746:	8f69                	and	a4,a4,a0
 748:	0e071e63          	bnez	a4,844 <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 74c:	07000713          	li	a4,112
 750:	10e78663          	beq	a5,a4,85c <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 754:	07300713          	li	a4,115
 758:	14e78663          	beq	a5,a4,8a4 <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 75c:	02500713          	li	a4,37
 760:	16e78e63          	beq	a5,a4,8dc <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 764:	02500593          	li	a1,37
 768:	855a                	mv	a0,s6
 76a:	e33ff0ef          	jal	59c <putc>
        putc(fd, c0);
 76e:	85a6                	mv	a1,s1
 770:	855a                	mv	a0,s6
 772:	e2bff0ef          	jal	59c <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 776:	4981                	li	s3,0
 778:	b73d                	j	6a6 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 77a:	008b8493          	addi	s1,s7,8
 77e:	4685                	li	a3,1
 780:	4629                	li	a2,10
 782:	000ba583          	lw	a1,0(s7)
 786:	855a                	mv	a0,s6
 788:	e33ff0ef          	jal	5ba <printint>
 78c:	8ba6                	mv	s7,s1
      state = 0;
 78e:	4981                	li	s3,0
 790:	bf19                	j	6a6 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 792:	008b8493          	addi	s1,s7,8
 796:	4685                	li	a3,1
 798:	4629                	li	a2,10
 79a:	000bb583          	ld	a1,0(s7)
 79e:	855a                	mv	a0,s6
 7a0:	e1bff0ef          	jal	5ba <printint>
        i += 1;
 7a4:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 7a6:	8ba6                	mv	s7,s1
      state = 0;
 7a8:	4981                	li	s3,0
 7aa:	bdf5                	j	6a6 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 7ac:	008b8493          	addi	s1,s7,8
 7b0:	4685                	li	a3,1
 7b2:	4629                	li	a2,10
 7b4:	000bb583          	ld	a1,0(s7)
 7b8:	855a                	mv	a0,s6
 7ba:	e01ff0ef          	jal	5ba <printint>
        i += 2;
 7be:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 7c0:	8ba6                	mv	s7,s1
      state = 0;
 7c2:	4981                	li	s3,0
        i += 2;
 7c4:	b5cd                	j	6a6 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 7c6:	008b8493          	addi	s1,s7,8
 7ca:	4681                	li	a3,0
 7cc:	4629                	li	a2,10
 7ce:	000ba583          	lw	a1,0(s7)
 7d2:	855a                	mv	a0,s6
 7d4:	de7ff0ef          	jal	5ba <printint>
 7d8:	8ba6                	mv	s7,s1
      state = 0;
 7da:	4981                	li	s3,0
 7dc:	b5e9                	j	6a6 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7de:	008b8493          	addi	s1,s7,8
 7e2:	4681                	li	a3,0
 7e4:	4629                	li	a2,10
 7e6:	000bb583          	ld	a1,0(s7)
 7ea:	855a                	mv	a0,s6
 7ec:	dcfff0ef          	jal	5ba <printint>
        i += 1;
 7f0:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 7f2:	8ba6                	mv	s7,s1
      state = 0;
 7f4:	4981                	li	s3,0
 7f6:	bd45                	j	6a6 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7f8:	008b8493          	addi	s1,s7,8
 7fc:	4681                	li	a3,0
 7fe:	4629                	li	a2,10
 800:	000bb583          	ld	a1,0(s7)
 804:	855a                	mv	a0,s6
 806:	db5ff0ef          	jal	5ba <printint>
        i += 2;
 80a:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 80c:	8ba6                	mv	s7,s1
      state = 0;
 80e:	4981                	li	s3,0
        i += 2;
 810:	bd59                	j	6a6 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 812:	008b8493          	addi	s1,s7,8
 816:	4681                	li	a3,0
 818:	4641                	li	a2,16
 81a:	000ba583          	lw	a1,0(s7)
 81e:	855a                	mv	a0,s6
 820:	d9bff0ef          	jal	5ba <printint>
 824:	8ba6                	mv	s7,s1
      state = 0;
 826:	4981                	li	s3,0
 828:	bdbd                	j	6a6 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 82a:	008b8493          	addi	s1,s7,8
 82e:	4681                	li	a3,0
 830:	4641                	li	a2,16
 832:	000bb583          	ld	a1,0(s7)
 836:	855a                	mv	a0,s6
 838:	d83ff0ef          	jal	5ba <printint>
        i += 1;
 83c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 83e:	8ba6                	mv	s7,s1
      state = 0;
 840:	4981                	li	s3,0
 842:	b595                	j	6a6 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 844:	008b8493          	addi	s1,s7,8
 848:	4641                	li	a2,16
 84a:	000bb583          	ld	a1,0(s7)
 84e:	855a                	mv	a0,s6
 850:	d6bff0ef          	jal	5ba <printint>
        i += 2;
 854:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 856:	8ba6                	mv	s7,s1
      state = 0;
 858:	4981                	li	s3,0
        i += 2;
 85a:	b5b1                	j	6a6 <vprintf+0x44>
 85c:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 85e:	008b8793          	addi	a5,s7,8
 862:	8cbe                	mv	s9,a5
 864:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 868:	03000593          	li	a1,48
 86c:	855a                	mv	a0,s6
 86e:	d2fff0ef          	jal	59c <putc>
  putc(fd, 'x');
 872:	07800593          	li	a1,120
 876:	855a                	mv	a0,s6
 878:	d25ff0ef          	jal	59c <putc>
 87c:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 87e:	00000b97          	auipc	s7,0x0
 882:	4bab8b93          	addi	s7,s7,1210 # d38 <digits>
 886:	03c9d793          	srli	a5,s3,0x3c
 88a:	97de                	add	a5,a5,s7
 88c:	0007c583          	lbu	a1,0(a5)
 890:	855a                	mv	a0,s6
 892:	d0bff0ef          	jal	59c <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 896:	0992                	slli	s3,s3,0x4
 898:	34fd                	addiw	s1,s1,-1
 89a:	f4f5                	bnez	s1,886 <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 89c:	8be6                	mv	s7,s9
      state = 0;
 89e:	4981                	li	s3,0
 8a0:	6ca2                	ld	s9,8(sp)
 8a2:	b511                	j	6a6 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 8a4:	008b8993          	addi	s3,s7,8
 8a8:	000bb483          	ld	s1,0(s7)
 8ac:	cc91                	beqz	s1,8c8 <vprintf+0x266>
        for(; *s; s++)
 8ae:	0004c583          	lbu	a1,0(s1)
 8b2:	c195                	beqz	a1,8d6 <vprintf+0x274>
          putc(fd, *s);
 8b4:	855a                	mv	a0,s6
 8b6:	ce7ff0ef          	jal	59c <putc>
        for(; *s; s++)
 8ba:	0485                	addi	s1,s1,1
 8bc:	0004c583          	lbu	a1,0(s1)
 8c0:	f9f5                	bnez	a1,8b4 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 8c2:	8bce                	mv	s7,s3
      state = 0;
 8c4:	4981                	li	s3,0
 8c6:	b3c5                	j	6a6 <vprintf+0x44>
          s = "(null)";
 8c8:	00000497          	auipc	s1,0x0
 8cc:	44048493          	addi	s1,s1,1088 # d08 <thread_switch+0xaa>
        for(; *s; s++)
 8d0:	02800593          	li	a1,40
 8d4:	b7c5                	j	8b4 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 8d6:	8bce                	mv	s7,s3
      state = 0;
 8d8:	4981                	li	s3,0
 8da:	b3f1                	j	6a6 <vprintf+0x44>
        putc(fd, '%');
 8dc:	85be                	mv	a1,a5
 8de:	855a                	mv	a0,s6
 8e0:	cbdff0ef          	jal	59c <putc>
 8e4:	bd49                	j	776 <vprintf+0x114>
 8e6:	6906                	ld	s2,64(sp)
 8e8:	79e2                	ld	s3,56(sp)
 8ea:	7a42                	ld	s4,48(sp)
 8ec:	7aa2                	ld	s5,40(sp)
 8ee:	7b02                	ld	s6,32(sp)
 8f0:	6be2                	ld	s7,24(sp)
 8f2:	6c42                	ld	s8,16(sp)
    }
  }
}
 8f4:	60e6                	ld	ra,88(sp)
 8f6:	6446                	ld	s0,80(sp)
 8f8:	64a6                	ld	s1,72(sp)
 8fa:	6125                	addi	sp,sp,96
 8fc:	8082                	ret
      if(c0 == 'd'){
 8fe:	06400713          	li	a4,100
 902:	e6e78ce3          	beq	a5,a4,77a <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 906:	f9478693          	addi	a3,a5,-108
 90a:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 90e:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 910:	4701                	li	a4,0
 912:	bbdd                	j	708 <vprintf+0xa6>

0000000000000914 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 914:	715d                	addi	sp,sp,-80
 916:	ec06                	sd	ra,24(sp)
 918:	e822                	sd	s0,16(sp)
 91a:	1000                	addi	s0,sp,32
 91c:	e010                	sd	a2,0(s0)
 91e:	e414                	sd	a3,8(s0)
 920:	e818                	sd	a4,16(s0)
 922:	ec1c                	sd	a5,24(s0)
 924:	03043023          	sd	a6,32(s0)
 928:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 92c:	8622                	mv	a2,s0
 92e:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 932:	d31ff0ef          	jal	662 <vprintf>
}
 936:	60e2                	ld	ra,24(sp)
 938:	6442                	ld	s0,16(sp)
 93a:	6161                	addi	sp,sp,80
 93c:	8082                	ret

000000000000093e <printf>:

void
printf(const char *fmt, ...)
{
 93e:	711d                	addi	sp,sp,-96
 940:	ec06                	sd	ra,24(sp)
 942:	e822                	sd	s0,16(sp)
 944:	1000                	addi	s0,sp,32
 946:	e40c                	sd	a1,8(s0)
 948:	e810                	sd	a2,16(s0)
 94a:	ec14                	sd	a3,24(s0)
 94c:	f018                	sd	a4,32(s0)
 94e:	f41c                	sd	a5,40(s0)
 950:	03043823          	sd	a6,48(s0)
 954:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 958:	00840613          	addi	a2,s0,8
 95c:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 960:	85aa                	mv	a1,a0
 962:	4505                	li	a0,1
 964:	cffff0ef          	jal	662 <vprintf>
}
 968:	60e2                	ld	ra,24(sp)
 96a:	6442                	ld	s0,16(sp)
 96c:	6125                	addi	sp,sp,96
 96e:	8082                	ret

0000000000000970 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 970:	1141                	addi	sp,sp,-16
 972:	e406                	sd	ra,8(sp)
 974:	e022                	sd	s0,0(sp)
 976:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 978:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 97c:	00000797          	auipc	a5,0x0
 980:	6847b783          	ld	a5,1668(a5) # 1000 <freep>
 984:	a095                	j	9e8 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 986:	ff852583          	lw	a1,-8(a0)
 98a:	6390                	ld	a2,0(a5)
 98c:	02059813          	slli	a6,a1,0x20
 990:	01c85693          	srli	a3,a6,0x1c
 994:	96ba                	add	a3,a3,a4
 996:	02d60563          	beq	a2,a3,9c0 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 99a:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 99e:	4790                	lw	a2,8(a5)
 9a0:	02061593          	slli	a1,a2,0x20
 9a4:	01c5d693          	srli	a3,a1,0x1c
 9a8:	96be                	add	a3,a3,a5
 9aa:	02d70263          	beq	a4,a3,9ce <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 9ae:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 9b0:	00000717          	auipc	a4,0x0
 9b4:	64f73823          	sd	a5,1616(a4) # 1000 <freep>
}
 9b8:	60a2                	ld	ra,8(sp)
 9ba:	6402                	ld	s0,0(sp)
 9bc:	0141                	addi	sp,sp,16
 9be:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 9c0:	4614                	lw	a3,8(a2)
 9c2:	9ead                	addw	a3,a3,a1
 9c4:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 9c8:	6394                	ld	a3,0(a5)
 9ca:	6290                	ld	a2,0(a3)
 9cc:	b7f9                	j	99a <free+0x2a>
    p->s.size += bp->s.size;
 9ce:	ff852703          	lw	a4,-8(a0)
 9d2:	9f31                	addw	a4,a4,a2
 9d4:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 9d6:	ff053703          	ld	a4,-16(a0)
 9da:	bfd1                	j	9ae <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9dc:	6394                	ld	a3,0(a5)
 9de:	00d7e463          	bltu	a5,a3,9e6 <free+0x76>
 9e2:	fad762e3          	bltu	a4,a3,986 <free+0x16>
 9e6:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9e8:	fee7fae3          	bgeu	a5,a4,9dc <free+0x6c>
 9ec:	6394                	ld	a3,0(a5)
 9ee:	f8d76ce3          	bltu	a4,a3,986 <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9f2:	f8d7fae3          	bgeu	a5,a3,986 <free+0x16>
 9f6:	87b6                	mv	a5,a3
 9f8:	bfc5                	j	9e8 <free+0x78>

00000000000009fa <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 9fa:	7139                	addi	sp,sp,-64
 9fc:	fc06                	sd	ra,56(sp)
 9fe:	f822                	sd	s0,48(sp)
 a00:	f04a                	sd	s2,32(sp)
 a02:	ec4e                	sd	s3,24(sp)
 a04:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 a06:	02051993          	slli	s3,a0,0x20
 a0a:	0209d993          	srli	s3,s3,0x20
 a0e:	09bd                	addi	s3,s3,15
 a10:	0049d993          	srli	s3,s3,0x4
 a14:	2985                	addiw	s3,s3,1
 a16:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 a18:	00000517          	auipc	a0,0x0
 a1c:	5e853503          	ld	a0,1512(a0) # 1000 <freep>
 a20:	c905                	beqz	a0,a50 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a22:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a24:	4798                	lw	a4,8(a5)
 a26:	09377663          	bgeu	a4,s3,ab2 <malloc+0xb8>
 a2a:	f426                	sd	s1,40(sp)
 a2c:	e852                	sd	s4,16(sp)
 a2e:	e456                	sd	s5,8(sp)
 a30:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 a32:	8a4e                	mv	s4,s3
 a34:	6705                	lui	a4,0x1
 a36:	00e9f363          	bgeu	s3,a4,a3c <malloc+0x42>
 a3a:	6a05                	lui	s4,0x1
 a3c:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 a40:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 a44:	00000497          	auipc	s1,0x0
 a48:	5bc48493          	addi	s1,s1,1468 # 1000 <freep>
  if(p == (char*)-1)
 a4c:	5afd                	li	s5,-1
 a4e:	a83d                	j	a8c <malloc+0x92>
 a50:	f426                	sd	s1,40(sp)
 a52:	e852                	sd	s4,16(sp)
 a54:	e456                	sd	s5,8(sp)
 a56:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 a58:	00001797          	auipc	a5,0x1
 a5c:	9b878793          	addi	a5,a5,-1608 # 1410 <base>
 a60:	00000717          	auipc	a4,0x0
 a64:	5af73023          	sd	a5,1440(a4) # 1000 <freep>
 a68:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 a6a:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 a6e:	b7d1                	j	a32 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 a70:	6398                	ld	a4,0(a5)
 a72:	e118                	sd	a4,0(a0)
 a74:	a899                	j	aca <malloc+0xd0>
  hp->s.size = nu;
 a76:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 a7a:	0541                	addi	a0,a0,16
 a7c:	ef5ff0ef          	jal	970 <free>
  return freep;
 a80:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 a82:	c125                	beqz	a0,ae2 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a84:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a86:	4798                	lw	a4,8(a5)
 a88:	03277163          	bgeu	a4,s2,aaa <malloc+0xb0>
    if(p == freep)
 a8c:	6098                	ld	a4,0(s1)
 a8e:	853e                	mv	a0,a5
 a90:	fef71ae3          	bne	a4,a5,a84 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 a94:	8552                	mv	a0,s4
 a96:	aefff0ef          	jal	584 <sbrk>
  if(p == (char*)-1)
 a9a:	fd551ee3          	bne	a0,s5,a76 <malloc+0x7c>
        return 0;
 a9e:	4501                	li	a0,0
 aa0:	74a2                	ld	s1,40(sp)
 aa2:	6a42                	ld	s4,16(sp)
 aa4:	6aa2                	ld	s5,8(sp)
 aa6:	6b02                	ld	s6,0(sp)
 aa8:	a03d                	j	ad6 <malloc+0xdc>
 aaa:	74a2                	ld	s1,40(sp)
 aac:	6a42                	ld	s4,16(sp)
 aae:	6aa2                	ld	s5,8(sp)
 ab0:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 ab2:	fae90fe3          	beq	s2,a4,a70 <malloc+0x76>
        p->s.size -= nunits;
 ab6:	4137073b          	subw	a4,a4,s3
 aba:	c798                	sw	a4,8(a5)
        p += p->s.size;
 abc:	02071693          	slli	a3,a4,0x20
 ac0:	01c6d713          	srli	a4,a3,0x1c
 ac4:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 ac6:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 aca:	00000717          	auipc	a4,0x0
 ace:	52a73b23          	sd	a0,1334(a4) # 1000 <freep>
      return (void*)(p + 1);
 ad2:	01078513          	addi	a0,a5,16
  }
}
 ad6:	70e2                	ld	ra,56(sp)
 ad8:	7442                	ld	s0,48(sp)
 ada:	7902                	ld	s2,32(sp)
 adc:	69e2                	ld	s3,24(sp)
 ade:	6121                	addi	sp,sp,64
 ae0:	8082                	ret
 ae2:	74a2                	ld	s1,40(sp)
 ae4:	6a42                	ld	s4,16(sp)
 ae6:	6aa2                	ld	s5,8(sp)
 ae8:	6b02                	ld	s6,0(sp)
 aea:	b7f5                	j	ad6 <malloc+0xdc>

0000000000000aec <thread_init>:
struct thread *current_thread;
extern void thread_switch(uint64, uint64);
              
void 
thread_init(void)
{
 aec:	1141                	addi	sp,sp,-16
 aee:	e406                	sd	ra,8(sp)
 af0:	e022                	sd	s0,0(sp)
 af2:	0800                	addi	s0,sp,16
  // main() is thread 0, which will make the first invocation to
  // thread_schedule(). It needs a stack so that the first thread_switch() can
  // save thread 0's state.
  current_thread = &all_thread[0];
 af4:	00001797          	auipc	a5,0x1
 af8:	92c78793          	addi	a5,a5,-1748 # 1420 <all_thread>
 afc:	00000717          	auipc	a4,0x0
 b00:	50f73623          	sd	a5,1292(a4) # 1008 <current_thread>
  current_thread->state = RUNNING;
 b04:	00003717          	auipc	a4,0x3
 b08:	91c70713          	addi	a4,a4,-1764 # 3420 <all_thread+0x2000>
 b0c:	4785                	li	a5,1
 b0e:	c31c                	sw	a5,0(a4)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 b10:	00003797          	auipc	a5,0x3
 b14:	8a078793          	addi	a5,a5,-1888 # 33b0 <all_thread+0x1f90>
  return (struct context *)(top & ~(uint64)0xf);
 b18:	9bc1                	andi	a5,a5,-16
  // Thread 0 runs on the process's own stack, but the first thread_switch()
  // still needs a writable place to save its context.
  current_thread->context = thread_context_slot(current_thread);
 b1a:	e71c                	sd	a5,8(a4)
}
 b1c:	60a2                	ld	ra,8(sp)
 b1e:	6402                	ld	s0,0(sp)
 b20:	0141                	addi	sp,sp,16
 b22:	8082                	ret

0000000000000b24 <thread_schedule>:

void 
thread_schedule(void)
{
 b24:	1141                	addi	sp,sp,-16
 b26:	e406                	sd	ra,8(sp)
 b28:	e022                	sd	s0,0(sp)
 b2a:	0800                	addi	s0,sp,16
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
 b2c:	00000597          	auipc	a1,0x0
 b30:	4dc5b583          	ld	a1,1244(a1) # 1008 <current_thread>
 b34:	6789                	lui	a5,0x2
 b36:	07c1                	addi	a5,a5,16 # 2010 <all_thread+0xbf0>
 b38:	97ae                	add	a5,a5,a1
 b3a:	4711                	li	a4,4
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
 b3c:	00009897          	auipc	a7,0x9
 b40:	92488893          	addi	a7,a7,-1756 # 9460 <all_thread+0x8040>
      t = all_thread;
    if(t->state == RUNNABLE) {
 b44:	6809                	lui	a6,0x2
 b46:	4509                	li	a0,2
      next_thread = t;
      break;
    }
    t = t + 1;
 b48:	01080613          	addi	a2,a6,16 # 2010 <all_thread+0xbf0>
 b4c:	a809                	j	b5e <thread_schedule+0x3a>
    if(t->state == RUNNABLE) {
 b4e:	010786b3          	add	a3,a5,a6
 b52:	4294                	lw	a3,0(a3)
 b54:	02a68563          	beq	a3,a0,b7e <thread_schedule+0x5a>
    t = t + 1;
 b58:	97b2                	add	a5,a5,a2
  for(int i = 0; i < MAX_THREAD; i++){
 b5a:	377d                	addiw	a4,a4,-1
 b5c:	cb01                	beqz	a4,b6c <thread_schedule+0x48>
    if(t >= all_thread + MAX_THREAD)
 b5e:	ff17e8e3          	bltu	a5,a7,b4e <thread_schedule+0x2a>
      t = all_thread;
 b62:	00001797          	auipc	a5,0x1
 b66:	8be78793          	addi	a5,a5,-1858 # 1420 <all_thread>
 b6a:	b7d5                	j	b4e <thread_schedule+0x2a>
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
 b6c:	00000517          	auipc	a0,0x0
 b70:	1a450513          	addi	a0,a0,420 # d10 <thread_switch+0xb2>
 b74:	dcbff0ef          	jal	93e <printf>
    exit(-1);
 b78:	557d                	li	a0,-1
 b7a:	983ff0ef          	jal	4fc <exit>
  }

  if (current_thread != next_thread) {         /* switch threads?  */
 b7e:	02f58163          	beq	a1,a5,ba0 <thread_schedule+0x7c>
    next_thread->state = RUNNING;
 b82:	6689                	lui	a3,0x2
 b84:	00d78733          	add	a4,a5,a3
 b88:	4605                	li	a2,1
 b8a:	c310                	sw	a2,0(a4)
    t = current_thread;
    current_thread = next_thread;
 b8c:	00000617          	auipc	a2,0x0
 b90:	46f63e23          	sd	a5,1148(a2) # 1008 <current_thread>
    thread_switch((uint64)t->context, (uint64)next_thread->context);
 b94:	00d587b3          	add	a5,a1,a3
 b98:	670c                	ld	a1,8(a4)
 b9a:	6788                	ld	a0,8(a5)
 b9c:	0c2000ef          	jal	c5e <thread_switch>
  } else
    next_thread = 0;
}
 ba0:	60a2                	ld	ra,8(sp)
 ba2:	6402                	ld	s0,0(sp)
 ba4:	0141                	addi	sp,sp,16
 ba6:	8082                	ret

0000000000000ba8 <thread_create>:

void 
thread_create(void (*func)())
{
 ba8:	1101                	addi	sp,sp,-32
 baa:	ec06                	sd	ra,24(sp)
 bac:	e822                	sd	s0,16(sp)
 bae:	e426                	sd	s1,8(sp)
 bb0:	e04a                	sd	s2,0(sp)
 bb2:	1000                	addi	s0,sp,32
 bb4:	892a                	mv	s2,a0
  struct thread *t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 bb6:	00003797          	auipc	a5,0x3
 bba:	87a78793          	addi	a5,a5,-1926 # 3430 <all_thread+0x2010>
 bbe:	0000b597          	auipc	a1,0xb
 bc2:	8b258593          	addi	a1,a1,-1870 # b470 <all_thread+0xa050>
 bc6:	6609                	lui	a2,0x2
 bc8:	0641                	addi	a2,a2,16 # 2010 <all_thread+0xbf0>
    if (t->state == FREE) break;
 bca:	873e                	mv	a4,a5
 bcc:	ff07a683          	lw	a3,-16(a5)
 bd0:	ce9d                	beqz	a3,c0e <thread_create+0x66>
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 bd2:	97b2                	add	a5,a5,a2
 bd4:	feb79be3          	bne	a5,a1,bca <thread_create+0x22>
  }
  t->state = RUNNABLE;
 bd8:	6489                	lui	s1,0x2
 bda:	94ba                	add	s1,s1,a4
 bdc:	4789                	li	a5,2
 bde:	c09c                	sw	a5,0(s1)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 be0:	6789                	lui	a5,0x2
 be2:	f9078793          	addi	a5,a5,-112 # 1f90 <all_thread+0xb70>
 be6:	973e                	add	a4,a4,a5
  return (struct context *)(top & ~(uint64)0xf);
 be8:	ff077513          	andi	a0,a4,-16
  // A never-run thread has no saved state, so construct one: thread_switch()
  // restores ra and sp, and `ret` then starts func on this thread's own stack.
  t->context = thread_context_slot(t);
 bec:	e488                	sd	a0,8(s1)
  memset(t->context, 0, sizeof(struct context));
 bee:	07000613          	li	a2,112
 bf2:	4581                	li	a1,0
 bf4:	f0aff0ef          	jal	2fe <memset>
  t->context->ra = (uint64)func;
 bf8:	649c                	ld	a5,8(s1)
 bfa:	0127b023          	sd	s2,0(a5)
  t->context->sp = (uint64)t->context;   // 16-byte aligned, grows down
 bfe:	649c                	ld	a5,8(s1)
 c00:	e79c                	sd	a5,8(a5)
}
 c02:	60e2                	ld	ra,24(sp)
 c04:	6442                	ld	s0,16(sp)
 c06:	64a2                	ld	s1,8(sp)
 c08:	6902                	ld	s2,0(sp)
 c0a:	6105                	addi	sp,sp,32
 c0c:	8082                	ret
 c0e:	7779                	lui	a4,0xffffe
 c10:	1741                	addi	a4,a4,-16 # ffffffffffffdff0 <all_thread+0xffffffffffffcbd0>
 c12:	973e                	add	a4,a4,a5
 c14:	b7d1                	j	bd8 <thread_create+0x30>

0000000000000c16 <thread_yield>:

void 
thread_yield(void)
{
 c16:	1141                	addi	sp,sp,-16
 c18:	e406                	sd	ra,8(sp)
 c1a:	e022                	sd	s0,0(sp)
 c1c:	0800                	addi	s0,sp,16
  current_thread->state = RUNNABLE;
 c1e:	00000797          	auipc	a5,0x0
 c22:	3ea7b783          	ld	a5,1002(a5) # 1008 <current_thread>
 c26:	6709                	lui	a4,0x2
 c28:	97ba                	add	a5,a5,a4
 c2a:	4709                	li	a4,2
 c2c:	c398                	sw	a4,0(a5)
  thread_schedule();
 c2e:	ef7ff0ef          	jal	b24 <thread_schedule>
}
 c32:	60a2                	ld	ra,8(sp)
 c34:	6402                	ld	s0,0(sp)
 c36:	0141                	addi	sp,sp,16
 c38:	8082                	ret

0000000000000c3a <thread_exit>:

void thread_exit(void) {
 c3a:	1141                	addi	sp,sp,-16
 c3c:	e406                	sd	ra,8(sp)
 c3e:	e022                	sd	s0,0(sp)
 c40:	0800                	addi	s0,sp,16
  current_thread->state = FREE;
 c42:	00000797          	auipc	a5,0x0
 c46:	3c67b783          	ld	a5,966(a5) # 1008 <current_thread>
 c4a:	6709                	lui	a4,0x2
 c4c:	97ba                	add	a5,a5,a4
 c4e:	0007a023          	sw	zero,0(a5)
  thread_schedule();
 c52:	ed3ff0ef          	jal	b24 <thread_schedule>
}
 c56:	60a2                	ld	ra,8(sp)
 c58:	6402                	ld	s0,0(sp)
 c5a:	0141                	addi	sp,sp,16
 c5c:	8082                	ret

0000000000000c5e <thread_switch>:
 c5e:	00153023          	sd	ra,0(a0)
 c62:	00253423          	sd	sp,8(a0)
 c66:	e900                	sd	s0,16(a0)
 c68:	ed04                	sd	s1,24(a0)
 c6a:	03253023          	sd	s2,32(a0)
 c6e:	03353423          	sd	s3,40(a0)
 c72:	03453823          	sd	s4,48(a0)
 c76:	03553c23          	sd	s5,56(a0)
 c7a:	05653023          	sd	s6,64(a0)
 c7e:	05753423          	sd	s7,72(a0)
 c82:	05853823          	sd	s8,80(a0)
 c86:	05953c23          	sd	s9,88(a0)
 c8a:	07a53023          	sd	s10,96(a0)
 c8e:	07b53423          	sd	s11,104(a0)
 c92:	0005b083          	ld	ra,0(a1)
 c96:	0085b103          	ld	sp,8(a1)
 c9a:	6980                	ld	s0,16(a1)
 c9c:	6d84                	ld	s1,24(a1)
 c9e:	0205b903          	ld	s2,32(a1)
 ca2:	0285b983          	ld	s3,40(a1)
 ca6:	0305ba03          	ld	s4,48(a1)
 caa:	0385ba83          	ld	s5,56(a1)
 cae:	0405bb03          	ld	s6,64(a1)
 cb2:	0485bb83          	ld	s7,72(a1)
 cb6:	0505bc03          	ld	s8,80(a1)
 cba:	0585bc83          	ld	s9,88(a1)
 cbe:	0605bd03          	ld	s10,96(a1)
 cc2:	0685bd83          	ld	s11,104(a1)
 cc6:	8082                	ret
