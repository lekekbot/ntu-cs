
user/_usertests:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <copyinstr1>:
}

// what if you pass ridiculous string pointers to system calls?
void
copyinstr1(char *s)
{
       0:	711d                	addi	sp,sp,-96
       2:	ec86                	sd	ra,88(sp)
       4:	e8a2                	sd	s0,80(sp)
       6:	e4a6                	sd	s1,72(sp)
       8:	e0ca                	sd	s2,64(sp)
       a:	fc4e                	sd	s3,56(sp)
       c:	f852                	sd	s4,48(sp)
       e:	1080                	addi	s0,sp,96
  uint64 addrs[] = { 0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
      10:	00008797          	auipc	a5,0x8
      14:	8a078793          	addi	a5,a5,-1888 # 78b0 <thread_switch+0x243a>
      18:	638c                	ld	a1,0(a5)
      1a:	6790                	ld	a2,8(a5)
      1c:	6b94                	ld	a3,16(a5)
      1e:	6f98                	ld	a4,24(a5)
      20:	fab43423          	sd	a1,-88(s0)
      24:	fac43823          	sd	a2,-80(s0)
      28:	fad43c23          	sd	a3,-72(s0)
      2c:	fce43023          	sd	a4,-64(s0)
      30:	739c                	ld	a5,32(a5)
      32:	fcf43423          	sd	a5,-56(s0)
                     0xffffffffffffffff };

  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
      36:	fa840493          	addi	s1,s0,-88
      3a:	fd040a13          	addi	s4,s0,-48
    uint64 addr = addrs[ai];

    int fd = open((char *)addr, O_CREATE|O_WRONLY);
      3e:	20100993          	li	s3,513
      42:	0004b903          	ld	s2,0(s1)
      46:	85ce                	mv	a1,s3
      48:	854a                	mv	a0,s2
      4a:	50b040ef          	jal	4d54 <open>
    if(fd >= 0){
      4e:	00055d63          	bgez	a0,68 <copyinstr1+0x68>
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
      52:	04a1                	addi	s1,s1,8
      54:	ff4497e3          	bne	s1,s4,42 <copyinstr1+0x42>
      printf("open(%p) returned %d, not -1\n", (void*)addr, fd);
      exit(1);
    }
  }
}
      58:	60e6                	ld	ra,88(sp)
      5a:	6446                	ld	s0,80(sp)
      5c:	64a6                	ld	s1,72(sp)
      5e:	6906                	ld	s2,64(sp)
      60:	79e2                	ld	s3,56(sp)
      62:	7a42                	ld	s4,48(sp)
      64:	6125                	addi	sp,sp,96
      66:	8082                	ret
      printf("open(%p) returned %d, not -1\n", (void*)addr, fd);
      68:	862a                	mv	a2,a0
      6a:	85ca                	mv	a1,s2
      6c:	00005517          	auipc	a0,0x5
      70:	47450513          	addi	a0,a0,1140 # 54e0 <thread_switch+0x6a>
      74:	0e2050ef          	jal	5156 <printf>
      exit(1);
      78:	4505                	li	a0,1
      7a:	49b040ef          	jal	4d14 <exit>

000000000000007e <bsstest>:
void
bsstest(char *s)
{
  int i;

  for(i = 0; i < sizeof(uninit); i++){
      7e:	00009797          	auipc	a5,0x9
      82:	4ea78793          	addi	a5,a5,1258 # 9568 <uninit>
      86:	0000c697          	auipc	a3,0xc
      8a:	bf268693          	addi	a3,a3,-1038 # bc78 <buf>
    if(uninit[i] != '\0'){
      8e:	0007c703          	lbu	a4,0(a5)
      92:	e709                	bnez	a4,9c <bsstest+0x1e>
  for(i = 0; i < sizeof(uninit); i++){
      94:	0785                	addi	a5,a5,1
      96:	fed79ce3          	bne	a5,a3,8e <bsstest+0x10>
      9a:	8082                	ret
{
      9c:	1141                	addi	sp,sp,-16
      9e:	e406                	sd	ra,8(sp)
      a0:	e022                	sd	s0,0(sp)
      a2:	0800                	addi	s0,sp,16
      printf("%s: bss test failed\n", s);
      a4:	85aa                	mv	a1,a0
      a6:	00005517          	auipc	a0,0x5
      aa:	45a50513          	addi	a0,a0,1114 # 5500 <thread_switch+0x8a>
      ae:	0a8050ef          	jal	5156 <printf>
      exit(1);
      b2:	4505                	li	a0,1
      b4:	461040ef          	jal	4d14 <exit>

00000000000000b8 <opentest>:
{
      b8:	1101                	addi	sp,sp,-32
      ba:	ec06                	sd	ra,24(sp)
      bc:	e822                	sd	s0,16(sp)
      be:	e426                	sd	s1,8(sp)
      c0:	1000                	addi	s0,sp,32
      c2:	84aa                	mv	s1,a0
  fd = open("echo", 0);
      c4:	4581                	li	a1,0
      c6:	00005517          	auipc	a0,0x5
      ca:	45250513          	addi	a0,a0,1106 # 5518 <thread_switch+0xa2>
      ce:	487040ef          	jal	4d54 <open>
  if(fd < 0){
      d2:	02054263          	bltz	a0,f6 <opentest+0x3e>
  close(fd);
      d6:	467040ef          	jal	4d3c <close>
  fd = open("doesnotexist", 0);
      da:	4581                	li	a1,0
      dc:	00005517          	auipc	a0,0x5
      e0:	45c50513          	addi	a0,a0,1116 # 5538 <thread_switch+0xc2>
      e4:	471040ef          	jal	4d54 <open>
  if(fd >= 0){
      e8:	02055163          	bgez	a0,10a <opentest+0x52>
}
      ec:	60e2                	ld	ra,24(sp)
      ee:	6442                	ld	s0,16(sp)
      f0:	64a2                	ld	s1,8(sp)
      f2:	6105                	addi	sp,sp,32
      f4:	8082                	ret
    printf("%s: open echo failed!\n", s);
      f6:	85a6                	mv	a1,s1
      f8:	00005517          	auipc	a0,0x5
      fc:	42850513          	addi	a0,a0,1064 # 5520 <thread_switch+0xaa>
     100:	056050ef          	jal	5156 <printf>
    exit(1);
     104:	4505                	li	a0,1
     106:	40f040ef          	jal	4d14 <exit>
    printf("%s: open doesnotexist succeeded!\n", s);
     10a:	85a6                	mv	a1,s1
     10c:	00005517          	auipc	a0,0x5
     110:	43c50513          	addi	a0,a0,1084 # 5548 <thread_switch+0xd2>
     114:	042050ef          	jal	5156 <printf>
    exit(1);
     118:	4505                	li	a0,1
     11a:	3fb040ef          	jal	4d14 <exit>

000000000000011e <truncate2>:
{
     11e:	7179                	addi	sp,sp,-48
     120:	f406                	sd	ra,40(sp)
     122:	f022                	sd	s0,32(sp)
     124:	ec26                	sd	s1,24(sp)
     126:	e84a                	sd	s2,16(sp)
     128:	e44e                	sd	s3,8(sp)
     12a:	1800                	addi	s0,sp,48
     12c:	89aa                	mv	s3,a0
  unlink("truncfile");
     12e:	00005517          	auipc	a0,0x5
     132:	44250513          	addi	a0,a0,1090 # 5570 <thread_switch+0xfa>
     136:	42f040ef          	jal	4d64 <unlink>
  int fd1 = open("truncfile", O_CREATE|O_TRUNC|O_WRONLY);
     13a:	60100593          	li	a1,1537
     13e:	00005517          	auipc	a0,0x5
     142:	43250513          	addi	a0,a0,1074 # 5570 <thread_switch+0xfa>
     146:	40f040ef          	jal	4d54 <open>
     14a:	84aa                	mv	s1,a0
  write(fd1, "abcd", 4);
     14c:	4611                	li	a2,4
     14e:	00005597          	auipc	a1,0x5
     152:	43258593          	addi	a1,a1,1074 # 5580 <thread_switch+0x10a>
     156:	3df040ef          	jal	4d34 <write>
  int fd2 = open("truncfile", O_TRUNC|O_WRONLY);
     15a:	40100593          	li	a1,1025
     15e:	00005517          	auipc	a0,0x5
     162:	41250513          	addi	a0,a0,1042 # 5570 <thread_switch+0xfa>
     166:	3ef040ef          	jal	4d54 <open>
     16a:	892a                	mv	s2,a0
  int n = write(fd1, "x", 1);
     16c:	4605                	li	a2,1
     16e:	00005597          	auipc	a1,0x5
     172:	41a58593          	addi	a1,a1,1050 # 5588 <thread_switch+0x112>
     176:	8526                	mv	a0,s1
     178:	3bd040ef          	jal	4d34 <write>
  if(n != -1){
     17c:	57fd                	li	a5,-1
     17e:	02f51563          	bne	a0,a5,1a8 <truncate2+0x8a>
  unlink("truncfile");
     182:	00005517          	auipc	a0,0x5
     186:	3ee50513          	addi	a0,a0,1006 # 5570 <thread_switch+0xfa>
     18a:	3db040ef          	jal	4d64 <unlink>
  close(fd1);
     18e:	8526                	mv	a0,s1
     190:	3ad040ef          	jal	4d3c <close>
  close(fd2);
     194:	854a                	mv	a0,s2
     196:	3a7040ef          	jal	4d3c <close>
}
     19a:	70a2                	ld	ra,40(sp)
     19c:	7402                	ld	s0,32(sp)
     19e:	64e2                	ld	s1,24(sp)
     1a0:	6942                	ld	s2,16(sp)
     1a2:	69a2                	ld	s3,8(sp)
     1a4:	6145                	addi	sp,sp,48
     1a6:	8082                	ret
    printf("%s: write returned %d, expected -1\n", s, n);
     1a8:	862a                	mv	a2,a0
     1aa:	85ce                	mv	a1,s3
     1ac:	00005517          	auipc	a0,0x5
     1b0:	3e450513          	addi	a0,a0,996 # 5590 <thread_switch+0x11a>
     1b4:	7a3040ef          	jal	5156 <printf>
    exit(1);
     1b8:	4505                	li	a0,1
     1ba:	35b040ef          	jal	4d14 <exit>

00000000000001be <createtest>:
{
     1be:	7139                	addi	sp,sp,-64
     1c0:	fc06                	sd	ra,56(sp)
     1c2:	f822                	sd	s0,48(sp)
     1c4:	f426                	sd	s1,40(sp)
     1c6:	f04a                	sd	s2,32(sp)
     1c8:	ec4e                	sd	s3,24(sp)
     1ca:	e852                	sd	s4,16(sp)
     1cc:	0080                	addi	s0,sp,64
  name[0] = 'a';
     1ce:	06100793          	li	a5,97
     1d2:	fcf40423          	sb	a5,-56(s0)
  name[2] = '\0';
     1d6:	fc040523          	sb	zero,-54(s0)
     1da:	03000493          	li	s1,48
    fd = open(name, O_CREATE|O_RDWR);
     1de:	fc840a13          	addi	s4,s0,-56
     1e2:	20200993          	li	s3,514
  for(i = 0; i < N; i++){
     1e6:	06400913          	li	s2,100
    name[1] = '0' + i;
     1ea:	fc9404a3          	sb	s1,-55(s0)
    fd = open(name, O_CREATE|O_RDWR);
     1ee:	85ce                	mv	a1,s3
     1f0:	8552                	mv	a0,s4
     1f2:	363040ef          	jal	4d54 <open>
    close(fd);
     1f6:	347040ef          	jal	4d3c <close>
  for(i = 0; i < N; i++){
     1fa:	2485                	addiw	s1,s1,1
     1fc:	0ff4f493          	zext.b	s1,s1
     200:	ff2495e3          	bne	s1,s2,1ea <createtest+0x2c>
  name[0] = 'a';
     204:	06100793          	li	a5,97
     208:	fcf40423          	sb	a5,-56(s0)
  name[2] = '\0';
     20c:	fc040523          	sb	zero,-54(s0)
     210:	03000493          	li	s1,48
    unlink(name);
     214:	fc840993          	addi	s3,s0,-56
  for(i = 0; i < N; i++){
     218:	06400913          	li	s2,100
    name[1] = '0' + i;
     21c:	fc9404a3          	sb	s1,-55(s0)
    unlink(name);
     220:	854e                	mv	a0,s3
     222:	343040ef          	jal	4d64 <unlink>
  for(i = 0; i < N; i++){
     226:	2485                	addiw	s1,s1,1
     228:	0ff4f493          	zext.b	s1,s1
     22c:	ff2498e3          	bne	s1,s2,21c <createtest+0x5e>
}
     230:	70e2                	ld	ra,56(sp)
     232:	7442                	ld	s0,48(sp)
     234:	74a2                	ld	s1,40(sp)
     236:	7902                	ld	s2,32(sp)
     238:	69e2                	ld	s3,24(sp)
     23a:	6a42                	ld	s4,16(sp)
     23c:	6121                	addi	sp,sp,64
     23e:	8082                	ret

0000000000000240 <bigwrite>:
{
     240:	711d                	addi	sp,sp,-96
     242:	ec86                	sd	ra,88(sp)
     244:	e8a2                	sd	s0,80(sp)
     246:	e4a6                	sd	s1,72(sp)
     248:	e0ca                	sd	s2,64(sp)
     24a:	fc4e                	sd	s3,56(sp)
     24c:	f852                	sd	s4,48(sp)
     24e:	f456                	sd	s5,40(sp)
     250:	f05a                	sd	s6,32(sp)
     252:	ec5e                	sd	s7,24(sp)
     254:	e862                	sd	s8,16(sp)
     256:	e466                	sd	s9,8(sp)
     258:	1080                	addi	s0,sp,96
     25a:	8caa                	mv	s9,a0
  unlink("bigwrite");
     25c:	00005517          	auipc	a0,0x5
     260:	35c50513          	addi	a0,a0,860 # 55b8 <thread_switch+0x142>
     264:	301040ef          	jal	4d64 <unlink>
  for(sz = 499; sz < (MAXOPBLOCKS+2)*BSIZE; sz += 471){
     268:	1f300493          	li	s1,499
    fd = open("bigwrite", O_CREATE | O_RDWR);
     26c:	20200b93          	li	s7,514
     270:	00005a17          	auipc	s4,0x5
     274:	348a0a13          	addi	s4,s4,840 # 55b8 <thread_switch+0x142>
    if(fd < 0){
     278:	4b09                	li	s6,2
      int cc = write(fd, buf, sz);
     27a:	0000c997          	auipc	s3,0xc
     27e:	9fe98993          	addi	s3,s3,-1538 # bc78 <buf>
  for(sz = 499; sz < (MAXOPBLOCKS+2)*BSIZE; sz += 471){
     282:	6a8d                	lui	s5,0x3
     284:	1c9a8a93          	addi	s5,s5,457 # 31c9 <subdir+0x4b3>
    fd = open("bigwrite", O_CREATE | O_RDWR);
     288:	85de                	mv	a1,s7
     28a:	8552                	mv	a0,s4
     28c:	2c9040ef          	jal	4d54 <open>
     290:	892a                	mv	s2,a0
    if(fd < 0){
     292:	04054463          	bltz	a0,2da <bigwrite+0x9a>
     296:	8c5a                	mv	s8,s6
      int cc = write(fd, buf, sz);
     298:	8626                	mv	a2,s1
     29a:	85ce                	mv	a1,s3
     29c:	854a                	mv	a0,s2
     29e:	297040ef          	jal	4d34 <write>
      if(cc != sz){
     2a2:	04951663          	bne	a0,s1,2ee <bigwrite+0xae>
    for(i = 0; i < 2; i++){
     2a6:	3c7d                	addiw	s8,s8,-1
     2a8:	fe0c18e3          	bnez	s8,298 <bigwrite+0x58>
    close(fd);
     2ac:	854a                	mv	a0,s2
     2ae:	28f040ef          	jal	4d3c <close>
    unlink("bigwrite");
     2b2:	8552                	mv	a0,s4
     2b4:	2b1040ef          	jal	4d64 <unlink>
  for(sz = 499; sz < (MAXOPBLOCKS+2)*BSIZE; sz += 471){
     2b8:	1d74849b          	addiw	s1,s1,471
     2bc:	fd5496e3          	bne	s1,s5,288 <bigwrite+0x48>
}
     2c0:	60e6                	ld	ra,88(sp)
     2c2:	6446                	ld	s0,80(sp)
     2c4:	64a6                	ld	s1,72(sp)
     2c6:	6906                	ld	s2,64(sp)
     2c8:	79e2                	ld	s3,56(sp)
     2ca:	7a42                	ld	s4,48(sp)
     2cc:	7aa2                	ld	s5,40(sp)
     2ce:	7b02                	ld	s6,32(sp)
     2d0:	6be2                	ld	s7,24(sp)
     2d2:	6c42                	ld	s8,16(sp)
     2d4:	6ca2                	ld	s9,8(sp)
     2d6:	6125                	addi	sp,sp,96
     2d8:	8082                	ret
      printf("%s: cannot create bigwrite\n", s);
     2da:	85e6                	mv	a1,s9
     2dc:	00005517          	auipc	a0,0x5
     2e0:	2ec50513          	addi	a0,a0,748 # 55c8 <thread_switch+0x152>
     2e4:	673040ef          	jal	5156 <printf>
      exit(1);
     2e8:	4505                	li	a0,1
     2ea:	22b040ef          	jal	4d14 <exit>
        printf("%s: write(%d) ret %d\n", s, sz, cc);
     2ee:	86aa                	mv	a3,a0
     2f0:	8626                	mv	a2,s1
     2f2:	85e6                	mv	a1,s9
     2f4:	00005517          	auipc	a0,0x5
     2f8:	2f450513          	addi	a0,a0,756 # 55e8 <thread_switch+0x172>
     2fc:	65b040ef          	jal	5156 <printf>
        exit(1);
     300:	4505                	li	a0,1
     302:	213040ef          	jal	4d14 <exit>

0000000000000306 <badwrite>:
// file is deleted? if the kernel has this bug, it will panic: balloc:
// out of blocks. assumed_free may need to be raised to be more than
// the number of free blocks. this test takes a long time.
void
badwrite(char *s)
{
     306:	7139                	addi	sp,sp,-64
     308:	fc06                	sd	ra,56(sp)
     30a:	f822                	sd	s0,48(sp)
     30c:	f426                	sd	s1,40(sp)
     30e:	f04a                	sd	s2,32(sp)
     310:	ec4e                	sd	s3,24(sp)
     312:	e852                	sd	s4,16(sp)
     314:	e456                	sd	s5,8(sp)
     316:	e05a                	sd	s6,0(sp)
     318:	0080                	addi	s0,sp,64
  int assumed_free = 600;
  
  unlink("junk");
     31a:	00005517          	auipc	a0,0x5
     31e:	2e650513          	addi	a0,a0,742 # 5600 <thread_switch+0x18a>
     322:	243040ef          	jal	4d64 <unlink>
     326:	25800913          	li	s2,600
  for(int i = 0; i < assumed_free; i++){
    int fd = open("junk", O_CREATE|O_WRONLY);
     32a:	20100a93          	li	s5,513
     32e:	00005997          	auipc	s3,0x5
     332:	2d298993          	addi	s3,s3,722 # 5600 <thread_switch+0x18a>
    if(fd < 0){
      printf("open junk failed\n");
      exit(1);
    }
    write(fd, (char*)0xffffffffffL, 1);
     336:	4b05                	li	s6,1
     338:	5a7d                	li	s4,-1
     33a:	018a5a13          	srli	s4,s4,0x18
    int fd = open("junk", O_CREATE|O_WRONLY);
     33e:	85d6                	mv	a1,s5
     340:	854e                	mv	a0,s3
     342:	213040ef          	jal	4d54 <open>
     346:	84aa                	mv	s1,a0
    if(fd < 0){
     348:	04054d63          	bltz	a0,3a2 <badwrite+0x9c>
    write(fd, (char*)0xffffffffffL, 1);
     34c:	865a                	mv	a2,s6
     34e:	85d2                	mv	a1,s4
     350:	1e5040ef          	jal	4d34 <write>
    close(fd);
     354:	8526                	mv	a0,s1
     356:	1e7040ef          	jal	4d3c <close>
    unlink("junk");
     35a:	854e                	mv	a0,s3
     35c:	209040ef          	jal	4d64 <unlink>
  for(int i = 0; i < assumed_free; i++){
     360:	397d                	addiw	s2,s2,-1
     362:	fc091ee3          	bnez	s2,33e <badwrite+0x38>
  }

  int fd = open("junk", O_CREATE|O_WRONLY);
     366:	20100593          	li	a1,513
     36a:	00005517          	auipc	a0,0x5
     36e:	29650513          	addi	a0,a0,662 # 5600 <thread_switch+0x18a>
     372:	1e3040ef          	jal	4d54 <open>
     376:	84aa                	mv	s1,a0
  if(fd < 0){
     378:	02054e63          	bltz	a0,3b4 <badwrite+0xae>
    printf("open junk failed\n");
    exit(1);
  }
  if(write(fd, "x", 1) != 1){
     37c:	4605                	li	a2,1
     37e:	00005597          	auipc	a1,0x5
     382:	20a58593          	addi	a1,a1,522 # 5588 <thread_switch+0x112>
     386:	1af040ef          	jal	4d34 <write>
     38a:	4785                	li	a5,1
     38c:	02f50d63          	beq	a0,a5,3c6 <badwrite+0xc0>
    printf("write failed\n");
     390:	00005517          	auipc	a0,0x5
     394:	29050513          	addi	a0,a0,656 # 5620 <thread_switch+0x1aa>
     398:	5bf040ef          	jal	5156 <printf>
    exit(1);
     39c:	4505                	li	a0,1
     39e:	177040ef          	jal	4d14 <exit>
      printf("open junk failed\n");
     3a2:	00005517          	auipc	a0,0x5
     3a6:	26650513          	addi	a0,a0,614 # 5608 <thread_switch+0x192>
     3aa:	5ad040ef          	jal	5156 <printf>
      exit(1);
     3ae:	4505                	li	a0,1
     3b0:	165040ef          	jal	4d14 <exit>
    printf("open junk failed\n");
     3b4:	00005517          	auipc	a0,0x5
     3b8:	25450513          	addi	a0,a0,596 # 5608 <thread_switch+0x192>
     3bc:	59b040ef          	jal	5156 <printf>
    exit(1);
     3c0:	4505                	li	a0,1
     3c2:	153040ef          	jal	4d14 <exit>
  }
  close(fd);
     3c6:	8526                	mv	a0,s1
     3c8:	175040ef          	jal	4d3c <close>
  unlink("junk");
     3cc:	00005517          	auipc	a0,0x5
     3d0:	23450513          	addi	a0,a0,564 # 5600 <thread_switch+0x18a>
     3d4:	191040ef          	jal	4d64 <unlink>

  exit(0);
     3d8:	4501                	li	a0,0
     3da:	13b040ef          	jal	4d14 <exit>

00000000000003de <outofinodes>:
  }
}

void
outofinodes(char *s)
{
     3de:	711d                	addi	sp,sp,-96
     3e0:	ec86                	sd	ra,88(sp)
     3e2:	e8a2                	sd	s0,80(sp)
     3e4:	e4a6                	sd	s1,72(sp)
     3e6:	e0ca                	sd	s2,64(sp)
     3e8:	fc4e                	sd	s3,56(sp)
     3ea:	f852                	sd	s4,48(sp)
     3ec:	f456                	sd	s5,40(sp)
     3ee:	1080                	addi	s0,sp,96
  int nzz = 32*32;
  for(int i = 0; i < nzz; i++){
     3f0:	4481                	li	s1,0
    char name[32];
    name[0] = 'z';
     3f2:	07a00993          	li	s3,122
    name[1] = 'z';
    name[2] = '0' + (i / 32);
    name[3] = '0' + (i % 32);
    name[4] = '\0';
    unlink(name);
     3f6:	fa040913          	addi	s2,s0,-96
    int fd = open(name, O_CREATE|O_RDWR|O_TRUNC);
     3fa:	60200a13          	li	s4,1538
  for(int i = 0; i < nzz; i++){
     3fe:	40000a93          	li	s5,1024
    name[0] = 'z';
     402:	fb340023          	sb	s3,-96(s0)
    name[1] = 'z';
     406:	fb3400a3          	sb	s3,-95(s0)
    name[2] = '0' + (i / 32);
     40a:	41f4d71b          	sraiw	a4,s1,0x1f
     40e:	01b7571b          	srliw	a4,a4,0x1b
     412:	009707bb          	addw	a5,a4,s1
     416:	4057d69b          	sraiw	a3,a5,0x5
     41a:	0306869b          	addiw	a3,a3,48
     41e:	fad40123          	sb	a3,-94(s0)
    name[3] = '0' + (i % 32);
     422:	8bfd                	andi	a5,a5,31
     424:	9f99                	subw	a5,a5,a4
     426:	0307879b          	addiw	a5,a5,48
     42a:	faf401a3          	sb	a5,-93(s0)
    name[4] = '\0';
     42e:	fa040223          	sb	zero,-92(s0)
    unlink(name);
     432:	854a                	mv	a0,s2
     434:	131040ef          	jal	4d64 <unlink>
    int fd = open(name, O_CREATE|O_RDWR|O_TRUNC);
     438:	85d2                	mv	a1,s4
     43a:	854a                	mv	a0,s2
     43c:	119040ef          	jal	4d54 <open>
    if(fd < 0){
     440:	00054763          	bltz	a0,44e <outofinodes+0x70>
      // failure is eventually expected.
      break;
    }
    close(fd);
     444:	0f9040ef          	jal	4d3c <close>
  for(int i = 0; i < nzz; i++){
     448:	2485                	addiw	s1,s1,1
     44a:	fb549ce3          	bne	s1,s5,402 <outofinodes+0x24>
  }

  for(int i = 0; i < nzz; i++){
     44e:	4481                	li	s1,0
    char name[32];
    name[0] = 'z';
     450:	07a00913          	li	s2,122
    name[1] = 'z';
    name[2] = '0' + (i / 32);
    name[3] = '0' + (i % 32);
    name[4] = '\0';
    unlink(name);
     454:	fa040a13          	addi	s4,s0,-96
  for(int i = 0; i < nzz; i++){
     458:	40000993          	li	s3,1024
    name[0] = 'z';
     45c:	fb240023          	sb	s2,-96(s0)
    name[1] = 'z';
     460:	fb2400a3          	sb	s2,-95(s0)
    name[2] = '0' + (i / 32);
     464:	41f4d71b          	sraiw	a4,s1,0x1f
     468:	01b7571b          	srliw	a4,a4,0x1b
     46c:	009707bb          	addw	a5,a4,s1
     470:	4057d69b          	sraiw	a3,a5,0x5
     474:	0306869b          	addiw	a3,a3,48
     478:	fad40123          	sb	a3,-94(s0)
    name[3] = '0' + (i % 32);
     47c:	8bfd                	andi	a5,a5,31
     47e:	9f99                	subw	a5,a5,a4
     480:	0307879b          	addiw	a5,a5,48
     484:	faf401a3          	sb	a5,-93(s0)
    name[4] = '\0';
     488:	fa040223          	sb	zero,-92(s0)
    unlink(name);
     48c:	8552                	mv	a0,s4
     48e:	0d7040ef          	jal	4d64 <unlink>
  for(int i = 0; i < nzz; i++){
     492:	2485                	addiw	s1,s1,1
     494:	fd3494e3          	bne	s1,s3,45c <outofinodes+0x7e>
  }
}
     498:	60e6                	ld	ra,88(sp)
     49a:	6446                	ld	s0,80(sp)
     49c:	64a6                	ld	s1,72(sp)
     49e:	6906                	ld	s2,64(sp)
     4a0:	79e2                	ld	s3,56(sp)
     4a2:	7a42                	ld	s4,48(sp)
     4a4:	7aa2                	ld	s5,40(sp)
     4a6:	6125                	addi	sp,sp,96
     4a8:	8082                	ret

00000000000004aa <copyin>:
{
     4aa:	7175                	addi	sp,sp,-144
     4ac:	e506                	sd	ra,136(sp)
     4ae:	e122                	sd	s0,128(sp)
     4b0:	fca6                	sd	s1,120(sp)
     4b2:	f8ca                	sd	s2,112(sp)
     4b4:	f4ce                	sd	s3,104(sp)
     4b6:	f0d2                	sd	s4,96(sp)
     4b8:	ecd6                	sd	s5,88(sp)
     4ba:	e8da                	sd	s6,80(sp)
     4bc:	e4de                	sd	s7,72(sp)
     4be:	e0e2                	sd	s8,64(sp)
     4c0:	fc66                	sd	s9,56(sp)
     4c2:	0900                	addi	s0,sp,144
  uint64 addrs[] = { 0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
     4c4:	00007797          	auipc	a5,0x7
     4c8:	3ec78793          	addi	a5,a5,1004 # 78b0 <thread_switch+0x243a>
     4cc:	638c                	ld	a1,0(a5)
     4ce:	6790                	ld	a2,8(a5)
     4d0:	6b94                	ld	a3,16(a5)
     4d2:	6f98                	ld	a4,24(a5)
     4d4:	f6b43c23          	sd	a1,-136(s0)
     4d8:	f8c43023          	sd	a2,-128(s0)
     4dc:	f8d43423          	sd	a3,-120(s0)
     4e0:	f8e43823          	sd	a4,-112(s0)
     4e4:	739c                	ld	a5,32(a5)
     4e6:	f8f43c23          	sd	a5,-104(s0)
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
     4ea:	f7840913          	addi	s2,s0,-136
     4ee:	fa040c93          	addi	s9,s0,-96
    int fd = open("copyin1", O_CREATE|O_WRONLY);
     4f2:	20100b13          	li	s6,513
     4f6:	00005a97          	auipc	s5,0x5
     4fa:	13aa8a93          	addi	s5,s5,314 # 5630 <thread_switch+0x1ba>
    int n = write(fd, (void*)addr, 8192);
     4fe:	6a09                	lui	s4,0x2
    n = write(1, (char*)addr, 8192);
     500:	4c05                	li	s8,1
    if(pipe(fds) < 0){
     502:	f7040b93          	addi	s7,s0,-144
    uint64 addr = addrs[ai];
     506:	00093983          	ld	s3,0(s2)
    int fd = open("copyin1", O_CREATE|O_WRONLY);
     50a:	85da                	mv	a1,s6
     50c:	8556                	mv	a0,s5
     50e:	047040ef          	jal	4d54 <open>
     512:	84aa                	mv	s1,a0
    if(fd < 0){
     514:	06054a63          	bltz	a0,588 <copyin+0xde>
    int n = write(fd, (void*)addr, 8192);
     518:	8652                	mv	a2,s4
     51a:	85ce                	mv	a1,s3
     51c:	019040ef          	jal	4d34 <write>
    if(n >= 0){
     520:	06055d63          	bgez	a0,59a <copyin+0xf0>
    close(fd);
     524:	8526                	mv	a0,s1
     526:	017040ef          	jal	4d3c <close>
    unlink("copyin1");
     52a:	8556                	mv	a0,s5
     52c:	039040ef          	jal	4d64 <unlink>
    n = write(1, (char*)addr, 8192);
     530:	8652                	mv	a2,s4
     532:	85ce                	mv	a1,s3
     534:	8562                	mv	a0,s8
     536:	7fe040ef          	jal	4d34 <write>
    if(n > 0){
     53a:	06a04b63          	bgtz	a0,5b0 <copyin+0x106>
    if(pipe(fds) < 0){
     53e:	855e                	mv	a0,s7
     540:	7e4040ef          	jal	4d24 <pipe>
     544:	08054163          	bltz	a0,5c6 <copyin+0x11c>
    n = write(fds[1], (char*)addr, 8192);
     548:	8652                	mv	a2,s4
     54a:	85ce                	mv	a1,s3
     54c:	f7442503          	lw	a0,-140(s0)
     550:	7e4040ef          	jal	4d34 <write>
    if(n > 0){
     554:	08a04263          	bgtz	a0,5d8 <copyin+0x12e>
    close(fds[0]);
     558:	f7042503          	lw	a0,-144(s0)
     55c:	7e0040ef          	jal	4d3c <close>
    close(fds[1]);
     560:	f7442503          	lw	a0,-140(s0)
     564:	7d8040ef          	jal	4d3c <close>
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
     568:	0921                	addi	s2,s2,8
     56a:	f9991ee3          	bne	s2,s9,506 <copyin+0x5c>
}
     56e:	60aa                	ld	ra,136(sp)
     570:	640a                	ld	s0,128(sp)
     572:	74e6                	ld	s1,120(sp)
     574:	7946                	ld	s2,112(sp)
     576:	79a6                	ld	s3,104(sp)
     578:	7a06                	ld	s4,96(sp)
     57a:	6ae6                	ld	s5,88(sp)
     57c:	6b46                	ld	s6,80(sp)
     57e:	6ba6                	ld	s7,72(sp)
     580:	6c06                	ld	s8,64(sp)
     582:	7ce2                	ld	s9,56(sp)
     584:	6149                	addi	sp,sp,144
     586:	8082                	ret
      printf("open(copyin1) failed\n");
     588:	00005517          	auipc	a0,0x5
     58c:	0b050513          	addi	a0,a0,176 # 5638 <thread_switch+0x1c2>
     590:	3c7040ef          	jal	5156 <printf>
      exit(1);
     594:	4505                	li	a0,1
     596:	77e040ef          	jal	4d14 <exit>
      printf("write(fd, %p, 8192) returned %d, not -1\n", (void*)addr, n);
     59a:	862a                	mv	a2,a0
     59c:	85ce                	mv	a1,s3
     59e:	00005517          	auipc	a0,0x5
     5a2:	0b250513          	addi	a0,a0,178 # 5650 <thread_switch+0x1da>
     5a6:	3b1040ef          	jal	5156 <printf>
      exit(1);
     5aa:	4505                	li	a0,1
     5ac:	768040ef          	jal	4d14 <exit>
      printf("write(1, %p, 8192) returned %d, not -1 or 0\n", (void*)addr, n);
     5b0:	862a                	mv	a2,a0
     5b2:	85ce                	mv	a1,s3
     5b4:	00005517          	auipc	a0,0x5
     5b8:	0cc50513          	addi	a0,a0,204 # 5680 <thread_switch+0x20a>
     5bc:	39b040ef          	jal	5156 <printf>
      exit(1);
     5c0:	4505                	li	a0,1
     5c2:	752040ef          	jal	4d14 <exit>
      printf("pipe() failed\n");
     5c6:	00005517          	auipc	a0,0x5
     5ca:	0ea50513          	addi	a0,a0,234 # 56b0 <thread_switch+0x23a>
     5ce:	389040ef          	jal	5156 <printf>
      exit(1);
     5d2:	4505                	li	a0,1
     5d4:	740040ef          	jal	4d14 <exit>
      printf("write(pipe, %p, 8192) returned %d, not -1 or 0\n", (void*)addr, n);
     5d8:	862a                	mv	a2,a0
     5da:	85ce                	mv	a1,s3
     5dc:	00005517          	auipc	a0,0x5
     5e0:	0e450513          	addi	a0,a0,228 # 56c0 <thread_switch+0x24a>
     5e4:	373040ef          	jal	5156 <printf>
      exit(1);
     5e8:	4505                	li	a0,1
     5ea:	72a040ef          	jal	4d14 <exit>

00000000000005ee <copyout>:
{
     5ee:	7135                	addi	sp,sp,-160
     5f0:	ed06                	sd	ra,152(sp)
     5f2:	e922                	sd	s0,144(sp)
     5f4:	e526                	sd	s1,136(sp)
     5f6:	e14a                	sd	s2,128(sp)
     5f8:	fcce                	sd	s3,120(sp)
     5fa:	f8d2                	sd	s4,112(sp)
     5fc:	f4d6                	sd	s5,104(sp)
     5fe:	f0da                	sd	s6,96(sp)
     600:	ecde                	sd	s7,88(sp)
     602:	e8e2                	sd	s8,80(sp)
     604:	e4e6                	sd	s9,72(sp)
     606:	1100                	addi	s0,sp,160
  uint64 addrs[] = { 0LL, 0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
     608:	00007797          	auipc	a5,0x7
     60c:	2a878793          	addi	a5,a5,680 # 78b0 <thread_switch+0x243a>
     610:	7788                	ld	a0,40(a5)
     612:	7b8c                	ld	a1,48(a5)
     614:	7f90                	ld	a2,56(a5)
     616:	63b4                	ld	a3,64(a5)
     618:	67b8                	ld	a4,72(a5)
     61a:	f6a43823          	sd	a0,-144(s0)
     61e:	f6b43c23          	sd	a1,-136(s0)
     622:	f8c43023          	sd	a2,-128(s0)
     626:	f8d43423          	sd	a3,-120(s0)
     62a:	f8e43823          	sd	a4,-112(s0)
     62e:	6bbc                	ld	a5,80(a5)
     630:	f8f43c23          	sd	a5,-104(s0)
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
     634:	f7040913          	addi	s2,s0,-144
     638:	fa040c93          	addi	s9,s0,-96
    int fd = open("README", 0);
     63c:	00005b17          	auipc	s6,0x5
     640:	0b4b0b13          	addi	s6,s6,180 # 56f0 <thread_switch+0x27a>
    int n = read(fd, (void*)addr, 8192);
     644:	6a89                	lui	s5,0x2
    if(pipe(fds) < 0){
     646:	f6840c13          	addi	s8,s0,-152
    n = write(fds[1], "x", 1);
     64a:	4a05                	li	s4,1
     64c:	00005b97          	auipc	s7,0x5
     650:	f3cb8b93          	addi	s7,s7,-196 # 5588 <thread_switch+0x112>
    uint64 addr = addrs[ai];
     654:	00093983          	ld	s3,0(s2)
    int fd = open("README", 0);
     658:	4581                	li	a1,0
     65a:	855a                	mv	a0,s6
     65c:	6f8040ef          	jal	4d54 <open>
     660:	84aa                	mv	s1,a0
    if(fd < 0){
     662:	06054863          	bltz	a0,6d2 <copyout+0xe4>
    int n = read(fd, (void*)addr, 8192);
     666:	8656                	mv	a2,s5
     668:	85ce                	mv	a1,s3
     66a:	6c2040ef          	jal	4d2c <read>
    if(n > 0){
     66e:	06a04b63          	bgtz	a0,6e4 <copyout+0xf6>
    close(fd);
     672:	8526                	mv	a0,s1
     674:	6c8040ef          	jal	4d3c <close>
    if(pipe(fds) < 0){
     678:	8562                	mv	a0,s8
     67a:	6aa040ef          	jal	4d24 <pipe>
     67e:	06054e63          	bltz	a0,6fa <copyout+0x10c>
    n = write(fds[1], "x", 1);
     682:	8652                	mv	a2,s4
     684:	85de                	mv	a1,s7
     686:	f6c42503          	lw	a0,-148(s0)
     68a:	6aa040ef          	jal	4d34 <write>
    if(n != 1){
     68e:	07451f63          	bne	a0,s4,70c <copyout+0x11e>
    n = read(fds[0], (void*)addr, 8192);
     692:	8656                	mv	a2,s5
     694:	85ce                	mv	a1,s3
     696:	f6842503          	lw	a0,-152(s0)
     69a:	692040ef          	jal	4d2c <read>
    if(n > 0){
     69e:	08a04063          	bgtz	a0,71e <copyout+0x130>
    close(fds[0]);
     6a2:	f6842503          	lw	a0,-152(s0)
     6a6:	696040ef          	jal	4d3c <close>
    close(fds[1]);
     6aa:	f6c42503          	lw	a0,-148(s0)
     6ae:	68e040ef          	jal	4d3c <close>
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
     6b2:	0921                	addi	s2,s2,8
     6b4:	fb9910e3          	bne	s2,s9,654 <copyout+0x66>
}
     6b8:	60ea                	ld	ra,152(sp)
     6ba:	644a                	ld	s0,144(sp)
     6bc:	64aa                	ld	s1,136(sp)
     6be:	690a                	ld	s2,128(sp)
     6c0:	79e6                	ld	s3,120(sp)
     6c2:	7a46                	ld	s4,112(sp)
     6c4:	7aa6                	ld	s5,104(sp)
     6c6:	7b06                	ld	s6,96(sp)
     6c8:	6be6                	ld	s7,88(sp)
     6ca:	6c46                	ld	s8,80(sp)
     6cc:	6ca6                	ld	s9,72(sp)
     6ce:	610d                	addi	sp,sp,160
     6d0:	8082                	ret
      printf("open(README) failed\n");
     6d2:	00005517          	auipc	a0,0x5
     6d6:	02650513          	addi	a0,a0,38 # 56f8 <thread_switch+0x282>
     6da:	27d040ef          	jal	5156 <printf>
      exit(1);
     6de:	4505                	li	a0,1
     6e0:	634040ef          	jal	4d14 <exit>
      printf("read(fd, %p, 8192) returned %d, not -1 or 0\n", (void*)addr, n);
     6e4:	862a                	mv	a2,a0
     6e6:	85ce                	mv	a1,s3
     6e8:	00005517          	auipc	a0,0x5
     6ec:	02850513          	addi	a0,a0,40 # 5710 <thread_switch+0x29a>
     6f0:	267040ef          	jal	5156 <printf>
      exit(1);
     6f4:	4505                	li	a0,1
     6f6:	61e040ef          	jal	4d14 <exit>
      printf("pipe() failed\n");
     6fa:	00005517          	auipc	a0,0x5
     6fe:	fb650513          	addi	a0,a0,-74 # 56b0 <thread_switch+0x23a>
     702:	255040ef          	jal	5156 <printf>
      exit(1);
     706:	4505                	li	a0,1
     708:	60c040ef          	jal	4d14 <exit>
      printf("pipe write failed\n");
     70c:	00005517          	auipc	a0,0x5
     710:	03450513          	addi	a0,a0,52 # 5740 <thread_switch+0x2ca>
     714:	243040ef          	jal	5156 <printf>
      exit(1);
     718:	4505                	li	a0,1
     71a:	5fa040ef          	jal	4d14 <exit>
      printf("read(pipe, %p, 8192) returned %d, not -1 or 0\n", (void*)addr, n);
     71e:	862a                	mv	a2,a0
     720:	85ce                	mv	a1,s3
     722:	00005517          	auipc	a0,0x5
     726:	03650513          	addi	a0,a0,54 # 5758 <thread_switch+0x2e2>
     72a:	22d040ef          	jal	5156 <printf>
      exit(1);
     72e:	4505                	li	a0,1
     730:	5e4040ef          	jal	4d14 <exit>

0000000000000734 <truncate1>:
{
     734:	711d                	addi	sp,sp,-96
     736:	ec86                	sd	ra,88(sp)
     738:	e8a2                	sd	s0,80(sp)
     73a:	e4a6                	sd	s1,72(sp)
     73c:	e0ca                	sd	s2,64(sp)
     73e:	fc4e                	sd	s3,56(sp)
     740:	f852                	sd	s4,48(sp)
     742:	f456                	sd	s5,40(sp)
     744:	1080                	addi	s0,sp,96
     746:	8a2a                	mv	s4,a0
  unlink("truncfile");
     748:	00005517          	auipc	a0,0x5
     74c:	e2850513          	addi	a0,a0,-472 # 5570 <thread_switch+0xfa>
     750:	614040ef          	jal	4d64 <unlink>
  int fd1 = open("truncfile", O_CREATE|O_WRONLY|O_TRUNC);
     754:	60100593          	li	a1,1537
     758:	00005517          	auipc	a0,0x5
     75c:	e1850513          	addi	a0,a0,-488 # 5570 <thread_switch+0xfa>
     760:	5f4040ef          	jal	4d54 <open>
     764:	84aa                	mv	s1,a0
  write(fd1, "abcd", 4);
     766:	4611                	li	a2,4
     768:	00005597          	auipc	a1,0x5
     76c:	e1858593          	addi	a1,a1,-488 # 5580 <thread_switch+0x10a>
     770:	5c4040ef          	jal	4d34 <write>
  close(fd1);
     774:	8526                	mv	a0,s1
     776:	5c6040ef          	jal	4d3c <close>
  int fd2 = open("truncfile", O_RDONLY);
     77a:	4581                	li	a1,0
     77c:	00005517          	auipc	a0,0x5
     780:	df450513          	addi	a0,a0,-524 # 5570 <thread_switch+0xfa>
     784:	5d0040ef          	jal	4d54 <open>
     788:	84aa                	mv	s1,a0
  int n = read(fd2, buf, sizeof(buf));
     78a:	02000613          	li	a2,32
     78e:	fa040593          	addi	a1,s0,-96
     792:	59a040ef          	jal	4d2c <read>
  if(n != 4){
     796:	4791                	li	a5,4
     798:	0af51863          	bne	a0,a5,848 <truncate1+0x114>
  fd1 = open("truncfile", O_WRONLY|O_TRUNC);
     79c:	40100593          	li	a1,1025
     7a0:	00005517          	auipc	a0,0x5
     7a4:	dd050513          	addi	a0,a0,-560 # 5570 <thread_switch+0xfa>
     7a8:	5ac040ef          	jal	4d54 <open>
     7ac:	89aa                	mv	s3,a0
  int fd3 = open("truncfile", O_RDONLY);
     7ae:	4581                	li	a1,0
     7b0:	00005517          	auipc	a0,0x5
     7b4:	dc050513          	addi	a0,a0,-576 # 5570 <thread_switch+0xfa>
     7b8:	59c040ef          	jal	4d54 <open>
     7bc:	892a                	mv	s2,a0
  n = read(fd3, buf, sizeof(buf));
     7be:	02000613          	li	a2,32
     7c2:	fa040593          	addi	a1,s0,-96
     7c6:	566040ef          	jal	4d2c <read>
     7ca:	8aaa                	mv	s5,a0
  if(n != 0){
     7cc:	e949                	bnez	a0,85e <truncate1+0x12a>
  n = read(fd2, buf, sizeof(buf));
     7ce:	02000613          	li	a2,32
     7d2:	fa040593          	addi	a1,s0,-96
     7d6:	8526                	mv	a0,s1
     7d8:	554040ef          	jal	4d2c <read>
     7dc:	8aaa                	mv	s5,a0
  if(n != 0){
     7de:	e155                	bnez	a0,882 <truncate1+0x14e>
  write(fd1, "abcdef", 6);
     7e0:	4619                	li	a2,6
     7e2:	00005597          	auipc	a1,0x5
     7e6:	00658593          	addi	a1,a1,6 # 57e8 <thread_switch+0x372>
     7ea:	854e                	mv	a0,s3
     7ec:	548040ef          	jal	4d34 <write>
  n = read(fd3, buf, sizeof(buf));
     7f0:	02000613          	li	a2,32
     7f4:	fa040593          	addi	a1,s0,-96
     7f8:	854a                	mv	a0,s2
     7fa:	532040ef          	jal	4d2c <read>
  if(n != 6){
     7fe:	4799                	li	a5,6
     800:	0af51363          	bne	a0,a5,8a6 <truncate1+0x172>
  n = read(fd2, buf, sizeof(buf));
     804:	02000613          	li	a2,32
     808:	fa040593          	addi	a1,s0,-96
     80c:	8526                	mv	a0,s1
     80e:	51e040ef          	jal	4d2c <read>
  if(n != 2){
     812:	4789                	li	a5,2
     814:	0af51463          	bne	a0,a5,8bc <truncate1+0x188>
  unlink("truncfile");
     818:	00005517          	auipc	a0,0x5
     81c:	d5850513          	addi	a0,a0,-680 # 5570 <thread_switch+0xfa>
     820:	544040ef          	jal	4d64 <unlink>
  close(fd1);
     824:	854e                	mv	a0,s3
     826:	516040ef          	jal	4d3c <close>
  close(fd2);
     82a:	8526                	mv	a0,s1
     82c:	510040ef          	jal	4d3c <close>
  close(fd3);
     830:	854a                	mv	a0,s2
     832:	50a040ef          	jal	4d3c <close>
}
     836:	60e6                	ld	ra,88(sp)
     838:	6446                	ld	s0,80(sp)
     83a:	64a6                	ld	s1,72(sp)
     83c:	6906                	ld	s2,64(sp)
     83e:	79e2                	ld	s3,56(sp)
     840:	7a42                	ld	s4,48(sp)
     842:	7aa2                	ld	s5,40(sp)
     844:	6125                	addi	sp,sp,96
     846:	8082                	ret
    printf("%s: read %d bytes, wanted 4\n", s, n);
     848:	862a                	mv	a2,a0
     84a:	85d2                	mv	a1,s4
     84c:	00005517          	auipc	a0,0x5
     850:	f3c50513          	addi	a0,a0,-196 # 5788 <thread_switch+0x312>
     854:	103040ef          	jal	5156 <printf>
    exit(1);
     858:	4505                	li	a0,1
     85a:	4ba040ef          	jal	4d14 <exit>
    printf("aaa fd3=%d\n", fd3);
     85e:	85ca                	mv	a1,s2
     860:	00005517          	auipc	a0,0x5
     864:	f4850513          	addi	a0,a0,-184 # 57a8 <thread_switch+0x332>
     868:	0ef040ef          	jal	5156 <printf>
    printf("%s: read %d bytes, wanted 0\n", s, n);
     86c:	8656                	mv	a2,s5
     86e:	85d2                	mv	a1,s4
     870:	00005517          	auipc	a0,0x5
     874:	f4850513          	addi	a0,a0,-184 # 57b8 <thread_switch+0x342>
     878:	0df040ef          	jal	5156 <printf>
    exit(1);
     87c:	4505                	li	a0,1
     87e:	496040ef          	jal	4d14 <exit>
    printf("bbb fd2=%d\n", fd2);
     882:	85a6                	mv	a1,s1
     884:	00005517          	auipc	a0,0x5
     888:	f5450513          	addi	a0,a0,-172 # 57d8 <thread_switch+0x362>
     88c:	0cb040ef          	jal	5156 <printf>
    printf("%s: read %d bytes, wanted 0\n", s, n);
     890:	8656                	mv	a2,s5
     892:	85d2                	mv	a1,s4
     894:	00005517          	auipc	a0,0x5
     898:	f2450513          	addi	a0,a0,-220 # 57b8 <thread_switch+0x342>
     89c:	0bb040ef          	jal	5156 <printf>
    exit(1);
     8a0:	4505                	li	a0,1
     8a2:	472040ef          	jal	4d14 <exit>
    printf("%s: read %d bytes, wanted 6\n", s, n);
     8a6:	862a                	mv	a2,a0
     8a8:	85d2                	mv	a1,s4
     8aa:	00005517          	auipc	a0,0x5
     8ae:	f4650513          	addi	a0,a0,-186 # 57f0 <thread_switch+0x37a>
     8b2:	0a5040ef          	jal	5156 <printf>
    exit(1);
     8b6:	4505                	li	a0,1
     8b8:	45c040ef          	jal	4d14 <exit>
    printf("%s: read %d bytes, wanted 2\n", s, n);
     8bc:	862a                	mv	a2,a0
     8be:	85d2                	mv	a1,s4
     8c0:	00005517          	auipc	a0,0x5
     8c4:	f5050513          	addi	a0,a0,-176 # 5810 <thread_switch+0x39a>
     8c8:	08f040ef          	jal	5156 <printf>
    exit(1);
     8cc:	4505                	li	a0,1
     8ce:	446040ef          	jal	4d14 <exit>

00000000000008d2 <writetest>:
{
     8d2:	715d                	addi	sp,sp,-80
     8d4:	e486                	sd	ra,72(sp)
     8d6:	e0a2                	sd	s0,64(sp)
     8d8:	fc26                	sd	s1,56(sp)
     8da:	f84a                	sd	s2,48(sp)
     8dc:	f44e                	sd	s3,40(sp)
     8de:	f052                	sd	s4,32(sp)
     8e0:	ec56                	sd	s5,24(sp)
     8e2:	e85a                	sd	s6,16(sp)
     8e4:	e45e                	sd	s7,8(sp)
     8e6:	0880                	addi	s0,sp,80
     8e8:	8baa                	mv	s7,a0
  fd = open("small", O_CREATE|O_RDWR);
     8ea:	20200593          	li	a1,514
     8ee:	00005517          	auipc	a0,0x5
     8f2:	f4250513          	addi	a0,a0,-190 # 5830 <thread_switch+0x3ba>
     8f6:	45e040ef          	jal	4d54 <open>
  if(fd < 0){
     8fa:	08054f63          	bltz	a0,998 <writetest+0xc6>
     8fe:	89aa                	mv	s3,a0
     900:	4901                	li	s2,0
    if(write(fd, "aaaaaaaaaa", SZ) != SZ){
     902:	44a9                	li	s1,10
     904:	00005a17          	auipc	s4,0x5
     908:	f54a0a13          	addi	s4,s4,-172 # 5858 <thread_switch+0x3e2>
    if(write(fd, "bbbbbbbbbb", SZ) != SZ){
     90c:	00005b17          	auipc	s6,0x5
     910:	f84b0b13          	addi	s6,s6,-124 # 5890 <thread_switch+0x41a>
  for(i = 0; i < N; i++){
     914:	06400a93          	li	s5,100
    if(write(fd, "aaaaaaaaaa", SZ) != SZ){
     918:	8626                	mv	a2,s1
     91a:	85d2                	mv	a1,s4
     91c:	854e                	mv	a0,s3
     91e:	416040ef          	jal	4d34 <write>
     922:	08951563          	bne	a0,s1,9ac <writetest+0xda>
    if(write(fd, "bbbbbbbbbb", SZ) != SZ){
     926:	8626                	mv	a2,s1
     928:	85da                	mv	a1,s6
     92a:	854e                	mv	a0,s3
     92c:	408040ef          	jal	4d34 <write>
     930:	08951963          	bne	a0,s1,9c2 <writetest+0xf0>
  for(i = 0; i < N; i++){
     934:	2905                	addiw	s2,s2,1
     936:	ff5911e3          	bne	s2,s5,918 <writetest+0x46>
  close(fd);
     93a:	854e                	mv	a0,s3
     93c:	400040ef          	jal	4d3c <close>
  fd = open("small", O_RDONLY);
     940:	4581                	li	a1,0
     942:	00005517          	auipc	a0,0x5
     946:	eee50513          	addi	a0,a0,-274 # 5830 <thread_switch+0x3ba>
     94a:	40a040ef          	jal	4d54 <open>
     94e:	84aa                	mv	s1,a0
  if(fd < 0){
     950:	08054463          	bltz	a0,9d8 <writetest+0x106>
  i = read(fd, buf, N*SZ*2);
     954:	7d000613          	li	a2,2000
     958:	0000b597          	auipc	a1,0xb
     95c:	32058593          	addi	a1,a1,800 # bc78 <buf>
     960:	3cc040ef          	jal	4d2c <read>
  if(i != N*SZ*2){
     964:	7d000793          	li	a5,2000
     968:	08f51263          	bne	a0,a5,9ec <writetest+0x11a>
  close(fd);
     96c:	8526                	mv	a0,s1
     96e:	3ce040ef          	jal	4d3c <close>
  if(unlink("small") < 0){
     972:	00005517          	auipc	a0,0x5
     976:	ebe50513          	addi	a0,a0,-322 # 5830 <thread_switch+0x3ba>
     97a:	3ea040ef          	jal	4d64 <unlink>
     97e:	08054163          	bltz	a0,a00 <writetest+0x12e>
}
     982:	60a6                	ld	ra,72(sp)
     984:	6406                	ld	s0,64(sp)
     986:	74e2                	ld	s1,56(sp)
     988:	7942                	ld	s2,48(sp)
     98a:	79a2                	ld	s3,40(sp)
     98c:	7a02                	ld	s4,32(sp)
     98e:	6ae2                	ld	s5,24(sp)
     990:	6b42                	ld	s6,16(sp)
     992:	6ba2                	ld	s7,8(sp)
     994:	6161                	addi	sp,sp,80
     996:	8082                	ret
    printf("%s: error: creat small failed!\n", s);
     998:	85de                	mv	a1,s7
     99a:	00005517          	auipc	a0,0x5
     99e:	e9e50513          	addi	a0,a0,-354 # 5838 <thread_switch+0x3c2>
     9a2:	7b4040ef          	jal	5156 <printf>
    exit(1);
     9a6:	4505                	li	a0,1
     9a8:	36c040ef          	jal	4d14 <exit>
      printf("%s: error: write aa %d new file failed\n", s, i);
     9ac:	864a                	mv	a2,s2
     9ae:	85de                	mv	a1,s7
     9b0:	00005517          	auipc	a0,0x5
     9b4:	eb850513          	addi	a0,a0,-328 # 5868 <thread_switch+0x3f2>
     9b8:	79e040ef          	jal	5156 <printf>
      exit(1);
     9bc:	4505                	li	a0,1
     9be:	356040ef          	jal	4d14 <exit>
      printf("%s: error: write bb %d new file failed\n", s, i);
     9c2:	864a                	mv	a2,s2
     9c4:	85de                	mv	a1,s7
     9c6:	00005517          	auipc	a0,0x5
     9ca:	eda50513          	addi	a0,a0,-294 # 58a0 <thread_switch+0x42a>
     9ce:	788040ef          	jal	5156 <printf>
      exit(1);
     9d2:	4505                	li	a0,1
     9d4:	340040ef          	jal	4d14 <exit>
    printf("%s: error: open small failed!\n", s);
     9d8:	85de                	mv	a1,s7
     9da:	00005517          	auipc	a0,0x5
     9de:	eee50513          	addi	a0,a0,-274 # 58c8 <thread_switch+0x452>
     9e2:	774040ef          	jal	5156 <printf>
    exit(1);
     9e6:	4505                	li	a0,1
     9e8:	32c040ef          	jal	4d14 <exit>
    printf("%s: read failed\n", s);
     9ec:	85de                	mv	a1,s7
     9ee:	00005517          	auipc	a0,0x5
     9f2:	efa50513          	addi	a0,a0,-262 # 58e8 <thread_switch+0x472>
     9f6:	760040ef          	jal	5156 <printf>
    exit(1);
     9fa:	4505                	li	a0,1
     9fc:	318040ef          	jal	4d14 <exit>
    printf("%s: unlink small failed\n", s);
     a00:	85de                	mv	a1,s7
     a02:	00005517          	auipc	a0,0x5
     a06:	efe50513          	addi	a0,a0,-258 # 5900 <thread_switch+0x48a>
     a0a:	74c040ef          	jal	5156 <printf>
    exit(1);
     a0e:	4505                	li	a0,1
     a10:	304040ef          	jal	4d14 <exit>

0000000000000a14 <writebig>:
{
     a14:	7139                	addi	sp,sp,-64
     a16:	fc06                	sd	ra,56(sp)
     a18:	f822                	sd	s0,48(sp)
     a1a:	f426                	sd	s1,40(sp)
     a1c:	f04a                	sd	s2,32(sp)
     a1e:	ec4e                	sd	s3,24(sp)
     a20:	e852                	sd	s4,16(sp)
     a22:	e456                	sd	s5,8(sp)
     a24:	e05a                	sd	s6,0(sp)
     a26:	0080                	addi	s0,sp,64
     a28:	8b2a                	mv	s6,a0
  fd = open("big", O_CREATE|O_RDWR);
     a2a:	20200593          	li	a1,514
     a2e:	00005517          	auipc	a0,0x5
     a32:	ef250513          	addi	a0,a0,-270 # 5920 <thread_switch+0x4aa>
     a36:	31e040ef          	jal	4d54 <open>
  if(fd < 0){
     a3a:	06054a63          	bltz	a0,aae <writebig+0x9a>
     a3e:	8a2a                	mv	s4,a0
     a40:	4481                	li	s1,0
    ((int*)buf)[0] = i;
     a42:	0000b997          	auipc	s3,0xb
     a46:	23698993          	addi	s3,s3,566 # bc78 <buf>
    if(write(fd, buf, BSIZE) != BSIZE){
     a4a:	40000913          	li	s2,1024
  for(i = 0; i < MAXFILE; i++){
     a4e:	10c00a93          	li	s5,268
    ((int*)buf)[0] = i;
     a52:	0099a023          	sw	s1,0(s3)
    if(write(fd, buf, BSIZE) != BSIZE){
     a56:	864a                	mv	a2,s2
     a58:	85ce                	mv	a1,s3
     a5a:	8552                	mv	a0,s4
     a5c:	2d8040ef          	jal	4d34 <write>
     a60:	07251163          	bne	a0,s2,ac2 <writebig+0xae>
  for(i = 0; i < MAXFILE; i++){
     a64:	2485                	addiw	s1,s1,1
     a66:	ff5496e3          	bne	s1,s5,a52 <writebig+0x3e>
  close(fd);
     a6a:	8552                	mv	a0,s4
     a6c:	2d0040ef          	jal	4d3c <close>
  fd = open("big", O_RDONLY);
     a70:	4581                	li	a1,0
     a72:	00005517          	auipc	a0,0x5
     a76:	eae50513          	addi	a0,a0,-338 # 5920 <thread_switch+0x4aa>
     a7a:	2da040ef          	jal	4d54 <open>
     a7e:	8a2a                	mv	s4,a0
  n = 0;
     a80:	4481                	li	s1,0
    i = read(fd, buf, BSIZE);
     a82:	40000993          	li	s3,1024
     a86:	0000b917          	auipc	s2,0xb
     a8a:	1f290913          	addi	s2,s2,498 # bc78 <buf>
  if(fd < 0){
     a8e:	04054563          	bltz	a0,ad8 <writebig+0xc4>
    i = read(fd, buf, BSIZE);
     a92:	864e                	mv	a2,s3
     a94:	85ca                	mv	a1,s2
     a96:	8552                	mv	a0,s4
     a98:	294040ef          	jal	4d2c <read>
    if(i == 0){
     a9c:	c921                	beqz	a0,aec <writebig+0xd8>
    } else if(i != BSIZE){
     a9e:	09351b63          	bne	a0,s3,b34 <writebig+0x120>
    if(((int*)buf)[0] != n){
     aa2:	00092683          	lw	a3,0(s2)
     aa6:	0a969263          	bne	a3,s1,b4a <writebig+0x136>
    n++;
     aaa:	2485                	addiw	s1,s1,1
    i = read(fd, buf, BSIZE);
     aac:	b7dd                	j	a92 <writebig+0x7e>
    printf("%s: error: creat big failed!\n", s);
     aae:	85da                	mv	a1,s6
     ab0:	00005517          	auipc	a0,0x5
     ab4:	e7850513          	addi	a0,a0,-392 # 5928 <thread_switch+0x4b2>
     ab8:	69e040ef          	jal	5156 <printf>
    exit(1);
     abc:	4505                	li	a0,1
     abe:	256040ef          	jal	4d14 <exit>
      printf("%s: error: write big file failed i=%d\n", s, i);
     ac2:	8626                	mv	a2,s1
     ac4:	85da                	mv	a1,s6
     ac6:	00005517          	auipc	a0,0x5
     aca:	e8250513          	addi	a0,a0,-382 # 5948 <thread_switch+0x4d2>
     ace:	688040ef          	jal	5156 <printf>
      exit(1);
     ad2:	4505                	li	a0,1
     ad4:	240040ef          	jal	4d14 <exit>
    printf("%s: error: open big failed!\n", s);
     ad8:	85da                	mv	a1,s6
     ada:	00005517          	auipc	a0,0x5
     ade:	e9650513          	addi	a0,a0,-362 # 5970 <thread_switch+0x4fa>
     ae2:	674040ef          	jal	5156 <printf>
    exit(1);
     ae6:	4505                	li	a0,1
     ae8:	22c040ef          	jal	4d14 <exit>
      if(n != MAXFILE){
     aec:	10c00793          	li	a5,268
     af0:	02f49763          	bne	s1,a5,b1e <writebig+0x10a>
  close(fd);
     af4:	8552                	mv	a0,s4
     af6:	246040ef          	jal	4d3c <close>
  if(unlink("big") < 0){
     afa:	00005517          	auipc	a0,0x5
     afe:	e2650513          	addi	a0,a0,-474 # 5920 <thread_switch+0x4aa>
     b02:	262040ef          	jal	4d64 <unlink>
     b06:	04054d63          	bltz	a0,b60 <writebig+0x14c>
}
     b0a:	70e2                	ld	ra,56(sp)
     b0c:	7442                	ld	s0,48(sp)
     b0e:	74a2                	ld	s1,40(sp)
     b10:	7902                	ld	s2,32(sp)
     b12:	69e2                	ld	s3,24(sp)
     b14:	6a42                	ld	s4,16(sp)
     b16:	6aa2                	ld	s5,8(sp)
     b18:	6b02                	ld	s6,0(sp)
     b1a:	6121                	addi	sp,sp,64
     b1c:	8082                	ret
        printf("%s: read only %d blocks from big", s, n);
     b1e:	8626                	mv	a2,s1
     b20:	85da                	mv	a1,s6
     b22:	00005517          	auipc	a0,0x5
     b26:	e6e50513          	addi	a0,a0,-402 # 5990 <thread_switch+0x51a>
     b2a:	62c040ef          	jal	5156 <printf>
        exit(1);
     b2e:	4505                	li	a0,1
     b30:	1e4040ef          	jal	4d14 <exit>
      printf("%s: read failed %d\n", s, i);
     b34:	862a                	mv	a2,a0
     b36:	85da                	mv	a1,s6
     b38:	00005517          	auipc	a0,0x5
     b3c:	e8050513          	addi	a0,a0,-384 # 59b8 <thread_switch+0x542>
     b40:	616040ef          	jal	5156 <printf>
      exit(1);
     b44:	4505                	li	a0,1
     b46:	1ce040ef          	jal	4d14 <exit>
      printf("%s: read content of block %d is %d\n", s,
     b4a:	8626                	mv	a2,s1
     b4c:	85da                	mv	a1,s6
     b4e:	00005517          	auipc	a0,0x5
     b52:	e8250513          	addi	a0,a0,-382 # 59d0 <thread_switch+0x55a>
     b56:	600040ef          	jal	5156 <printf>
      exit(1);
     b5a:	4505                	li	a0,1
     b5c:	1b8040ef          	jal	4d14 <exit>
    printf("%s: unlink big failed\n", s);
     b60:	85da                	mv	a1,s6
     b62:	00005517          	auipc	a0,0x5
     b66:	e9650513          	addi	a0,a0,-362 # 59f8 <thread_switch+0x582>
     b6a:	5ec040ef          	jal	5156 <printf>
    exit(1);
     b6e:	4505                	li	a0,1
     b70:	1a4040ef          	jal	4d14 <exit>

0000000000000b74 <unlinkread>:
{
     b74:	7179                	addi	sp,sp,-48
     b76:	f406                	sd	ra,40(sp)
     b78:	f022                	sd	s0,32(sp)
     b7a:	ec26                	sd	s1,24(sp)
     b7c:	e84a                	sd	s2,16(sp)
     b7e:	e44e                	sd	s3,8(sp)
     b80:	1800                	addi	s0,sp,48
     b82:	89aa                	mv	s3,a0
  fd = open("unlinkread", O_CREATE | O_RDWR);
     b84:	20200593          	li	a1,514
     b88:	00005517          	auipc	a0,0x5
     b8c:	e8850513          	addi	a0,a0,-376 # 5a10 <thread_switch+0x59a>
     b90:	1c4040ef          	jal	4d54 <open>
  if(fd < 0){
     b94:	0a054f63          	bltz	a0,c52 <unlinkread+0xde>
     b98:	84aa                	mv	s1,a0
  write(fd, "hello", SZ);
     b9a:	4615                	li	a2,5
     b9c:	00005597          	auipc	a1,0x5
     ba0:	ea458593          	addi	a1,a1,-348 # 5a40 <thread_switch+0x5ca>
     ba4:	190040ef          	jal	4d34 <write>
  close(fd);
     ba8:	8526                	mv	a0,s1
     baa:	192040ef          	jal	4d3c <close>
  fd = open("unlinkread", O_RDWR);
     bae:	4589                	li	a1,2
     bb0:	00005517          	auipc	a0,0x5
     bb4:	e6050513          	addi	a0,a0,-416 # 5a10 <thread_switch+0x59a>
     bb8:	19c040ef          	jal	4d54 <open>
     bbc:	84aa                	mv	s1,a0
  if(fd < 0){
     bbe:	0a054463          	bltz	a0,c66 <unlinkread+0xf2>
  if(unlink("unlinkread") != 0){
     bc2:	00005517          	auipc	a0,0x5
     bc6:	e4e50513          	addi	a0,a0,-434 # 5a10 <thread_switch+0x59a>
     bca:	19a040ef          	jal	4d64 <unlink>
     bce:	e555                	bnez	a0,c7a <unlinkread+0x106>
  fd1 = open("unlinkread", O_CREATE | O_RDWR);
     bd0:	20200593          	li	a1,514
     bd4:	00005517          	auipc	a0,0x5
     bd8:	e3c50513          	addi	a0,a0,-452 # 5a10 <thread_switch+0x59a>
     bdc:	178040ef          	jal	4d54 <open>
     be0:	892a                	mv	s2,a0
  write(fd1, "yyy", 3);
     be2:	460d                	li	a2,3
     be4:	00005597          	auipc	a1,0x5
     be8:	ea458593          	addi	a1,a1,-348 # 5a88 <thread_switch+0x612>
     bec:	148040ef          	jal	4d34 <write>
  close(fd1);
     bf0:	854a                	mv	a0,s2
     bf2:	14a040ef          	jal	4d3c <close>
  if(read(fd, buf, sizeof(buf)) != SZ){
     bf6:	660d                	lui	a2,0x3
     bf8:	0000b597          	auipc	a1,0xb
     bfc:	08058593          	addi	a1,a1,128 # bc78 <buf>
     c00:	8526                	mv	a0,s1
     c02:	12a040ef          	jal	4d2c <read>
     c06:	4795                	li	a5,5
     c08:	08f51363          	bne	a0,a5,c8e <unlinkread+0x11a>
  if(buf[0] != 'h'){
     c0c:	0000b717          	auipc	a4,0xb
     c10:	06c74703          	lbu	a4,108(a4) # bc78 <buf>
     c14:	06800793          	li	a5,104
     c18:	08f71563          	bne	a4,a5,ca2 <unlinkread+0x12e>
  if(write(fd, buf, 10) != 10){
     c1c:	4629                	li	a2,10
     c1e:	0000b597          	auipc	a1,0xb
     c22:	05a58593          	addi	a1,a1,90 # bc78 <buf>
     c26:	8526                	mv	a0,s1
     c28:	10c040ef          	jal	4d34 <write>
     c2c:	47a9                	li	a5,10
     c2e:	08f51463          	bne	a0,a5,cb6 <unlinkread+0x142>
  close(fd);
     c32:	8526                	mv	a0,s1
     c34:	108040ef          	jal	4d3c <close>
  unlink("unlinkread");
     c38:	00005517          	auipc	a0,0x5
     c3c:	dd850513          	addi	a0,a0,-552 # 5a10 <thread_switch+0x59a>
     c40:	124040ef          	jal	4d64 <unlink>
}
     c44:	70a2                	ld	ra,40(sp)
     c46:	7402                	ld	s0,32(sp)
     c48:	64e2                	ld	s1,24(sp)
     c4a:	6942                	ld	s2,16(sp)
     c4c:	69a2                	ld	s3,8(sp)
     c4e:	6145                	addi	sp,sp,48
     c50:	8082                	ret
    printf("%s: create unlinkread failed\n", s);
     c52:	85ce                	mv	a1,s3
     c54:	00005517          	auipc	a0,0x5
     c58:	dcc50513          	addi	a0,a0,-564 # 5a20 <thread_switch+0x5aa>
     c5c:	4fa040ef          	jal	5156 <printf>
    exit(1);
     c60:	4505                	li	a0,1
     c62:	0b2040ef          	jal	4d14 <exit>
    printf("%s: open unlinkread failed\n", s);
     c66:	85ce                	mv	a1,s3
     c68:	00005517          	auipc	a0,0x5
     c6c:	de050513          	addi	a0,a0,-544 # 5a48 <thread_switch+0x5d2>
     c70:	4e6040ef          	jal	5156 <printf>
    exit(1);
     c74:	4505                	li	a0,1
     c76:	09e040ef          	jal	4d14 <exit>
    printf("%s: unlink unlinkread failed\n", s);
     c7a:	85ce                	mv	a1,s3
     c7c:	00005517          	auipc	a0,0x5
     c80:	dec50513          	addi	a0,a0,-532 # 5a68 <thread_switch+0x5f2>
     c84:	4d2040ef          	jal	5156 <printf>
    exit(1);
     c88:	4505                	li	a0,1
     c8a:	08a040ef          	jal	4d14 <exit>
    printf("%s: unlinkread read failed", s);
     c8e:	85ce                	mv	a1,s3
     c90:	00005517          	auipc	a0,0x5
     c94:	e0050513          	addi	a0,a0,-512 # 5a90 <thread_switch+0x61a>
     c98:	4be040ef          	jal	5156 <printf>
    exit(1);
     c9c:	4505                	li	a0,1
     c9e:	076040ef          	jal	4d14 <exit>
    printf("%s: unlinkread wrong data\n", s);
     ca2:	85ce                	mv	a1,s3
     ca4:	00005517          	auipc	a0,0x5
     ca8:	e0c50513          	addi	a0,a0,-500 # 5ab0 <thread_switch+0x63a>
     cac:	4aa040ef          	jal	5156 <printf>
    exit(1);
     cb0:	4505                	li	a0,1
     cb2:	062040ef          	jal	4d14 <exit>
    printf("%s: unlinkread write failed\n", s);
     cb6:	85ce                	mv	a1,s3
     cb8:	00005517          	auipc	a0,0x5
     cbc:	e1850513          	addi	a0,a0,-488 # 5ad0 <thread_switch+0x65a>
     cc0:	496040ef          	jal	5156 <printf>
    exit(1);
     cc4:	4505                	li	a0,1
     cc6:	04e040ef          	jal	4d14 <exit>

0000000000000cca <linktest>:
{
     cca:	1101                	addi	sp,sp,-32
     ccc:	ec06                	sd	ra,24(sp)
     cce:	e822                	sd	s0,16(sp)
     cd0:	e426                	sd	s1,8(sp)
     cd2:	e04a                	sd	s2,0(sp)
     cd4:	1000                	addi	s0,sp,32
     cd6:	892a                	mv	s2,a0
  unlink("lf1");
     cd8:	00005517          	auipc	a0,0x5
     cdc:	e1850513          	addi	a0,a0,-488 # 5af0 <thread_switch+0x67a>
     ce0:	084040ef          	jal	4d64 <unlink>
  unlink("lf2");
     ce4:	00005517          	auipc	a0,0x5
     ce8:	e1450513          	addi	a0,a0,-492 # 5af8 <thread_switch+0x682>
     cec:	078040ef          	jal	4d64 <unlink>
  fd = open("lf1", O_CREATE|O_RDWR);
     cf0:	20200593          	li	a1,514
     cf4:	00005517          	auipc	a0,0x5
     cf8:	dfc50513          	addi	a0,a0,-516 # 5af0 <thread_switch+0x67a>
     cfc:	058040ef          	jal	4d54 <open>
  if(fd < 0){
     d00:	0c054f63          	bltz	a0,dde <linktest+0x114>
     d04:	84aa                	mv	s1,a0
  if(write(fd, "hello", SZ) != SZ){
     d06:	4615                	li	a2,5
     d08:	00005597          	auipc	a1,0x5
     d0c:	d3858593          	addi	a1,a1,-712 # 5a40 <thread_switch+0x5ca>
     d10:	024040ef          	jal	4d34 <write>
     d14:	4795                	li	a5,5
     d16:	0cf51e63          	bne	a0,a5,df2 <linktest+0x128>
  close(fd);
     d1a:	8526                	mv	a0,s1
     d1c:	020040ef          	jal	4d3c <close>
  if(link("lf1", "lf2") < 0){
     d20:	00005597          	auipc	a1,0x5
     d24:	dd858593          	addi	a1,a1,-552 # 5af8 <thread_switch+0x682>
     d28:	00005517          	auipc	a0,0x5
     d2c:	dc850513          	addi	a0,a0,-568 # 5af0 <thread_switch+0x67a>
     d30:	044040ef          	jal	4d74 <link>
     d34:	0c054963          	bltz	a0,e06 <linktest+0x13c>
  unlink("lf1");
     d38:	00005517          	auipc	a0,0x5
     d3c:	db850513          	addi	a0,a0,-584 # 5af0 <thread_switch+0x67a>
     d40:	024040ef          	jal	4d64 <unlink>
  if(open("lf1", 0) >= 0){
     d44:	4581                	li	a1,0
     d46:	00005517          	auipc	a0,0x5
     d4a:	daa50513          	addi	a0,a0,-598 # 5af0 <thread_switch+0x67a>
     d4e:	006040ef          	jal	4d54 <open>
     d52:	0c055463          	bgez	a0,e1a <linktest+0x150>
  fd = open("lf2", 0);
     d56:	4581                	li	a1,0
     d58:	00005517          	auipc	a0,0x5
     d5c:	da050513          	addi	a0,a0,-608 # 5af8 <thread_switch+0x682>
     d60:	7f5030ef          	jal	4d54 <open>
     d64:	84aa                	mv	s1,a0
  if(fd < 0){
     d66:	0c054463          	bltz	a0,e2e <linktest+0x164>
  if(read(fd, buf, sizeof(buf)) != SZ){
     d6a:	660d                	lui	a2,0x3
     d6c:	0000b597          	auipc	a1,0xb
     d70:	f0c58593          	addi	a1,a1,-244 # bc78 <buf>
     d74:	7b9030ef          	jal	4d2c <read>
     d78:	4795                	li	a5,5
     d7a:	0cf51463          	bne	a0,a5,e42 <linktest+0x178>
  close(fd);
     d7e:	8526                	mv	a0,s1
     d80:	7bd030ef          	jal	4d3c <close>
  if(link("lf2", "lf2") >= 0){
     d84:	00005597          	auipc	a1,0x5
     d88:	d7458593          	addi	a1,a1,-652 # 5af8 <thread_switch+0x682>
     d8c:	852e                	mv	a0,a1
     d8e:	7e7030ef          	jal	4d74 <link>
     d92:	0c055263          	bgez	a0,e56 <linktest+0x18c>
  unlink("lf2");
     d96:	00005517          	auipc	a0,0x5
     d9a:	d6250513          	addi	a0,a0,-670 # 5af8 <thread_switch+0x682>
     d9e:	7c7030ef          	jal	4d64 <unlink>
  if(link("lf2", "lf1") >= 0){
     da2:	00005597          	auipc	a1,0x5
     da6:	d4e58593          	addi	a1,a1,-690 # 5af0 <thread_switch+0x67a>
     daa:	00005517          	auipc	a0,0x5
     dae:	d4e50513          	addi	a0,a0,-690 # 5af8 <thread_switch+0x682>
     db2:	7c3030ef          	jal	4d74 <link>
     db6:	0a055a63          	bgez	a0,e6a <linktest+0x1a0>
  if(link(".", "lf1") >= 0){
     dba:	00005597          	auipc	a1,0x5
     dbe:	d3658593          	addi	a1,a1,-714 # 5af0 <thread_switch+0x67a>
     dc2:	00005517          	auipc	a0,0x5
     dc6:	e3e50513          	addi	a0,a0,-450 # 5c00 <thread_switch+0x78a>
     dca:	7ab030ef          	jal	4d74 <link>
     dce:	0a055863          	bgez	a0,e7e <linktest+0x1b4>
}
     dd2:	60e2                	ld	ra,24(sp)
     dd4:	6442                	ld	s0,16(sp)
     dd6:	64a2                	ld	s1,8(sp)
     dd8:	6902                	ld	s2,0(sp)
     dda:	6105                	addi	sp,sp,32
     ddc:	8082                	ret
    printf("%s: create lf1 failed\n", s);
     dde:	85ca                	mv	a1,s2
     de0:	00005517          	auipc	a0,0x5
     de4:	d2050513          	addi	a0,a0,-736 # 5b00 <thread_switch+0x68a>
     de8:	36e040ef          	jal	5156 <printf>
    exit(1);
     dec:	4505                	li	a0,1
     dee:	727030ef          	jal	4d14 <exit>
    printf("%s: write lf1 failed\n", s);
     df2:	85ca                	mv	a1,s2
     df4:	00005517          	auipc	a0,0x5
     df8:	d2450513          	addi	a0,a0,-732 # 5b18 <thread_switch+0x6a2>
     dfc:	35a040ef          	jal	5156 <printf>
    exit(1);
     e00:	4505                	li	a0,1
     e02:	713030ef          	jal	4d14 <exit>
    printf("%s: link lf1 lf2 failed\n", s);
     e06:	85ca                	mv	a1,s2
     e08:	00005517          	auipc	a0,0x5
     e0c:	d2850513          	addi	a0,a0,-728 # 5b30 <thread_switch+0x6ba>
     e10:	346040ef          	jal	5156 <printf>
    exit(1);
     e14:	4505                	li	a0,1
     e16:	6ff030ef          	jal	4d14 <exit>
    printf("%s: unlinked lf1 but it is still there!\n", s);
     e1a:	85ca                	mv	a1,s2
     e1c:	00005517          	auipc	a0,0x5
     e20:	d3450513          	addi	a0,a0,-716 # 5b50 <thread_switch+0x6da>
     e24:	332040ef          	jal	5156 <printf>
    exit(1);
     e28:	4505                	li	a0,1
     e2a:	6eb030ef          	jal	4d14 <exit>
    printf("%s: open lf2 failed\n", s);
     e2e:	85ca                	mv	a1,s2
     e30:	00005517          	auipc	a0,0x5
     e34:	d5050513          	addi	a0,a0,-688 # 5b80 <thread_switch+0x70a>
     e38:	31e040ef          	jal	5156 <printf>
    exit(1);
     e3c:	4505                	li	a0,1
     e3e:	6d7030ef          	jal	4d14 <exit>
    printf("%s: read lf2 failed\n", s);
     e42:	85ca                	mv	a1,s2
     e44:	00005517          	auipc	a0,0x5
     e48:	d5450513          	addi	a0,a0,-684 # 5b98 <thread_switch+0x722>
     e4c:	30a040ef          	jal	5156 <printf>
    exit(1);
     e50:	4505                	li	a0,1
     e52:	6c3030ef          	jal	4d14 <exit>
    printf("%s: link lf2 lf2 succeeded! oops\n", s);
     e56:	85ca                	mv	a1,s2
     e58:	00005517          	auipc	a0,0x5
     e5c:	d5850513          	addi	a0,a0,-680 # 5bb0 <thread_switch+0x73a>
     e60:	2f6040ef          	jal	5156 <printf>
    exit(1);
     e64:	4505                	li	a0,1
     e66:	6af030ef          	jal	4d14 <exit>
    printf("%s: link non-existent succeeded! oops\n", s);
     e6a:	85ca                	mv	a1,s2
     e6c:	00005517          	auipc	a0,0x5
     e70:	d6c50513          	addi	a0,a0,-660 # 5bd8 <thread_switch+0x762>
     e74:	2e2040ef          	jal	5156 <printf>
    exit(1);
     e78:	4505                	li	a0,1
     e7a:	69b030ef          	jal	4d14 <exit>
    printf("%s: link . lf1 succeeded! oops\n", s);
     e7e:	85ca                	mv	a1,s2
     e80:	00005517          	auipc	a0,0x5
     e84:	d8850513          	addi	a0,a0,-632 # 5c08 <thread_switch+0x792>
     e88:	2ce040ef          	jal	5156 <printf>
    exit(1);
     e8c:	4505                	li	a0,1
     e8e:	687030ef          	jal	4d14 <exit>

0000000000000e92 <validatetest>:
{
     e92:	7139                	addi	sp,sp,-64
     e94:	fc06                	sd	ra,56(sp)
     e96:	f822                	sd	s0,48(sp)
     e98:	f426                	sd	s1,40(sp)
     e9a:	f04a                	sd	s2,32(sp)
     e9c:	ec4e                	sd	s3,24(sp)
     e9e:	e852                	sd	s4,16(sp)
     ea0:	e456                	sd	s5,8(sp)
     ea2:	e05a                	sd	s6,0(sp)
     ea4:	0080                	addi	s0,sp,64
     ea6:	8b2a                	mv	s6,a0
  for(p = 0; p <= (uint)hi; p += PGSIZE){
     ea8:	4481                	li	s1,0
    if(link("nosuchfile", (char*)p) != -1){
     eaa:	00005997          	auipc	s3,0x5
     eae:	d7e98993          	addi	s3,s3,-642 # 5c28 <thread_switch+0x7b2>
     eb2:	597d                	li	s2,-1
  for(p = 0; p <= (uint)hi; p += PGSIZE){
     eb4:	6a85                	lui	s5,0x1
     eb6:	00114a37          	lui	s4,0x114
    if(link("nosuchfile", (char*)p) != -1){
     eba:	85a6                	mv	a1,s1
     ebc:	854e                	mv	a0,s3
     ebe:	6b7030ef          	jal	4d74 <link>
     ec2:	01251f63          	bne	a0,s2,ee0 <validatetest+0x4e>
  for(p = 0; p <= (uint)hi; p += PGSIZE){
     ec6:	94d6                	add	s1,s1,s5
     ec8:	ff4499e3          	bne	s1,s4,eba <validatetest+0x28>
}
     ecc:	70e2                	ld	ra,56(sp)
     ece:	7442                	ld	s0,48(sp)
     ed0:	74a2                	ld	s1,40(sp)
     ed2:	7902                	ld	s2,32(sp)
     ed4:	69e2                	ld	s3,24(sp)
     ed6:	6a42                	ld	s4,16(sp)
     ed8:	6aa2                	ld	s5,8(sp)
     eda:	6b02                	ld	s6,0(sp)
     edc:	6121                	addi	sp,sp,64
     ede:	8082                	ret
      printf("%s: link should not succeed\n", s);
     ee0:	85da                	mv	a1,s6
     ee2:	00005517          	auipc	a0,0x5
     ee6:	d5650513          	addi	a0,a0,-682 # 5c38 <thread_switch+0x7c2>
     eea:	26c040ef          	jal	5156 <printf>
      exit(1);
     eee:	4505                	li	a0,1
     ef0:	625030ef          	jal	4d14 <exit>

0000000000000ef4 <bigdir>:
{
     ef4:	711d                	addi	sp,sp,-96
     ef6:	ec86                	sd	ra,88(sp)
     ef8:	e8a2                	sd	s0,80(sp)
     efa:	e4a6                	sd	s1,72(sp)
     efc:	e0ca                	sd	s2,64(sp)
     efe:	fc4e                	sd	s3,56(sp)
     f00:	f852                	sd	s4,48(sp)
     f02:	f456                	sd	s5,40(sp)
     f04:	f05a                	sd	s6,32(sp)
     f06:	ec5e                	sd	s7,24(sp)
     f08:	1080                	addi	s0,sp,96
     f0a:	8baa                	mv	s7,a0
  unlink("bd");
     f0c:	00005517          	auipc	a0,0x5
     f10:	d4c50513          	addi	a0,a0,-692 # 5c58 <thread_switch+0x7e2>
     f14:	651030ef          	jal	4d64 <unlink>
  fd = open("bd", O_CREATE);
     f18:	20000593          	li	a1,512
     f1c:	00005517          	auipc	a0,0x5
     f20:	d3c50513          	addi	a0,a0,-708 # 5c58 <thread_switch+0x7e2>
     f24:	631030ef          	jal	4d54 <open>
  if(fd < 0){
     f28:	0c054463          	bltz	a0,ff0 <bigdir+0xfc>
  close(fd);
     f2c:	611030ef          	jal	4d3c <close>
  for(i = 0; i < N; i++){
     f30:	4901                	li	s2,0
    name[0] = 'x';
     f32:	07800a93          	li	s5,120
    if(link("bd", name) != 0){
     f36:	fa040a13          	addi	s4,s0,-96
     f3a:	00005997          	auipc	s3,0x5
     f3e:	d1e98993          	addi	s3,s3,-738 # 5c58 <thread_switch+0x7e2>
  for(i = 0; i < N; i++){
     f42:	1f400b13          	li	s6,500
    name[0] = 'x';
     f46:	fb540023          	sb	s5,-96(s0)
    name[1] = '0' + (i / 64);
     f4a:	41f9571b          	sraiw	a4,s2,0x1f
     f4e:	01a7571b          	srliw	a4,a4,0x1a
     f52:	012707bb          	addw	a5,a4,s2
     f56:	4067d69b          	sraiw	a3,a5,0x6
     f5a:	0306869b          	addiw	a3,a3,48
     f5e:	fad400a3          	sb	a3,-95(s0)
    name[2] = '0' + (i % 64);
     f62:	03f7f793          	andi	a5,a5,63
     f66:	9f99                	subw	a5,a5,a4
     f68:	0307879b          	addiw	a5,a5,48
     f6c:	faf40123          	sb	a5,-94(s0)
    name[3] = '\0';
     f70:	fa0401a3          	sb	zero,-93(s0)
    if(link("bd", name) != 0){
     f74:	85d2                	mv	a1,s4
     f76:	854e                	mv	a0,s3
     f78:	5fd030ef          	jal	4d74 <link>
     f7c:	84aa                	mv	s1,a0
     f7e:	e159                	bnez	a0,1004 <bigdir+0x110>
  for(i = 0; i < N; i++){
     f80:	2905                	addiw	s2,s2,1
     f82:	fd6912e3          	bne	s2,s6,f46 <bigdir+0x52>
  unlink("bd");
     f86:	00005517          	auipc	a0,0x5
     f8a:	cd250513          	addi	a0,a0,-814 # 5c58 <thread_switch+0x7e2>
     f8e:	5d7030ef          	jal	4d64 <unlink>
    name[0] = 'x';
     f92:	07800993          	li	s3,120
    if(unlink(name) != 0){
     f96:	fa040913          	addi	s2,s0,-96
  for(i = 0; i < N; i++){
     f9a:	1f400a13          	li	s4,500
    name[0] = 'x';
     f9e:	fb340023          	sb	s3,-96(s0)
    name[1] = '0' + (i / 64);
     fa2:	41f4d71b          	sraiw	a4,s1,0x1f
     fa6:	01a7571b          	srliw	a4,a4,0x1a
     faa:	009707bb          	addw	a5,a4,s1
     fae:	4067d69b          	sraiw	a3,a5,0x6
     fb2:	0306869b          	addiw	a3,a3,48
     fb6:	fad400a3          	sb	a3,-95(s0)
    name[2] = '0' + (i % 64);
     fba:	03f7f793          	andi	a5,a5,63
     fbe:	9f99                	subw	a5,a5,a4
     fc0:	0307879b          	addiw	a5,a5,48
     fc4:	faf40123          	sb	a5,-94(s0)
    name[3] = '\0';
     fc8:	fa0401a3          	sb	zero,-93(s0)
    if(unlink(name) != 0){
     fcc:	854a                	mv	a0,s2
     fce:	597030ef          	jal	4d64 <unlink>
     fd2:	e531                	bnez	a0,101e <bigdir+0x12a>
  for(i = 0; i < N; i++){
     fd4:	2485                	addiw	s1,s1,1
     fd6:	fd4494e3          	bne	s1,s4,f9e <bigdir+0xaa>
}
     fda:	60e6                	ld	ra,88(sp)
     fdc:	6446                	ld	s0,80(sp)
     fde:	64a6                	ld	s1,72(sp)
     fe0:	6906                	ld	s2,64(sp)
     fe2:	79e2                	ld	s3,56(sp)
     fe4:	7a42                	ld	s4,48(sp)
     fe6:	7aa2                	ld	s5,40(sp)
     fe8:	7b02                	ld	s6,32(sp)
     fea:	6be2                	ld	s7,24(sp)
     fec:	6125                	addi	sp,sp,96
     fee:	8082                	ret
    printf("%s: bigdir create failed\n", s);
     ff0:	85de                	mv	a1,s7
     ff2:	00005517          	auipc	a0,0x5
     ff6:	c6e50513          	addi	a0,a0,-914 # 5c60 <thread_switch+0x7ea>
     ffa:	15c040ef          	jal	5156 <printf>
    exit(1);
     ffe:	4505                	li	a0,1
    1000:	515030ef          	jal	4d14 <exit>
      printf("%s: bigdir i=%d link(bd, %s) failed\n", s, i, name);
    1004:	fa040693          	addi	a3,s0,-96
    1008:	864a                	mv	a2,s2
    100a:	85de                	mv	a1,s7
    100c:	00005517          	auipc	a0,0x5
    1010:	c7450513          	addi	a0,a0,-908 # 5c80 <thread_switch+0x80a>
    1014:	142040ef          	jal	5156 <printf>
      exit(1);
    1018:	4505                	li	a0,1
    101a:	4fb030ef          	jal	4d14 <exit>
      printf("%s: bigdir unlink failed", s);
    101e:	85de                	mv	a1,s7
    1020:	00005517          	auipc	a0,0x5
    1024:	c8850513          	addi	a0,a0,-888 # 5ca8 <thread_switch+0x832>
    1028:	12e040ef          	jal	5156 <printf>
      exit(1);
    102c:	4505                	li	a0,1
    102e:	4e7030ef          	jal	4d14 <exit>

0000000000001032 <pgbug>:
{
    1032:	7179                	addi	sp,sp,-48
    1034:	f406                	sd	ra,40(sp)
    1036:	f022                	sd	s0,32(sp)
    1038:	ec26                	sd	s1,24(sp)
    103a:	1800                	addi	s0,sp,48
  argv[0] = 0;
    103c:	fc043c23          	sd	zero,-40(s0)
  exec(big, argv);
    1040:	00007497          	auipc	s1,0x7
    1044:	fc048493          	addi	s1,s1,-64 # 8000 <big>
    1048:	fd840593          	addi	a1,s0,-40
    104c:	6088                	ld	a0,0(s1)
    104e:	4ff030ef          	jal	4d4c <exec>
  pipe(big);
    1052:	6088                	ld	a0,0(s1)
    1054:	4d1030ef          	jal	4d24 <pipe>
  exit(0);
    1058:	4501                	li	a0,0
    105a:	4bb030ef          	jal	4d14 <exit>

000000000000105e <badarg>:
{
    105e:	7139                	addi	sp,sp,-64
    1060:	fc06                	sd	ra,56(sp)
    1062:	f822                	sd	s0,48(sp)
    1064:	f426                	sd	s1,40(sp)
    1066:	f04a                	sd	s2,32(sp)
    1068:	ec4e                	sd	s3,24(sp)
    106a:	e852                	sd	s4,16(sp)
    106c:	0080                	addi	s0,sp,64
    106e:	64b1                	lui	s1,0xc
    1070:	35048493          	addi	s1,s1,848 # c350 <buf+0x6d8>
    argv[0] = (char*)0xffffffff;
    1074:	597d                	li	s2,-1
    1076:	02095913          	srli	s2,s2,0x20
    exec("echo", argv);
    107a:	fc040a13          	addi	s4,s0,-64
    107e:	00004997          	auipc	s3,0x4
    1082:	49a98993          	addi	s3,s3,1178 # 5518 <thread_switch+0xa2>
    argv[0] = (char*)0xffffffff;
    1086:	fd243023          	sd	s2,-64(s0)
    argv[1] = 0;
    108a:	fc043423          	sd	zero,-56(s0)
    exec("echo", argv);
    108e:	85d2                	mv	a1,s4
    1090:	854e                	mv	a0,s3
    1092:	4bb030ef          	jal	4d4c <exec>
  for(int i = 0; i < 50000; i++){
    1096:	34fd                	addiw	s1,s1,-1
    1098:	f4fd                	bnez	s1,1086 <badarg+0x28>
  exit(0);
    109a:	4501                	li	a0,0
    109c:	479030ef          	jal	4d14 <exit>

00000000000010a0 <copyinstr2>:
{
    10a0:	7155                	addi	sp,sp,-208
    10a2:	e586                	sd	ra,200(sp)
    10a4:	e1a2                	sd	s0,192(sp)
    10a6:	0980                	addi	s0,sp,208
  for(int i = 0; i < MAXPATH; i++)
    10a8:	f6840793          	addi	a5,s0,-152
    10ac:	fe840693          	addi	a3,s0,-24
    b[i] = 'x';
    10b0:	07800713          	li	a4,120
    10b4:	00e78023          	sb	a4,0(a5)
  for(int i = 0; i < MAXPATH; i++)
    10b8:	0785                	addi	a5,a5,1
    10ba:	fed79de3          	bne	a5,a3,10b4 <copyinstr2+0x14>
  b[MAXPATH] = '\0';
    10be:	fe040423          	sb	zero,-24(s0)
  int ret = unlink(b);
    10c2:	f6840513          	addi	a0,s0,-152
    10c6:	49f030ef          	jal	4d64 <unlink>
  if(ret != -1){
    10ca:	57fd                	li	a5,-1
    10cc:	0cf51263          	bne	a0,a5,1190 <copyinstr2+0xf0>
  int fd = open(b, O_CREATE | O_WRONLY);
    10d0:	20100593          	li	a1,513
    10d4:	f6840513          	addi	a0,s0,-152
    10d8:	47d030ef          	jal	4d54 <open>
  if(fd != -1){
    10dc:	57fd                	li	a5,-1
    10de:	0cf51563          	bne	a0,a5,11a8 <copyinstr2+0x108>
  ret = link(b, b);
    10e2:	f6840513          	addi	a0,s0,-152
    10e6:	85aa                	mv	a1,a0
    10e8:	48d030ef          	jal	4d74 <link>
  if(ret != -1){
    10ec:	57fd                	li	a5,-1
    10ee:	0cf51963          	bne	a0,a5,11c0 <copyinstr2+0x120>
  char *args[] = { "xx", 0 };
    10f2:	00006797          	auipc	a5,0x6
    10f6:	d0678793          	addi	a5,a5,-762 # 6df8 <thread_switch+0x1982>
    10fa:	f4f43c23          	sd	a5,-168(s0)
    10fe:	f6043023          	sd	zero,-160(s0)
  ret = exec(b, args);
    1102:	f5840593          	addi	a1,s0,-168
    1106:	f6840513          	addi	a0,s0,-152
    110a:	443030ef          	jal	4d4c <exec>
  if(ret != -1){
    110e:	57fd                	li	a5,-1
    1110:	0cf51563          	bne	a0,a5,11da <copyinstr2+0x13a>
  int pid = fork();
    1114:	3f9030ef          	jal	4d0c <fork>
  if(pid < 0){
    1118:	0c054d63          	bltz	a0,11f2 <copyinstr2+0x152>
  if(pid == 0){
    111c:	0e051863          	bnez	a0,120c <copyinstr2+0x16c>
    1120:	00007797          	auipc	a5,0x7
    1124:	44078793          	addi	a5,a5,1088 # 8560 <big.0>
    1128:	00008697          	auipc	a3,0x8
    112c:	43868693          	addi	a3,a3,1080 # 9560 <big.0+0x1000>
      big[i] = 'x';
    1130:	07800713          	li	a4,120
    1134:	00e78023          	sb	a4,0(a5)
    for(int i = 0; i < PGSIZE; i++)
    1138:	0785                	addi	a5,a5,1
    113a:	fed79de3          	bne	a5,a3,1134 <copyinstr2+0x94>
    big[PGSIZE] = '\0';
    113e:	00008797          	auipc	a5,0x8
    1142:	42078123          	sb	zero,1058(a5) # 9560 <big.0+0x1000>
    char *args2[] = { big, big, big, 0 };
    1146:	00006797          	auipc	a5,0x6
    114a:	76a78793          	addi	a5,a5,1898 # 78b0 <thread_switch+0x243a>
    114e:	6fb0                	ld	a2,88(a5)
    1150:	73b4                	ld	a3,96(a5)
    1152:	77b8                	ld	a4,104(a5)
    1154:	f2c43823          	sd	a2,-208(s0)
    1158:	f2d43c23          	sd	a3,-200(s0)
    115c:	f4e43023          	sd	a4,-192(s0)
    1160:	7bbc                	ld	a5,112(a5)
    1162:	f4f43423          	sd	a5,-184(s0)
    ret = exec("echo", args2);
    1166:	f3040593          	addi	a1,s0,-208
    116a:	00004517          	auipc	a0,0x4
    116e:	3ae50513          	addi	a0,a0,942 # 5518 <thread_switch+0xa2>
    1172:	3db030ef          	jal	4d4c <exec>
    if(ret != -1){
    1176:	57fd                	li	a5,-1
    1178:	08f50663          	beq	a0,a5,1204 <copyinstr2+0x164>
      printf("exec(echo, BIG) returned %d, not -1\n", fd);
    117c:	85be                	mv	a1,a5
    117e:	00005517          	auipc	a0,0x5
    1182:	bd250513          	addi	a0,a0,-1070 # 5d50 <thread_switch+0x8da>
    1186:	7d1030ef          	jal	5156 <printf>
      exit(1);
    118a:	4505                	li	a0,1
    118c:	389030ef          	jal	4d14 <exit>
    printf("unlink(%s) returned %d, not -1\n", b, ret);
    1190:	862a                	mv	a2,a0
    1192:	f6840593          	addi	a1,s0,-152
    1196:	00005517          	auipc	a0,0x5
    119a:	b3250513          	addi	a0,a0,-1230 # 5cc8 <thread_switch+0x852>
    119e:	7b9030ef          	jal	5156 <printf>
    exit(1);
    11a2:	4505                	li	a0,1
    11a4:	371030ef          	jal	4d14 <exit>
    printf("open(%s) returned %d, not -1\n", b, fd);
    11a8:	862a                	mv	a2,a0
    11aa:	f6840593          	addi	a1,s0,-152
    11ae:	00005517          	auipc	a0,0x5
    11b2:	b3a50513          	addi	a0,a0,-1222 # 5ce8 <thread_switch+0x872>
    11b6:	7a1030ef          	jal	5156 <printf>
    exit(1);
    11ba:	4505                	li	a0,1
    11bc:	359030ef          	jal	4d14 <exit>
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
    11c0:	f6840593          	addi	a1,s0,-152
    11c4:	86aa                	mv	a3,a0
    11c6:	862e                	mv	a2,a1
    11c8:	00005517          	auipc	a0,0x5
    11cc:	b4050513          	addi	a0,a0,-1216 # 5d08 <thread_switch+0x892>
    11d0:	787030ef          	jal	5156 <printf>
    exit(1);
    11d4:	4505                	li	a0,1
    11d6:	33f030ef          	jal	4d14 <exit>
    printf("exec(%s) returned %d, not -1\n", b, fd);
    11da:	863e                	mv	a2,a5
    11dc:	f6840593          	addi	a1,s0,-152
    11e0:	00005517          	auipc	a0,0x5
    11e4:	b5050513          	addi	a0,a0,-1200 # 5d30 <thread_switch+0x8ba>
    11e8:	76f030ef          	jal	5156 <printf>
    exit(1);
    11ec:	4505                	li	a0,1
    11ee:	327030ef          	jal	4d14 <exit>
    printf("fork failed\n");
    11f2:	00006517          	auipc	a0,0x6
    11f6:	12650513          	addi	a0,a0,294 # 7318 <thread_switch+0x1ea2>
    11fa:	75d030ef          	jal	5156 <printf>
    exit(1);
    11fe:	4505                	li	a0,1
    1200:	315030ef          	jal	4d14 <exit>
    exit(747); // OK
    1204:	2eb00513          	li	a0,747
    1208:	30d030ef          	jal	4d14 <exit>
  int st = 0;
    120c:	f4042a23          	sw	zero,-172(s0)
  wait(&st);
    1210:	f5440513          	addi	a0,s0,-172
    1214:	309030ef          	jal	4d1c <wait>
  if(st != 747){
    1218:	f5442703          	lw	a4,-172(s0)
    121c:	2eb00793          	li	a5,747
    1220:	00f71663          	bne	a4,a5,122c <copyinstr2+0x18c>
}
    1224:	60ae                	ld	ra,200(sp)
    1226:	640e                	ld	s0,192(sp)
    1228:	6169                	addi	sp,sp,208
    122a:	8082                	ret
    printf("exec(echo, BIG) succeeded, should have failed\n");
    122c:	00005517          	auipc	a0,0x5
    1230:	b4c50513          	addi	a0,a0,-1204 # 5d78 <thread_switch+0x902>
    1234:	723030ef          	jal	5156 <printf>
    exit(1);
    1238:	4505                	li	a0,1
    123a:	2db030ef          	jal	4d14 <exit>

000000000000123e <truncate3>:
{
    123e:	7175                	addi	sp,sp,-144
    1240:	e506                	sd	ra,136(sp)
    1242:	e122                	sd	s0,128(sp)
    1244:	fc66                	sd	s9,56(sp)
    1246:	0900                	addi	s0,sp,144
    1248:	8caa                	mv	s9,a0
  close(open("truncfile", O_CREATE|O_TRUNC|O_WRONLY));
    124a:	60100593          	li	a1,1537
    124e:	00004517          	auipc	a0,0x4
    1252:	32250513          	addi	a0,a0,802 # 5570 <thread_switch+0xfa>
    1256:	2ff030ef          	jal	4d54 <open>
    125a:	2e3030ef          	jal	4d3c <close>
  pid = fork();
    125e:	2af030ef          	jal	4d0c <fork>
  if(pid < 0){
    1262:	06054d63          	bltz	a0,12dc <truncate3+0x9e>
  if(pid == 0){
    1266:	e171                	bnez	a0,132a <truncate3+0xec>
    1268:	fca6                	sd	s1,120(sp)
    126a:	f8ca                	sd	s2,112(sp)
    126c:	f4ce                	sd	s3,104(sp)
    126e:	f0d2                	sd	s4,96(sp)
    1270:	ecd6                	sd	s5,88(sp)
    1272:	e8da                	sd	s6,80(sp)
    1274:	e4de                	sd	s7,72(sp)
    1276:	e0e2                	sd	s8,64(sp)
    1278:	06400913          	li	s2,100
      int fd = open("truncfile", O_WRONLY);
    127c:	4a85                	li	s5,1
    127e:	00004997          	auipc	s3,0x4
    1282:	2f298993          	addi	s3,s3,754 # 5570 <thread_switch+0xfa>
      int n = write(fd, "1234567890", 10);
    1286:	4a29                	li	s4,10
    1288:	00005b17          	auipc	s6,0x5
    128c:	b50b0b13          	addi	s6,s6,-1200 # 5dd8 <thread_switch+0x962>
      read(fd, buf, sizeof(buf));
    1290:	f7840c13          	addi	s8,s0,-136
    1294:	02000b93          	li	s7,32
      int fd = open("truncfile", O_WRONLY);
    1298:	85d6                	mv	a1,s5
    129a:	854e                	mv	a0,s3
    129c:	2b9030ef          	jal	4d54 <open>
    12a0:	84aa                	mv	s1,a0
      if(fd < 0){
    12a2:	04054f63          	bltz	a0,1300 <truncate3+0xc2>
      int n = write(fd, "1234567890", 10);
    12a6:	8652                	mv	a2,s4
    12a8:	85da                	mv	a1,s6
    12aa:	28b030ef          	jal	4d34 <write>
      if(n != 10){
    12ae:	07451363          	bne	a0,s4,1314 <truncate3+0xd6>
      close(fd);
    12b2:	8526                	mv	a0,s1
    12b4:	289030ef          	jal	4d3c <close>
      fd = open("truncfile", O_RDONLY);
    12b8:	4581                	li	a1,0
    12ba:	854e                	mv	a0,s3
    12bc:	299030ef          	jal	4d54 <open>
    12c0:	84aa                	mv	s1,a0
      read(fd, buf, sizeof(buf));
    12c2:	865e                	mv	a2,s7
    12c4:	85e2                	mv	a1,s8
    12c6:	267030ef          	jal	4d2c <read>
      close(fd);
    12ca:	8526                	mv	a0,s1
    12cc:	271030ef          	jal	4d3c <close>
    for(int i = 0; i < 100; i++){
    12d0:	397d                	addiw	s2,s2,-1
    12d2:	fc0913e3          	bnez	s2,1298 <truncate3+0x5a>
    exit(0);
    12d6:	4501                	li	a0,0
    12d8:	23d030ef          	jal	4d14 <exit>
    12dc:	fca6                	sd	s1,120(sp)
    12de:	f8ca                	sd	s2,112(sp)
    12e0:	f4ce                	sd	s3,104(sp)
    12e2:	f0d2                	sd	s4,96(sp)
    12e4:	ecd6                	sd	s5,88(sp)
    12e6:	e8da                	sd	s6,80(sp)
    12e8:	e4de                	sd	s7,72(sp)
    12ea:	e0e2                	sd	s8,64(sp)
    printf("%s: fork failed\n", s);
    12ec:	85e6                	mv	a1,s9
    12ee:	00005517          	auipc	a0,0x5
    12f2:	aba50513          	addi	a0,a0,-1350 # 5da8 <thread_switch+0x932>
    12f6:	661030ef          	jal	5156 <printf>
    exit(1);
    12fa:	4505                	li	a0,1
    12fc:	219030ef          	jal	4d14 <exit>
        printf("%s: open failed\n", s);
    1300:	85e6                	mv	a1,s9
    1302:	00005517          	auipc	a0,0x5
    1306:	abe50513          	addi	a0,a0,-1346 # 5dc0 <thread_switch+0x94a>
    130a:	64d030ef          	jal	5156 <printf>
        exit(1);
    130e:	4505                	li	a0,1
    1310:	205030ef          	jal	4d14 <exit>
        printf("%s: write got %d, expected 10\n", s, n);
    1314:	862a                	mv	a2,a0
    1316:	85e6                	mv	a1,s9
    1318:	00005517          	auipc	a0,0x5
    131c:	ad050513          	addi	a0,a0,-1328 # 5de8 <thread_switch+0x972>
    1320:	637030ef          	jal	5156 <printf>
        exit(1);
    1324:	4505                	li	a0,1
    1326:	1ef030ef          	jal	4d14 <exit>
    132a:	fca6                	sd	s1,120(sp)
    132c:	f8ca                	sd	s2,112(sp)
    132e:	f4ce                	sd	s3,104(sp)
    1330:	f0d2                	sd	s4,96(sp)
    1332:	ecd6                	sd	s5,88(sp)
    1334:	e8da                	sd	s6,80(sp)
  if(pid == 0){
    1336:	09600913          	li	s2,150
    int fd = open("truncfile", O_CREATE|O_WRONLY|O_TRUNC);
    133a:	60100a93          	li	s5,1537
    133e:	00004a17          	auipc	s4,0x4
    1342:	232a0a13          	addi	s4,s4,562 # 5570 <thread_switch+0xfa>
    int n = write(fd, "xxx", 3);
    1346:	498d                	li	s3,3
    1348:	00005b17          	auipc	s6,0x5
    134c:	ac0b0b13          	addi	s6,s6,-1344 # 5e08 <thread_switch+0x992>
    int fd = open("truncfile", O_CREATE|O_WRONLY|O_TRUNC);
    1350:	85d6                	mv	a1,s5
    1352:	8552                	mv	a0,s4
    1354:	201030ef          	jal	4d54 <open>
    1358:	84aa                	mv	s1,a0
    if(fd < 0){
    135a:	02054e63          	bltz	a0,1396 <truncate3+0x158>
    int n = write(fd, "xxx", 3);
    135e:	864e                	mv	a2,s3
    1360:	85da                	mv	a1,s6
    1362:	1d3030ef          	jal	4d34 <write>
    if(n != 3){
    1366:	05351463          	bne	a0,s3,13ae <truncate3+0x170>
    close(fd);
    136a:	8526                	mv	a0,s1
    136c:	1d1030ef          	jal	4d3c <close>
  for(int i = 0; i < 150; i++){
    1370:	397d                	addiw	s2,s2,-1
    1372:	fc091fe3          	bnez	s2,1350 <truncate3+0x112>
    1376:	e4de                	sd	s7,72(sp)
    1378:	e0e2                	sd	s8,64(sp)
  wait(&xstatus);
    137a:	f9c40513          	addi	a0,s0,-100
    137e:	19f030ef          	jal	4d1c <wait>
  unlink("truncfile");
    1382:	00004517          	auipc	a0,0x4
    1386:	1ee50513          	addi	a0,a0,494 # 5570 <thread_switch+0xfa>
    138a:	1db030ef          	jal	4d64 <unlink>
  exit(xstatus);
    138e:	f9c42503          	lw	a0,-100(s0)
    1392:	183030ef          	jal	4d14 <exit>
    1396:	e4de                	sd	s7,72(sp)
    1398:	e0e2                	sd	s8,64(sp)
      printf("%s: open failed\n", s);
    139a:	85e6                	mv	a1,s9
    139c:	00005517          	auipc	a0,0x5
    13a0:	a2450513          	addi	a0,a0,-1500 # 5dc0 <thread_switch+0x94a>
    13a4:	5b3030ef          	jal	5156 <printf>
      exit(1);
    13a8:	4505                	li	a0,1
    13aa:	16b030ef          	jal	4d14 <exit>
    13ae:	e4de                	sd	s7,72(sp)
    13b0:	e0e2                	sd	s8,64(sp)
      printf("%s: write got %d, expected 3\n", s, n);
    13b2:	862a                	mv	a2,a0
    13b4:	85e6                	mv	a1,s9
    13b6:	00005517          	auipc	a0,0x5
    13ba:	a5a50513          	addi	a0,a0,-1446 # 5e10 <thread_switch+0x99a>
    13be:	599030ef          	jal	5156 <printf>
      exit(1);
    13c2:	4505                	li	a0,1
    13c4:	151030ef          	jal	4d14 <exit>

00000000000013c8 <exectest>:
{
    13c8:	715d                	addi	sp,sp,-80
    13ca:	e486                	sd	ra,72(sp)
    13cc:	e0a2                	sd	s0,64(sp)
    13ce:	f84a                	sd	s2,48(sp)
    13d0:	0880                	addi	s0,sp,80
    13d2:	892a                	mv	s2,a0
  char *echoargv[] = { "echo", "OK", 0 };
    13d4:	00004797          	auipc	a5,0x4
    13d8:	14478793          	addi	a5,a5,324 # 5518 <thread_switch+0xa2>
    13dc:	fcf43023          	sd	a5,-64(s0)
    13e0:	00005797          	auipc	a5,0x5
    13e4:	a5078793          	addi	a5,a5,-1456 # 5e30 <thread_switch+0x9ba>
    13e8:	fcf43423          	sd	a5,-56(s0)
    13ec:	fc043823          	sd	zero,-48(s0)
  unlink("echo-ok");
    13f0:	00005517          	auipc	a0,0x5
    13f4:	a4850513          	addi	a0,a0,-1464 # 5e38 <thread_switch+0x9c2>
    13f8:	16d030ef          	jal	4d64 <unlink>
  pid = fork();
    13fc:	111030ef          	jal	4d0c <fork>
  if(pid < 0) {
    1400:	02054f63          	bltz	a0,143e <exectest+0x76>
    1404:	fc26                	sd	s1,56(sp)
    1406:	84aa                	mv	s1,a0
  if(pid == 0) {
    1408:	e935                	bnez	a0,147c <exectest+0xb4>
    close(1);
    140a:	4505                	li	a0,1
    140c:	131030ef          	jal	4d3c <close>
    fd = open("echo-ok", O_CREATE|O_WRONLY);
    1410:	20100593          	li	a1,513
    1414:	00005517          	auipc	a0,0x5
    1418:	a2450513          	addi	a0,a0,-1500 # 5e38 <thread_switch+0x9c2>
    141c:	139030ef          	jal	4d54 <open>
    if(fd < 0) {
    1420:	02054a63          	bltz	a0,1454 <exectest+0x8c>
    if(fd != 1) {
    1424:	4785                	li	a5,1
    1426:	04f50163          	beq	a0,a5,1468 <exectest+0xa0>
      printf("%s: wrong fd\n", s);
    142a:	85ca                	mv	a1,s2
    142c:	00005517          	auipc	a0,0x5
    1430:	a2c50513          	addi	a0,a0,-1492 # 5e58 <thread_switch+0x9e2>
    1434:	523030ef          	jal	5156 <printf>
      exit(1);
    1438:	4505                	li	a0,1
    143a:	0db030ef          	jal	4d14 <exit>
    143e:	fc26                	sd	s1,56(sp)
     printf("%s: fork failed\n", s);
    1440:	85ca                	mv	a1,s2
    1442:	00005517          	auipc	a0,0x5
    1446:	96650513          	addi	a0,a0,-1690 # 5da8 <thread_switch+0x932>
    144a:	50d030ef          	jal	5156 <printf>
     exit(1);
    144e:	4505                	li	a0,1
    1450:	0c5030ef          	jal	4d14 <exit>
      printf("%s: create failed\n", s);
    1454:	85ca                	mv	a1,s2
    1456:	00005517          	auipc	a0,0x5
    145a:	9ea50513          	addi	a0,a0,-1558 # 5e40 <thread_switch+0x9ca>
    145e:	4f9030ef          	jal	5156 <printf>
      exit(1);
    1462:	4505                	li	a0,1
    1464:	0b1030ef          	jal	4d14 <exit>
    if(exec("echo", echoargv) < 0){
    1468:	fc040593          	addi	a1,s0,-64
    146c:	00004517          	auipc	a0,0x4
    1470:	0ac50513          	addi	a0,a0,172 # 5518 <thread_switch+0xa2>
    1474:	0d9030ef          	jal	4d4c <exec>
    1478:	00054d63          	bltz	a0,1492 <exectest+0xca>
  if (wait(&xstatus) != pid) {
    147c:	fdc40513          	addi	a0,s0,-36
    1480:	09d030ef          	jal	4d1c <wait>
    1484:	02951163          	bne	a0,s1,14a6 <exectest+0xde>
  if(xstatus != 0)
    1488:	fdc42503          	lw	a0,-36(s0)
    148c:	c50d                	beqz	a0,14b6 <exectest+0xee>
    exit(xstatus);
    148e:	087030ef          	jal	4d14 <exit>
      printf("%s: exec echo failed\n", s);
    1492:	85ca                	mv	a1,s2
    1494:	00005517          	auipc	a0,0x5
    1498:	9d450513          	addi	a0,a0,-1580 # 5e68 <thread_switch+0x9f2>
    149c:	4bb030ef          	jal	5156 <printf>
      exit(1);
    14a0:	4505                	li	a0,1
    14a2:	073030ef          	jal	4d14 <exit>
    printf("%s: wait failed!\n", s);
    14a6:	85ca                	mv	a1,s2
    14a8:	00005517          	auipc	a0,0x5
    14ac:	9d850513          	addi	a0,a0,-1576 # 5e80 <thread_switch+0xa0a>
    14b0:	4a7030ef          	jal	5156 <printf>
    14b4:	bfd1                	j	1488 <exectest+0xc0>
  fd = open("echo-ok", O_RDONLY);
    14b6:	4581                	li	a1,0
    14b8:	00005517          	auipc	a0,0x5
    14bc:	98050513          	addi	a0,a0,-1664 # 5e38 <thread_switch+0x9c2>
    14c0:	095030ef          	jal	4d54 <open>
  if(fd < 0) {
    14c4:	02054463          	bltz	a0,14ec <exectest+0x124>
  if (read(fd, buf, 2) != 2) {
    14c8:	4609                	li	a2,2
    14ca:	fb840593          	addi	a1,s0,-72
    14ce:	05f030ef          	jal	4d2c <read>
    14d2:	4789                	li	a5,2
    14d4:	02f50663          	beq	a0,a5,1500 <exectest+0x138>
    printf("%s: read failed\n", s);
    14d8:	85ca                	mv	a1,s2
    14da:	00004517          	auipc	a0,0x4
    14de:	40e50513          	addi	a0,a0,1038 # 58e8 <thread_switch+0x472>
    14e2:	475030ef          	jal	5156 <printf>
    exit(1);
    14e6:	4505                	li	a0,1
    14e8:	02d030ef          	jal	4d14 <exit>
    printf("%s: open failed\n", s);
    14ec:	85ca                	mv	a1,s2
    14ee:	00005517          	auipc	a0,0x5
    14f2:	8d250513          	addi	a0,a0,-1838 # 5dc0 <thread_switch+0x94a>
    14f6:	461030ef          	jal	5156 <printf>
    exit(1);
    14fa:	4505                	li	a0,1
    14fc:	019030ef          	jal	4d14 <exit>
  unlink("echo-ok");
    1500:	00005517          	auipc	a0,0x5
    1504:	93850513          	addi	a0,a0,-1736 # 5e38 <thread_switch+0x9c2>
    1508:	05d030ef          	jal	4d64 <unlink>
  if(buf[0] == 'O' && buf[1] == 'K')
    150c:	fb844703          	lbu	a4,-72(s0)
    1510:	04f00793          	li	a5,79
    1514:	00f71863          	bne	a4,a5,1524 <exectest+0x15c>
    1518:	fb944703          	lbu	a4,-71(s0)
    151c:	04b00793          	li	a5,75
    1520:	00f70c63          	beq	a4,a5,1538 <exectest+0x170>
    printf("%s: wrong output\n", s);
    1524:	85ca                	mv	a1,s2
    1526:	00005517          	auipc	a0,0x5
    152a:	97250513          	addi	a0,a0,-1678 # 5e98 <thread_switch+0xa22>
    152e:	429030ef          	jal	5156 <printf>
    exit(1);
    1532:	4505                	li	a0,1
    1534:	7e0030ef          	jal	4d14 <exit>
    exit(0);
    1538:	4501                	li	a0,0
    153a:	7da030ef          	jal	4d14 <exit>

000000000000153e <pipe1>:
{
    153e:	711d                	addi	sp,sp,-96
    1540:	ec86                	sd	ra,88(sp)
    1542:	e8a2                	sd	s0,80(sp)
    1544:	e862                	sd	s8,16(sp)
    1546:	1080                	addi	s0,sp,96
    1548:	8c2a                	mv	s8,a0
  if(pipe(fds) != 0){
    154a:	fa840513          	addi	a0,s0,-88
    154e:	7d6030ef          	jal	4d24 <pipe>
    1552:	e925                	bnez	a0,15c2 <pipe1+0x84>
    1554:	e4a6                	sd	s1,72(sp)
    1556:	fc4e                	sd	s3,56(sp)
    1558:	84aa                	mv	s1,a0
  pid = fork();
    155a:	7b2030ef          	jal	4d0c <fork>
    155e:	89aa                	mv	s3,a0
  if(pid == 0){
    1560:	c151                	beqz	a0,15e4 <pipe1+0xa6>
  } else if(pid > 0){
    1562:	16a05063          	blez	a0,16c2 <pipe1+0x184>
    1566:	e0ca                	sd	s2,64(sp)
    1568:	f852                	sd	s4,48(sp)
    close(fds[1]);
    156a:	fac42503          	lw	a0,-84(s0)
    156e:	7ce030ef          	jal	4d3c <close>
    total = 0;
    1572:	89a6                	mv	s3,s1
    cc = 1;
    1574:	4905                	li	s2,1
    while((n = read(fds[0], buf, cc)) > 0){
    1576:	0000aa17          	auipc	s4,0xa
    157a:	702a0a13          	addi	s4,s4,1794 # bc78 <buf>
    157e:	864a                	mv	a2,s2
    1580:	85d2                	mv	a1,s4
    1582:	fa842503          	lw	a0,-88(s0)
    1586:	7a6030ef          	jal	4d2c <read>
    158a:	85aa                	mv	a1,a0
    158c:	0ea05963          	blez	a0,167e <pipe1+0x140>
    1590:	0000a797          	auipc	a5,0xa
    1594:	6e878793          	addi	a5,a5,1768 # bc78 <buf>
    1598:	00b4863b          	addw	a2,s1,a1
        if((buf[i] & 0xff) != (seq++ & 0xff)){
    159c:	0007c683          	lbu	a3,0(a5)
    15a0:	0ff4f713          	zext.b	a4,s1
    15a4:	0ae69d63          	bne	a3,a4,165e <pipe1+0x120>
    15a8:	2485                	addiw	s1,s1,1
      for(i = 0; i < n; i++){
    15aa:	0785                	addi	a5,a5,1
    15ac:	fec498e3          	bne	s1,a2,159c <pipe1+0x5e>
      total += n;
    15b0:	00b989bb          	addw	s3,s3,a1
      cc = cc * 2;
    15b4:	0019191b          	slliw	s2,s2,0x1
      if(cc > sizeof(buf))
    15b8:	678d                	lui	a5,0x3
    15ba:	fd27f2e3          	bgeu	a5,s2,157e <pipe1+0x40>
        cc = sizeof(buf);
    15be:	893e                	mv	s2,a5
    15c0:	bf7d                	j	157e <pipe1+0x40>
    15c2:	e4a6                	sd	s1,72(sp)
    15c4:	e0ca                	sd	s2,64(sp)
    15c6:	fc4e                	sd	s3,56(sp)
    15c8:	f852                	sd	s4,48(sp)
    15ca:	f456                	sd	s5,40(sp)
    15cc:	f05a                	sd	s6,32(sp)
    15ce:	ec5e                	sd	s7,24(sp)
    printf("%s: pipe() failed\n", s);
    15d0:	85e2                	mv	a1,s8
    15d2:	00005517          	auipc	a0,0x5
    15d6:	8de50513          	addi	a0,a0,-1826 # 5eb0 <thread_switch+0xa3a>
    15da:	37d030ef          	jal	5156 <printf>
    exit(1);
    15de:	4505                	li	a0,1
    15e0:	734030ef          	jal	4d14 <exit>
    15e4:	e0ca                	sd	s2,64(sp)
    15e6:	f852                	sd	s4,48(sp)
    15e8:	f456                	sd	s5,40(sp)
    15ea:	f05a                	sd	s6,32(sp)
    15ec:	ec5e                	sd	s7,24(sp)
    close(fds[0]);
    15ee:	fa842503          	lw	a0,-88(s0)
    15f2:	74a030ef          	jal	4d3c <close>
    for(n = 0; n < N; n++){
    15f6:	0000ab17          	auipc	s6,0xa
    15fa:	682b0b13          	addi	s6,s6,1666 # bc78 <buf>
    15fe:	416004bb          	negw	s1,s6
    1602:	0ff4f493          	zext.b	s1,s1
    1606:	409b0913          	addi	s2,s6,1033
      if(write(fds[1], buf, SZ) != SZ){
    160a:	40900a13          	li	s4,1033
    160e:	8bda                	mv	s7,s6
    for(n = 0; n < N; n++){
    1610:	6a85                	lui	s5,0x1
    1612:	42da8a93          	addi	s5,s5,1069 # 142d <exectest+0x65>
{
    1616:	87da                	mv	a5,s6
        buf[i] = seq++;
    1618:	0097873b          	addw	a4,a5,s1
    161c:	00e78023          	sb	a4,0(a5) # 3000 <subdir+0x2ea>
      for(i = 0; i < SZ; i++)
    1620:	0785                	addi	a5,a5,1
    1622:	ff279be3          	bne	a5,s2,1618 <pipe1+0xda>
      if(write(fds[1], buf, SZ) != SZ){
    1626:	8652                	mv	a2,s4
    1628:	85de                	mv	a1,s7
    162a:	fac42503          	lw	a0,-84(s0)
    162e:	706030ef          	jal	4d34 <write>
    1632:	01451c63          	bne	a0,s4,164a <pipe1+0x10c>
    1636:	4099899b          	addiw	s3,s3,1033
    for(n = 0; n < N; n++){
    163a:	24a5                	addiw	s1,s1,9
    163c:	0ff4f493          	zext.b	s1,s1
    1640:	fd599be3          	bne	s3,s5,1616 <pipe1+0xd8>
    exit(0);
    1644:	4501                	li	a0,0
    1646:	6ce030ef          	jal	4d14 <exit>
        printf("%s: pipe1 oops 1\n", s);
    164a:	85e2                	mv	a1,s8
    164c:	00005517          	auipc	a0,0x5
    1650:	87c50513          	addi	a0,a0,-1924 # 5ec8 <thread_switch+0xa52>
    1654:	303030ef          	jal	5156 <printf>
        exit(1);
    1658:	4505                	li	a0,1
    165a:	6ba030ef          	jal	4d14 <exit>
          printf("%s: pipe1 oops 2\n", s);
    165e:	85e2                	mv	a1,s8
    1660:	00005517          	auipc	a0,0x5
    1664:	88050513          	addi	a0,a0,-1920 # 5ee0 <thread_switch+0xa6a>
    1668:	2ef030ef          	jal	5156 <printf>
          return;
    166c:	64a6                	ld	s1,72(sp)
    166e:	6906                	ld	s2,64(sp)
    1670:	79e2                	ld	s3,56(sp)
    1672:	7a42                	ld	s4,48(sp)
}
    1674:	60e6                	ld	ra,88(sp)
    1676:	6446                	ld	s0,80(sp)
    1678:	6c42                	ld	s8,16(sp)
    167a:	6125                	addi	sp,sp,96
    167c:	8082                	ret
    if(total != N * SZ){
    167e:	6785                	lui	a5,0x1
    1680:	42d78793          	addi	a5,a5,1069 # 142d <exectest+0x65>
    1684:	02f98063          	beq	s3,a5,16a4 <pipe1+0x166>
    1688:	f456                	sd	s5,40(sp)
    168a:	f05a                	sd	s6,32(sp)
    168c:	ec5e                	sd	s7,24(sp)
      printf("%s: pipe1 oops 3 total %d\n", s, total);
    168e:	864e                	mv	a2,s3
    1690:	85e2                	mv	a1,s8
    1692:	00005517          	auipc	a0,0x5
    1696:	86650513          	addi	a0,a0,-1946 # 5ef8 <thread_switch+0xa82>
    169a:	2bd030ef          	jal	5156 <printf>
      exit(1);
    169e:	4505                	li	a0,1
    16a0:	674030ef          	jal	4d14 <exit>
    16a4:	f456                	sd	s5,40(sp)
    16a6:	f05a                	sd	s6,32(sp)
    16a8:	ec5e                	sd	s7,24(sp)
    close(fds[0]);
    16aa:	fa842503          	lw	a0,-88(s0)
    16ae:	68e030ef          	jal	4d3c <close>
    wait(&xstatus);
    16b2:	fa440513          	addi	a0,s0,-92
    16b6:	666030ef          	jal	4d1c <wait>
    exit(xstatus);
    16ba:	fa442503          	lw	a0,-92(s0)
    16be:	656030ef          	jal	4d14 <exit>
    16c2:	e0ca                	sd	s2,64(sp)
    16c4:	f852                	sd	s4,48(sp)
    16c6:	f456                	sd	s5,40(sp)
    16c8:	f05a                	sd	s6,32(sp)
    16ca:	ec5e                	sd	s7,24(sp)
    printf("%s: fork() failed\n", s);
    16cc:	85e2                	mv	a1,s8
    16ce:	00005517          	auipc	a0,0x5
    16d2:	84a50513          	addi	a0,a0,-1974 # 5f18 <thread_switch+0xaa2>
    16d6:	281030ef          	jal	5156 <printf>
    exit(1);
    16da:	4505                	li	a0,1
    16dc:	638030ef          	jal	4d14 <exit>

00000000000016e0 <exitwait>:
{
    16e0:	715d                	addi	sp,sp,-80
    16e2:	e486                	sd	ra,72(sp)
    16e4:	e0a2                	sd	s0,64(sp)
    16e6:	fc26                	sd	s1,56(sp)
    16e8:	f84a                	sd	s2,48(sp)
    16ea:	f44e                	sd	s3,40(sp)
    16ec:	f052                	sd	s4,32(sp)
    16ee:	ec56                	sd	s5,24(sp)
    16f0:	0880                	addi	s0,sp,80
    16f2:	8aaa                	mv	s5,a0
  for(i = 0; i < 100; i++){
    16f4:	4901                	li	s2,0
      if(wait(&xstate) != pid){
    16f6:	fbc40993          	addi	s3,s0,-68
  for(i = 0; i < 100; i++){
    16fa:	06400a13          	li	s4,100
    pid = fork();
    16fe:	60e030ef          	jal	4d0c <fork>
    1702:	84aa                	mv	s1,a0
    if(pid < 0){
    1704:	02054863          	bltz	a0,1734 <exitwait+0x54>
    if(pid){
    1708:	c525                	beqz	a0,1770 <exitwait+0x90>
      if(wait(&xstate) != pid){
    170a:	854e                	mv	a0,s3
    170c:	610030ef          	jal	4d1c <wait>
    1710:	02951c63          	bne	a0,s1,1748 <exitwait+0x68>
      if(i != xstate) {
    1714:	fbc42783          	lw	a5,-68(s0)
    1718:	05279263          	bne	a5,s2,175c <exitwait+0x7c>
  for(i = 0; i < 100; i++){
    171c:	2905                	addiw	s2,s2,1
    171e:	ff4910e3          	bne	s2,s4,16fe <exitwait+0x1e>
}
    1722:	60a6                	ld	ra,72(sp)
    1724:	6406                	ld	s0,64(sp)
    1726:	74e2                	ld	s1,56(sp)
    1728:	7942                	ld	s2,48(sp)
    172a:	79a2                	ld	s3,40(sp)
    172c:	7a02                	ld	s4,32(sp)
    172e:	6ae2                	ld	s5,24(sp)
    1730:	6161                	addi	sp,sp,80
    1732:	8082                	ret
      printf("%s: fork failed\n", s);
    1734:	85d6                	mv	a1,s5
    1736:	00004517          	auipc	a0,0x4
    173a:	67250513          	addi	a0,a0,1650 # 5da8 <thread_switch+0x932>
    173e:	219030ef          	jal	5156 <printf>
      exit(1);
    1742:	4505                	li	a0,1
    1744:	5d0030ef          	jal	4d14 <exit>
        printf("%s: wait wrong pid\n", s);
    1748:	85d6                	mv	a1,s5
    174a:	00004517          	auipc	a0,0x4
    174e:	7e650513          	addi	a0,a0,2022 # 5f30 <thread_switch+0xaba>
    1752:	205030ef          	jal	5156 <printf>
        exit(1);
    1756:	4505                	li	a0,1
    1758:	5bc030ef          	jal	4d14 <exit>
        printf("%s: wait wrong exit status\n", s);
    175c:	85d6                	mv	a1,s5
    175e:	00004517          	auipc	a0,0x4
    1762:	7ea50513          	addi	a0,a0,2026 # 5f48 <thread_switch+0xad2>
    1766:	1f1030ef          	jal	5156 <printf>
        exit(1);
    176a:	4505                	li	a0,1
    176c:	5a8030ef          	jal	4d14 <exit>
      exit(i);
    1770:	854a                	mv	a0,s2
    1772:	5a2030ef          	jal	4d14 <exit>

0000000000001776 <twochildren>:
{
    1776:	1101                	addi	sp,sp,-32
    1778:	ec06                	sd	ra,24(sp)
    177a:	e822                	sd	s0,16(sp)
    177c:	e426                	sd	s1,8(sp)
    177e:	e04a                	sd	s2,0(sp)
    1780:	1000                	addi	s0,sp,32
    1782:	892a                	mv	s2,a0
    1784:	3e800493          	li	s1,1000
    int pid1 = fork();
    1788:	584030ef          	jal	4d0c <fork>
    if(pid1 < 0){
    178c:	02054663          	bltz	a0,17b8 <twochildren+0x42>
    if(pid1 == 0){
    1790:	cd15                	beqz	a0,17cc <twochildren+0x56>
      int pid2 = fork();
    1792:	57a030ef          	jal	4d0c <fork>
      if(pid2 < 0){
    1796:	02054d63          	bltz	a0,17d0 <twochildren+0x5a>
      if(pid2 == 0){
    179a:	c529                	beqz	a0,17e4 <twochildren+0x6e>
        wait(0);
    179c:	4501                	li	a0,0
    179e:	57e030ef          	jal	4d1c <wait>
        wait(0);
    17a2:	4501                	li	a0,0
    17a4:	578030ef          	jal	4d1c <wait>
  for(int i = 0; i < 1000; i++){
    17a8:	34fd                	addiw	s1,s1,-1
    17aa:	fcf9                	bnez	s1,1788 <twochildren+0x12>
}
    17ac:	60e2                	ld	ra,24(sp)
    17ae:	6442                	ld	s0,16(sp)
    17b0:	64a2                	ld	s1,8(sp)
    17b2:	6902                	ld	s2,0(sp)
    17b4:	6105                	addi	sp,sp,32
    17b6:	8082                	ret
      printf("%s: fork failed\n", s);
    17b8:	85ca                	mv	a1,s2
    17ba:	00004517          	auipc	a0,0x4
    17be:	5ee50513          	addi	a0,a0,1518 # 5da8 <thread_switch+0x932>
    17c2:	195030ef          	jal	5156 <printf>
      exit(1);
    17c6:	4505                	li	a0,1
    17c8:	54c030ef          	jal	4d14 <exit>
      exit(0);
    17cc:	548030ef          	jal	4d14 <exit>
        printf("%s: fork failed\n", s);
    17d0:	85ca                	mv	a1,s2
    17d2:	00004517          	auipc	a0,0x4
    17d6:	5d650513          	addi	a0,a0,1494 # 5da8 <thread_switch+0x932>
    17da:	17d030ef          	jal	5156 <printf>
        exit(1);
    17de:	4505                	li	a0,1
    17e0:	534030ef          	jal	4d14 <exit>
        exit(0);
    17e4:	530030ef          	jal	4d14 <exit>

00000000000017e8 <forkfork>:
{
    17e8:	7179                	addi	sp,sp,-48
    17ea:	f406                	sd	ra,40(sp)
    17ec:	f022                	sd	s0,32(sp)
    17ee:	ec26                	sd	s1,24(sp)
    17f0:	1800                	addi	s0,sp,48
    17f2:	84aa                	mv	s1,a0
    int pid = fork();
    17f4:	518030ef          	jal	4d0c <fork>
    if(pid < 0){
    17f8:	02054b63          	bltz	a0,182e <forkfork+0x46>
    if(pid == 0){
    17fc:	c139                	beqz	a0,1842 <forkfork+0x5a>
    int pid = fork();
    17fe:	50e030ef          	jal	4d0c <fork>
    if(pid < 0){
    1802:	02054663          	bltz	a0,182e <forkfork+0x46>
    if(pid == 0){
    1806:	cd15                	beqz	a0,1842 <forkfork+0x5a>
    wait(&xstatus);
    1808:	fdc40513          	addi	a0,s0,-36
    180c:	510030ef          	jal	4d1c <wait>
    if(xstatus != 0) {
    1810:	fdc42783          	lw	a5,-36(s0)
    1814:	ebb9                	bnez	a5,186a <forkfork+0x82>
    wait(&xstatus);
    1816:	fdc40513          	addi	a0,s0,-36
    181a:	502030ef          	jal	4d1c <wait>
    if(xstatus != 0) {
    181e:	fdc42783          	lw	a5,-36(s0)
    1822:	e7a1                	bnez	a5,186a <forkfork+0x82>
}
    1824:	70a2                	ld	ra,40(sp)
    1826:	7402                	ld	s0,32(sp)
    1828:	64e2                	ld	s1,24(sp)
    182a:	6145                	addi	sp,sp,48
    182c:	8082                	ret
      printf("%s: fork failed", s);
    182e:	85a6                	mv	a1,s1
    1830:	00004517          	auipc	a0,0x4
    1834:	73850513          	addi	a0,a0,1848 # 5f68 <thread_switch+0xaf2>
    1838:	11f030ef          	jal	5156 <printf>
      exit(1);
    183c:	4505                	li	a0,1
    183e:	4d6030ef          	jal	4d14 <exit>
{
    1842:	0c800493          	li	s1,200
        int pid1 = fork();
    1846:	4c6030ef          	jal	4d0c <fork>
        if(pid1 < 0){
    184a:	00054b63          	bltz	a0,1860 <forkfork+0x78>
        if(pid1 == 0){
    184e:	cd01                	beqz	a0,1866 <forkfork+0x7e>
        wait(0);
    1850:	4501                	li	a0,0
    1852:	4ca030ef          	jal	4d1c <wait>
      for(int j = 0; j < 200; j++){
    1856:	34fd                	addiw	s1,s1,-1
    1858:	f4fd                	bnez	s1,1846 <forkfork+0x5e>
      exit(0);
    185a:	4501                	li	a0,0
    185c:	4b8030ef          	jal	4d14 <exit>
          exit(1);
    1860:	4505                	li	a0,1
    1862:	4b2030ef          	jal	4d14 <exit>
          exit(0);
    1866:	4ae030ef          	jal	4d14 <exit>
      printf("%s: fork in child failed", s);
    186a:	85a6                	mv	a1,s1
    186c:	00004517          	auipc	a0,0x4
    1870:	70c50513          	addi	a0,a0,1804 # 5f78 <thread_switch+0xb02>
    1874:	0e3030ef          	jal	5156 <printf>
      exit(1);
    1878:	4505                	li	a0,1
    187a:	49a030ef          	jal	4d14 <exit>

000000000000187e <reparent2>:
{
    187e:	1101                	addi	sp,sp,-32
    1880:	ec06                	sd	ra,24(sp)
    1882:	e822                	sd	s0,16(sp)
    1884:	e426                	sd	s1,8(sp)
    1886:	1000                	addi	s0,sp,32
    1888:	32000493          	li	s1,800
    int pid1 = fork();
    188c:	480030ef          	jal	4d0c <fork>
    if(pid1 < 0){
    1890:	00054b63          	bltz	a0,18a6 <reparent2+0x28>
    if(pid1 == 0){
    1894:	c115                	beqz	a0,18b8 <reparent2+0x3a>
    wait(0);
    1896:	4501                	li	a0,0
    1898:	484030ef          	jal	4d1c <wait>
  for(int i = 0; i < 800; i++){
    189c:	34fd                	addiw	s1,s1,-1
    189e:	f4fd                	bnez	s1,188c <reparent2+0xe>
  exit(0);
    18a0:	4501                	li	a0,0
    18a2:	472030ef          	jal	4d14 <exit>
      printf("fork failed\n");
    18a6:	00006517          	auipc	a0,0x6
    18aa:	a7250513          	addi	a0,a0,-1422 # 7318 <thread_switch+0x1ea2>
    18ae:	0a9030ef          	jal	5156 <printf>
      exit(1);
    18b2:	4505                	li	a0,1
    18b4:	460030ef          	jal	4d14 <exit>
      fork();
    18b8:	454030ef          	jal	4d0c <fork>
      fork();
    18bc:	450030ef          	jal	4d0c <fork>
      exit(0);
    18c0:	4501                	li	a0,0
    18c2:	452030ef          	jal	4d14 <exit>

00000000000018c6 <createdelete>:
{
    18c6:	7135                	addi	sp,sp,-160
    18c8:	ed06                	sd	ra,152(sp)
    18ca:	e922                	sd	s0,144(sp)
    18cc:	e526                	sd	s1,136(sp)
    18ce:	e14a                	sd	s2,128(sp)
    18d0:	fcce                	sd	s3,120(sp)
    18d2:	f8d2                	sd	s4,112(sp)
    18d4:	f4d6                	sd	s5,104(sp)
    18d6:	f0da                	sd	s6,96(sp)
    18d8:	ecde                	sd	s7,88(sp)
    18da:	e8e2                	sd	s8,80(sp)
    18dc:	e4e6                	sd	s9,72(sp)
    18de:	e0ea                	sd	s10,64(sp)
    18e0:	fc6e                	sd	s11,56(sp)
    18e2:	1100                	addi	s0,sp,160
    18e4:	8daa                	mv	s11,a0
  for(pi = 0; pi < NCHILD; pi++){
    18e6:	4901                	li	s2,0
    18e8:	4991                	li	s3,4
    pid = fork();
    18ea:	422030ef          	jal	4d0c <fork>
    18ee:	84aa                	mv	s1,a0
    if(pid < 0){
    18f0:	04054063          	bltz	a0,1930 <createdelete+0x6a>
    if(pid == 0){
    18f4:	c921                	beqz	a0,1944 <createdelete+0x7e>
  for(pi = 0; pi < NCHILD; pi++){
    18f6:	2905                	addiw	s2,s2,1
    18f8:	ff3919e3          	bne	s2,s3,18ea <createdelete+0x24>
    18fc:	4491                	li	s1,4
    wait(&xstatus);
    18fe:	f6c40913          	addi	s2,s0,-148
    1902:	854a                	mv	a0,s2
    1904:	418030ef          	jal	4d1c <wait>
    if(xstatus != 0)
    1908:	f6c42a83          	lw	s5,-148(s0)
    190c:	0c0a9263          	bnez	s5,19d0 <createdelete+0x10a>
  for(pi = 0; pi < NCHILD; pi++){
    1910:	34fd                	addiw	s1,s1,-1
    1912:	f8e5                	bnez	s1,1902 <createdelete+0x3c>
  name[0] = name[1] = name[2] = 0;
    1914:	f6040923          	sb	zero,-142(s0)
    1918:	03000993          	li	s3,48
    191c:	5a7d                	li	s4,-1
      if((i == 0 || i >= N/2) && fd < 0){
    191e:	4d25                	li	s10,9
    1920:	07000c93          	li	s9,112
      fd = open(name, 0);
    1924:	f7040c13          	addi	s8,s0,-144
      } else if((i >= 1 && i < N/2) && fd >= 0){
    1928:	4ba1                	li	s7,8
    for(pi = 0; pi < NCHILD; pi++){
    192a:	07400b13          	li	s6,116
    192e:	aa39                	j	1a4c <createdelete+0x186>
      printf("%s: fork failed\n", s);
    1930:	85ee                	mv	a1,s11
    1932:	00004517          	auipc	a0,0x4
    1936:	47650513          	addi	a0,a0,1142 # 5da8 <thread_switch+0x932>
    193a:	01d030ef          	jal	5156 <printf>
      exit(1);
    193e:	4505                	li	a0,1
    1940:	3d4030ef          	jal	4d14 <exit>
      name[0] = 'p' + pi;
    1944:	0709091b          	addiw	s2,s2,112
    1948:	f7240823          	sb	s2,-144(s0)
      name[2] = '\0';
    194c:	f6040923          	sb	zero,-142(s0)
        fd = open(name, O_CREATE | O_RDWR);
    1950:	f7040913          	addi	s2,s0,-144
    1954:	20200993          	li	s3,514
      for(i = 0; i < N; i++){
    1958:	4a51                	li	s4,20
    195a:	a815                	j	198e <createdelete+0xc8>
          printf("%s: create failed\n", s);
    195c:	85ee                	mv	a1,s11
    195e:	00004517          	auipc	a0,0x4
    1962:	4e250513          	addi	a0,a0,1250 # 5e40 <thread_switch+0x9ca>
    1966:	7f0030ef          	jal	5156 <printf>
          exit(1);
    196a:	4505                	li	a0,1
    196c:	3a8030ef          	jal	4d14 <exit>
          name[1] = '0' + (i / 2);
    1970:	01f4d79b          	srliw	a5,s1,0x1f
    1974:	9fa5                	addw	a5,a5,s1
    1976:	4017d79b          	sraiw	a5,a5,0x1
    197a:	0307879b          	addiw	a5,a5,48
    197e:	f6f408a3          	sb	a5,-143(s0)
          if(unlink(name) < 0){
    1982:	854a                	mv	a0,s2
    1984:	3e0030ef          	jal	4d64 <unlink>
    1988:	02054a63          	bltz	a0,19bc <createdelete+0xf6>
      for(i = 0; i < N; i++){
    198c:	2485                	addiw	s1,s1,1
        name[1] = '0' + i;
    198e:	0304879b          	addiw	a5,s1,48
    1992:	f6f408a3          	sb	a5,-143(s0)
        fd = open(name, O_CREATE | O_RDWR);
    1996:	85ce                	mv	a1,s3
    1998:	854a                	mv	a0,s2
    199a:	3ba030ef          	jal	4d54 <open>
        if(fd < 0){
    199e:	fa054fe3          	bltz	a0,195c <createdelete+0x96>
        close(fd);
    19a2:	39a030ef          	jal	4d3c <close>
        if(i > 0 && (i % 2 ) == 0){
    19a6:	fe9053e3          	blez	s1,198c <createdelete+0xc6>
    19aa:	0014f793          	andi	a5,s1,1
    19ae:	d3e9                	beqz	a5,1970 <createdelete+0xaa>
      for(i = 0; i < N; i++){
    19b0:	2485                	addiw	s1,s1,1
    19b2:	fd449ee3          	bne	s1,s4,198e <createdelete+0xc8>
      exit(0);
    19b6:	4501                	li	a0,0
    19b8:	35c030ef          	jal	4d14 <exit>
            printf("%s: unlink failed\n", s);
    19bc:	85ee                	mv	a1,s11
    19be:	00004517          	auipc	a0,0x4
    19c2:	5da50513          	addi	a0,a0,1498 # 5f98 <thread_switch+0xb22>
    19c6:	790030ef          	jal	5156 <printf>
            exit(1);
    19ca:	4505                	li	a0,1
    19cc:	348030ef          	jal	4d14 <exit>
      exit(1);
    19d0:	4505                	li	a0,1
    19d2:	342030ef          	jal	4d14 <exit>
        printf("%s: oops createdelete %s didn't exist\n", s, name);
    19d6:	f7040613          	addi	a2,s0,-144
    19da:	85ee                	mv	a1,s11
    19dc:	00004517          	auipc	a0,0x4
    19e0:	5d450513          	addi	a0,a0,1492 # 5fb0 <thread_switch+0xb3a>
    19e4:	772030ef          	jal	5156 <printf>
        exit(1);
    19e8:	4505                	li	a0,1
    19ea:	32a030ef          	jal	4d14 <exit>
      } else if((i >= 1 && i < N/2) && fd >= 0){
    19ee:	02054063          	bltz	a0,1a0e <createdelete+0x148>
        printf("%s: oops createdelete %s did exist\n", s, name);
    19f2:	f7040613          	addi	a2,s0,-144
    19f6:	85ee                	mv	a1,s11
    19f8:	00004517          	auipc	a0,0x4
    19fc:	5e050513          	addi	a0,a0,1504 # 5fd8 <thread_switch+0xb62>
    1a00:	756030ef          	jal	5156 <printf>
        exit(1);
    1a04:	4505                	li	a0,1
    1a06:	30e030ef          	jal	4d14 <exit>
        close(fd);
    1a0a:	332030ef          	jal	4d3c <close>
    for(pi = 0; pi < NCHILD; pi++){
    1a0e:	2485                	addiw	s1,s1,1
    1a10:	0ff4f493          	zext.b	s1,s1
    1a14:	03648463          	beq	s1,s6,1a3c <createdelete+0x176>
      name[0] = 'p' + pi;
    1a18:	f6940823          	sb	s1,-144(s0)
      name[1] = '0' + i;
    1a1c:	f73408a3          	sb	s3,-143(s0)
      fd = open(name, 0);
    1a20:	4581                	li	a1,0
    1a22:	8562                	mv	a0,s8
    1a24:	330030ef          	jal	4d54 <open>
      if((i == 0 || i >= N/2) && fd < 0){
    1a28:	01f5579b          	srliw	a5,a0,0x1f
    1a2c:	00f977b3          	and	a5,s2,a5
    1a30:	f3dd                	bnez	a5,19d6 <createdelete+0x110>
      } else if((i >= 1 && i < N/2) && fd >= 0){
    1a32:	fb4bfee3          	bgeu	s7,s4,19ee <createdelete+0x128>
      if(fd >= 0)
    1a36:	fc054ce3          	bltz	a0,1a0e <createdelete+0x148>
    1a3a:	bfc1                	j	1a0a <createdelete+0x144>
  for(i = 0; i < N; i++){
    1a3c:	2a85                	addiw	s5,s5,1
    1a3e:	2a05                	addiw	s4,s4,1
    1a40:	2985                	addiw	s3,s3,1
    1a42:	0ff9f993          	zext.b	s3,s3
    1a46:	47d1                	li	a5,20
    1a48:	00fa8a63          	beq	s5,a5,1a5c <createdelete+0x196>
      if((i == 0 || i >= N/2) && fd < 0){
    1a4c:	001ab913          	seqz	s2,s5
    1a50:	015d27b3          	slt	a5,s10,s5
    1a54:	00f96933          	or	s2,s2,a5
    1a58:	84e6                	mv	s1,s9
    1a5a:	bf7d                	j	1a18 <createdelete+0x152>
  for(i = 0; i < N; i++){
    1a5c:	03000913          	li	s2,48
  name[0] = name[1] = name[2] = 0;
    1a60:	07000b13          	li	s6,112
      unlink(name);
    1a64:	f7040a13          	addi	s4,s0,-144
    for(pi = 0; pi < NCHILD; pi++){
    1a68:	07400993          	li	s3,116
  for(i = 0; i < N; i++){
    1a6c:	04400a93          	li	s5,68
  name[0] = name[1] = name[2] = 0;
    1a70:	84da                	mv	s1,s6
      name[0] = 'p' + pi;
    1a72:	f6940823          	sb	s1,-144(s0)
      name[1] = '0' + i;
    1a76:	f72408a3          	sb	s2,-143(s0)
      unlink(name);
    1a7a:	8552                	mv	a0,s4
    1a7c:	2e8030ef          	jal	4d64 <unlink>
    for(pi = 0; pi < NCHILD; pi++){
    1a80:	2485                	addiw	s1,s1,1
    1a82:	0ff4f493          	zext.b	s1,s1
    1a86:	ff3496e3          	bne	s1,s3,1a72 <createdelete+0x1ac>
  for(i = 0; i < N; i++){
    1a8a:	2905                	addiw	s2,s2,1
    1a8c:	0ff97913          	zext.b	s2,s2
    1a90:	ff5910e3          	bne	s2,s5,1a70 <createdelete+0x1aa>
}
    1a94:	60ea                	ld	ra,152(sp)
    1a96:	644a                	ld	s0,144(sp)
    1a98:	64aa                	ld	s1,136(sp)
    1a9a:	690a                	ld	s2,128(sp)
    1a9c:	79e6                	ld	s3,120(sp)
    1a9e:	7a46                	ld	s4,112(sp)
    1aa0:	7aa6                	ld	s5,104(sp)
    1aa2:	7b06                	ld	s6,96(sp)
    1aa4:	6be6                	ld	s7,88(sp)
    1aa6:	6c46                	ld	s8,80(sp)
    1aa8:	6ca6                	ld	s9,72(sp)
    1aaa:	6d06                	ld	s10,64(sp)
    1aac:	7de2                	ld	s11,56(sp)
    1aae:	610d                	addi	sp,sp,160
    1ab0:	8082                	ret

0000000000001ab2 <linkunlink>:
{
    1ab2:	711d                	addi	sp,sp,-96
    1ab4:	ec86                	sd	ra,88(sp)
    1ab6:	e8a2                	sd	s0,80(sp)
    1ab8:	e4a6                	sd	s1,72(sp)
    1aba:	e0ca                	sd	s2,64(sp)
    1abc:	fc4e                	sd	s3,56(sp)
    1abe:	f852                	sd	s4,48(sp)
    1ac0:	f456                	sd	s5,40(sp)
    1ac2:	f05a                	sd	s6,32(sp)
    1ac4:	ec5e                	sd	s7,24(sp)
    1ac6:	e862                	sd	s8,16(sp)
    1ac8:	e466                	sd	s9,8(sp)
    1aca:	e06a                	sd	s10,0(sp)
    1acc:	1080                	addi	s0,sp,96
    1ace:	84aa                	mv	s1,a0
  unlink("x");
    1ad0:	00004517          	auipc	a0,0x4
    1ad4:	ab850513          	addi	a0,a0,-1352 # 5588 <thread_switch+0x112>
    1ad8:	28c030ef          	jal	4d64 <unlink>
  pid = fork();
    1adc:	230030ef          	jal	4d0c <fork>
  if(pid < 0){
    1ae0:	04054663          	bltz	a0,1b2c <linkunlink+0x7a>
    1ae4:	8d2a                	mv	s10,a0
  unsigned int x = (pid ? 1 : 97);
    1ae6:	00153913          	seqz	s2,a0
    1aea:	41200933          	neg	s2,s2
    1aee:	06097913          	andi	s2,s2,96
    1af2:	0905                	addi	s2,s2,1
    1af4:	06400493          	li	s1,100
    x = x * 1103515245 + 12345;
    1af8:	41c65ab7          	lui	s5,0x41c65
    1afc:	e6da8a9b          	addiw	s5,s5,-403 # 41c64e6d <all_thread+0x41c561e5>
    1b00:	6a0d                	lui	s4,0x3
    1b02:	039a0a1b          	addiw	s4,s4,57 # 3039 <subdir+0x323>
    if((x % 3) == 0){
    1b06:	000ab9b7          	lui	s3,0xab
    1b0a:	aab98993          	addi	s3,s3,-1365 # aaaab <all_thread+0x9be23>
    1b0e:	09b2                	slli	s3,s3,0xc
    1b10:	aab98993          	addi	s3,s3,-1365
    } else if((x % 3) == 1){
    1b14:	4b85                	li	s7,1
      unlink("x");
    1b16:	00004b17          	auipc	s6,0x4
    1b1a:	a72b0b13          	addi	s6,s6,-1422 # 5588 <thread_switch+0x112>
      link("cat", "x");
    1b1e:	00004c97          	auipc	s9,0x4
    1b22:	4e2c8c93          	addi	s9,s9,1250 # 6000 <thread_switch+0xb8a>
      close(open("x", O_RDWR | O_CREATE));
    1b26:	20200c13          	li	s8,514
    1b2a:	a03d                	j	1b58 <linkunlink+0xa6>
    printf("%s: fork failed\n", s);
    1b2c:	85a6                	mv	a1,s1
    1b2e:	00004517          	auipc	a0,0x4
    1b32:	27a50513          	addi	a0,a0,634 # 5da8 <thread_switch+0x932>
    1b36:	620030ef          	jal	5156 <printf>
    exit(1);
    1b3a:	4505                	li	a0,1
    1b3c:	1d8030ef          	jal	4d14 <exit>
      close(open("x", O_RDWR | O_CREATE));
    1b40:	85e2                	mv	a1,s8
    1b42:	855a                	mv	a0,s6
    1b44:	210030ef          	jal	4d54 <open>
    1b48:	1f4030ef          	jal	4d3c <close>
    1b4c:	a021                	j	1b54 <linkunlink+0xa2>
      unlink("x");
    1b4e:	855a                	mv	a0,s6
    1b50:	214030ef          	jal	4d64 <unlink>
  for(i = 0; i < 100; i++){
    1b54:	34fd                	addiw	s1,s1,-1
    1b56:	c885                	beqz	s1,1b86 <linkunlink+0xd4>
    x = x * 1103515245 + 12345;
    1b58:	035907bb          	mulw	a5,s2,s5
    1b5c:	00fa07bb          	addw	a5,s4,a5
    1b60:	893e                	mv	s2,a5
    if((x % 3) == 0){
    1b62:	02079713          	slli	a4,a5,0x20
    1b66:	9301                	srli	a4,a4,0x20
    1b68:	03370733          	mul	a4,a4,s3
    1b6c:	9305                	srli	a4,a4,0x21
    1b6e:	0017169b          	slliw	a3,a4,0x1
    1b72:	9f35                	addw	a4,a4,a3
    1b74:	9f99                	subw	a5,a5,a4
    1b76:	d7e9                	beqz	a5,1b40 <linkunlink+0x8e>
    } else if((x % 3) == 1){
    1b78:	fd779be3          	bne	a5,s7,1b4e <linkunlink+0x9c>
      link("cat", "x");
    1b7c:	85da                	mv	a1,s6
    1b7e:	8566                	mv	a0,s9
    1b80:	1f4030ef          	jal	4d74 <link>
    1b84:	bfc1                	j	1b54 <linkunlink+0xa2>
  if(pid)
    1b86:	020d0363          	beqz	s10,1bac <linkunlink+0xfa>
    wait(0);
    1b8a:	4501                	li	a0,0
    1b8c:	190030ef          	jal	4d1c <wait>
}
    1b90:	60e6                	ld	ra,88(sp)
    1b92:	6446                	ld	s0,80(sp)
    1b94:	64a6                	ld	s1,72(sp)
    1b96:	6906                	ld	s2,64(sp)
    1b98:	79e2                	ld	s3,56(sp)
    1b9a:	7a42                	ld	s4,48(sp)
    1b9c:	7aa2                	ld	s5,40(sp)
    1b9e:	7b02                	ld	s6,32(sp)
    1ba0:	6be2                	ld	s7,24(sp)
    1ba2:	6c42                	ld	s8,16(sp)
    1ba4:	6ca2                	ld	s9,8(sp)
    1ba6:	6d02                	ld	s10,0(sp)
    1ba8:	6125                	addi	sp,sp,96
    1baa:	8082                	ret
    exit(0);
    1bac:	4501                	li	a0,0
    1bae:	166030ef          	jal	4d14 <exit>

0000000000001bb2 <forktest>:
{
    1bb2:	7179                	addi	sp,sp,-48
    1bb4:	f406                	sd	ra,40(sp)
    1bb6:	f022                	sd	s0,32(sp)
    1bb8:	ec26                	sd	s1,24(sp)
    1bba:	e84a                	sd	s2,16(sp)
    1bbc:	e44e                	sd	s3,8(sp)
    1bbe:	1800                	addi	s0,sp,48
    1bc0:	89aa                	mv	s3,a0
  for(n=0; n<N; n++){
    1bc2:	4481                	li	s1,0
    1bc4:	3e800913          	li	s2,1000
    pid = fork();
    1bc8:	144030ef          	jal	4d0c <fork>
    if(pid < 0)
    1bcc:	06054063          	bltz	a0,1c2c <forktest+0x7a>
    if(pid == 0)
    1bd0:	cd11                	beqz	a0,1bec <forktest+0x3a>
  for(n=0; n<N; n++){
    1bd2:	2485                	addiw	s1,s1,1
    1bd4:	ff249ae3          	bne	s1,s2,1bc8 <forktest+0x16>
    printf("%s: fork claimed to work 1000 times!\n", s);
    1bd8:	85ce                	mv	a1,s3
    1bda:	00004517          	auipc	a0,0x4
    1bde:	47650513          	addi	a0,a0,1142 # 6050 <thread_switch+0xbda>
    1be2:	574030ef          	jal	5156 <printf>
    exit(1);
    1be6:	4505                	li	a0,1
    1be8:	12c030ef          	jal	4d14 <exit>
      exit(0);
    1bec:	128030ef          	jal	4d14 <exit>
    printf("%s: no fork at all!\n", s);
    1bf0:	85ce                	mv	a1,s3
    1bf2:	00004517          	auipc	a0,0x4
    1bf6:	41650513          	addi	a0,a0,1046 # 6008 <thread_switch+0xb92>
    1bfa:	55c030ef          	jal	5156 <printf>
    exit(1);
    1bfe:	4505                	li	a0,1
    1c00:	114030ef          	jal	4d14 <exit>
      printf("%s: wait stopped early\n", s);
    1c04:	85ce                	mv	a1,s3
    1c06:	00004517          	auipc	a0,0x4
    1c0a:	41a50513          	addi	a0,a0,1050 # 6020 <thread_switch+0xbaa>
    1c0e:	548030ef          	jal	5156 <printf>
      exit(1);
    1c12:	4505                	li	a0,1
    1c14:	100030ef          	jal	4d14 <exit>
    printf("%s: wait got too many\n", s);
    1c18:	85ce                	mv	a1,s3
    1c1a:	00004517          	auipc	a0,0x4
    1c1e:	41e50513          	addi	a0,a0,1054 # 6038 <thread_switch+0xbc2>
    1c22:	534030ef          	jal	5156 <printf>
    exit(1);
    1c26:	4505                	li	a0,1
    1c28:	0ec030ef          	jal	4d14 <exit>
  if (n == 0) {
    1c2c:	d0f1                	beqz	s1,1bf0 <forktest+0x3e>
  for(; n > 0; n--){
    1c2e:	00905963          	blez	s1,1c40 <forktest+0x8e>
    if(wait(0) < 0){
    1c32:	4501                	li	a0,0
    1c34:	0e8030ef          	jal	4d1c <wait>
    1c38:	fc0546e3          	bltz	a0,1c04 <forktest+0x52>
  for(; n > 0; n--){
    1c3c:	34fd                	addiw	s1,s1,-1
    1c3e:	f8f5                	bnez	s1,1c32 <forktest+0x80>
  if(wait(0) != -1){
    1c40:	4501                	li	a0,0
    1c42:	0da030ef          	jal	4d1c <wait>
    1c46:	57fd                	li	a5,-1
    1c48:	fcf518e3          	bne	a0,a5,1c18 <forktest+0x66>
}
    1c4c:	70a2                	ld	ra,40(sp)
    1c4e:	7402                	ld	s0,32(sp)
    1c50:	64e2                	ld	s1,24(sp)
    1c52:	6942                	ld	s2,16(sp)
    1c54:	69a2                	ld	s3,8(sp)
    1c56:	6145                	addi	sp,sp,48
    1c58:	8082                	ret

0000000000001c5a <kernmem>:
{
    1c5a:	715d                	addi	sp,sp,-80
    1c5c:	e486                	sd	ra,72(sp)
    1c5e:	e0a2                	sd	s0,64(sp)
    1c60:	fc26                	sd	s1,56(sp)
    1c62:	f84a                	sd	s2,48(sp)
    1c64:	f44e                	sd	s3,40(sp)
    1c66:	f052                	sd	s4,32(sp)
    1c68:	ec56                	sd	s5,24(sp)
    1c6a:	e85a                	sd	s6,16(sp)
    1c6c:	0880                	addi	s0,sp,80
    1c6e:	8b2a                	mv	s6,a0
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    1c70:	4485                	li	s1,1
    1c72:	04fe                	slli	s1,s1,0x1f
    wait(&xstatus);
    1c74:	fbc40a93          	addi	s5,s0,-68
    if(xstatus != -1)  // did kernel kill child?
    1c78:	5a7d                	li	s4,-1
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    1c7a:	69b1                	lui	s3,0xc
    1c7c:	35098993          	addi	s3,s3,848 # c350 <buf+0x6d8>
    1c80:	1003d937          	lui	s2,0x1003d
    1c84:	090e                	slli	s2,s2,0x3
    1c86:	48090913          	addi	s2,s2,1152 # 1003d480 <all_thread+0x1002e7f8>
    pid = fork();
    1c8a:	082030ef          	jal	4d0c <fork>
    if(pid < 0){
    1c8e:	02054763          	bltz	a0,1cbc <kernmem+0x62>
    if(pid == 0){
    1c92:	cd1d                	beqz	a0,1cd0 <kernmem+0x76>
    wait(&xstatus);
    1c94:	8556                	mv	a0,s5
    1c96:	086030ef          	jal	4d1c <wait>
    if(xstatus != -1)  // did kernel kill child?
    1c9a:	fbc42783          	lw	a5,-68(s0)
    1c9e:	05479663          	bne	a5,s4,1cea <kernmem+0x90>
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    1ca2:	94ce                	add	s1,s1,s3
    1ca4:	ff2493e3          	bne	s1,s2,1c8a <kernmem+0x30>
}
    1ca8:	60a6                	ld	ra,72(sp)
    1caa:	6406                	ld	s0,64(sp)
    1cac:	74e2                	ld	s1,56(sp)
    1cae:	7942                	ld	s2,48(sp)
    1cb0:	79a2                	ld	s3,40(sp)
    1cb2:	7a02                	ld	s4,32(sp)
    1cb4:	6ae2                	ld	s5,24(sp)
    1cb6:	6b42                	ld	s6,16(sp)
    1cb8:	6161                	addi	sp,sp,80
    1cba:	8082                	ret
      printf("%s: fork failed\n", s);
    1cbc:	85da                	mv	a1,s6
    1cbe:	00004517          	auipc	a0,0x4
    1cc2:	0ea50513          	addi	a0,a0,234 # 5da8 <thread_switch+0x932>
    1cc6:	490030ef          	jal	5156 <printf>
      exit(1);
    1cca:	4505                	li	a0,1
    1ccc:	048030ef          	jal	4d14 <exit>
      printf("%s: oops could read %p = %x\n", s, a, *a);
    1cd0:	0004c683          	lbu	a3,0(s1)
    1cd4:	8626                	mv	a2,s1
    1cd6:	85da                	mv	a1,s6
    1cd8:	00004517          	auipc	a0,0x4
    1cdc:	3a050513          	addi	a0,a0,928 # 6078 <thread_switch+0xc02>
    1ce0:	476030ef          	jal	5156 <printf>
      exit(1);
    1ce4:	4505                	li	a0,1
    1ce6:	02e030ef          	jal	4d14 <exit>
      exit(1);
    1cea:	4505                	li	a0,1
    1cec:	028030ef          	jal	4d14 <exit>

0000000000001cf0 <MAXVAplus>:
{
    1cf0:	7139                	addi	sp,sp,-64
    1cf2:	fc06                	sd	ra,56(sp)
    1cf4:	f822                	sd	s0,48(sp)
    1cf6:	0080                	addi	s0,sp,64
  volatile uint64 a = MAXVA;
    1cf8:	4785                	li	a5,1
    1cfa:	179a                	slli	a5,a5,0x26
    1cfc:	fcf43423          	sd	a5,-56(s0)
  for( ; a != 0; a <<= 1){
    1d00:	fc843783          	ld	a5,-56(s0)
    1d04:	cf9d                	beqz	a5,1d42 <MAXVAplus+0x52>
    1d06:	f426                	sd	s1,40(sp)
    1d08:	f04a                	sd	s2,32(sp)
    1d0a:	ec4e                	sd	s3,24(sp)
    1d0c:	89aa                	mv	s3,a0
    wait(&xstatus);
    1d0e:	fc440913          	addi	s2,s0,-60
    if(xstatus != -1)  // did kernel kill child?
    1d12:	54fd                	li	s1,-1
    pid = fork();
    1d14:	7f9020ef          	jal	4d0c <fork>
    if(pid < 0){
    1d18:	02054963          	bltz	a0,1d4a <MAXVAplus+0x5a>
    if(pid == 0){
    1d1c:	c129                	beqz	a0,1d5e <MAXVAplus+0x6e>
    wait(&xstatus);
    1d1e:	854a                	mv	a0,s2
    1d20:	7fd020ef          	jal	4d1c <wait>
    if(xstatus != -1)  // did kernel kill child?
    1d24:	fc442783          	lw	a5,-60(s0)
    1d28:	04979d63          	bne	a5,s1,1d82 <MAXVAplus+0x92>
  for( ; a != 0; a <<= 1){
    1d2c:	fc843783          	ld	a5,-56(s0)
    1d30:	0786                	slli	a5,a5,0x1
    1d32:	fcf43423          	sd	a5,-56(s0)
    1d36:	fc843783          	ld	a5,-56(s0)
    1d3a:	ffe9                	bnez	a5,1d14 <MAXVAplus+0x24>
    1d3c:	74a2                	ld	s1,40(sp)
    1d3e:	7902                	ld	s2,32(sp)
    1d40:	69e2                	ld	s3,24(sp)
}
    1d42:	70e2                	ld	ra,56(sp)
    1d44:	7442                	ld	s0,48(sp)
    1d46:	6121                	addi	sp,sp,64
    1d48:	8082                	ret
      printf("%s: fork failed\n", s);
    1d4a:	85ce                	mv	a1,s3
    1d4c:	00004517          	auipc	a0,0x4
    1d50:	05c50513          	addi	a0,a0,92 # 5da8 <thread_switch+0x932>
    1d54:	402030ef          	jal	5156 <printf>
      exit(1);
    1d58:	4505                	li	a0,1
    1d5a:	7bb020ef          	jal	4d14 <exit>
      *(char*)a = 99;
    1d5e:	fc843783          	ld	a5,-56(s0)
    1d62:	06300713          	li	a4,99
    1d66:	00e78023          	sb	a4,0(a5)
      printf("%s: oops wrote %p\n", s, (void*)a);
    1d6a:	fc843603          	ld	a2,-56(s0)
    1d6e:	85ce                	mv	a1,s3
    1d70:	00004517          	auipc	a0,0x4
    1d74:	32850513          	addi	a0,a0,808 # 6098 <thread_switch+0xc22>
    1d78:	3de030ef          	jal	5156 <printf>
      exit(1);
    1d7c:	4505                	li	a0,1
    1d7e:	797020ef          	jal	4d14 <exit>
      exit(1);
    1d82:	4505                	li	a0,1
    1d84:	791020ef          	jal	4d14 <exit>

0000000000001d88 <stacktest>:
{
    1d88:	7179                	addi	sp,sp,-48
    1d8a:	f406                	sd	ra,40(sp)
    1d8c:	f022                	sd	s0,32(sp)
    1d8e:	ec26                	sd	s1,24(sp)
    1d90:	1800                	addi	s0,sp,48
    1d92:	84aa                	mv	s1,a0
  pid = fork();
    1d94:	779020ef          	jal	4d0c <fork>
  if(pid == 0) {
    1d98:	cd11                	beqz	a0,1db4 <stacktest+0x2c>
  } else if(pid < 0){
    1d9a:	02054c63          	bltz	a0,1dd2 <stacktest+0x4a>
  wait(&xstatus);
    1d9e:	fdc40513          	addi	a0,s0,-36
    1da2:	77b020ef          	jal	4d1c <wait>
  if(xstatus == -1)  // kernel killed child?
    1da6:	fdc42503          	lw	a0,-36(s0)
    1daa:	57fd                	li	a5,-1
    1dac:	02f50d63          	beq	a0,a5,1de6 <stacktest+0x5e>
    exit(xstatus);
    1db0:	765020ef          	jal	4d14 <exit>

static inline uint64
r_sp()
{
  uint64 x;
  asm volatile("mv %0, sp" : "=r" (x) );
    1db4:	870a                	mv	a4,sp
    printf("%s: stacktest: read below stack %d\n", s, *sp);
    1db6:	77fd                	lui	a5,0xfffff
    1db8:	97ba                	add	a5,a5,a4
    1dba:	0007c603          	lbu	a2,0(a5) # fffffffffffff000 <all_thread+0xffffffffffff0378>
    1dbe:	85a6                	mv	a1,s1
    1dc0:	00004517          	auipc	a0,0x4
    1dc4:	2f050513          	addi	a0,a0,752 # 60b0 <thread_switch+0xc3a>
    1dc8:	38e030ef          	jal	5156 <printf>
    exit(1);
    1dcc:	4505                	li	a0,1
    1dce:	747020ef          	jal	4d14 <exit>
    printf("%s: fork failed\n", s);
    1dd2:	85a6                	mv	a1,s1
    1dd4:	00004517          	auipc	a0,0x4
    1dd8:	fd450513          	addi	a0,a0,-44 # 5da8 <thread_switch+0x932>
    1ddc:	37a030ef          	jal	5156 <printf>
    exit(1);
    1de0:	4505                	li	a0,1
    1de2:	733020ef          	jal	4d14 <exit>
    exit(0);
    1de6:	4501                	li	a0,0
    1de8:	72d020ef          	jal	4d14 <exit>

0000000000001dec <nowrite>:
{
    1dec:	7159                	addi	sp,sp,-112
    1dee:	f486                	sd	ra,104(sp)
    1df0:	f0a2                	sd	s0,96(sp)
    1df2:	eca6                	sd	s1,88(sp)
    1df4:	e8ca                	sd	s2,80(sp)
    1df6:	e4ce                	sd	s3,72(sp)
    1df8:	e0d2                	sd	s4,64(sp)
    1dfa:	1880                	addi	s0,sp,112
    1dfc:	8a2a                	mv	s4,a0
  uint64 addrs[] = { 0, 0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
    1dfe:	00006797          	auipc	a5,0x6
    1e02:	ab278793          	addi	a5,a5,-1358 # 78b0 <thread_switch+0x243a>
    1e06:	7788                	ld	a0,40(a5)
    1e08:	7b8c                	ld	a1,48(a5)
    1e0a:	7f90                	ld	a2,56(a5)
    1e0c:	63b4                	ld	a3,64(a5)
    1e0e:	67b8                	ld	a4,72(a5)
    1e10:	f8a43c23          	sd	a0,-104(s0)
    1e14:	fab43023          	sd	a1,-96(s0)
    1e18:	fac43423          	sd	a2,-88(s0)
    1e1c:	fad43823          	sd	a3,-80(s0)
    1e20:	fae43c23          	sd	a4,-72(s0)
    1e24:	6bbc                	ld	a5,80(a5)
    1e26:	fcf43023          	sd	a5,-64(s0)
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
    1e2a:	4481                	li	s1,0
    wait(&xstatus);
    1e2c:	fcc40913          	addi	s2,s0,-52
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
    1e30:	4999                	li	s3,6
    pid = fork();
    1e32:	6db020ef          	jal	4d0c <fork>
    if(pid == 0) {
    1e36:	cd19                	beqz	a0,1e54 <nowrite+0x68>
    } else if(pid < 0){
    1e38:	04054063          	bltz	a0,1e78 <nowrite+0x8c>
    wait(&xstatus);
    1e3c:	854a                	mv	a0,s2
    1e3e:	6df020ef          	jal	4d1c <wait>
    if(xstatus == 0){
    1e42:	fcc42783          	lw	a5,-52(s0)
    1e46:	c3b9                	beqz	a5,1e8c <nowrite+0xa0>
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
    1e48:	2485                	addiw	s1,s1,1
    1e4a:	ff3494e3          	bne	s1,s3,1e32 <nowrite+0x46>
  exit(0);
    1e4e:	4501                	li	a0,0
    1e50:	6c5020ef          	jal	4d14 <exit>
      volatile int *addr = (int *) addrs[ai];
    1e54:	048e                	slli	s1,s1,0x3
    1e56:	fd040793          	addi	a5,s0,-48
    1e5a:	94be                	add	s1,s1,a5
    1e5c:	fc84b603          	ld	a2,-56(s1)
      *addr = 10;
    1e60:	47a9                	li	a5,10
    1e62:	c21c                	sw	a5,0(a2)
      printf("%s: write to %p did not fail!\n", s, addr);
    1e64:	85d2                	mv	a1,s4
    1e66:	00004517          	auipc	a0,0x4
    1e6a:	27250513          	addi	a0,a0,626 # 60d8 <thread_switch+0xc62>
    1e6e:	2e8030ef          	jal	5156 <printf>
      exit(0);
    1e72:	4501                	li	a0,0
    1e74:	6a1020ef          	jal	4d14 <exit>
      printf("%s: fork failed\n", s);
    1e78:	85d2                	mv	a1,s4
    1e7a:	00004517          	auipc	a0,0x4
    1e7e:	f2e50513          	addi	a0,a0,-210 # 5da8 <thread_switch+0x932>
    1e82:	2d4030ef          	jal	5156 <printf>
      exit(1);
    1e86:	4505                	li	a0,1
    1e88:	68d020ef          	jal	4d14 <exit>
      exit(1);
    1e8c:	4505                	li	a0,1
    1e8e:	687020ef          	jal	4d14 <exit>

0000000000001e92 <manywrites>:
{
    1e92:	7159                	addi	sp,sp,-112
    1e94:	f486                	sd	ra,104(sp)
    1e96:	f0a2                	sd	s0,96(sp)
    1e98:	eca6                	sd	s1,88(sp)
    1e9a:	e8ca                	sd	s2,80(sp)
    1e9c:	e4ce                	sd	s3,72(sp)
    1e9e:	ec66                	sd	s9,24(sp)
    1ea0:	1880                	addi	s0,sp,112
    1ea2:	8caa                	mv	s9,a0
  for(int ci = 0; ci < nchildren; ci++){
    1ea4:	4901                	li	s2,0
    1ea6:	4991                	li	s3,4
    int pid = fork();
    1ea8:	665020ef          	jal	4d0c <fork>
    1eac:	84aa                	mv	s1,a0
    if(pid < 0){
    1eae:	02054c63          	bltz	a0,1ee6 <manywrites+0x54>
    if(pid == 0){
    1eb2:	c929                	beqz	a0,1f04 <manywrites+0x72>
  for(int ci = 0; ci < nchildren; ci++){
    1eb4:	2905                	addiw	s2,s2,1
    1eb6:	ff3919e3          	bne	s2,s3,1ea8 <manywrites+0x16>
    1eba:	4491                	li	s1,4
    wait(&st);
    1ebc:	f9840913          	addi	s2,s0,-104
    int st = 0;
    1ec0:	f8042c23          	sw	zero,-104(s0)
    wait(&st);
    1ec4:	854a                	mv	a0,s2
    1ec6:	657020ef          	jal	4d1c <wait>
    if(st != 0)
    1eca:	f9842503          	lw	a0,-104(s0)
    1ece:	0e051763          	bnez	a0,1fbc <manywrites+0x12a>
  for(int ci = 0; ci < nchildren; ci++){
    1ed2:	34fd                	addiw	s1,s1,-1
    1ed4:	f4f5                	bnez	s1,1ec0 <manywrites+0x2e>
    1ed6:	e0d2                	sd	s4,64(sp)
    1ed8:	fc56                	sd	s5,56(sp)
    1eda:	f85a                	sd	s6,48(sp)
    1edc:	f45e                	sd	s7,40(sp)
    1ede:	f062                	sd	s8,32(sp)
    1ee0:	e86a                	sd	s10,16(sp)
  exit(0);
    1ee2:	633020ef          	jal	4d14 <exit>
    1ee6:	e0d2                	sd	s4,64(sp)
    1ee8:	fc56                	sd	s5,56(sp)
    1eea:	f85a                	sd	s6,48(sp)
    1eec:	f45e                	sd	s7,40(sp)
    1eee:	f062                	sd	s8,32(sp)
    1ef0:	e86a                	sd	s10,16(sp)
      printf("fork failed\n");
    1ef2:	00005517          	auipc	a0,0x5
    1ef6:	42650513          	addi	a0,a0,1062 # 7318 <thread_switch+0x1ea2>
    1efa:	25c030ef          	jal	5156 <printf>
      exit(1);
    1efe:	4505                	li	a0,1
    1f00:	615020ef          	jal	4d14 <exit>
    1f04:	e0d2                	sd	s4,64(sp)
    1f06:	fc56                	sd	s5,56(sp)
    1f08:	f85a                	sd	s6,48(sp)
    1f0a:	f45e                	sd	s7,40(sp)
    1f0c:	f062                	sd	s8,32(sp)
    1f0e:	e86a                	sd	s10,16(sp)
      name[0] = 'b';
    1f10:	06200793          	li	a5,98
    1f14:	f8f40c23          	sb	a5,-104(s0)
      name[1] = 'a' + ci;
    1f18:	0619079b          	addiw	a5,s2,97
    1f1c:	f8f40ca3          	sb	a5,-103(s0)
      name[2] = '\0';
    1f20:	f8040d23          	sb	zero,-102(s0)
      unlink(name);
    1f24:	f9840513          	addi	a0,s0,-104
    1f28:	63d020ef          	jal	4d64 <unlink>
    1f2c:	47f9                	li	a5,30
    1f2e:	8d3e                	mv	s10,a5
          int fd = open(name, O_CREATE | O_RDWR);
    1f30:	f9840b93          	addi	s7,s0,-104
    1f34:	20200b13          	li	s6,514
          int cc = write(fd, buf, sz);
    1f38:	6a8d                	lui	s5,0x3
    1f3a:	0000ac17          	auipc	s8,0xa
    1f3e:	d3ec0c13          	addi	s8,s8,-706 # bc78 <buf>
        for(int i = 0; i < ci+1; i++){
    1f42:	8a26                	mv	s4,s1
    1f44:	02094563          	bltz	s2,1f6e <manywrites+0xdc>
          int fd = open(name, O_CREATE | O_RDWR);
    1f48:	85da                	mv	a1,s6
    1f4a:	855e                	mv	a0,s7
    1f4c:	609020ef          	jal	4d54 <open>
    1f50:	89aa                	mv	s3,a0
          if(fd < 0){
    1f52:	02054d63          	bltz	a0,1f8c <manywrites+0xfa>
          int cc = write(fd, buf, sz);
    1f56:	8656                	mv	a2,s5
    1f58:	85e2                	mv	a1,s8
    1f5a:	5db020ef          	jal	4d34 <write>
          if(cc != sz){
    1f5e:	05551363          	bne	a0,s5,1fa4 <manywrites+0x112>
          close(fd);
    1f62:	854e                	mv	a0,s3
    1f64:	5d9020ef          	jal	4d3c <close>
        for(int i = 0; i < ci+1; i++){
    1f68:	2a05                	addiw	s4,s4,1
    1f6a:	fd495fe3          	bge	s2,s4,1f48 <manywrites+0xb6>
        unlink(name);
    1f6e:	f9840513          	addi	a0,s0,-104
    1f72:	5f3020ef          	jal	4d64 <unlink>
      for(int iters = 0; iters < howmany; iters++){
    1f76:	fffd079b          	addiw	a5,s10,-1
    1f7a:	8d3e                	mv	s10,a5
    1f7c:	f3f9                	bnez	a5,1f42 <manywrites+0xb0>
      unlink(name);
    1f7e:	f9840513          	addi	a0,s0,-104
    1f82:	5e3020ef          	jal	4d64 <unlink>
      exit(0);
    1f86:	4501                	li	a0,0
    1f88:	58d020ef          	jal	4d14 <exit>
            printf("%s: cannot create %s\n", s, name);
    1f8c:	f9840613          	addi	a2,s0,-104
    1f90:	85e6                	mv	a1,s9
    1f92:	00004517          	auipc	a0,0x4
    1f96:	16650513          	addi	a0,a0,358 # 60f8 <thread_switch+0xc82>
    1f9a:	1bc030ef          	jal	5156 <printf>
            exit(1);
    1f9e:	4505                	li	a0,1
    1fa0:	575020ef          	jal	4d14 <exit>
            printf("%s: write(%d) ret %d\n", s, sz, cc);
    1fa4:	86aa                	mv	a3,a0
    1fa6:	660d                	lui	a2,0x3
    1fa8:	85e6                	mv	a1,s9
    1faa:	00003517          	auipc	a0,0x3
    1fae:	63e50513          	addi	a0,a0,1598 # 55e8 <thread_switch+0x172>
    1fb2:	1a4030ef          	jal	5156 <printf>
            exit(1);
    1fb6:	4505                	li	a0,1
    1fb8:	55d020ef          	jal	4d14 <exit>
    1fbc:	e0d2                	sd	s4,64(sp)
    1fbe:	fc56                	sd	s5,56(sp)
    1fc0:	f85a                	sd	s6,48(sp)
    1fc2:	f45e                	sd	s7,40(sp)
    1fc4:	f062                	sd	s8,32(sp)
    1fc6:	e86a                	sd	s10,16(sp)
      exit(st);
    1fc8:	54d020ef          	jal	4d14 <exit>

0000000000001fcc <copyinstr3>:
{
    1fcc:	7179                	addi	sp,sp,-48
    1fce:	f406                	sd	ra,40(sp)
    1fd0:	f022                	sd	s0,32(sp)
    1fd2:	ec26                	sd	s1,24(sp)
    1fd4:	1800                	addi	s0,sp,48
  sbrk(8192);
    1fd6:	6509                	lui	a0,0x2
    1fd8:	5c5020ef          	jal	4d9c <sbrk>
  uint64 top = (uint64) sbrk(0);
    1fdc:	4501                	li	a0,0
    1fde:	5bf020ef          	jal	4d9c <sbrk>
  if((top % PGSIZE) != 0){
    1fe2:	03451793          	slli	a5,a0,0x34
    1fe6:	e7bd                	bnez	a5,2054 <copyinstr3+0x88>
  top = (uint64) sbrk(0);
    1fe8:	4501                	li	a0,0
    1fea:	5b3020ef          	jal	4d9c <sbrk>
  if(top % PGSIZE){
    1fee:	03451793          	slli	a5,a0,0x34
    1ff2:	ebad                	bnez	a5,2064 <copyinstr3+0x98>
  char *b = (char *) (top - 1);
    1ff4:	fff50493          	addi	s1,a0,-1 # 1fff <copyinstr3+0x33>
  *b = 'x';
    1ff8:	07800793          	li	a5,120
    1ffc:	fef50fa3          	sb	a5,-1(a0)
  int ret = unlink(b);
    2000:	8526                	mv	a0,s1
    2002:	563020ef          	jal	4d64 <unlink>
  if(ret != -1){
    2006:	57fd                	li	a5,-1
    2008:	06f51763          	bne	a0,a5,2076 <copyinstr3+0xaa>
  int fd = open(b, O_CREATE | O_WRONLY);
    200c:	20100593          	li	a1,513
    2010:	8526                	mv	a0,s1
    2012:	543020ef          	jal	4d54 <open>
  if(fd != -1){
    2016:	57fd                	li	a5,-1
    2018:	06f51a63          	bne	a0,a5,208c <copyinstr3+0xc0>
  ret = link(b, b);
    201c:	85a6                	mv	a1,s1
    201e:	8526                	mv	a0,s1
    2020:	555020ef          	jal	4d74 <link>
  if(ret != -1){
    2024:	57fd                	li	a5,-1
    2026:	06f51e63          	bne	a0,a5,20a2 <copyinstr3+0xd6>
  char *args[] = { "xx", 0 };
    202a:	00005797          	auipc	a5,0x5
    202e:	dce78793          	addi	a5,a5,-562 # 6df8 <thread_switch+0x1982>
    2032:	fcf43823          	sd	a5,-48(s0)
    2036:	fc043c23          	sd	zero,-40(s0)
  ret = exec(b, args);
    203a:	fd040593          	addi	a1,s0,-48
    203e:	8526                	mv	a0,s1
    2040:	50d020ef          	jal	4d4c <exec>
  if(ret != -1){
    2044:	57fd                	li	a5,-1
    2046:	06f51a63          	bne	a0,a5,20ba <copyinstr3+0xee>
}
    204a:	70a2                	ld	ra,40(sp)
    204c:	7402                	ld	s0,32(sp)
    204e:	64e2                	ld	s1,24(sp)
    2050:	6145                	addi	sp,sp,48
    2052:	8082                	ret
    sbrk(PGSIZE - (top % PGSIZE));
    2054:	0347d513          	srli	a0,a5,0x34
    2058:	6785                	lui	a5,0x1
    205a:	40a7853b          	subw	a0,a5,a0
    205e:	53f020ef          	jal	4d9c <sbrk>
    2062:	b759                	j	1fe8 <copyinstr3+0x1c>
    printf("oops\n");
    2064:	00004517          	auipc	a0,0x4
    2068:	0ac50513          	addi	a0,a0,172 # 6110 <thread_switch+0xc9a>
    206c:	0ea030ef          	jal	5156 <printf>
    exit(1);
    2070:	4505                	li	a0,1
    2072:	4a3020ef          	jal	4d14 <exit>
    printf("unlink(%s) returned %d, not -1\n", b, ret);
    2076:	862a                	mv	a2,a0
    2078:	85a6                	mv	a1,s1
    207a:	00004517          	auipc	a0,0x4
    207e:	c4e50513          	addi	a0,a0,-946 # 5cc8 <thread_switch+0x852>
    2082:	0d4030ef          	jal	5156 <printf>
    exit(1);
    2086:	4505                	li	a0,1
    2088:	48d020ef          	jal	4d14 <exit>
    printf("open(%s) returned %d, not -1\n", b, fd);
    208c:	862a                	mv	a2,a0
    208e:	85a6                	mv	a1,s1
    2090:	00004517          	auipc	a0,0x4
    2094:	c5850513          	addi	a0,a0,-936 # 5ce8 <thread_switch+0x872>
    2098:	0be030ef          	jal	5156 <printf>
    exit(1);
    209c:	4505                	li	a0,1
    209e:	477020ef          	jal	4d14 <exit>
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
    20a2:	86aa                	mv	a3,a0
    20a4:	8626                	mv	a2,s1
    20a6:	85a6                	mv	a1,s1
    20a8:	00004517          	auipc	a0,0x4
    20ac:	c6050513          	addi	a0,a0,-928 # 5d08 <thread_switch+0x892>
    20b0:	0a6030ef          	jal	5156 <printf>
    exit(1);
    20b4:	4505                	li	a0,1
    20b6:	45f020ef          	jal	4d14 <exit>
    printf("exec(%s) returned %d, not -1\n", b, fd);
    20ba:	863e                	mv	a2,a5
    20bc:	85a6                	mv	a1,s1
    20be:	00004517          	auipc	a0,0x4
    20c2:	c7250513          	addi	a0,a0,-910 # 5d30 <thread_switch+0x8ba>
    20c6:	090030ef          	jal	5156 <printf>
    exit(1);
    20ca:	4505                	li	a0,1
    20cc:	449020ef          	jal	4d14 <exit>

00000000000020d0 <rwsbrk>:
{
    20d0:	1101                	addi	sp,sp,-32
    20d2:	ec06                	sd	ra,24(sp)
    20d4:	e822                	sd	s0,16(sp)
    20d6:	1000                	addi	s0,sp,32
  uint64 a = (uint64) sbrk(8192);
    20d8:	6509                	lui	a0,0x2
    20da:	4c3020ef          	jal	4d9c <sbrk>
  if(a == 0xffffffffffffffffLL) {
    20de:	57fd                	li	a5,-1
    20e0:	04f50a63          	beq	a0,a5,2134 <rwsbrk+0x64>
    20e4:	e426                	sd	s1,8(sp)
    20e6:	84aa                	mv	s1,a0
  if ((uint64) sbrk(-8192) ==  0xffffffffffffffffLL) {
    20e8:	7579                	lui	a0,0xffffe
    20ea:	4b3020ef          	jal	4d9c <sbrk>
    20ee:	57fd                	li	a5,-1
    20f0:	04f50d63          	beq	a0,a5,214a <rwsbrk+0x7a>
    20f4:	e04a                	sd	s2,0(sp)
  fd = open("rwsbrk", O_CREATE|O_WRONLY);
    20f6:	20100593          	li	a1,513
    20fa:	00004517          	auipc	a0,0x4
    20fe:	05650513          	addi	a0,a0,86 # 6150 <thread_switch+0xcda>
    2102:	453020ef          	jal	4d54 <open>
    2106:	892a                	mv	s2,a0
  if(fd < 0){
    2108:	04054b63          	bltz	a0,215e <rwsbrk+0x8e>
  n = write(fd, (void*)(a+4096), 1024);
    210c:	6785                	lui	a5,0x1
    210e:	94be                	add	s1,s1,a5
    2110:	40000613          	li	a2,1024
    2114:	85a6                	mv	a1,s1
    2116:	41f020ef          	jal	4d34 <write>
    211a:	862a                	mv	a2,a0
  if(n >= 0){
    211c:	04054a63          	bltz	a0,2170 <rwsbrk+0xa0>
    printf("write(fd, %p, 1024) returned %d, not -1\n", (void*)a+4096, n);
    2120:	85a6                	mv	a1,s1
    2122:	00004517          	auipc	a0,0x4
    2126:	04e50513          	addi	a0,a0,78 # 6170 <thread_switch+0xcfa>
    212a:	02c030ef          	jal	5156 <printf>
    exit(1);
    212e:	4505                	li	a0,1
    2130:	3e5020ef          	jal	4d14 <exit>
    2134:	e426                	sd	s1,8(sp)
    2136:	e04a                	sd	s2,0(sp)
    printf("sbrk(rwsbrk) failed\n");
    2138:	00004517          	auipc	a0,0x4
    213c:	fe050513          	addi	a0,a0,-32 # 6118 <thread_switch+0xca2>
    2140:	016030ef          	jal	5156 <printf>
    exit(1);
    2144:	4505                	li	a0,1
    2146:	3cf020ef          	jal	4d14 <exit>
    214a:	e04a                	sd	s2,0(sp)
    printf("sbrk(rwsbrk) shrink failed\n");
    214c:	00004517          	auipc	a0,0x4
    2150:	fe450513          	addi	a0,a0,-28 # 6130 <thread_switch+0xcba>
    2154:	002030ef          	jal	5156 <printf>
    exit(1);
    2158:	4505                	li	a0,1
    215a:	3bb020ef          	jal	4d14 <exit>
    printf("open(rwsbrk) failed\n");
    215e:	00004517          	auipc	a0,0x4
    2162:	ffa50513          	addi	a0,a0,-6 # 6158 <thread_switch+0xce2>
    2166:	7f1020ef          	jal	5156 <printf>
    exit(1);
    216a:	4505                	li	a0,1
    216c:	3a9020ef          	jal	4d14 <exit>
  close(fd);
    2170:	854a                	mv	a0,s2
    2172:	3cb020ef          	jal	4d3c <close>
  unlink("rwsbrk");
    2176:	00004517          	auipc	a0,0x4
    217a:	fda50513          	addi	a0,a0,-38 # 6150 <thread_switch+0xcda>
    217e:	3e7020ef          	jal	4d64 <unlink>
  fd = open("README", O_RDONLY);
    2182:	4581                	li	a1,0
    2184:	00003517          	auipc	a0,0x3
    2188:	56c50513          	addi	a0,a0,1388 # 56f0 <thread_switch+0x27a>
    218c:	3c9020ef          	jal	4d54 <open>
    2190:	892a                	mv	s2,a0
  if(fd < 0){
    2192:	02054363          	bltz	a0,21b8 <rwsbrk+0xe8>
  n = read(fd, (void*)(a+4096), 10);
    2196:	4629                	li	a2,10
    2198:	85a6                	mv	a1,s1
    219a:	393020ef          	jal	4d2c <read>
    219e:	862a                	mv	a2,a0
  if(n >= 0){
    21a0:	02054563          	bltz	a0,21ca <rwsbrk+0xfa>
    printf("read(fd, %p, 10) returned %d, not -1\n", (void*)a+4096, n);
    21a4:	85a6                	mv	a1,s1
    21a6:	00004517          	auipc	a0,0x4
    21aa:	ffa50513          	addi	a0,a0,-6 # 61a0 <thread_switch+0xd2a>
    21ae:	7a9020ef          	jal	5156 <printf>
    exit(1);
    21b2:	4505                	li	a0,1
    21b4:	361020ef          	jal	4d14 <exit>
    printf("open(rwsbrk) failed\n");
    21b8:	00004517          	auipc	a0,0x4
    21bc:	fa050513          	addi	a0,a0,-96 # 6158 <thread_switch+0xce2>
    21c0:	797020ef          	jal	5156 <printf>
    exit(1);
    21c4:	4505                	li	a0,1
    21c6:	34f020ef          	jal	4d14 <exit>
  close(fd);
    21ca:	854a                	mv	a0,s2
    21cc:	371020ef          	jal	4d3c <close>
  exit(0);
    21d0:	4501                	li	a0,0
    21d2:	343020ef          	jal	4d14 <exit>

00000000000021d6 <sbrkbasic>:
{
    21d6:	715d                	addi	sp,sp,-80
    21d8:	e486                	sd	ra,72(sp)
    21da:	e0a2                	sd	s0,64(sp)
    21dc:	ec56                	sd	s5,24(sp)
    21de:	0880                	addi	s0,sp,80
    21e0:	8aaa                	mv	s5,a0
  pid = fork();
    21e2:	32b020ef          	jal	4d0c <fork>
  if(pid < 0){
    21e6:	02054c63          	bltz	a0,221e <sbrkbasic+0x48>
  if(pid == 0){
    21ea:	ed31                	bnez	a0,2246 <sbrkbasic+0x70>
    a = sbrk(TOOMUCH);
    21ec:	40000537          	lui	a0,0x40000
    21f0:	3ad020ef          	jal	4d9c <sbrk>
    if(a == (char*)0xffffffffffffffffL){
    21f4:	57fd                	li	a5,-1
    21f6:	04f50163          	beq	a0,a5,2238 <sbrkbasic+0x62>
    21fa:	fc26                	sd	s1,56(sp)
    21fc:	f84a                	sd	s2,48(sp)
    21fe:	f44e                	sd	s3,40(sp)
    2200:	f052                	sd	s4,32(sp)
    for(b = a; b < a+TOOMUCH; b += 4096){
    2202:	400007b7          	lui	a5,0x40000
    2206:	97aa                	add	a5,a5,a0
      *b = 99;
    2208:	06300693          	li	a3,99
    for(b = a; b < a+TOOMUCH; b += 4096){
    220c:	6705                	lui	a4,0x1
      *b = 99;
    220e:	00d50023          	sb	a3,0(a0) # 40000000 <all_thread+0x3fff1378>
    for(b = a; b < a+TOOMUCH; b += 4096){
    2212:	953a                	add	a0,a0,a4
    2214:	fef51de3          	bne	a0,a5,220e <sbrkbasic+0x38>
    exit(1);
    2218:	4505                	li	a0,1
    221a:	2fb020ef          	jal	4d14 <exit>
    221e:	fc26                	sd	s1,56(sp)
    2220:	f84a                	sd	s2,48(sp)
    2222:	f44e                	sd	s3,40(sp)
    2224:	f052                	sd	s4,32(sp)
    printf("fork failed in sbrkbasic\n");
    2226:	00004517          	auipc	a0,0x4
    222a:	fa250513          	addi	a0,a0,-94 # 61c8 <thread_switch+0xd52>
    222e:	729020ef          	jal	5156 <printf>
    exit(1);
    2232:	4505                	li	a0,1
    2234:	2e1020ef          	jal	4d14 <exit>
    2238:	fc26                	sd	s1,56(sp)
    223a:	f84a                	sd	s2,48(sp)
    223c:	f44e                	sd	s3,40(sp)
    223e:	f052                	sd	s4,32(sp)
      exit(0);
    2240:	4501                	li	a0,0
    2242:	2d3020ef          	jal	4d14 <exit>
  wait(&xstatus);
    2246:	fbc40513          	addi	a0,s0,-68
    224a:	2d3020ef          	jal	4d1c <wait>
  if(xstatus == 1){
    224e:	fbc42703          	lw	a4,-68(s0)
    2252:	4785                	li	a5,1
    2254:	02f70063          	beq	a4,a5,2274 <sbrkbasic+0x9e>
    2258:	fc26                	sd	s1,56(sp)
    225a:	f84a                	sd	s2,48(sp)
    225c:	f44e                	sd	s3,40(sp)
    225e:	f052                	sd	s4,32(sp)
  a = sbrk(0);
    2260:	4501                	li	a0,0
    2262:	33b020ef          	jal	4d9c <sbrk>
    2266:	84aa                	mv	s1,a0
  for(i = 0; i < 5000; i++){
    2268:	4901                	li	s2,0
    b = sbrk(1);
    226a:	4985                	li	s3,1
  for(i = 0; i < 5000; i++){
    226c:	6a05                	lui	s4,0x1
    226e:	388a0a13          	addi	s4,s4,904 # 1388 <truncate3+0x14a>
    2272:	a005                	j	2292 <sbrkbasic+0xbc>
    2274:	fc26                	sd	s1,56(sp)
    2276:	f84a                	sd	s2,48(sp)
    2278:	f44e                	sd	s3,40(sp)
    227a:	f052                	sd	s4,32(sp)
    printf("%s: too much memory allocated!\n", s);
    227c:	85d6                	mv	a1,s5
    227e:	00004517          	auipc	a0,0x4
    2282:	f6a50513          	addi	a0,a0,-150 # 61e8 <thread_switch+0xd72>
    2286:	6d1020ef          	jal	5156 <printf>
    exit(1);
    228a:	4505                	li	a0,1
    228c:	289020ef          	jal	4d14 <exit>
  for(i = 0; i < 5000; i++){
    2290:	84be                	mv	s1,a5
    b = sbrk(1);
    2292:	854e                	mv	a0,s3
    2294:	309020ef          	jal	4d9c <sbrk>
    if(b != a){
    2298:	04951163          	bne	a0,s1,22da <sbrkbasic+0x104>
    *b = 1;
    229c:	01348023          	sb	s3,0(s1)
    a = b + 1;
    22a0:	00148793          	addi	a5,s1,1
  for(i = 0; i < 5000; i++){
    22a4:	2905                	addiw	s2,s2,1
    22a6:	ff4915e3          	bne	s2,s4,2290 <sbrkbasic+0xba>
  pid = fork();
    22aa:	263020ef          	jal	4d0c <fork>
    22ae:	892a                	mv	s2,a0
  if(pid < 0){
    22b0:	04054263          	bltz	a0,22f4 <sbrkbasic+0x11e>
  c = sbrk(1);
    22b4:	4505                	li	a0,1
    22b6:	2e7020ef          	jal	4d9c <sbrk>
  c = sbrk(1);
    22ba:	4505                	li	a0,1
    22bc:	2e1020ef          	jal	4d9c <sbrk>
  if(c != a + 1){
    22c0:	0489                	addi	s1,s1,2
    22c2:	04950363          	beq	a0,s1,2308 <sbrkbasic+0x132>
    printf("%s: sbrk test failed post-fork\n", s);
    22c6:	85d6                	mv	a1,s5
    22c8:	00004517          	auipc	a0,0x4
    22cc:	f8050513          	addi	a0,a0,-128 # 6248 <thread_switch+0xdd2>
    22d0:	687020ef          	jal	5156 <printf>
    exit(1);
    22d4:	4505                	li	a0,1
    22d6:	23f020ef          	jal	4d14 <exit>
      printf("%s: sbrk test failed %d %p %p\n", s, i, a, b);
    22da:	872a                	mv	a4,a0
    22dc:	86a6                	mv	a3,s1
    22de:	864a                	mv	a2,s2
    22e0:	85d6                	mv	a1,s5
    22e2:	00004517          	auipc	a0,0x4
    22e6:	f2650513          	addi	a0,a0,-218 # 6208 <thread_switch+0xd92>
    22ea:	66d020ef          	jal	5156 <printf>
      exit(1);
    22ee:	4505                	li	a0,1
    22f0:	225020ef          	jal	4d14 <exit>
    printf("%s: sbrk test fork failed\n", s);
    22f4:	85d6                	mv	a1,s5
    22f6:	00004517          	auipc	a0,0x4
    22fa:	f3250513          	addi	a0,a0,-206 # 6228 <thread_switch+0xdb2>
    22fe:	659020ef          	jal	5156 <printf>
    exit(1);
    2302:	4505                	li	a0,1
    2304:	211020ef          	jal	4d14 <exit>
  if(pid == 0)
    2308:	00091563          	bnez	s2,2312 <sbrkbasic+0x13c>
    exit(0);
    230c:	4501                	li	a0,0
    230e:	207020ef          	jal	4d14 <exit>
  wait(&xstatus);
    2312:	fbc40513          	addi	a0,s0,-68
    2316:	207020ef          	jal	4d1c <wait>
  exit(xstatus);
    231a:	fbc42503          	lw	a0,-68(s0)
    231e:	1f7020ef          	jal	4d14 <exit>

0000000000002322 <sbrkmuch>:
{
    2322:	7179                	addi	sp,sp,-48
    2324:	f406                	sd	ra,40(sp)
    2326:	f022                	sd	s0,32(sp)
    2328:	ec26                	sd	s1,24(sp)
    232a:	e84a                	sd	s2,16(sp)
    232c:	e44e                	sd	s3,8(sp)
    232e:	e052                	sd	s4,0(sp)
    2330:	1800                	addi	s0,sp,48
    2332:	89aa                	mv	s3,a0
  oldbrk = sbrk(0);
    2334:	4501                	li	a0,0
    2336:	267020ef          	jal	4d9c <sbrk>
    233a:	892a                	mv	s2,a0
  a = sbrk(0);
    233c:	4501                	li	a0,0
    233e:	25f020ef          	jal	4d9c <sbrk>
    2342:	84aa                	mv	s1,a0
  p = sbrk(amt);
    2344:	06400537          	lui	a0,0x6400
    2348:	9d05                	subw	a0,a0,s1
    234a:	253020ef          	jal	4d9c <sbrk>
  if (p != a) {
    234e:	0aa49463          	bne	s1,a0,23f6 <sbrkmuch+0xd4>
  char *eee = sbrk(0);
    2352:	4501                	li	a0,0
    2354:	249020ef          	jal	4d9c <sbrk>
    2358:	87aa                	mv	a5,a0
  for(char *pp = a; pp < eee; pp += 4096)
    235a:	00a4f963          	bgeu	s1,a0,236c <sbrkmuch+0x4a>
    *pp = 1;
    235e:	4685                	li	a3,1
  for(char *pp = a; pp < eee; pp += 4096)
    2360:	6705                	lui	a4,0x1
    *pp = 1;
    2362:	00d48023          	sb	a3,0(s1)
  for(char *pp = a; pp < eee; pp += 4096)
    2366:	94ba                	add	s1,s1,a4
    2368:	fef4ede3          	bltu	s1,a5,2362 <sbrkmuch+0x40>
  *lastaddr = 99;
    236c:	064007b7          	lui	a5,0x6400
    2370:	06300713          	li	a4,99
    2374:	fee78fa3          	sb	a4,-1(a5) # 63fffff <all_thread+0x63f1377>
  a = sbrk(0);
    2378:	4501                	li	a0,0
    237a:	223020ef          	jal	4d9c <sbrk>
    237e:	84aa                	mv	s1,a0
  c = sbrk(-PGSIZE);
    2380:	757d                	lui	a0,0xfffff
    2382:	21b020ef          	jal	4d9c <sbrk>
  if(c == (char*)0xffffffffffffffffL){
    2386:	57fd                	li	a5,-1
    2388:	08f50163          	beq	a0,a5,240a <sbrkmuch+0xe8>
  c = sbrk(0);
    238c:	4501                	li	a0,0
    238e:	20f020ef          	jal	4d9c <sbrk>
  if(c != a - PGSIZE){
    2392:	77fd                	lui	a5,0xfffff
    2394:	97a6                	add	a5,a5,s1
    2396:	08f51463          	bne	a0,a5,241e <sbrkmuch+0xfc>
  a = sbrk(0);
    239a:	4501                	li	a0,0
    239c:	201020ef          	jal	4d9c <sbrk>
    23a0:	84aa                	mv	s1,a0
  c = sbrk(PGSIZE);
    23a2:	6505                	lui	a0,0x1
    23a4:	1f9020ef          	jal	4d9c <sbrk>
    23a8:	8a2a                	mv	s4,a0
  if(c != a || sbrk(0) != a + PGSIZE){
    23aa:	08a49663          	bne	s1,a0,2436 <sbrkmuch+0x114>
    23ae:	4501                	li	a0,0
    23b0:	1ed020ef          	jal	4d9c <sbrk>
    23b4:	6785                	lui	a5,0x1
    23b6:	97a6                	add	a5,a5,s1
    23b8:	06f51f63          	bne	a0,a5,2436 <sbrkmuch+0x114>
  if(*lastaddr == 99){
    23bc:	064007b7          	lui	a5,0x6400
    23c0:	fff7c703          	lbu	a4,-1(a5) # 63fffff <all_thread+0x63f1377>
    23c4:	06300793          	li	a5,99
    23c8:	08f70363          	beq	a4,a5,244e <sbrkmuch+0x12c>
  a = sbrk(0);
    23cc:	4501                	li	a0,0
    23ce:	1cf020ef          	jal	4d9c <sbrk>
    23d2:	84aa                	mv	s1,a0
  c = sbrk(-(sbrk(0) - oldbrk));
    23d4:	4501                	li	a0,0
    23d6:	1c7020ef          	jal	4d9c <sbrk>
    23da:	40a9053b          	subw	a0,s2,a0
    23de:	1bf020ef          	jal	4d9c <sbrk>
  if(c != a){
    23e2:	08a49063          	bne	s1,a0,2462 <sbrkmuch+0x140>
}
    23e6:	70a2                	ld	ra,40(sp)
    23e8:	7402                	ld	s0,32(sp)
    23ea:	64e2                	ld	s1,24(sp)
    23ec:	6942                	ld	s2,16(sp)
    23ee:	69a2                	ld	s3,8(sp)
    23f0:	6a02                	ld	s4,0(sp)
    23f2:	6145                	addi	sp,sp,48
    23f4:	8082                	ret
    printf("%s: sbrk test failed to grow big address space; enough phys mem?\n", s);
    23f6:	85ce                	mv	a1,s3
    23f8:	00004517          	auipc	a0,0x4
    23fc:	e7050513          	addi	a0,a0,-400 # 6268 <thread_switch+0xdf2>
    2400:	557020ef          	jal	5156 <printf>
    exit(1);
    2404:	4505                	li	a0,1
    2406:	10f020ef          	jal	4d14 <exit>
    printf("%s: sbrk could not deallocate\n", s);
    240a:	85ce                	mv	a1,s3
    240c:	00004517          	auipc	a0,0x4
    2410:	ea450513          	addi	a0,a0,-348 # 62b0 <thread_switch+0xe3a>
    2414:	543020ef          	jal	5156 <printf>
    exit(1);
    2418:	4505                	li	a0,1
    241a:	0fb020ef          	jal	4d14 <exit>
    printf("%s: sbrk deallocation produced wrong address, a %p c %p\n", s, a, c);
    241e:	86aa                	mv	a3,a0
    2420:	8626                	mv	a2,s1
    2422:	85ce                	mv	a1,s3
    2424:	00004517          	auipc	a0,0x4
    2428:	eac50513          	addi	a0,a0,-340 # 62d0 <thread_switch+0xe5a>
    242c:	52b020ef          	jal	5156 <printf>
    exit(1);
    2430:	4505                	li	a0,1
    2432:	0e3020ef          	jal	4d14 <exit>
    printf("%s: sbrk re-allocation failed, a %p c %p\n", s, a, c);
    2436:	86d2                	mv	a3,s4
    2438:	8626                	mv	a2,s1
    243a:	85ce                	mv	a1,s3
    243c:	00004517          	auipc	a0,0x4
    2440:	ed450513          	addi	a0,a0,-300 # 6310 <thread_switch+0xe9a>
    2444:	513020ef          	jal	5156 <printf>
    exit(1);
    2448:	4505                	li	a0,1
    244a:	0cb020ef          	jal	4d14 <exit>
    printf("%s: sbrk de-allocation didn't really deallocate\n", s);
    244e:	85ce                	mv	a1,s3
    2450:	00004517          	auipc	a0,0x4
    2454:	ef050513          	addi	a0,a0,-272 # 6340 <thread_switch+0xeca>
    2458:	4ff020ef          	jal	5156 <printf>
    exit(1);
    245c:	4505                	li	a0,1
    245e:	0b7020ef          	jal	4d14 <exit>
    printf("%s: sbrk downsize failed, a %p c %p\n", s, a, c);
    2462:	86aa                	mv	a3,a0
    2464:	8626                	mv	a2,s1
    2466:	85ce                	mv	a1,s3
    2468:	00004517          	auipc	a0,0x4
    246c:	f1050513          	addi	a0,a0,-240 # 6378 <thread_switch+0xf02>
    2470:	4e7020ef          	jal	5156 <printf>
    exit(1);
    2474:	4505                	li	a0,1
    2476:	09f020ef          	jal	4d14 <exit>

000000000000247a <sbrkarg>:
{
    247a:	7179                	addi	sp,sp,-48
    247c:	f406                	sd	ra,40(sp)
    247e:	f022                	sd	s0,32(sp)
    2480:	ec26                	sd	s1,24(sp)
    2482:	e84a                	sd	s2,16(sp)
    2484:	e44e                	sd	s3,8(sp)
    2486:	1800                	addi	s0,sp,48
    2488:	89aa                	mv	s3,a0
  a = sbrk(PGSIZE);
    248a:	6505                	lui	a0,0x1
    248c:	111020ef          	jal	4d9c <sbrk>
    2490:	892a                	mv	s2,a0
  fd = open("sbrk", O_CREATE|O_WRONLY);
    2492:	20100593          	li	a1,513
    2496:	00004517          	auipc	a0,0x4
    249a:	f0a50513          	addi	a0,a0,-246 # 63a0 <thread_switch+0xf2a>
    249e:	0b7020ef          	jal	4d54 <open>
    24a2:	84aa                	mv	s1,a0
  unlink("sbrk");
    24a4:	00004517          	auipc	a0,0x4
    24a8:	efc50513          	addi	a0,a0,-260 # 63a0 <thread_switch+0xf2a>
    24ac:	0b9020ef          	jal	4d64 <unlink>
  if(fd < 0)  {
    24b0:	0204c963          	bltz	s1,24e2 <sbrkarg+0x68>
  if ((n = write(fd, a, PGSIZE)) < 0) {
    24b4:	6605                	lui	a2,0x1
    24b6:	85ca                	mv	a1,s2
    24b8:	8526                	mv	a0,s1
    24ba:	07b020ef          	jal	4d34 <write>
    24be:	02054c63          	bltz	a0,24f6 <sbrkarg+0x7c>
  close(fd);
    24c2:	8526                	mv	a0,s1
    24c4:	079020ef          	jal	4d3c <close>
  a = sbrk(PGSIZE);
    24c8:	6505                	lui	a0,0x1
    24ca:	0d3020ef          	jal	4d9c <sbrk>
  if(pipe((int *) a) != 0){
    24ce:	057020ef          	jal	4d24 <pipe>
    24d2:	ed05                	bnez	a0,250a <sbrkarg+0x90>
}
    24d4:	70a2                	ld	ra,40(sp)
    24d6:	7402                	ld	s0,32(sp)
    24d8:	64e2                	ld	s1,24(sp)
    24da:	6942                	ld	s2,16(sp)
    24dc:	69a2                	ld	s3,8(sp)
    24de:	6145                	addi	sp,sp,48
    24e0:	8082                	ret
    printf("%s: open sbrk failed\n", s);
    24e2:	85ce                	mv	a1,s3
    24e4:	00004517          	auipc	a0,0x4
    24e8:	ec450513          	addi	a0,a0,-316 # 63a8 <thread_switch+0xf32>
    24ec:	46b020ef          	jal	5156 <printf>
    exit(1);
    24f0:	4505                	li	a0,1
    24f2:	023020ef          	jal	4d14 <exit>
    printf("%s: write sbrk failed\n", s);
    24f6:	85ce                	mv	a1,s3
    24f8:	00004517          	auipc	a0,0x4
    24fc:	ec850513          	addi	a0,a0,-312 # 63c0 <thread_switch+0xf4a>
    2500:	457020ef          	jal	5156 <printf>
    exit(1);
    2504:	4505                	li	a0,1
    2506:	00f020ef          	jal	4d14 <exit>
    printf("%s: pipe() failed\n", s);
    250a:	85ce                	mv	a1,s3
    250c:	00004517          	auipc	a0,0x4
    2510:	9a450513          	addi	a0,a0,-1628 # 5eb0 <thread_switch+0xa3a>
    2514:	443020ef          	jal	5156 <printf>
    exit(1);
    2518:	4505                	li	a0,1
    251a:	7fa020ef          	jal	4d14 <exit>

000000000000251e <argptest>:
{
    251e:	1101                	addi	sp,sp,-32
    2520:	ec06                	sd	ra,24(sp)
    2522:	e822                	sd	s0,16(sp)
    2524:	e426                	sd	s1,8(sp)
    2526:	e04a                	sd	s2,0(sp)
    2528:	1000                	addi	s0,sp,32
    252a:	892a                	mv	s2,a0
  fd = open("init", O_RDONLY);
    252c:	4581                	li	a1,0
    252e:	00004517          	auipc	a0,0x4
    2532:	eaa50513          	addi	a0,a0,-342 # 63d8 <thread_switch+0xf62>
    2536:	01f020ef          	jal	4d54 <open>
  if (fd < 0) {
    253a:	02054563          	bltz	a0,2564 <argptest+0x46>
    253e:	84aa                	mv	s1,a0
  read(fd, sbrk(0) - 1, -1);
    2540:	4501                	li	a0,0
    2542:	05b020ef          	jal	4d9c <sbrk>
    2546:	567d                	li	a2,-1
    2548:	00c505b3          	add	a1,a0,a2
    254c:	8526                	mv	a0,s1
    254e:	7de020ef          	jal	4d2c <read>
  close(fd);
    2552:	8526                	mv	a0,s1
    2554:	7e8020ef          	jal	4d3c <close>
}
    2558:	60e2                	ld	ra,24(sp)
    255a:	6442                	ld	s0,16(sp)
    255c:	64a2                	ld	s1,8(sp)
    255e:	6902                	ld	s2,0(sp)
    2560:	6105                	addi	sp,sp,32
    2562:	8082                	ret
    printf("%s: open failed\n", s);
    2564:	85ca                	mv	a1,s2
    2566:	00004517          	auipc	a0,0x4
    256a:	85a50513          	addi	a0,a0,-1958 # 5dc0 <thread_switch+0x94a>
    256e:	3e9020ef          	jal	5156 <printf>
    exit(1);
    2572:	4505                	li	a0,1
    2574:	7a0020ef          	jal	4d14 <exit>

0000000000002578 <sbrkbugs>:
{
    2578:	1141                	addi	sp,sp,-16
    257a:	e406                	sd	ra,8(sp)
    257c:	e022                	sd	s0,0(sp)
    257e:	0800                	addi	s0,sp,16
  int pid = fork();
    2580:	78c020ef          	jal	4d0c <fork>
  if(pid < 0){
    2584:	00054c63          	bltz	a0,259c <sbrkbugs+0x24>
  if(pid == 0){
    2588:	e11d                	bnez	a0,25ae <sbrkbugs+0x36>
    int sz = (uint64) sbrk(0);
    258a:	013020ef          	jal	4d9c <sbrk>
    sbrk(-sz);
    258e:	40a0053b          	negw	a0,a0
    2592:	00b020ef          	jal	4d9c <sbrk>
    exit(0);
    2596:	4501                	li	a0,0
    2598:	77c020ef          	jal	4d14 <exit>
    printf("fork failed\n");
    259c:	00005517          	auipc	a0,0x5
    25a0:	d7c50513          	addi	a0,a0,-644 # 7318 <thread_switch+0x1ea2>
    25a4:	3b3020ef          	jal	5156 <printf>
    exit(1);
    25a8:	4505                	li	a0,1
    25aa:	76a020ef          	jal	4d14 <exit>
  wait(0);
    25ae:	4501                	li	a0,0
    25b0:	76c020ef          	jal	4d1c <wait>
  pid = fork();
    25b4:	758020ef          	jal	4d0c <fork>
  if(pid < 0){
    25b8:	00054f63          	bltz	a0,25d6 <sbrkbugs+0x5e>
  if(pid == 0){
    25bc:	e515                	bnez	a0,25e8 <sbrkbugs+0x70>
    int sz = (uint64) sbrk(0);
    25be:	7de020ef          	jal	4d9c <sbrk>
    sbrk(-(sz - 3500));
    25c2:	6785                	lui	a5,0x1
    25c4:	dac7879b          	addiw	a5,a5,-596 # dac <linktest+0xe2>
    25c8:	40a7853b          	subw	a0,a5,a0
    25cc:	7d0020ef          	jal	4d9c <sbrk>
    exit(0);
    25d0:	4501                	li	a0,0
    25d2:	742020ef          	jal	4d14 <exit>
    printf("fork failed\n");
    25d6:	00005517          	auipc	a0,0x5
    25da:	d4250513          	addi	a0,a0,-702 # 7318 <thread_switch+0x1ea2>
    25de:	379020ef          	jal	5156 <printf>
    exit(1);
    25e2:	4505                	li	a0,1
    25e4:	730020ef          	jal	4d14 <exit>
  wait(0);
    25e8:	4501                	li	a0,0
    25ea:	732020ef          	jal	4d1c <wait>
  pid = fork();
    25ee:	71e020ef          	jal	4d0c <fork>
  if(pid < 0){
    25f2:	02054263          	bltz	a0,2616 <sbrkbugs+0x9e>
  if(pid == 0){
    25f6:	e90d                	bnez	a0,2628 <sbrkbugs+0xb0>
    sbrk((10*4096 + 2048) - (uint64)sbrk(0));
    25f8:	7a4020ef          	jal	4d9c <sbrk>
    25fc:	67ad                	lui	a5,0xb
    25fe:	8007879b          	addiw	a5,a5,-2048 # a800 <uninit+0x1298>
    2602:	40a7853b          	subw	a0,a5,a0
    2606:	796020ef          	jal	4d9c <sbrk>
    sbrk(-10);
    260a:	5559                	li	a0,-10
    260c:	790020ef          	jal	4d9c <sbrk>
    exit(0);
    2610:	4501                	li	a0,0
    2612:	702020ef          	jal	4d14 <exit>
    printf("fork failed\n");
    2616:	00005517          	auipc	a0,0x5
    261a:	d0250513          	addi	a0,a0,-766 # 7318 <thread_switch+0x1ea2>
    261e:	339020ef          	jal	5156 <printf>
    exit(1);
    2622:	4505                	li	a0,1
    2624:	6f0020ef          	jal	4d14 <exit>
  wait(0);
    2628:	4501                	li	a0,0
    262a:	6f2020ef          	jal	4d1c <wait>
  exit(0);
    262e:	4501                	li	a0,0
    2630:	6e4020ef          	jal	4d14 <exit>

0000000000002634 <sbrklast>:
{
    2634:	7179                	addi	sp,sp,-48
    2636:	f406                	sd	ra,40(sp)
    2638:	f022                	sd	s0,32(sp)
    263a:	ec26                	sd	s1,24(sp)
    263c:	e84a                	sd	s2,16(sp)
    263e:	e44e                	sd	s3,8(sp)
    2640:	e052                	sd	s4,0(sp)
    2642:	1800                	addi	s0,sp,48
  uint64 top = (uint64) sbrk(0);
    2644:	4501                	li	a0,0
    2646:	756020ef          	jal	4d9c <sbrk>
  if((top % 4096) != 0)
    264a:	03451793          	slli	a5,a0,0x34
    264e:	ebad                	bnez	a5,26c0 <sbrklast+0x8c>
  sbrk(4096);
    2650:	6505                	lui	a0,0x1
    2652:	74a020ef          	jal	4d9c <sbrk>
  sbrk(10);
    2656:	4529                	li	a0,10
    2658:	744020ef          	jal	4d9c <sbrk>
  sbrk(-20);
    265c:	5531                	li	a0,-20
    265e:	73e020ef          	jal	4d9c <sbrk>
  top = (uint64) sbrk(0);
    2662:	4501                	li	a0,0
    2664:	738020ef          	jal	4d9c <sbrk>
    2668:	84aa                	mv	s1,a0
  char *p = (char *) (top - 64);
    266a:	fc050913          	addi	s2,a0,-64 # fc0 <bigdir+0xcc>
  p[0] = 'x';
    266e:	07800993          	li	s3,120
    2672:	fd350023          	sb	s3,-64(a0)
  p[1] = '\0';
    2676:	fc0500a3          	sb	zero,-63(a0)
  int fd = open(p, O_RDWR|O_CREATE);
    267a:	20200593          	li	a1,514
    267e:	854a                	mv	a0,s2
    2680:	6d4020ef          	jal	4d54 <open>
    2684:	8a2a                	mv	s4,a0
  write(fd, p, 1);
    2686:	4605                	li	a2,1
    2688:	85ca                	mv	a1,s2
    268a:	6aa020ef          	jal	4d34 <write>
  close(fd);
    268e:	8552                	mv	a0,s4
    2690:	6ac020ef          	jal	4d3c <close>
  fd = open(p, O_RDWR);
    2694:	4589                	li	a1,2
    2696:	854a                	mv	a0,s2
    2698:	6bc020ef          	jal	4d54 <open>
  p[0] = '\0';
    269c:	fc048023          	sb	zero,-64(s1)
  read(fd, p, 1);
    26a0:	4605                	li	a2,1
    26a2:	85ca                	mv	a1,s2
    26a4:	688020ef          	jal	4d2c <read>
  if(p[0] != 'x')
    26a8:	fc04c783          	lbu	a5,-64(s1)
    26ac:	03379263          	bne	a5,s3,26d0 <sbrklast+0x9c>
}
    26b0:	70a2                	ld	ra,40(sp)
    26b2:	7402                	ld	s0,32(sp)
    26b4:	64e2                	ld	s1,24(sp)
    26b6:	6942                	ld	s2,16(sp)
    26b8:	69a2                	ld	s3,8(sp)
    26ba:	6a02                	ld	s4,0(sp)
    26bc:	6145                	addi	sp,sp,48
    26be:	8082                	ret
    sbrk(4096 - (top % 4096));
    26c0:	0347d513          	srli	a0,a5,0x34
    26c4:	6785                	lui	a5,0x1
    26c6:	40a7853b          	subw	a0,a5,a0
    26ca:	6d2020ef          	jal	4d9c <sbrk>
    26ce:	b749                	j	2650 <sbrklast+0x1c>
    exit(1);
    26d0:	4505                	li	a0,1
    26d2:	642020ef          	jal	4d14 <exit>

00000000000026d6 <sbrk8000>:
{
    26d6:	1141                	addi	sp,sp,-16
    26d8:	e406                	sd	ra,8(sp)
    26da:	e022                	sd	s0,0(sp)
    26dc:	0800                	addi	s0,sp,16
  sbrk(0x80000004);
    26de:	80000537          	lui	a0,0x80000
    26e2:	0511                	addi	a0,a0,4 # ffffffff80000004 <all_thread+0xffffffff7fff137c>
    26e4:	6b8020ef          	jal	4d9c <sbrk>
  volatile char *top = sbrk(0);
    26e8:	4501                	li	a0,0
    26ea:	6b2020ef          	jal	4d9c <sbrk>
  *(top-1) = *(top-1) + 1;
    26ee:	fff54783          	lbu	a5,-1(a0)
    26f2:	2785                	addiw	a5,a5,1 # 1001 <bigdir+0x10d>
    26f4:	fef50fa3          	sb	a5,-1(a0)
}
    26f8:	60a2                	ld	ra,8(sp)
    26fa:	6402                	ld	s0,0(sp)
    26fc:	0141                	addi	sp,sp,16
    26fe:	8082                	ret

0000000000002700 <execout>:
{
    2700:	711d                	addi	sp,sp,-96
    2702:	ec86                	sd	ra,88(sp)
    2704:	e8a2                	sd	s0,80(sp)
    2706:	e4a6                	sd	s1,72(sp)
    2708:	e0ca                	sd	s2,64(sp)
    270a:	fc4e                	sd	s3,56(sp)
    270c:	1080                	addi	s0,sp,96
  for(int avail = 0; avail < 15; avail++){
    270e:	4901                	li	s2,0
    2710:	49bd                	li	s3,15
    int pid = fork();
    2712:	5fa020ef          	jal	4d0c <fork>
    2716:	84aa                	mv	s1,a0
    if(pid < 0){
    2718:	00054e63          	bltz	a0,2734 <execout+0x34>
    } else if(pid == 0){
    271c:	c51d                	beqz	a0,274a <execout+0x4a>
      wait((int*)0);
    271e:	4501                	li	a0,0
    2720:	5fc020ef          	jal	4d1c <wait>
  for(int avail = 0; avail < 15; avail++){
    2724:	2905                	addiw	s2,s2,1
    2726:	ff3916e3          	bne	s2,s3,2712 <execout+0x12>
    272a:	f852                	sd	s4,48(sp)
    272c:	f456                	sd	s5,40(sp)
  exit(0);
    272e:	4501                	li	a0,0
    2730:	5e4020ef          	jal	4d14 <exit>
    2734:	f852                	sd	s4,48(sp)
    2736:	f456                	sd	s5,40(sp)
      printf("fork failed\n");
    2738:	00005517          	auipc	a0,0x5
    273c:	be050513          	addi	a0,a0,-1056 # 7318 <thread_switch+0x1ea2>
    2740:	217020ef          	jal	5156 <printf>
      exit(1);
    2744:	4505                	li	a0,1
    2746:	5ce020ef          	jal	4d14 <exit>
    274a:	f852                	sd	s4,48(sp)
    274c:	f456                	sd	s5,40(sp)
        uint64 a = (uint64) sbrk(4096);
    274e:	6985                	lui	s3,0x1
        if(a == 0xffffffffffffffffLL)
    2750:	5a7d                	li	s4,-1
        *(char*)(a + 4096 - 1) = 1;
    2752:	4a85                	li	s5,1
        uint64 a = (uint64) sbrk(4096);
    2754:	854e                	mv	a0,s3
    2756:	646020ef          	jal	4d9c <sbrk>
        if(a == 0xffffffffffffffffLL)
    275a:	01450663          	beq	a0,s4,2766 <execout+0x66>
        *(char*)(a + 4096 - 1) = 1;
    275e:	954e                	add	a0,a0,s3
    2760:	ff550fa3          	sb	s5,-1(a0)
      while(1){
    2764:	bfc5                	j	2754 <execout+0x54>
        sbrk(-4096);
    2766:	79fd                	lui	s3,0xfffff
      for(int i = 0; i < avail; i++)
    2768:	01205863          	blez	s2,2778 <execout+0x78>
        sbrk(-4096);
    276c:	854e                	mv	a0,s3
    276e:	62e020ef          	jal	4d9c <sbrk>
      for(int i = 0; i < avail; i++)
    2772:	2485                	addiw	s1,s1,1
    2774:	ff249ce3          	bne	s1,s2,276c <execout+0x6c>
      close(1);
    2778:	4505                	li	a0,1
    277a:	5c2020ef          	jal	4d3c <close>
      char *args[] = { "echo", "x", 0 };
    277e:	00003797          	auipc	a5,0x3
    2782:	d9a78793          	addi	a5,a5,-614 # 5518 <thread_switch+0xa2>
    2786:	faf43423          	sd	a5,-88(s0)
    278a:	00003797          	auipc	a5,0x3
    278e:	dfe78793          	addi	a5,a5,-514 # 5588 <thread_switch+0x112>
    2792:	faf43823          	sd	a5,-80(s0)
    2796:	fa043c23          	sd	zero,-72(s0)
      exec("echo", args);
    279a:	fa840593          	addi	a1,s0,-88
    279e:	00003517          	auipc	a0,0x3
    27a2:	d7a50513          	addi	a0,a0,-646 # 5518 <thread_switch+0xa2>
    27a6:	5a6020ef          	jal	4d4c <exec>
      exit(0);
    27aa:	4501                	li	a0,0
    27ac:	568020ef          	jal	4d14 <exit>

00000000000027b0 <fourteen>:
{
    27b0:	1101                	addi	sp,sp,-32
    27b2:	ec06                	sd	ra,24(sp)
    27b4:	e822                	sd	s0,16(sp)
    27b6:	e426                	sd	s1,8(sp)
    27b8:	1000                	addi	s0,sp,32
    27ba:	84aa                	mv	s1,a0
  if(mkdir("12345678901234") != 0){
    27bc:	00004517          	auipc	a0,0x4
    27c0:	df450513          	addi	a0,a0,-524 # 65b0 <thread_switch+0x113a>
    27c4:	5b8020ef          	jal	4d7c <mkdir>
    27c8:	e555                	bnez	a0,2874 <fourteen+0xc4>
  if(mkdir("12345678901234/123456789012345") != 0){
    27ca:	00004517          	auipc	a0,0x4
    27ce:	c3e50513          	addi	a0,a0,-962 # 6408 <thread_switch+0xf92>
    27d2:	5aa020ef          	jal	4d7c <mkdir>
    27d6:	e94d                	bnez	a0,2888 <fourteen+0xd8>
  fd = open("123456789012345/123456789012345/123456789012345", O_CREATE);
    27d8:	20000593          	li	a1,512
    27dc:	00004517          	auipc	a0,0x4
    27e0:	c8450513          	addi	a0,a0,-892 # 6460 <thread_switch+0xfea>
    27e4:	570020ef          	jal	4d54 <open>
  if(fd < 0){
    27e8:	0a054a63          	bltz	a0,289c <fourteen+0xec>
  close(fd);
    27ec:	550020ef          	jal	4d3c <close>
  fd = open("12345678901234/12345678901234/12345678901234", 0);
    27f0:	4581                	li	a1,0
    27f2:	00004517          	auipc	a0,0x4
    27f6:	ce650513          	addi	a0,a0,-794 # 64d8 <thread_switch+0x1062>
    27fa:	55a020ef          	jal	4d54 <open>
  if(fd < 0){
    27fe:	0a054963          	bltz	a0,28b0 <fourteen+0x100>
  close(fd);
    2802:	53a020ef          	jal	4d3c <close>
  if(mkdir("12345678901234/12345678901234") == 0){
    2806:	00004517          	auipc	a0,0x4
    280a:	d4250513          	addi	a0,a0,-702 # 6548 <thread_switch+0x10d2>
    280e:	56e020ef          	jal	4d7c <mkdir>
    2812:	c94d                	beqz	a0,28c4 <fourteen+0x114>
  if(mkdir("123456789012345/12345678901234") == 0){
    2814:	00004517          	auipc	a0,0x4
    2818:	d8c50513          	addi	a0,a0,-628 # 65a0 <thread_switch+0x112a>
    281c:	560020ef          	jal	4d7c <mkdir>
    2820:	cd45                	beqz	a0,28d8 <fourteen+0x128>
  unlink("123456789012345/12345678901234");
    2822:	00004517          	auipc	a0,0x4
    2826:	d7e50513          	addi	a0,a0,-642 # 65a0 <thread_switch+0x112a>
    282a:	53a020ef          	jal	4d64 <unlink>
  unlink("12345678901234/12345678901234");
    282e:	00004517          	auipc	a0,0x4
    2832:	d1a50513          	addi	a0,a0,-742 # 6548 <thread_switch+0x10d2>
    2836:	52e020ef          	jal	4d64 <unlink>
  unlink("12345678901234/12345678901234/12345678901234");
    283a:	00004517          	auipc	a0,0x4
    283e:	c9e50513          	addi	a0,a0,-866 # 64d8 <thread_switch+0x1062>
    2842:	522020ef          	jal	4d64 <unlink>
  unlink("123456789012345/123456789012345/123456789012345");
    2846:	00004517          	auipc	a0,0x4
    284a:	c1a50513          	addi	a0,a0,-998 # 6460 <thread_switch+0xfea>
    284e:	516020ef          	jal	4d64 <unlink>
  unlink("12345678901234/123456789012345");
    2852:	00004517          	auipc	a0,0x4
    2856:	bb650513          	addi	a0,a0,-1098 # 6408 <thread_switch+0xf92>
    285a:	50a020ef          	jal	4d64 <unlink>
  unlink("12345678901234");
    285e:	00004517          	auipc	a0,0x4
    2862:	d5250513          	addi	a0,a0,-686 # 65b0 <thread_switch+0x113a>
    2866:	4fe020ef          	jal	4d64 <unlink>
}
    286a:	60e2                	ld	ra,24(sp)
    286c:	6442                	ld	s0,16(sp)
    286e:	64a2                	ld	s1,8(sp)
    2870:	6105                	addi	sp,sp,32
    2872:	8082                	ret
    printf("%s: mkdir 12345678901234 failed\n", s);
    2874:	85a6                	mv	a1,s1
    2876:	00004517          	auipc	a0,0x4
    287a:	b6a50513          	addi	a0,a0,-1174 # 63e0 <thread_switch+0xf6a>
    287e:	0d9020ef          	jal	5156 <printf>
    exit(1);
    2882:	4505                	li	a0,1
    2884:	490020ef          	jal	4d14 <exit>
    printf("%s: mkdir 12345678901234/123456789012345 failed\n", s);
    2888:	85a6                	mv	a1,s1
    288a:	00004517          	auipc	a0,0x4
    288e:	b9e50513          	addi	a0,a0,-1122 # 6428 <thread_switch+0xfb2>
    2892:	0c5020ef          	jal	5156 <printf>
    exit(1);
    2896:	4505                	li	a0,1
    2898:	47c020ef          	jal	4d14 <exit>
    printf("%s: create 123456789012345/123456789012345/123456789012345 failed\n", s);
    289c:	85a6                	mv	a1,s1
    289e:	00004517          	auipc	a0,0x4
    28a2:	bf250513          	addi	a0,a0,-1038 # 6490 <thread_switch+0x101a>
    28a6:	0b1020ef          	jal	5156 <printf>
    exit(1);
    28aa:	4505                	li	a0,1
    28ac:	468020ef          	jal	4d14 <exit>
    printf("%s: open 12345678901234/12345678901234/12345678901234 failed\n", s);
    28b0:	85a6                	mv	a1,s1
    28b2:	00004517          	auipc	a0,0x4
    28b6:	c5650513          	addi	a0,a0,-938 # 6508 <thread_switch+0x1092>
    28ba:	09d020ef          	jal	5156 <printf>
    exit(1);
    28be:	4505                	li	a0,1
    28c0:	454020ef          	jal	4d14 <exit>
    printf("%s: mkdir 12345678901234/12345678901234 succeeded!\n", s);
    28c4:	85a6                	mv	a1,s1
    28c6:	00004517          	auipc	a0,0x4
    28ca:	ca250513          	addi	a0,a0,-862 # 6568 <thread_switch+0x10f2>
    28ce:	089020ef          	jal	5156 <printf>
    exit(1);
    28d2:	4505                	li	a0,1
    28d4:	440020ef          	jal	4d14 <exit>
    printf("%s: mkdir 12345678901234/123456789012345 succeeded!\n", s);
    28d8:	85a6                	mv	a1,s1
    28da:	00004517          	auipc	a0,0x4
    28de:	ce650513          	addi	a0,a0,-794 # 65c0 <thread_switch+0x114a>
    28e2:	075020ef          	jal	5156 <printf>
    exit(1);
    28e6:	4505                	li	a0,1
    28e8:	42c020ef          	jal	4d14 <exit>

00000000000028ec <diskfull>:
{
    28ec:	b6010113          	addi	sp,sp,-1184
    28f0:	48113c23          	sd	ra,1176(sp)
    28f4:	48813823          	sd	s0,1168(sp)
    28f8:	48913423          	sd	s1,1160(sp)
    28fc:	49213023          	sd	s2,1152(sp)
    2900:	47313c23          	sd	s3,1144(sp)
    2904:	47413823          	sd	s4,1136(sp)
    2908:	47513423          	sd	s5,1128(sp)
    290c:	47613023          	sd	s6,1120(sp)
    2910:	45713c23          	sd	s7,1112(sp)
    2914:	45813823          	sd	s8,1104(sp)
    2918:	45913423          	sd	s9,1096(sp)
    291c:	45a13023          	sd	s10,1088(sp)
    2920:	43b13c23          	sd	s11,1080(sp)
    2924:	4a010413          	addi	s0,sp,1184
    2928:	b6a43423          	sd	a0,-1176(s0)
  unlink("diskfulldir");
    292c:	00004517          	auipc	a0,0x4
    2930:	ccc50513          	addi	a0,a0,-820 # 65f8 <thread_switch+0x1182>
    2934:	430020ef          	jal	4d64 <unlink>
    2938:	03000a93          	li	s5,48
    name[0] = 'b';
    293c:	06200d13          	li	s10,98
    name[1] = 'i';
    2940:	06900c93          	li	s9,105
    name[2] = 'g';
    2944:	06700c13          	li	s8,103
    unlink(name);
    2948:	b7040b13          	addi	s6,s0,-1168
    int fd = open(name, O_CREATE|O_RDWR|O_TRUNC);
    294c:	60200b93          	li	s7,1538
    if(fd < 0){
    2950:	10c00d93          	li	s11,268
      if(write(fd, buf, BSIZE) != BSIZE){
    2954:	b9040a13          	addi	s4,s0,-1136
    2958:	aa8d                	j	2aca <diskfull+0x1de>
      printf("%s: could not create file %s\n", s, name);
    295a:	b7040613          	addi	a2,s0,-1168
    295e:	b6843583          	ld	a1,-1176(s0)
    2962:	00004517          	auipc	a0,0x4
    2966:	ca650513          	addi	a0,a0,-858 # 6608 <thread_switch+0x1192>
    296a:	7ec020ef          	jal	5156 <printf>
      break;
    296e:	a039                	j	297c <diskfull+0x90>
        close(fd);
    2970:	854e                	mv	a0,s3
    2972:	3ca020ef          	jal	4d3c <close>
    close(fd);
    2976:	854e                	mv	a0,s3
    2978:	3c4020ef          	jal	4d3c <close>
  for(int i = 0; i < nzz; i++){
    297c:	4481                	li	s1,0
    name[0] = 'z';
    297e:	07a00993          	li	s3,122
    unlink(name);
    2982:	b9040913          	addi	s2,s0,-1136
    int fd = open(name, O_CREATE|O_RDWR|O_TRUNC);
    2986:	60200a13          	li	s4,1538
  for(int i = 0; i < nzz; i++){
    298a:	08000a93          	li	s5,128
    name[0] = 'z';
    298e:	b9340823          	sb	s3,-1136(s0)
    name[1] = 'z';
    2992:	b93408a3          	sb	s3,-1135(s0)
    name[2] = '0' + (i / 32);
    2996:	41f4d71b          	sraiw	a4,s1,0x1f
    299a:	01b7571b          	srliw	a4,a4,0x1b
    299e:	009707bb          	addw	a5,a4,s1
    29a2:	4057d69b          	sraiw	a3,a5,0x5
    29a6:	0306869b          	addiw	a3,a3,48
    29aa:	b8d40923          	sb	a3,-1134(s0)
    name[3] = '0' + (i % 32);
    29ae:	8bfd                	andi	a5,a5,31
    29b0:	9f99                	subw	a5,a5,a4
    29b2:	0307879b          	addiw	a5,a5,48
    29b6:	b8f409a3          	sb	a5,-1133(s0)
    name[4] = '\0';
    29ba:	b8040a23          	sb	zero,-1132(s0)
    unlink(name);
    29be:	854a                	mv	a0,s2
    29c0:	3a4020ef          	jal	4d64 <unlink>
    int fd = open(name, O_CREATE|O_RDWR|O_TRUNC);
    29c4:	85d2                	mv	a1,s4
    29c6:	854a                	mv	a0,s2
    29c8:	38c020ef          	jal	4d54 <open>
    if(fd < 0)
    29cc:	00054763          	bltz	a0,29da <diskfull+0xee>
    close(fd);
    29d0:	36c020ef          	jal	4d3c <close>
  for(int i = 0; i < nzz; i++){
    29d4:	2485                	addiw	s1,s1,1
    29d6:	fb549ce3          	bne	s1,s5,298e <diskfull+0xa2>
  if(mkdir("diskfulldir") == 0)
    29da:	00004517          	auipc	a0,0x4
    29de:	c1e50513          	addi	a0,a0,-994 # 65f8 <thread_switch+0x1182>
    29e2:	39a020ef          	jal	4d7c <mkdir>
    29e6:	12050363          	beqz	a0,2b0c <diskfull+0x220>
  unlink("diskfulldir");
    29ea:	00004517          	auipc	a0,0x4
    29ee:	c0e50513          	addi	a0,a0,-1010 # 65f8 <thread_switch+0x1182>
    29f2:	372020ef          	jal	4d64 <unlink>
  for(int i = 0; i < nzz; i++){
    29f6:	4481                	li	s1,0
    name[0] = 'z';
    29f8:	07a00913          	li	s2,122
    unlink(name);
    29fc:	b9040a13          	addi	s4,s0,-1136
  for(int i = 0; i < nzz; i++){
    2a00:	08000993          	li	s3,128
    name[0] = 'z';
    2a04:	b9240823          	sb	s2,-1136(s0)
    name[1] = 'z';
    2a08:	b92408a3          	sb	s2,-1135(s0)
    name[2] = '0' + (i / 32);
    2a0c:	41f4d71b          	sraiw	a4,s1,0x1f
    2a10:	01b7571b          	srliw	a4,a4,0x1b
    2a14:	009707bb          	addw	a5,a4,s1
    2a18:	4057d69b          	sraiw	a3,a5,0x5
    2a1c:	0306869b          	addiw	a3,a3,48
    2a20:	b8d40923          	sb	a3,-1134(s0)
    name[3] = '0' + (i % 32);
    2a24:	8bfd                	andi	a5,a5,31
    2a26:	9f99                	subw	a5,a5,a4
    2a28:	0307879b          	addiw	a5,a5,48
    2a2c:	b8f409a3          	sb	a5,-1133(s0)
    name[4] = '\0';
    2a30:	b8040a23          	sb	zero,-1132(s0)
    unlink(name);
    2a34:	8552                	mv	a0,s4
    2a36:	32e020ef          	jal	4d64 <unlink>
  for(int i = 0; i < nzz; i++){
    2a3a:	2485                	addiw	s1,s1,1
    2a3c:	fd3494e3          	bne	s1,s3,2a04 <diskfull+0x118>
    2a40:	03000493          	li	s1,48
    name[0] = 'b';
    2a44:	06200b13          	li	s6,98
    name[1] = 'i';
    2a48:	06900a93          	li	s5,105
    name[2] = 'g';
    2a4c:	06700a13          	li	s4,103
    unlink(name);
    2a50:	b9040993          	addi	s3,s0,-1136
  for(int i = 0; '0' + i < 0177; i++){
    2a54:	07f00913          	li	s2,127
    name[0] = 'b';
    2a58:	b9640823          	sb	s6,-1136(s0)
    name[1] = 'i';
    2a5c:	b95408a3          	sb	s5,-1135(s0)
    name[2] = 'g';
    2a60:	b9440923          	sb	s4,-1134(s0)
    name[3] = '0' + i;
    2a64:	b89409a3          	sb	s1,-1133(s0)
    name[4] = '\0';
    2a68:	b8040a23          	sb	zero,-1132(s0)
    unlink(name);
    2a6c:	854e                	mv	a0,s3
    2a6e:	2f6020ef          	jal	4d64 <unlink>
  for(int i = 0; '0' + i < 0177; i++){
    2a72:	2485                	addiw	s1,s1,1
    2a74:	0ff4f493          	zext.b	s1,s1
    2a78:	ff2490e3          	bne	s1,s2,2a58 <diskfull+0x16c>
}
    2a7c:	49813083          	ld	ra,1176(sp)
    2a80:	49013403          	ld	s0,1168(sp)
    2a84:	48813483          	ld	s1,1160(sp)
    2a88:	48013903          	ld	s2,1152(sp)
    2a8c:	47813983          	ld	s3,1144(sp)
    2a90:	47013a03          	ld	s4,1136(sp)
    2a94:	46813a83          	ld	s5,1128(sp)
    2a98:	46013b03          	ld	s6,1120(sp)
    2a9c:	45813b83          	ld	s7,1112(sp)
    2aa0:	45013c03          	ld	s8,1104(sp)
    2aa4:	44813c83          	ld	s9,1096(sp)
    2aa8:	44013d03          	ld	s10,1088(sp)
    2aac:	43813d83          	ld	s11,1080(sp)
    2ab0:	4a010113          	addi	sp,sp,1184
    2ab4:	8082                	ret
    close(fd);
    2ab6:	854e                	mv	a0,s3
    2ab8:	284020ef          	jal	4d3c <close>
  for(fi = 0; done == 0 && '0' + fi < 0177; fi++){
    2abc:	2a85                	addiw	s5,s5,1 # 3001 <subdir+0x2eb>
    2abe:	0ffafa93          	zext.b	s5,s5
    2ac2:	07f00793          	li	a5,127
    2ac6:	eafa8be3          	beq	s5,a5,297c <diskfull+0x90>
    name[0] = 'b';
    2aca:	b7a40823          	sb	s10,-1168(s0)
    name[1] = 'i';
    2ace:	b79408a3          	sb	s9,-1167(s0)
    name[2] = 'g';
    2ad2:	b7840923          	sb	s8,-1166(s0)
    name[3] = '0' + fi;
    2ad6:	b75409a3          	sb	s5,-1165(s0)
    name[4] = '\0';
    2ada:	b6040a23          	sb	zero,-1164(s0)
    unlink(name);
    2ade:	855a                	mv	a0,s6
    2ae0:	284020ef          	jal	4d64 <unlink>
    int fd = open(name, O_CREATE|O_RDWR|O_TRUNC);
    2ae4:	85de                	mv	a1,s7
    2ae6:	855a                	mv	a0,s6
    2ae8:	26c020ef          	jal	4d54 <open>
    2aec:	89aa                	mv	s3,a0
    if(fd < 0){
    2aee:	e60546e3          	bltz	a0,295a <diskfull+0x6e>
    2af2:	84ee                	mv	s1,s11
      if(write(fd, buf, BSIZE) != BSIZE){
    2af4:	40000913          	li	s2,1024
    2af8:	864a                	mv	a2,s2
    2afa:	85d2                	mv	a1,s4
    2afc:	854e                	mv	a0,s3
    2afe:	236020ef          	jal	4d34 <write>
    2b02:	e72517e3          	bne	a0,s2,2970 <diskfull+0x84>
    for(int i = 0; i < MAXFILE; i++){
    2b06:	34fd                	addiw	s1,s1,-1
    2b08:	f8e5                	bnez	s1,2af8 <diskfull+0x20c>
    2b0a:	b775                	j	2ab6 <diskfull+0x1ca>
    printf("%s: mkdir(diskfulldir) unexpectedly succeeded!\n", s);
    2b0c:	b6843583          	ld	a1,-1176(s0)
    2b10:	00004517          	auipc	a0,0x4
    2b14:	b1850513          	addi	a0,a0,-1256 # 6628 <thread_switch+0x11b2>
    2b18:	63e020ef          	jal	5156 <printf>
    2b1c:	b5f9                	j	29ea <diskfull+0xfe>

0000000000002b1e <iputtest>:
{
    2b1e:	1101                	addi	sp,sp,-32
    2b20:	ec06                	sd	ra,24(sp)
    2b22:	e822                	sd	s0,16(sp)
    2b24:	e426                	sd	s1,8(sp)
    2b26:	1000                	addi	s0,sp,32
    2b28:	84aa                	mv	s1,a0
  if(mkdir("iputdir") < 0){
    2b2a:	00004517          	auipc	a0,0x4
    2b2e:	b2e50513          	addi	a0,a0,-1234 # 6658 <thread_switch+0x11e2>
    2b32:	24a020ef          	jal	4d7c <mkdir>
    2b36:	02054f63          	bltz	a0,2b74 <iputtest+0x56>
  if(chdir("iputdir") < 0){
    2b3a:	00004517          	auipc	a0,0x4
    2b3e:	b1e50513          	addi	a0,a0,-1250 # 6658 <thread_switch+0x11e2>
    2b42:	242020ef          	jal	4d84 <chdir>
    2b46:	04054163          	bltz	a0,2b88 <iputtest+0x6a>
  if(unlink("../iputdir") < 0){
    2b4a:	00004517          	auipc	a0,0x4
    2b4e:	b4e50513          	addi	a0,a0,-1202 # 6698 <thread_switch+0x1222>
    2b52:	212020ef          	jal	4d64 <unlink>
    2b56:	04054363          	bltz	a0,2b9c <iputtest+0x7e>
  if(chdir("/") < 0){
    2b5a:	00004517          	auipc	a0,0x4
    2b5e:	b6e50513          	addi	a0,a0,-1170 # 66c8 <thread_switch+0x1252>
    2b62:	222020ef          	jal	4d84 <chdir>
    2b66:	04054563          	bltz	a0,2bb0 <iputtest+0x92>
}
    2b6a:	60e2                	ld	ra,24(sp)
    2b6c:	6442                	ld	s0,16(sp)
    2b6e:	64a2                	ld	s1,8(sp)
    2b70:	6105                	addi	sp,sp,32
    2b72:	8082                	ret
    printf("%s: mkdir failed\n", s);
    2b74:	85a6                	mv	a1,s1
    2b76:	00004517          	auipc	a0,0x4
    2b7a:	aea50513          	addi	a0,a0,-1302 # 6660 <thread_switch+0x11ea>
    2b7e:	5d8020ef          	jal	5156 <printf>
    exit(1);
    2b82:	4505                	li	a0,1
    2b84:	190020ef          	jal	4d14 <exit>
    printf("%s: chdir iputdir failed\n", s);
    2b88:	85a6                	mv	a1,s1
    2b8a:	00004517          	auipc	a0,0x4
    2b8e:	aee50513          	addi	a0,a0,-1298 # 6678 <thread_switch+0x1202>
    2b92:	5c4020ef          	jal	5156 <printf>
    exit(1);
    2b96:	4505                	li	a0,1
    2b98:	17c020ef          	jal	4d14 <exit>
    printf("%s: unlink ../iputdir failed\n", s);
    2b9c:	85a6                	mv	a1,s1
    2b9e:	00004517          	auipc	a0,0x4
    2ba2:	b0a50513          	addi	a0,a0,-1270 # 66a8 <thread_switch+0x1232>
    2ba6:	5b0020ef          	jal	5156 <printf>
    exit(1);
    2baa:	4505                	li	a0,1
    2bac:	168020ef          	jal	4d14 <exit>
    printf("%s: chdir / failed\n", s);
    2bb0:	85a6                	mv	a1,s1
    2bb2:	00004517          	auipc	a0,0x4
    2bb6:	b1e50513          	addi	a0,a0,-1250 # 66d0 <thread_switch+0x125a>
    2bba:	59c020ef          	jal	5156 <printf>
    exit(1);
    2bbe:	4505                	li	a0,1
    2bc0:	154020ef          	jal	4d14 <exit>

0000000000002bc4 <exitiputtest>:
{
    2bc4:	7179                	addi	sp,sp,-48
    2bc6:	f406                	sd	ra,40(sp)
    2bc8:	f022                	sd	s0,32(sp)
    2bca:	ec26                	sd	s1,24(sp)
    2bcc:	1800                	addi	s0,sp,48
    2bce:	84aa                	mv	s1,a0
  pid = fork();
    2bd0:	13c020ef          	jal	4d0c <fork>
  if(pid < 0){
    2bd4:	02054e63          	bltz	a0,2c10 <exitiputtest+0x4c>
  if(pid == 0){
    2bd8:	e541                	bnez	a0,2c60 <exitiputtest+0x9c>
    if(mkdir("iputdir") < 0){
    2bda:	00004517          	auipc	a0,0x4
    2bde:	a7e50513          	addi	a0,a0,-1410 # 6658 <thread_switch+0x11e2>
    2be2:	19a020ef          	jal	4d7c <mkdir>
    2be6:	02054f63          	bltz	a0,2c24 <exitiputtest+0x60>
    if(chdir("iputdir") < 0){
    2bea:	00004517          	auipc	a0,0x4
    2bee:	a6e50513          	addi	a0,a0,-1426 # 6658 <thread_switch+0x11e2>
    2bf2:	192020ef          	jal	4d84 <chdir>
    2bf6:	04054163          	bltz	a0,2c38 <exitiputtest+0x74>
    if(unlink("../iputdir") < 0){
    2bfa:	00004517          	auipc	a0,0x4
    2bfe:	a9e50513          	addi	a0,a0,-1378 # 6698 <thread_switch+0x1222>
    2c02:	162020ef          	jal	4d64 <unlink>
    2c06:	04054363          	bltz	a0,2c4c <exitiputtest+0x88>
    exit(0);
    2c0a:	4501                	li	a0,0
    2c0c:	108020ef          	jal	4d14 <exit>
    printf("%s: fork failed\n", s);
    2c10:	85a6                	mv	a1,s1
    2c12:	00003517          	auipc	a0,0x3
    2c16:	19650513          	addi	a0,a0,406 # 5da8 <thread_switch+0x932>
    2c1a:	53c020ef          	jal	5156 <printf>
    exit(1);
    2c1e:	4505                	li	a0,1
    2c20:	0f4020ef          	jal	4d14 <exit>
      printf("%s: mkdir failed\n", s);
    2c24:	85a6                	mv	a1,s1
    2c26:	00004517          	auipc	a0,0x4
    2c2a:	a3a50513          	addi	a0,a0,-1478 # 6660 <thread_switch+0x11ea>
    2c2e:	528020ef          	jal	5156 <printf>
      exit(1);
    2c32:	4505                	li	a0,1
    2c34:	0e0020ef          	jal	4d14 <exit>
      printf("%s: child chdir failed\n", s);
    2c38:	85a6                	mv	a1,s1
    2c3a:	00004517          	auipc	a0,0x4
    2c3e:	aae50513          	addi	a0,a0,-1362 # 66e8 <thread_switch+0x1272>
    2c42:	514020ef          	jal	5156 <printf>
      exit(1);
    2c46:	4505                	li	a0,1
    2c48:	0cc020ef          	jal	4d14 <exit>
      printf("%s: unlink ../iputdir failed\n", s);
    2c4c:	85a6                	mv	a1,s1
    2c4e:	00004517          	auipc	a0,0x4
    2c52:	a5a50513          	addi	a0,a0,-1446 # 66a8 <thread_switch+0x1232>
    2c56:	500020ef          	jal	5156 <printf>
      exit(1);
    2c5a:	4505                	li	a0,1
    2c5c:	0b8020ef          	jal	4d14 <exit>
  wait(&xstatus);
    2c60:	fdc40513          	addi	a0,s0,-36
    2c64:	0b8020ef          	jal	4d1c <wait>
  exit(xstatus);
    2c68:	fdc42503          	lw	a0,-36(s0)
    2c6c:	0a8020ef          	jal	4d14 <exit>

0000000000002c70 <dirtest>:
{
    2c70:	1101                	addi	sp,sp,-32
    2c72:	ec06                	sd	ra,24(sp)
    2c74:	e822                	sd	s0,16(sp)
    2c76:	e426                	sd	s1,8(sp)
    2c78:	1000                	addi	s0,sp,32
    2c7a:	84aa                	mv	s1,a0
  if(mkdir("dir0") < 0){
    2c7c:	00004517          	auipc	a0,0x4
    2c80:	a8450513          	addi	a0,a0,-1404 # 6700 <thread_switch+0x128a>
    2c84:	0f8020ef          	jal	4d7c <mkdir>
    2c88:	02054f63          	bltz	a0,2cc6 <dirtest+0x56>
  if(chdir("dir0") < 0){
    2c8c:	00004517          	auipc	a0,0x4
    2c90:	a7450513          	addi	a0,a0,-1420 # 6700 <thread_switch+0x128a>
    2c94:	0f0020ef          	jal	4d84 <chdir>
    2c98:	04054163          	bltz	a0,2cda <dirtest+0x6a>
  if(chdir("..") < 0){
    2c9c:	00004517          	auipc	a0,0x4
    2ca0:	a8450513          	addi	a0,a0,-1404 # 6720 <thread_switch+0x12aa>
    2ca4:	0e0020ef          	jal	4d84 <chdir>
    2ca8:	04054363          	bltz	a0,2cee <dirtest+0x7e>
  if(unlink("dir0") < 0){
    2cac:	00004517          	auipc	a0,0x4
    2cb0:	a5450513          	addi	a0,a0,-1452 # 6700 <thread_switch+0x128a>
    2cb4:	0b0020ef          	jal	4d64 <unlink>
    2cb8:	04054563          	bltz	a0,2d02 <dirtest+0x92>
}
    2cbc:	60e2                	ld	ra,24(sp)
    2cbe:	6442                	ld	s0,16(sp)
    2cc0:	64a2                	ld	s1,8(sp)
    2cc2:	6105                	addi	sp,sp,32
    2cc4:	8082                	ret
    printf("%s: mkdir failed\n", s);
    2cc6:	85a6                	mv	a1,s1
    2cc8:	00004517          	auipc	a0,0x4
    2ccc:	99850513          	addi	a0,a0,-1640 # 6660 <thread_switch+0x11ea>
    2cd0:	486020ef          	jal	5156 <printf>
    exit(1);
    2cd4:	4505                	li	a0,1
    2cd6:	03e020ef          	jal	4d14 <exit>
    printf("%s: chdir dir0 failed\n", s);
    2cda:	85a6                	mv	a1,s1
    2cdc:	00004517          	auipc	a0,0x4
    2ce0:	a2c50513          	addi	a0,a0,-1492 # 6708 <thread_switch+0x1292>
    2ce4:	472020ef          	jal	5156 <printf>
    exit(1);
    2ce8:	4505                	li	a0,1
    2cea:	02a020ef          	jal	4d14 <exit>
    printf("%s: chdir .. failed\n", s);
    2cee:	85a6                	mv	a1,s1
    2cf0:	00004517          	auipc	a0,0x4
    2cf4:	a3850513          	addi	a0,a0,-1480 # 6728 <thread_switch+0x12b2>
    2cf8:	45e020ef          	jal	5156 <printf>
    exit(1);
    2cfc:	4505                	li	a0,1
    2cfe:	016020ef          	jal	4d14 <exit>
    printf("%s: unlink dir0 failed\n", s);
    2d02:	85a6                	mv	a1,s1
    2d04:	00004517          	auipc	a0,0x4
    2d08:	a3c50513          	addi	a0,a0,-1476 # 6740 <thread_switch+0x12ca>
    2d0c:	44a020ef          	jal	5156 <printf>
    exit(1);
    2d10:	4505                	li	a0,1
    2d12:	002020ef          	jal	4d14 <exit>

0000000000002d16 <subdir>:
{
    2d16:	1101                	addi	sp,sp,-32
    2d18:	ec06                	sd	ra,24(sp)
    2d1a:	e822                	sd	s0,16(sp)
    2d1c:	e426                	sd	s1,8(sp)
    2d1e:	e04a                	sd	s2,0(sp)
    2d20:	1000                	addi	s0,sp,32
    2d22:	892a                	mv	s2,a0
  unlink("ff");
    2d24:	00004517          	auipc	a0,0x4
    2d28:	b6450513          	addi	a0,a0,-1180 # 6888 <thread_switch+0x1412>
    2d2c:	038020ef          	jal	4d64 <unlink>
  if(mkdir("dd") != 0){
    2d30:	00004517          	auipc	a0,0x4
    2d34:	a2850513          	addi	a0,a0,-1496 # 6758 <thread_switch+0x12e2>
    2d38:	044020ef          	jal	4d7c <mkdir>
    2d3c:	2e051263          	bnez	a0,3020 <subdir+0x30a>
  fd = open("dd/ff", O_CREATE | O_RDWR);
    2d40:	20200593          	li	a1,514
    2d44:	00004517          	auipc	a0,0x4
    2d48:	a3450513          	addi	a0,a0,-1484 # 6778 <thread_switch+0x1302>
    2d4c:	008020ef          	jal	4d54 <open>
    2d50:	84aa                	mv	s1,a0
  if(fd < 0){
    2d52:	2e054163          	bltz	a0,3034 <subdir+0x31e>
  write(fd, "ff", 2);
    2d56:	4609                	li	a2,2
    2d58:	00004597          	auipc	a1,0x4
    2d5c:	b3058593          	addi	a1,a1,-1232 # 6888 <thread_switch+0x1412>
    2d60:	7d5010ef          	jal	4d34 <write>
  close(fd);
    2d64:	8526                	mv	a0,s1
    2d66:	7d7010ef          	jal	4d3c <close>
  if(unlink("dd") >= 0){
    2d6a:	00004517          	auipc	a0,0x4
    2d6e:	9ee50513          	addi	a0,a0,-1554 # 6758 <thread_switch+0x12e2>
    2d72:	7f3010ef          	jal	4d64 <unlink>
    2d76:	2c055963          	bgez	a0,3048 <subdir+0x332>
  if(mkdir("/dd/dd") != 0){
    2d7a:	00004517          	auipc	a0,0x4
    2d7e:	a5650513          	addi	a0,a0,-1450 # 67d0 <thread_switch+0x135a>
    2d82:	7fb010ef          	jal	4d7c <mkdir>
    2d86:	2c051b63          	bnez	a0,305c <subdir+0x346>
  fd = open("dd/dd/ff", O_CREATE | O_RDWR);
    2d8a:	20200593          	li	a1,514
    2d8e:	00004517          	auipc	a0,0x4
    2d92:	a6a50513          	addi	a0,a0,-1430 # 67f8 <thread_switch+0x1382>
    2d96:	7bf010ef          	jal	4d54 <open>
    2d9a:	84aa                	mv	s1,a0
  if(fd < 0){
    2d9c:	2c054a63          	bltz	a0,3070 <subdir+0x35a>
  write(fd, "FF", 2);
    2da0:	4609                	li	a2,2
    2da2:	00004597          	auipc	a1,0x4
    2da6:	a8658593          	addi	a1,a1,-1402 # 6828 <thread_switch+0x13b2>
    2daa:	78b010ef          	jal	4d34 <write>
  close(fd);
    2dae:	8526                	mv	a0,s1
    2db0:	78d010ef          	jal	4d3c <close>
  fd = open("dd/dd/../ff", 0);
    2db4:	4581                	li	a1,0
    2db6:	00004517          	auipc	a0,0x4
    2dba:	a7a50513          	addi	a0,a0,-1414 # 6830 <thread_switch+0x13ba>
    2dbe:	797010ef          	jal	4d54 <open>
    2dc2:	84aa                	mv	s1,a0
  if(fd < 0){
    2dc4:	2c054063          	bltz	a0,3084 <subdir+0x36e>
  cc = read(fd, buf, sizeof(buf));
    2dc8:	660d                	lui	a2,0x3
    2dca:	00009597          	auipc	a1,0x9
    2dce:	eae58593          	addi	a1,a1,-338 # bc78 <buf>
    2dd2:	75b010ef          	jal	4d2c <read>
  if(cc != 2 || buf[0] != 'f'){
    2dd6:	4789                	li	a5,2
    2dd8:	2cf51063          	bne	a0,a5,3098 <subdir+0x382>
    2ddc:	00009717          	auipc	a4,0x9
    2de0:	e9c74703          	lbu	a4,-356(a4) # bc78 <buf>
    2de4:	06600793          	li	a5,102
    2de8:	2af71863          	bne	a4,a5,3098 <subdir+0x382>
  close(fd);
    2dec:	8526                	mv	a0,s1
    2dee:	74f010ef          	jal	4d3c <close>
  if(link("dd/dd/ff", "dd/dd/ffff") != 0){
    2df2:	00004597          	auipc	a1,0x4
    2df6:	a8e58593          	addi	a1,a1,-1394 # 6880 <thread_switch+0x140a>
    2dfa:	00004517          	auipc	a0,0x4
    2dfe:	9fe50513          	addi	a0,a0,-1538 # 67f8 <thread_switch+0x1382>
    2e02:	773010ef          	jal	4d74 <link>
    2e06:	2a051363          	bnez	a0,30ac <subdir+0x396>
  if(unlink("dd/dd/ff") != 0){
    2e0a:	00004517          	auipc	a0,0x4
    2e0e:	9ee50513          	addi	a0,a0,-1554 # 67f8 <thread_switch+0x1382>
    2e12:	753010ef          	jal	4d64 <unlink>
    2e16:	2a051563          	bnez	a0,30c0 <subdir+0x3aa>
  if(open("dd/dd/ff", O_RDONLY) >= 0){
    2e1a:	4581                	li	a1,0
    2e1c:	00004517          	auipc	a0,0x4
    2e20:	9dc50513          	addi	a0,a0,-1572 # 67f8 <thread_switch+0x1382>
    2e24:	731010ef          	jal	4d54 <open>
    2e28:	2a055663          	bgez	a0,30d4 <subdir+0x3be>
  if(chdir("dd") != 0){
    2e2c:	00004517          	auipc	a0,0x4
    2e30:	92c50513          	addi	a0,a0,-1748 # 6758 <thread_switch+0x12e2>
    2e34:	751010ef          	jal	4d84 <chdir>
    2e38:	2a051863          	bnez	a0,30e8 <subdir+0x3d2>
  if(chdir("dd/../../dd") != 0){
    2e3c:	00004517          	auipc	a0,0x4
    2e40:	adc50513          	addi	a0,a0,-1316 # 6918 <thread_switch+0x14a2>
    2e44:	741010ef          	jal	4d84 <chdir>
    2e48:	2a051a63          	bnez	a0,30fc <subdir+0x3e6>
  if(chdir("dd/../../../dd") != 0){
    2e4c:	00004517          	auipc	a0,0x4
    2e50:	afc50513          	addi	a0,a0,-1284 # 6948 <thread_switch+0x14d2>
    2e54:	731010ef          	jal	4d84 <chdir>
    2e58:	2a051c63          	bnez	a0,3110 <subdir+0x3fa>
  if(chdir("./..") != 0){
    2e5c:	00004517          	auipc	a0,0x4
    2e60:	b2450513          	addi	a0,a0,-1244 # 6980 <thread_switch+0x150a>
    2e64:	721010ef          	jal	4d84 <chdir>
    2e68:	2a051e63          	bnez	a0,3124 <subdir+0x40e>
  fd = open("dd/dd/ffff", 0);
    2e6c:	4581                	li	a1,0
    2e6e:	00004517          	auipc	a0,0x4
    2e72:	a1250513          	addi	a0,a0,-1518 # 6880 <thread_switch+0x140a>
    2e76:	6df010ef          	jal	4d54 <open>
    2e7a:	84aa                	mv	s1,a0
  if(fd < 0){
    2e7c:	2a054e63          	bltz	a0,3138 <subdir+0x422>
  if(read(fd, buf, sizeof(buf)) != 2){
    2e80:	660d                	lui	a2,0x3
    2e82:	00009597          	auipc	a1,0x9
    2e86:	df658593          	addi	a1,a1,-522 # bc78 <buf>
    2e8a:	6a3010ef          	jal	4d2c <read>
    2e8e:	4789                	li	a5,2
    2e90:	2af51e63          	bne	a0,a5,314c <subdir+0x436>
  close(fd);
    2e94:	8526                	mv	a0,s1
    2e96:	6a7010ef          	jal	4d3c <close>
  if(open("dd/dd/ff", O_RDONLY) >= 0){
    2e9a:	4581                	li	a1,0
    2e9c:	00004517          	auipc	a0,0x4
    2ea0:	95c50513          	addi	a0,a0,-1700 # 67f8 <thread_switch+0x1382>
    2ea4:	6b1010ef          	jal	4d54 <open>
    2ea8:	2a055c63          	bgez	a0,3160 <subdir+0x44a>
  if(open("dd/ff/ff", O_CREATE|O_RDWR) >= 0){
    2eac:	20200593          	li	a1,514
    2eb0:	00004517          	auipc	a0,0x4
    2eb4:	b6050513          	addi	a0,a0,-1184 # 6a10 <thread_switch+0x159a>
    2eb8:	69d010ef          	jal	4d54 <open>
    2ebc:	2a055c63          	bgez	a0,3174 <subdir+0x45e>
  if(open("dd/xx/ff", O_CREATE|O_RDWR) >= 0){
    2ec0:	20200593          	li	a1,514
    2ec4:	00004517          	auipc	a0,0x4
    2ec8:	b7c50513          	addi	a0,a0,-1156 # 6a40 <thread_switch+0x15ca>
    2ecc:	689010ef          	jal	4d54 <open>
    2ed0:	2a055c63          	bgez	a0,3188 <subdir+0x472>
  if(open("dd", O_CREATE) >= 0){
    2ed4:	20000593          	li	a1,512
    2ed8:	00004517          	auipc	a0,0x4
    2edc:	88050513          	addi	a0,a0,-1920 # 6758 <thread_switch+0x12e2>
    2ee0:	675010ef          	jal	4d54 <open>
    2ee4:	2a055c63          	bgez	a0,319c <subdir+0x486>
  if(open("dd", O_RDWR) >= 0){
    2ee8:	4589                	li	a1,2
    2eea:	00004517          	auipc	a0,0x4
    2eee:	86e50513          	addi	a0,a0,-1938 # 6758 <thread_switch+0x12e2>
    2ef2:	663010ef          	jal	4d54 <open>
    2ef6:	2a055d63          	bgez	a0,31b0 <subdir+0x49a>
  if(open("dd", O_WRONLY) >= 0){
    2efa:	4585                	li	a1,1
    2efc:	00004517          	auipc	a0,0x4
    2f00:	85c50513          	addi	a0,a0,-1956 # 6758 <thread_switch+0x12e2>
    2f04:	651010ef          	jal	4d54 <open>
    2f08:	2a055e63          	bgez	a0,31c4 <subdir+0x4ae>
  if(link("dd/ff/ff", "dd/dd/xx") == 0){
    2f0c:	00004597          	auipc	a1,0x4
    2f10:	bc458593          	addi	a1,a1,-1084 # 6ad0 <thread_switch+0x165a>
    2f14:	00004517          	auipc	a0,0x4
    2f18:	afc50513          	addi	a0,a0,-1284 # 6a10 <thread_switch+0x159a>
    2f1c:	659010ef          	jal	4d74 <link>
    2f20:	2a050c63          	beqz	a0,31d8 <subdir+0x4c2>
  if(link("dd/xx/ff", "dd/dd/xx") == 0){
    2f24:	00004597          	auipc	a1,0x4
    2f28:	bac58593          	addi	a1,a1,-1108 # 6ad0 <thread_switch+0x165a>
    2f2c:	00004517          	auipc	a0,0x4
    2f30:	b1450513          	addi	a0,a0,-1260 # 6a40 <thread_switch+0x15ca>
    2f34:	641010ef          	jal	4d74 <link>
    2f38:	2a050a63          	beqz	a0,31ec <subdir+0x4d6>
  if(link("dd/ff", "dd/dd/ffff") == 0){
    2f3c:	00004597          	auipc	a1,0x4
    2f40:	94458593          	addi	a1,a1,-1724 # 6880 <thread_switch+0x140a>
    2f44:	00004517          	auipc	a0,0x4
    2f48:	83450513          	addi	a0,a0,-1996 # 6778 <thread_switch+0x1302>
    2f4c:	629010ef          	jal	4d74 <link>
    2f50:	2a050863          	beqz	a0,3200 <subdir+0x4ea>
  if(mkdir("dd/ff/ff") == 0){
    2f54:	00004517          	auipc	a0,0x4
    2f58:	abc50513          	addi	a0,a0,-1348 # 6a10 <thread_switch+0x159a>
    2f5c:	621010ef          	jal	4d7c <mkdir>
    2f60:	2a050a63          	beqz	a0,3214 <subdir+0x4fe>
  if(mkdir("dd/xx/ff") == 0){
    2f64:	00004517          	auipc	a0,0x4
    2f68:	adc50513          	addi	a0,a0,-1316 # 6a40 <thread_switch+0x15ca>
    2f6c:	611010ef          	jal	4d7c <mkdir>
    2f70:	2a050c63          	beqz	a0,3228 <subdir+0x512>
  if(mkdir("dd/dd/ffff") == 0){
    2f74:	00004517          	auipc	a0,0x4
    2f78:	90c50513          	addi	a0,a0,-1780 # 6880 <thread_switch+0x140a>
    2f7c:	601010ef          	jal	4d7c <mkdir>
    2f80:	2a050e63          	beqz	a0,323c <subdir+0x526>
  if(unlink("dd/xx/ff") == 0){
    2f84:	00004517          	auipc	a0,0x4
    2f88:	abc50513          	addi	a0,a0,-1348 # 6a40 <thread_switch+0x15ca>
    2f8c:	5d9010ef          	jal	4d64 <unlink>
    2f90:	2c050063          	beqz	a0,3250 <subdir+0x53a>
  if(unlink("dd/ff/ff") == 0){
    2f94:	00004517          	auipc	a0,0x4
    2f98:	a7c50513          	addi	a0,a0,-1412 # 6a10 <thread_switch+0x159a>
    2f9c:	5c9010ef          	jal	4d64 <unlink>
    2fa0:	2c050263          	beqz	a0,3264 <subdir+0x54e>
  if(chdir("dd/ff") == 0){
    2fa4:	00003517          	auipc	a0,0x3
    2fa8:	7d450513          	addi	a0,a0,2004 # 6778 <thread_switch+0x1302>
    2fac:	5d9010ef          	jal	4d84 <chdir>
    2fb0:	2c050463          	beqz	a0,3278 <subdir+0x562>
  if(chdir("dd/xx") == 0){
    2fb4:	00004517          	auipc	a0,0x4
    2fb8:	c6c50513          	addi	a0,a0,-916 # 6c20 <thread_switch+0x17aa>
    2fbc:	5c9010ef          	jal	4d84 <chdir>
    2fc0:	2c050663          	beqz	a0,328c <subdir+0x576>
  if(unlink("dd/dd/ffff") != 0){
    2fc4:	00004517          	auipc	a0,0x4
    2fc8:	8bc50513          	addi	a0,a0,-1860 # 6880 <thread_switch+0x140a>
    2fcc:	599010ef          	jal	4d64 <unlink>
    2fd0:	2c051863          	bnez	a0,32a0 <subdir+0x58a>
  if(unlink("dd/ff") != 0){
    2fd4:	00003517          	auipc	a0,0x3
    2fd8:	7a450513          	addi	a0,a0,1956 # 6778 <thread_switch+0x1302>
    2fdc:	589010ef          	jal	4d64 <unlink>
    2fe0:	2c051a63          	bnez	a0,32b4 <subdir+0x59e>
  if(unlink("dd") == 0){
    2fe4:	00003517          	auipc	a0,0x3
    2fe8:	77450513          	addi	a0,a0,1908 # 6758 <thread_switch+0x12e2>
    2fec:	579010ef          	jal	4d64 <unlink>
    2ff0:	2c050c63          	beqz	a0,32c8 <subdir+0x5b2>
  if(unlink("dd/dd") < 0){
    2ff4:	00004517          	auipc	a0,0x4
    2ff8:	c9c50513          	addi	a0,a0,-868 # 6c90 <thread_switch+0x181a>
    2ffc:	569010ef          	jal	4d64 <unlink>
    3000:	2c054e63          	bltz	a0,32dc <subdir+0x5c6>
  if(unlink("dd") < 0){
    3004:	00003517          	auipc	a0,0x3
    3008:	75450513          	addi	a0,a0,1876 # 6758 <thread_switch+0x12e2>
    300c:	559010ef          	jal	4d64 <unlink>
    3010:	2e054063          	bltz	a0,32f0 <subdir+0x5da>
}
    3014:	60e2                	ld	ra,24(sp)
    3016:	6442                	ld	s0,16(sp)
    3018:	64a2                	ld	s1,8(sp)
    301a:	6902                	ld	s2,0(sp)
    301c:	6105                	addi	sp,sp,32
    301e:	8082                	ret
    printf("%s: mkdir dd failed\n", s);
    3020:	85ca                	mv	a1,s2
    3022:	00003517          	auipc	a0,0x3
    3026:	73e50513          	addi	a0,a0,1854 # 6760 <thread_switch+0x12ea>
    302a:	12c020ef          	jal	5156 <printf>
    exit(1);
    302e:	4505                	li	a0,1
    3030:	4e5010ef          	jal	4d14 <exit>
    printf("%s: create dd/ff failed\n", s);
    3034:	85ca                	mv	a1,s2
    3036:	00003517          	auipc	a0,0x3
    303a:	74a50513          	addi	a0,a0,1866 # 6780 <thread_switch+0x130a>
    303e:	118020ef          	jal	5156 <printf>
    exit(1);
    3042:	4505                	li	a0,1
    3044:	4d1010ef          	jal	4d14 <exit>
    printf("%s: unlink dd (non-empty dir) succeeded!\n", s);
    3048:	85ca                	mv	a1,s2
    304a:	00003517          	auipc	a0,0x3
    304e:	75650513          	addi	a0,a0,1878 # 67a0 <thread_switch+0x132a>
    3052:	104020ef          	jal	5156 <printf>
    exit(1);
    3056:	4505                	li	a0,1
    3058:	4bd010ef          	jal	4d14 <exit>
    printf("%s: subdir mkdir dd/dd failed\n", s);
    305c:	85ca                	mv	a1,s2
    305e:	00003517          	auipc	a0,0x3
    3062:	77a50513          	addi	a0,a0,1914 # 67d8 <thread_switch+0x1362>
    3066:	0f0020ef          	jal	5156 <printf>
    exit(1);
    306a:	4505                	li	a0,1
    306c:	4a9010ef          	jal	4d14 <exit>
    printf("%s: create dd/dd/ff failed\n", s);
    3070:	85ca                	mv	a1,s2
    3072:	00003517          	auipc	a0,0x3
    3076:	79650513          	addi	a0,a0,1942 # 6808 <thread_switch+0x1392>
    307a:	0dc020ef          	jal	5156 <printf>
    exit(1);
    307e:	4505                	li	a0,1
    3080:	495010ef          	jal	4d14 <exit>
    printf("%s: open dd/dd/../ff failed\n", s);
    3084:	85ca                	mv	a1,s2
    3086:	00003517          	auipc	a0,0x3
    308a:	7ba50513          	addi	a0,a0,1978 # 6840 <thread_switch+0x13ca>
    308e:	0c8020ef          	jal	5156 <printf>
    exit(1);
    3092:	4505                	li	a0,1
    3094:	481010ef          	jal	4d14 <exit>
    printf("%s: dd/dd/../ff wrong content\n", s);
    3098:	85ca                	mv	a1,s2
    309a:	00003517          	auipc	a0,0x3
    309e:	7c650513          	addi	a0,a0,1990 # 6860 <thread_switch+0x13ea>
    30a2:	0b4020ef          	jal	5156 <printf>
    exit(1);
    30a6:	4505                	li	a0,1
    30a8:	46d010ef          	jal	4d14 <exit>
    printf("%s: link dd/dd/ff dd/dd/ffff failed\n", s);
    30ac:	85ca                	mv	a1,s2
    30ae:	00003517          	auipc	a0,0x3
    30b2:	7e250513          	addi	a0,a0,2018 # 6890 <thread_switch+0x141a>
    30b6:	0a0020ef          	jal	5156 <printf>
    exit(1);
    30ba:	4505                	li	a0,1
    30bc:	459010ef          	jal	4d14 <exit>
    printf("%s: unlink dd/dd/ff failed\n", s);
    30c0:	85ca                	mv	a1,s2
    30c2:	00003517          	auipc	a0,0x3
    30c6:	7f650513          	addi	a0,a0,2038 # 68b8 <thread_switch+0x1442>
    30ca:	08c020ef          	jal	5156 <printf>
    exit(1);
    30ce:	4505                	li	a0,1
    30d0:	445010ef          	jal	4d14 <exit>
    printf("%s: open (unlinked) dd/dd/ff succeeded\n", s);
    30d4:	85ca                	mv	a1,s2
    30d6:	00004517          	auipc	a0,0x4
    30da:	80250513          	addi	a0,a0,-2046 # 68d8 <thread_switch+0x1462>
    30de:	078020ef          	jal	5156 <printf>
    exit(1);
    30e2:	4505                	li	a0,1
    30e4:	431010ef          	jal	4d14 <exit>
    printf("%s: chdir dd failed\n", s);
    30e8:	85ca                	mv	a1,s2
    30ea:	00004517          	auipc	a0,0x4
    30ee:	81650513          	addi	a0,a0,-2026 # 6900 <thread_switch+0x148a>
    30f2:	064020ef          	jal	5156 <printf>
    exit(1);
    30f6:	4505                	li	a0,1
    30f8:	41d010ef          	jal	4d14 <exit>
    printf("%s: chdir dd/../../dd failed\n", s);
    30fc:	85ca                	mv	a1,s2
    30fe:	00004517          	auipc	a0,0x4
    3102:	82a50513          	addi	a0,a0,-2006 # 6928 <thread_switch+0x14b2>
    3106:	050020ef          	jal	5156 <printf>
    exit(1);
    310a:	4505                	li	a0,1
    310c:	409010ef          	jal	4d14 <exit>
    printf("%s: chdir dd/../../../dd failed\n", s);
    3110:	85ca                	mv	a1,s2
    3112:	00004517          	auipc	a0,0x4
    3116:	84650513          	addi	a0,a0,-1978 # 6958 <thread_switch+0x14e2>
    311a:	03c020ef          	jal	5156 <printf>
    exit(1);
    311e:	4505                	li	a0,1
    3120:	3f5010ef          	jal	4d14 <exit>
    printf("%s: chdir ./.. failed\n", s);
    3124:	85ca                	mv	a1,s2
    3126:	00004517          	auipc	a0,0x4
    312a:	86250513          	addi	a0,a0,-1950 # 6988 <thread_switch+0x1512>
    312e:	028020ef          	jal	5156 <printf>
    exit(1);
    3132:	4505                	li	a0,1
    3134:	3e1010ef          	jal	4d14 <exit>
    printf("%s: open dd/dd/ffff failed\n", s);
    3138:	85ca                	mv	a1,s2
    313a:	00004517          	auipc	a0,0x4
    313e:	86650513          	addi	a0,a0,-1946 # 69a0 <thread_switch+0x152a>
    3142:	014020ef          	jal	5156 <printf>
    exit(1);
    3146:	4505                	li	a0,1
    3148:	3cd010ef          	jal	4d14 <exit>
    printf("%s: read dd/dd/ffff wrong len\n", s);
    314c:	85ca                	mv	a1,s2
    314e:	00004517          	auipc	a0,0x4
    3152:	87250513          	addi	a0,a0,-1934 # 69c0 <thread_switch+0x154a>
    3156:	000020ef          	jal	5156 <printf>
    exit(1);
    315a:	4505                	li	a0,1
    315c:	3b9010ef          	jal	4d14 <exit>
    printf("%s: open (unlinked) dd/dd/ff succeeded!\n", s);
    3160:	85ca                	mv	a1,s2
    3162:	00004517          	auipc	a0,0x4
    3166:	87e50513          	addi	a0,a0,-1922 # 69e0 <thread_switch+0x156a>
    316a:	7ed010ef          	jal	5156 <printf>
    exit(1);
    316e:	4505                	li	a0,1
    3170:	3a5010ef          	jal	4d14 <exit>
    printf("%s: create dd/ff/ff succeeded!\n", s);
    3174:	85ca                	mv	a1,s2
    3176:	00004517          	auipc	a0,0x4
    317a:	8aa50513          	addi	a0,a0,-1878 # 6a20 <thread_switch+0x15aa>
    317e:	7d9010ef          	jal	5156 <printf>
    exit(1);
    3182:	4505                	li	a0,1
    3184:	391010ef          	jal	4d14 <exit>
    printf("%s: create dd/xx/ff succeeded!\n", s);
    3188:	85ca                	mv	a1,s2
    318a:	00004517          	auipc	a0,0x4
    318e:	8c650513          	addi	a0,a0,-1850 # 6a50 <thread_switch+0x15da>
    3192:	7c5010ef          	jal	5156 <printf>
    exit(1);
    3196:	4505                	li	a0,1
    3198:	37d010ef          	jal	4d14 <exit>
    printf("%s: create dd succeeded!\n", s);
    319c:	85ca                	mv	a1,s2
    319e:	00004517          	auipc	a0,0x4
    31a2:	8d250513          	addi	a0,a0,-1838 # 6a70 <thread_switch+0x15fa>
    31a6:	7b1010ef          	jal	5156 <printf>
    exit(1);
    31aa:	4505                	li	a0,1
    31ac:	369010ef          	jal	4d14 <exit>
    printf("%s: open dd rdwr succeeded!\n", s);
    31b0:	85ca                	mv	a1,s2
    31b2:	00004517          	auipc	a0,0x4
    31b6:	8de50513          	addi	a0,a0,-1826 # 6a90 <thread_switch+0x161a>
    31ba:	79d010ef          	jal	5156 <printf>
    exit(1);
    31be:	4505                	li	a0,1
    31c0:	355010ef          	jal	4d14 <exit>
    printf("%s: open dd wronly succeeded!\n", s);
    31c4:	85ca                	mv	a1,s2
    31c6:	00004517          	auipc	a0,0x4
    31ca:	8ea50513          	addi	a0,a0,-1814 # 6ab0 <thread_switch+0x163a>
    31ce:	789010ef          	jal	5156 <printf>
    exit(1);
    31d2:	4505                	li	a0,1
    31d4:	341010ef          	jal	4d14 <exit>
    printf("%s: link dd/ff/ff dd/dd/xx succeeded!\n", s);
    31d8:	85ca                	mv	a1,s2
    31da:	00004517          	auipc	a0,0x4
    31de:	90650513          	addi	a0,a0,-1786 # 6ae0 <thread_switch+0x166a>
    31e2:	775010ef          	jal	5156 <printf>
    exit(1);
    31e6:	4505                	li	a0,1
    31e8:	32d010ef          	jal	4d14 <exit>
    printf("%s: link dd/xx/ff dd/dd/xx succeeded!\n", s);
    31ec:	85ca                	mv	a1,s2
    31ee:	00004517          	auipc	a0,0x4
    31f2:	91a50513          	addi	a0,a0,-1766 # 6b08 <thread_switch+0x1692>
    31f6:	761010ef          	jal	5156 <printf>
    exit(1);
    31fa:	4505                	li	a0,1
    31fc:	319010ef          	jal	4d14 <exit>
    printf("%s: link dd/ff dd/dd/ffff succeeded!\n", s);
    3200:	85ca                	mv	a1,s2
    3202:	00004517          	auipc	a0,0x4
    3206:	92e50513          	addi	a0,a0,-1746 # 6b30 <thread_switch+0x16ba>
    320a:	74d010ef          	jal	5156 <printf>
    exit(1);
    320e:	4505                	li	a0,1
    3210:	305010ef          	jal	4d14 <exit>
    printf("%s: mkdir dd/ff/ff succeeded!\n", s);
    3214:	85ca                	mv	a1,s2
    3216:	00004517          	auipc	a0,0x4
    321a:	94250513          	addi	a0,a0,-1726 # 6b58 <thread_switch+0x16e2>
    321e:	739010ef          	jal	5156 <printf>
    exit(1);
    3222:	4505                	li	a0,1
    3224:	2f1010ef          	jal	4d14 <exit>
    printf("%s: mkdir dd/xx/ff succeeded!\n", s);
    3228:	85ca                	mv	a1,s2
    322a:	00004517          	auipc	a0,0x4
    322e:	94e50513          	addi	a0,a0,-1714 # 6b78 <thread_switch+0x1702>
    3232:	725010ef          	jal	5156 <printf>
    exit(1);
    3236:	4505                	li	a0,1
    3238:	2dd010ef          	jal	4d14 <exit>
    printf("%s: mkdir dd/dd/ffff succeeded!\n", s);
    323c:	85ca                	mv	a1,s2
    323e:	00004517          	auipc	a0,0x4
    3242:	95a50513          	addi	a0,a0,-1702 # 6b98 <thread_switch+0x1722>
    3246:	711010ef          	jal	5156 <printf>
    exit(1);
    324a:	4505                	li	a0,1
    324c:	2c9010ef          	jal	4d14 <exit>
    printf("%s: unlink dd/xx/ff succeeded!\n", s);
    3250:	85ca                	mv	a1,s2
    3252:	00004517          	auipc	a0,0x4
    3256:	96e50513          	addi	a0,a0,-1682 # 6bc0 <thread_switch+0x174a>
    325a:	6fd010ef          	jal	5156 <printf>
    exit(1);
    325e:	4505                	li	a0,1
    3260:	2b5010ef          	jal	4d14 <exit>
    printf("%s: unlink dd/ff/ff succeeded!\n", s);
    3264:	85ca                	mv	a1,s2
    3266:	00004517          	auipc	a0,0x4
    326a:	97a50513          	addi	a0,a0,-1670 # 6be0 <thread_switch+0x176a>
    326e:	6e9010ef          	jal	5156 <printf>
    exit(1);
    3272:	4505                	li	a0,1
    3274:	2a1010ef          	jal	4d14 <exit>
    printf("%s: chdir dd/ff succeeded!\n", s);
    3278:	85ca                	mv	a1,s2
    327a:	00004517          	auipc	a0,0x4
    327e:	98650513          	addi	a0,a0,-1658 # 6c00 <thread_switch+0x178a>
    3282:	6d5010ef          	jal	5156 <printf>
    exit(1);
    3286:	4505                	li	a0,1
    3288:	28d010ef          	jal	4d14 <exit>
    printf("%s: chdir dd/xx succeeded!\n", s);
    328c:	85ca                	mv	a1,s2
    328e:	00004517          	auipc	a0,0x4
    3292:	99a50513          	addi	a0,a0,-1638 # 6c28 <thread_switch+0x17b2>
    3296:	6c1010ef          	jal	5156 <printf>
    exit(1);
    329a:	4505                	li	a0,1
    329c:	279010ef          	jal	4d14 <exit>
    printf("%s: unlink dd/dd/ff failed\n", s);
    32a0:	85ca                	mv	a1,s2
    32a2:	00003517          	auipc	a0,0x3
    32a6:	61650513          	addi	a0,a0,1558 # 68b8 <thread_switch+0x1442>
    32aa:	6ad010ef          	jal	5156 <printf>
    exit(1);
    32ae:	4505                	li	a0,1
    32b0:	265010ef          	jal	4d14 <exit>
    printf("%s: unlink dd/ff failed\n", s);
    32b4:	85ca                	mv	a1,s2
    32b6:	00004517          	auipc	a0,0x4
    32ba:	99250513          	addi	a0,a0,-1646 # 6c48 <thread_switch+0x17d2>
    32be:	699010ef          	jal	5156 <printf>
    exit(1);
    32c2:	4505                	li	a0,1
    32c4:	251010ef          	jal	4d14 <exit>
    printf("%s: unlink non-empty dd succeeded!\n", s);
    32c8:	85ca                	mv	a1,s2
    32ca:	00004517          	auipc	a0,0x4
    32ce:	99e50513          	addi	a0,a0,-1634 # 6c68 <thread_switch+0x17f2>
    32d2:	685010ef          	jal	5156 <printf>
    exit(1);
    32d6:	4505                	li	a0,1
    32d8:	23d010ef          	jal	4d14 <exit>
    printf("%s: unlink dd/dd failed\n", s);
    32dc:	85ca                	mv	a1,s2
    32de:	00004517          	auipc	a0,0x4
    32e2:	9ba50513          	addi	a0,a0,-1606 # 6c98 <thread_switch+0x1822>
    32e6:	671010ef          	jal	5156 <printf>
    exit(1);
    32ea:	4505                	li	a0,1
    32ec:	229010ef          	jal	4d14 <exit>
    printf("%s: unlink dd failed\n", s);
    32f0:	85ca                	mv	a1,s2
    32f2:	00004517          	auipc	a0,0x4
    32f6:	9c650513          	addi	a0,a0,-1594 # 6cb8 <thread_switch+0x1842>
    32fa:	65d010ef          	jal	5156 <printf>
    exit(1);
    32fe:	4505                	li	a0,1
    3300:	215010ef          	jal	4d14 <exit>

0000000000003304 <rmdot>:
{
    3304:	1101                	addi	sp,sp,-32
    3306:	ec06                	sd	ra,24(sp)
    3308:	e822                	sd	s0,16(sp)
    330a:	e426                	sd	s1,8(sp)
    330c:	1000                	addi	s0,sp,32
    330e:	84aa                	mv	s1,a0
  if(mkdir("dots") != 0){
    3310:	00004517          	auipc	a0,0x4
    3314:	9c050513          	addi	a0,a0,-1600 # 6cd0 <thread_switch+0x185a>
    3318:	265010ef          	jal	4d7c <mkdir>
    331c:	e53d                	bnez	a0,338a <rmdot+0x86>
  if(chdir("dots") != 0){
    331e:	00004517          	auipc	a0,0x4
    3322:	9b250513          	addi	a0,a0,-1614 # 6cd0 <thread_switch+0x185a>
    3326:	25f010ef          	jal	4d84 <chdir>
    332a:	e935                	bnez	a0,339e <rmdot+0x9a>
  if(unlink(".") == 0){
    332c:	00003517          	auipc	a0,0x3
    3330:	8d450513          	addi	a0,a0,-1836 # 5c00 <thread_switch+0x78a>
    3334:	231010ef          	jal	4d64 <unlink>
    3338:	cd2d                	beqz	a0,33b2 <rmdot+0xae>
  if(unlink("..") == 0){
    333a:	00003517          	auipc	a0,0x3
    333e:	3e650513          	addi	a0,a0,998 # 6720 <thread_switch+0x12aa>
    3342:	223010ef          	jal	4d64 <unlink>
    3346:	c141                	beqz	a0,33c6 <rmdot+0xc2>
  if(chdir("/") != 0){
    3348:	00003517          	auipc	a0,0x3
    334c:	38050513          	addi	a0,a0,896 # 66c8 <thread_switch+0x1252>
    3350:	235010ef          	jal	4d84 <chdir>
    3354:	e159                	bnez	a0,33da <rmdot+0xd6>
  if(unlink("dots/.") == 0){
    3356:	00004517          	auipc	a0,0x4
    335a:	9e250513          	addi	a0,a0,-1566 # 6d38 <thread_switch+0x18c2>
    335e:	207010ef          	jal	4d64 <unlink>
    3362:	c551                	beqz	a0,33ee <rmdot+0xea>
  if(unlink("dots/..") == 0){
    3364:	00004517          	auipc	a0,0x4
    3368:	9fc50513          	addi	a0,a0,-1540 # 6d60 <thread_switch+0x18ea>
    336c:	1f9010ef          	jal	4d64 <unlink>
    3370:	c949                	beqz	a0,3402 <rmdot+0xfe>
  if(unlink("dots") != 0){
    3372:	00004517          	auipc	a0,0x4
    3376:	95e50513          	addi	a0,a0,-1698 # 6cd0 <thread_switch+0x185a>
    337a:	1eb010ef          	jal	4d64 <unlink>
    337e:	ed41                	bnez	a0,3416 <rmdot+0x112>
}
    3380:	60e2                	ld	ra,24(sp)
    3382:	6442                	ld	s0,16(sp)
    3384:	64a2                	ld	s1,8(sp)
    3386:	6105                	addi	sp,sp,32
    3388:	8082                	ret
    printf("%s: mkdir dots failed\n", s);
    338a:	85a6                	mv	a1,s1
    338c:	00004517          	auipc	a0,0x4
    3390:	94c50513          	addi	a0,a0,-1716 # 6cd8 <thread_switch+0x1862>
    3394:	5c3010ef          	jal	5156 <printf>
    exit(1);
    3398:	4505                	li	a0,1
    339a:	17b010ef          	jal	4d14 <exit>
    printf("%s: chdir dots failed\n", s);
    339e:	85a6                	mv	a1,s1
    33a0:	00004517          	auipc	a0,0x4
    33a4:	95050513          	addi	a0,a0,-1712 # 6cf0 <thread_switch+0x187a>
    33a8:	5af010ef          	jal	5156 <printf>
    exit(1);
    33ac:	4505                	li	a0,1
    33ae:	167010ef          	jal	4d14 <exit>
    printf("%s: rm . worked!\n", s);
    33b2:	85a6                	mv	a1,s1
    33b4:	00004517          	auipc	a0,0x4
    33b8:	95450513          	addi	a0,a0,-1708 # 6d08 <thread_switch+0x1892>
    33bc:	59b010ef          	jal	5156 <printf>
    exit(1);
    33c0:	4505                	li	a0,1
    33c2:	153010ef          	jal	4d14 <exit>
    printf("%s: rm .. worked!\n", s);
    33c6:	85a6                	mv	a1,s1
    33c8:	00004517          	auipc	a0,0x4
    33cc:	95850513          	addi	a0,a0,-1704 # 6d20 <thread_switch+0x18aa>
    33d0:	587010ef          	jal	5156 <printf>
    exit(1);
    33d4:	4505                	li	a0,1
    33d6:	13f010ef          	jal	4d14 <exit>
    printf("%s: chdir / failed\n", s);
    33da:	85a6                	mv	a1,s1
    33dc:	00003517          	auipc	a0,0x3
    33e0:	2f450513          	addi	a0,a0,756 # 66d0 <thread_switch+0x125a>
    33e4:	573010ef          	jal	5156 <printf>
    exit(1);
    33e8:	4505                	li	a0,1
    33ea:	12b010ef          	jal	4d14 <exit>
    printf("%s: unlink dots/. worked!\n", s);
    33ee:	85a6                	mv	a1,s1
    33f0:	00004517          	auipc	a0,0x4
    33f4:	95050513          	addi	a0,a0,-1712 # 6d40 <thread_switch+0x18ca>
    33f8:	55f010ef          	jal	5156 <printf>
    exit(1);
    33fc:	4505                	li	a0,1
    33fe:	117010ef          	jal	4d14 <exit>
    printf("%s: unlink dots/.. worked!\n", s);
    3402:	85a6                	mv	a1,s1
    3404:	00004517          	auipc	a0,0x4
    3408:	96450513          	addi	a0,a0,-1692 # 6d68 <thread_switch+0x18f2>
    340c:	54b010ef          	jal	5156 <printf>
    exit(1);
    3410:	4505                	li	a0,1
    3412:	103010ef          	jal	4d14 <exit>
    printf("%s: unlink dots failed!\n", s);
    3416:	85a6                	mv	a1,s1
    3418:	00004517          	auipc	a0,0x4
    341c:	97050513          	addi	a0,a0,-1680 # 6d88 <thread_switch+0x1912>
    3420:	537010ef          	jal	5156 <printf>
    exit(1);
    3424:	4505                	li	a0,1
    3426:	0ef010ef          	jal	4d14 <exit>

000000000000342a <dirfile>:
{
    342a:	1101                	addi	sp,sp,-32
    342c:	ec06                	sd	ra,24(sp)
    342e:	e822                	sd	s0,16(sp)
    3430:	e426                	sd	s1,8(sp)
    3432:	e04a                	sd	s2,0(sp)
    3434:	1000                	addi	s0,sp,32
    3436:	892a                	mv	s2,a0
  fd = open("dirfile", O_CREATE);
    3438:	20000593          	li	a1,512
    343c:	00004517          	auipc	a0,0x4
    3440:	96c50513          	addi	a0,a0,-1684 # 6da8 <thread_switch+0x1932>
    3444:	111010ef          	jal	4d54 <open>
  if(fd < 0){
    3448:	0c054563          	bltz	a0,3512 <dirfile+0xe8>
  close(fd);
    344c:	0f1010ef          	jal	4d3c <close>
  if(chdir("dirfile") == 0){
    3450:	00004517          	auipc	a0,0x4
    3454:	95850513          	addi	a0,a0,-1704 # 6da8 <thread_switch+0x1932>
    3458:	12d010ef          	jal	4d84 <chdir>
    345c:	c569                	beqz	a0,3526 <dirfile+0xfc>
  fd = open("dirfile/xx", 0);
    345e:	4581                	li	a1,0
    3460:	00004517          	auipc	a0,0x4
    3464:	99050513          	addi	a0,a0,-1648 # 6df0 <thread_switch+0x197a>
    3468:	0ed010ef          	jal	4d54 <open>
  if(fd >= 0){
    346c:	0c055763          	bgez	a0,353a <dirfile+0x110>
  fd = open("dirfile/xx", O_CREATE);
    3470:	20000593          	li	a1,512
    3474:	00004517          	auipc	a0,0x4
    3478:	97c50513          	addi	a0,a0,-1668 # 6df0 <thread_switch+0x197a>
    347c:	0d9010ef          	jal	4d54 <open>
  if(fd >= 0){
    3480:	0c055763          	bgez	a0,354e <dirfile+0x124>
  if(mkdir("dirfile/xx") == 0){
    3484:	00004517          	auipc	a0,0x4
    3488:	96c50513          	addi	a0,a0,-1684 # 6df0 <thread_switch+0x197a>
    348c:	0f1010ef          	jal	4d7c <mkdir>
    3490:	0c050963          	beqz	a0,3562 <dirfile+0x138>
  if(unlink("dirfile/xx") == 0){
    3494:	00004517          	auipc	a0,0x4
    3498:	95c50513          	addi	a0,a0,-1700 # 6df0 <thread_switch+0x197a>
    349c:	0c9010ef          	jal	4d64 <unlink>
    34a0:	0c050b63          	beqz	a0,3576 <dirfile+0x14c>
  if(link("README", "dirfile/xx") == 0){
    34a4:	00004597          	auipc	a1,0x4
    34a8:	94c58593          	addi	a1,a1,-1716 # 6df0 <thread_switch+0x197a>
    34ac:	00002517          	auipc	a0,0x2
    34b0:	24450513          	addi	a0,a0,580 # 56f0 <thread_switch+0x27a>
    34b4:	0c1010ef          	jal	4d74 <link>
    34b8:	0c050963          	beqz	a0,358a <dirfile+0x160>
  if(unlink("dirfile") != 0){
    34bc:	00004517          	auipc	a0,0x4
    34c0:	8ec50513          	addi	a0,a0,-1812 # 6da8 <thread_switch+0x1932>
    34c4:	0a1010ef          	jal	4d64 <unlink>
    34c8:	0c051b63          	bnez	a0,359e <dirfile+0x174>
  fd = open(".", O_RDWR);
    34cc:	4589                	li	a1,2
    34ce:	00002517          	auipc	a0,0x2
    34d2:	73250513          	addi	a0,a0,1842 # 5c00 <thread_switch+0x78a>
    34d6:	07f010ef          	jal	4d54 <open>
  if(fd >= 0){
    34da:	0c055c63          	bgez	a0,35b2 <dirfile+0x188>
  fd = open(".", 0);
    34de:	4581                	li	a1,0
    34e0:	00002517          	auipc	a0,0x2
    34e4:	72050513          	addi	a0,a0,1824 # 5c00 <thread_switch+0x78a>
    34e8:	06d010ef          	jal	4d54 <open>
    34ec:	84aa                	mv	s1,a0
  if(write(fd, "x", 1) > 0){
    34ee:	4605                	li	a2,1
    34f0:	00002597          	auipc	a1,0x2
    34f4:	09858593          	addi	a1,a1,152 # 5588 <thread_switch+0x112>
    34f8:	03d010ef          	jal	4d34 <write>
    34fc:	0ca04563          	bgtz	a0,35c6 <dirfile+0x19c>
  close(fd);
    3500:	8526                	mv	a0,s1
    3502:	03b010ef          	jal	4d3c <close>
}
    3506:	60e2                	ld	ra,24(sp)
    3508:	6442                	ld	s0,16(sp)
    350a:	64a2                	ld	s1,8(sp)
    350c:	6902                	ld	s2,0(sp)
    350e:	6105                	addi	sp,sp,32
    3510:	8082                	ret
    printf("%s: create dirfile failed\n", s);
    3512:	85ca                	mv	a1,s2
    3514:	00004517          	auipc	a0,0x4
    3518:	89c50513          	addi	a0,a0,-1892 # 6db0 <thread_switch+0x193a>
    351c:	43b010ef          	jal	5156 <printf>
    exit(1);
    3520:	4505                	li	a0,1
    3522:	7f2010ef          	jal	4d14 <exit>
    printf("%s: chdir dirfile succeeded!\n", s);
    3526:	85ca                	mv	a1,s2
    3528:	00004517          	auipc	a0,0x4
    352c:	8a850513          	addi	a0,a0,-1880 # 6dd0 <thread_switch+0x195a>
    3530:	427010ef          	jal	5156 <printf>
    exit(1);
    3534:	4505                	li	a0,1
    3536:	7de010ef          	jal	4d14 <exit>
    printf("%s: create dirfile/xx succeeded!\n", s);
    353a:	85ca                	mv	a1,s2
    353c:	00004517          	auipc	a0,0x4
    3540:	8c450513          	addi	a0,a0,-1852 # 6e00 <thread_switch+0x198a>
    3544:	413010ef          	jal	5156 <printf>
    exit(1);
    3548:	4505                	li	a0,1
    354a:	7ca010ef          	jal	4d14 <exit>
    printf("%s: create dirfile/xx succeeded!\n", s);
    354e:	85ca                	mv	a1,s2
    3550:	00004517          	auipc	a0,0x4
    3554:	8b050513          	addi	a0,a0,-1872 # 6e00 <thread_switch+0x198a>
    3558:	3ff010ef          	jal	5156 <printf>
    exit(1);
    355c:	4505                	li	a0,1
    355e:	7b6010ef          	jal	4d14 <exit>
    printf("%s: mkdir dirfile/xx succeeded!\n", s);
    3562:	85ca                	mv	a1,s2
    3564:	00004517          	auipc	a0,0x4
    3568:	8c450513          	addi	a0,a0,-1852 # 6e28 <thread_switch+0x19b2>
    356c:	3eb010ef          	jal	5156 <printf>
    exit(1);
    3570:	4505                	li	a0,1
    3572:	7a2010ef          	jal	4d14 <exit>
    printf("%s: unlink dirfile/xx succeeded!\n", s);
    3576:	85ca                	mv	a1,s2
    3578:	00004517          	auipc	a0,0x4
    357c:	8d850513          	addi	a0,a0,-1832 # 6e50 <thread_switch+0x19da>
    3580:	3d7010ef          	jal	5156 <printf>
    exit(1);
    3584:	4505                	li	a0,1
    3586:	78e010ef          	jal	4d14 <exit>
    printf("%s: link to dirfile/xx succeeded!\n", s);
    358a:	85ca                	mv	a1,s2
    358c:	00004517          	auipc	a0,0x4
    3590:	8ec50513          	addi	a0,a0,-1812 # 6e78 <thread_switch+0x1a02>
    3594:	3c3010ef          	jal	5156 <printf>
    exit(1);
    3598:	4505                	li	a0,1
    359a:	77a010ef          	jal	4d14 <exit>
    printf("%s: unlink dirfile failed!\n", s);
    359e:	85ca                	mv	a1,s2
    35a0:	00004517          	auipc	a0,0x4
    35a4:	90050513          	addi	a0,a0,-1792 # 6ea0 <thread_switch+0x1a2a>
    35a8:	3af010ef          	jal	5156 <printf>
    exit(1);
    35ac:	4505                	li	a0,1
    35ae:	766010ef          	jal	4d14 <exit>
    printf("%s: open . for writing succeeded!\n", s);
    35b2:	85ca                	mv	a1,s2
    35b4:	00004517          	auipc	a0,0x4
    35b8:	90c50513          	addi	a0,a0,-1780 # 6ec0 <thread_switch+0x1a4a>
    35bc:	39b010ef          	jal	5156 <printf>
    exit(1);
    35c0:	4505                	li	a0,1
    35c2:	752010ef          	jal	4d14 <exit>
    printf("%s: write . succeeded!\n", s);
    35c6:	85ca                	mv	a1,s2
    35c8:	00004517          	auipc	a0,0x4
    35cc:	92050513          	addi	a0,a0,-1760 # 6ee8 <thread_switch+0x1a72>
    35d0:	387010ef          	jal	5156 <printf>
    exit(1);
    35d4:	4505                	li	a0,1
    35d6:	73e010ef          	jal	4d14 <exit>

00000000000035da <iref>:
{
    35da:	715d                	addi	sp,sp,-80
    35dc:	e486                	sd	ra,72(sp)
    35de:	e0a2                	sd	s0,64(sp)
    35e0:	fc26                	sd	s1,56(sp)
    35e2:	f84a                	sd	s2,48(sp)
    35e4:	f44e                	sd	s3,40(sp)
    35e6:	f052                	sd	s4,32(sp)
    35e8:	ec56                	sd	s5,24(sp)
    35ea:	e85a                	sd	s6,16(sp)
    35ec:	e45e                	sd	s7,8(sp)
    35ee:	0880                	addi	s0,sp,80
    35f0:	8baa                	mv	s7,a0
    35f2:	03300913          	li	s2,51
    if(mkdir("irefd") != 0){
    35f6:	00004a97          	auipc	s5,0x4
    35fa:	90aa8a93          	addi	s5,s5,-1782 # 6f00 <thread_switch+0x1a8a>
    mkdir("");
    35fe:	00003497          	auipc	s1,0x3
    3602:	40a48493          	addi	s1,s1,1034 # 6a08 <thread_switch+0x1592>
    link("README", "");
    3606:	00002b17          	auipc	s6,0x2
    360a:	0eab0b13          	addi	s6,s6,234 # 56f0 <thread_switch+0x27a>
    fd = open("", O_CREATE);
    360e:	20000a13          	li	s4,512
    fd = open("xx", O_CREATE);
    3612:	00003997          	auipc	s3,0x3
    3616:	7e698993          	addi	s3,s3,2022 # 6df8 <thread_switch+0x1982>
    361a:	a835                	j	3656 <iref+0x7c>
      printf("%s: mkdir irefd failed\n", s);
    361c:	85de                	mv	a1,s7
    361e:	00004517          	auipc	a0,0x4
    3622:	8ea50513          	addi	a0,a0,-1814 # 6f08 <thread_switch+0x1a92>
    3626:	331010ef          	jal	5156 <printf>
      exit(1);
    362a:	4505                	li	a0,1
    362c:	6e8010ef          	jal	4d14 <exit>
      printf("%s: chdir irefd failed\n", s);
    3630:	85de                	mv	a1,s7
    3632:	00004517          	auipc	a0,0x4
    3636:	8ee50513          	addi	a0,a0,-1810 # 6f20 <thread_switch+0x1aaa>
    363a:	31d010ef          	jal	5156 <printf>
      exit(1);
    363e:	4505                	li	a0,1
    3640:	6d4010ef          	jal	4d14 <exit>
      close(fd);
    3644:	6f8010ef          	jal	4d3c <close>
    3648:	a825                	j	3680 <iref+0xa6>
    unlink("xx");
    364a:	854e                	mv	a0,s3
    364c:	718010ef          	jal	4d64 <unlink>
  for(i = 0; i < NINODE + 1; i++){
    3650:	397d                	addiw	s2,s2,-1
    3652:	04090063          	beqz	s2,3692 <iref+0xb8>
    if(mkdir("irefd") != 0){
    3656:	8556                	mv	a0,s5
    3658:	724010ef          	jal	4d7c <mkdir>
    365c:	f161                	bnez	a0,361c <iref+0x42>
    if(chdir("irefd") != 0){
    365e:	8556                	mv	a0,s5
    3660:	724010ef          	jal	4d84 <chdir>
    3664:	f571                	bnez	a0,3630 <iref+0x56>
    mkdir("");
    3666:	8526                	mv	a0,s1
    3668:	714010ef          	jal	4d7c <mkdir>
    link("README", "");
    366c:	85a6                	mv	a1,s1
    366e:	855a                	mv	a0,s6
    3670:	704010ef          	jal	4d74 <link>
    fd = open("", O_CREATE);
    3674:	85d2                	mv	a1,s4
    3676:	8526                	mv	a0,s1
    3678:	6dc010ef          	jal	4d54 <open>
    if(fd >= 0)
    367c:	fc0554e3          	bgez	a0,3644 <iref+0x6a>
    fd = open("xx", O_CREATE);
    3680:	85d2                	mv	a1,s4
    3682:	854e                	mv	a0,s3
    3684:	6d0010ef          	jal	4d54 <open>
    if(fd >= 0)
    3688:	fc0541e3          	bltz	a0,364a <iref+0x70>
      close(fd);
    368c:	6b0010ef          	jal	4d3c <close>
    3690:	bf6d                	j	364a <iref+0x70>
  for(i = 0; i < NINODE + 1; i++){
    3692:	03300493          	li	s1,51
    chdir("..");
    3696:	00003997          	auipc	s3,0x3
    369a:	08a98993          	addi	s3,s3,138 # 6720 <thread_switch+0x12aa>
    unlink("irefd");
    369e:	00004917          	auipc	s2,0x4
    36a2:	86290913          	addi	s2,s2,-1950 # 6f00 <thread_switch+0x1a8a>
    chdir("..");
    36a6:	854e                	mv	a0,s3
    36a8:	6dc010ef          	jal	4d84 <chdir>
    unlink("irefd");
    36ac:	854a                	mv	a0,s2
    36ae:	6b6010ef          	jal	4d64 <unlink>
  for(i = 0; i < NINODE + 1; i++){
    36b2:	34fd                	addiw	s1,s1,-1
    36b4:	f8ed                	bnez	s1,36a6 <iref+0xcc>
  chdir("/");
    36b6:	00003517          	auipc	a0,0x3
    36ba:	01250513          	addi	a0,a0,18 # 66c8 <thread_switch+0x1252>
    36be:	6c6010ef          	jal	4d84 <chdir>
}
    36c2:	60a6                	ld	ra,72(sp)
    36c4:	6406                	ld	s0,64(sp)
    36c6:	74e2                	ld	s1,56(sp)
    36c8:	7942                	ld	s2,48(sp)
    36ca:	79a2                	ld	s3,40(sp)
    36cc:	7a02                	ld	s4,32(sp)
    36ce:	6ae2                	ld	s5,24(sp)
    36d0:	6b42                	ld	s6,16(sp)
    36d2:	6ba2                	ld	s7,8(sp)
    36d4:	6161                	addi	sp,sp,80
    36d6:	8082                	ret

00000000000036d8 <openiputtest>:
{
    36d8:	7179                	addi	sp,sp,-48
    36da:	f406                	sd	ra,40(sp)
    36dc:	f022                	sd	s0,32(sp)
    36de:	ec26                	sd	s1,24(sp)
    36e0:	1800                	addi	s0,sp,48
    36e2:	84aa                	mv	s1,a0
  if(mkdir("oidir") < 0){
    36e4:	00004517          	auipc	a0,0x4
    36e8:	85450513          	addi	a0,a0,-1964 # 6f38 <thread_switch+0x1ac2>
    36ec:	690010ef          	jal	4d7c <mkdir>
    36f0:	02054a63          	bltz	a0,3724 <openiputtest+0x4c>
  pid = fork();
    36f4:	618010ef          	jal	4d0c <fork>
  if(pid < 0){
    36f8:	04054063          	bltz	a0,3738 <openiputtest+0x60>
  if(pid == 0){
    36fc:	e939                	bnez	a0,3752 <openiputtest+0x7a>
    int fd = open("oidir", O_RDWR);
    36fe:	4589                	li	a1,2
    3700:	00004517          	auipc	a0,0x4
    3704:	83850513          	addi	a0,a0,-1992 # 6f38 <thread_switch+0x1ac2>
    3708:	64c010ef          	jal	4d54 <open>
    if(fd >= 0){
    370c:	04054063          	bltz	a0,374c <openiputtest+0x74>
      printf("%s: open directory for write succeeded\n", s);
    3710:	85a6                	mv	a1,s1
    3712:	00004517          	auipc	a0,0x4
    3716:	84650513          	addi	a0,a0,-1978 # 6f58 <thread_switch+0x1ae2>
    371a:	23d010ef          	jal	5156 <printf>
      exit(1);
    371e:	4505                	li	a0,1
    3720:	5f4010ef          	jal	4d14 <exit>
    printf("%s: mkdir oidir failed\n", s);
    3724:	85a6                	mv	a1,s1
    3726:	00004517          	auipc	a0,0x4
    372a:	81a50513          	addi	a0,a0,-2022 # 6f40 <thread_switch+0x1aca>
    372e:	229010ef          	jal	5156 <printf>
    exit(1);
    3732:	4505                	li	a0,1
    3734:	5e0010ef          	jal	4d14 <exit>
    printf("%s: fork failed\n", s);
    3738:	85a6                	mv	a1,s1
    373a:	00002517          	auipc	a0,0x2
    373e:	66e50513          	addi	a0,a0,1646 # 5da8 <thread_switch+0x932>
    3742:	215010ef          	jal	5156 <printf>
    exit(1);
    3746:	4505                	li	a0,1
    3748:	5cc010ef          	jal	4d14 <exit>
    exit(0);
    374c:	4501                	li	a0,0
    374e:	5c6010ef          	jal	4d14 <exit>
  sleep(1);
    3752:	4505                	li	a0,1
    3754:	650010ef          	jal	4da4 <sleep>
  if(unlink("oidir") != 0){
    3758:	00003517          	auipc	a0,0x3
    375c:	7e050513          	addi	a0,a0,2016 # 6f38 <thread_switch+0x1ac2>
    3760:	604010ef          	jal	4d64 <unlink>
    3764:	c919                	beqz	a0,377a <openiputtest+0xa2>
    printf("%s: unlink failed\n", s);
    3766:	85a6                	mv	a1,s1
    3768:	00003517          	auipc	a0,0x3
    376c:	83050513          	addi	a0,a0,-2000 # 5f98 <thread_switch+0xb22>
    3770:	1e7010ef          	jal	5156 <printf>
    exit(1);
    3774:	4505                	li	a0,1
    3776:	59e010ef          	jal	4d14 <exit>
  wait(&xstatus);
    377a:	fdc40513          	addi	a0,s0,-36
    377e:	59e010ef          	jal	4d1c <wait>
  exit(xstatus);
    3782:	fdc42503          	lw	a0,-36(s0)
    3786:	58e010ef          	jal	4d14 <exit>

000000000000378a <forkforkfork>:
{
    378a:	1101                	addi	sp,sp,-32
    378c:	ec06                	sd	ra,24(sp)
    378e:	e822                	sd	s0,16(sp)
    3790:	e426                	sd	s1,8(sp)
    3792:	1000                	addi	s0,sp,32
    3794:	84aa                	mv	s1,a0
  unlink("stopforking");
    3796:	00003517          	auipc	a0,0x3
    379a:	7ea50513          	addi	a0,a0,2026 # 6f80 <thread_switch+0x1b0a>
    379e:	5c6010ef          	jal	4d64 <unlink>
  int pid = fork();
    37a2:	56a010ef          	jal	4d0c <fork>
  if(pid < 0){
    37a6:	02054b63          	bltz	a0,37dc <forkforkfork+0x52>
  if(pid == 0){
    37aa:	c125                	beqz	a0,380a <forkforkfork+0x80>
  sleep(20); // two seconds
    37ac:	4551                	li	a0,20
    37ae:	5f6010ef          	jal	4da4 <sleep>
  close(open("stopforking", O_CREATE|O_RDWR));
    37b2:	20200593          	li	a1,514
    37b6:	00003517          	auipc	a0,0x3
    37ba:	7ca50513          	addi	a0,a0,1994 # 6f80 <thread_switch+0x1b0a>
    37be:	596010ef          	jal	4d54 <open>
    37c2:	57a010ef          	jal	4d3c <close>
  wait(0);
    37c6:	4501                	li	a0,0
    37c8:	554010ef          	jal	4d1c <wait>
  sleep(10); // one second
    37cc:	4529                	li	a0,10
    37ce:	5d6010ef          	jal	4da4 <sleep>
}
    37d2:	60e2                	ld	ra,24(sp)
    37d4:	6442                	ld	s0,16(sp)
    37d6:	64a2                	ld	s1,8(sp)
    37d8:	6105                	addi	sp,sp,32
    37da:	8082                	ret
    printf("%s: fork failed", s);
    37dc:	85a6                	mv	a1,s1
    37de:	00002517          	auipc	a0,0x2
    37e2:	78a50513          	addi	a0,a0,1930 # 5f68 <thread_switch+0xaf2>
    37e6:	171010ef          	jal	5156 <printf>
    exit(1);
    37ea:	4505                	li	a0,1
    37ec:	528010ef          	jal	4d14 <exit>
        exit(0);
    37f0:	4501                	li	a0,0
    37f2:	522010ef          	jal	4d14 <exit>
        close(open("stopforking", O_CREATE|O_RDWR));
    37f6:	20200593          	li	a1,514
    37fa:	00003517          	auipc	a0,0x3
    37fe:	78650513          	addi	a0,a0,1926 # 6f80 <thread_switch+0x1b0a>
    3802:	552010ef          	jal	4d54 <open>
    3806:	536010ef          	jal	4d3c <close>
      int fd = open("stopforking", 0);
    380a:	4581                	li	a1,0
    380c:	00003517          	auipc	a0,0x3
    3810:	77450513          	addi	a0,a0,1908 # 6f80 <thread_switch+0x1b0a>
    3814:	540010ef          	jal	4d54 <open>
      if(fd >= 0){
    3818:	fc055ce3          	bgez	a0,37f0 <forkforkfork+0x66>
      if(fork() < 0){
    381c:	4f0010ef          	jal	4d0c <fork>
    3820:	fe0555e3          	bgez	a0,380a <forkforkfork+0x80>
    3824:	bfc9                	j	37f6 <forkforkfork+0x6c>

0000000000003826 <killstatus>:
{
    3826:	715d                	addi	sp,sp,-80
    3828:	e486                	sd	ra,72(sp)
    382a:	e0a2                	sd	s0,64(sp)
    382c:	fc26                	sd	s1,56(sp)
    382e:	f84a                	sd	s2,48(sp)
    3830:	f44e                	sd	s3,40(sp)
    3832:	f052                	sd	s4,32(sp)
    3834:	ec56                	sd	s5,24(sp)
    3836:	e85a                	sd	s6,16(sp)
    3838:	0880                	addi	s0,sp,80
    383a:	8b2a                	mv	s6,a0
    383c:	06400913          	li	s2,100
    sleep(1);
    3840:	4a85                	li	s5,1
    wait(&xst);
    3842:	fbc40a13          	addi	s4,s0,-68
    if(xst != -1) {
    3846:	59fd                	li	s3,-1
    int pid1 = fork();
    3848:	4c4010ef          	jal	4d0c <fork>
    384c:	84aa                	mv	s1,a0
    if(pid1 < 0){
    384e:	02054663          	bltz	a0,387a <killstatus+0x54>
    if(pid1 == 0){
    3852:	cd15                	beqz	a0,388e <killstatus+0x68>
    sleep(1);
    3854:	8556                	mv	a0,s5
    3856:	54e010ef          	jal	4da4 <sleep>
    kill(pid1);
    385a:	8526                	mv	a0,s1
    385c:	4e8010ef          	jal	4d44 <kill>
    wait(&xst);
    3860:	8552                	mv	a0,s4
    3862:	4ba010ef          	jal	4d1c <wait>
    if(xst != -1) {
    3866:	fbc42783          	lw	a5,-68(s0)
    386a:	03379563          	bne	a5,s3,3894 <killstatus+0x6e>
  for(int i = 0; i < 100; i++){
    386e:	397d                	addiw	s2,s2,-1
    3870:	fc091ce3          	bnez	s2,3848 <killstatus+0x22>
  exit(0);
    3874:	4501                	li	a0,0
    3876:	49e010ef          	jal	4d14 <exit>
      printf("%s: fork failed\n", s);
    387a:	85da                	mv	a1,s6
    387c:	00002517          	auipc	a0,0x2
    3880:	52c50513          	addi	a0,a0,1324 # 5da8 <thread_switch+0x932>
    3884:	0d3010ef          	jal	5156 <printf>
      exit(1);
    3888:	4505                	li	a0,1
    388a:	48a010ef          	jal	4d14 <exit>
        getpid();
    388e:	506010ef          	jal	4d94 <getpid>
      while(1) {
    3892:	bff5                	j	388e <killstatus+0x68>
       printf("%s: status should be -1\n", s);
    3894:	85da                	mv	a1,s6
    3896:	00003517          	auipc	a0,0x3
    389a:	6fa50513          	addi	a0,a0,1786 # 6f90 <thread_switch+0x1b1a>
    389e:	0b9010ef          	jal	5156 <printf>
       exit(1);
    38a2:	4505                	li	a0,1
    38a4:	470010ef          	jal	4d14 <exit>

00000000000038a8 <preempt>:
{
    38a8:	7139                	addi	sp,sp,-64
    38aa:	fc06                	sd	ra,56(sp)
    38ac:	f822                	sd	s0,48(sp)
    38ae:	f426                	sd	s1,40(sp)
    38b0:	f04a                	sd	s2,32(sp)
    38b2:	ec4e                	sd	s3,24(sp)
    38b4:	e852                	sd	s4,16(sp)
    38b6:	0080                	addi	s0,sp,64
    38b8:	892a                	mv	s2,a0
  pid1 = fork();
    38ba:	452010ef          	jal	4d0c <fork>
  if(pid1 < 0) {
    38be:	00054563          	bltz	a0,38c8 <preempt+0x20>
    38c2:	84aa                	mv	s1,a0
  if(pid1 == 0)
    38c4:	ed01                	bnez	a0,38dc <preempt+0x34>
    for(;;)
    38c6:	a001                	j	38c6 <preempt+0x1e>
    printf("%s: fork failed", s);
    38c8:	85ca                	mv	a1,s2
    38ca:	00002517          	auipc	a0,0x2
    38ce:	69e50513          	addi	a0,a0,1694 # 5f68 <thread_switch+0xaf2>
    38d2:	085010ef          	jal	5156 <printf>
    exit(1);
    38d6:	4505                	li	a0,1
    38d8:	43c010ef          	jal	4d14 <exit>
  pid2 = fork();
    38dc:	430010ef          	jal	4d0c <fork>
    38e0:	89aa                	mv	s3,a0
  if(pid2 < 0) {
    38e2:	00054463          	bltz	a0,38ea <preempt+0x42>
  if(pid2 == 0)
    38e6:	ed01                	bnez	a0,38fe <preempt+0x56>
    for(;;)
    38e8:	a001                	j	38e8 <preempt+0x40>
    printf("%s: fork failed\n", s);
    38ea:	85ca                	mv	a1,s2
    38ec:	00002517          	auipc	a0,0x2
    38f0:	4bc50513          	addi	a0,a0,1212 # 5da8 <thread_switch+0x932>
    38f4:	063010ef          	jal	5156 <printf>
    exit(1);
    38f8:	4505                	li	a0,1
    38fa:	41a010ef          	jal	4d14 <exit>
  pipe(pfds);
    38fe:	fc840513          	addi	a0,s0,-56
    3902:	422010ef          	jal	4d24 <pipe>
  pid3 = fork();
    3906:	406010ef          	jal	4d0c <fork>
    390a:	8a2a                	mv	s4,a0
  if(pid3 < 0) {
    390c:	02054863          	bltz	a0,393c <preempt+0x94>
  if(pid3 == 0){
    3910:	e921                	bnez	a0,3960 <preempt+0xb8>
    close(pfds[0]);
    3912:	fc842503          	lw	a0,-56(s0)
    3916:	426010ef          	jal	4d3c <close>
    if(write(pfds[1], "x", 1) != 1)
    391a:	4605                	li	a2,1
    391c:	00002597          	auipc	a1,0x2
    3920:	c6c58593          	addi	a1,a1,-916 # 5588 <thread_switch+0x112>
    3924:	fcc42503          	lw	a0,-52(s0)
    3928:	40c010ef          	jal	4d34 <write>
    392c:	4785                	li	a5,1
    392e:	02f51163          	bne	a0,a5,3950 <preempt+0xa8>
    close(pfds[1]);
    3932:	fcc42503          	lw	a0,-52(s0)
    3936:	406010ef          	jal	4d3c <close>
    for(;;)
    393a:	a001                	j	393a <preempt+0x92>
     printf("%s: fork failed\n", s);
    393c:	85ca                	mv	a1,s2
    393e:	00002517          	auipc	a0,0x2
    3942:	46a50513          	addi	a0,a0,1130 # 5da8 <thread_switch+0x932>
    3946:	011010ef          	jal	5156 <printf>
     exit(1);
    394a:	4505                	li	a0,1
    394c:	3c8010ef          	jal	4d14 <exit>
      printf("%s: preempt write error", s);
    3950:	85ca                	mv	a1,s2
    3952:	00003517          	auipc	a0,0x3
    3956:	65e50513          	addi	a0,a0,1630 # 6fb0 <thread_switch+0x1b3a>
    395a:	7fc010ef          	jal	5156 <printf>
    395e:	bfd1                	j	3932 <preempt+0x8a>
  close(pfds[1]);
    3960:	fcc42503          	lw	a0,-52(s0)
    3964:	3d8010ef          	jal	4d3c <close>
  if(read(pfds[0], buf, sizeof(buf)) != 1){
    3968:	660d                	lui	a2,0x3
    396a:	00008597          	auipc	a1,0x8
    396e:	30e58593          	addi	a1,a1,782 # bc78 <buf>
    3972:	fc842503          	lw	a0,-56(s0)
    3976:	3b6010ef          	jal	4d2c <read>
    397a:	4785                	li	a5,1
    397c:	00f50a63          	beq	a0,a5,3990 <preempt+0xe8>
    printf("%s: preempt read error", s);
    3980:	85ca                	mv	a1,s2
    3982:	00003517          	auipc	a0,0x3
    3986:	64650513          	addi	a0,a0,1606 # 6fc8 <thread_switch+0x1b52>
    398a:	7cc010ef          	jal	5156 <printf>
    return;
    398e:	a099                	j	39d4 <preempt+0x12c>
  close(pfds[0]);
    3990:	fc842503          	lw	a0,-56(s0)
    3994:	3a8010ef          	jal	4d3c <close>
  printf("kill... ");
    3998:	00003517          	auipc	a0,0x3
    399c:	64850513          	addi	a0,a0,1608 # 6fe0 <thread_switch+0x1b6a>
    39a0:	7b6010ef          	jal	5156 <printf>
  kill(pid1);
    39a4:	8526                	mv	a0,s1
    39a6:	39e010ef          	jal	4d44 <kill>
  kill(pid2);
    39aa:	854e                	mv	a0,s3
    39ac:	398010ef          	jal	4d44 <kill>
  kill(pid3);
    39b0:	8552                	mv	a0,s4
    39b2:	392010ef          	jal	4d44 <kill>
  printf("wait... ");
    39b6:	00003517          	auipc	a0,0x3
    39ba:	63a50513          	addi	a0,a0,1594 # 6ff0 <thread_switch+0x1b7a>
    39be:	798010ef          	jal	5156 <printf>
  wait(0);
    39c2:	4501                	li	a0,0
    39c4:	358010ef          	jal	4d1c <wait>
  wait(0);
    39c8:	4501                	li	a0,0
    39ca:	352010ef          	jal	4d1c <wait>
  wait(0);
    39ce:	4501                	li	a0,0
    39d0:	34c010ef          	jal	4d1c <wait>
}
    39d4:	70e2                	ld	ra,56(sp)
    39d6:	7442                	ld	s0,48(sp)
    39d8:	74a2                	ld	s1,40(sp)
    39da:	7902                	ld	s2,32(sp)
    39dc:	69e2                	ld	s3,24(sp)
    39de:	6a42                	ld	s4,16(sp)
    39e0:	6121                	addi	sp,sp,64
    39e2:	8082                	ret

00000000000039e4 <reparent>:
{
    39e4:	7179                	addi	sp,sp,-48
    39e6:	f406                	sd	ra,40(sp)
    39e8:	f022                	sd	s0,32(sp)
    39ea:	ec26                	sd	s1,24(sp)
    39ec:	e84a                	sd	s2,16(sp)
    39ee:	e44e                	sd	s3,8(sp)
    39f0:	e052                	sd	s4,0(sp)
    39f2:	1800                	addi	s0,sp,48
    39f4:	89aa                	mv	s3,a0
  int master_pid = getpid();
    39f6:	39e010ef          	jal	4d94 <getpid>
    39fa:	8a2a                	mv	s4,a0
    39fc:	0c800913          	li	s2,200
    int pid = fork();
    3a00:	30c010ef          	jal	4d0c <fork>
    3a04:	84aa                	mv	s1,a0
    if(pid < 0){
    3a06:	00054e63          	bltz	a0,3a22 <reparent+0x3e>
    if(pid){
    3a0a:	c121                	beqz	a0,3a4a <reparent+0x66>
      if(wait(0) != pid){
    3a0c:	4501                	li	a0,0
    3a0e:	30e010ef          	jal	4d1c <wait>
    3a12:	02951263          	bne	a0,s1,3a36 <reparent+0x52>
  for(int i = 0; i < 200; i++){
    3a16:	397d                	addiw	s2,s2,-1
    3a18:	fe0914e3          	bnez	s2,3a00 <reparent+0x1c>
  exit(0);
    3a1c:	4501                	li	a0,0
    3a1e:	2f6010ef          	jal	4d14 <exit>
      printf("%s: fork failed\n", s);
    3a22:	85ce                	mv	a1,s3
    3a24:	00002517          	auipc	a0,0x2
    3a28:	38450513          	addi	a0,a0,900 # 5da8 <thread_switch+0x932>
    3a2c:	72a010ef          	jal	5156 <printf>
      exit(1);
    3a30:	4505                	li	a0,1
    3a32:	2e2010ef          	jal	4d14 <exit>
        printf("%s: wait wrong pid\n", s);
    3a36:	85ce                	mv	a1,s3
    3a38:	00002517          	auipc	a0,0x2
    3a3c:	4f850513          	addi	a0,a0,1272 # 5f30 <thread_switch+0xaba>
    3a40:	716010ef          	jal	5156 <printf>
        exit(1);
    3a44:	4505                	li	a0,1
    3a46:	2ce010ef          	jal	4d14 <exit>
      int pid2 = fork();
    3a4a:	2c2010ef          	jal	4d0c <fork>
      if(pid2 < 0){
    3a4e:	00054563          	bltz	a0,3a58 <reparent+0x74>
      exit(0);
    3a52:	4501                	li	a0,0
    3a54:	2c0010ef          	jal	4d14 <exit>
        kill(master_pid);
    3a58:	8552                	mv	a0,s4
    3a5a:	2ea010ef          	jal	4d44 <kill>
        exit(1);
    3a5e:	4505                	li	a0,1
    3a60:	2b4010ef          	jal	4d14 <exit>

0000000000003a64 <sbrkfail>:
{
    3a64:	7175                	addi	sp,sp,-144
    3a66:	e506                	sd	ra,136(sp)
    3a68:	e122                	sd	s0,128(sp)
    3a6a:	fca6                	sd	s1,120(sp)
    3a6c:	f8ca                	sd	s2,112(sp)
    3a6e:	f4ce                	sd	s3,104(sp)
    3a70:	f0d2                	sd	s4,96(sp)
    3a72:	ecd6                	sd	s5,88(sp)
    3a74:	e8da                	sd	s6,80(sp)
    3a76:	e4de                	sd	s7,72(sp)
    3a78:	0900                	addi	s0,sp,144
    3a7a:	8baa                	mv	s7,a0
  if(pipe(fds) != 0){
    3a7c:	fa040513          	addi	a0,s0,-96
    3a80:	2a4010ef          	jal	4d24 <pipe>
    3a84:	e919                	bnez	a0,3a9a <sbrkfail+0x36>
    3a86:	f7040493          	addi	s1,s0,-144
    3a8a:	f9840993          	addi	s3,s0,-104
    3a8e:	8926                	mv	s2,s1
    if(pids[i] != -1)
    3a90:	5a7d                	li	s4,-1
      read(fds[0], &scratch, 1);
    3a92:	f9f40b13          	addi	s6,s0,-97
    3a96:	4a85                	li	s5,1
    3a98:	a0a9                	j	3ae2 <sbrkfail+0x7e>
    printf("%s: pipe() failed\n", s);
    3a9a:	85de                	mv	a1,s7
    3a9c:	00002517          	auipc	a0,0x2
    3aa0:	41450513          	addi	a0,a0,1044 # 5eb0 <thread_switch+0xa3a>
    3aa4:	6b2010ef          	jal	5156 <printf>
    exit(1);
    3aa8:	4505                	li	a0,1
    3aaa:	26a010ef          	jal	4d14 <exit>
      sbrk(BIG - (uint64)sbrk(0));
    3aae:	2ee010ef          	jal	4d9c <sbrk>
    3ab2:	064007b7          	lui	a5,0x6400
    3ab6:	40a7853b          	subw	a0,a5,a0
    3aba:	2e2010ef          	jal	4d9c <sbrk>
      write(fds[1], "x", 1);
    3abe:	4605                	li	a2,1
    3ac0:	00002597          	auipc	a1,0x2
    3ac4:	ac858593          	addi	a1,a1,-1336 # 5588 <thread_switch+0x112>
    3ac8:	fa442503          	lw	a0,-92(s0)
    3acc:	268010ef          	jal	4d34 <write>
      for(;;) sleep(1000);
    3ad0:	3e800493          	li	s1,1000
    3ad4:	8526                	mv	a0,s1
    3ad6:	2ce010ef          	jal	4da4 <sleep>
    3ada:	bfed                	j	3ad4 <sbrkfail+0x70>
  for(i = 0; i < sizeof(pids)/sizeof(pids[0]); i++){
    3adc:	0911                	addi	s2,s2,4
    3ade:	03390063          	beq	s2,s3,3afe <sbrkfail+0x9a>
    if((pids[i] = fork()) == 0){
    3ae2:	22a010ef          	jal	4d0c <fork>
    3ae6:	00a92023          	sw	a0,0(s2)
    3aea:	d171                	beqz	a0,3aae <sbrkfail+0x4a>
    if(pids[i] != -1)
    3aec:	ff4508e3          	beq	a0,s4,3adc <sbrkfail+0x78>
      read(fds[0], &scratch, 1);
    3af0:	8656                	mv	a2,s5
    3af2:	85da                	mv	a1,s6
    3af4:	fa042503          	lw	a0,-96(s0)
    3af8:	234010ef          	jal	4d2c <read>
    3afc:	b7c5                	j	3adc <sbrkfail+0x78>
  c = sbrk(PGSIZE);
    3afe:	6505                	lui	a0,0x1
    3b00:	29c010ef          	jal	4d9c <sbrk>
    3b04:	8a2a                	mv	s4,a0
    if(pids[i] == -1)
    3b06:	597d                	li	s2,-1
    3b08:	a021                	j	3b10 <sbrkfail+0xac>
  for(i = 0; i < sizeof(pids)/sizeof(pids[0]); i++){
    3b0a:	0491                	addi	s1,s1,4
    3b0c:	01348b63          	beq	s1,s3,3b22 <sbrkfail+0xbe>
    if(pids[i] == -1)
    3b10:	4088                	lw	a0,0(s1)
    3b12:	ff250ce3          	beq	a0,s2,3b0a <sbrkfail+0xa6>
    kill(pids[i]);
    3b16:	22e010ef          	jal	4d44 <kill>
    wait(0);
    3b1a:	4501                	li	a0,0
    3b1c:	200010ef          	jal	4d1c <wait>
    3b20:	b7ed                	j	3b0a <sbrkfail+0xa6>
  if(c == (char*)0xffffffffffffffffL){
    3b22:	57fd                	li	a5,-1
    3b24:	04fa0263          	beq	s4,a5,3b68 <sbrkfail+0x104>
  pid = fork();
    3b28:	1e4010ef          	jal	4d0c <fork>
    3b2c:	84aa                	mv	s1,a0
  if(pid < 0){
    3b2e:	04054763          	bltz	a0,3b7c <sbrkfail+0x118>
  if(pid == 0){
    3b32:	cd39                	beqz	a0,3b90 <sbrkfail+0x12c>
  wait(&xstatus);
    3b34:	fac40513          	addi	a0,s0,-84
    3b38:	1e4010ef          	jal	4d1c <wait>
  if(xstatus != -1 && xstatus != 2)
    3b3c:	fac42783          	lw	a5,-84(s0)
    3b40:	00178713          	addi	a4,a5,1 # 6400001 <all_thread+0x63f1379>
    3b44:	00e03733          	snez	a4,a4
    3b48:	17f9                	addi	a5,a5,-2
    3b4a:	00f037b3          	snez	a5,a5
    3b4e:	8ff9                	and	a5,a5,a4
    3b50:	efb5                	bnez	a5,3bcc <sbrkfail+0x168>
}
    3b52:	60aa                	ld	ra,136(sp)
    3b54:	640a                	ld	s0,128(sp)
    3b56:	74e6                	ld	s1,120(sp)
    3b58:	7946                	ld	s2,112(sp)
    3b5a:	79a6                	ld	s3,104(sp)
    3b5c:	7a06                	ld	s4,96(sp)
    3b5e:	6ae6                	ld	s5,88(sp)
    3b60:	6b46                	ld	s6,80(sp)
    3b62:	6ba6                	ld	s7,72(sp)
    3b64:	6149                	addi	sp,sp,144
    3b66:	8082                	ret
    printf("%s: failed sbrk leaked memory\n", s);
    3b68:	85de                	mv	a1,s7
    3b6a:	00003517          	auipc	a0,0x3
    3b6e:	49650513          	addi	a0,a0,1174 # 7000 <thread_switch+0x1b8a>
    3b72:	5e4010ef          	jal	5156 <printf>
    exit(1);
    3b76:	4505                	li	a0,1
    3b78:	19c010ef          	jal	4d14 <exit>
    printf("%s: fork failed\n", s);
    3b7c:	85de                	mv	a1,s7
    3b7e:	00002517          	auipc	a0,0x2
    3b82:	22a50513          	addi	a0,a0,554 # 5da8 <thread_switch+0x932>
    3b86:	5d0010ef          	jal	5156 <printf>
    exit(1);
    3b8a:	4505                	li	a0,1
    3b8c:	188010ef          	jal	4d14 <exit>
    a = sbrk(0);
    3b90:	4501                	li	a0,0
    3b92:	20a010ef          	jal	4d9c <sbrk>
    3b96:	892a                	mv	s2,a0
    sbrk(10*BIG);
    3b98:	3e800537          	lui	a0,0x3e800
    3b9c:	200010ef          	jal	4d9c <sbrk>
    for (i = 0; i < 10*BIG; i += PGSIZE) {
    3ba0:	87ca                	mv	a5,s2
    3ba2:	3e800737          	lui	a4,0x3e800
    3ba6:	993a                	add	s2,s2,a4
    3ba8:	6705                	lui	a4,0x1
      n += *(a+i);
    3baa:	0007c603          	lbu	a2,0(a5)
    3bae:	9e25                	addw	a2,a2,s1
    3bb0:	84b2                	mv	s1,a2
    for (i = 0; i < 10*BIG; i += PGSIZE) {
    3bb2:	97ba                	add	a5,a5,a4
    3bb4:	fef91be3          	bne	s2,a5,3baa <sbrkfail+0x146>
    printf("%s: allocate a lot of memory succeeded %d\n", s, n);
    3bb8:	85de                	mv	a1,s7
    3bba:	00003517          	auipc	a0,0x3
    3bbe:	46650513          	addi	a0,a0,1126 # 7020 <thread_switch+0x1baa>
    3bc2:	594010ef          	jal	5156 <printf>
    exit(1);
    3bc6:	4505                	li	a0,1
    3bc8:	14c010ef          	jal	4d14 <exit>
    exit(1);
    3bcc:	4505                	li	a0,1
    3bce:	146010ef          	jal	4d14 <exit>

0000000000003bd2 <mem>:
{
    3bd2:	7139                	addi	sp,sp,-64
    3bd4:	fc06                	sd	ra,56(sp)
    3bd6:	f822                	sd	s0,48(sp)
    3bd8:	f426                	sd	s1,40(sp)
    3bda:	f04a                	sd	s2,32(sp)
    3bdc:	ec4e                	sd	s3,24(sp)
    3bde:	0080                	addi	s0,sp,64
    3be0:	89aa                	mv	s3,a0
  if((pid = fork()) == 0){
    3be2:	12a010ef          	jal	4d0c <fork>
    m1 = 0;
    3be6:	4481                	li	s1,0
    while((m2 = malloc(10001)) != 0){
    3be8:	6909                	lui	s2,0x2
    3bea:	71190913          	addi	s2,s2,1809 # 2711 <execout+0x11>
  if((pid = fork()) == 0){
    3bee:	cd11                	beqz	a0,3c0a <mem+0x38>
    wait(&xstatus);
    3bf0:	fcc40513          	addi	a0,s0,-52
    3bf4:	128010ef          	jal	4d1c <wait>
    if(xstatus == -1){
    3bf8:	fcc42503          	lw	a0,-52(s0)
    3bfc:	57fd                	li	a5,-1
    3bfe:	04f50363          	beq	a0,a5,3c44 <mem+0x72>
    exit(xstatus);
    3c02:	112010ef          	jal	4d14 <exit>
      *(char**)m2 = m1;
    3c06:	e104                	sd	s1,0(a0)
      m1 = m2;
    3c08:	84aa                	mv	s1,a0
    while((m2 = malloc(10001)) != 0){
    3c0a:	854a                	mv	a0,s2
    3c0c:	606010ef          	jal	5212 <malloc>
    3c10:	f97d                	bnez	a0,3c06 <mem+0x34>
    while(m1){
    3c12:	c491                	beqz	s1,3c1e <mem+0x4c>
      m2 = *(char**)m1;
    3c14:	8526                	mv	a0,s1
    3c16:	6084                	ld	s1,0(s1)
      free(m1);
    3c18:	570010ef          	jal	5188 <free>
    while(m1){
    3c1c:	fce5                	bnez	s1,3c14 <mem+0x42>
    m1 = malloc(1024*20);
    3c1e:	6515                	lui	a0,0x5
    3c20:	5f2010ef          	jal	5212 <malloc>
    if(m1 == 0){
    3c24:	c511                	beqz	a0,3c30 <mem+0x5e>
    free(m1);
    3c26:	562010ef          	jal	5188 <free>
    exit(0);
    3c2a:	4501                	li	a0,0
    3c2c:	0e8010ef          	jal	4d14 <exit>
      printf("%s: couldn't allocate mem?!!\n", s);
    3c30:	85ce                	mv	a1,s3
    3c32:	00003517          	auipc	a0,0x3
    3c36:	41e50513          	addi	a0,a0,1054 # 7050 <thread_switch+0x1bda>
    3c3a:	51c010ef          	jal	5156 <printf>
      exit(1);
    3c3e:	4505                	li	a0,1
    3c40:	0d4010ef          	jal	4d14 <exit>
      exit(0);
    3c44:	4501                	li	a0,0
    3c46:	0ce010ef          	jal	4d14 <exit>

0000000000003c4a <sharedfd>:
{
    3c4a:	7159                	addi	sp,sp,-112
    3c4c:	f486                	sd	ra,104(sp)
    3c4e:	f0a2                	sd	s0,96(sp)
    3c50:	eca6                	sd	s1,88(sp)
    3c52:	f85a                	sd	s6,48(sp)
    3c54:	1880                	addi	s0,sp,112
    3c56:	84aa                	mv	s1,a0
    3c58:	8b2a                	mv	s6,a0
  unlink("sharedfd");
    3c5a:	00003517          	auipc	a0,0x3
    3c5e:	41650513          	addi	a0,a0,1046 # 7070 <thread_switch+0x1bfa>
    3c62:	102010ef          	jal	4d64 <unlink>
  fd = open("sharedfd", O_CREATE|O_RDWR);
    3c66:	20200593          	li	a1,514
    3c6a:	00003517          	auipc	a0,0x3
    3c6e:	40650513          	addi	a0,a0,1030 # 7070 <thread_switch+0x1bfa>
    3c72:	0e2010ef          	jal	4d54 <open>
  if(fd < 0){
    3c76:	04054863          	bltz	a0,3cc6 <sharedfd+0x7c>
    3c7a:	e8ca                	sd	s2,80(sp)
    3c7c:	e4ce                	sd	s3,72(sp)
    3c7e:	e0d2                	sd	s4,64(sp)
    3c80:	fc56                	sd	s5,56(sp)
    3c82:	89aa                	mv	s3,a0
  pid = fork();
    3c84:	088010ef          	jal	4d0c <fork>
    3c88:	8aaa                	mv	s5,a0
  memset(buf, pid==0?'c':'p', sizeof(buf));
    3c8a:	07000593          	li	a1,112
    3c8e:	e119                	bnez	a0,3c94 <sharedfd+0x4a>
    3c90:	06300593          	li	a1,99
    3c94:	4629                	li	a2,10
    3c96:	fa040513          	addi	a0,s0,-96
    3c9a:	67d000ef          	jal	4b16 <memset>
    3c9e:	3e800493          	li	s1,1000
    if(write(fd, buf, sizeof(buf)) != sizeof(buf)){
    3ca2:	fa040a13          	addi	s4,s0,-96
    3ca6:	4929                	li	s2,10
    3ca8:	864a                	mv	a2,s2
    3caa:	85d2                	mv	a1,s4
    3cac:	854e                	mv	a0,s3
    3cae:	086010ef          	jal	4d34 <write>
    3cb2:	03251963          	bne	a0,s2,3ce4 <sharedfd+0x9a>
  for(i = 0; i < N; i++){
    3cb6:	34fd                	addiw	s1,s1,-1
    3cb8:	f8e5                	bnez	s1,3ca8 <sharedfd+0x5e>
  if(pid == 0) {
    3cba:	040a9063          	bnez	s5,3cfa <sharedfd+0xb0>
    3cbe:	f45e                	sd	s7,40(sp)
    exit(0);
    3cc0:	4501                	li	a0,0
    3cc2:	052010ef          	jal	4d14 <exit>
    3cc6:	e8ca                	sd	s2,80(sp)
    3cc8:	e4ce                	sd	s3,72(sp)
    3cca:	e0d2                	sd	s4,64(sp)
    3ccc:	fc56                	sd	s5,56(sp)
    3cce:	f45e                	sd	s7,40(sp)
    printf("%s: cannot open sharedfd for writing", s);
    3cd0:	85a6                	mv	a1,s1
    3cd2:	00003517          	auipc	a0,0x3
    3cd6:	3ae50513          	addi	a0,a0,942 # 7080 <thread_switch+0x1c0a>
    3cda:	47c010ef          	jal	5156 <printf>
    exit(1);
    3cde:	4505                	li	a0,1
    3ce0:	034010ef          	jal	4d14 <exit>
    3ce4:	f45e                	sd	s7,40(sp)
      printf("%s: write sharedfd failed\n", s);
    3ce6:	85da                	mv	a1,s6
    3ce8:	00003517          	auipc	a0,0x3
    3cec:	3c050513          	addi	a0,a0,960 # 70a8 <thread_switch+0x1c32>
    3cf0:	466010ef          	jal	5156 <printf>
      exit(1);
    3cf4:	4505                	li	a0,1
    3cf6:	01e010ef          	jal	4d14 <exit>
    wait(&xstatus);
    3cfa:	f9c40513          	addi	a0,s0,-100
    3cfe:	01e010ef          	jal	4d1c <wait>
    if(xstatus != 0)
    3d02:	f9c42a03          	lw	s4,-100(s0)
    3d06:	000a0663          	beqz	s4,3d12 <sharedfd+0xc8>
    3d0a:	f45e                	sd	s7,40(sp)
      exit(xstatus);
    3d0c:	8552                	mv	a0,s4
    3d0e:	006010ef          	jal	4d14 <exit>
    3d12:	f45e                	sd	s7,40(sp)
  close(fd);
    3d14:	854e                	mv	a0,s3
    3d16:	026010ef          	jal	4d3c <close>
  fd = open("sharedfd", 0);
    3d1a:	4581                	li	a1,0
    3d1c:	00003517          	auipc	a0,0x3
    3d20:	35450513          	addi	a0,a0,852 # 7070 <thread_switch+0x1bfa>
    3d24:	030010ef          	jal	4d54 <open>
    3d28:	8baa                	mv	s7,a0
  nc = np = 0;
    3d2a:	89d2                	mv	s3,s4
  if(fd < 0){
    3d2c:	02054363          	bltz	a0,3d52 <sharedfd+0x108>
    3d30:	faa40913          	addi	s2,s0,-86
      if(buf[i] == 'c')
    3d34:	06300493          	li	s1,99
      if(buf[i] == 'p')
    3d38:	07000a93          	li	s5,112
  while((n = read(fd, buf, sizeof(buf))) > 0){
    3d3c:	4629                	li	a2,10
    3d3e:	fa040593          	addi	a1,s0,-96
    3d42:	855e                	mv	a0,s7
    3d44:	7e9000ef          	jal	4d2c <read>
    3d48:	02a05b63          	blez	a0,3d7e <sharedfd+0x134>
    3d4c:	fa040793          	addi	a5,s0,-96
    3d50:	a839                	j	3d6e <sharedfd+0x124>
    printf("%s: cannot open sharedfd for reading\n", s);
    3d52:	85da                	mv	a1,s6
    3d54:	00003517          	auipc	a0,0x3
    3d58:	37450513          	addi	a0,a0,884 # 70c8 <thread_switch+0x1c52>
    3d5c:	3fa010ef          	jal	5156 <printf>
    exit(1);
    3d60:	4505                	li	a0,1
    3d62:	7b3000ef          	jal	4d14 <exit>
        nc++;
    3d66:	2a05                	addiw	s4,s4,1
    for(i = 0; i < sizeof(buf); i++){
    3d68:	0785                	addi	a5,a5,1
    3d6a:	fd2789e3          	beq	a5,s2,3d3c <sharedfd+0xf2>
      if(buf[i] == 'c')
    3d6e:	0007c703          	lbu	a4,0(a5)
    3d72:	fe970ae3          	beq	a4,s1,3d66 <sharedfd+0x11c>
      if(buf[i] == 'p')
    3d76:	ff5719e3          	bne	a4,s5,3d68 <sharedfd+0x11e>
        np++;
    3d7a:	2985                	addiw	s3,s3,1
    3d7c:	b7f5                	j	3d68 <sharedfd+0x11e>
  close(fd);
    3d7e:	855e                	mv	a0,s7
    3d80:	7bd000ef          	jal	4d3c <close>
  unlink("sharedfd");
    3d84:	00003517          	auipc	a0,0x3
    3d88:	2ec50513          	addi	a0,a0,748 # 7070 <thread_switch+0x1bfa>
    3d8c:	7d9000ef          	jal	4d64 <unlink>
  if(nc == N*SZ && np == N*SZ){
    3d90:	6789                	lui	a5,0x2
    3d92:	71078793          	addi	a5,a5,1808 # 2710 <execout+0x10>
    3d96:	00fa1763          	bne	s4,a5,3da4 <sharedfd+0x15a>
    3d9a:	01499563          	bne	s3,s4,3da4 <sharedfd+0x15a>
    exit(0);
    3d9e:	4501                	li	a0,0
    3da0:	775000ef          	jal	4d14 <exit>
    printf("%s: nc/np test fails\n", s);
    3da4:	85da                	mv	a1,s6
    3da6:	00003517          	auipc	a0,0x3
    3daa:	34a50513          	addi	a0,a0,842 # 70f0 <thread_switch+0x1c7a>
    3dae:	3a8010ef          	jal	5156 <printf>
    exit(1);
    3db2:	4505                	li	a0,1
    3db4:	761000ef          	jal	4d14 <exit>

0000000000003db8 <fourfiles>:
{
    3db8:	7135                	addi	sp,sp,-160
    3dba:	ed06                	sd	ra,152(sp)
    3dbc:	e922                	sd	s0,144(sp)
    3dbe:	e526                	sd	s1,136(sp)
    3dc0:	e14a                	sd	s2,128(sp)
    3dc2:	fcce                	sd	s3,120(sp)
    3dc4:	f8d2                	sd	s4,112(sp)
    3dc6:	f4d6                	sd	s5,104(sp)
    3dc8:	f0da                	sd	s6,96(sp)
    3dca:	ecde                	sd	s7,88(sp)
    3dcc:	e8e2                	sd	s8,80(sp)
    3dce:	e4e6                	sd	s9,72(sp)
    3dd0:	e0ea                	sd	s10,64(sp)
    3dd2:	fc6e                	sd	s11,56(sp)
    3dd4:	1100                	addi	s0,sp,160
    3dd6:	8caa                	mv	s9,a0
  char *names[] = { "f0", "f1", "f2", "f3" };
    3dd8:	00003797          	auipc	a5,0x3
    3ddc:	33078793          	addi	a5,a5,816 # 7108 <thread_switch+0x1c92>
    3de0:	f6f43823          	sd	a5,-144(s0)
    3de4:	00003797          	auipc	a5,0x3
    3de8:	32c78793          	addi	a5,a5,812 # 7110 <thread_switch+0x1c9a>
    3dec:	f6f43c23          	sd	a5,-136(s0)
    3df0:	00003797          	auipc	a5,0x3
    3df4:	32878793          	addi	a5,a5,808 # 7118 <thread_switch+0x1ca2>
    3df8:	f8f43023          	sd	a5,-128(s0)
    3dfc:	00003797          	auipc	a5,0x3
    3e00:	32478793          	addi	a5,a5,804 # 7120 <thread_switch+0x1caa>
    3e04:	f8f43423          	sd	a5,-120(s0)
  for(pi = 0; pi < NCHILD; pi++){
    3e08:	f7040b93          	addi	s7,s0,-144
  char *names[] = { "f0", "f1", "f2", "f3" };
    3e0c:	895e                	mv	s2,s7
  for(pi = 0; pi < NCHILD; pi++){
    3e0e:	4481                	li	s1,0
    3e10:	4a11                	li	s4,4
    fname = names[pi];
    3e12:	00093983          	ld	s3,0(s2)
    unlink(fname);
    3e16:	854e                	mv	a0,s3
    3e18:	74d000ef          	jal	4d64 <unlink>
    pid = fork();
    3e1c:	6f1000ef          	jal	4d0c <fork>
    if(pid < 0){
    3e20:	04054063          	bltz	a0,3e60 <fourfiles+0xa8>
    if(pid == 0){
    3e24:	c921                	beqz	a0,3e74 <fourfiles+0xbc>
  for(pi = 0; pi < NCHILD; pi++){
    3e26:	2485                	addiw	s1,s1,1
    3e28:	0921                	addi	s2,s2,8
    3e2a:	ff4494e3          	bne	s1,s4,3e12 <fourfiles+0x5a>
    3e2e:	4491                	li	s1,4
    wait(&xstatus);
    3e30:	f6c40913          	addi	s2,s0,-148
    3e34:	854a                	mv	a0,s2
    3e36:	6e7000ef          	jal	4d1c <wait>
    if(xstatus != 0)
    3e3a:	f6c42b03          	lw	s6,-148(s0)
    3e3e:	0a0b1463          	bnez	s6,3ee6 <fourfiles+0x12e>
  for(pi = 0; pi < NCHILD; pi++){
    3e42:	34fd                	addiw	s1,s1,-1
    3e44:	f8e5                	bnez	s1,3e34 <fourfiles+0x7c>
    3e46:	03000493          	li	s1,48
    while((n = read(fd, buf, sizeof(buf))) > 0){
    3e4a:	6a8d                	lui	s5,0x3
    3e4c:	00008a17          	auipc	s4,0x8
    3e50:	e2ca0a13          	addi	s4,s4,-468 # bc78 <buf>
    if(total != N*SZ){
    3e54:	6d05                	lui	s10,0x1
    3e56:	770d0d13          	addi	s10,s10,1904 # 1770 <exitwait+0x90>
  for(i = 0; i < NCHILD; i++){
    3e5a:	03400d93          	li	s11,52
    3e5e:	a86d                	j	3f18 <fourfiles+0x160>
      printf("%s: fork failed\n", s);
    3e60:	85e6                	mv	a1,s9
    3e62:	00002517          	auipc	a0,0x2
    3e66:	f4650513          	addi	a0,a0,-186 # 5da8 <thread_switch+0x932>
    3e6a:	2ec010ef          	jal	5156 <printf>
      exit(1);
    3e6e:	4505                	li	a0,1
    3e70:	6a5000ef          	jal	4d14 <exit>
      fd = open(fname, O_CREATE | O_RDWR);
    3e74:	20200593          	li	a1,514
    3e78:	854e                	mv	a0,s3
    3e7a:	6db000ef          	jal	4d54 <open>
    3e7e:	892a                	mv	s2,a0
      if(fd < 0){
    3e80:	04054063          	bltz	a0,3ec0 <fourfiles+0x108>
      memset(buf, '0'+pi, SZ);
    3e84:	1f400613          	li	a2,500
    3e88:	0304859b          	addiw	a1,s1,48
    3e8c:	00008517          	auipc	a0,0x8
    3e90:	dec50513          	addi	a0,a0,-532 # bc78 <buf>
    3e94:	483000ef          	jal	4b16 <memset>
    3e98:	44b1                	li	s1,12
        if((n = write(fd, buf, SZ)) != SZ){
    3e9a:	1f400993          	li	s3,500
    3e9e:	00008a17          	auipc	s4,0x8
    3ea2:	ddaa0a13          	addi	s4,s4,-550 # bc78 <buf>
    3ea6:	864e                	mv	a2,s3
    3ea8:	85d2                	mv	a1,s4
    3eaa:	854a                	mv	a0,s2
    3eac:	689000ef          	jal	4d34 <write>
    3eb0:	85aa                	mv	a1,a0
    3eb2:	03351163          	bne	a0,s3,3ed4 <fourfiles+0x11c>
      for(i = 0; i < N; i++){
    3eb6:	34fd                	addiw	s1,s1,-1
    3eb8:	f4fd                	bnez	s1,3ea6 <fourfiles+0xee>
      exit(0);
    3eba:	4501                	li	a0,0
    3ebc:	659000ef          	jal	4d14 <exit>
        printf("%s: create failed\n", s);
    3ec0:	85e6                	mv	a1,s9
    3ec2:	00002517          	auipc	a0,0x2
    3ec6:	f7e50513          	addi	a0,a0,-130 # 5e40 <thread_switch+0x9ca>
    3eca:	28c010ef          	jal	5156 <printf>
        exit(1);
    3ece:	4505                	li	a0,1
    3ed0:	645000ef          	jal	4d14 <exit>
          printf("write failed %d\n", n);
    3ed4:	00003517          	auipc	a0,0x3
    3ed8:	25450513          	addi	a0,a0,596 # 7128 <thread_switch+0x1cb2>
    3edc:	27a010ef          	jal	5156 <printf>
          exit(1);
    3ee0:	4505                	li	a0,1
    3ee2:	633000ef          	jal	4d14 <exit>
      exit(xstatus);
    3ee6:	855a                	mv	a0,s6
    3ee8:	62d000ef          	jal	4d14 <exit>
          printf("%s: wrong char\n", s);
    3eec:	85e6                	mv	a1,s9
    3eee:	00003517          	auipc	a0,0x3
    3ef2:	25250513          	addi	a0,a0,594 # 7140 <thread_switch+0x1cca>
    3ef6:	260010ef          	jal	5156 <printf>
          exit(1);
    3efa:	4505                	li	a0,1
    3efc:	619000ef          	jal	4d14 <exit>
    close(fd);
    3f00:	854e                	mv	a0,s3
    3f02:	63b000ef          	jal	4d3c <close>
    if(total != N*SZ){
    3f06:	05a91863          	bne	s2,s10,3f56 <fourfiles+0x19e>
    unlink(fname);
    3f0a:	8562                	mv	a0,s8
    3f0c:	659000ef          	jal	4d64 <unlink>
  for(i = 0; i < NCHILD; i++){
    3f10:	0ba1                	addi	s7,s7,8
    3f12:	2485                	addiw	s1,s1,1
    3f14:	05b48b63          	beq	s1,s11,3f6a <fourfiles+0x1b2>
    fname = names[i];
    3f18:	000bbc03          	ld	s8,0(s7)
    fd = open(fname, 0);
    3f1c:	4581                	li	a1,0
    3f1e:	8562                	mv	a0,s8
    3f20:	635000ef          	jal	4d54 <open>
    3f24:	89aa                	mv	s3,a0
    total = 0;
    3f26:	895a                	mv	s2,s6
    while((n = read(fd, buf, sizeof(buf))) > 0){
    3f28:	8656                	mv	a2,s5
    3f2a:	85d2                	mv	a1,s4
    3f2c:	854e                	mv	a0,s3
    3f2e:	5ff000ef          	jal	4d2c <read>
    3f32:	fca057e3          	blez	a0,3f00 <fourfiles+0x148>
    3f36:	00008797          	auipc	a5,0x8
    3f3a:	d4278793          	addi	a5,a5,-702 # bc78 <buf>
    3f3e:	00f506b3          	add	a3,a0,a5
        if(buf[j] != '0'+i){
    3f42:	0007c703          	lbu	a4,0(a5)
    3f46:	fa9713e3          	bne	a4,s1,3eec <fourfiles+0x134>
      for(j = 0; j < n; j++){
    3f4a:	0785                	addi	a5,a5,1
    3f4c:	fed79be3          	bne	a5,a3,3f42 <fourfiles+0x18a>
      total += n;
    3f50:	00a9093b          	addw	s2,s2,a0
    3f54:	bfd1                	j	3f28 <fourfiles+0x170>
      printf("wrong length %d\n", total);
    3f56:	85ca                	mv	a1,s2
    3f58:	00003517          	auipc	a0,0x3
    3f5c:	1f850513          	addi	a0,a0,504 # 7150 <thread_switch+0x1cda>
    3f60:	1f6010ef          	jal	5156 <printf>
      exit(1);
    3f64:	4505                	li	a0,1
    3f66:	5af000ef          	jal	4d14 <exit>
}
    3f6a:	60ea                	ld	ra,152(sp)
    3f6c:	644a                	ld	s0,144(sp)
    3f6e:	64aa                	ld	s1,136(sp)
    3f70:	690a                	ld	s2,128(sp)
    3f72:	79e6                	ld	s3,120(sp)
    3f74:	7a46                	ld	s4,112(sp)
    3f76:	7aa6                	ld	s5,104(sp)
    3f78:	7b06                	ld	s6,96(sp)
    3f7a:	6be6                	ld	s7,88(sp)
    3f7c:	6c46                	ld	s8,80(sp)
    3f7e:	6ca6                	ld	s9,72(sp)
    3f80:	6d06                	ld	s10,64(sp)
    3f82:	7de2                	ld	s11,56(sp)
    3f84:	610d                	addi	sp,sp,160
    3f86:	8082                	ret

0000000000003f88 <concreate>:
{
    3f88:	7171                	addi	sp,sp,-176
    3f8a:	f506                	sd	ra,168(sp)
    3f8c:	f122                	sd	s0,160(sp)
    3f8e:	ed26                	sd	s1,152(sp)
    3f90:	e94a                	sd	s2,144(sp)
    3f92:	e54e                	sd	s3,136(sp)
    3f94:	e152                	sd	s4,128(sp)
    3f96:	fcd6                	sd	s5,120(sp)
    3f98:	f8da                	sd	s6,112(sp)
    3f9a:	f4de                	sd	s7,104(sp)
    3f9c:	f0e2                	sd	s8,96(sp)
    3f9e:	ece6                	sd	s9,88(sp)
    3fa0:	e8ea                	sd	s10,80(sp)
    3fa2:	1900                	addi	s0,sp,176
    3fa4:	8d2a                	mv	s10,a0
  file[0] = 'C';
    3fa6:	04300793          	li	a5,67
    3faa:	f8f40c23          	sb	a5,-104(s0)
  file[2] = '\0';
    3fae:	f8040d23          	sb	zero,-102(s0)
  for(i = 0; i < N; i++){
    3fb2:	4901                	li	s2,0
    unlink(file);
    3fb4:	f9840993          	addi	s3,s0,-104
    if(pid && (i % 3) == 1){
    3fb8:	55555b37          	lui	s6,0x55555
    3fbc:	556b0b13          	addi	s6,s6,1366 # 55555556 <all_thread+0x555468ce>
    3fc0:	4b85                	li	s7,1
      fd = open(file, O_CREATE | O_RDWR);
    3fc2:	20200c13          	li	s8,514
      link("C0", file);
    3fc6:	00003c97          	auipc	s9,0x3
    3fca:	1a2c8c93          	addi	s9,s9,418 # 7168 <thread_switch+0x1cf2>
      wait(&xstatus);
    3fce:	f5c40a93          	addi	s5,s0,-164
  for(i = 0; i < N; i++){
    3fd2:	02800a13          	li	s4,40
    3fd6:	a481                	j	4216 <concreate+0x28e>
      link("C0", file);
    3fd8:	85ce                	mv	a1,s3
    3fda:	8566                	mv	a0,s9
    3fdc:	599000ef          	jal	4d74 <link>
    if(pid == 0) {
    3fe0:	a40d                	j	4202 <concreate+0x27a>
    } else if(pid == 0 && (i % 5) == 1){
    3fe2:	666667b7          	lui	a5,0x66666
    3fe6:	66778793          	addi	a5,a5,1639 # 66666667 <all_thread+0x666579df>
    3fea:	02f907b3          	mul	a5,s2,a5
    3fee:	9785                	srai	a5,a5,0x21
    3ff0:	41f9571b          	sraiw	a4,s2,0x1f
    3ff4:	9f99                	subw	a5,a5,a4
    3ff6:	0027971b          	slliw	a4,a5,0x2
    3ffa:	9fb9                	addw	a5,a5,a4
    3ffc:	40f9093b          	subw	s2,s2,a5
    4000:	4785                	li	a5,1
    4002:	02f90563          	beq	s2,a5,402c <concreate+0xa4>
      fd = open(file, O_CREATE | O_RDWR);
    4006:	20200593          	li	a1,514
    400a:	f9840513          	addi	a0,s0,-104
    400e:	547000ef          	jal	4d54 <open>
      if(fd < 0){
    4012:	1e055363          	bgez	a0,41f8 <concreate+0x270>
        printf("concreate create %s failed\n", file);
    4016:	f9840593          	addi	a1,s0,-104
    401a:	00003517          	auipc	a0,0x3
    401e:	15650513          	addi	a0,a0,342 # 7170 <thread_switch+0x1cfa>
    4022:	134010ef          	jal	5156 <printf>
        exit(1);
    4026:	4505                	li	a0,1
    4028:	4ed000ef          	jal	4d14 <exit>
      link("C0", file);
    402c:	f9840593          	addi	a1,s0,-104
    4030:	00003517          	auipc	a0,0x3
    4034:	13850513          	addi	a0,a0,312 # 7168 <thread_switch+0x1cf2>
    4038:	53d000ef          	jal	4d74 <link>
      exit(0);
    403c:	4501                	li	a0,0
    403e:	4d7000ef          	jal	4d14 <exit>
        exit(1);
    4042:	4505                	li	a0,1
    4044:	4d1000ef          	jal	4d14 <exit>
  memset(fa, 0, sizeof(fa));
    4048:	02800613          	li	a2,40
    404c:	4581                	li	a1,0
    404e:	f7040513          	addi	a0,s0,-144
    4052:	2c5000ef          	jal	4b16 <memset>
  fd = open(".", 0);
    4056:	4581                	li	a1,0
    4058:	00002517          	auipc	a0,0x2
    405c:	ba850513          	addi	a0,a0,-1112 # 5c00 <thread_switch+0x78a>
    4060:	4f5000ef          	jal	4d54 <open>
    4064:	892a                	mv	s2,a0
  n = 0;
    4066:	8b26                	mv	s6,s1
  while(read(fd, &de, sizeof(de)) > 0){
    4068:	f6040a13          	addi	s4,s0,-160
    406c:	49c1                	li	s3,16
    if(de.name[0] == 'C' && de.name[2] == '\0'){
    406e:	04300a93          	li	s5,67
      if(i < 0 || i >= sizeof(fa)){
    4072:	02700b93          	li	s7,39
      fa[i] = 1;
    4076:	4c05                	li	s8,1
  while(read(fd, &de, sizeof(de)) > 0){
    4078:	864e                	mv	a2,s3
    407a:	85d2                	mv	a1,s4
    407c:	854a                	mv	a0,s2
    407e:	4af000ef          	jal	4d2c <read>
    4082:	06a05763          	blez	a0,40f0 <concreate+0x168>
    if(de.inum == 0)
    4086:	f6045783          	lhu	a5,-160(s0)
    408a:	d7fd                	beqz	a5,4078 <concreate+0xf0>
    if(de.name[0] == 'C' && de.name[2] == '\0'){
    408c:	f6244783          	lbu	a5,-158(s0)
    4090:	ff5794e3          	bne	a5,s5,4078 <concreate+0xf0>
    4094:	f6444783          	lbu	a5,-156(s0)
    4098:	f3e5                	bnez	a5,4078 <concreate+0xf0>
      i = de.name[1] - '0';
    409a:	f6344783          	lbu	a5,-157(s0)
    409e:	fd07879b          	addiw	a5,a5,-48
      if(i < 0 || i >= sizeof(fa)){
    40a2:	00fbef63          	bltu	s7,a5,40c0 <concreate+0x138>
      if(fa[i]){
    40a6:	fa040713          	addi	a4,s0,-96
    40aa:	973e                	add	a4,a4,a5
    40ac:	fd074703          	lbu	a4,-48(a4) # fd0 <bigdir+0xdc>
    40b0:	e705                	bnez	a4,40d8 <concreate+0x150>
      fa[i] = 1;
    40b2:	fa040713          	addi	a4,s0,-96
    40b6:	97ba                	add	a5,a5,a4
    40b8:	fd878823          	sb	s8,-48(a5)
      n++;
    40bc:	2b05                	addiw	s6,s6,1
    40be:	bf6d                	j	4078 <concreate+0xf0>
        printf("%s: concreate weird file %s\n", s, de.name);
    40c0:	f6240613          	addi	a2,s0,-158
    40c4:	85ea                	mv	a1,s10
    40c6:	00003517          	auipc	a0,0x3
    40ca:	0ca50513          	addi	a0,a0,202 # 7190 <thread_switch+0x1d1a>
    40ce:	088010ef          	jal	5156 <printf>
        exit(1);
    40d2:	4505                	li	a0,1
    40d4:	441000ef          	jal	4d14 <exit>
        printf("%s: concreate duplicate file %s\n", s, de.name);
    40d8:	f6240613          	addi	a2,s0,-158
    40dc:	85ea                	mv	a1,s10
    40de:	00003517          	auipc	a0,0x3
    40e2:	0d250513          	addi	a0,a0,210 # 71b0 <thread_switch+0x1d3a>
    40e6:	070010ef          	jal	5156 <printf>
        exit(1);
    40ea:	4505                	li	a0,1
    40ec:	429000ef          	jal	4d14 <exit>
  close(fd);
    40f0:	854a                	mv	a0,s2
    40f2:	44b000ef          	jal	4d3c <close>
  if(n != N){
    40f6:	02800793          	li	a5,40
    40fa:	00fb1a63          	bne	s6,a5,410e <concreate+0x186>
    if(((i % 3) == 0 && pid == 0) ||
    40fe:	55555a37          	lui	s4,0x55555
    4102:	556a0a13          	addi	s4,s4,1366 # 55555556 <all_thread+0x555468ce>
      close(open(file, 0));
    4106:	f9840993          	addi	s3,s0,-104
  for(i = 0; i < N; i++){
    410a:	8ada                	mv	s5,s6
    410c:	a049                	j	418e <concreate+0x206>
    printf("%s: concreate not enough files in directory listing\n", s);
    410e:	85ea                	mv	a1,s10
    4110:	00003517          	auipc	a0,0x3
    4114:	0c850513          	addi	a0,a0,200 # 71d8 <thread_switch+0x1d62>
    4118:	03e010ef          	jal	5156 <printf>
    exit(1);
    411c:	4505                	li	a0,1
    411e:	3f7000ef          	jal	4d14 <exit>
      printf("%s: fork failed\n", s);
    4122:	85ea                	mv	a1,s10
    4124:	00002517          	auipc	a0,0x2
    4128:	c8450513          	addi	a0,a0,-892 # 5da8 <thread_switch+0x932>
    412c:	02a010ef          	jal	5156 <printf>
      exit(1);
    4130:	4505                	li	a0,1
    4132:	3e3000ef          	jal	4d14 <exit>
      close(open(file, 0));
    4136:	4581                	li	a1,0
    4138:	854e                	mv	a0,s3
    413a:	41b000ef          	jal	4d54 <open>
    413e:	3ff000ef          	jal	4d3c <close>
      close(open(file, 0));
    4142:	4581                	li	a1,0
    4144:	854e                	mv	a0,s3
    4146:	40f000ef          	jal	4d54 <open>
    414a:	3f3000ef          	jal	4d3c <close>
      close(open(file, 0));
    414e:	4581                	li	a1,0
    4150:	854e                	mv	a0,s3
    4152:	403000ef          	jal	4d54 <open>
    4156:	3e7000ef          	jal	4d3c <close>
      close(open(file, 0));
    415a:	4581                	li	a1,0
    415c:	854e                	mv	a0,s3
    415e:	3f7000ef          	jal	4d54 <open>
    4162:	3db000ef          	jal	4d3c <close>
      close(open(file, 0));
    4166:	4581                	li	a1,0
    4168:	854e                	mv	a0,s3
    416a:	3eb000ef          	jal	4d54 <open>
    416e:	3cf000ef          	jal	4d3c <close>
      close(open(file, 0));
    4172:	4581                	li	a1,0
    4174:	854e                	mv	a0,s3
    4176:	3df000ef          	jal	4d54 <open>
    417a:	3c3000ef          	jal	4d3c <close>
    if(pid == 0)
    417e:	06090a63          	beqz	s2,41f2 <concreate+0x26a>
      wait(0);
    4182:	4501                	li	a0,0
    4184:	399000ef          	jal	4d1c <wait>
  for(i = 0; i < N; i++){
    4188:	2485                	addiw	s1,s1,1
    418a:	0d548563          	beq	s1,s5,4254 <concreate+0x2cc>
    file[1] = '0' + i;
    418e:	0304879b          	addiw	a5,s1,48
    4192:	f8f40ca3          	sb	a5,-103(s0)
    pid = fork();
    4196:	377000ef          	jal	4d0c <fork>
    419a:	892a                	mv	s2,a0
    if(pid < 0){
    419c:	f80543e3          	bltz	a0,4122 <concreate+0x19a>
    if(((i % 3) == 0 && pid == 0) ||
    41a0:	03448733          	mul	a4,s1,s4
    41a4:	9301                	srli	a4,a4,0x20
    41a6:	41f4d79b          	sraiw	a5,s1,0x1f
    41aa:	9f1d                	subw	a4,a4,a5
    41ac:	0017179b          	slliw	a5,a4,0x1
    41b0:	9fb9                	addw	a5,a5,a4
    41b2:	40f487bb          	subw	a5,s1,a5
    41b6:	00a7e733          	or	a4,a5,a0
    41ba:	2701                	sext.w	a4,a4
    41bc:	df2d                	beqz	a4,4136 <concreate+0x1ae>
       ((i % 3) == 1 && pid != 0)){
    41be:	00a03733          	snez	a4,a0
    if(((i % 3) == 0 && pid == 0) ||
    41c2:	17fd                	addi	a5,a5,-1
    41c4:	0017b793          	seqz	a5,a5
       ((i % 3) == 1 && pid != 0)){
    41c8:	8ff9                	and	a5,a5,a4
    41ca:	f7b5                	bnez	a5,4136 <concreate+0x1ae>
      unlink(file);
    41cc:	854e                	mv	a0,s3
    41ce:	397000ef          	jal	4d64 <unlink>
      unlink(file);
    41d2:	854e                	mv	a0,s3
    41d4:	391000ef          	jal	4d64 <unlink>
      unlink(file);
    41d8:	854e                	mv	a0,s3
    41da:	38b000ef          	jal	4d64 <unlink>
      unlink(file);
    41de:	854e                	mv	a0,s3
    41e0:	385000ef          	jal	4d64 <unlink>
      unlink(file);
    41e4:	854e                	mv	a0,s3
    41e6:	37f000ef          	jal	4d64 <unlink>
      unlink(file);
    41ea:	854e                	mv	a0,s3
    41ec:	379000ef          	jal	4d64 <unlink>
    41f0:	b779                	j	417e <concreate+0x1f6>
      exit(0);
    41f2:	4501                	li	a0,0
    41f4:	321000ef          	jal	4d14 <exit>
      close(fd);
    41f8:	345000ef          	jal	4d3c <close>
    if(pid == 0) {
    41fc:	b581                	j	403c <concreate+0xb4>
      close(fd);
    41fe:	33f000ef          	jal	4d3c <close>
      wait(&xstatus);
    4202:	8556                	mv	a0,s5
    4204:	319000ef          	jal	4d1c <wait>
      if(xstatus != 0)
    4208:	f5c42483          	lw	s1,-164(s0)
    420c:	e2049be3          	bnez	s1,4042 <concreate+0xba>
  for(i = 0; i < N; i++){
    4210:	2905                	addiw	s2,s2,1
    4212:	e3490be3          	beq	s2,s4,4048 <concreate+0xc0>
    file[1] = '0' + i;
    4216:	0309079b          	addiw	a5,s2,48
    421a:	f8f40ca3          	sb	a5,-103(s0)
    unlink(file);
    421e:	854e                	mv	a0,s3
    4220:	345000ef          	jal	4d64 <unlink>
    pid = fork();
    4224:	2e9000ef          	jal	4d0c <fork>
    if(pid && (i % 3) == 1){
    4228:	da050de3          	beqz	a0,3fe2 <concreate+0x5a>
    422c:	036907b3          	mul	a5,s2,s6
    4230:	9381                	srli	a5,a5,0x20
    4232:	41f9571b          	sraiw	a4,s2,0x1f
    4236:	9f99                	subw	a5,a5,a4
    4238:	0017971b          	slliw	a4,a5,0x1
    423c:	9fb9                	addw	a5,a5,a4
    423e:	40f907bb          	subw	a5,s2,a5
    4242:	d9778be3          	beq	a5,s7,3fd8 <concreate+0x50>
      fd = open(file, O_CREATE | O_RDWR);
    4246:	85e2                	mv	a1,s8
    4248:	854e                	mv	a0,s3
    424a:	30b000ef          	jal	4d54 <open>
      if(fd < 0){
    424e:	fa0558e3          	bgez	a0,41fe <concreate+0x276>
    4252:	b3d1                	j	4016 <concreate+0x8e>
}
    4254:	70aa                	ld	ra,168(sp)
    4256:	740a                	ld	s0,160(sp)
    4258:	64ea                	ld	s1,152(sp)
    425a:	694a                	ld	s2,144(sp)
    425c:	69aa                	ld	s3,136(sp)
    425e:	6a0a                	ld	s4,128(sp)
    4260:	7ae6                	ld	s5,120(sp)
    4262:	7b46                	ld	s6,112(sp)
    4264:	7ba6                	ld	s7,104(sp)
    4266:	7c06                	ld	s8,96(sp)
    4268:	6ce6                	ld	s9,88(sp)
    426a:	6d46                	ld	s10,80(sp)
    426c:	614d                	addi	sp,sp,176
    426e:	8082                	ret

0000000000004270 <bigfile>:
{
    4270:	7139                	addi	sp,sp,-64
    4272:	fc06                	sd	ra,56(sp)
    4274:	f822                	sd	s0,48(sp)
    4276:	f426                	sd	s1,40(sp)
    4278:	f04a                	sd	s2,32(sp)
    427a:	ec4e                	sd	s3,24(sp)
    427c:	e852                	sd	s4,16(sp)
    427e:	e456                	sd	s5,8(sp)
    4280:	e05a                	sd	s6,0(sp)
    4282:	0080                	addi	s0,sp,64
    4284:	8b2a                	mv	s6,a0
  unlink("bigfile.dat");
    4286:	00003517          	auipc	a0,0x3
    428a:	f8a50513          	addi	a0,a0,-118 # 7210 <thread_switch+0x1d9a>
    428e:	2d7000ef          	jal	4d64 <unlink>
  fd = open("bigfile.dat", O_CREATE | O_RDWR);
    4292:	20200593          	li	a1,514
    4296:	00003517          	auipc	a0,0x3
    429a:	f7a50513          	addi	a0,a0,-134 # 7210 <thread_switch+0x1d9a>
    429e:	2b7000ef          	jal	4d54 <open>
  if(fd < 0){
    42a2:	08054a63          	bltz	a0,4336 <bigfile+0xc6>
    42a6:	8a2a                	mv	s4,a0
    42a8:	4481                	li	s1,0
    memset(buf, i, SZ);
    42aa:	25800913          	li	s2,600
    42ae:	00008997          	auipc	s3,0x8
    42b2:	9ca98993          	addi	s3,s3,-1590 # bc78 <buf>
  for(i = 0; i < N; i++){
    42b6:	4ad1                	li	s5,20
    memset(buf, i, SZ);
    42b8:	864a                	mv	a2,s2
    42ba:	85a6                	mv	a1,s1
    42bc:	854e                	mv	a0,s3
    42be:	059000ef          	jal	4b16 <memset>
    if(write(fd, buf, SZ) != SZ){
    42c2:	864a                	mv	a2,s2
    42c4:	85ce                	mv	a1,s3
    42c6:	8552                	mv	a0,s4
    42c8:	26d000ef          	jal	4d34 <write>
    42cc:	07251f63          	bne	a0,s2,434a <bigfile+0xda>
  for(i = 0; i < N; i++){
    42d0:	2485                	addiw	s1,s1,1
    42d2:	ff5493e3          	bne	s1,s5,42b8 <bigfile+0x48>
  close(fd);
    42d6:	8552                	mv	a0,s4
    42d8:	265000ef          	jal	4d3c <close>
  fd = open("bigfile.dat", 0);
    42dc:	4581                	li	a1,0
    42de:	00003517          	auipc	a0,0x3
    42e2:	f3250513          	addi	a0,a0,-206 # 7210 <thread_switch+0x1d9a>
    42e6:	26f000ef          	jal	4d54 <open>
    42ea:	8aaa                	mv	s5,a0
  total = 0;
    42ec:	4a01                	li	s4,0
  for(i = 0; ; i++){
    42ee:	4481                	li	s1,0
    cc = read(fd, buf, SZ/2);
    42f0:	12c00993          	li	s3,300
    42f4:	00008917          	auipc	s2,0x8
    42f8:	98490913          	addi	s2,s2,-1660 # bc78 <buf>
  if(fd < 0){
    42fc:	06054163          	bltz	a0,435e <bigfile+0xee>
    cc = read(fd, buf, SZ/2);
    4300:	864e                	mv	a2,s3
    4302:	85ca                	mv	a1,s2
    4304:	8556                	mv	a0,s5
    4306:	227000ef          	jal	4d2c <read>
    if(cc < 0){
    430a:	06054463          	bltz	a0,4372 <bigfile+0x102>
    if(cc == 0)
    430e:	c145                	beqz	a0,43ae <bigfile+0x13e>
    if(cc != SZ/2){
    4310:	07351b63          	bne	a0,s3,4386 <bigfile+0x116>
    if(buf[0] != i/2 || buf[SZ/2-1] != i/2){
    4314:	01f4d79b          	srliw	a5,s1,0x1f
    4318:	9fa5                	addw	a5,a5,s1
    431a:	4017d79b          	sraiw	a5,a5,0x1
    431e:	00094703          	lbu	a4,0(s2)
    4322:	06f71c63          	bne	a4,a5,439a <bigfile+0x12a>
    4326:	12b94703          	lbu	a4,299(s2)
    432a:	06f71863          	bne	a4,a5,439a <bigfile+0x12a>
    total += cc;
    432e:	12ca0a1b          	addiw	s4,s4,300
  for(i = 0; ; i++){
    4332:	2485                	addiw	s1,s1,1
    cc = read(fd, buf, SZ/2);
    4334:	b7f1                	j	4300 <bigfile+0x90>
    printf("%s: cannot create bigfile", s);
    4336:	85da                	mv	a1,s6
    4338:	00003517          	auipc	a0,0x3
    433c:	ee850513          	addi	a0,a0,-280 # 7220 <thread_switch+0x1daa>
    4340:	617000ef          	jal	5156 <printf>
    exit(1);
    4344:	4505                	li	a0,1
    4346:	1cf000ef          	jal	4d14 <exit>
      printf("%s: write bigfile failed\n", s);
    434a:	85da                	mv	a1,s6
    434c:	00003517          	auipc	a0,0x3
    4350:	ef450513          	addi	a0,a0,-268 # 7240 <thread_switch+0x1dca>
    4354:	603000ef          	jal	5156 <printf>
      exit(1);
    4358:	4505                	li	a0,1
    435a:	1bb000ef          	jal	4d14 <exit>
    printf("%s: cannot open bigfile\n", s);
    435e:	85da                	mv	a1,s6
    4360:	00003517          	auipc	a0,0x3
    4364:	f0050513          	addi	a0,a0,-256 # 7260 <thread_switch+0x1dea>
    4368:	5ef000ef          	jal	5156 <printf>
    exit(1);
    436c:	4505                	li	a0,1
    436e:	1a7000ef          	jal	4d14 <exit>
      printf("%s: read bigfile failed\n", s);
    4372:	85da                	mv	a1,s6
    4374:	00003517          	auipc	a0,0x3
    4378:	f0c50513          	addi	a0,a0,-244 # 7280 <thread_switch+0x1e0a>
    437c:	5db000ef          	jal	5156 <printf>
      exit(1);
    4380:	4505                	li	a0,1
    4382:	193000ef          	jal	4d14 <exit>
      printf("%s: short read bigfile\n", s);
    4386:	85da                	mv	a1,s6
    4388:	00003517          	auipc	a0,0x3
    438c:	f1850513          	addi	a0,a0,-232 # 72a0 <thread_switch+0x1e2a>
    4390:	5c7000ef          	jal	5156 <printf>
      exit(1);
    4394:	4505                	li	a0,1
    4396:	17f000ef          	jal	4d14 <exit>
      printf("%s: read bigfile wrong data\n", s);
    439a:	85da                	mv	a1,s6
    439c:	00003517          	auipc	a0,0x3
    43a0:	f1c50513          	addi	a0,a0,-228 # 72b8 <thread_switch+0x1e42>
    43a4:	5b3000ef          	jal	5156 <printf>
      exit(1);
    43a8:	4505                	li	a0,1
    43aa:	16b000ef          	jal	4d14 <exit>
  close(fd);
    43ae:	8556                	mv	a0,s5
    43b0:	18d000ef          	jal	4d3c <close>
  if(total != N*SZ){
    43b4:	678d                	lui	a5,0x3
    43b6:	ee078793          	addi	a5,a5,-288 # 2ee0 <subdir+0x1ca>
    43ba:	02fa1263          	bne	s4,a5,43de <bigfile+0x16e>
  unlink("bigfile.dat");
    43be:	00003517          	auipc	a0,0x3
    43c2:	e5250513          	addi	a0,a0,-430 # 7210 <thread_switch+0x1d9a>
    43c6:	19f000ef          	jal	4d64 <unlink>
}
    43ca:	70e2                	ld	ra,56(sp)
    43cc:	7442                	ld	s0,48(sp)
    43ce:	74a2                	ld	s1,40(sp)
    43d0:	7902                	ld	s2,32(sp)
    43d2:	69e2                	ld	s3,24(sp)
    43d4:	6a42                	ld	s4,16(sp)
    43d6:	6aa2                	ld	s5,8(sp)
    43d8:	6b02                	ld	s6,0(sp)
    43da:	6121                	addi	sp,sp,64
    43dc:	8082                	ret
    printf("%s: read bigfile wrong total\n", s);
    43de:	85da                	mv	a1,s6
    43e0:	00003517          	auipc	a0,0x3
    43e4:	ef850513          	addi	a0,a0,-264 # 72d8 <thread_switch+0x1e62>
    43e8:	56f000ef          	jal	5156 <printf>
    exit(1);
    43ec:	4505                	li	a0,1
    43ee:	127000ef          	jal	4d14 <exit>

00000000000043f2 <bigargtest>:
{
    43f2:	7121                	addi	sp,sp,-448
    43f4:	ff06                	sd	ra,440(sp)
    43f6:	fb22                	sd	s0,432(sp)
    43f8:	f726                	sd	s1,424(sp)
    43fa:	0380                	addi	s0,sp,448
    43fc:	84aa                	mv	s1,a0
  unlink("bigarg-ok");
    43fe:	00003517          	auipc	a0,0x3
    4402:	efa50513          	addi	a0,a0,-262 # 72f8 <thread_switch+0x1e82>
    4406:	15f000ef          	jal	4d64 <unlink>
  pid = fork();
    440a:	103000ef          	jal	4d0c <fork>
  if(pid == 0){
    440e:	c915                	beqz	a0,4442 <bigargtest+0x50>
  } else if(pid < 0){
    4410:	08054c63          	bltz	a0,44a8 <bigargtest+0xb6>
  wait(&xstatus);
    4414:	fdc40513          	addi	a0,s0,-36
    4418:	105000ef          	jal	4d1c <wait>
  if(xstatus != 0)
    441c:	fdc42503          	lw	a0,-36(s0)
    4420:	ed51                	bnez	a0,44bc <bigargtest+0xca>
  fd = open("bigarg-ok", 0);
    4422:	4581                	li	a1,0
    4424:	00003517          	auipc	a0,0x3
    4428:	ed450513          	addi	a0,a0,-300 # 72f8 <thread_switch+0x1e82>
    442c:	129000ef          	jal	4d54 <open>
  if(fd < 0){
    4430:	08054863          	bltz	a0,44c0 <bigargtest+0xce>
  close(fd);
    4434:	109000ef          	jal	4d3c <close>
}
    4438:	70fa                	ld	ra,440(sp)
    443a:	745a                	ld	s0,432(sp)
    443c:	74ba                	ld	s1,424(sp)
    443e:	6139                	addi	sp,sp,448
    4440:	8082                	ret
    memset(big, ' ', sizeof(big));
    4442:	19000613          	li	a2,400
    4446:	02000593          	li	a1,32
    444a:	e4840513          	addi	a0,s0,-440
    444e:	6c8000ef          	jal	4b16 <memset>
    big[sizeof(big)-1] = '\0';
    4452:	fc040ba3          	sb	zero,-41(s0)
    for(i = 0; i < MAXARG-1; i++)
    4456:	00004797          	auipc	a5,0x4
    445a:	00a78793          	addi	a5,a5,10 # 8460 <args.1>
    445e:	00004697          	auipc	a3,0x4
    4462:	0fa68693          	addi	a3,a3,250 # 8558 <args.1+0xf8>
      args[i] = big;
    4466:	e4840713          	addi	a4,s0,-440
    446a:	e398                	sd	a4,0(a5)
    for(i = 0; i < MAXARG-1; i++)
    446c:	07a1                	addi	a5,a5,8
    446e:	fed79ee3          	bne	a5,a3,446a <bigargtest+0x78>
    args[MAXARG-1] = 0;
    4472:	00004797          	auipc	a5,0x4
    4476:	0e07b323          	sd	zero,230(a5) # 8558 <args.1+0xf8>
    exec("echo", args);
    447a:	00004597          	auipc	a1,0x4
    447e:	fe658593          	addi	a1,a1,-26 # 8460 <args.1>
    4482:	00001517          	auipc	a0,0x1
    4486:	09650513          	addi	a0,a0,150 # 5518 <thread_switch+0xa2>
    448a:	0c3000ef          	jal	4d4c <exec>
    fd = open("bigarg-ok", O_CREATE);
    448e:	20000593          	li	a1,512
    4492:	00003517          	auipc	a0,0x3
    4496:	e6650513          	addi	a0,a0,-410 # 72f8 <thread_switch+0x1e82>
    449a:	0bb000ef          	jal	4d54 <open>
    close(fd);
    449e:	09f000ef          	jal	4d3c <close>
    exit(0);
    44a2:	4501                	li	a0,0
    44a4:	071000ef          	jal	4d14 <exit>
    printf("%s: bigargtest: fork failed\n", s);
    44a8:	85a6                	mv	a1,s1
    44aa:	00003517          	auipc	a0,0x3
    44ae:	e5e50513          	addi	a0,a0,-418 # 7308 <thread_switch+0x1e92>
    44b2:	4a5000ef          	jal	5156 <printf>
    exit(1);
    44b6:	4505                	li	a0,1
    44b8:	05d000ef          	jal	4d14 <exit>
    exit(xstatus);
    44bc:	059000ef          	jal	4d14 <exit>
    printf("%s: bigarg test failed!\n", s);
    44c0:	85a6                	mv	a1,s1
    44c2:	00003517          	auipc	a0,0x3
    44c6:	e6650513          	addi	a0,a0,-410 # 7328 <thread_switch+0x1eb2>
    44ca:	48d000ef          	jal	5156 <printf>
    exit(1);
    44ce:	4505                	li	a0,1
    44d0:	045000ef          	jal	4d14 <exit>

00000000000044d4 <fsfull>:
{
    44d4:	7131                	addi	sp,sp,-192
    44d6:	fd06                	sd	ra,184(sp)
    44d8:	f922                	sd	s0,176(sp)
    44da:	f526                	sd	s1,168(sp)
    44dc:	f14a                	sd	s2,160(sp)
    44de:	ed4e                	sd	s3,152(sp)
    44e0:	e952                	sd	s4,144(sp)
    44e2:	e556                	sd	s5,136(sp)
    44e4:	e15a                	sd	s6,128(sp)
    44e6:	fcde                	sd	s7,120(sp)
    44e8:	f8e2                	sd	s8,112(sp)
    44ea:	f4e6                	sd	s9,104(sp)
    44ec:	f0ea                	sd	s10,96(sp)
    44ee:	ecee                	sd	s11,88(sp)
    44f0:	0180                	addi	s0,sp,192
  printf("fsfull test\n");
    44f2:	00003517          	auipc	a0,0x3
    44f6:	e5650513          	addi	a0,a0,-426 # 7348 <thread_switch+0x1ed2>
    44fa:	45d000ef          	jal	5156 <printf>
  int fsblocks = 0;
    44fe:	4981                	li	s3,0
  for(nfiles = 0; ; nfiles++){
    4500:	4481                	li	s1,0
    name[0] = 'f';
    4502:	06600d93          	li	s11,102
    name[1] = '0' + nfiles / 1000;
    4506:	106257b7          	lui	a5,0x10625
    450a:	dd378793          	addi	a5,a5,-557 # 10624dd3 <all_thread+0x1061614b>
    450e:	f4f43423          	sd	a5,-184(s0)
    name[2] = '0' + (nfiles % 1000) / 100;
    4512:	51eb8b37          	lui	s6,0x51eb8
    4516:	51fb0b13          	addi	s6,s6,1311 # 51eb851f <all_thread+0x51ea9897>
    name[3] = '0' + (nfiles % 100) / 10;
    451a:	66666ab7          	lui	s5,0x66666
    451e:	667a8a93          	addi	s5,s5,1639 # 66666667 <all_thread+0x666579df>
    printf("writing %s\n", name);
    4522:	f5040d13          	addi	s10,s0,-176
    name[0] = 'f';
    4526:	f5b40823          	sb	s11,-176(s0)
    name[1] = '0' + nfiles / 1000;
    452a:	f4843783          	ld	a5,-184(s0)
    452e:	02f487b3          	mul	a5,s1,a5
    4532:	9799                	srai	a5,a5,0x26
    4534:	41f4d69b          	sraiw	a3,s1,0x1f
    4538:	9f95                	subw	a5,a5,a3
    453a:	0307871b          	addiw	a4,a5,48
    453e:	f4e408a3          	sb	a4,-175(s0)
    name[2] = '0' + (nfiles % 1000) / 100;
    4542:	3e800713          	li	a4,1000
    4546:	02f707bb          	mulw	a5,a4,a5
    454a:	40f487bb          	subw	a5,s1,a5
    454e:	03678733          	mul	a4,a5,s6
    4552:	9715                	srai	a4,a4,0x25
    4554:	41f7d79b          	sraiw	a5,a5,0x1f
    4558:	40f707bb          	subw	a5,a4,a5
    455c:	0307879b          	addiw	a5,a5,48
    4560:	f4f40923          	sb	a5,-174(s0)
    name[3] = '0' + (nfiles % 100) / 10;
    4564:	036487b3          	mul	a5,s1,s6
    4568:	9795                	srai	a5,a5,0x25
    456a:	9f95                	subw	a5,a5,a3
    456c:	06400713          	li	a4,100
    4570:	02f707bb          	mulw	a5,a4,a5
    4574:	40f487bb          	subw	a5,s1,a5
    4578:	03578733          	mul	a4,a5,s5
    457c:	9709                	srai	a4,a4,0x22
    457e:	41f7d79b          	sraiw	a5,a5,0x1f
    4582:	40f707bb          	subw	a5,a4,a5
    4586:	0307879b          	addiw	a5,a5,48
    458a:	f4f409a3          	sb	a5,-173(s0)
    name[4] = '0' + (nfiles % 10);
    458e:	03548733          	mul	a4,s1,s5
    4592:	9709                	srai	a4,a4,0x22
    4594:	9f15                	subw	a4,a4,a3
    4596:	0027179b          	slliw	a5,a4,0x2
    459a:	9fb9                	addw	a5,a5,a4
    459c:	0017979b          	slliw	a5,a5,0x1
    45a0:	40f487bb          	subw	a5,s1,a5
    45a4:	0307879b          	addiw	a5,a5,48
    45a8:	f4f40a23          	sb	a5,-172(s0)
    name[5] = '\0';
    45ac:	f4040aa3          	sb	zero,-171(s0)
    printf("writing %s\n", name);
    45b0:	85ea                	mv	a1,s10
    45b2:	00003517          	auipc	a0,0x3
    45b6:	da650513          	addi	a0,a0,-602 # 7358 <thread_switch+0x1ee2>
    45ba:	39d000ef          	jal	5156 <printf>
    int fd = open(name, O_CREATE|O_RDWR);
    45be:	20200593          	li	a1,514
    45c2:	856a                	mv	a0,s10
    45c4:	790000ef          	jal	4d54 <open>
    45c8:	892a                	mv	s2,a0
    if(fd < 0){
    45ca:	0e055c63          	bgez	a0,46c2 <fsfull+0x1ee>
      printf("open %s failed\n", name);
    45ce:	f5040593          	addi	a1,s0,-176
    45d2:	00003517          	auipc	a0,0x3
    45d6:	d9650513          	addi	a0,a0,-618 # 7368 <thread_switch+0x1ef2>
    45da:	37d000ef          	jal	5156 <printf>
  while(nfiles >= 0){
    45de:	0a04cc63          	bltz	s1,4696 <fsfull+0x1c2>
    name[0] = 'f';
    45e2:	06600c93          	li	s9,102
    name[1] = '0' + nfiles / 1000;
    45e6:	10625ab7          	lui	s5,0x10625
    45ea:	dd3a8a93          	addi	s5,s5,-557 # 10624dd3 <all_thread+0x1061614b>
    name[2] = '0' + (nfiles % 1000) / 100;
    45ee:	3e800c13          	li	s8,1000
    45f2:	51eb8a37          	lui	s4,0x51eb8
    45f6:	51fa0a13          	addi	s4,s4,1311 # 51eb851f <all_thread+0x51ea9897>
    name[3] = '0' + (nfiles % 100) / 10;
    45fa:	06400b93          	li	s7,100
    45fe:	66666937          	lui	s2,0x66666
    4602:	66790913          	addi	s2,s2,1639 # 66666667 <all_thread+0x666579df>
    unlink(name);
    4606:	f5040b13          	addi	s6,s0,-176
    name[0] = 'f';
    460a:	f5940823          	sb	s9,-176(s0)
    name[1] = '0' + nfiles / 1000;
    460e:	035487b3          	mul	a5,s1,s5
    4612:	9799                	srai	a5,a5,0x26
    4614:	41f4d69b          	sraiw	a3,s1,0x1f
    4618:	9f95                	subw	a5,a5,a3
    461a:	0307871b          	addiw	a4,a5,48
    461e:	f4e408a3          	sb	a4,-175(s0)
    name[2] = '0' + (nfiles % 1000) / 100;
    4622:	02fc07bb          	mulw	a5,s8,a5
    4626:	40f487bb          	subw	a5,s1,a5
    462a:	03478733          	mul	a4,a5,s4
    462e:	9715                	srai	a4,a4,0x25
    4630:	41f7d79b          	sraiw	a5,a5,0x1f
    4634:	40f707bb          	subw	a5,a4,a5
    4638:	0307879b          	addiw	a5,a5,48
    463c:	f4f40923          	sb	a5,-174(s0)
    name[3] = '0' + (nfiles % 100) / 10;
    4640:	034487b3          	mul	a5,s1,s4
    4644:	9795                	srai	a5,a5,0x25
    4646:	9f95                	subw	a5,a5,a3
    4648:	02fb87bb          	mulw	a5,s7,a5
    464c:	40f487bb          	subw	a5,s1,a5
    4650:	03278733          	mul	a4,a5,s2
    4654:	9709                	srai	a4,a4,0x22
    4656:	41f7d79b          	sraiw	a5,a5,0x1f
    465a:	40f707bb          	subw	a5,a4,a5
    465e:	0307879b          	addiw	a5,a5,48
    4662:	f4f409a3          	sb	a5,-173(s0)
    name[4] = '0' + (nfiles % 10);
    4666:	03248733          	mul	a4,s1,s2
    466a:	9709                	srai	a4,a4,0x22
    466c:	9f15                	subw	a4,a4,a3
    466e:	0027179b          	slliw	a5,a4,0x2
    4672:	9fb9                	addw	a5,a5,a4
    4674:	0017979b          	slliw	a5,a5,0x1
    4678:	40f487bb          	subw	a5,s1,a5
    467c:	0307879b          	addiw	a5,a5,48
    4680:	f4f40a23          	sb	a5,-172(s0)
    name[5] = '\0';
    4684:	f4040aa3          	sb	zero,-171(s0)
    unlink(name);
    4688:	855a                	mv	a0,s6
    468a:	6da000ef          	jal	4d64 <unlink>
    nfiles--;
    468e:	34fd                	addiw	s1,s1,-1
  while(nfiles >= 0){
    4690:	57fd                	li	a5,-1
    4692:	f6f49ce3          	bne	s1,a5,460a <fsfull+0x136>
  printf("fsfull test finished, %d blocks\n", fsblocks);
    4696:	85ce                	mv	a1,s3
    4698:	00003517          	auipc	a0,0x3
    469c:	cf050513          	addi	a0,a0,-784 # 7388 <thread_switch+0x1f12>
    46a0:	2b7000ef          	jal	5156 <printf>
}
    46a4:	70ea                	ld	ra,184(sp)
    46a6:	744a                	ld	s0,176(sp)
    46a8:	74aa                	ld	s1,168(sp)
    46aa:	790a                	ld	s2,160(sp)
    46ac:	69ea                	ld	s3,152(sp)
    46ae:	6a4a                	ld	s4,144(sp)
    46b0:	6aaa                	ld	s5,136(sp)
    46b2:	6b0a                	ld	s6,128(sp)
    46b4:	7be6                	ld	s7,120(sp)
    46b6:	7c46                	ld	s8,112(sp)
    46b8:	7ca6                	ld	s9,104(sp)
    46ba:	7d06                	ld	s10,96(sp)
    46bc:	6de6                	ld	s11,88(sp)
    46be:	6129                	addi	sp,sp,192
    46c0:	8082                	ret
    int total = 0;
    46c2:	4a01                	li	s4,0
      int cc = write(fd, buf, BSIZE);
    46c4:	40000c93          	li	s9,1024
    46c8:	00007c17          	auipc	s8,0x7
    46cc:	5b0c0c13          	addi	s8,s8,1456 # bc78 <buf>
      if(cc < BSIZE)
    46d0:	3ff00b93          	li	s7,1023
      int cc = write(fd, buf, BSIZE);
    46d4:	8666                	mv	a2,s9
    46d6:	85e2                	mv	a1,s8
    46d8:	854a                	mv	a0,s2
    46da:	65a000ef          	jal	4d34 <write>
      if(cc < BSIZE)
    46de:	00abd663          	bge	s7,a0,46ea <fsfull+0x216>
      total += cc;
    46e2:	00aa0a3b          	addw	s4,s4,a0
      fsblocks++;
    46e6:	2985                	addiw	s3,s3,1
    while(1){
    46e8:	b7f5                	j	46d4 <fsfull+0x200>
    printf("wrote %d bytes\n", total);
    46ea:	85d2                	mv	a1,s4
    46ec:	00003517          	auipc	a0,0x3
    46f0:	c8c50513          	addi	a0,a0,-884 # 7378 <thread_switch+0x1f02>
    46f4:	263000ef          	jal	5156 <printf>
    close(fd);
    46f8:	854a                	mv	a0,s2
    46fa:	642000ef          	jal	4d3c <close>
    if(total == 0)
    46fe:	ee0a00e3          	beqz	s4,45de <fsfull+0x10a>
  for(nfiles = 0; ; nfiles++){
    4702:	2485                	addiw	s1,s1,1
    4704:	b50d                	j	4526 <fsfull+0x52>

0000000000004706 <run>:
//

// run each test in its own process. run returns 1 if child's exit()
// indicates success.
int
run(void f(char *), char *s) {
    4706:	7179                	addi	sp,sp,-48
    4708:	f406                	sd	ra,40(sp)
    470a:	f022                	sd	s0,32(sp)
    470c:	ec26                	sd	s1,24(sp)
    470e:	e84a                	sd	s2,16(sp)
    4710:	1800                	addi	s0,sp,48
    4712:	84aa                	mv	s1,a0
    4714:	892e                	mv	s2,a1
  int pid;
  int xstatus;

  printf("test %s: ", s);
    4716:	00003517          	auipc	a0,0x3
    471a:	c9a50513          	addi	a0,a0,-870 # 73b0 <thread_switch+0x1f3a>
    471e:	239000ef          	jal	5156 <printf>
  if((pid = fork()) < 0) {
    4722:	5ea000ef          	jal	4d0c <fork>
    4726:	02054a63          	bltz	a0,475a <run+0x54>
    printf("runtest: fork error\n");
    exit(1);
  }
  if(pid == 0) {
    472a:	c129                	beqz	a0,476c <run+0x66>
    f(s);
    exit(0);
  } else {
    wait(&xstatus);
    472c:	fdc40513          	addi	a0,s0,-36
    4730:	5ec000ef          	jal	4d1c <wait>
    if(xstatus != 0) 
    4734:	fdc42783          	lw	a5,-36(s0)
    4738:	cf9d                	beqz	a5,4776 <run+0x70>
      printf("FAILED\n");
    473a:	00003517          	auipc	a0,0x3
    473e:	c9e50513          	addi	a0,a0,-866 # 73d8 <thread_switch+0x1f62>
    4742:	215000ef          	jal	5156 <printf>
    else
      printf("OK\n");
    return xstatus == 0;
    4746:	fdc42503          	lw	a0,-36(s0)
  }
}
    474a:	00153513          	seqz	a0,a0
    474e:	70a2                	ld	ra,40(sp)
    4750:	7402                	ld	s0,32(sp)
    4752:	64e2                	ld	s1,24(sp)
    4754:	6942                	ld	s2,16(sp)
    4756:	6145                	addi	sp,sp,48
    4758:	8082                	ret
    printf("runtest: fork error\n");
    475a:	00003517          	auipc	a0,0x3
    475e:	c6650513          	addi	a0,a0,-922 # 73c0 <thread_switch+0x1f4a>
    4762:	1f5000ef          	jal	5156 <printf>
    exit(1);
    4766:	4505                	li	a0,1
    4768:	5ac000ef          	jal	4d14 <exit>
    f(s);
    476c:	854a                	mv	a0,s2
    476e:	9482                	jalr	s1
    exit(0);
    4770:	4501                	li	a0,0
    4772:	5a2000ef          	jal	4d14 <exit>
      printf("OK\n");
    4776:	00003517          	auipc	a0,0x3
    477a:	c6a50513          	addi	a0,a0,-918 # 73e0 <thread_switch+0x1f6a>
    477e:	1d9000ef          	jal	5156 <printf>
    4782:	b7d1                	j	4746 <run+0x40>

0000000000004784 <runtests>:

int
runtests(struct test *tests, char *justone, int continuous) {
    4784:	7179                	addi	sp,sp,-48
    4786:	f406                	sd	ra,40(sp)
    4788:	f022                	sd	s0,32(sp)
    478a:	e84a                	sd	s2,16(sp)
    478c:	1800                	addi	s0,sp,48
  for (struct test *t = tests; t->s != 0; t++) {
    478e:	00853903          	ld	s2,8(a0)
    4792:	04090f63          	beqz	s2,47f0 <runtests+0x6c>
    4796:	ec26                	sd	s1,24(sp)
    4798:	e44e                	sd	s3,8(sp)
    479a:	e052                	sd	s4,0(sp)
    479c:	84aa                	mv	s1,a0
    479e:	89ae                	mv	s3,a1
    if((justone == 0) || strcmp(t->s, justone) == 0) {
      if(!run(t->f, t->s)){
        if(continuous != 2){
    47a0:	1679                	addi	a2,a2,-2 # 2ffe <subdir+0x2e8>
    47a2:	00c03a33          	snez	s4,a2
    47a6:	a839                	j	47c4 <runtests+0x40>
      if(!run(t->f, t->s)){
    47a8:	85ca                	mv	a1,s2
    47aa:	6088                	ld	a0,0(s1)
    47ac:	f5bff0ef          	jal	4706 <run>
    47b0:	00153513          	seqz	a0,a0
        if(continuous != 2){
    47b4:	00aa7533          	and	a0,s4,a0
    47b8:	ed11                	bnez	a0,47d4 <runtests+0x50>
  for (struct test *t = tests; t->s != 0; t++) {
    47ba:	04c1                	addi	s1,s1,16
    47bc:	0084b903          	ld	s2,8(s1)
    47c0:	02090563          	beqz	s2,47ea <runtests+0x66>
    if((justone == 0) || strcmp(t->s, justone) == 0) {
    47c4:	fe0982e3          	beqz	s3,47a8 <runtests+0x24>
    47c8:	85ce                	mv	a1,s3
    47ca:	854a                	mv	a0,s2
    47cc:	2ee000ef          	jal	4aba <strcmp>
    47d0:	f56d                	bnez	a0,47ba <runtests+0x36>
    47d2:	bfd9                	j	47a8 <runtests+0x24>
          printf("SOME TESTS FAILED\n");
    47d4:	00003517          	auipc	a0,0x3
    47d8:	c1450513          	addi	a0,a0,-1004 # 73e8 <thread_switch+0x1f72>
    47dc:	17b000ef          	jal	5156 <printf>
          return 1;
    47e0:	4505                	li	a0,1
    47e2:	64e2                	ld	s1,24(sp)
    47e4:	69a2                	ld	s3,8(sp)
    47e6:	6a02                	ld	s4,0(sp)
    47e8:	a029                	j	47f2 <runtests+0x6e>
    47ea:	64e2                	ld	s1,24(sp)
    47ec:	69a2                	ld	s3,8(sp)
    47ee:	6a02                	ld	s4,0(sp)
        }
      }
    }
  }
  return 0;
    47f0:	4501                	li	a0,0
}
    47f2:	70a2                	ld	ra,40(sp)
    47f4:	7402                	ld	s0,32(sp)
    47f6:	6942                	ld	s2,16(sp)
    47f8:	6145                	addi	sp,sp,48
    47fa:	8082                	ret

00000000000047fc <countfree>:
// because out of memory with lazy allocation results in the process
// taking a fault and being killed, fork and report back.
//
int
countfree()
{
    47fc:	7139                	addi	sp,sp,-64
    47fe:	fc06                	sd	ra,56(sp)
    4800:	f822                	sd	s0,48(sp)
    4802:	0080                	addi	s0,sp,64
  int fds[2];

  if(pipe(fds) < 0){
    4804:	fc840513          	addi	a0,s0,-56
    4808:	51c000ef          	jal	4d24 <pipe>
    480c:	04054f63          	bltz	a0,486a <countfree+0x6e>
    printf("pipe() failed in countfree()\n");
    exit(1);
  }
  
  int pid = fork();
    4810:	4fc000ef          	jal	4d0c <fork>

  if(pid < 0){
    4814:	06054863          	bltz	a0,4884 <countfree+0x88>
    printf("fork failed in countfree()\n");
    exit(1);
  }

  if(pid == 0){
    4818:	e551                	bnez	a0,48a4 <countfree+0xa8>
    481a:	f426                	sd	s1,40(sp)
    481c:	f04a                	sd	s2,32(sp)
    481e:	ec4e                	sd	s3,24(sp)
    4820:	e852                	sd	s4,16(sp)
    close(fds[0]);
    4822:	fc842503          	lw	a0,-56(s0)
    4826:	516000ef          	jal	4d3c <close>
    
    while(1){
      uint64 a = (uint64) sbrk(4096);
    482a:	6905                	lui	s2,0x1
      if(a == 0xffffffffffffffff){
    482c:	59fd                	li	s3,-1
        break;
      }

      // modify the memory to make sure it's really allocated.
      *(char *)(a + 4096 - 1) = 1;
    482e:	4485                	li	s1,1

      // report back one more page.
      if(write(fds[1], "x", 1) != 1){
    4830:	00001a17          	auipc	s4,0x1
    4834:	d58a0a13          	addi	s4,s4,-680 # 5588 <thread_switch+0x112>
      uint64 a = (uint64) sbrk(4096);
    4838:	854a                	mv	a0,s2
    483a:	562000ef          	jal	4d9c <sbrk>
      if(a == 0xffffffffffffffff){
    483e:	07350063          	beq	a0,s3,489e <countfree+0xa2>
      *(char *)(a + 4096 - 1) = 1;
    4842:	954a                	add	a0,a0,s2
    4844:	fe950fa3          	sb	s1,-1(a0)
      if(write(fds[1], "x", 1) != 1){
    4848:	8626                	mv	a2,s1
    484a:	85d2                	mv	a1,s4
    484c:	fcc42503          	lw	a0,-52(s0)
    4850:	4e4000ef          	jal	4d34 <write>
    4854:	fe9502e3          	beq	a0,s1,4838 <countfree+0x3c>
        printf("write() failed in countfree()\n");
    4858:	00003517          	auipc	a0,0x3
    485c:	be850513          	addi	a0,a0,-1048 # 7440 <thread_switch+0x1fca>
    4860:	0f7000ef          	jal	5156 <printf>
        exit(1);
    4864:	4505                	li	a0,1
    4866:	4ae000ef          	jal	4d14 <exit>
    486a:	f426                	sd	s1,40(sp)
    486c:	f04a                	sd	s2,32(sp)
    486e:	ec4e                	sd	s3,24(sp)
    4870:	e852                	sd	s4,16(sp)
    printf("pipe() failed in countfree()\n");
    4872:	00003517          	auipc	a0,0x3
    4876:	b8e50513          	addi	a0,a0,-1138 # 7400 <thread_switch+0x1f8a>
    487a:	0dd000ef          	jal	5156 <printf>
    exit(1);
    487e:	4505                	li	a0,1
    4880:	494000ef          	jal	4d14 <exit>
    4884:	f426                	sd	s1,40(sp)
    4886:	f04a                	sd	s2,32(sp)
    4888:	ec4e                	sd	s3,24(sp)
    488a:	e852                	sd	s4,16(sp)
    printf("fork failed in countfree()\n");
    488c:	00003517          	auipc	a0,0x3
    4890:	b9450513          	addi	a0,a0,-1132 # 7420 <thread_switch+0x1faa>
    4894:	0c3000ef          	jal	5156 <printf>
    exit(1);
    4898:	4505                	li	a0,1
    489a:	47a000ef          	jal	4d14 <exit>
      }
    }

    exit(0);
    489e:	4501                	li	a0,0
    48a0:	474000ef          	jal	4d14 <exit>
    48a4:	f426                	sd	s1,40(sp)
    48a6:	f04a                	sd	s2,32(sp)
    48a8:	ec4e                	sd	s3,24(sp)
  }

  close(fds[1]);
    48aa:	fcc42503          	lw	a0,-52(s0)
    48ae:	48e000ef          	jal	4d3c <close>

  int n = 0;
    48b2:	4481                	li	s1,0
  while(1){
    char c;
    int cc = read(fds[0], &c, 1);
    48b4:	fc740993          	addi	s3,s0,-57
    48b8:	4905                	li	s2,1
    48ba:	864a                	mv	a2,s2
    48bc:	85ce                	mv	a1,s3
    48be:	fc842503          	lw	a0,-56(s0)
    48c2:	46a000ef          	jal	4d2c <read>
    if(cc < 0){
    48c6:	00054563          	bltz	a0,48d0 <countfree+0xd4>
      printf("read() failed in countfree()\n");
      exit(1);
    }
    if(cc == 0)
    48ca:	cd09                	beqz	a0,48e4 <countfree+0xe8>
      break;
    n += 1;
    48cc:	2485                	addiw	s1,s1,1
  while(1){
    48ce:	b7f5                	j	48ba <countfree+0xbe>
    48d0:	e852                	sd	s4,16(sp)
      printf("read() failed in countfree()\n");
    48d2:	00003517          	auipc	a0,0x3
    48d6:	b8e50513          	addi	a0,a0,-1138 # 7460 <thread_switch+0x1fea>
    48da:	07d000ef          	jal	5156 <printf>
      exit(1);
    48de:	4505                	li	a0,1
    48e0:	434000ef          	jal	4d14 <exit>
  }

  close(fds[0]);
    48e4:	fc842503          	lw	a0,-56(s0)
    48e8:	454000ef          	jal	4d3c <close>
  wait((int*)0);
    48ec:	4501                	li	a0,0
    48ee:	42e000ef          	jal	4d1c <wait>
  
  return n;
}
    48f2:	8526                	mv	a0,s1
    48f4:	74a2                	ld	s1,40(sp)
    48f6:	7902                	ld	s2,32(sp)
    48f8:	69e2                	ld	s3,24(sp)
    48fa:	70e2                	ld	ra,56(sp)
    48fc:	7442                	ld	s0,48(sp)
    48fe:	6121                	addi	sp,sp,64
    4900:	8082                	ret

0000000000004902 <drivetests>:

int
drivetests(int quick, int continuous, char *justone) {
    4902:	7159                	addi	sp,sp,-112
    4904:	f486                	sd	ra,104(sp)
    4906:	f0a2                	sd	s0,96(sp)
    4908:	eca6                	sd	s1,88(sp)
    490a:	e8ca                	sd	s2,80(sp)
    490c:	e4ce                	sd	s3,72(sp)
    490e:	e0d2                	sd	s4,64(sp)
    4910:	fc56                	sd	s5,56(sp)
    4912:	f85a                	sd	s6,48(sp)
    4914:	f45e                	sd	s7,40(sp)
    4916:	f062                	sd	s8,32(sp)
    4918:	ec66                	sd	s9,24(sp)
    491a:	e86a                	sd	s10,16(sp)
    491c:	e46e                	sd	s11,8(sp)
    491e:	1880                	addi	s0,sp,112
    4920:	8aaa                	mv	s5,a0
    4922:	892e                	mv	s2,a1
    4924:	89b2                	mv	s3,a2
  do {
    printf("usertests starting\n");
    int free0 = countfree();
    int free1 = 0;
    if (runtests(quicktests, justone, continuous)) {
      if(continuous != 2) {
    4926:	ffe58a13          	addi	s4,a1,-2
    492a:	01403a33          	snez	s4,s4
    printf("usertests starting\n");
    492e:	00003b97          	auipc	s7,0x3
    4932:	b52b8b93          	addi	s7,s7,-1198 # 7480 <thread_switch+0x200a>
    if (runtests(quicktests, justone, continuous)) {
    4936:	00003b17          	auipc	s6,0x3
    493a:	6dab0b13          	addi	s6,s6,1754 # 8010 <quicktests>
      }
    }
    if(!quick) {
      if (justone == 0)
        printf("usertests slow tests starting\n");
      if (runtests(slowtests, justone, continuous)) {
    493e:	00004c17          	auipc	s8,0x4
    4942:	aa2c0c13          	addi	s8,s8,-1374 # 83e0 <slowtests>
        printf("usertests slow tests starting\n");
    4946:	00003d97          	auipc	s11,0x3
    494a:	b52d8d93          	addi	s11,s11,-1198 # 7498 <thread_switch+0x2022>
          return 1;
        }
      }
    }
    if((free1 = countfree()) < free0) {
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    494e:	00003d17          	auipc	s10,0x3
    4952:	b6ad0d13          	addi	s10,s10,-1174 # 74b8 <thread_switch+0x2042>
      if(continuous != 2) {
    4956:	4c89                	li	s9,2
    4958:	a00d                	j	497a <drivetests+0x78>
      if (runtests(slowtests, justone, continuous)) {
    495a:	864a                	mv	a2,s2
    495c:	85ce                	mv	a1,s3
    495e:	8562                	mv	a0,s8
    4960:	e25ff0ef          	jal	4784 <runtests>
    4964:	00a03533          	snez	a0,a0
        if(continuous != 2) {
    4968:	00aa7533          	and	a0,s4,a0
    496c:	e531                	bnez	a0,49b8 <drivetests+0xb6>
    if((free1 = countfree()) < free0) {
    496e:	e8fff0ef          	jal	47fc <countfree>
    4972:	02954c63          	blt	a0,s1,49aa <drivetests+0xa8>
        return 1;
      }
    }
  } while(continuous);
    4976:	06090163          	beqz	s2,49d8 <drivetests+0xd6>
    printf("usertests starting\n");
    497a:	855e                	mv	a0,s7
    497c:	7da000ef          	jal	5156 <printf>
    int free0 = countfree();
    4980:	e7dff0ef          	jal	47fc <countfree>
    4984:	84aa                	mv	s1,a0
    if (runtests(quicktests, justone, continuous)) {
    4986:	864a                	mv	a2,s2
    4988:	85ce                	mv	a1,s3
    498a:	855a                	mv	a0,s6
    498c:	df9ff0ef          	jal	4784 <runtests>
    4990:	00a03533          	snez	a0,a0
      if(continuous != 2) {
    4994:	00aa7533          	and	a0,s4,a0
    4998:	e105                	bnez	a0,49b8 <drivetests+0xb6>
    if(!quick) {
    499a:	fc0a9ae3          	bnez	s5,496e <drivetests+0x6c>
      if (justone == 0)
    499e:	fa099ee3          	bnez	s3,495a <drivetests+0x58>
        printf("usertests slow tests starting\n");
    49a2:	856e                	mv	a0,s11
    49a4:	7b2000ef          	jal	5156 <printf>
    49a8:	bf4d                	j	495a <drivetests+0x58>
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    49aa:	8626                	mv	a2,s1
    49ac:	85aa                	mv	a1,a0
    49ae:	856a                	mv	a0,s10
    49b0:	7a6000ef          	jal	5156 <printf>
      if(continuous != 2) {
    49b4:	fd9903e3          	beq	s2,s9,497a <drivetests+0x78>
        return 1;
    49b8:	4505                	li	a0,1
  return 0;
}
    49ba:	70a6                	ld	ra,104(sp)
    49bc:	7406                	ld	s0,96(sp)
    49be:	64e6                	ld	s1,88(sp)
    49c0:	6946                	ld	s2,80(sp)
    49c2:	69a6                	ld	s3,72(sp)
    49c4:	6a06                	ld	s4,64(sp)
    49c6:	7ae2                	ld	s5,56(sp)
    49c8:	7b42                	ld	s6,48(sp)
    49ca:	7ba2                	ld	s7,40(sp)
    49cc:	7c02                	ld	s8,32(sp)
    49ce:	6ce2                	ld	s9,24(sp)
    49d0:	6d42                	ld	s10,16(sp)
    49d2:	6da2                	ld	s11,8(sp)
    49d4:	6165                	addi	sp,sp,112
    49d6:	8082                	ret
  return 0;
    49d8:	854a                	mv	a0,s2
    49da:	b7c5                	j	49ba <drivetests+0xb8>

00000000000049dc <main>:

int
main(int argc, char *argv[])
{
    49dc:	1101                	addi	sp,sp,-32
    49de:	ec06                	sd	ra,24(sp)
    49e0:	e822                	sd	s0,16(sp)
    49e2:	e426                	sd	s1,8(sp)
    49e4:	e04a                	sd	s2,0(sp)
    49e6:	1000                	addi	s0,sp,32
    49e8:	84aa                	mv	s1,a0
  int continuous = 0;
  int quick = 0;
  char *justone = 0;

  if(argc == 2 && strcmp(argv[1], "-q") == 0){
    49ea:	4789                	li	a5,2
    49ec:	00f50f63          	beq	a0,a5,4a0a <main+0x2e>
    continuous = 1;
  } else if(argc == 2 && strcmp(argv[1], "-C") == 0){
    continuous = 2;
  } else if(argc == 2 && argv[1][0] != '-'){
    justone = argv[1];
  } else if(argc > 1){
    49f0:	4785                	li	a5,1
    49f2:	06a7c063          	blt	a5,a0,4a52 <main+0x76>
  char *justone = 0;
    49f6:	4901                	li	s2,0
  int quick = 0;
    49f8:	4501                	li	a0,0
  int continuous = 0;
    49fa:	4581                	li	a1,0
    printf("Usage: usertests [-c] [-C] [-q] [testname]\n");
    exit(1);
  }
  if (drivetests(quick, continuous, justone)) {
    49fc:	864a                	mv	a2,s2
    49fe:	f05ff0ef          	jal	4902 <drivetests>
    4a02:	c935                	beqz	a0,4a76 <main+0x9a>
    exit(1);
    4a04:	4505                	li	a0,1
    4a06:	30e000ef          	jal	4d14 <exit>
  if(argc == 2 && strcmp(argv[1], "-q") == 0){
    4a0a:	0085b903          	ld	s2,8(a1)
    4a0e:	00003597          	auipc	a1,0x3
    4a12:	ada58593          	addi	a1,a1,-1318 # 74e8 <thread_switch+0x2072>
    4a16:	854a                	mv	a0,s2
    4a18:	0a2000ef          	jal	4aba <strcmp>
    4a1c:	85aa                	mv	a1,a0
    4a1e:	c139                	beqz	a0,4a64 <main+0x88>
  } else if(argc == 2 && strcmp(argv[1], "-c") == 0){
    4a20:	00003597          	auipc	a1,0x3
    4a24:	ad058593          	addi	a1,a1,-1328 # 74f0 <thread_switch+0x207a>
    4a28:	854a                	mv	a0,s2
    4a2a:	090000ef          	jal	4aba <strcmp>
    4a2e:	cd15                	beqz	a0,4a6a <main+0x8e>
  } else if(argc == 2 && strcmp(argv[1], "-C") == 0){
    4a30:	00003597          	auipc	a1,0x3
    4a34:	ac858593          	addi	a1,a1,-1336 # 74f8 <thread_switch+0x2082>
    4a38:	854a                	mv	a0,s2
    4a3a:	080000ef          	jal	4aba <strcmp>
    4a3e:	c90d                	beqz	a0,4a70 <main+0x94>
  } else if(argc == 2 && argv[1][0] != '-'){
    4a40:	00094703          	lbu	a4,0(s2) # 1000 <bigdir+0x10c>
    4a44:	02d00793          	li	a5,45
    4a48:	00f70563          	beq	a4,a5,4a52 <main+0x76>
  int quick = 0;
    4a4c:	4501                	li	a0,0
  int continuous = 0;
    4a4e:	4581                	li	a1,0
    4a50:	b775                	j	49fc <main+0x20>
    printf("Usage: usertests [-c] [-C] [-q] [testname]\n");
    4a52:	00003517          	auipc	a0,0x3
    4a56:	aae50513          	addi	a0,a0,-1362 # 7500 <thread_switch+0x208a>
    4a5a:	6fc000ef          	jal	5156 <printf>
    exit(1);
    4a5e:	4505                	li	a0,1
    4a60:	2b4000ef          	jal	4d14 <exit>
  char *justone = 0;
    4a64:	4901                	li	s2,0
    quick = 1;
    4a66:	4505                	li	a0,1
    4a68:	bf51                	j	49fc <main+0x20>
  char *justone = 0;
    4a6a:	4901                	li	s2,0
    continuous = 1;
    4a6c:	4585                	li	a1,1
    4a6e:	b779                	j	49fc <main+0x20>
    continuous = 2;
    4a70:	85a6                	mv	a1,s1
  char *justone = 0;
    4a72:	4901                	li	s2,0
    4a74:	b761                	j	49fc <main+0x20>
  }
  printf("ALL TESTS PASSED\n");
    4a76:	00003517          	auipc	a0,0x3
    4a7a:	aba50513          	addi	a0,a0,-1350 # 7530 <thread_switch+0x20ba>
    4a7e:	6d8000ef          	jal	5156 <printf>
  exit(0);
    4a82:	4501                	li	a0,0
    4a84:	290000ef          	jal	4d14 <exit>

0000000000004a88 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
    4a88:	1141                	addi	sp,sp,-16
    4a8a:	e406                	sd	ra,8(sp)
    4a8c:	e022                	sd	s0,0(sp)
    4a8e:	0800                	addi	s0,sp,16
  extern int main();
  main();
    4a90:	f4dff0ef          	jal	49dc <main>
  exit(0);
    4a94:	4501                	li	a0,0
    4a96:	27e000ef          	jal	4d14 <exit>

0000000000004a9a <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
    4a9a:	1141                	addi	sp,sp,-16
    4a9c:	e406                	sd	ra,8(sp)
    4a9e:	e022                	sd	s0,0(sp)
    4aa0:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
    4aa2:	87aa                	mv	a5,a0
    4aa4:	0585                	addi	a1,a1,1
    4aa6:	0785                	addi	a5,a5,1
    4aa8:	fff5c703          	lbu	a4,-1(a1)
    4aac:	fee78fa3          	sb	a4,-1(a5)
    4ab0:	fb75                	bnez	a4,4aa4 <strcpy+0xa>
    ;
  return os;
}
    4ab2:	60a2                	ld	ra,8(sp)
    4ab4:	6402                	ld	s0,0(sp)
    4ab6:	0141                	addi	sp,sp,16
    4ab8:	8082                	ret

0000000000004aba <strcmp>:

int
strcmp(const char *p, const char *q)
{
    4aba:	1141                	addi	sp,sp,-16
    4abc:	e406                	sd	ra,8(sp)
    4abe:	e022                	sd	s0,0(sp)
    4ac0:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
    4ac2:	00054783          	lbu	a5,0(a0)
    4ac6:	cb91                	beqz	a5,4ada <strcmp+0x20>
    4ac8:	0005c703          	lbu	a4,0(a1)
    4acc:	00f71763          	bne	a4,a5,4ada <strcmp+0x20>
    p++, q++;
    4ad0:	0505                	addi	a0,a0,1
    4ad2:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
    4ad4:	00054783          	lbu	a5,0(a0)
    4ad8:	fbe5                	bnez	a5,4ac8 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
    4ada:	0005c503          	lbu	a0,0(a1)
}
    4ade:	40a7853b          	subw	a0,a5,a0
    4ae2:	60a2                	ld	ra,8(sp)
    4ae4:	6402                	ld	s0,0(sp)
    4ae6:	0141                	addi	sp,sp,16
    4ae8:	8082                	ret

0000000000004aea <strlen>:

uint
strlen(const char *s)
{
    4aea:	1141                	addi	sp,sp,-16
    4aec:	e406                	sd	ra,8(sp)
    4aee:	e022                	sd	s0,0(sp)
    4af0:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    4af2:	00054783          	lbu	a5,0(a0)
    4af6:	cf91                	beqz	a5,4b12 <strlen+0x28>
    4af8:	00150793          	addi	a5,a0,1
    4afc:	86be                	mv	a3,a5
    4afe:	0785                	addi	a5,a5,1
    4b00:	fff7c703          	lbu	a4,-1(a5)
    4b04:	ff65                	bnez	a4,4afc <strlen+0x12>
    4b06:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    4b0a:	60a2                	ld	ra,8(sp)
    4b0c:	6402                	ld	s0,0(sp)
    4b0e:	0141                	addi	sp,sp,16
    4b10:	8082                	ret
  for(n = 0; s[n]; n++)
    4b12:	4501                	li	a0,0
    4b14:	bfdd                	j	4b0a <strlen+0x20>

0000000000004b16 <memset>:

void*
memset(void *dst, int c, uint n)
{
    4b16:	1141                	addi	sp,sp,-16
    4b18:	e406                	sd	ra,8(sp)
    4b1a:	e022                	sd	s0,0(sp)
    4b1c:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    4b1e:	ca19                	beqz	a2,4b34 <memset+0x1e>
    4b20:	87aa                	mv	a5,a0
    4b22:	1602                	slli	a2,a2,0x20
    4b24:	9201                	srli	a2,a2,0x20
    4b26:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    4b2a:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    4b2e:	0785                	addi	a5,a5,1
    4b30:	fee79de3          	bne	a5,a4,4b2a <memset+0x14>
  }
  return dst;
}
    4b34:	60a2                	ld	ra,8(sp)
    4b36:	6402                	ld	s0,0(sp)
    4b38:	0141                	addi	sp,sp,16
    4b3a:	8082                	ret

0000000000004b3c <strchr>:

char*
strchr(const char *s, char c)
{
    4b3c:	1141                	addi	sp,sp,-16
    4b3e:	e406                	sd	ra,8(sp)
    4b40:	e022                	sd	s0,0(sp)
    4b42:	0800                	addi	s0,sp,16
  for(; *s; s++)
    4b44:	00054783          	lbu	a5,0(a0)
    4b48:	c799                	beqz	a5,4b56 <strchr+0x1a>
    if(*s == c)
    4b4a:	00f58763          	beq	a1,a5,4b58 <strchr+0x1c>
  for(; *s; s++)
    4b4e:	0505                	addi	a0,a0,1
    4b50:	00054783          	lbu	a5,0(a0)
    4b54:	fbfd                	bnez	a5,4b4a <strchr+0xe>
      return (char*)s;
  return 0;
    4b56:	4501                	li	a0,0
}
    4b58:	60a2                	ld	ra,8(sp)
    4b5a:	6402                	ld	s0,0(sp)
    4b5c:	0141                	addi	sp,sp,16
    4b5e:	8082                	ret

0000000000004b60 <gets>:

char*
gets(char *buf, int max)
{
    4b60:	711d                	addi	sp,sp,-96
    4b62:	ec86                	sd	ra,88(sp)
    4b64:	e8a2                	sd	s0,80(sp)
    4b66:	e4a6                	sd	s1,72(sp)
    4b68:	e0ca                	sd	s2,64(sp)
    4b6a:	fc4e                	sd	s3,56(sp)
    4b6c:	f852                	sd	s4,48(sp)
    4b6e:	f456                	sd	s5,40(sp)
    4b70:	f05a                	sd	s6,32(sp)
    4b72:	ec5e                	sd	s7,24(sp)
    4b74:	e862                	sd	s8,16(sp)
    4b76:	1080                	addi	s0,sp,96
    4b78:	8baa                	mv	s7,a0
    4b7a:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    4b7c:	892a                	mv	s2,a0
    4b7e:	4481                	li	s1,0
    cc = read(0, &c, 1);
    4b80:	faf40b13          	addi	s6,s0,-81
    4b84:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
    4b86:	8c26                	mv	s8,s1
    4b88:	0014899b          	addiw	s3,s1,1
    4b8c:	84ce                	mv	s1,s3
    4b8e:	0349d863          	bge	s3,s4,4bbe <gets+0x5e>
    cc = read(0, &c, 1);
    4b92:	8656                	mv	a2,s5
    4b94:	85da                	mv	a1,s6
    4b96:	4501                	li	a0,0
    4b98:	194000ef          	jal	4d2c <read>
    if(cc < 1)
    4b9c:	02a05163          	blez	a0,4bbe <gets+0x5e>
      break;
    buf[i++] = c;
    4ba0:	faf44783          	lbu	a5,-81(s0)
    4ba4:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
    4ba8:	0905                	addi	s2,s2,1
    4baa:	ff678713          	addi	a4,a5,-10
    4bae:	00173713          	seqz	a4,a4
    4bb2:	17cd                	addi	a5,a5,-13
    4bb4:	0017b793          	seqz	a5,a5
    4bb8:	8fd9                	or	a5,a5,a4
    4bba:	d7f1                	beqz	a5,4b86 <gets+0x26>
    buf[i++] = c;
    4bbc:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
    4bbe:	9c5e                	add	s8,s8,s7
    4bc0:	000c0023          	sb	zero,0(s8)
  return buf;
}
    4bc4:	855e                	mv	a0,s7
    4bc6:	60e6                	ld	ra,88(sp)
    4bc8:	6446                	ld	s0,80(sp)
    4bca:	64a6                	ld	s1,72(sp)
    4bcc:	6906                	ld	s2,64(sp)
    4bce:	79e2                	ld	s3,56(sp)
    4bd0:	7a42                	ld	s4,48(sp)
    4bd2:	7aa2                	ld	s5,40(sp)
    4bd4:	7b02                	ld	s6,32(sp)
    4bd6:	6be2                	ld	s7,24(sp)
    4bd8:	6c42                	ld	s8,16(sp)
    4bda:	6125                	addi	sp,sp,96
    4bdc:	8082                	ret

0000000000004bde <stat>:

int
stat(const char *n, struct stat *st)
{
    4bde:	1101                	addi	sp,sp,-32
    4be0:	ec06                	sd	ra,24(sp)
    4be2:	e822                	sd	s0,16(sp)
    4be4:	e04a                	sd	s2,0(sp)
    4be6:	1000                	addi	s0,sp,32
    4be8:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
    4bea:	4581                	li	a1,0
    4bec:	168000ef          	jal	4d54 <open>
  if(fd < 0)
    4bf0:	02054263          	bltz	a0,4c14 <stat+0x36>
    4bf4:	e426                	sd	s1,8(sp)
    4bf6:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
    4bf8:	85ca                	mv	a1,s2
    4bfa:	172000ef          	jal	4d6c <fstat>
    4bfe:	892a                	mv	s2,a0
  close(fd);
    4c00:	8526                	mv	a0,s1
    4c02:	13a000ef          	jal	4d3c <close>
  return r;
    4c06:	64a2                	ld	s1,8(sp)
}
    4c08:	854a                	mv	a0,s2
    4c0a:	60e2                	ld	ra,24(sp)
    4c0c:	6442                	ld	s0,16(sp)
    4c0e:	6902                	ld	s2,0(sp)
    4c10:	6105                	addi	sp,sp,32
    4c12:	8082                	ret
    return -1;
    4c14:	57fd                	li	a5,-1
    4c16:	893e                	mv	s2,a5
    4c18:	bfc5                	j	4c08 <stat+0x2a>

0000000000004c1a <atoi>:

int
atoi(const char *s)
{
    4c1a:	1141                	addi	sp,sp,-16
    4c1c:	e406                	sd	ra,8(sp)
    4c1e:	e022                	sd	s0,0(sp)
    4c20:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    4c22:	00054683          	lbu	a3,0(a0)
    4c26:	fd06879b          	addiw	a5,a3,-48
    4c2a:	0ff7f793          	zext.b	a5,a5
    4c2e:	4625                	li	a2,9
    4c30:	02f66963          	bltu	a2,a5,4c62 <atoi+0x48>
    4c34:	872a                	mv	a4,a0
  n = 0;
    4c36:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
    4c38:	0705                	addi	a4,a4,1
    4c3a:	0025179b          	slliw	a5,a0,0x2
    4c3e:	9fa9                	addw	a5,a5,a0
    4c40:	0017979b          	slliw	a5,a5,0x1
    4c44:	9fb5                	addw	a5,a5,a3
    4c46:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
    4c4a:	00074683          	lbu	a3,0(a4)
    4c4e:	fd06879b          	addiw	a5,a3,-48
    4c52:	0ff7f793          	zext.b	a5,a5
    4c56:	fef671e3          	bgeu	a2,a5,4c38 <atoi+0x1e>
  return n;
}
    4c5a:	60a2                	ld	ra,8(sp)
    4c5c:	6402                	ld	s0,0(sp)
    4c5e:	0141                	addi	sp,sp,16
    4c60:	8082                	ret
  n = 0;
    4c62:	4501                	li	a0,0
    4c64:	bfdd                	j	4c5a <atoi+0x40>

0000000000004c66 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
    4c66:	1141                	addi	sp,sp,-16
    4c68:	e406                	sd	ra,8(sp)
    4c6a:	e022                	sd	s0,0(sp)
    4c6c:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
    4c6e:	02b57563          	bgeu	a0,a1,4c98 <memmove+0x32>
    while(n-- > 0)
    4c72:	00c05f63          	blez	a2,4c90 <memmove+0x2a>
    4c76:	1602                	slli	a2,a2,0x20
    4c78:	9201                	srli	a2,a2,0x20
    4c7a:	00c507b3          	add	a5,a0,a2
  dst = vdst;
    4c7e:	872a                	mv	a4,a0
      *dst++ = *src++;
    4c80:	0585                	addi	a1,a1,1
    4c82:	0705                	addi	a4,a4,1
    4c84:	fff5c683          	lbu	a3,-1(a1)
    4c88:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    4c8c:	fee79ae3          	bne	a5,a4,4c80 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
    4c90:	60a2                	ld	ra,8(sp)
    4c92:	6402                	ld	s0,0(sp)
    4c94:	0141                	addi	sp,sp,16
    4c96:	8082                	ret
    while(n-- > 0)
    4c98:	fec05ce3          	blez	a2,4c90 <memmove+0x2a>
    dst += n;
    4c9c:	00c50733          	add	a4,a0,a2
    src += n;
    4ca0:	95b2                	add	a1,a1,a2
    4ca2:	fff6079b          	addiw	a5,a2,-1
    4ca6:	1782                	slli	a5,a5,0x20
    4ca8:	9381                	srli	a5,a5,0x20
    4caa:	fff7c793          	not	a5,a5
    4cae:	97ba                	add	a5,a5,a4
      *--dst = *--src;
    4cb0:	15fd                	addi	a1,a1,-1
    4cb2:	177d                	addi	a4,a4,-1
    4cb4:	0005c683          	lbu	a3,0(a1)
    4cb8:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
    4cbc:	fef71ae3          	bne	a4,a5,4cb0 <memmove+0x4a>
    4cc0:	bfc1                	j	4c90 <memmove+0x2a>

0000000000004cc2 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
    4cc2:	1141                	addi	sp,sp,-16
    4cc4:	e406                	sd	ra,8(sp)
    4cc6:	e022                	sd	s0,0(sp)
    4cc8:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
    4cca:	ce19                	beqz	a2,4ce8 <memcmp+0x26>
    4ccc:	1602                	slli	a2,a2,0x20
    4cce:	9201                	srli	a2,a2,0x20
    4cd0:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
    4cd4:	00054783          	lbu	a5,0(a0)
    4cd8:	0005c703          	lbu	a4,0(a1)
    4cdc:	00e79b63          	bne	a5,a4,4cf2 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
    4ce0:	0505                	addi	a0,a0,1
    p2++;
    4ce2:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    4ce4:	fed518e3          	bne	a0,a3,4cd4 <memcmp+0x12>
  }
  return 0;
    4ce8:	4501                	li	a0,0
}
    4cea:	60a2                	ld	ra,8(sp)
    4cec:	6402                	ld	s0,0(sp)
    4cee:	0141                	addi	sp,sp,16
    4cf0:	8082                	ret
      return *p1 - *p2;
    4cf2:	40e7853b          	subw	a0,a5,a4
    4cf6:	bfd5                	j	4cea <memcmp+0x28>

0000000000004cf8 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
    4cf8:	1141                	addi	sp,sp,-16
    4cfa:	e406                	sd	ra,8(sp)
    4cfc:	e022                	sd	s0,0(sp)
    4cfe:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    4d00:	f67ff0ef          	jal	4c66 <memmove>
}
    4d04:	60a2                	ld	ra,8(sp)
    4d06:	6402                	ld	s0,0(sp)
    4d08:	0141                	addi	sp,sp,16
    4d0a:	8082                	ret

0000000000004d0c <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
    4d0c:	4885                	li	a7,1
 ecall
    4d0e:	00000073          	ecall
 ret
    4d12:	8082                	ret

0000000000004d14 <exit>:
.global exit
exit:
 li a7, SYS_exit
    4d14:	4889                	li	a7,2
 ecall
    4d16:	00000073          	ecall
 ret
    4d1a:	8082                	ret

0000000000004d1c <wait>:
.global wait
wait:
 li a7, SYS_wait
    4d1c:	488d                	li	a7,3
 ecall
    4d1e:	00000073          	ecall
 ret
    4d22:	8082                	ret

0000000000004d24 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
    4d24:	4891                	li	a7,4
 ecall
    4d26:	00000073          	ecall
 ret
    4d2a:	8082                	ret

0000000000004d2c <read>:
.global read
read:
 li a7, SYS_read
    4d2c:	4895                	li	a7,5
 ecall
    4d2e:	00000073          	ecall
 ret
    4d32:	8082                	ret

0000000000004d34 <write>:
.global write
write:
 li a7, SYS_write
    4d34:	48c1                	li	a7,16
 ecall
    4d36:	00000073          	ecall
 ret
    4d3a:	8082                	ret

0000000000004d3c <close>:
.global close
close:
 li a7, SYS_close
    4d3c:	48d5                	li	a7,21
 ecall
    4d3e:	00000073          	ecall
 ret
    4d42:	8082                	ret

0000000000004d44 <kill>:
.global kill
kill:
 li a7, SYS_kill
    4d44:	4899                	li	a7,6
 ecall
    4d46:	00000073          	ecall
 ret
    4d4a:	8082                	ret

0000000000004d4c <exec>:
.global exec
exec:
 li a7, SYS_exec
    4d4c:	489d                	li	a7,7
 ecall
    4d4e:	00000073          	ecall
 ret
    4d52:	8082                	ret

0000000000004d54 <open>:
.global open
open:
 li a7, SYS_open
    4d54:	48bd                	li	a7,15
 ecall
    4d56:	00000073          	ecall
 ret
    4d5a:	8082                	ret

0000000000004d5c <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
    4d5c:	48c5                	li	a7,17
 ecall
    4d5e:	00000073          	ecall
 ret
    4d62:	8082                	ret

0000000000004d64 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
    4d64:	48c9                	li	a7,18
 ecall
    4d66:	00000073          	ecall
 ret
    4d6a:	8082                	ret

0000000000004d6c <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
    4d6c:	48a1                	li	a7,8
 ecall
    4d6e:	00000073          	ecall
 ret
    4d72:	8082                	ret

0000000000004d74 <link>:
.global link
link:
 li a7, SYS_link
    4d74:	48cd                	li	a7,19
 ecall
    4d76:	00000073          	ecall
 ret
    4d7a:	8082                	ret

0000000000004d7c <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
    4d7c:	48d1                	li	a7,20
 ecall
    4d7e:	00000073          	ecall
 ret
    4d82:	8082                	ret

0000000000004d84 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
    4d84:	48a5                	li	a7,9
 ecall
    4d86:	00000073          	ecall
 ret
    4d8a:	8082                	ret

0000000000004d8c <dup>:
.global dup
dup:
 li a7, SYS_dup
    4d8c:	48a9                	li	a7,10
 ecall
    4d8e:	00000073          	ecall
 ret
    4d92:	8082                	ret

0000000000004d94 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
    4d94:	48ad                	li	a7,11
 ecall
    4d96:	00000073          	ecall
 ret
    4d9a:	8082                	ret

0000000000004d9c <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
    4d9c:	48b1                	li	a7,12
 ecall
    4d9e:	00000073          	ecall
 ret
    4da2:	8082                	ret

0000000000004da4 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
    4da4:	48b5                	li	a7,13
 ecall
    4da6:	00000073          	ecall
 ret
    4daa:	8082                	ret

0000000000004dac <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
    4dac:	48b9                	li	a7,14
 ecall
    4dae:	00000073          	ecall
 ret
    4db2:	8082                	ret

0000000000004db4 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
    4db4:	1101                	addi	sp,sp,-32
    4db6:	ec06                	sd	ra,24(sp)
    4db8:	e822                	sd	s0,16(sp)
    4dba:	1000                	addi	s0,sp,32
    4dbc:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
    4dc0:	4605                	li	a2,1
    4dc2:	fef40593          	addi	a1,s0,-17
    4dc6:	f6fff0ef          	jal	4d34 <write>
}
    4dca:	60e2                	ld	ra,24(sp)
    4dcc:	6442                	ld	s0,16(sp)
    4dce:	6105                	addi	sp,sp,32
    4dd0:	8082                	ret

0000000000004dd2 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
    4dd2:	715d                	addi	sp,sp,-80
    4dd4:	e486                	sd	ra,72(sp)
    4dd6:	e0a2                	sd	s0,64(sp)
    4dd8:	f84a                	sd	s2,48(sp)
    4dda:	f44e                	sd	s3,40(sp)
    4ddc:	0880                	addi	s0,sp,80
    4dde:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
    4de0:	00d036b3          	snez	a3,a3
    4de4:	03f5d793          	srli	a5,a1,0x3f
    4de8:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
    4dea:	0005871b          	sext.w	a4,a1
  neg = 0;
    4dee:	4301                	li	t1,0
  if(sgn && xx < 0){
    4df0:	c681                	beqz	a3,4df8 <printint+0x26>
    x = -xx;
    4df2:	40b0073b          	negw	a4,a1
    neg = 1;
    4df6:	4305                	li	t1,1
  }

  i = 0;
    4df8:	fb840993          	addi	s3,s0,-72
  neg = 0;
    4dfc:	85ce                	mv	a1,s3
  i = 0;
    4dfe:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
    4e00:	00003817          	auipc	a6,0x3
    4e04:	b2880813          	addi	a6,a6,-1240 # 7928 <digits>
    4e08:	88b6                	mv	a7,a3
    4e0a:	0016851b          	addiw	a0,a3,1
    4e0e:	86aa                	mv	a3,a0
    4e10:	02c777bb          	remuw	a5,a4,a2
    4e14:	1782                	slli	a5,a5,0x20
    4e16:	9381                	srli	a5,a5,0x20
    4e18:	97c2                	add	a5,a5,a6
    4e1a:	0007c783          	lbu	a5,0(a5)
    4e1e:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
    4e22:	87ba                	mv	a5,a4
    4e24:	02c7573b          	divuw	a4,a4,a2
    4e28:	0585                	addi	a1,a1,1
    4e2a:	fcc7ffe3          	bgeu	a5,a2,4e08 <printint+0x36>
  if(neg)
    4e2e:	00030b63          	beqz	t1,4e44 <printint+0x72>
    buf[i++] = '-';
    4e32:	fd040793          	addi	a5,s0,-48
    4e36:	953e                	add	a0,a0,a5
    4e38:	02d00793          	li	a5,45
    4e3c:	fef50423          	sb	a5,-24(a0)
    4e40:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
    4e44:	02d05563          	blez	a3,4e6e <printint+0x9c>
    4e48:	fc26                	sd	s1,56(sp)
    4e4a:	36fd                	addiw	a3,a3,-1
    4e4c:	00d984b3          	add	s1,s3,a3
    4e50:	19fd                	addi	s3,s3,-1
    4e52:	99b6                	add	s3,s3,a3
    4e54:	1682                	slli	a3,a3,0x20
    4e56:	9281                	srli	a3,a3,0x20
    4e58:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
    4e5c:	0004c583          	lbu	a1,0(s1)
    4e60:	854a                	mv	a0,s2
    4e62:	f53ff0ef          	jal	4db4 <putc>
  while(--i >= 0)
    4e66:	14fd                	addi	s1,s1,-1
    4e68:	ff349ae3          	bne	s1,s3,4e5c <printint+0x8a>
    4e6c:	74e2                	ld	s1,56(sp)
}
    4e6e:	60a6                	ld	ra,72(sp)
    4e70:	6406                	ld	s0,64(sp)
    4e72:	7942                	ld	s2,48(sp)
    4e74:	79a2                	ld	s3,40(sp)
    4e76:	6161                	addi	sp,sp,80
    4e78:	8082                	ret

0000000000004e7a <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
    4e7a:	711d                	addi	sp,sp,-96
    4e7c:	ec86                	sd	ra,88(sp)
    4e7e:	e8a2                	sd	s0,80(sp)
    4e80:	e4a6                	sd	s1,72(sp)
    4e82:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
    4e84:	0005c483          	lbu	s1,0(a1)
    4e88:	28048263          	beqz	s1,510c <vprintf+0x292>
    4e8c:	e0ca                	sd	s2,64(sp)
    4e8e:	fc4e                	sd	s3,56(sp)
    4e90:	f852                	sd	s4,48(sp)
    4e92:	f456                	sd	s5,40(sp)
    4e94:	f05a                	sd	s6,32(sp)
    4e96:	ec5e                	sd	s7,24(sp)
    4e98:	e862                	sd	s8,16(sp)
    4e9a:	8b2a                	mv	s6,a0
    4e9c:	8a2e                	mv	s4,a1
    4e9e:	8bb2                	mv	s7,a2
  state = 0;
    4ea0:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
    4ea2:	4901                	li	s2,0
    4ea4:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
    4ea6:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
    4eaa:	06400c13          	li	s8,100
    4eae:	a00d                	j	4ed0 <vprintf+0x56>
        putc(fd, c0);
    4eb0:	85a6                	mv	a1,s1
    4eb2:	855a                	mv	a0,s6
    4eb4:	f01ff0ef          	jal	4db4 <putc>
    4eb8:	a019                	j	4ebe <vprintf+0x44>
    } else if(state == '%'){
    4eba:	03598363          	beq	s3,s5,4ee0 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
    4ebe:	0019079b          	addiw	a5,s2,1
    4ec2:	893e                	mv	s2,a5
    4ec4:	873e                	mv	a4,a5
    4ec6:	97d2                	add	a5,a5,s4
    4ec8:	0007c483          	lbu	s1,0(a5)
    4ecc:	22048963          	beqz	s1,50fe <vprintf+0x284>
    c0 = fmt[i] & 0xff;
    4ed0:	0004879b          	sext.w	a5,s1
    if(state == 0){
    4ed4:	fe0993e3          	bnez	s3,4eba <vprintf+0x40>
      if(c0 == '%'){
    4ed8:	fd579ce3          	bne	a5,s5,4eb0 <vprintf+0x36>
        state = '%';
    4edc:	89be                	mv	s3,a5
    4ede:	b7c5                	j	4ebe <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
    4ee0:	00ea06b3          	add	a3,s4,a4
    4ee4:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
    4ee8:	22060763          	beqz	a2,5116 <vprintf+0x29c>
      if(c0 == 'd'){
    4eec:	0b878363          	beq	a5,s8,4f92 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
    4ef0:	f9478693          	addi	a3,a5,-108
    4ef4:	0016b693          	seqz	a3,a3
    4ef8:	f9c60593          	addi	a1,a2,-100
    4efc:	0015b593          	seqz	a1,a1
    4f00:	8df5                	and	a1,a1,a3
    4f02:	e5c5                	bnez	a1,4faa <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
    4f04:	9752                	add	a4,a4,s4
    4f06:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    4f0a:	f9460713          	addi	a4,a2,-108
    4f0e:	00173713          	seqz	a4,a4
    4f12:	8f75                	and	a4,a4,a3
    4f14:	f9c50593          	addi	a1,a0,-100
    4f18:	0015b593          	seqz	a1,a1
    4f1c:	8df9                	and	a1,a1,a4
    4f1e:	e1dd                	bnez	a1,4fc4 <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
    4f20:	07500593          	li	a1,117
    4f24:	0ab78d63          	beq	a5,a1,4fde <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
    4f28:	f8b60593          	addi	a1,a2,-117
    4f2c:	0015b593          	seqz	a1,a1
    4f30:	8df5                	and	a1,a1,a3
    4f32:	e1f1                	bnez	a1,4ff6 <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    4f34:	f8b50593          	addi	a1,a0,-117
    4f38:	0015b593          	seqz	a1,a1
    4f3c:	8df9                	and	a1,a1,a4
    4f3e:	e9e9                	bnez	a1,5010 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
    4f40:	07800593          	li	a1,120
    4f44:	0eb78363          	beq	a5,a1,502a <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
    4f48:	f8860613          	addi	a2,a2,-120
    4f4c:	00163613          	seqz	a2,a2
    4f50:	8ef1                	and	a3,a3,a2
    4f52:	0e069863          	bnez	a3,5042 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    4f56:	f8850513          	addi	a0,a0,-120
    4f5a:	00153513          	seqz	a0,a0
    4f5e:	8f69                	and	a4,a4,a0
    4f60:	0e071e63          	bnez	a4,505c <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
    4f64:	07000713          	li	a4,112
    4f68:	10e78663          	beq	a5,a4,5074 <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
    4f6c:	07300713          	li	a4,115
    4f70:	14e78663          	beq	a5,a4,50bc <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
    4f74:	02500713          	li	a4,37
    4f78:	16e78e63          	beq	a5,a4,50f4 <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
    4f7c:	02500593          	li	a1,37
    4f80:	855a                	mv	a0,s6
    4f82:	e33ff0ef          	jal	4db4 <putc>
        putc(fd, c0);
    4f86:	85a6                	mv	a1,s1
    4f88:	855a                	mv	a0,s6
    4f8a:	e2bff0ef          	jal	4db4 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
    4f8e:	4981                	li	s3,0
    4f90:	b73d                	j	4ebe <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
    4f92:	008b8493          	addi	s1,s7,8
    4f96:	4685                	li	a3,1
    4f98:	4629                	li	a2,10
    4f9a:	000ba583          	lw	a1,0(s7)
    4f9e:	855a                	mv	a0,s6
    4fa0:	e33ff0ef          	jal	4dd2 <printint>
    4fa4:	8ba6                	mv	s7,s1
      state = 0;
    4fa6:	4981                	li	s3,0
    4fa8:	bf19                	j	4ebe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
    4faa:	008b8493          	addi	s1,s7,8
    4fae:	4685                	li	a3,1
    4fb0:	4629                	li	a2,10
    4fb2:	000bb583          	ld	a1,0(s7)
    4fb6:	855a                	mv	a0,s6
    4fb8:	e1bff0ef          	jal	4dd2 <printint>
        i += 1;
    4fbc:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
    4fbe:	8ba6                	mv	s7,s1
      state = 0;
    4fc0:	4981                	li	s3,0
    4fc2:	bdf5                	j	4ebe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
    4fc4:	008b8493          	addi	s1,s7,8
    4fc8:	4685                	li	a3,1
    4fca:	4629                	li	a2,10
    4fcc:	000bb583          	ld	a1,0(s7)
    4fd0:	855a                	mv	a0,s6
    4fd2:	e01ff0ef          	jal	4dd2 <printint>
        i += 2;
    4fd6:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
    4fd8:	8ba6                	mv	s7,s1
      state = 0;
    4fda:	4981                	li	s3,0
        i += 2;
    4fdc:	b5cd                	j	4ebe <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
    4fde:	008b8493          	addi	s1,s7,8
    4fe2:	4681                	li	a3,0
    4fe4:	4629                	li	a2,10
    4fe6:	000ba583          	lw	a1,0(s7)
    4fea:	855a                	mv	a0,s6
    4fec:	de7ff0ef          	jal	4dd2 <printint>
    4ff0:	8ba6                	mv	s7,s1
      state = 0;
    4ff2:	4981                	li	s3,0
    4ff4:	b5e9                	j	4ebe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
    4ff6:	008b8493          	addi	s1,s7,8
    4ffa:	4681                	li	a3,0
    4ffc:	4629                	li	a2,10
    4ffe:	000bb583          	ld	a1,0(s7)
    5002:	855a                	mv	a0,s6
    5004:	dcfff0ef          	jal	4dd2 <printint>
        i += 1;
    5008:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
    500a:	8ba6                	mv	s7,s1
      state = 0;
    500c:	4981                	li	s3,0
    500e:	bd45                	j	4ebe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
    5010:	008b8493          	addi	s1,s7,8
    5014:	4681                	li	a3,0
    5016:	4629                	li	a2,10
    5018:	000bb583          	ld	a1,0(s7)
    501c:	855a                	mv	a0,s6
    501e:	db5ff0ef          	jal	4dd2 <printint>
        i += 2;
    5022:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
    5024:	8ba6                	mv	s7,s1
      state = 0;
    5026:	4981                	li	s3,0
        i += 2;
    5028:	bd59                	j	4ebe <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
    502a:	008b8493          	addi	s1,s7,8
    502e:	4681                	li	a3,0
    5030:	4641                	li	a2,16
    5032:	000ba583          	lw	a1,0(s7)
    5036:	855a                	mv	a0,s6
    5038:	d9bff0ef          	jal	4dd2 <printint>
    503c:	8ba6                	mv	s7,s1
      state = 0;
    503e:	4981                	li	s3,0
    5040:	bdbd                	j	4ebe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
    5042:	008b8493          	addi	s1,s7,8
    5046:	4681                	li	a3,0
    5048:	4641                	li	a2,16
    504a:	000bb583          	ld	a1,0(s7)
    504e:	855a                	mv	a0,s6
    5050:	d83ff0ef          	jal	4dd2 <printint>
        i += 1;
    5054:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
    5056:	8ba6                	mv	s7,s1
      state = 0;
    5058:	4981                	li	s3,0
    505a:	b595                	j	4ebe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
    505c:	008b8493          	addi	s1,s7,8
    5060:	4641                	li	a2,16
    5062:	000bb583          	ld	a1,0(s7)
    5066:	855a                	mv	a0,s6
    5068:	d6bff0ef          	jal	4dd2 <printint>
        i += 2;
    506c:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
    506e:	8ba6                	mv	s7,s1
      state = 0;
    5070:	4981                	li	s3,0
        i += 2;
    5072:	b5b1                	j	4ebe <vprintf+0x44>
    5074:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
    5076:	008b8793          	addi	a5,s7,8
    507a:	8cbe                	mv	s9,a5
    507c:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
    5080:	03000593          	li	a1,48
    5084:	855a                	mv	a0,s6
    5086:	d2fff0ef          	jal	4db4 <putc>
  putc(fd, 'x');
    508a:	07800593          	li	a1,120
    508e:	855a                	mv	a0,s6
    5090:	d25ff0ef          	jal	4db4 <putc>
    5094:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    5096:	00003b97          	auipc	s7,0x3
    509a:	892b8b93          	addi	s7,s7,-1902 # 7928 <digits>
    509e:	03c9d793          	srli	a5,s3,0x3c
    50a2:	97de                	add	a5,a5,s7
    50a4:	0007c583          	lbu	a1,0(a5)
    50a8:	855a                	mv	a0,s6
    50aa:	d0bff0ef          	jal	4db4 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    50ae:	0992                	slli	s3,s3,0x4
    50b0:	34fd                	addiw	s1,s1,-1
    50b2:	f4f5                	bnez	s1,509e <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
    50b4:	8be6                	mv	s7,s9
      state = 0;
    50b6:	4981                	li	s3,0
    50b8:	6ca2                	ld	s9,8(sp)
    50ba:	b511                	j	4ebe <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
    50bc:	008b8993          	addi	s3,s7,8
    50c0:	000bb483          	ld	s1,0(s7)
    50c4:	cc91                	beqz	s1,50e0 <vprintf+0x266>
        for(; *s; s++)
    50c6:	0004c583          	lbu	a1,0(s1)
    50ca:	c195                	beqz	a1,50ee <vprintf+0x274>
          putc(fd, *s);
    50cc:	855a                	mv	a0,s6
    50ce:	ce7ff0ef          	jal	4db4 <putc>
        for(; *s; s++)
    50d2:	0485                	addi	s1,s1,1
    50d4:	0004c583          	lbu	a1,0(s1)
    50d8:	f9f5                	bnez	a1,50cc <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
    50da:	8bce                	mv	s7,s3
      state = 0;
    50dc:	4981                	li	s3,0
    50de:	b3c5                	j	4ebe <vprintf+0x44>
          s = "(null)";
    50e0:	00002497          	auipc	s1,0x2
    50e4:	7a048493          	addi	s1,s1,1952 # 7880 <thread_switch+0x240a>
        for(; *s; s++)
    50e8:	02800593          	li	a1,40
    50ec:	b7c5                	j	50cc <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
    50ee:	8bce                	mv	s7,s3
      state = 0;
    50f0:	4981                	li	s3,0
    50f2:	b3f1                	j	4ebe <vprintf+0x44>
        putc(fd, '%');
    50f4:	85be                	mv	a1,a5
    50f6:	855a                	mv	a0,s6
    50f8:	cbdff0ef          	jal	4db4 <putc>
    50fc:	bd49                	j	4f8e <vprintf+0x114>
    50fe:	6906                	ld	s2,64(sp)
    5100:	79e2                	ld	s3,56(sp)
    5102:	7a42                	ld	s4,48(sp)
    5104:	7aa2                	ld	s5,40(sp)
    5106:	7b02                	ld	s6,32(sp)
    5108:	6be2                	ld	s7,24(sp)
    510a:	6c42                	ld	s8,16(sp)
    }
  }
}
    510c:	60e6                	ld	ra,88(sp)
    510e:	6446                	ld	s0,80(sp)
    5110:	64a6                	ld	s1,72(sp)
    5112:	6125                	addi	sp,sp,96
    5114:	8082                	ret
      if(c0 == 'd'){
    5116:	06400713          	li	a4,100
    511a:	e6e78ce3          	beq	a5,a4,4f92 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
    511e:	f9478693          	addi	a3,a5,-108
    5122:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
    5126:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    5128:	4701                	li	a4,0
    512a:	bbdd                	j	4f20 <vprintf+0xa6>

000000000000512c <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
    512c:	715d                	addi	sp,sp,-80
    512e:	ec06                	sd	ra,24(sp)
    5130:	e822                	sd	s0,16(sp)
    5132:	1000                	addi	s0,sp,32
    5134:	e010                	sd	a2,0(s0)
    5136:	e414                	sd	a3,8(s0)
    5138:	e818                	sd	a4,16(s0)
    513a:	ec1c                	sd	a5,24(s0)
    513c:	03043023          	sd	a6,32(s0)
    5140:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
    5144:	8622                	mv	a2,s0
    5146:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
    514a:	d31ff0ef          	jal	4e7a <vprintf>
}
    514e:	60e2                	ld	ra,24(sp)
    5150:	6442                	ld	s0,16(sp)
    5152:	6161                	addi	sp,sp,80
    5154:	8082                	ret

0000000000005156 <printf>:

void
printf(const char *fmt, ...)
{
    5156:	711d                	addi	sp,sp,-96
    5158:	ec06                	sd	ra,24(sp)
    515a:	e822                	sd	s0,16(sp)
    515c:	1000                	addi	s0,sp,32
    515e:	e40c                	sd	a1,8(s0)
    5160:	e810                	sd	a2,16(s0)
    5162:	ec14                	sd	a3,24(s0)
    5164:	f018                	sd	a4,32(s0)
    5166:	f41c                	sd	a5,40(s0)
    5168:	03043823          	sd	a6,48(s0)
    516c:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
    5170:	00840613          	addi	a2,s0,8
    5174:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
    5178:	85aa                	mv	a1,a0
    517a:	4505                	li	a0,1
    517c:	cffff0ef          	jal	4e7a <vprintf>
}
    5180:	60e2                	ld	ra,24(sp)
    5182:	6442                	ld	s0,16(sp)
    5184:	6125                	addi	sp,sp,96
    5186:	8082                	ret

0000000000005188 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
    5188:	1141                	addi	sp,sp,-16
    518a:	e406                	sd	ra,8(sp)
    518c:	e022                	sd	s0,0(sp)
    518e:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
    5190:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    5194:	00003797          	auipc	a5,0x3
    5198:	2bc7b783          	ld	a5,700(a5) # 8450 <freep>
    519c:	a095                	j	5200 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    519e:	ff852583          	lw	a1,-8(a0)
    51a2:	6390                	ld	a2,0(a5)
    51a4:	02059813          	slli	a6,a1,0x20
    51a8:	01c85693          	srli	a3,a6,0x1c
    51ac:	96ba                	add	a3,a3,a4
    51ae:	02d60563          	beq	a2,a3,51d8 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
    51b2:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    51b6:	4790                	lw	a2,8(a5)
    51b8:	02061593          	slli	a1,a2,0x20
    51bc:	01c5d693          	srli	a3,a1,0x1c
    51c0:	96be                	add	a3,a3,a5
    51c2:	02d70263          	beq	a4,a3,51e6 <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
    51c6:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
    51c8:	00003717          	auipc	a4,0x3
    51cc:	28f73423          	sd	a5,648(a4) # 8450 <freep>
}
    51d0:	60a2                	ld	ra,8(sp)
    51d2:	6402                	ld	s0,0(sp)
    51d4:	0141                	addi	sp,sp,16
    51d6:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
    51d8:	4614                	lw	a3,8(a2)
    51da:	9ead                	addw	a3,a3,a1
    51dc:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
    51e0:	6394                	ld	a3,0(a5)
    51e2:	6290                	ld	a2,0(a3)
    51e4:	b7f9                	j	51b2 <free+0x2a>
    p->s.size += bp->s.size;
    51e6:	ff852703          	lw	a4,-8(a0)
    51ea:	9f31                	addw	a4,a4,a2
    51ec:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
    51ee:	ff053703          	ld	a4,-16(a0)
    51f2:	bfd1                	j	51c6 <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    51f4:	6394                	ld	a3,0(a5)
    51f6:	00d7e463          	bltu	a5,a3,51fe <free+0x76>
    51fa:	fad762e3          	bltu	a4,a3,519e <free+0x16>
    51fe:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    5200:	fee7fae3          	bgeu	a5,a4,51f4 <free+0x6c>
    5204:	6394                	ld	a3,0(a5)
    5206:	f8d76ce3          	bltu	a4,a3,519e <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    520a:	f8d7fae3          	bgeu	a5,a3,519e <free+0x16>
    520e:	87b6                	mv	a5,a3
    5210:	bfc5                	j	5200 <free+0x78>

0000000000005212 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
    5212:	7139                	addi	sp,sp,-64
    5214:	fc06                	sd	ra,56(sp)
    5216:	f822                	sd	s0,48(sp)
    5218:	f04a                	sd	s2,32(sp)
    521a:	ec4e                	sd	s3,24(sp)
    521c:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    521e:	02051993          	slli	s3,a0,0x20
    5222:	0209d993          	srli	s3,s3,0x20
    5226:	09bd                	addi	s3,s3,15
    5228:	0049d993          	srli	s3,s3,0x4
    522c:	2985                	addiw	s3,s3,1
    522e:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
    5230:	00003517          	auipc	a0,0x3
    5234:	22053503          	ld	a0,544(a0) # 8450 <freep>
    5238:	c905                	beqz	a0,5268 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    523a:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    523c:	4798                	lw	a4,8(a5)
    523e:	09377663          	bgeu	a4,s3,52ca <malloc+0xb8>
    5242:	f426                	sd	s1,40(sp)
    5244:	e852                	sd	s4,16(sp)
    5246:	e456                	sd	s5,8(sp)
    5248:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
    524a:	8a4e                	mv	s4,s3
    524c:	6705                	lui	a4,0x1
    524e:	00e9f363          	bgeu	s3,a4,5254 <malloc+0x42>
    5252:	6a05                	lui	s4,0x1
    5254:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
    5258:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
    525c:	00003497          	auipc	s1,0x3
    5260:	1f448493          	addi	s1,s1,500 # 8450 <freep>
  if(p == (char*)-1)
    5264:	5afd                	li	s5,-1
    5266:	a83d                	j	52a4 <malloc+0x92>
    5268:	f426                	sd	s1,40(sp)
    526a:	e852                	sd	s4,16(sp)
    526c:	e456                	sd	s5,8(sp)
    526e:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
    5270:	0000a797          	auipc	a5,0xa
    5274:	a0878793          	addi	a5,a5,-1528 # ec78 <base>
    5278:	00003717          	auipc	a4,0x3
    527c:	1cf73c23          	sd	a5,472(a4) # 8450 <freep>
    5280:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
    5282:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
    5286:	b7d1                	j	524a <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
    5288:	6398                	ld	a4,0(a5)
    528a:	e118                	sd	a4,0(a0)
    528c:	a899                	j	52e2 <malloc+0xd0>
  hp->s.size = nu;
    528e:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
    5292:	0541                	addi	a0,a0,16
    5294:	ef5ff0ef          	jal	5188 <free>
  return freep;
    5298:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
    529a:	c125                	beqz	a0,52fa <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    529c:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    529e:	4798                	lw	a4,8(a5)
    52a0:	03277163          	bgeu	a4,s2,52c2 <malloc+0xb0>
    if(p == freep)
    52a4:	6098                	ld	a4,0(s1)
    52a6:	853e                	mv	a0,a5
    52a8:	fef71ae3          	bne	a4,a5,529c <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
    52ac:	8552                	mv	a0,s4
    52ae:	aefff0ef          	jal	4d9c <sbrk>
  if(p == (char*)-1)
    52b2:	fd551ee3          	bne	a0,s5,528e <malloc+0x7c>
        return 0;
    52b6:	4501                	li	a0,0
    52b8:	74a2                	ld	s1,40(sp)
    52ba:	6a42                	ld	s4,16(sp)
    52bc:	6aa2                	ld	s5,8(sp)
    52be:	6b02                	ld	s6,0(sp)
    52c0:	a03d                	j	52ee <malloc+0xdc>
    52c2:	74a2                	ld	s1,40(sp)
    52c4:	6a42                	ld	s4,16(sp)
    52c6:	6aa2                	ld	s5,8(sp)
    52c8:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
    52ca:	fae90fe3          	beq	s2,a4,5288 <malloc+0x76>
        p->s.size -= nunits;
    52ce:	4137073b          	subw	a4,a4,s3
    52d2:	c798                	sw	a4,8(a5)
        p += p->s.size;
    52d4:	02071693          	slli	a3,a4,0x20
    52d8:	01c6d713          	srli	a4,a3,0x1c
    52dc:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
    52de:	0137a423          	sw	s3,8(a5)
      freep = prevp;
    52e2:	00003717          	auipc	a4,0x3
    52e6:	16a73723          	sd	a0,366(a4) # 8450 <freep>
      return (void*)(p + 1);
    52ea:	01078513          	addi	a0,a5,16
  }
}
    52ee:	70e2                	ld	ra,56(sp)
    52f0:	7442                	ld	s0,48(sp)
    52f2:	7902                	ld	s2,32(sp)
    52f4:	69e2                	ld	s3,24(sp)
    52f6:	6121                	addi	sp,sp,64
    52f8:	8082                	ret
    52fa:	74a2                	ld	s1,40(sp)
    52fc:	6a42                	ld	s4,16(sp)
    52fe:	6aa2                	ld	s5,8(sp)
    5300:	6b02                	ld	s6,0(sp)
    5302:	b7f5                	j	52ee <malloc+0xdc>

0000000000005304 <thread_init>:
struct thread *current_thread;
extern void thread_switch(uint64, uint64);
              
void 
thread_init(void)
{
    5304:	1141                	addi	sp,sp,-16
    5306:	e406                	sd	ra,8(sp)
    5308:	e022                	sd	s0,0(sp)
    530a:	0800                	addi	s0,sp,16
  // main() is thread 0, which will make the first invocation to
  // thread_schedule(). It needs a stack so that the first thread_switch() can
  // save thread 0's state.
  current_thread = &all_thread[0];
    530c:	0000a797          	auipc	a5,0xa
    5310:	97c78793          	addi	a5,a5,-1668 # ec88 <all_thread>
    5314:	00003717          	auipc	a4,0x3
    5318:	14f73223          	sd	a5,324(a4) # 8458 <current_thread>
  current_thread->state = RUNNING;
    531c:	0000c717          	auipc	a4,0xc
    5320:	96c70713          	addi	a4,a4,-1684 # 10c88 <all_thread+0x2000>
    5324:	4785                	li	a5,1
    5326:	c31c                	sw	a5,0(a4)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
    5328:	0000c797          	auipc	a5,0xc
    532c:	8f078793          	addi	a5,a5,-1808 # 10c18 <all_thread+0x1f90>
  return (struct context *)(top & ~(uint64)0xf);
    5330:	9bc1                	andi	a5,a5,-16
  // Thread 0 runs on the process's own stack, but the first thread_switch()
  // still needs a writable place to save its context.
  current_thread->context = thread_context_slot(current_thread);
    5332:	e71c                	sd	a5,8(a4)
}
    5334:	60a2                	ld	ra,8(sp)
    5336:	6402                	ld	s0,0(sp)
    5338:	0141                	addi	sp,sp,16
    533a:	8082                	ret

000000000000533c <thread_schedule>:

void 
thread_schedule(void)
{
    533c:	1141                	addi	sp,sp,-16
    533e:	e406                	sd	ra,8(sp)
    5340:	e022                	sd	s0,0(sp)
    5342:	0800                	addi	s0,sp,16
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
    5344:	00003597          	auipc	a1,0x3
    5348:	1145b583          	ld	a1,276(a1) # 8458 <current_thread>
    534c:	6789                	lui	a5,0x2
    534e:	07c1                	addi	a5,a5,16 # 2010 <copyinstr3+0x44>
    5350:	97ae                	add	a5,a5,a1
    5352:	4711                	li	a4,4
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
    5354:	00012897          	auipc	a7,0x12
    5358:	97488893          	addi	a7,a7,-1676 # 16cc8 <all_thread+0x8040>
      t = all_thread;
    if(t->state == RUNNABLE) {
    535c:	6809                	lui	a6,0x2
    535e:	4509                	li	a0,2
      next_thread = t;
      break;
    }
    t = t + 1;
    5360:	01080613          	addi	a2,a6,16 # 2010 <copyinstr3+0x44>
    5364:	a809                	j	5376 <thread_schedule+0x3a>
    if(t->state == RUNNABLE) {
    5366:	010786b3          	add	a3,a5,a6
    536a:	4294                	lw	a3,0(a3)
    536c:	02a68563          	beq	a3,a0,5396 <thread_schedule+0x5a>
    t = t + 1;
    5370:	97b2                	add	a5,a5,a2
  for(int i = 0; i < MAX_THREAD; i++){
    5372:	377d                	addiw	a4,a4,-1
    5374:	cb01                	beqz	a4,5384 <thread_schedule+0x48>
    if(t >= all_thread + MAX_THREAD)
    5376:	ff17e8e3          	bltu	a5,a7,5366 <thread_schedule+0x2a>
      t = all_thread;
    537a:	0000a797          	auipc	a5,0xa
    537e:	90e78793          	addi	a5,a5,-1778 # ec88 <all_thread>
    5382:	b7d5                	j	5366 <thread_schedule+0x2a>
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
    5384:	00002517          	auipc	a0,0x2
    5388:	50450513          	addi	a0,a0,1284 # 7888 <thread_switch+0x2412>
    538c:	dcbff0ef          	jal	5156 <printf>
    exit(-1);
    5390:	557d                	li	a0,-1
    5392:	983ff0ef          	jal	4d14 <exit>
  }

  if (current_thread != next_thread) {         /* switch threads?  */
    5396:	02f58163          	beq	a1,a5,53b8 <thread_schedule+0x7c>
    next_thread->state = RUNNING;
    539a:	6689                	lui	a3,0x2
    539c:	00d78733          	add	a4,a5,a3
    53a0:	4605                	li	a2,1
    53a2:	c310                	sw	a2,0(a4)
    t = current_thread;
    current_thread = next_thread;
    53a4:	00003617          	auipc	a2,0x3
    53a8:	0af63a23          	sd	a5,180(a2) # 8458 <current_thread>
    thread_switch((uint64)t->context, (uint64)next_thread->context);
    53ac:	00d587b3          	add	a5,a1,a3
    53b0:	670c                	ld	a1,8(a4)
    53b2:	6788                	ld	a0,8(a5)
    53b4:	0c2000ef          	jal	5476 <thread_switch>
  } else
    next_thread = 0;
}
    53b8:	60a2                	ld	ra,8(sp)
    53ba:	6402                	ld	s0,0(sp)
    53bc:	0141                	addi	sp,sp,16
    53be:	8082                	ret

00000000000053c0 <thread_create>:

void 
thread_create(void (*func)())
{
    53c0:	1101                	addi	sp,sp,-32
    53c2:	ec06                	sd	ra,24(sp)
    53c4:	e822                	sd	s0,16(sp)
    53c6:	e426                	sd	s1,8(sp)
    53c8:	e04a                	sd	s2,0(sp)
    53ca:	1000                	addi	s0,sp,32
    53cc:	892a                	mv	s2,a0
  struct thread *t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
    53ce:	0000c797          	auipc	a5,0xc
    53d2:	8ca78793          	addi	a5,a5,-1846 # 10c98 <all_thread+0x2010>
    53d6:	00014597          	auipc	a1,0x14
    53da:	90258593          	addi	a1,a1,-1790 # 18cd8 <all_thread+0xa050>
    53de:	6609                	lui	a2,0x2
    53e0:	0641                	addi	a2,a2,16 # 2010 <copyinstr3+0x44>
    if (t->state == FREE) break;
    53e2:	873e                	mv	a4,a5
    53e4:	ff07a683          	lw	a3,-16(a5)
    53e8:	ce9d                	beqz	a3,5426 <thread_create+0x66>
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
    53ea:	97b2                	add	a5,a5,a2
    53ec:	feb79be3          	bne	a5,a1,53e2 <thread_create+0x22>
  }
  t->state = RUNNABLE;
    53f0:	6489                	lui	s1,0x2
    53f2:	94ba                	add	s1,s1,a4
    53f4:	4789                	li	a5,2
    53f6:	c09c                	sw	a5,0(s1)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
    53f8:	6789                	lui	a5,0x2
    53fa:	f9078793          	addi	a5,a5,-112 # 1f90 <manywrites+0xfe>
    53fe:	973e                	add	a4,a4,a5
  return (struct context *)(top & ~(uint64)0xf);
    5400:	ff077513          	andi	a0,a4,-16
  // A never-run thread has no saved state, so construct one: thread_switch()
  // restores ra and sp, and `ret` then starts func on this thread's own stack.
  t->context = thread_context_slot(t);
    5404:	e488                	sd	a0,8(s1)
  memset(t->context, 0, sizeof(struct context));
    5406:	07000613          	li	a2,112
    540a:	4581                	li	a1,0
    540c:	f0aff0ef          	jal	4b16 <memset>
  t->context->ra = (uint64)func;
    5410:	649c                	ld	a5,8(s1)
    5412:	0127b023          	sd	s2,0(a5)
  t->context->sp = (uint64)t->context;   // 16-byte aligned, grows down
    5416:	649c                	ld	a5,8(s1)
    5418:	e79c                	sd	a5,8(a5)
}
    541a:	60e2                	ld	ra,24(sp)
    541c:	6442                	ld	s0,16(sp)
    541e:	64a2                	ld	s1,8(sp)
    5420:	6902                	ld	s2,0(sp)
    5422:	6105                	addi	sp,sp,32
    5424:	8082                	ret
    5426:	7779                	lui	a4,0xffffe
    5428:	1741                	addi	a4,a4,-16 # ffffffffffffdff0 <all_thread+0xfffffffffffef368>
    542a:	973e                	add	a4,a4,a5
    542c:	b7d1                	j	53f0 <thread_create+0x30>

000000000000542e <thread_yield>:

void 
thread_yield(void)
{
    542e:	1141                	addi	sp,sp,-16
    5430:	e406                	sd	ra,8(sp)
    5432:	e022                	sd	s0,0(sp)
    5434:	0800                	addi	s0,sp,16
  current_thread->state = RUNNABLE;
    5436:	00003797          	auipc	a5,0x3
    543a:	0227b783          	ld	a5,34(a5) # 8458 <current_thread>
    543e:	6709                	lui	a4,0x2
    5440:	97ba                	add	a5,a5,a4
    5442:	4709                	li	a4,2
    5444:	c398                	sw	a4,0(a5)
  thread_schedule();
    5446:	ef7ff0ef          	jal	533c <thread_schedule>
}
    544a:	60a2                	ld	ra,8(sp)
    544c:	6402                	ld	s0,0(sp)
    544e:	0141                	addi	sp,sp,16
    5450:	8082                	ret

0000000000005452 <thread_exit>:

void thread_exit(void) {
    5452:	1141                	addi	sp,sp,-16
    5454:	e406                	sd	ra,8(sp)
    5456:	e022                	sd	s0,0(sp)
    5458:	0800                	addi	s0,sp,16
  current_thread->state = FREE;
    545a:	00003797          	auipc	a5,0x3
    545e:	ffe7b783          	ld	a5,-2(a5) # 8458 <current_thread>
    5462:	6709                	lui	a4,0x2
    5464:	97ba                	add	a5,a5,a4
    5466:	0007a023          	sw	zero,0(a5)
  thread_schedule();
    546a:	ed3ff0ef          	jal	533c <thread_schedule>
}
    546e:	60a2                	ld	ra,8(sp)
    5470:	6402                	ld	s0,0(sp)
    5472:	0141                	addi	sp,sp,16
    5474:	8082                	ret

0000000000005476 <thread_switch>:
    5476:	00153023          	sd	ra,0(a0)
    547a:	00253423          	sd	sp,8(a0)
    547e:	e900                	sd	s0,16(a0)
    5480:	ed04                	sd	s1,24(a0)
    5482:	03253023          	sd	s2,32(a0)
    5486:	03353423          	sd	s3,40(a0)
    548a:	03453823          	sd	s4,48(a0)
    548e:	03553c23          	sd	s5,56(a0)
    5492:	05653023          	sd	s6,64(a0)
    5496:	05753423          	sd	s7,72(a0)
    549a:	05853823          	sd	s8,80(a0)
    549e:	05953c23          	sd	s9,88(a0)
    54a2:	07a53023          	sd	s10,96(a0)
    54a6:	07b53423          	sd	s11,104(a0)
    54aa:	0005b083          	ld	ra,0(a1)
    54ae:	0085b103          	ld	sp,8(a1)
    54b2:	6980                	ld	s0,16(a1)
    54b4:	6d84                	ld	s1,24(a1)
    54b6:	0205b903          	ld	s2,32(a1)
    54ba:	0285b983          	ld	s3,40(a1)
    54be:	0305ba03          	ld	s4,48(a1)
    54c2:	0385ba83          	ld	s5,56(a1)
    54c6:	0405bb03          	ld	s6,64(a1)
    54ca:	0485bb83          	ld	s7,72(a1)
    54ce:	0505bc03          	ld	s8,80(a1)
    54d2:	0585bc83          	ld	s9,88(a1)
    54d6:	0605bd03          	ld	s10,96(a1)
    54da:	0685bd83          	ld	s11,104(a1)
    54de:	8082                	ret
