
user/_wc:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <wc>:

char buf[512];

void
wc(int fd, char *name)
{
   0:	7119                	addi	sp,sp,-128
   2:	fc86                	sd	ra,120(sp)
   4:	f8a2                	sd	s0,112(sp)
   6:	f4a6                	sd	s1,104(sp)
   8:	f0ca                	sd	s2,96(sp)
   a:	ecce                	sd	s3,88(sp)
   c:	e8d2                	sd	s4,80(sp)
   e:	e4d6                	sd	s5,72(sp)
  10:	e0da                	sd	s6,64(sp)
  12:	fc5e                	sd	s7,56(sp)
  14:	f862                	sd	s8,48(sp)
  16:	f466                	sd	s9,40(sp)
  18:	f06a                	sd	s10,32(sp)
  1a:	ec6e                	sd	s11,24(sp)
  1c:	0100                	addi	s0,sp,128
  1e:	f8a43423          	sd	a0,-120(s0)
  22:	f8b43023          	sd	a1,-128(s0)
  int i, n;
  int l, w, c, inword;

  l = w = c = 0;
  inword = 0;
  26:	4901                	li	s2,0
  l = w = c = 0;
  28:	4c81                	li	s9,0
  2a:	4c01                	li	s8,0
  2c:	4b81                	li	s7,0
  while((n = read(fd, buf, sizeof(buf))) > 0){
  2e:	20000d93          	li	s11,512
  32:	00001d17          	auipc	s10,0x1
  36:	fded0d13          	addi	s10,s10,-34 # 1010 <buf>
    for(i=0; i<n; i++){
      c++;
      if(buf[i] == '\n')
  3a:	4aa9                	li	s5,10
        l++;
      if(strchr(" \r\t\n\v", buf[i]))
  3c:	00001a17          	auipc	s4,0x1
  40:	b84a0a13          	addi	s4,s4,-1148 # bc0 <thread_switch+0x76>
  while((n = read(fd, buf, sizeof(buf))) > 0){
  44:	a035                	j	70 <wc+0x70>
      if(strchr(" \r\t\n\v", buf[i]))
  46:	8552                	mv	a0,s4
  48:	1c8000ef          	jal	210 <strchr>
  4c:	c919                	beqz	a0,62 <wc+0x62>
        inword = 0;
  4e:	4901                	li	s2,0
    for(i=0; i<n; i++){
  50:	0485                	addi	s1,s1,1
  52:	01348d63          	beq	s1,s3,6c <wc+0x6c>
      if(buf[i] == '\n')
  56:	0004c583          	lbu	a1,0(s1)
  5a:	ff5596e3          	bne	a1,s5,46 <wc+0x46>
        l++;
  5e:	2b85                	addiw	s7,s7,1
  60:	b7dd                	j	46 <wc+0x46>
      else if(!inword){
  62:	fe0917e3          	bnez	s2,50 <wc+0x50>
        w++;
  66:	2c05                	addiw	s8,s8,1
        inword = 1;
  68:	4905                	li	s2,1
  6a:	b7dd                	j	50 <wc+0x50>
  6c:	019b0cbb          	addw	s9,s6,s9
  while((n = read(fd, buf, sizeof(buf))) > 0){
  70:	866e                	mv	a2,s11
  72:	85ea                	mv	a1,s10
  74:	f8843503          	ld	a0,-120(s0)
  78:	388000ef          	jal	400 <read>
  7c:	8b2a                	mv	s6,a0
  7e:	00a05963          	blez	a0,90 <wc+0x90>
  82:	00001497          	auipc	s1,0x1
  86:	f8e48493          	addi	s1,s1,-114 # 1010 <buf>
  8a:	009b09b3          	add	s3,s6,s1
  8e:	b7e1                	j	56 <wc+0x56>
      }
    }
  }
  if(n < 0){
  90:	02054c63          	bltz	a0,c8 <wc+0xc8>
    printf("wc: read error\n");
    exit(1);
  }
  printf("%d %d %d %s\n", l, w, c, name);
  94:	f8043703          	ld	a4,-128(s0)
  98:	86e6                	mv	a3,s9
  9a:	8662                	mv	a2,s8
  9c:	85de                	mv	a1,s7
  9e:	00001517          	auipc	a0,0x1
  a2:	b4250513          	addi	a0,a0,-1214 # be0 <thread_switch+0x96>
  a6:	784000ef          	jal	82a <printf>
}
  aa:	70e6                	ld	ra,120(sp)
  ac:	7446                	ld	s0,112(sp)
  ae:	74a6                	ld	s1,104(sp)
  b0:	7906                	ld	s2,96(sp)
  b2:	69e6                	ld	s3,88(sp)
  b4:	6a46                	ld	s4,80(sp)
  b6:	6aa6                	ld	s5,72(sp)
  b8:	6b06                	ld	s6,64(sp)
  ba:	7be2                	ld	s7,56(sp)
  bc:	7c42                	ld	s8,48(sp)
  be:	7ca2                	ld	s9,40(sp)
  c0:	7d02                	ld	s10,32(sp)
  c2:	6de2                	ld	s11,24(sp)
  c4:	6109                	addi	sp,sp,128
  c6:	8082                	ret
    printf("wc: read error\n");
  c8:	00001517          	auipc	a0,0x1
  cc:	b0850513          	addi	a0,a0,-1272 # bd0 <thread_switch+0x86>
  d0:	75a000ef          	jal	82a <printf>
    exit(1);
  d4:	4505                	li	a0,1
  d6:	312000ef          	jal	3e8 <exit>

00000000000000da <main>:

int
main(int argc, char *argv[])
{
  da:	7179                	addi	sp,sp,-48
  dc:	f406                	sd	ra,40(sp)
  de:	f022                	sd	s0,32(sp)
  e0:	1800                	addi	s0,sp,48
  int fd, i;

  if(argc <= 1){
  e2:	4785                	li	a5,1
  e4:	04a7d463          	bge	a5,a0,12c <main+0x52>
  e8:	ec26                	sd	s1,24(sp)
  ea:	e84a                	sd	s2,16(sp)
  ec:	e44e                	sd	s3,8(sp)
  ee:	00858913          	addi	s2,a1,8
  f2:	ffe5099b          	addiw	s3,a0,-2
  f6:	02099793          	slli	a5,s3,0x20
  fa:	01d7d993          	srli	s3,a5,0x1d
  fe:	05c1                	addi	a1,a1,16
 100:	99ae                	add	s3,s3,a1
    wc(0, "");
    exit(0);
  }

  for(i = 1; i < argc; i++){
    if((fd = open(argv[i], O_RDONLY)) < 0){
 102:	4581                	li	a1,0
 104:	00093503          	ld	a0,0(s2)
 108:	320000ef          	jal	428 <open>
 10c:	84aa                	mv	s1,a0
 10e:	02054c63          	bltz	a0,146 <main+0x6c>
      printf("wc: cannot open %s\n", argv[i]);
      exit(1);
    }
    wc(fd, argv[i]);
 112:	00093583          	ld	a1,0(s2)
 116:	eebff0ef          	jal	0 <wc>
    close(fd);
 11a:	8526                	mv	a0,s1
 11c:	2f4000ef          	jal	410 <close>
  for(i = 1; i < argc; i++){
 120:	0921                	addi	s2,s2,8
 122:	ff3910e3          	bne	s2,s3,102 <main+0x28>
  }
  exit(0);
 126:	4501                	li	a0,0
 128:	2c0000ef          	jal	3e8 <exit>
 12c:	ec26                	sd	s1,24(sp)
 12e:	e84a                	sd	s2,16(sp)
 130:	e44e                	sd	s3,8(sp)
    wc(0, "");
 132:	00001597          	auipc	a1,0x1
 136:	a9658593          	addi	a1,a1,-1386 # bc8 <thread_switch+0x7e>
 13a:	4501                	li	a0,0
 13c:	ec5ff0ef          	jal	0 <wc>
    exit(0);
 140:	4501                	li	a0,0
 142:	2a6000ef          	jal	3e8 <exit>
      printf("wc: cannot open %s\n", argv[i]);
 146:	00093583          	ld	a1,0(s2)
 14a:	00001517          	auipc	a0,0x1
 14e:	aa650513          	addi	a0,a0,-1370 # bf0 <thread_switch+0xa6>
 152:	6d8000ef          	jal	82a <printf>
      exit(1);
 156:	4505                	li	a0,1
 158:	290000ef          	jal	3e8 <exit>

000000000000015c <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 15c:	1141                	addi	sp,sp,-16
 15e:	e406                	sd	ra,8(sp)
 160:	e022                	sd	s0,0(sp)
 162:	0800                	addi	s0,sp,16
  extern int main();
  main();
 164:	f77ff0ef          	jal	da <main>
  exit(0);
 168:	4501                	li	a0,0
 16a:	27e000ef          	jal	3e8 <exit>

000000000000016e <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 16e:	1141                	addi	sp,sp,-16
 170:	e406                	sd	ra,8(sp)
 172:	e022                	sd	s0,0(sp)
 174:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 176:	87aa                	mv	a5,a0
 178:	0585                	addi	a1,a1,1
 17a:	0785                	addi	a5,a5,1
 17c:	fff5c703          	lbu	a4,-1(a1)
 180:	fee78fa3          	sb	a4,-1(a5)
 184:	fb75                	bnez	a4,178 <strcpy+0xa>
    ;
  return os;
}
 186:	60a2                	ld	ra,8(sp)
 188:	6402                	ld	s0,0(sp)
 18a:	0141                	addi	sp,sp,16
 18c:	8082                	ret

000000000000018e <strcmp>:

int
strcmp(const char *p, const char *q)
{
 18e:	1141                	addi	sp,sp,-16
 190:	e406                	sd	ra,8(sp)
 192:	e022                	sd	s0,0(sp)
 194:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 196:	00054783          	lbu	a5,0(a0)
 19a:	cb91                	beqz	a5,1ae <strcmp+0x20>
 19c:	0005c703          	lbu	a4,0(a1)
 1a0:	00f71763          	bne	a4,a5,1ae <strcmp+0x20>
    p++, q++;
 1a4:	0505                	addi	a0,a0,1
 1a6:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 1a8:	00054783          	lbu	a5,0(a0)
 1ac:	fbe5                	bnez	a5,19c <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 1ae:	0005c503          	lbu	a0,0(a1)
}
 1b2:	40a7853b          	subw	a0,a5,a0
 1b6:	60a2                	ld	ra,8(sp)
 1b8:	6402                	ld	s0,0(sp)
 1ba:	0141                	addi	sp,sp,16
 1bc:	8082                	ret

00000000000001be <strlen>:

uint
strlen(const char *s)
{
 1be:	1141                	addi	sp,sp,-16
 1c0:	e406                	sd	ra,8(sp)
 1c2:	e022                	sd	s0,0(sp)
 1c4:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 1c6:	00054783          	lbu	a5,0(a0)
 1ca:	cf91                	beqz	a5,1e6 <strlen+0x28>
 1cc:	00150793          	addi	a5,a0,1
 1d0:	86be                	mv	a3,a5
 1d2:	0785                	addi	a5,a5,1
 1d4:	fff7c703          	lbu	a4,-1(a5)
 1d8:	ff65                	bnez	a4,1d0 <strlen+0x12>
 1da:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 1de:	60a2                	ld	ra,8(sp)
 1e0:	6402                	ld	s0,0(sp)
 1e2:	0141                	addi	sp,sp,16
 1e4:	8082                	ret
  for(n = 0; s[n]; n++)
 1e6:	4501                	li	a0,0
 1e8:	bfdd                	j	1de <strlen+0x20>

00000000000001ea <memset>:

void*
memset(void *dst, int c, uint n)
{
 1ea:	1141                	addi	sp,sp,-16
 1ec:	e406                	sd	ra,8(sp)
 1ee:	e022                	sd	s0,0(sp)
 1f0:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 1f2:	ca19                	beqz	a2,208 <memset+0x1e>
 1f4:	87aa                	mv	a5,a0
 1f6:	1602                	slli	a2,a2,0x20
 1f8:	9201                	srli	a2,a2,0x20
 1fa:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 1fe:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 202:	0785                	addi	a5,a5,1
 204:	fee79de3          	bne	a5,a4,1fe <memset+0x14>
  }
  return dst;
}
 208:	60a2                	ld	ra,8(sp)
 20a:	6402                	ld	s0,0(sp)
 20c:	0141                	addi	sp,sp,16
 20e:	8082                	ret

0000000000000210 <strchr>:

char*
strchr(const char *s, char c)
{
 210:	1141                	addi	sp,sp,-16
 212:	e406                	sd	ra,8(sp)
 214:	e022                	sd	s0,0(sp)
 216:	0800                	addi	s0,sp,16
  for(; *s; s++)
 218:	00054783          	lbu	a5,0(a0)
 21c:	c799                	beqz	a5,22a <strchr+0x1a>
    if(*s == c)
 21e:	00f58763          	beq	a1,a5,22c <strchr+0x1c>
  for(; *s; s++)
 222:	0505                	addi	a0,a0,1
 224:	00054783          	lbu	a5,0(a0)
 228:	fbfd                	bnez	a5,21e <strchr+0xe>
      return (char*)s;
  return 0;
 22a:	4501                	li	a0,0
}
 22c:	60a2                	ld	ra,8(sp)
 22e:	6402                	ld	s0,0(sp)
 230:	0141                	addi	sp,sp,16
 232:	8082                	ret

0000000000000234 <gets>:

char*
gets(char *buf, int max)
{
 234:	711d                	addi	sp,sp,-96
 236:	ec86                	sd	ra,88(sp)
 238:	e8a2                	sd	s0,80(sp)
 23a:	e4a6                	sd	s1,72(sp)
 23c:	e0ca                	sd	s2,64(sp)
 23e:	fc4e                	sd	s3,56(sp)
 240:	f852                	sd	s4,48(sp)
 242:	f456                	sd	s5,40(sp)
 244:	f05a                	sd	s6,32(sp)
 246:	ec5e                	sd	s7,24(sp)
 248:	e862                	sd	s8,16(sp)
 24a:	1080                	addi	s0,sp,96
 24c:	8baa                	mv	s7,a0
 24e:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 250:	892a                	mv	s2,a0
 252:	4481                	li	s1,0
    cc = read(0, &c, 1);
 254:	faf40b13          	addi	s6,s0,-81
 258:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 25a:	8c26                	mv	s8,s1
 25c:	0014899b          	addiw	s3,s1,1
 260:	84ce                	mv	s1,s3
 262:	0349d863          	bge	s3,s4,292 <gets+0x5e>
    cc = read(0, &c, 1);
 266:	8656                	mv	a2,s5
 268:	85da                	mv	a1,s6
 26a:	4501                	li	a0,0
 26c:	194000ef          	jal	400 <read>
    if(cc < 1)
 270:	02a05163          	blez	a0,292 <gets+0x5e>
      break;
    buf[i++] = c;
 274:	faf44783          	lbu	a5,-81(s0)
 278:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 27c:	0905                	addi	s2,s2,1
 27e:	ff678713          	addi	a4,a5,-10
 282:	00173713          	seqz	a4,a4
 286:	17cd                	addi	a5,a5,-13
 288:	0017b793          	seqz	a5,a5
 28c:	8fd9                	or	a5,a5,a4
 28e:	d7f1                	beqz	a5,25a <gets+0x26>
    buf[i++] = c;
 290:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 292:	9c5e                	add	s8,s8,s7
 294:	000c0023          	sb	zero,0(s8)
  return buf;
}
 298:	855e                	mv	a0,s7
 29a:	60e6                	ld	ra,88(sp)
 29c:	6446                	ld	s0,80(sp)
 29e:	64a6                	ld	s1,72(sp)
 2a0:	6906                	ld	s2,64(sp)
 2a2:	79e2                	ld	s3,56(sp)
 2a4:	7a42                	ld	s4,48(sp)
 2a6:	7aa2                	ld	s5,40(sp)
 2a8:	7b02                	ld	s6,32(sp)
 2aa:	6be2                	ld	s7,24(sp)
 2ac:	6c42                	ld	s8,16(sp)
 2ae:	6125                	addi	sp,sp,96
 2b0:	8082                	ret

00000000000002b2 <stat>:

int
stat(const char *n, struct stat *st)
{
 2b2:	1101                	addi	sp,sp,-32
 2b4:	ec06                	sd	ra,24(sp)
 2b6:	e822                	sd	s0,16(sp)
 2b8:	e04a                	sd	s2,0(sp)
 2ba:	1000                	addi	s0,sp,32
 2bc:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 2be:	4581                	li	a1,0
 2c0:	168000ef          	jal	428 <open>
  if(fd < 0)
 2c4:	02054263          	bltz	a0,2e8 <stat+0x36>
 2c8:	e426                	sd	s1,8(sp)
 2ca:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 2cc:	85ca                	mv	a1,s2
 2ce:	172000ef          	jal	440 <fstat>
 2d2:	892a                	mv	s2,a0
  close(fd);
 2d4:	8526                	mv	a0,s1
 2d6:	13a000ef          	jal	410 <close>
  return r;
 2da:	64a2                	ld	s1,8(sp)
}
 2dc:	854a                	mv	a0,s2
 2de:	60e2                	ld	ra,24(sp)
 2e0:	6442                	ld	s0,16(sp)
 2e2:	6902                	ld	s2,0(sp)
 2e4:	6105                	addi	sp,sp,32
 2e6:	8082                	ret
    return -1;
 2e8:	57fd                	li	a5,-1
 2ea:	893e                	mv	s2,a5
 2ec:	bfc5                	j	2dc <stat+0x2a>

00000000000002ee <atoi>:

int
atoi(const char *s)
{
 2ee:	1141                	addi	sp,sp,-16
 2f0:	e406                	sd	ra,8(sp)
 2f2:	e022                	sd	s0,0(sp)
 2f4:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 2f6:	00054683          	lbu	a3,0(a0)
 2fa:	fd06879b          	addiw	a5,a3,-48
 2fe:	0ff7f793          	zext.b	a5,a5
 302:	4625                	li	a2,9
 304:	02f66963          	bltu	a2,a5,336 <atoi+0x48>
 308:	872a                	mv	a4,a0
  n = 0;
 30a:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 30c:	0705                	addi	a4,a4,1
 30e:	0025179b          	slliw	a5,a0,0x2
 312:	9fa9                	addw	a5,a5,a0
 314:	0017979b          	slliw	a5,a5,0x1
 318:	9fb5                	addw	a5,a5,a3
 31a:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 31e:	00074683          	lbu	a3,0(a4)
 322:	fd06879b          	addiw	a5,a3,-48
 326:	0ff7f793          	zext.b	a5,a5
 32a:	fef671e3          	bgeu	a2,a5,30c <atoi+0x1e>
  return n;
}
 32e:	60a2                	ld	ra,8(sp)
 330:	6402                	ld	s0,0(sp)
 332:	0141                	addi	sp,sp,16
 334:	8082                	ret
  n = 0;
 336:	4501                	li	a0,0
 338:	bfdd                	j	32e <atoi+0x40>

000000000000033a <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 33a:	1141                	addi	sp,sp,-16
 33c:	e406                	sd	ra,8(sp)
 33e:	e022                	sd	s0,0(sp)
 340:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 342:	02b57563          	bgeu	a0,a1,36c <memmove+0x32>
    while(n-- > 0)
 346:	00c05f63          	blez	a2,364 <memmove+0x2a>
 34a:	1602                	slli	a2,a2,0x20
 34c:	9201                	srli	a2,a2,0x20
 34e:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 352:	872a                	mv	a4,a0
      *dst++ = *src++;
 354:	0585                	addi	a1,a1,1
 356:	0705                	addi	a4,a4,1
 358:	fff5c683          	lbu	a3,-1(a1)
 35c:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 360:	fee79ae3          	bne	a5,a4,354 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 364:	60a2                	ld	ra,8(sp)
 366:	6402                	ld	s0,0(sp)
 368:	0141                	addi	sp,sp,16
 36a:	8082                	ret
    while(n-- > 0)
 36c:	fec05ce3          	blez	a2,364 <memmove+0x2a>
    dst += n;
 370:	00c50733          	add	a4,a0,a2
    src += n;
 374:	95b2                	add	a1,a1,a2
 376:	fff6079b          	addiw	a5,a2,-1
 37a:	1782                	slli	a5,a5,0x20
 37c:	9381                	srli	a5,a5,0x20
 37e:	fff7c793          	not	a5,a5
 382:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 384:	15fd                	addi	a1,a1,-1
 386:	177d                	addi	a4,a4,-1
 388:	0005c683          	lbu	a3,0(a1)
 38c:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 390:	fef71ae3          	bne	a4,a5,384 <memmove+0x4a>
 394:	bfc1                	j	364 <memmove+0x2a>

0000000000000396 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 396:	1141                	addi	sp,sp,-16
 398:	e406                	sd	ra,8(sp)
 39a:	e022                	sd	s0,0(sp)
 39c:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 39e:	ce19                	beqz	a2,3bc <memcmp+0x26>
 3a0:	1602                	slli	a2,a2,0x20
 3a2:	9201                	srli	a2,a2,0x20
 3a4:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 3a8:	00054783          	lbu	a5,0(a0)
 3ac:	0005c703          	lbu	a4,0(a1)
 3b0:	00e79b63          	bne	a5,a4,3c6 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 3b4:	0505                	addi	a0,a0,1
    p2++;
 3b6:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 3b8:	fed518e3          	bne	a0,a3,3a8 <memcmp+0x12>
  }
  return 0;
 3bc:	4501                	li	a0,0
}
 3be:	60a2                	ld	ra,8(sp)
 3c0:	6402                	ld	s0,0(sp)
 3c2:	0141                	addi	sp,sp,16
 3c4:	8082                	ret
      return *p1 - *p2;
 3c6:	40e7853b          	subw	a0,a5,a4
 3ca:	bfd5                	j	3be <memcmp+0x28>

00000000000003cc <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 3cc:	1141                	addi	sp,sp,-16
 3ce:	e406                	sd	ra,8(sp)
 3d0:	e022                	sd	s0,0(sp)
 3d2:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 3d4:	f67ff0ef          	jal	33a <memmove>
}
 3d8:	60a2                	ld	ra,8(sp)
 3da:	6402                	ld	s0,0(sp)
 3dc:	0141                	addi	sp,sp,16
 3de:	8082                	ret

00000000000003e0 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 3e0:	4885                	li	a7,1
 ecall
 3e2:	00000073          	ecall
 ret
 3e6:	8082                	ret

00000000000003e8 <exit>:
.global exit
exit:
 li a7, SYS_exit
 3e8:	4889                	li	a7,2
 ecall
 3ea:	00000073          	ecall
 ret
 3ee:	8082                	ret

00000000000003f0 <wait>:
.global wait
wait:
 li a7, SYS_wait
 3f0:	488d                	li	a7,3
 ecall
 3f2:	00000073          	ecall
 ret
 3f6:	8082                	ret

00000000000003f8 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 3f8:	4891                	li	a7,4
 ecall
 3fa:	00000073          	ecall
 ret
 3fe:	8082                	ret

0000000000000400 <read>:
.global read
read:
 li a7, SYS_read
 400:	4895                	li	a7,5
 ecall
 402:	00000073          	ecall
 ret
 406:	8082                	ret

0000000000000408 <write>:
.global write
write:
 li a7, SYS_write
 408:	48c1                	li	a7,16
 ecall
 40a:	00000073          	ecall
 ret
 40e:	8082                	ret

0000000000000410 <close>:
.global close
close:
 li a7, SYS_close
 410:	48d5                	li	a7,21
 ecall
 412:	00000073          	ecall
 ret
 416:	8082                	ret

0000000000000418 <kill>:
.global kill
kill:
 li a7, SYS_kill
 418:	4899                	li	a7,6
 ecall
 41a:	00000073          	ecall
 ret
 41e:	8082                	ret

0000000000000420 <exec>:
.global exec
exec:
 li a7, SYS_exec
 420:	489d                	li	a7,7
 ecall
 422:	00000073          	ecall
 ret
 426:	8082                	ret

0000000000000428 <open>:
.global open
open:
 li a7, SYS_open
 428:	48bd                	li	a7,15
 ecall
 42a:	00000073          	ecall
 ret
 42e:	8082                	ret

0000000000000430 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 430:	48c5                	li	a7,17
 ecall
 432:	00000073          	ecall
 ret
 436:	8082                	ret

0000000000000438 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 438:	48c9                	li	a7,18
 ecall
 43a:	00000073          	ecall
 ret
 43e:	8082                	ret

0000000000000440 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 440:	48a1                	li	a7,8
 ecall
 442:	00000073          	ecall
 ret
 446:	8082                	ret

0000000000000448 <link>:
.global link
link:
 li a7, SYS_link
 448:	48cd                	li	a7,19
 ecall
 44a:	00000073          	ecall
 ret
 44e:	8082                	ret

0000000000000450 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 450:	48d1                	li	a7,20
 ecall
 452:	00000073          	ecall
 ret
 456:	8082                	ret

0000000000000458 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 458:	48a5                	li	a7,9
 ecall
 45a:	00000073          	ecall
 ret
 45e:	8082                	ret

0000000000000460 <dup>:
.global dup
dup:
 li a7, SYS_dup
 460:	48a9                	li	a7,10
 ecall
 462:	00000073          	ecall
 ret
 466:	8082                	ret

0000000000000468 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 468:	48ad                	li	a7,11
 ecall
 46a:	00000073          	ecall
 ret
 46e:	8082                	ret

0000000000000470 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 470:	48b1                	li	a7,12
 ecall
 472:	00000073          	ecall
 ret
 476:	8082                	ret

0000000000000478 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 478:	48b5                	li	a7,13
 ecall
 47a:	00000073          	ecall
 ret
 47e:	8082                	ret

0000000000000480 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 480:	48b9                	li	a7,14
 ecall
 482:	00000073          	ecall
 ret
 486:	8082                	ret

0000000000000488 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 488:	1101                	addi	sp,sp,-32
 48a:	ec06                	sd	ra,24(sp)
 48c:	e822                	sd	s0,16(sp)
 48e:	1000                	addi	s0,sp,32
 490:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 494:	4605                	li	a2,1
 496:	fef40593          	addi	a1,s0,-17
 49a:	f6fff0ef          	jal	408 <write>
}
 49e:	60e2                	ld	ra,24(sp)
 4a0:	6442                	ld	s0,16(sp)
 4a2:	6105                	addi	sp,sp,32
 4a4:	8082                	ret

00000000000004a6 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 4a6:	715d                	addi	sp,sp,-80
 4a8:	e486                	sd	ra,72(sp)
 4aa:	e0a2                	sd	s0,64(sp)
 4ac:	f84a                	sd	s2,48(sp)
 4ae:	f44e                	sd	s3,40(sp)
 4b0:	0880                	addi	s0,sp,80
 4b2:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 4b4:	00d036b3          	snez	a3,a3
 4b8:	03f5d793          	srli	a5,a1,0x3f
 4bc:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 4be:	0005871b          	sext.w	a4,a1
  neg = 0;
 4c2:	4301                	li	t1,0
  if(sgn && xx < 0){
 4c4:	c681                	beqz	a3,4cc <printint+0x26>
    x = -xx;
 4c6:	40b0073b          	negw	a4,a1
    neg = 1;
 4ca:	4305                	li	t1,1
  }

  i = 0;
 4cc:	fb840993          	addi	s3,s0,-72
  neg = 0;
 4d0:	85ce                	mv	a1,s3
  i = 0;
 4d2:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 4d4:	00000817          	auipc	a6,0x0
 4d8:	76480813          	addi	a6,a6,1892 # c38 <digits>
 4dc:	88b6                	mv	a7,a3
 4de:	0016851b          	addiw	a0,a3,1
 4e2:	86aa                	mv	a3,a0
 4e4:	02c777bb          	remuw	a5,a4,a2
 4e8:	1782                	slli	a5,a5,0x20
 4ea:	9381                	srli	a5,a5,0x20
 4ec:	97c2                	add	a5,a5,a6
 4ee:	0007c783          	lbu	a5,0(a5)
 4f2:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 4f6:	87ba                	mv	a5,a4
 4f8:	02c7573b          	divuw	a4,a4,a2
 4fc:	0585                	addi	a1,a1,1
 4fe:	fcc7ffe3          	bgeu	a5,a2,4dc <printint+0x36>
  if(neg)
 502:	00030b63          	beqz	t1,518 <printint+0x72>
    buf[i++] = '-';
 506:	fd040793          	addi	a5,s0,-48
 50a:	953e                	add	a0,a0,a5
 50c:	02d00793          	li	a5,45
 510:	fef50423          	sb	a5,-24(a0)
 514:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 518:	02d05563          	blez	a3,542 <printint+0x9c>
 51c:	fc26                	sd	s1,56(sp)
 51e:	36fd                	addiw	a3,a3,-1
 520:	00d984b3          	add	s1,s3,a3
 524:	19fd                	addi	s3,s3,-1
 526:	99b6                	add	s3,s3,a3
 528:	1682                	slli	a3,a3,0x20
 52a:	9281                	srli	a3,a3,0x20
 52c:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 530:	0004c583          	lbu	a1,0(s1)
 534:	854a                	mv	a0,s2
 536:	f53ff0ef          	jal	488 <putc>
  while(--i >= 0)
 53a:	14fd                	addi	s1,s1,-1
 53c:	ff349ae3          	bne	s1,s3,530 <printint+0x8a>
 540:	74e2                	ld	s1,56(sp)
}
 542:	60a6                	ld	ra,72(sp)
 544:	6406                	ld	s0,64(sp)
 546:	7942                	ld	s2,48(sp)
 548:	79a2                	ld	s3,40(sp)
 54a:	6161                	addi	sp,sp,80
 54c:	8082                	ret

000000000000054e <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 54e:	711d                	addi	sp,sp,-96
 550:	ec86                	sd	ra,88(sp)
 552:	e8a2                	sd	s0,80(sp)
 554:	e4a6                	sd	s1,72(sp)
 556:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 558:	0005c483          	lbu	s1,0(a1)
 55c:	28048263          	beqz	s1,7e0 <vprintf+0x292>
 560:	e0ca                	sd	s2,64(sp)
 562:	fc4e                	sd	s3,56(sp)
 564:	f852                	sd	s4,48(sp)
 566:	f456                	sd	s5,40(sp)
 568:	f05a                	sd	s6,32(sp)
 56a:	ec5e                	sd	s7,24(sp)
 56c:	e862                	sd	s8,16(sp)
 56e:	8b2a                	mv	s6,a0
 570:	8a2e                	mv	s4,a1
 572:	8bb2                	mv	s7,a2
  state = 0;
 574:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 576:	4901                	li	s2,0
 578:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 57a:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 57e:	06400c13          	li	s8,100
 582:	a00d                	j	5a4 <vprintf+0x56>
        putc(fd, c0);
 584:	85a6                	mv	a1,s1
 586:	855a                	mv	a0,s6
 588:	f01ff0ef          	jal	488 <putc>
 58c:	a019                	j	592 <vprintf+0x44>
    } else if(state == '%'){
 58e:	03598363          	beq	s3,s5,5b4 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 592:	0019079b          	addiw	a5,s2,1
 596:	893e                	mv	s2,a5
 598:	873e                	mv	a4,a5
 59a:	97d2                	add	a5,a5,s4
 59c:	0007c483          	lbu	s1,0(a5)
 5a0:	22048963          	beqz	s1,7d2 <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 5a4:	0004879b          	sext.w	a5,s1
    if(state == 0){
 5a8:	fe0993e3          	bnez	s3,58e <vprintf+0x40>
      if(c0 == '%'){
 5ac:	fd579ce3          	bne	a5,s5,584 <vprintf+0x36>
        state = '%';
 5b0:	89be                	mv	s3,a5
 5b2:	b7c5                	j	592 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 5b4:	00ea06b3          	add	a3,s4,a4
 5b8:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 5bc:	22060763          	beqz	a2,7ea <vprintf+0x29c>
      if(c0 == 'd'){
 5c0:	0b878363          	beq	a5,s8,666 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 5c4:	f9478693          	addi	a3,a5,-108
 5c8:	0016b693          	seqz	a3,a3
 5cc:	f9c60593          	addi	a1,a2,-100
 5d0:	0015b593          	seqz	a1,a1
 5d4:	8df5                	and	a1,a1,a3
 5d6:	e5c5                	bnez	a1,67e <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 5d8:	9752                	add	a4,a4,s4
 5da:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 5de:	f9460713          	addi	a4,a2,-108
 5e2:	00173713          	seqz	a4,a4
 5e6:	8f75                	and	a4,a4,a3
 5e8:	f9c50593          	addi	a1,a0,-100
 5ec:	0015b593          	seqz	a1,a1
 5f0:	8df9                	and	a1,a1,a4
 5f2:	e1dd                	bnez	a1,698 <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 5f4:	07500593          	li	a1,117
 5f8:	0ab78d63          	beq	a5,a1,6b2 <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 5fc:	f8b60593          	addi	a1,a2,-117
 600:	0015b593          	seqz	a1,a1
 604:	8df5                	and	a1,a1,a3
 606:	e1f1                	bnez	a1,6ca <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 608:	f8b50593          	addi	a1,a0,-117
 60c:	0015b593          	seqz	a1,a1
 610:	8df9                	and	a1,a1,a4
 612:	e9e9                	bnez	a1,6e4 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 614:	07800593          	li	a1,120
 618:	0eb78363          	beq	a5,a1,6fe <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 61c:	f8860613          	addi	a2,a2,-120
 620:	00163613          	seqz	a2,a2
 624:	8ef1                	and	a3,a3,a2
 626:	0e069863          	bnez	a3,716 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 62a:	f8850513          	addi	a0,a0,-120
 62e:	00153513          	seqz	a0,a0
 632:	8f69                	and	a4,a4,a0
 634:	0e071e63          	bnez	a4,730 <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 638:	07000713          	li	a4,112
 63c:	10e78663          	beq	a5,a4,748 <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 640:	07300713          	li	a4,115
 644:	14e78663          	beq	a5,a4,790 <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 648:	02500713          	li	a4,37
 64c:	16e78e63          	beq	a5,a4,7c8 <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 650:	02500593          	li	a1,37
 654:	855a                	mv	a0,s6
 656:	e33ff0ef          	jal	488 <putc>
        putc(fd, c0);
 65a:	85a6                	mv	a1,s1
 65c:	855a                	mv	a0,s6
 65e:	e2bff0ef          	jal	488 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 662:	4981                	li	s3,0
 664:	b73d                	j	592 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 666:	008b8493          	addi	s1,s7,8
 66a:	4685                	li	a3,1
 66c:	4629                	li	a2,10
 66e:	000ba583          	lw	a1,0(s7)
 672:	855a                	mv	a0,s6
 674:	e33ff0ef          	jal	4a6 <printint>
 678:	8ba6                	mv	s7,s1
      state = 0;
 67a:	4981                	li	s3,0
 67c:	bf19                	j	592 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 67e:	008b8493          	addi	s1,s7,8
 682:	4685                	li	a3,1
 684:	4629                	li	a2,10
 686:	000bb583          	ld	a1,0(s7)
 68a:	855a                	mv	a0,s6
 68c:	e1bff0ef          	jal	4a6 <printint>
        i += 1;
 690:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 692:	8ba6                	mv	s7,s1
      state = 0;
 694:	4981                	li	s3,0
 696:	bdf5                	j	592 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 698:	008b8493          	addi	s1,s7,8
 69c:	4685                	li	a3,1
 69e:	4629                	li	a2,10
 6a0:	000bb583          	ld	a1,0(s7)
 6a4:	855a                	mv	a0,s6
 6a6:	e01ff0ef          	jal	4a6 <printint>
        i += 2;
 6aa:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 6ac:	8ba6                	mv	s7,s1
      state = 0;
 6ae:	4981                	li	s3,0
        i += 2;
 6b0:	b5cd                	j	592 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 6b2:	008b8493          	addi	s1,s7,8
 6b6:	4681                	li	a3,0
 6b8:	4629                	li	a2,10
 6ba:	000ba583          	lw	a1,0(s7)
 6be:	855a                	mv	a0,s6
 6c0:	de7ff0ef          	jal	4a6 <printint>
 6c4:	8ba6                	mv	s7,s1
      state = 0;
 6c6:	4981                	li	s3,0
 6c8:	b5e9                	j	592 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 6ca:	008b8493          	addi	s1,s7,8
 6ce:	4681                	li	a3,0
 6d0:	4629                	li	a2,10
 6d2:	000bb583          	ld	a1,0(s7)
 6d6:	855a                	mv	a0,s6
 6d8:	dcfff0ef          	jal	4a6 <printint>
        i += 1;
 6dc:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 6de:	8ba6                	mv	s7,s1
      state = 0;
 6e0:	4981                	li	s3,0
 6e2:	bd45                	j	592 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 6e4:	008b8493          	addi	s1,s7,8
 6e8:	4681                	li	a3,0
 6ea:	4629                	li	a2,10
 6ec:	000bb583          	ld	a1,0(s7)
 6f0:	855a                	mv	a0,s6
 6f2:	db5ff0ef          	jal	4a6 <printint>
        i += 2;
 6f6:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 6f8:	8ba6                	mv	s7,s1
      state = 0;
 6fa:	4981                	li	s3,0
        i += 2;
 6fc:	bd59                	j	592 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 6fe:	008b8493          	addi	s1,s7,8
 702:	4681                	li	a3,0
 704:	4641                	li	a2,16
 706:	000ba583          	lw	a1,0(s7)
 70a:	855a                	mv	a0,s6
 70c:	d9bff0ef          	jal	4a6 <printint>
 710:	8ba6                	mv	s7,s1
      state = 0;
 712:	4981                	li	s3,0
 714:	bdbd                	j	592 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 716:	008b8493          	addi	s1,s7,8
 71a:	4681                	li	a3,0
 71c:	4641                	li	a2,16
 71e:	000bb583          	ld	a1,0(s7)
 722:	855a                	mv	a0,s6
 724:	d83ff0ef          	jal	4a6 <printint>
        i += 1;
 728:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 72a:	8ba6                	mv	s7,s1
      state = 0;
 72c:	4981                	li	s3,0
 72e:	b595                	j	592 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 730:	008b8493          	addi	s1,s7,8
 734:	4641                	li	a2,16
 736:	000bb583          	ld	a1,0(s7)
 73a:	855a                	mv	a0,s6
 73c:	d6bff0ef          	jal	4a6 <printint>
        i += 2;
 740:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 742:	8ba6                	mv	s7,s1
      state = 0;
 744:	4981                	li	s3,0
        i += 2;
 746:	b5b1                	j	592 <vprintf+0x44>
 748:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 74a:	008b8793          	addi	a5,s7,8
 74e:	8cbe                	mv	s9,a5
 750:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 754:	03000593          	li	a1,48
 758:	855a                	mv	a0,s6
 75a:	d2fff0ef          	jal	488 <putc>
  putc(fd, 'x');
 75e:	07800593          	li	a1,120
 762:	855a                	mv	a0,s6
 764:	d25ff0ef          	jal	488 <putc>
 768:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 76a:	00000b97          	auipc	s7,0x0
 76e:	4ceb8b93          	addi	s7,s7,1230 # c38 <digits>
 772:	03c9d793          	srli	a5,s3,0x3c
 776:	97de                	add	a5,a5,s7
 778:	0007c583          	lbu	a1,0(a5)
 77c:	855a                	mv	a0,s6
 77e:	d0bff0ef          	jal	488 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 782:	0992                	slli	s3,s3,0x4
 784:	34fd                	addiw	s1,s1,-1
 786:	f4f5                	bnez	s1,772 <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 788:	8be6                	mv	s7,s9
      state = 0;
 78a:	4981                	li	s3,0
 78c:	6ca2                	ld	s9,8(sp)
 78e:	b511                	j	592 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 790:	008b8993          	addi	s3,s7,8
 794:	000bb483          	ld	s1,0(s7)
 798:	cc91                	beqz	s1,7b4 <vprintf+0x266>
        for(; *s; s++)
 79a:	0004c583          	lbu	a1,0(s1)
 79e:	c195                	beqz	a1,7c2 <vprintf+0x274>
          putc(fd, *s);
 7a0:	855a                	mv	a0,s6
 7a2:	ce7ff0ef          	jal	488 <putc>
        for(; *s; s++)
 7a6:	0485                	addi	s1,s1,1
 7a8:	0004c583          	lbu	a1,0(s1)
 7ac:	f9f5                	bnez	a1,7a0 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 7ae:	8bce                	mv	s7,s3
      state = 0;
 7b0:	4981                	li	s3,0
 7b2:	b3c5                	j	592 <vprintf+0x44>
          s = "(null)";
 7b4:	00000497          	auipc	s1,0x0
 7b8:	45448493          	addi	s1,s1,1108 # c08 <thread_switch+0xbe>
        for(; *s; s++)
 7bc:	02800593          	li	a1,40
 7c0:	b7c5                	j	7a0 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 7c2:	8bce                	mv	s7,s3
      state = 0;
 7c4:	4981                	li	s3,0
 7c6:	b3f1                	j	592 <vprintf+0x44>
        putc(fd, '%');
 7c8:	85be                	mv	a1,a5
 7ca:	855a                	mv	a0,s6
 7cc:	cbdff0ef          	jal	488 <putc>
 7d0:	bd49                	j	662 <vprintf+0x114>
 7d2:	6906                	ld	s2,64(sp)
 7d4:	79e2                	ld	s3,56(sp)
 7d6:	7a42                	ld	s4,48(sp)
 7d8:	7aa2                	ld	s5,40(sp)
 7da:	7b02                	ld	s6,32(sp)
 7dc:	6be2                	ld	s7,24(sp)
 7de:	6c42                	ld	s8,16(sp)
    }
  }
}
 7e0:	60e6                	ld	ra,88(sp)
 7e2:	6446                	ld	s0,80(sp)
 7e4:	64a6                	ld	s1,72(sp)
 7e6:	6125                	addi	sp,sp,96
 7e8:	8082                	ret
      if(c0 == 'd'){
 7ea:	06400713          	li	a4,100
 7ee:	e6e78ce3          	beq	a5,a4,666 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 7f2:	f9478693          	addi	a3,a5,-108
 7f6:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 7fa:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 7fc:	4701                	li	a4,0
 7fe:	bbdd                	j	5f4 <vprintf+0xa6>

0000000000000800 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 800:	715d                	addi	sp,sp,-80
 802:	ec06                	sd	ra,24(sp)
 804:	e822                	sd	s0,16(sp)
 806:	1000                	addi	s0,sp,32
 808:	e010                	sd	a2,0(s0)
 80a:	e414                	sd	a3,8(s0)
 80c:	e818                	sd	a4,16(s0)
 80e:	ec1c                	sd	a5,24(s0)
 810:	03043023          	sd	a6,32(s0)
 814:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 818:	8622                	mv	a2,s0
 81a:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 81e:	d31ff0ef          	jal	54e <vprintf>
}
 822:	60e2                	ld	ra,24(sp)
 824:	6442                	ld	s0,16(sp)
 826:	6161                	addi	sp,sp,80
 828:	8082                	ret

000000000000082a <printf>:

void
printf(const char *fmt, ...)
{
 82a:	711d                	addi	sp,sp,-96
 82c:	ec06                	sd	ra,24(sp)
 82e:	e822                	sd	s0,16(sp)
 830:	1000                	addi	s0,sp,32
 832:	e40c                	sd	a1,8(s0)
 834:	e810                	sd	a2,16(s0)
 836:	ec14                	sd	a3,24(s0)
 838:	f018                	sd	a4,32(s0)
 83a:	f41c                	sd	a5,40(s0)
 83c:	03043823          	sd	a6,48(s0)
 840:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 844:	00840613          	addi	a2,s0,8
 848:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 84c:	85aa                	mv	a1,a0
 84e:	4505                	li	a0,1
 850:	cffff0ef          	jal	54e <vprintf>
}
 854:	60e2                	ld	ra,24(sp)
 856:	6442                	ld	s0,16(sp)
 858:	6125                	addi	sp,sp,96
 85a:	8082                	ret

000000000000085c <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 85c:	1141                	addi	sp,sp,-16
 85e:	e406                	sd	ra,8(sp)
 860:	e022                	sd	s0,0(sp)
 862:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 864:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 868:	00000797          	auipc	a5,0x0
 86c:	7987b783          	ld	a5,1944(a5) # 1000 <freep>
 870:	a095                	j	8d4 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 872:	ff852583          	lw	a1,-8(a0)
 876:	6390                	ld	a2,0(a5)
 878:	02059813          	slli	a6,a1,0x20
 87c:	01c85693          	srli	a3,a6,0x1c
 880:	96ba                	add	a3,a3,a4
 882:	02d60563          	beq	a2,a3,8ac <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 886:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 88a:	4790                	lw	a2,8(a5)
 88c:	02061593          	slli	a1,a2,0x20
 890:	01c5d693          	srli	a3,a1,0x1c
 894:	96be                	add	a3,a3,a5
 896:	02d70263          	beq	a4,a3,8ba <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 89a:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 89c:	00000717          	auipc	a4,0x0
 8a0:	76f73223          	sd	a5,1892(a4) # 1000 <freep>
}
 8a4:	60a2                	ld	ra,8(sp)
 8a6:	6402                	ld	s0,0(sp)
 8a8:	0141                	addi	sp,sp,16
 8aa:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 8ac:	4614                	lw	a3,8(a2)
 8ae:	9ead                	addw	a3,a3,a1
 8b0:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 8b4:	6394                	ld	a3,0(a5)
 8b6:	6290                	ld	a2,0(a3)
 8b8:	b7f9                	j	886 <free+0x2a>
    p->s.size += bp->s.size;
 8ba:	ff852703          	lw	a4,-8(a0)
 8be:	9f31                	addw	a4,a4,a2
 8c0:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 8c2:	ff053703          	ld	a4,-16(a0)
 8c6:	bfd1                	j	89a <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8c8:	6394                	ld	a3,0(a5)
 8ca:	00d7e463          	bltu	a5,a3,8d2 <free+0x76>
 8ce:	fad762e3          	bltu	a4,a3,872 <free+0x16>
 8d2:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8d4:	fee7fae3          	bgeu	a5,a4,8c8 <free+0x6c>
 8d8:	6394                	ld	a3,0(a5)
 8da:	f8d76ce3          	bltu	a4,a3,872 <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8de:	f8d7fae3          	bgeu	a5,a3,872 <free+0x16>
 8e2:	87b6                	mv	a5,a3
 8e4:	bfc5                	j	8d4 <free+0x78>

00000000000008e6 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 8e6:	7139                	addi	sp,sp,-64
 8e8:	fc06                	sd	ra,56(sp)
 8ea:	f822                	sd	s0,48(sp)
 8ec:	f04a                	sd	s2,32(sp)
 8ee:	ec4e                	sd	s3,24(sp)
 8f0:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 8f2:	02051993          	slli	s3,a0,0x20
 8f6:	0209d993          	srli	s3,s3,0x20
 8fa:	09bd                	addi	s3,s3,15
 8fc:	0049d993          	srli	s3,s3,0x4
 900:	2985                	addiw	s3,s3,1
 902:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 904:	00000517          	auipc	a0,0x0
 908:	6fc53503          	ld	a0,1788(a0) # 1000 <freep>
 90c:	c905                	beqz	a0,93c <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 90e:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 910:	4798                	lw	a4,8(a5)
 912:	09377663          	bgeu	a4,s3,99e <malloc+0xb8>
 916:	f426                	sd	s1,40(sp)
 918:	e852                	sd	s4,16(sp)
 91a:	e456                	sd	s5,8(sp)
 91c:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 91e:	8a4e                	mv	s4,s3
 920:	6705                	lui	a4,0x1
 922:	00e9f363          	bgeu	s3,a4,928 <malloc+0x42>
 926:	6a05                	lui	s4,0x1
 928:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 92c:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 930:	00000497          	auipc	s1,0x0
 934:	6d048493          	addi	s1,s1,1744 # 1000 <freep>
  if(p == (char*)-1)
 938:	5afd                	li	s5,-1
 93a:	a83d                	j	978 <malloc+0x92>
 93c:	f426                	sd	s1,40(sp)
 93e:	e852                	sd	s4,16(sp)
 940:	e456                	sd	s5,8(sp)
 942:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 944:	00001797          	auipc	a5,0x1
 948:	8cc78793          	addi	a5,a5,-1844 # 1210 <base>
 94c:	00000717          	auipc	a4,0x0
 950:	6af73a23          	sd	a5,1716(a4) # 1000 <freep>
 954:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 956:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 95a:	b7d1                	j	91e <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 95c:	6398                	ld	a4,0(a5)
 95e:	e118                	sd	a4,0(a0)
 960:	a899                	j	9b6 <malloc+0xd0>
  hp->s.size = nu;
 962:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 966:	0541                	addi	a0,a0,16
 968:	ef5ff0ef          	jal	85c <free>
  return freep;
 96c:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 96e:	c125                	beqz	a0,9ce <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 970:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 972:	4798                	lw	a4,8(a5)
 974:	03277163          	bgeu	a4,s2,996 <malloc+0xb0>
    if(p == freep)
 978:	6098                	ld	a4,0(s1)
 97a:	853e                	mv	a0,a5
 97c:	fef71ae3          	bne	a4,a5,970 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 980:	8552                	mv	a0,s4
 982:	aefff0ef          	jal	470 <sbrk>
  if(p == (char*)-1)
 986:	fd551ee3          	bne	a0,s5,962 <malloc+0x7c>
        return 0;
 98a:	4501                	li	a0,0
 98c:	74a2                	ld	s1,40(sp)
 98e:	6a42                	ld	s4,16(sp)
 990:	6aa2                	ld	s5,8(sp)
 992:	6b02                	ld	s6,0(sp)
 994:	a03d                	j	9c2 <malloc+0xdc>
 996:	74a2                	ld	s1,40(sp)
 998:	6a42                	ld	s4,16(sp)
 99a:	6aa2                	ld	s5,8(sp)
 99c:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 99e:	fae90fe3          	beq	s2,a4,95c <malloc+0x76>
        p->s.size -= nunits;
 9a2:	4137073b          	subw	a4,a4,s3
 9a6:	c798                	sw	a4,8(a5)
        p += p->s.size;
 9a8:	02071693          	slli	a3,a4,0x20
 9ac:	01c6d713          	srli	a4,a3,0x1c
 9b0:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 9b2:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 9b6:	00000717          	auipc	a4,0x0
 9ba:	64a73523          	sd	a0,1610(a4) # 1000 <freep>
      return (void*)(p + 1);
 9be:	01078513          	addi	a0,a5,16
  }
}
 9c2:	70e2                	ld	ra,56(sp)
 9c4:	7442                	ld	s0,48(sp)
 9c6:	7902                	ld	s2,32(sp)
 9c8:	69e2                	ld	s3,24(sp)
 9ca:	6121                	addi	sp,sp,64
 9cc:	8082                	ret
 9ce:	74a2                	ld	s1,40(sp)
 9d0:	6a42                	ld	s4,16(sp)
 9d2:	6aa2                	ld	s5,8(sp)
 9d4:	6b02                	ld	s6,0(sp)
 9d6:	b7f5                	j	9c2 <malloc+0xdc>

00000000000009d8 <thread_init>:
struct thread *current_thread;
extern void thread_switch(uint64, uint64);
              
void 
thread_init(void)
{
 9d8:	1141                	addi	sp,sp,-16
 9da:	e406                	sd	ra,8(sp)
 9dc:	e022                	sd	s0,0(sp)
 9de:	0800                	addi	s0,sp,16
  // main() is thread 0, which will make the first invocation to
  // thread_schedule(). It needs a stack so that the first thread_switch() can
  // save thread 0's state.
  current_thread = &all_thread[0];
 9e0:	00001797          	auipc	a5,0x1
 9e4:	84078793          	addi	a5,a5,-1984 # 1220 <all_thread>
 9e8:	00000717          	auipc	a4,0x0
 9ec:	62f73023          	sd	a5,1568(a4) # 1008 <current_thread>
  current_thread->state = RUNNING;
 9f0:	00003717          	auipc	a4,0x3
 9f4:	83070713          	addi	a4,a4,-2000 # 3220 <all_thread+0x2000>
 9f8:	4785                	li	a5,1
 9fa:	c31c                	sw	a5,0(a4)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 9fc:	00002797          	auipc	a5,0x2
 a00:	7b478793          	addi	a5,a5,1972 # 31b0 <all_thread+0x1f90>
  return (struct context *)(top & ~(uint64)0xf);
 a04:	9bc1                	andi	a5,a5,-16
  // Thread 0 runs on the process's own stack, but the first thread_switch()
  // still needs a writable place to save its context.
  current_thread->context = thread_context_slot(current_thread);
 a06:	e71c                	sd	a5,8(a4)
}
 a08:	60a2                	ld	ra,8(sp)
 a0a:	6402                	ld	s0,0(sp)
 a0c:	0141                	addi	sp,sp,16
 a0e:	8082                	ret

0000000000000a10 <thread_schedule>:

void 
thread_schedule(void)
{
 a10:	1141                	addi	sp,sp,-16
 a12:	e406                	sd	ra,8(sp)
 a14:	e022                	sd	s0,0(sp)
 a16:	0800                	addi	s0,sp,16
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
 a18:	00000597          	auipc	a1,0x0
 a1c:	5f05b583          	ld	a1,1520(a1) # 1008 <current_thread>
 a20:	6789                	lui	a5,0x2
 a22:	07c1                	addi	a5,a5,16 # 2010 <all_thread+0xdf0>
 a24:	97ae                	add	a5,a5,a1
 a26:	4711                	li	a4,4
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
 a28:	00009897          	auipc	a7,0x9
 a2c:	83888893          	addi	a7,a7,-1992 # 9260 <all_thread+0x8040>
      t = all_thread;
    if(t->state == RUNNABLE) {
 a30:	6809                	lui	a6,0x2
 a32:	4509                	li	a0,2
      next_thread = t;
      break;
    }
    t = t + 1;
 a34:	01080613          	addi	a2,a6,16 # 2010 <all_thread+0xdf0>
 a38:	a809                	j	a4a <thread_schedule+0x3a>
    if(t->state == RUNNABLE) {
 a3a:	010786b3          	add	a3,a5,a6
 a3e:	4294                	lw	a3,0(a3)
 a40:	02a68563          	beq	a3,a0,a6a <thread_schedule+0x5a>
    t = t + 1;
 a44:	97b2                	add	a5,a5,a2
  for(int i = 0; i < MAX_THREAD; i++){
 a46:	377d                	addiw	a4,a4,-1
 a48:	cb01                	beqz	a4,a58 <thread_schedule+0x48>
    if(t >= all_thread + MAX_THREAD)
 a4a:	ff17e8e3          	bltu	a5,a7,a3a <thread_schedule+0x2a>
      t = all_thread;
 a4e:	00000797          	auipc	a5,0x0
 a52:	7d278793          	addi	a5,a5,2002 # 1220 <all_thread>
 a56:	b7d5                	j	a3a <thread_schedule+0x2a>
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
 a58:	00000517          	auipc	a0,0x0
 a5c:	1b850513          	addi	a0,a0,440 # c10 <thread_switch+0xc6>
 a60:	dcbff0ef          	jal	82a <printf>
    exit(-1);
 a64:	557d                	li	a0,-1
 a66:	983ff0ef          	jal	3e8 <exit>
  }

  if (current_thread != next_thread) {         /* switch threads?  */
 a6a:	02f58163          	beq	a1,a5,a8c <thread_schedule+0x7c>
    next_thread->state = RUNNING;
 a6e:	6689                	lui	a3,0x2
 a70:	00d78733          	add	a4,a5,a3
 a74:	4605                	li	a2,1
 a76:	c310                	sw	a2,0(a4)
    t = current_thread;
    current_thread = next_thread;
 a78:	00000617          	auipc	a2,0x0
 a7c:	58f63823          	sd	a5,1424(a2) # 1008 <current_thread>
    thread_switch((uint64)t->context, (uint64)next_thread->context);
 a80:	00d587b3          	add	a5,a1,a3
 a84:	670c                	ld	a1,8(a4)
 a86:	6788                	ld	a0,8(a5)
 a88:	0c2000ef          	jal	b4a <thread_switch>
  } else
    next_thread = 0;
}
 a8c:	60a2                	ld	ra,8(sp)
 a8e:	6402                	ld	s0,0(sp)
 a90:	0141                	addi	sp,sp,16
 a92:	8082                	ret

0000000000000a94 <thread_create>:

void 
thread_create(void (*func)())
{
 a94:	1101                	addi	sp,sp,-32
 a96:	ec06                	sd	ra,24(sp)
 a98:	e822                	sd	s0,16(sp)
 a9a:	e426                	sd	s1,8(sp)
 a9c:	e04a                	sd	s2,0(sp)
 a9e:	1000                	addi	s0,sp,32
 aa0:	892a                	mv	s2,a0
  struct thread *t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 aa2:	00002797          	auipc	a5,0x2
 aa6:	78e78793          	addi	a5,a5,1934 # 3230 <all_thread+0x2010>
 aaa:	0000a597          	auipc	a1,0xa
 aae:	7c658593          	addi	a1,a1,1990 # b270 <all_thread+0xa050>
 ab2:	6609                	lui	a2,0x2
 ab4:	0641                	addi	a2,a2,16 # 2010 <all_thread+0xdf0>
    if (t->state == FREE) break;
 ab6:	873e                	mv	a4,a5
 ab8:	ff07a683          	lw	a3,-16(a5)
 abc:	ce9d                	beqz	a3,afa <thread_create+0x66>
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 abe:	97b2                	add	a5,a5,a2
 ac0:	feb79be3          	bne	a5,a1,ab6 <thread_create+0x22>
  }
  t->state = RUNNABLE;
 ac4:	6489                	lui	s1,0x2
 ac6:	94ba                	add	s1,s1,a4
 ac8:	4789                	li	a5,2
 aca:	c09c                	sw	a5,0(s1)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 acc:	6789                	lui	a5,0x2
 ace:	f9078793          	addi	a5,a5,-112 # 1f90 <all_thread+0xd70>
 ad2:	973e                	add	a4,a4,a5
  return (struct context *)(top & ~(uint64)0xf);
 ad4:	ff077513          	andi	a0,a4,-16
  // A never-run thread has no saved state, so construct one: thread_switch()
  // restores ra and sp, and `ret` then starts func on this thread's own stack.
  t->context = thread_context_slot(t);
 ad8:	e488                	sd	a0,8(s1)
  memset(t->context, 0, sizeof(struct context));
 ada:	07000613          	li	a2,112
 ade:	4581                	li	a1,0
 ae0:	f0aff0ef          	jal	1ea <memset>
  t->context->ra = (uint64)func;
 ae4:	649c                	ld	a5,8(s1)
 ae6:	0127b023          	sd	s2,0(a5)
  t->context->sp = (uint64)t->context;   // 16-byte aligned, grows down
 aea:	649c                	ld	a5,8(s1)
 aec:	e79c                	sd	a5,8(a5)
}
 aee:	60e2                	ld	ra,24(sp)
 af0:	6442                	ld	s0,16(sp)
 af2:	64a2                	ld	s1,8(sp)
 af4:	6902                	ld	s2,0(sp)
 af6:	6105                	addi	sp,sp,32
 af8:	8082                	ret
 afa:	7779                	lui	a4,0xffffe
 afc:	1741                	addi	a4,a4,-16 # ffffffffffffdff0 <all_thread+0xffffffffffffcdd0>
 afe:	973e                	add	a4,a4,a5
 b00:	b7d1                	j	ac4 <thread_create+0x30>

0000000000000b02 <thread_yield>:

void 
thread_yield(void)
{
 b02:	1141                	addi	sp,sp,-16
 b04:	e406                	sd	ra,8(sp)
 b06:	e022                	sd	s0,0(sp)
 b08:	0800                	addi	s0,sp,16
  current_thread->state = RUNNABLE;
 b0a:	00000797          	auipc	a5,0x0
 b0e:	4fe7b783          	ld	a5,1278(a5) # 1008 <current_thread>
 b12:	6709                	lui	a4,0x2
 b14:	97ba                	add	a5,a5,a4
 b16:	4709                	li	a4,2
 b18:	c398                	sw	a4,0(a5)
  thread_schedule();
 b1a:	ef7ff0ef          	jal	a10 <thread_schedule>
}
 b1e:	60a2                	ld	ra,8(sp)
 b20:	6402                	ld	s0,0(sp)
 b22:	0141                	addi	sp,sp,16
 b24:	8082                	ret

0000000000000b26 <thread_exit>:

void thread_exit(void) {
 b26:	1141                	addi	sp,sp,-16
 b28:	e406                	sd	ra,8(sp)
 b2a:	e022                	sd	s0,0(sp)
 b2c:	0800                	addi	s0,sp,16
  current_thread->state = FREE;
 b2e:	00000797          	auipc	a5,0x0
 b32:	4da7b783          	ld	a5,1242(a5) # 1008 <current_thread>
 b36:	6709                	lui	a4,0x2
 b38:	97ba                	add	a5,a5,a4
 b3a:	0007a023          	sw	zero,0(a5)
  thread_schedule();
 b3e:	ed3ff0ef          	jal	a10 <thread_schedule>
}
 b42:	60a2                	ld	ra,8(sp)
 b44:	6402                	ld	s0,0(sp)
 b46:	0141                	addi	sp,sp,16
 b48:	8082                	ret

0000000000000b4a <thread_switch>:
 b4a:	00153023          	sd	ra,0(a0)
 b4e:	00253423          	sd	sp,8(a0)
 b52:	e900                	sd	s0,16(a0)
 b54:	ed04                	sd	s1,24(a0)
 b56:	03253023          	sd	s2,32(a0)
 b5a:	03353423          	sd	s3,40(a0)
 b5e:	03453823          	sd	s4,48(a0)
 b62:	03553c23          	sd	s5,56(a0)
 b66:	05653023          	sd	s6,64(a0)
 b6a:	05753423          	sd	s7,72(a0)
 b6e:	05853823          	sd	s8,80(a0)
 b72:	05953c23          	sd	s9,88(a0)
 b76:	07a53023          	sd	s10,96(a0)
 b7a:	07b53423          	sd	s11,104(a0)
 b7e:	0005b083          	ld	ra,0(a1)
 b82:	0085b103          	ld	sp,8(a1)
 b86:	6980                	ld	s0,16(a1)
 b88:	6d84                	ld	s1,24(a1)
 b8a:	0205b903          	ld	s2,32(a1)
 b8e:	0285b983          	ld	s3,40(a1)
 b92:	0305ba03          	ld	s4,48(a1)
 b96:	0385ba83          	ld	s5,56(a1)
 b9a:	0405bb03          	ld	s6,64(a1)
 b9e:	0485bb83          	ld	s7,72(a1)
 ba2:	0505bc03          	ld	s8,80(a1)
 ba6:	0585bc83          	ld	s9,88(a1)
 baa:	0605bd03          	ld	s10,96(a1)
 bae:	0685bd83          	ld	s11,104(a1)
 bb2:	8082                	ret
