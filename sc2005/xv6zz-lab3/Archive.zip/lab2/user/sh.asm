
user/_sh:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <getcmd>:
  exit(0);
}

int
getcmd(char *buf, int nbuf)
{
       0:	1101                	addi	sp,sp,-32
       2:	ec06                	sd	ra,24(sp)
       4:	e822                	sd	s0,16(sp)
       6:	e426                	sd	s1,8(sp)
       8:	e04a                	sd	s2,0(sp)
       a:	1000                	addi	s0,sp,32
       c:	84aa                	mv	s1,a0
       e:	892e                	mv	s2,a1
  write(2, "$ ", 2);
      10:	4609                	li	a2,2
      12:	00001597          	auipc	a1,0x1
      16:	3fe58593          	addi	a1,a1,1022 # 1410 <thread_switch+0x76>
      1a:	8532                	mv	a0,a2
      1c:	43d000ef          	jal	c58 <write>
  memset(buf, 0, nbuf);
      20:	864a                	mv	a2,s2
      22:	4581                	li	a1,0
      24:	8526                	mv	a0,s1
      26:	215000ef          	jal	a3a <memset>
  gets(buf, nbuf);
      2a:	85ca                	mv	a1,s2
      2c:	8526                	mv	a0,s1
      2e:	257000ef          	jal	a84 <gets>
  if(buf[0] == 0) // EOF
      32:	0004c503          	lbu	a0,0(s1)
      36:	00153513          	seqz	a0,a0
    return -1;
  return 0;
}
      3a:	40a0053b          	negw	a0,a0
      3e:	60e2                	ld	ra,24(sp)
      40:	6442                	ld	s0,16(sp)
      42:	64a2                	ld	s1,8(sp)
      44:	6902                	ld	s2,0(sp)
      46:	6105                	addi	sp,sp,32
      48:	8082                	ret

000000000000004a <panic>:
  exit(0);
}

void
panic(char *s)
{
      4a:	1141                	addi	sp,sp,-16
      4c:	e406                	sd	ra,8(sp)
      4e:	e022                	sd	s0,0(sp)
      50:	0800                	addi	s0,sp,16
      52:	862a                	mv	a2,a0
  fprintf(2, "%s\n", s);
      54:	00001597          	auipc	a1,0x1
      58:	3cc58593          	addi	a1,a1,972 # 1420 <thread_switch+0x86>
      5c:	4509                	li	a0,2
      5e:	7f3000ef          	jal	1050 <fprintf>
  exit(1);
      62:	4505                	li	a0,1
      64:	3d5000ef          	jal	c38 <exit>

0000000000000068 <fork1>:
}

int
fork1(void)
{
      68:	1141                	addi	sp,sp,-16
      6a:	e406                	sd	ra,8(sp)
      6c:	e022                	sd	s0,0(sp)
      6e:	0800                	addi	s0,sp,16
  int pid;

  pid = fork();
      70:	3c1000ef          	jal	c30 <fork>
  if(pid == -1)
      74:	57fd                	li	a5,-1
      76:	00f50663          	beq	a0,a5,82 <fork1+0x1a>
    panic("fork");
  return pid;
}
      7a:	60a2                	ld	ra,8(sp)
      7c:	6402                	ld	s0,0(sp)
      7e:	0141                	addi	sp,sp,16
      80:	8082                	ret
    panic("fork");
      82:	00001517          	auipc	a0,0x1
      86:	3a650513          	addi	a0,a0,934 # 1428 <thread_switch+0x8e>
      8a:	fc1ff0ef          	jal	4a <panic>

000000000000008e <runcmd>:
{
      8e:	7179                	addi	sp,sp,-48
      90:	f406                	sd	ra,40(sp)
      92:	f022                	sd	s0,32(sp)
      94:	1800                	addi	s0,sp,48
  if(cmd == 0)
      96:	c115                	beqz	a0,ba <runcmd+0x2c>
      98:	ec26                	sd	s1,24(sp)
      9a:	84aa                	mv	s1,a0
  switch(cmd->type){
      9c:	4118                	lw	a4,0(a0)
      9e:	4795                	li	a5,5
      a0:	02e7e163          	bltu	a5,a4,c2 <runcmd+0x34>
      a4:	00056783          	lwu	a5,0(a0)
      a8:	078a                	slli	a5,a5,0x2
      aa:	00001717          	auipc	a4,0x1
      ae:	4a670713          	addi	a4,a4,1190 # 1550 <thread_switch+0x1b6>
      b2:	97ba                	add	a5,a5,a4
      b4:	439c                	lw	a5,0(a5)
      b6:	97ba                	add	a5,a5,a4
      b8:	8782                	jr	a5
      ba:	ec26                	sd	s1,24(sp)
    exit(1);
      bc:	4505                	li	a0,1
      be:	37b000ef          	jal	c38 <exit>
    panic("runcmd");
      c2:	00001517          	auipc	a0,0x1
      c6:	36e50513          	addi	a0,a0,878 # 1430 <thread_switch+0x96>
      ca:	f81ff0ef          	jal	4a <panic>
    if(ecmd->argv[0] == 0)
      ce:	6508                	ld	a0,8(a0)
      d0:	c105                	beqz	a0,f0 <runcmd+0x62>
    exec(ecmd->argv[0], ecmd->argv);
      d2:	00848593          	addi	a1,s1,8
      d6:	39b000ef          	jal	c70 <exec>
    fprintf(2, "exec %s failed\n", ecmd->argv[0]);
      da:	6490                	ld	a2,8(s1)
      dc:	00001597          	auipc	a1,0x1
      e0:	35c58593          	addi	a1,a1,860 # 1438 <thread_switch+0x9e>
      e4:	4509                	li	a0,2
      e6:	76b000ef          	jal	1050 <fprintf>
  exit(0);
      ea:	4501                	li	a0,0
      ec:	34d000ef          	jal	c38 <exit>
      exit(1);
      f0:	4505                	li	a0,1
      f2:	347000ef          	jal	c38 <exit>
    close(rcmd->fd);
      f6:	5148                	lw	a0,36(a0)
      f8:	369000ef          	jal	c60 <close>
    if(open(rcmd->file, rcmd->mode) < 0){
      fc:	508c                	lw	a1,32(s1)
      fe:	6888                	ld	a0,16(s1)
     100:	379000ef          	jal	c78 <open>
     104:	00054563          	bltz	a0,10e <runcmd+0x80>
    runcmd(rcmd->cmd);
     108:	6488                	ld	a0,8(s1)
     10a:	f85ff0ef          	jal	8e <runcmd>
      fprintf(2, "open %s failed\n", rcmd->file);
     10e:	6890                	ld	a2,16(s1)
     110:	00001597          	auipc	a1,0x1
     114:	33858593          	addi	a1,a1,824 # 1448 <thread_switch+0xae>
     118:	4509                	li	a0,2
     11a:	737000ef          	jal	1050 <fprintf>
      exit(1);
     11e:	4505                	li	a0,1
     120:	319000ef          	jal	c38 <exit>
    if(fork1() == 0)
     124:	f45ff0ef          	jal	68 <fork1>
     128:	e501                	bnez	a0,130 <runcmd+0xa2>
      runcmd(lcmd->left);
     12a:	6488                	ld	a0,8(s1)
     12c:	f63ff0ef          	jal	8e <runcmd>
    wait(0);
     130:	4501                	li	a0,0
     132:	30f000ef          	jal	c40 <wait>
    runcmd(lcmd->right);
     136:	6888                	ld	a0,16(s1)
     138:	f57ff0ef          	jal	8e <runcmd>
    if(pipe(p) < 0)
     13c:	fd840513          	addi	a0,s0,-40
     140:	309000ef          	jal	c48 <pipe>
     144:	02054763          	bltz	a0,172 <runcmd+0xe4>
    if(fork1() == 0){
     148:	f21ff0ef          	jal	68 <fork1>
     14c:	e90d                	bnez	a0,17e <runcmd+0xf0>
      close(1);
     14e:	4505                	li	a0,1
     150:	311000ef          	jal	c60 <close>
      dup(p[1]);
     154:	fdc42503          	lw	a0,-36(s0)
     158:	359000ef          	jal	cb0 <dup>
      close(p[0]);
     15c:	fd842503          	lw	a0,-40(s0)
     160:	301000ef          	jal	c60 <close>
      close(p[1]);
     164:	fdc42503          	lw	a0,-36(s0)
     168:	2f9000ef          	jal	c60 <close>
      runcmd(pcmd->left);
     16c:	6488                	ld	a0,8(s1)
     16e:	f21ff0ef          	jal	8e <runcmd>
      panic("pipe");
     172:	00001517          	auipc	a0,0x1
     176:	2e650513          	addi	a0,a0,742 # 1458 <thread_switch+0xbe>
     17a:	ed1ff0ef          	jal	4a <panic>
    if(fork1() == 0){
     17e:	eebff0ef          	jal	68 <fork1>
     182:	e115                	bnez	a0,1a6 <runcmd+0x118>
      close(0);
     184:	2dd000ef          	jal	c60 <close>
      dup(p[0]);
     188:	fd842503          	lw	a0,-40(s0)
     18c:	325000ef          	jal	cb0 <dup>
      close(p[0]);
     190:	fd842503          	lw	a0,-40(s0)
     194:	2cd000ef          	jal	c60 <close>
      close(p[1]);
     198:	fdc42503          	lw	a0,-36(s0)
     19c:	2c5000ef          	jal	c60 <close>
      runcmd(pcmd->right);
     1a0:	6888                	ld	a0,16(s1)
     1a2:	eedff0ef          	jal	8e <runcmd>
    close(p[0]);
     1a6:	fd842503          	lw	a0,-40(s0)
     1aa:	2b7000ef          	jal	c60 <close>
    close(p[1]);
     1ae:	fdc42503          	lw	a0,-36(s0)
     1b2:	2af000ef          	jal	c60 <close>
    wait(0);
     1b6:	4501                	li	a0,0
     1b8:	289000ef          	jal	c40 <wait>
    wait(0);
     1bc:	4501                	li	a0,0
     1be:	283000ef          	jal	c40 <wait>
    break;
     1c2:	b725                	j	ea <runcmd+0x5c>
    if(fork1() == 0)
     1c4:	ea5ff0ef          	jal	68 <fork1>
     1c8:	f20511e3          	bnez	a0,ea <runcmd+0x5c>
      runcmd(bcmd->cmd);
     1cc:	6488                	ld	a0,8(s1)
     1ce:	ec1ff0ef          	jal	8e <runcmd>

00000000000001d2 <execcmd>:
//PAGEBREAK!
// Constructors

struct cmd*
execcmd(void)
{
     1d2:	1101                	addi	sp,sp,-32
     1d4:	ec06                	sd	ra,24(sp)
     1d6:	e822                	sd	s0,16(sp)
     1d8:	e426                	sd	s1,8(sp)
     1da:	1000                	addi	s0,sp,32
  struct execcmd *cmd;

  cmd = malloc(sizeof(*cmd));
     1dc:	0a800513          	li	a0,168
     1e0:	757000ef          	jal	1136 <malloc>
     1e4:	84aa                	mv	s1,a0
  memset(cmd, 0, sizeof(*cmd));
     1e6:	0a800613          	li	a2,168
     1ea:	4581                	li	a1,0
     1ec:	04f000ef          	jal	a3a <memset>
  cmd->type = EXEC;
     1f0:	4785                	li	a5,1
     1f2:	c09c                	sw	a5,0(s1)
  return (struct cmd*)cmd;
}
     1f4:	8526                	mv	a0,s1
     1f6:	60e2                	ld	ra,24(sp)
     1f8:	6442                	ld	s0,16(sp)
     1fa:	64a2                	ld	s1,8(sp)
     1fc:	6105                	addi	sp,sp,32
     1fe:	8082                	ret

0000000000000200 <redircmd>:

struct cmd*
redircmd(struct cmd *subcmd, char *file, char *efile, int mode, int fd)
{
     200:	7139                	addi	sp,sp,-64
     202:	fc06                	sd	ra,56(sp)
     204:	f822                	sd	s0,48(sp)
     206:	f426                	sd	s1,40(sp)
     208:	f04a                	sd	s2,32(sp)
     20a:	ec4e                	sd	s3,24(sp)
     20c:	e852                	sd	s4,16(sp)
     20e:	e456                	sd	s5,8(sp)
     210:	e05a                	sd	s6,0(sp)
     212:	0080                	addi	s0,sp,64
     214:	892a                	mv	s2,a0
     216:	89ae                	mv	s3,a1
     218:	8a32                	mv	s4,a2
     21a:	8ab6                	mv	s5,a3
     21c:	8b3a                	mv	s6,a4
  struct redircmd *cmd;

  cmd = malloc(sizeof(*cmd));
     21e:	02800513          	li	a0,40
     222:	715000ef          	jal	1136 <malloc>
     226:	84aa                	mv	s1,a0
  memset(cmd, 0, sizeof(*cmd));
     228:	02800613          	li	a2,40
     22c:	4581                	li	a1,0
     22e:	00d000ef          	jal	a3a <memset>
  cmd->type = REDIR;
     232:	4789                	li	a5,2
     234:	c09c                	sw	a5,0(s1)
  cmd->cmd = subcmd;
     236:	0124b423          	sd	s2,8(s1)
  cmd->file = file;
     23a:	0134b823          	sd	s3,16(s1)
  cmd->efile = efile;
     23e:	0144bc23          	sd	s4,24(s1)
  cmd->mode = mode;
     242:	0354a023          	sw	s5,32(s1)
  cmd->fd = fd;
     246:	0364a223          	sw	s6,36(s1)
  return (struct cmd*)cmd;
}
     24a:	8526                	mv	a0,s1
     24c:	70e2                	ld	ra,56(sp)
     24e:	7442                	ld	s0,48(sp)
     250:	74a2                	ld	s1,40(sp)
     252:	7902                	ld	s2,32(sp)
     254:	69e2                	ld	s3,24(sp)
     256:	6a42                	ld	s4,16(sp)
     258:	6aa2                	ld	s5,8(sp)
     25a:	6b02                	ld	s6,0(sp)
     25c:	6121                	addi	sp,sp,64
     25e:	8082                	ret

0000000000000260 <pipecmd>:

struct cmd*
pipecmd(struct cmd *left, struct cmd *right)
{
     260:	7179                	addi	sp,sp,-48
     262:	f406                	sd	ra,40(sp)
     264:	f022                	sd	s0,32(sp)
     266:	ec26                	sd	s1,24(sp)
     268:	e84a                	sd	s2,16(sp)
     26a:	e44e                	sd	s3,8(sp)
     26c:	1800                	addi	s0,sp,48
     26e:	892a                	mv	s2,a0
     270:	89ae                	mv	s3,a1
  struct pipecmd *cmd;

  cmd = malloc(sizeof(*cmd));
     272:	4561                	li	a0,24
     274:	6c3000ef          	jal	1136 <malloc>
     278:	84aa                	mv	s1,a0
  memset(cmd, 0, sizeof(*cmd));
     27a:	4661                	li	a2,24
     27c:	4581                	li	a1,0
     27e:	7bc000ef          	jal	a3a <memset>
  cmd->type = PIPE;
     282:	478d                	li	a5,3
     284:	c09c                	sw	a5,0(s1)
  cmd->left = left;
     286:	0124b423          	sd	s2,8(s1)
  cmd->right = right;
     28a:	0134b823          	sd	s3,16(s1)
  return (struct cmd*)cmd;
}
     28e:	8526                	mv	a0,s1
     290:	70a2                	ld	ra,40(sp)
     292:	7402                	ld	s0,32(sp)
     294:	64e2                	ld	s1,24(sp)
     296:	6942                	ld	s2,16(sp)
     298:	69a2                	ld	s3,8(sp)
     29a:	6145                	addi	sp,sp,48
     29c:	8082                	ret

000000000000029e <listcmd>:

struct cmd*
listcmd(struct cmd *left, struct cmd *right)
{
     29e:	7179                	addi	sp,sp,-48
     2a0:	f406                	sd	ra,40(sp)
     2a2:	f022                	sd	s0,32(sp)
     2a4:	ec26                	sd	s1,24(sp)
     2a6:	e84a                	sd	s2,16(sp)
     2a8:	e44e                	sd	s3,8(sp)
     2aa:	1800                	addi	s0,sp,48
     2ac:	892a                	mv	s2,a0
     2ae:	89ae                	mv	s3,a1
  struct listcmd *cmd;

  cmd = malloc(sizeof(*cmd));
     2b0:	4561                	li	a0,24
     2b2:	685000ef          	jal	1136 <malloc>
     2b6:	84aa                	mv	s1,a0
  memset(cmd, 0, sizeof(*cmd));
     2b8:	4661                	li	a2,24
     2ba:	4581                	li	a1,0
     2bc:	77e000ef          	jal	a3a <memset>
  cmd->type = LIST;
     2c0:	4791                	li	a5,4
     2c2:	c09c                	sw	a5,0(s1)
  cmd->left = left;
     2c4:	0124b423          	sd	s2,8(s1)
  cmd->right = right;
     2c8:	0134b823          	sd	s3,16(s1)
  return (struct cmd*)cmd;
}
     2cc:	8526                	mv	a0,s1
     2ce:	70a2                	ld	ra,40(sp)
     2d0:	7402                	ld	s0,32(sp)
     2d2:	64e2                	ld	s1,24(sp)
     2d4:	6942                	ld	s2,16(sp)
     2d6:	69a2                	ld	s3,8(sp)
     2d8:	6145                	addi	sp,sp,48
     2da:	8082                	ret

00000000000002dc <backcmd>:

struct cmd*
backcmd(struct cmd *subcmd)
{
     2dc:	1101                	addi	sp,sp,-32
     2de:	ec06                	sd	ra,24(sp)
     2e0:	e822                	sd	s0,16(sp)
     2e2:	e426                	sd	s1,8(sp)
     2e4:	e04a                	sd	s2,0(sp)
     2e6:	1000                	addi	s0,sp,32
     2e8:	892a                	mv	s2,a0
  struct backcmd *cmd;

  cmd = malloc(sizeof(*cmd));
     2ea:	4541                	li	a0,16
     2ec:	64b000ef          	jal	1136 <malloc>
     2f0:	84aa                	mv	s1,a0
  memset(cmd, 0, sizeof(*cmd));
     2f2:	4641                	li	a2,16
     2f4:	4581                	li	a1,0
     2f6:	744000ef          	jal	a3a <memset>
  cmd->type = BACK;
     2fa:	4795                	li	a5,5
     2fc:	c09c                	sw	a5,0(s1)
  cmd->cmd = subcmd;
     2fe:	0124b423          	sd	s2,8(s1)
  return (struct cmd*)cmd;
}
     302:	8526                	mv	a0,s1
     304:	60e2                	ld	ra,24(sp)
     306:	6442                	ld	s0,16(sp)
     308:	64a2                	ld	s1,8(sp)
     30a:	6902                	ld	s2,0(sp)
     30c:	6105                	addi	sp,sp,32
     30e:	8082                	ret

0000000000000310 <gettoken>:
char whitespace[] = " \t\r\n\v";
char symbols[] = "<|>&;()";

int
gettoken(char **ps, char *es, char **q, char **eq)
{
     310:	7139                	addi	sp,sp,-64
     312:	fc06                	sd	ra,56(sp)
     314:	f822                	sd	s0,48(sp)
     316:	f426                	sd	s1,40(sp)
     318:	f04a                	sd	s2,32(sp)
     31a:	ec4e                	sd	s3,24(sp)
     31c:	e852                	sd	s4,16(sp)
     31e:	e456                	sd	s5,8(sp)
     320:	e05a                	sd	s6,0(sp)
     322:	0080                	addi	s0,sp,64
     324:	8a2a                	mv	s4,a0
     326:	892e                	mv	s2,a1
     328:	8ab2                	mv	s5,a2
     32a:	8b36                	mv	s6,a3
  char *s;
  int ret;

  s = *ps;
     32c:	6104                	ld	s1,0(a0)
  while(s < es && strchr(whitespace, *s))
     32e:	00002997          	auipc	s3,0x2
     332:	cda98993          	addi	s3,s3,-806 # 2008 <whitespace>
     336:	00b4fc63          	bgeu	s1,a1,34e <gettoken+0x3e>
     33a:	0004c583          	lbu	a1,0(s1)
     33e:	854e                	mv	a0,s3
     340:	720000ef          	jal	a60 <strchr>
     344:	c509                	beqz	a0,34e <gettoken+0x3e>
    s++;
     346:	0485                	addi	s1,s1,1
  while(s < es && strchr(whitespace, *s))
     348:	fe9919e3          	bne	s2,s1,33a <gettoken+0x2a>
     34c:	84ca                	mv	s1,s2
  if(q)
     34e:	000a8463          	beqz	s5,356 <gettoken+0x46>
    *q = s;
     352:	009ab023          	sd	s1,0(s5)
  ret = *s;
     356:	0004c783          	lbu	a5,0(s1)
     35a:	00078a9b          	sext.w	s5,a5
  switch(*s){
     35e:	03c00713          	li	a4,60
     362:	08f76e63          	bltu	a4,a5,3fe <gettoken+0xee>
     366:	02500713          	li	a4,37
     36a:	04f76363          	bltu	a4,a5,3b0 <gettoken+0xa0>
     36e:	eba9                	bnez	a5,3c0 <gettoken+0xb0>
    ret = 'a';
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
      s++;
    break;
  }
  if(eq)
     370:	000b0463          	beqz	s6,378 <gettoken+0x68>
    *eq = s;
     374:	009b3023          	sd	s1,0(s6)

  while(s < es && strchr(whitespace, *s))
     378:	0124ff63          	bgeu	s1,s2,396 <gettoken+0x86>
     37c:	00002997          	auipc	s3,0x2
     380:	c8c98993          	addi	s3,s3,-884 # 2008 <whitespace>
     384:	0004c583          	lbu	a1,0(s1)
     388:	854e                	mv	a0,s3
     38a:	6d6000ef          	jal	a60 <strchr>
     38e:	c501                	beqz	a0,396 <gettoken+0x86>
    s++;
     390:	0485                	addi	s1,s1,1
  while(s < es && strchr(whitespace, *s))
     392:	fe9919e3          	bne	s2,s1,384 <gettoken+0x74>
  *ps = s;
     396:	009a3023          	sd	s1,0(s4)
  return ret;
}
     39a:	8556                	mv	a0,s5
     39c:	70e2                	ld	ra,56(sp)
     39e:	7442                	ld	s0,48(sp)
     3a0:	74a2                	ld	s1,40(sp)
     3a2:	7902                	ld	s2,32(sp)
     3a4:	69e2                	ld	s3,24(sp)
     3a6:	6a42                	ld	s4,16(sp)
     3a8:	6aa2                	ld	s5,8(sp)
     3aa:	6b02                	ld	s6,0(sp)
     3ac:	6121                	addi	sp,sp,64
     3ae:	8082                	ret
  switch(*s){
     3b0:	00600737          	lui	a4,0x600
     3b4:	0735                	addi	a4,a4,13 # 60000d <all_thread+0x5fdf75>
     3b6:	171a                	slli	a4,a4,0x26
     3b8:	00f757b3          	srl	a5,a4,a5
     3bc:	8b85                	andi	a5,a5,1
     3be:	e3ad                	bnez	a5,420 <gettoken+0x110>
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
     3c0:	00002997          	auipc	s3,0x2
     3c4:	c4898993          	addi	s3,s3,-952 # 2008 <whitespace>
     3c8:	00002a97          	auipc	s5,0x2
     3cc:	c38a8a93          	addi	s5,s5,-968 # 2000 <symbols>
     3d0:	0724f163          	bgeu	s1,s2,432 <gettoken+0x122>
     3d4:	0004c583          	lbu	a1,0(s1)
     3d8:	854e                	mv	a0,s3
     3da:	686000ef          	jal	a60 <strchr>
     3de:	e539                	bnez	a0,42c <gettoken+0x11c>
     3e0:	0004c583          	lbu	a1,0(s1)
     3e4:	8556                	mv	a0,s5
     3e6:	67a000ef          	jal	a60 <strchr>
     3ea:	e129                	bnez	a0,42c <gettoken+0x11c>
      s++;
     3ec:	0485                	addi	s1,s1,1
    while(s < es && !strchr(whitespace, *s) && !strchr(symbols, *s))
     3ee:	fe9913e3          	bne	s2,s1,3d4 <gettoken+0xc4>
  if(eq)
     3f2:	84ca                	mv	s1,s2
    ret = 'a';
     3f4:	06100a93          	li	s5,97
  if(eq)
     3f8:	f60b1ee3          	bnez	s6,374 <gettoken+0x64>
     3fc:	bf69                	j	396 <gettoken+0x86>
  switch(*s){
     3fe:	03e00713          	li	a4,62
     402:	00e79b63          	bne	a5,a4,418 <gettoken+0x108>
    if(*s == '>'){
     406:	0014c703          	lbu	a4,1(s1)
     40a:	03e00793          	li	a5,62
     40e:	00f70b63          	beq	a4,a5,424 <gettoken+0x114>
    s++;
     412:	0485                	addi	s1,s1,1
  ret = *s;
     414:	8abe                	mv	s5,a5
     416:	bfa9                	j	370 <gettoken+0x60>
  switch(*s){
     418:	07c00713          	li	a4,124
     41c:	fae792e3          	bne	a5,a4,3c0 <gettoken+0xb0>
    s++;
     420:	0485                	addi	s1,s1,1
    break;
     422:	b7b9                	j	370 <gettoken+0x60>
      s++;
     424:	0489                	addi	s1,s1,2
      ret = '+';
     426:	02b00a93          	li	s5,43
     42a:	b799                	j	370 <gettoken+0x60>
    ret = 'a';
     42c:	06100a93          	li	s5,97
     430:	b781                	j	370 <gettoken+0x60>
     432:	06100a93          	li	s5,97
  if(eq)
     436:	f20b1fe3          	bnez	s6,374 <gettoken+0x64>
     43a:	bfb1                	j	396 <gettoken+0x86>

000000000000043c <peek>:

int
peek(char **ps, char *es, char *toks)
{
     43c:	7139                	addi	sp,sp,-64
     43e:	fc06                	sd	ra,56(sp)
     440:	f822                	sd	s0,48(sp)
     442:	f426                	sd	s1,40(sp)
     444:	f04a                	sd	s2,32(sp)
     446:	ec4e                	sd	s3,24(sp)
     448:	e852                	sd	s4,16(sp)
     44a:	e456                	sd	s5,8(sp)
     44c:	0080                	addi	s0,sp,64
     44e:	8a2a                	mv	s4,a0
     450:	892e                	mv	s2,a1
     452:	8ab2                	mv	s5,a2
  char *s;

  s = *ps;
     454:	6104                	ld	s1,0(a0)
  while(s < es && strchr(whitespace, *s))
     456:	00002997          	auipc	s3,0x2
     45a:	bb298993          	addi	s3,s3,-1102 # 2008 <whitespace>
     45e:	00b4fc63          	bgeu	s1,a1,476 <peek+0x3a>
     462:	0004c583          	lbu	a1,0(s1)
     466:	854e                	mv	a0,s3
     468:	5f8000ef          	jal	a60 <strchr>
     46c:	c509                	beqz	a0,476 <peek+0x3a>
    s++;
     46e:	0485                	addi	s1,s1,1
  while(s < es && strchr(whitespace, *s))
     470:	fe9919e3          	bne	s2,s1,462 <peek+0x26>
     474:	84ca                	mv	s1,s2
  *ps = s;
     476:	009a3023          	sd	s1,0(s4)
  return *s && strchr(toks, *s);
     47a:	0004c583          	lbu	a1,0(s1)
     47e:	4501                	li	a0,0
     480:	e991                	bnez	a1,494 <peek+0x58>
}
     482:	70e2                	ld	ra,56(sp)
     484:	7442                	ld	s0,48(sp)
     486:	74a2                	ld	s1,40(sp)
     488:	7902                	ld	s2,32(sp)
     48a:	69e2                	ld	s3,24(sp)
     48c:	6a42                	ld	s4,16(sp)
     48e:	6aa2                	ld	s5,8(sp)
     490:	6121                	addi	sp,sp,64
     492:	8082                	ret
  return *s && strchr(toks, *s);
     494:	8556                	mv	a0,s5
     496:	5ca000ef          	jal	a60 <strchr>
     49a:	00a03533          	snez	a0,a0
     49e:	b7d5                	j	482 <peek+0x46>

00000000000004a0 <parseredirs>:
  return cmd;
}

struct cmd*
parseredirs(struct cmd *cmd, char **ps, char *es)
{
     4a0:	7159                	addi	sp,sp,-112
     4a2:	f486                	sd	ra,104(sp)
     4a4:	f0a2                	sd	s0,96(sp)
     4a6:	eca6                	sd	s1,88(sp)
     4a8:	e8ca                	sd	s2,80(sp)
     4aa:	e4ce                	sd	s3,72(sp)
     4ac:	e0d2                	sd	s4,64(sp)
     4ae:	fc56                	sd	s5,56(sp)
     4b0:	f85a                	sd	s6,48(sp)
     4b2:	f45e                	sd	s7,40(sp)
     4b4:	f062                	sd	s8,32(sp)
     4b6:	ec66                	sd	s9,24(sp)
     4b8:	1880                	addi	s0,sp,112
     4ba:	8a2a                	mv	s4,a0
     4bc:	89ae                	mv	s3,a1
     4be:	8932                	mv	s2,a2
  int tok;
  char *q, *eq;

  while(peek(ps, es, "<>")){
     4c0:	00001b17          	auipc	s6,0x1
     4c4:	fc0b0b13          	addi	s6,s6,-64 # 1480 <thread_switch+0xe6>
    tok = gettoken(ps, es, 0, 0);
    if(gettoken(ps, es, &q, &eq) != 'a')
     4c8:	f9040c93          	addi	s9,s0,-112
     4cc:	f9840c13          	addi	s8,s0,-104
     4d0:	06100b93          	li	s7,97
  while(peek(ps, es, "<>")){
     4d4:	a889                	j	526 <parseredirs+0x86>
      panic("missing file for redirection");
     4d6:	00001517          	auipc	a0,0x1
     4da:	f8a50513          	addi	a0,a0,-118 # 1460 <thread_switch+0xc6>
     4de:	b6dff0ef          	jal	4a <panic>
    switch(tok){
    case '<':
      cmd = redircmd(cmd, q, eq, O_RDONLY, 0);
     4e2:	4701                	li	a4,0
     4e4:	4681                	li	a3,0
     4e6:	f9043603          	ld	a2,-112(s0)
     4ea:	f9843583          	ld	a1,-104(s0)
     4ee:	8552                	mv	a0,s4
     4f0:	d11ff0ef          	jal	200 <redircmd>
     4f4:	8a2a                	mv	s4,a0
      break;
     4f6:	a805                	j	526 <parseredirs+0x86>
    case '>':
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE|O_TRUNC, 1);
     4f8:	4705                	li	a4,1
     4fa:	60100693          	li	a3,1537
     4fe:	f9043603          	ld	a2,-112(s0)
     502:	f9843583          	ld	a1,-104(s0)
     506:	8552                	mv	a0,s4
     508:	cf9ff0ef          	jal	200 <redircmd>
     50c:	8a2a                	mv	s4,a0
      break;
     50e:	a821                	j	526 <parseredirs+0x86>
    case '+':  // >>
      cmd = redircmd(cmd, q, eq, O_WRONLY|O_CREATE, 1);
     510:	4705                	li	a4,1
     512:	20100693          	li	a3,513
     516:	f9043603          	ld	a2,-112(s0)
     51a:	f9843583          	ld	a1,-104(s0)
     51e:	8552                	mv	a0,s4
     520:	ce1ff0ef          	jal	200 <redircmd>
     524:	8a2a                	mv	s4,a0
    switch(tok){
     526:	03c00a93          	li	s5,60
  while(peek(ps, es, "<>")){
     52a:	865a                	mv	a2,s6
     52c:	85ca                	mv	a1,s2
     52e:	854e                	mv	a0,s3
     530:	f0dff0ef          	jal	43c <peek>
     534:	c91d                	beqz	a0,56a <parseredirs+0xca>
    tok = gettoken(ps, es, 0, 0);
     536:	4681                	li	a3,0
     538:	4601                	li	a2,0
     53a:	85ca                	mv	a1,s2
     53c:	854e                	mv	a0,s3
     53e:	dd3ff0ef          	jal	310 <gettoken>
     542:	84aa                	mv	s1,a0
    if(gettoken(ps, es, &q, &eq) != 'a')
     544:	86e6                	mv	a3,s9
     546:	8662                	mv	a2,s8
     548:	85ca                	mv	a1,s2
     54a:	854e                	mv	a0,s3
     54c:	dc5ff0ef          	jal	310 <gettoken>
     550:	f97513e3          	bne	a0,s7,4d6 <parseredirs+0x36>
    switch(tok){
     554:	f95487e3          	beq	s1,s5,4e2 <parseredirs+0x42>
     558:	03e00793          	li	a5,62
     55c:	f8f48ee3          	beq	s1,a5,4f8 <parseredirs+0x58>
     560:	02b00793          	li	a5,43
     564:	faf486e3          	beq	s1,a5,510 <parseredirs+0x70>
     568:	b7c9                	j	52a <parseredirs+0x8a>
      break;
    }
  }
  return cmd;
}
     56a:	8552                	mv	a0,s4
     56c:	70a6                	ld	ra,104(sp)
     56e:	7406                	ld	s0,96(sp)
     570:	64e6                	ld	s1,88(sp)
     572:	6946                	ld	s2,80(sp)
     574:	69a6                	ld	s3,72(sp)
     576:	6a06                	ld	s4,64(sp)
     578:	7ae2                	ld	s5,56(sp)
     57a:	7b42                	ld	s6,48(sp)
     57c:	7ba2                	ld	s7,40(sp)
     57e:	7c02                	ld	s8,32(sp)
     580:	6ce2                	ld	s9,24(sp)
     582:	6165                	addi	sp,sp,112
     584:	8082                	ret

0000000000000586 <parseexec>:
  return cmd;
}

struct cmd*
parseexec(char **ps, char *es)
{
     586:	7119                	addi	sp,sp,-128
     588:	fc86                	sd	ra,120(sp)
     58a:	f8a2                	sd	s0,112(sp)
     58c:	f4a6                	sd	s1,104(sp)
     58e:	e8d2                	sd	s4,80(sp)
     590:	e4d6                	sd	s5,72(sp)
     592:	0100                	addi	s0,sp,128
     594:	8a2a                	mv	s4,a0
     596:	8aae                	mv	s5,a1
  char *q, *eq;
  int tok, argc;
  struct execcmd *cmd;
  struct cmd *ret;

  if(peek(ps, es, "("))
     598:	00001617          	auipc	a2,0x1
     59c:	ef060613          	addi	a2,a2,-272 # 1488 <thread_switch+0xee>
     5a0:	e9dff0ef          	jal	43c <peek>
     5a4:	e121                	bnez	a0,5e4 <parseexec+0x5e>
     5a6:	f0ca                	sd	s2,96(sp)
     5a8:	ecce                	sd	s3,88(sp)
     5aa:	e0da                	sd	s6,64(sp)
     5ac:	fc5e                	sd	s7,56(sp)
     5ae:	f862                	sd	s8,48(sp)
     5b0:	f466                	sd	s9,40(sp)
     5b2:	f06a                	sd	s10,32(sp)
     5b4:	ec6e                	sd	s11,24(sp)
     5b6:	892a                	mv	s2,a0
    return parseblock(ps, es);

  ret = execcmd();
     5b8:	c1bff0ef          	jal	1d2 <execcmd>
     5bc:	89aa                	mv	s3,a0
     5be:	8daa                	mv	s11,a0
  cmd = (struct execcmd*)ret;

  argc = 0;
  ret = parseredirs(ret, ps, es);
     5c0:	8656                	mv	a2,s5
     5c2:	85d2                	mv	a1,s4
     5c4:	eddff0ef          	jal	4a0 <parseredirs>
     5c8:	84aa                	mv	s1,a0
  while(!peek(ps, es, "|)&;")){
     5ca:	09a1                	addi	s3,s3,8
     5cc:	00001b17          	auipc	s6,0x1
     5d0:	edcb0b13          	addi	s6,s6,-292 # 14a8 <thread_switch+0x10e>
    if((tok=gettoken(ps, es, &q, &eq)) == 0)
     5d4:	f8040c13          	addi	s8,s0,-128
     5d8:	f8840b93          	addi	s7,s0,-120
      break;
    if(tok != 'a')
     5dc:	06100d13          	li	s10,97
      panic("syntax");
    cmd->argv[argc] = q;
    cmd->eargv[argc] = eq;
    argc++;
    if(argc >= MAXARGS)
     5e0:	4ca9                	li	s9,10
  while(!peek(ps, es, "|)&;")){
     5e2:	a81d                	j	618 <parseexec+0x92>
    return parseblock(ps, es);
     5e4:	85d6                	mv	a1,s5
     5e6:	8552                	mv	a0,s4
     5e8:	178000ef          	jal	760 <parseblock>
     5ec:	84aa                	mv	s1,a0
    ret = parseredirs(ret, ps, es);
  }
  cmd->argv[argc] = 0;
  cmd->eargv[argc] = 0;
  return ret;
}
     5ee:	8526                	mv	a0,s1
     5f0:	70e6                	ld	ra,120(sp)
     5f2:	7446                	ld	s0,112(sp)
     5f4:	74a6                	ld	s1,104(sp)
     5f6:	6a46                	ld	s4,80(sp)
     5f8:	6aa6                	ld	s5,72(sp)
     5fa:	6109                	addi	sp,sp,128
     5fc:	8082                	ret
      panic("syntax");
     5fe:	00001517          	auipc	a0,0x1
     602:	e9250513          	addi	a0,a0,-366 # 1490 <thread_switch+0xf6>
     606:	a45ff0ef          	jal	4a <panic>
    if(argc >= MAXARGS)
     60a:	09a1                	addi	s3,s3,8
    ret = parseredirs(ret, ps, es);
     60c:	8656                	mv	a2,s5
     60e:	85d2                	mv	a1,s4
     610:	8526                	mv	a0,s1
     612:	e8fff0ef          	jal	4a0 <parseredirs>
     616:	84aa                	mv	s1,a0
  while(!peek(ps, es, "|)&;")){
     618:	865a                	mv	a2,s6
     61a:	85d6                	mv	a1,s5
     61c:	8552                	mv	a0,s4
     61e:	e1fff0ef          	jal	43c <peek>
     622:	e91d                	bnez	a0,658 <parseexec+0xd2>
    if((tok=gettoken(ps, es, &q, &eq)) == 0)
     624:	86e2                	mv	a3,s8
     626:	865e                	mv	a2,s7
     628:	85d6                	mv	a1,s5
     62a:	8552                	mv	a0,s4
     62c:	ce5ff0ef          	jal	310 <gettoken>
     630:	c505                	beqz	a0,658 <parseexec+0xd2>
    if(tok != 'a')
     632:	fda516e3          	bne	a0,s10,5fe <parseexec+0x78>
    cmd->argv[argc] = q;
     636:	f8843783          	ld	a5,-120(s0)
     63a:	00f9b023          	sd	a5,0(s3)
    cmd->eargv[argc] = eq;
     63e:	f8043783          	ld	a5,-128(s0)
     642:	04f9b823          	sd	a5,80(s3)
    argc++;
     646:	2905                	addiw	s2,s2,1
    if(argc >= MAXARGS)
     648:	fd9911e3          	bne	s2,s9,60a <parseexec+0x84>
      panic("too many args");
     64c:	00001517          	auipc	a0,0x1
     650:	e4c50513          	addi	a0,a0,-436 # 1498 <thread_switch+0xfe>
     654:	9f7ff0ef          	jal	4a <panic>
  cmd->argv[argc] = 0;
     658:	090e                	slli	s2,s2,0x3
     65a:	012d87b3          	add	a5,s11,s2
     65e:	0007b423          	sd	zero,8(a5)
  cmd->eargv[argc] = 0;
     662:	0407bc23          	sd	zero,88(a5)
     666:	7906                	ld	s2,96(sp)
     668:	69e6                	ld	s3,88(sp)
     66a:	6b06                	ld	s6,64(sp)
     66c:	7be2                	ld	s7,56(sp)
     66e:	7c42                	ld	s8,48(sp)
     670:	7ca2                	ld	s9,40(sp)
     672:	7d02                	ld	s10,32(sp)
     674:	6de2                	ld	s11,24(sp)
  return ret;
     676:	bfa5                	j	5ee <parseexec+0x68>

0000000000000678 <parsepipe>:
{
     678:	7179                	addi	sp,sp,-48
     67a:	f406                	sd	ra,40(sp)
     67c:	f022                	sd	s0,32(sp)
     67e:	ec26                	sd	s1,24(sp)
     680:	e84a                	sd	s2,16(sp)
     682:	e44e                	sd	s3,8(sp)
     684:	e052                	sd	s4,0(sp)
     686:	1800                	addi	s0,sp,48
     688:	892a                	mv	s2,a0
     68a:	8a2a                	mv	s4,a0
     68c:	84ae                	mv	s1,a1
  cmd = parseexec(ps, es);
     68e:	ef9ff0ef          	jal	586 <parseexec>
     692:	89aa                	mv	s3,a0
  if(peek(ps, es, "|")){
     694:	00001617          	auipc	a2,0x1
     698:	e1c60613          	addi	a2,a2,-484 # 14b0 <thread_switch+0x116>
     69c:	85a6                	mv	a1,s1
     69e:	854a                	mv	a0,s2
     6a0:	d9dff0ef          	jal	43c <peek>
     6a4:	e911                	bnez	a0,6b8 <parsepipe+0x40>
}
     6a6:	854e                	mv	a0,s3
     6a8:	70a2                	ld	ra,40(sp)
     6aa:	7402                	ld	s0,32(sp)
     6ac:	64e2                	ld	s1,24(sp)
     6ae:	6942                	ld	s2,16(sp)
     6b0:	69a2                	ld	s3,8(sp)
     6b2:	6a02                	ld	s4,0(sp)
     6b4:	6145                	addi	sp,sp,48
     6b6:	8082                	ret
    gettoken(ps, es, 0, 0);
     6b8:	4681                	li	a3,0
     6ba:	4601                	li	a2,0
     6bc:	85a6                	mv	a1,s1
     6be:	8552                	mv	a0,s4
     6c0:	c51ff0ef          	jal	310 <gettoken>
    cmd = pipecmd(cmd, parsepipe(ps, es));
     6c4:	85a6                	mv	a1,s1
     6c6:	8552                	mv	a0,s4
     6c8:	fb1ff0ef          	jal	678 <parsepipe>
     6cc:	85aa                	mv	a1,a0
     6ce:	854e                	mv	a0,s3
     6d0:	b91ff0ef          	jal	260 <pipecmd>
     6d4:	89aa                	mv	s3,a0
  return cmd;
     6d6:	bfc1                	j	6a6 <parsepipe+0x2e>

00000000000006d8 <parseline>:
{
     6d8:	7179                	addi	sp,sp,-48
     6da:	f406                	sd	ra,40(sp)
     6dc:	f022                	sd	s0,32(sp)
     6de:	ec26                	sd	s1,24(sp)
     6e0:	e84a                	sd	s2,16(sp)
     6e2:	e44e                	sd	s3,8(sp)
     6e4:	e052                	sd	s4,0(sp)
     6e6:	1800                	addi	s0,sp,48
     6e8:	892a                	mv	s2,a0
     6ea:	89ae                	mv	s3,a1
  cmd = parsepipe(ps, es);
     6ec:	f8dff0ef          	jal	678 <parsepipe>
     6f0:	84aa                	mv	s1,a0
  while(peek(ps, es, "&")){
     6f2:	00001a17          	auipc	s4,0x1
     6f6:	dc6a0a13          	addi	s4,s4,-570 # 14b8 <thread_switch+0x11e>
     6fa:	a819                	j	710 <parseline+0x38>
    gettoken(ps, es, 0, 0);
     6fc:	4681                	li	a3,0
     6fe:	4601                	li	a2,0
     700:	85ce                	mv	a1,s3
     702:	854a                	mv	a0,s2
     704:	c0dff0ef          	jal	310 <gettoken>
    cmd = backcmd(cmd);
     708:	8526                	mv	a0,s1
     70a:	bd3ff0ef          	jal	2dc <backcmd>
     70e:	84aa                	mv	s1,a0
  while(peek(ps, es, "&")){
     710:	8652                	mv	a2,s4
     712:	85ce                	mv	a1,s3
     714:	854a                	mv	a0,s2
     716:	d27ff0ef          	jal	43c <peek>
     71a:	f16d                	bnez	a0,6fc <parseline+0x24>
  if(peek(ps, es, ";")){
     71c:	00001617          	auipc	a2,0x1
     720:	da460613          	addi	a2,a2,-604 # 14c0 <thread_switch+0x126>
     724:	85ce                	mv	a1,s3
     726:	854a                	mv	a0,s2
     728:	d15ff0ef          	jal	43c <peek>
     72c:	e911                	bnez	a0,740 <parseline+0x68>
}
     72e:	8526                	mv	a0,s1
     730:	70a2                	ld	ra,40(sp)
     732:	7402                	ld	s0,32(sp)
     734:	64e2                	ld	s1,24(sp)
     736:	6942                	ld	s2,16(sp)
     738:	69a2                	ld	s3,8(sp)
     73a:	6a02                	ld	s4,0(sp)
     73c:	6145                	addi	sp,sp,48
     73e:	8082                	ret
    gettoken(ps, es, 0, 0);
     740:	4681                	li	a3,0
     742:	4601                	li	a2,0
     744:	85ce                	mv	a1,s3
     746:	854a                	mv	a0,s2
     748:	bc9ff0ef          	jal	310 <gettoken>
    cmd = listcmd(cmd, parseline(ps, es));
     74c:	85ce                	mv	a1,s3
     74e:	854a                	mv	a0,s2
     750:	f89ff0ef          	jal	6d8 <parseline>
     754:	85aa                	mv	a1,a0
     756:	8526                	mv	a0,s1
     758:	b47ff0ef          	jal	29e <listcmd>
     75c:	84aa                	mv	s1,a0
  return cmd;
     75e:	bfc1                	j	72e <parseline+0x56>

0000000000000760 <parseblock>:
{
     760:	7179                	addi	sp,sp,-48
     762:	f406                	sd	ra,40(sp)
     764:	f022                	sd	s0,32(sp)
     766:	ec26                	sd	s1,24(sp)
     768:	e84a                	sd	s2,16(sp)
     76a:	e44e                	sd	s3,8(sp)
     76c:	1800                	addi	s0,sp,48
     76e:	84aa                	mv	s1,a0
     770:	892e                	mv	s2,a1
  if(!peek(ps, es, "("))
     772:	00001617          	auipc	a2,0x1
     776:	d1660613          	addi	a2,a2,-746 # 1488 <thread_switch+0xee>
     77a:	cc3ff0ef          	jal	43c <peek>
     77e:	c539                	beqz	a0,7cc <parseblock+0x6c>
  gettoken(ps, es, 0, 0);
     780:	4681                	li	a3,0
     782:	4601                	li	a2,0
     784:	85ca                	mv	a1,s2
     786:	8526                	mv	a0,s1
     788:	b89ff0ef          	jal	310 <gettoken>
  cmd = parseline(ps, es);
     78c:	85ca                	mv	a1,s2
     78e:	8526                	mv	a0,s1
     790:	f49ff0ef          	jal	6d8 <parseline>
     794:	89aa                	mv	s3,a0
  if(!peek(ps, es, ")"))
     796:	00001617          	auipc	a2,0x1
     79a:	d4260613          	addi	a2,a2,-702 # 14d8 <thread_switch+0x13e>
     79e:	85ca                	mv	a1,s2
     7a0:	8526                	mv	a0,s1
     7a2:	c9bff0ef          	jal	43c <peek>
     7a6:	c90d                	beqz	a0,7d8 <parseblock+0x78>
  gettoken(ps, es, 0, 0);
     7a8:	4681                	li	a3,0
     7aa:	4601                	li	a2,0
     7ac:	85ca                	mv	a1,s2
     7ae:	8526                	mv	a0,s1
     7b0:	b61ff0ef          	jal	310 <gettoken>
  cmd = parseredirs(cmd, ps, es);
     7b4:	864a                	mv	a2,s2
     7b6:	85a6                	mv	a1,s1
     7b8:	854e                	mv	a0,s3
     7ba:	ce7ff0ef          	jal	4a0 <parseredirs>
}
     7be:	70a2                	ld	ra,40(sp)
     7c0:	7402                	ld	s0,32(sp)
     7c2:	64e2                	ld	s1,24(sp)
     7c4:	6942                	ld	s2,16(sp)
     7c6:	69a2                	ld	s3,8(sp)
     7c8:	6145                	addi	sp,sp,48
     7ca:	8082                	ret
    panic("parseblock");
     7cc:	00001517          	auipc	a0,0x1
     7d0:	cfc50513          	addi	a0,a0,-772 # 14c8 <thread_switch+0x12e>
     7d4:	877ff0ef          	jal	4a <panic>
    panic("syntax - missing )");
     7d8:	00001517          	auipc	a0,0x1
     7dc:	d0850513          	addi	a0,a0,-760 # 14e0 <thread_switch+0x146>
     7e0:	86bff0ef          	jal	4a <panic>

00000000000007e4 <nulterminate>:

// NUL-terminate all the counted strings.
struct cmd*
nulterminate(struct cmd *cmd)
{
     7e4:	1101                	addi	sp,sp,-32
     7e6:	ec06                	sd	ra,24(sp)
     7e8:	e822                	sd	s0,16(sp)
     7ea:	e426                	sd	s1,8(sp)
     7ec:	1000                	addi	s0,sp,32
     7ee:	84aa                	mv	s1,a0
  struct execcmd *ecmd;
  struct listcmd *lcmd;
  struct pipecmd *pcmd;
  struct redircmd *rcmd;

  if(cmd == 0)
     7f0:	c131                	beqz	a0,834 <nulterminate+0x50>
    return 0;

  switch(cmd->type){
     7f2:	4118                	lw	a4,0(a0)
     7f4:	4795                	li	a5,5
     7f6:	02e7ef63          	bltu	a5,a4,834 <nulterminate+0x50>
     7fa:	00056783          	lwu	a5,0(a0)
     7fe:	078a                	slli	a5,a5,0x2
     800:	00001717          	auipc	a4,0x1
     804:	d6870713          	addi	a4,a4,-664 # 1568 <thread_switch+0x1ce>
     808:	97ba                	add	a5,a5,a4
     80a:	439c                	lw	a5,0(a5)
     80c:	97ba                	add	a5,a5,a4
     80e:	8782                	jr	a5
  case EXEC:
    ecmd = (struct execcmd*)cmd;
    for(i=0; ecmd->argv[i]; i++)
     810:	651c                	ld	a5,8(a0)
     812:	c38d                	beqz	a5,834 <nulterminate+0x50>
     814:	01050793          	addi	a5,a0,16
      *ecmd->eargv[i] = 0;
     818:	67b8                	ld	a4,72(a5)
     81a:	00070023          	sb	zero,0(a4)
    for(i=0; ecmd->argv[i]; i++)
     81e:	07a1                	addi	a5,a5,8
     820:	ff87b703          	ld	a4,-8(a5)
     824:	fb75                	bnez	a4,818 <nulterminate+0x34>
     826:	a039                	j	834 <nulterminate+0x50>
    break;

  case REDIR:
    rcmd = (struct redircmd*)cmd;
    nulterminate(rcmd->cmd);
     828:	6508                	ld	a0,8(a0)
     82a:	fbbff0ef          	jal	7e4 <nulterminate>
    *rcmd->efile = 0;
     82e:	6c9c                	ld	a5,24(s1)
     830:	00078023          	sb	zero,0(a5)
    bcmd = (struct backcmd*)cmd;
    nulterminate(bcmd->cmd);
    break;
  }
  return cmd;
}
     834:	8526                	mv	a0,s1
     836:	60e2                	ld	ra,24(sp)
     838:	6442                	ld	s0,16(sp)
     83a:	64a2                	ld	s1,8(sp)
     83c:	6105                	addi	sp,sp,32
     83e:	8082                	ret
    nulterminate(pcmd->left);
     840:	6508                	ld	a0,8(a0)
     842:	fa3ff0ef          	jal	7e4 <nulterminate>
    nulterminate(pcmd->right);
     846:	6888                	ld	a0,16(s1)
     848:	f9dff0ef          	jal	7e4 <nulterminate>
    break;
     84c:	b7e5                	j	834 <nulterminate+0x50>
    nulterminate(lcmd->left);
     84e:	6508                	ld	a0,8(a0)
     850:	f95ff0ef          	jal	7e4 <nulterminate>
    nulterminate(lcmd->right);
     854:	6888                	ld	a0,16(s1)
     856:	f8fff0ef          	jal	7e4 <nulterminate>
    break;
     85a:	bfe9                	j	834 <nulterminate+0x50>
    nulterminate(bcmd->cmd);
     85c:	6508                	ld	a0,8(a0)
     85e:	f87ff0ef          	jal	7e4 <nulterminate>
    break;
     862:	bfc9                	j	834 <nulterminate+0x50>

0000000000000864 <parsecmd>:
{
     864:	7139                	addi	sp,sp,-64
     866:	fc06                	sd	ra,56(sp)
     868:	f822                	sd	s0,48(sp)
     86a:	f426                	sd	s1,40(sp)
     86c:	f04a                	sd	s2,32(sp)
     86e:	ec4e                	sd	s3,24(sp)
     870:	0080                	addi	s0,sp,64
     872:	fca43423          	sd	a0,-56(s0)
  es = s + strlen(s);
     876:	84aa                	mv	s1,a0
     878:	196000ef          	jal	a0e <strlen>
     87c:	1502                	slli	a0,a0,0x20
     87e:	9101                	srli	a0,a0,0x20
     880:	94aa                	add	s1,s1,a0
  cmd = parseline(&s, es);
     882:	fc840913          	addi	s2,s0,-56
     886:	85a6                	mv	a1,s1
     888:	854a                	mv	a0,s2
     88a:	e4fff0ef          	jal	6d8 <parseline>
     88e:	89aa                	mv	s3,a0
  peek(&s, es, "");
     890:	00001617          	auipc	a2,0x1
     894:	b8860613          	addi	a2,a2,-1144 # 1418 <thread_switch+0x7e>
     898:	85a6                	mv	a1,s1
     89a:	854a                	mv	a0,s2
     89c:	ba1ff0ef          	jal	43c <peek>
  if(s != es){
     8a0:	fc843603          	ld	a2,-56(s0)
     8a4:	00961d63          	bne	a2,s1,8be <parsecmd+0x5a>
  nulterminate(cmd);
     8a8:	854e                	mv	a0,s3
     8aa:	f3bff0ef          	jal	7e4 <nulterminate>
}
     8ae:	854e                	mv	a0,s3
     8b0:	70e2                	ld	ra,56(sp)
     8b2:	7442                	ld	s0,48(sp)
     8b4:	74a2                	ld	s1,40(sp)
     8b6:	7902                	ld	s2,32(sp)
     8b8:	69e2                	ld	s3,24(sp)
     8ba:	6121                	addi	sp,sp,64
     8bc:	8082                	ret
    fprintf(2, "leftovers: %s\n", s);
     8be:	00001597          	auipc	a1,0x1
     8c2:	c3a58593          	addi	a1,a1,-966 # 14f8 <thread_switch+0x15e>
     8c6:	4509                	li	a0,2
     8c8:	788000ef          	jal	1050 <fprintf>
    panic("syntax");
     8cc:	00001517          	auipc	a0,0x1
     8d0:	bc450513          	addi	a0,a0,-1084 # 1490 <thread_switch+0xf6>
     8d4:	f76ff0ef          	jal	4a <panic>

00000000000008d8 <main>:
{
     8d8:	7179                	addi	sp,sp,-48
     8da:	f406                	sd	ra,40(sp)
     8dc:	f022                	sd	s0,32(sp)
     8de:	ec26                	sd	s1,24(sp)
     8e0:	e84a                	sd	s2,16(sp)
     8e2:	e44e                	sd	s3,8(sp)
     8e4:	e052                	sd	s4,0(sp)
     8e6:	1800                	addi	s0,sp,48
  while((fd = open("console", O_RDWR)) >= 0){
     8e8:	4489                	li	s1,2
     8ea:	00001917          	auipc	s2,0x1
     8ee:	c1e90913          	addi	s2,s2,-994 # 1508 <thread_switch+0x16e>
     8f2:	85a6                	mv	a1,s1
     8f4:	854a                	mv	a0,s2
     8f6:	382000ef          	jal	c78 <open>
     8fa:	00054663          	bltz	a0,906 <main+0x2e>
    if(fd >= 3){
     8fe:	fea4dae3          	bge	s1,a0,8f2 <main+0x1a>
      close(fd);
     902:	35e000ef          	jal	c60 <close>
  while(getcmd(buf, sizeof(buf)) >= 0){
     906:	06400913          	li	s2,100
     90a:	00001497          	auipc	s1,0x1
     90e:	71648493          	addi	s1,s1,1814 # 2020 <buf.0>
    if(buf[0] == 'c' && buf[1] == 'd' && buf[2] == ' '){
     912:	06300993          	li	s3,99
     916:	02000a13          	li	s4,32
     91a:	a039                	j	928 <main+0x50>
    if(fork1() == 0)
     91c:	f4cff0ef          	jal	68 <fork1>
     920:	c93d                	beqz	a0,996 <main+0xbe>
    wait(0);
     922:	4501                	li	a0,0
     924:	31c000ef          	jal	c40 <wait>
  while(getcmd(buf, sizeof(buf)) >= 0){
     928:	85ca                	mv	a1,s2
     92a:	8526                	mv	a0,s1
     92c:	ed4ff0ef          	jal	0 <getcmd>
     930:	06054b63          	bltz	a0,9a6 <main+0xce>
    if(buf[0] == 'c' && buf[1] == 'd' && buf[2] == ' '){
     934:	0004c783          	lbu	a5,0(s1)
     938:	ff3792e3          	bne	a5,s3,91c <main+0x44>
     93c:	0014c783          	lbu	a5,1(s1)
     940:	fd279ee3          	bne	a5,s2,91c <main+0x44>
     944:	0024c783          	lbu	a5,2(s1)
     948:	fd479ae3          	bne	a5,s4,91c <main+0x44>
      buf[strlen(buf)-1] = 0;  // chop \n
     94c:	00001517          	auipc	a0,0x1
     950:	6d450513          	addi	a0,a0,1748 # 2020 <buf.0>
     954:	0ba000ef          	jal	a0e <strlen>
     958:	fff5079b          	addiw	a5,a0,-1
     95c:	1782                	slli	a5,a5,0x20
     95e:	9381                	srli	a5,a5,0x20
     960:	00001717          	auipc	a4,0x1
     964:	6c070713          	addi	a4,a4,1728 # 2020 <buf.0>
     968:	97ba                	add	a5,a5,a4
     96a:	00078023          	sb	zero,0(a5)
      if(chdir(buf+3) < 0)
     96e:	00001517          	auipc	a0,0x1
     972:	6b550513          	addi	a0,a0,1717 # 2023 <buf.0+0x3>
     976:	332000ef          	jal	ca8 <chdir>
     97a:	fa0557e3          	bgez	a0,928 <main+0x50>
        fprintf(2, "cannot cd %s\n", buf+3);
     97e:	00001617          	auipc	a2,0x1
     982:	6a560613          	addi	a2,a2,1701 # 2023 <buf.0+0x3>
     986:	00001597          	auipc	a1,0x1
     98a:	b8a58593          	addi	a1,a1,-1142 # 1510 <thread_switch+0x176>
     98e:	4509                	li	a0,2
     990:	6c0000ef          	jal	1050 <fprintf>
     994:	bf51                	j	928 <main+0x50>
      runcmd(parsecmd(buf));
     996:	00001517          	auipc	a0,0x1
     99a:	68a50513          	addi	a0,a0,1674 # 2020 <buf.0>
     99e:	ec7ff0ef          	jal	864 <parsecmd>
     9a2:	eecff0ef          	jal	8e <runcmd>
  exit(0);
     9a6:	4501                	li	a0,0
     9a8:	290000ef          	jal	c38 <exit>

00000000000009ac <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
     9ac:	1141                	addi	sp,sp,-16
     9ae:	e406                	sd	ra,8(sp)
     9b0:	e022                	sd	s0,0(sp)
     9b2:	0800                	addi	s0,sp,16
  extern int main();
  main();
     9b4:	f25ff0ef          	jal	8d8 <main>
  exit(0);
     9b8:	4501                	li	a0,0
     9ba:	27e000ef          	jal	c38 <exit>

00000000000009be <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
     9be:	1141                	addi	sp,sp,-16
     9c0:	e406                	sd	ra,8(sp)
     9c2:	e022                	sd	s0,0(sp)
     9c4:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
     9c6:	87aa                	mv	a5,a0
     9c8:	0585                	addi	a1,a1,1
     9ca:	0785                	addi	a5,a5,1
     9cc:	fff5c703          	lbu	a4,-1(a1)
     9d0:	fee78fa3          	sb	a4,-1(a5)
     9d4:	fb75                	bnez	a4,9c8 <strcpy+0xa>
    ;
  return os;
}
     9d6:	60a2                	ld	ra,8(sp)
     9d8:	6402                	ld	s0,0(sp)
     9da:	0141                	addi	sp,sp,16
     9dc:	8082                	ret

00000000000009de <strcmp>:

int
strcmp(const char *p, const char *q)
{
     9de:	1141                	addi	sp,sp,-16
     9e0:	e406                	sd	ra,8(sp)
     9e2:	e022                	sd	s0,0(sp)
     9e4:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
     9e6:	00054783          	lbu	a5,0(a0)
     9ea:	cb91                	beqz	a5,9fe <strcmp+0x20>
     9ec:	0005c703          	lbu	a4,0(a1)
     9f0:	00f71763          	bne	a4,a5,9fe <strcmp+0x20>
    p++, q++;
     9f4:	0505                	addi	a0,a0,1
     9f6:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
     9f8:	00054783          	lbu	a5,0(a0)
     9fc:	fbe5                	bnez	a5,9ec <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
     9fe:	0005c503          	lbu	a0,0(a1)
}
     a02:	40a7853b          	subw	a0,a5,a0
     a06:	60a2                	ld	ra,8(sp)
     a08:	6402                	ld	s0,0(sp)
     a0a:	0141                	addi	sp,sp,16
     a0c:	8082                	ret

0000000000000a0e <strlen>:

uint
strlen(const char *s)
{
     a0e:	1141                	addi	sp,sp,-16
     a10:	e406                	sd	ra,8(sp)
     a12:	e022                	sd	s0,0(sp)
     a14:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
     a16:	00054783          	lbu	a5,0(a0)
     a1a:	cf91                	beqz	a5,a36 <strlen+0x28>
     a1c:	00150793          	addi	a5,a0,1
     a20:	86be                	mv	a3,a5
     a22:	0785                	addi	a5,a5,1
     a24:	fff7c703          	lbu	a4,-1(a5)
     a28:	ff65                	bnez	a4,a20 <strlen+0x12>
     a2a:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
     a2e:	60a2                	ld	ra,8(sp)
     a30:	6402                	ld	s0,0(sp)
     a32:	0141                	addi	sp,sp,16
     a34:	8082                	ret
  for(n = 0; s[n]; n++)
     a36:	4501                	li	a0,0
     a38:	bfdd                	j	a2e <strlen+0x20>

0000000000000a3a <memset>:

void*
memset(void *dst, int c, uint n)
{
     a3a:	1141                	addi	sp,sp,-16
     a3c:	e406                	sd	ra,8(sp)
     a3e:	e022                	sd	s0,0(sp)
     a40:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
     a42:	ca19                	beqz	a2,a58 <memset+0x1e>
     a44:	87aa                	mv	a5,a0
     a46:	1602                	slli	a2,a2,0x20
     a48:	9201                	srli	a2,a2,0x20
     a4a:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
     a4e:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
     a52:	0785                	addi	a5,a5,1
     a54:	fee79de3          	bne	a5,a4,a4e <memset+0x14>
  }
  return dst;
}
     a58:	60a2                	ld	ra,8(sp)
     a5a:	6402                	ld	s0,0(sp)
     a5c:	0141                	addi	sp,sp,16
     a5e:	8082                	ret

0000000000000a60 <strchr>:

char*
strchr(const char *s, char c)
{
     a60:	1141                	addi	sp,sp,-16
     a62:	e406                	sd	ra,8(sp)
     a64:	e022                	sd	s0,0(sp)
     a66:	0800                	addi	s0,sp,16
  for(; *s; s++)
     a68:	00054783          	lbu	a5,0(a0)
     a6c:	c799                	beqz	a5,a7a <strchr+0x1a>
    if(*s == c)
     a6e:	00f58763          	beq	a1,a5,a7c <strchr+0x1c>
  for(; *s; s++)
     a72:	0505                	addi	a0,a0,1
     a74:	00054783          	lbu	a5,0(a0)
     a78:	fbfd                	bnez	a5,a6e <strchr+0xe>
      return (char*)s;
  return 0;
     a7a:	4501                	li	a0,0
}
     a7c:	60a2                	ld	ra,8(sp)
     a7e:	6402                	ld	s0,0(sp)
     a80:	0141                	addi	sp,sp,16
     a82:	8082                	ret

0000000000000a84 <gets>:

char*
gets(char *buf, int max)
{
     a84:	711d                	addi	sp,sp,-96
     a86:	ec86                	sd	ra,88(sp)
     a88:	e8a2                	sd	s0,80(sp)
     a8a:	e4a6                	sd	s1,72(sp)
     a8c:	e0ca                	sd	s2,64(sp)
     a8e:	fc4e                	sd	s3,56(sp)
     a90:	f852                	sd	s4,48(sp)
     a92:	f456                	sd	s5,40(sp)
     a94:	f05a                	sd	s6,32(sp)
     a96:	ec5e                	sd	s7,24(sp)
     a98:	e862                	sd	s8,16(sp)
     a9a:	1080                	addi	s0,sp,96
     a9c:	8baa                	mv	s7,a0
     a9e:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
     aa0:	892a                	mv	s2,a0
     aa2:	4481                	li	s1,0
    cc = read(0, &c, 1);
     aa4:	faf40b13          	addi	s6,s0,-81
     aa8:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
     aaa:	8c26                	mv	s8,s1
     aac:	0014899b          	addiw	s3,s1,1
     ab0:	84ce                	mv	s1,s3
     ab2:	0349d863          	bge	s3,s4,ae2 <gets+0x5e>
    cc = read(0, &c, 1);
     ab6:	8656                	mv	a2,s5
     ab8:	85da                	mv	a1,s6
     aba:	4501                	li	a0,0
     abc:	194000ef          	jal	c50 <read>
    if(cc < 1)
     ac0:	02a05163          	blez	a0,ae2 <gets+0x5e>
      break;
    buf[i++] = c;
     ac4:	faf44783          	lbu	a5,-81(s0)
     ac8:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
     acc:	0905                	addi	s2,s2,1
     ace:	ff678713          	addi	a4,a5,-10
     ad2:	00173713          	seqz	a4,a4
     ad6:	17cd                	addi	a5,a5,-13
     ad8:	0017b793          	seqz	a5,a5
     adc:	8fd9                	or	a5,a5,a4
     ade:	d7f1                	beqz	a5,aaa <gets+0x26>
    buf[i++] = c;
     ae0:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
     ae2:	9c5e                	add	s8,s8,s7
     ae4:	000c0023          	sb	zero,0(s8)
  return buf;
}
     ae8:	855e                	mv	a0,s7
     aea:	60e6                	ld	ra,88(sp)
     aec:	6446                	ld	s0,80(sp)
     aee:	64a6                	ld	s1,72(sp)
     af0:	6906                	ld	s2,64(sp)
     af2:	79e2                	ld	s3,56(sp)
     af4:	7a42                	ld	s4,48(sp)
     af6:	7aa2                	ld	s5,40(sp)
     af8:	7b02                	ld	s6,32(sp)
     afa:	6be2                	ld	s7,24(sp)
     afc:	6c42                	ld	s8,16(sp)
     afe:	6125                	addi	sp,sp,96
     b00:	8082                	ret

0000000000000b02 <stat>:

int
stat(const char *n, struct stat *st)
{
     b02:	1101                	addi	sp,sp,-32
     b04:	ec06                	sd	ra,24(sp)
     b06:	e822                	sd	s0,16(sp)
     b08:	e04a                	sd	s2,0(sp)
     b0a:	1000                	addi	s0,sp,32
     b0c:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
     b0e:	4581                	li	a1,0
     b10:	168000ef          	jal	c78 <open>
  if(fd < 0)
     b14:	02054263          	bltz	a0,b38 <stat+0x36>
     b18:	e426                	sd	s1,8(sp)
     b1a:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
     b1c:	85ca                	mv	a1,s2
     b1e:	172000ef          	jal	c90 <fstat>
     b22:	892a                	mv	s2,a0
  close(fd);
     b24:	8526                	mv	a0,s1
     b26:	13a000ef          	jal	c60 <close>
  return r;
     b2a:	64a2                	ld	s1,8(sp)
}
     b2c:	854a                	mv	a0,s2
     b2e:	60e2                	ld	ra,24(sp)
     b30:	6442                	ld	s0,16(sp)
     b32:	6902                	ld	s2,0(sp)
     b34:	6105                	addi	sp,sp,32
     b36:	8082                	ret
    return -1;
     b38:	57fd                	li	a5,-1
     b3a:	893e                	mv	s2,a5
     b3c:	bfc5                	j	b2c <stat+0x2a>

0000000000000b3e <atoi>:

int
atoi(const char *s)
{
     b3e:	1141                	addi	sp,sp,-16
     b40:	e406                	sd	ra,8(sp)
     b42:	e022                	sd	s0,0(sp)
     b44:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
     b46:	00054683          	lbu	a3,0(a0)
     b4a:	fd06879b          	addiw	a5,a3,-48
     b4e:	0ff7f793          	zext.b	a5,a5
     b52:	4625                	li	a2,9
     b54:	02f66963          	bltu	a2,a5,b86 <atoi+0x48>
     b58:	872a                	mv	a4,a0
  n = 0;
     b5a:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
     b5c:	0705                	addi	a4,a4,1
     b5e:	0025179b          	slliw	a5,a0,0x2
     b62:	9fa9                	addw	a5,a5,a0
     b64:	0017979b          	slliw	a5,a5,0x1
     b68:	9fb5                	addw	a5,a5,a3
     b6a:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
     b6e:	00074683          	lbu	a3,0(a4)
     b72:	fd06879b          	addiw	a5,a3,-48
     b76:	0ff7f793          	zext.b	a5,a5
     b7a:	fef671e3          	bgeu	a2,a5,b5c <atoi+0x1e>
  return n;
}
     b7e:	60a2                	ld	ra,8(sp)
     b80:	6402                	ld	s0,0(sp)
     b82:	0141                	addi	sp,sp,16
     b84:	8082                	ret
  n = 0;
     b86:	4501                	li	a0,0
     b88:	bfdd                	j	b7e <atoi+0x40>

0000000000000b8a <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
     b8a:	1141                	addi	sp,sp,-16
     b8c:	e406                	sd	ra,8(sp)
     b8e:	e022                	sd	s0,0(sp)
     b90:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
     b92:	02b57563          	bgeu	a0,a1,bbc <memmove+0x32>
    while(n-- > 0)
     b96:	00c05f63          	blez	a2,bb4 <memmove+0x2a>
     b9a:	1602                	slli	a2,a2,0x20
     b9c:	9201                	srli	a2,a2,0x20
     b9e:	00c507b3          	add	a5,a0,a2
  dst = vdst;
     ba2:	872a                	mv	a4,a0
      *dst++ = *src++;
     ba4:	0585                	addi	a1,a1,1
     ba6:	0705                	addi	a4,a4,1
     ba8:	fff5c683          	lbu	a3,-1(a1)
     bac:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
     bb0:	fee79ae3          	bne	a5,a4,ba4 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
     bb4:	60a2                	ld	ra,8(sp)
     bb6:	6402                	ld	s0,0(sp)
     bb8:	0141                	addi	sp,sp,16
     bba:	8082                	ret
    while(n-- > 0)
     bbc:	fec05ce3          	blez	a2,bb4 <memmove+0x2a>
    dst += n;
     bc0:	00c50733          	add	a4,a0,a2
    src += n;
     bc4:	95b2                	add	a1,a1,a2
     bc6:	fff6079b          	addiw	a5,a2,-1
     bca:	1782                	slli	a5,a5,0x20
     bcc:	9381                	srli	a5,a5,0x20
     bce:	fff7c793          	not	a5,a5
     bd2:	97ba                	add	a5,a5,a4
      *--dst = *--src;
     bd4:	15fd                	addi	a1,a1,-1
     bd6:	177d                	addi	a4,a4,-1
     bd8:	0005c683          	lbu	a3,0(a1)
     bdc:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
     be0:	fef71ae3          	bne	a4,a5,bd4 <memmove+0x4a>
     be4:	bfc1                	j	bb4 <memmove+0x2a>

0000000000000be6 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
     be6:	1141                	addi	sp,sp,-16
     be8:	e406                	sd	ra,8(sp)
     bea:	e022                	sd	s0,0(sp)
     bec:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
     bee:	ce19                	beqz	a2,c0c <memcmp+0x26>
     bf0:	1602                	slli	a2,a2,0x20
     bf2:	9201                	srli	a2,a2,0x20
     bf4:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
     bf8:	00054783          	lbu	a5,0(a0)
     bfc:	0005c703          	lbu	a4,0(a1)
     c00:	00e79b63          	bne	a5,a4,c16 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
     c04:	0505                	addi	a0,a0,1
    p2++;
     c06:	0585                	addi	a1,a1,1
  while (n-- > 0) {
     c08:	fed518e3          	bne	a0,a3,bf8 <memcmp+0x12>
  }
  return 0;
     c0c:	4501                	li	a0,0
}
     c0e:	60a2                	ld	ra,8(sp)
     c10:	6402                	ld	s0,0(sp)
     c12:	0141                	addi	sp,sp,16
     c14:	8082                	ret
      return *p1 - *p2;
     c16:	40e7853b          	subw	a0,a5,a4
     c1a:	bfd5                	j	c0e <memcmp+0x28>

0000000000000c1c <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
     c1c:	1141                	addi	sp,sp,-16
     c1e:	e406                	sd	ra,8(sp)
     c20:	e022                	sd	s0,0(sp)
     c22:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
     c24:	f67ff0ef          	jal	b8a <memmove>
}
     c28:	60a2                	ld	ra,8(sp)
     c2a:	6402                	ld	s0,0(sp)
     c2c:	0141                	addi	sp,sp,16
     c2e:	8082                	ret

0000000000000c30 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
     c30:	4885                	li	a7,1
 ecall
     c32:	00000073          	ecall
 ret
     c36:	8082                	ret

0000000000000c38 <exit>:
.global exit
exit:
 li a7, SYS_exit
     c38:	4889                	li	a7,2
 ecall
     c3a:	00000073          	ecall
 ret
     c3e:	8082                	ret

0000000000000c40 <wait>:
.global wait
wait:
 li a7, SYS_wait
     c40:	488d                	li	a7,3
 ecall
     c42:	00000073          	ecall
 ret
     c46:	8082                	ret

0000000000000c48 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
     c48:	4891                	li	a7,4
 ecall
     c4a:	00000073          	ecall
 ret
     c4e:	8082                	ret

0000000000000c50 <read>:
.global read
read:
 li a7, SYS_read
     c50:	4895                	li	a7,5
 ecall
     c52:	00000073          	ecall
 ret
     c56:	8082                	ret

0000000000000c58 <write>:
.global write
write:
 li a7, SYS_write
     c58:	48c1                	li	a7,16
 ecall
     c5a:	00000073          	ecall
 ret
     c5e:	8082                	ret

0000000000000c60 <close>:
.global close
close:
 li a7, SYS_close
     c60:	48d5                	li	a7,21
 ecall
     c62:	00000073          	ecall
 ret
     c66:	8082                	ret

0000000000000c68 <kill>:
.global kill
kill:
 li a7, SYS_kill
     c68:	4899                	li	a7,6
 ecall
     c6a:	00000073          	ecall
 ret
     c6e:	8082                	ret

0000000000000c70 <exec>:
.global exec
exec:
 li a7, SYS_exec
     c70:	489d                	li	a7,7
 ecall
     c72:	00000073          	ecall
 ret
     c76:	8082                	ret

0000000000000c78 <open>:
.global open
open:
 li a7, SYS_open
     c78:	48bd                	li	a7,15
 ecall
     c7a:	00000073          	ecall
 ret
     c7e:	8082                	ret

0000000000000c80 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
     c80:	48c5                	li	a7,17
 ecall
     c82:	00000073          	ecall
 ret
     c86:	8082                	ret

0000000000000c88 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
     c88:	48c9                	li	a7,18
 ecall
     c8a:	00000073          	ecall
 ret
     c8e:	8082                	ret

0000000000000c90 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
     c90:	48a1                	li	a7,8
 ecall
     c92:	00000073          	ecall
 ret
     c96:	8082                	ret

0000000000000c98 <link>:
.global link
link:
 li a7, SYS_link
     c98:	48cd                	li	a7,19
 ecall
     c9a:	00000073          	ecall
 ret
     c9e:	8082                	ret

0000000000000ca0 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
     ca0:	48d1                	li	a7,20
 ecall
     ca2:	00000073          	ecall
 ret
     ca6:	8082                	ret

0000000000000ca8 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
     ca8:	48a5                	li	a7,9
 ecall
     caa:	00000073          	ecall
 ret
     cae:	8082                	ret

0000000000000cb0 <dup>:
.global dup
dup:
 li a7, SYS_dup
     cb0:	48a9                	li	a7,10
 ecall
     cb2:	00000073          	ecall
 ret
     cb6:	8082                	ret

0000000000000cb8 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
     cb8:	48ad                	li	a7,11
 ecall
     cba:	00000073          	ecall
 ret
     cbe:	8082                	ret

0000000000000cc0 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
     cc0:	48b1                	li	a7,12
 ecall
     cc2:	00000073          	ecall
 ret
     cc6:	8082                	ret

0000000000000cc8 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
     cc8:	48b5                	li	a7,13
 ecall
     cca:	00000073          	ecall
 ret
     cce:	8082                	ret

0000000000000cd0 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
     cd0:	48b9                	li	a7,14
 ecall
     cd2:	00000073          	ecall
 ret
     cd6:	8082                	ret

0000000000000cd8 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
     cd8:	1101                	addi	sp,sp,-32
     cda:	ec06                	sd	ra,24(sp)
     cdc:	e822                	sd	s0,16(sp)
     cde:	1000                	addi	s0,sp,32
     ce0:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
     ce4:	4605                	li	a2,1
     ce6:	fef40593          	addi	a1,s0,-17
     cea:	f6fff0ef          	jal	c58 <write>
}
     cee:	60e2                	ld	ra,24(sp)
     cf0:	6442                	ld	s0,16(sp)
     cf2:	6105                	addi	sp,sp,32
     cf4:	8082                	ret

0000000000000cf6 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
     cf6:	715d                	addi	sp,sp,-80
     cf8:	e486                	sd	ra,72(sp)
     cfa:	e0a2                	sd	s0,64(sp)
     cfc:	f84a                	sd	s2,48(sp)
     cfe:	f44e                	sd	s3,40(sp)
     d00:	0880                	addi	s0,sp,80
     d02:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
     d04:	00d036b3          	snez	a3,a3
     d08:	03f5d793          	srli	a5,a1,0x3f
     d0c:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
     d0e:	0005871b          	sext.w	a4,a1
  neg = 0;
     d12:	4301                	li	t1,0
  if(sgn && xx < 0){
     d14:	c681                	beqz	a3,d1c <printint+0x26>
    x = -xx;
     d16:	40b0073b          	negw	a4,a1
    neg = 1;
     d1a:	4305                	li	t1,1
  }

  i = 0;
     d1c:	fb840993          	addi	s3,s0,-72
  neg = 0;
     d20:	85ce                	mv	a1,s3
  i = 0;
     d22:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
     d24:	00001817          	auipc	a6,0x1
     d28:	85c80813          	addi	a6,a6,-1956 # 1580 <digits>
     d2c:	88b6                	mv	a7,a3
     d2e:	0016851b          	addiw	a0,a3,1
     d32:	86aa                	mv	a3,a0
     d34:	02c777bb          	remuw	a5,a4,a2
     d38:	1782                	slli	a5,a5,0x20
     d3a:	9381                	srli	a5,a5,0x20
     d3c:	97c2                	add	a5,a5,a6
     d3e:	0007c783          	lbu	a5,0(a5)
     d42:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
     d46:	87ba                	mv	a5,a4
     d48:	02c7573b          	divuw	a4,a4,a2
     d4c:	0585                	addi	a1,a1,1
     d4e:	fcc7ffe3          	bgeu	a5,a2,d2c <printint+0x36>
  if(neg)
     d52:	00030b63          	beqz	t1,d68 <printint+0x72>
    buf[i++] = '-';
     d56:	fd040793          	addi	a5,s0,-48
     d5a:	953e                	add	a0,a0,a5
     d5c:	02d00793          	li	a5,45
     d60:	fef50423          	sb	a5,-24(a0)
     d64:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
     d68:	02d05563          	blez	a3,d92 <printint+0x9c>
     d6c:	fc26                	sd	s1,56(sp)
     d6e:	36fd                	addiw	a3,a3,-1
     d70:	00d984b3          	add	s1,s3,a3
     d74:	19fd                	addi	s3,s3,-1
     d76:	99b6                	add	s3,s3,a3
     d78:	1682                	slli	a3,a3,0x20
     d7a:	9281                	srli	a3,a3,0x20
     d7c:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
     d80:	0004c583          	lbu	a1,0(s1)
     d84:	854a                	mv	a0,s2
     d86:	f53ff0ef          	jal	cd8 <putc>
  while(--i >= 0)
     d8a:	14fd                	addi	s1,s1,-1
     d8c:	ff349ae3          	bne	s1,s3,d80 <printint+0x8a>
     d90:	74e2                	ld	s1,56(sp)
}
     d92:	60a6                	ld	ra,72(sp)
     d94:	6406                	ld	s0,64(sp)
     d96:	7942                	ld	s2,48(sp)
     d98:	79a2                	ld	s3,40(sp)
     d9a:	6161                	addi	sp,sp,80
     d9c:	8082                	ret

0000000000000d9e <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
     d9e:	711d                	addi	sp,sp,-96
     da0:	ec86                	sd	ra,88(sp)
     da2:	e8a2                	sd	s0,80(sp)
     da4:	e4a6                	sd	s1,72(sp)
     da6:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
     da8:	0005c483          	lbu	s1,0(a1)
     dac:	28048263          	beqz	s1,1030 <vprintf+0x292>
     db0:	e0ca                	sd	s2,64(sp)
     db2:	fc4e                	sd	s3,56(sp)
     db4:	f852                	sd	s4,48(sp)
     db6:	f456                	sd	s5,40(sp)
     db8:	f05a                	sd	s6,32(sp)
     dba:	ec5e                	sd	s7,24(sp)
     dbc:	e862                	sd	s8,16(sp)
     dbe:	8b2a                	mv	s6,a0
     dc0:	8a2e                	mv	s4,a1
     dc2:	8bb2                	mv	s7,a2
  state = 0;
     dc4:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
     dc6:	4901                	li	s2,0
     dc8:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
     dca:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
     dce:	06400c13          	li	s8,100
     dd2:	a00d                	j	df4 <vprintf+0x56>
        putc(fd, c0);
     dd4:	85a6                	mv	a1,s1
     dd6:	855a                	mv	a0,s6
     dd8:	f01ff0ef          	jal	cd8 <putc>
     ddc:	a019                	j	de2 <vprintf+0x44>
    } else if(state == '%'){
     dde:	03598363          	beq	s3,s5,e04 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
     de2:	0019079b          	addiw	a5,s2,1
     de6:	893e                	mv	s2,a5
     de8:	873e                	mv	a4,a5
     dea:	97d2                	add	a5,a5,s4
     dec:	0007c483          	lbu	s1,0(a5)
     df0:	22048963          	beqz	s1,1022 <vprintf+0x284>
    c0 = fmt[i] & 0xff;
     df4:	0004879b          	sext.w	a5,s1
    if(state == 0){
     df8:	fe0993e3          	bnez	s3,dde <vprintf+0x40>
      if(c0 == '%'){
     dfc:	fd579ce3          	bne	a5,s5,dd4 <vprintf+0x36>
        state = '%';
     e00:	89be                	mv	s3,a5
     e02:	b7c5                	j	de2 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
     e04:	00ea06b3          	add	a3,s4,a4
     e08:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
     e0c:	22060763          	beqz	a2,103a <vprintf+0x29c>
      if(c0 == 'd'){
     e10:	0b878363          	beq	a5,s8,eb6 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
     e14:	f9478693          	addi	a3,a5,-108
     e18:	0016b693          	seqz	a3,a3
     e1c:	f9c60593          	addi	a1,a2,-100
     e20:	0015b593          	seqz	a1,a1
     e24:	8df5                	and	a1,a1,a3
     e26:	e5c5                	bnez	a1,ece <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
     e28:	9752                	add	a4,a4,s4
     e2a:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
     e2e:	f9460713          	addi	a4,a2,-108
     e32:	00173713          	seqz	a4,a4
     e36:	8f75                	and	a4,a4,a3
     e38:	f9c50593          	addi	a1,a0,-100
     e3c:	0015b593          	seqz	a1,a1
     e40:	8df9                	and	a1,a1,a4
     e42:	e1dd                	bnez	a1,ee8 <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
     e44:	07500593          	li	a1,117
     e48:	0ab78d63          	beq	a5,a1,f02 <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
     e4c:	f8b60593          	addi	a1,a2,-117
     e50:	0015b593          	seqz	a1,a1
     e54:	8df5                	and	a1,a1,a3
     e56:	e1f1                	bnez	a1,f1a <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
     e58:	f8b50593          	addi	a1,a0,-117
     e5c:	0015b593          	seqz	a1,a1
     e60:	8df9                	and	a1,a1,a4
     e62:	e9e9                	bnez	a1,f34 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
     e64:	07800593          	li	a1,120
     e68:	0eb78363          	beq	a5,a1,f4e <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
     e6c:	f8860613          	addi	a2,a2,-120
     e70:	00163613          	seqz	a2,a2
     e74:	8ef1                	and	a3,a3,a2
     e76:	0e069863          	bnez	a3,f66 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
     e7a:	f8850513          	addi	a0,a0,-120
     e7e:	00153513          	seqz	a0,a0
     e82:	8f69                	and	a4,a4,a0
     e84:	0e071e63          	bnez	a4,f80 <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
     e88:	07000713          	li	a4,112
     e8c:	10e78663          	beq	a5,a4,f98 <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
     e90:	07300713          	li	a4,115
     e94:	14e78663          	beq	a5,a4,fe0 <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
     e98:	02500713          	li	a4,37
     e9c:	16e78e63          	beq	a5,a4,1018 <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
     ea0:	02500593          	li	a1,37
     ea4:	855a                	mv	a0,s6
     ea6:	e33ff0ef          	jal	cd8 <putc>
        putc(fd, c0);
     eaa:	85a6                	mv	a1,s1
     eac:	855a                	mv	a0,s6
     eae:	e2bff0ef          	jal	cd8 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
     eb2:	4981                	li	s3,0
     eb4:	b73d                	j	de2 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
     eb6:	008b8493          	addi	s1,s7,8
     eba:	4685                	li	a3,1
     ebc:	4629                	li	a2,10
     ebe:	000ba583          	lw	a1,0(s7)
     ec2:	855a                	mv	a0,s6
     ec4:	e33ff0ef          	jal	cf6 <printint>
     ec8:	8ba6                	mv	s7,s1
      state = 0;
     eca:	4981                	li	s3,0
     ecc:	bf19                	j	de2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
     ece:	008b8493          	addi	s1,s7,8
     ed2:	4685                	li	a3,1
     ed4:	4629                	li	a2,10
     ed6:	000bb583          	ld	a1,0(s7)
     eda:	855a                	mv	a0,s6
     edc:	e1bff0ef          	jal	cf6 <printint>
        i += 1;
     ee0:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
     ee2:	8ba6                	mv	s7,s1
      state = 0;
     ee4:	4981                	li	s3,0
     ee6:	bdf5                	j	de2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
     ee8:	008b8493          	addi	s1,s7,8
     eec:	4685                	li	a3,1
     eee:	4629                	li	a2,10
     ef0:	000bb583          	ld	a1,0(s7)
     ef4:	855a                	mv	a0,s6
     ef6:	e01ff0ef          	jal	cf6 <printint>
        i += 2;
     efa:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
     efc:	8ba6                	mv	s7,s1
      state = 0;
     efe:	4981                	li	s3,0
        i += 2;
     f00:	b5cd                	j	de2 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
     f02:	008b8493          	addi	s1,s7,8
     f06:	4681                	li	a3,0
     f08:	4629                	li	a2,10
     f0a:	000ba583          	lw	a1,0(s7)
     f0e:	855a                	mv	a0,s6
     f10:	de7ff0ef          	jal	cf6 <printint>
     f14:	8ba6                	mv	s7,s1
      state = 0;
     f16:	4981                	li	s3,0
     f18:	b5e9                	j	de2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
     f1a:	008b8493          	addi	s1,s7,8
     f1e:	4681                	li	a3,0
     f20:	4629                	li	a2,10
     f22:	000bb583          	ld	a1,0(s7)
     f26:	855a                	mv	a0,s6
     f28:	dcfff0ef          	jal	cf6 <printint>
        i += 1;
     f2c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
     f2e:	8ba6                	mv	s7,s1
      state = 0;
     f30:	4981                	li	s3,0
     f32:	bd45                	j	de2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
     f34:	008b8493          	addi	s1,s7,8
     f38:	4681                	li	a3,0
     f3a:	4629                	li	a2,10
     f3c:	000bb583          	ld	a1,0(s7)
     f40:	855a                	mv	a0,s6
     f42:	db5ff0ef          	jal	cf6 <printint>
        i += 2;
     f46:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
     f48:	8ba6                	mv	s7,s1
      state = 0;
     f4a:	4981                	li	s3,0
        i += 2;
     f4c:	bd59                	j	de2 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
     f4e:	008b8493          	addi	s1,s7,8
     f52:	4681                	li	a3,0
     f54:	4641                	li	a2,16
     f56:	000ba583          	lw	a1,0(s7)
     f5a:	855a                	mv	a0,s6
     f5c:	d9bff0ef          	jal	cf6 <printint>
     f60:	8ba6                	mv	s7,s1
      state = 0;
     f62:	4981                	li	s3,0
     f64:	bdbd                	j	de2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
     f66:	008b8493          	addi	s1,s7,8
     f6a:	4681                	li	a3,0
     f6c:	4641                	li	a2,16
     f6e:	000bb583          	ld	a1,0(s7)
     f72:	855a                	mv	a0,s6
     f74:	d83ff0ef          	jal	cf6 <printint>
        i += 1;
     f78:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
     f7a:	8ba6                	mv	s7,s1
      state = 0;
     f7c:	4981                	li	s3,0
     f7e:	b595                	j	de2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
     f80:	008b8493          	addi	s1,s7,8
     f84:	4641                	li	a2,16
     f86:	000bb583          	ld	a1,0(s7)
     f8a:	855a                	mv	a0,s6
     f8c:	d6bff0ef          	jal	cf6 <printint>
        i += 2;
     f90:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
     f92:	8ba6                	mv	s7,s1
      state = 0;
     f94:	4981                	li	s3,0
        i += 2;
     f96:	b5b1                	j	de2 <vprintf+0x44>
     f98:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
     f9a:	008b8793          	addi	a5,s7,8
     f9e:	8cbe                	mv	s9,a5
     fa0:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
     fa4:	03000593          	li	a1,48
     fa8:	855a                	mv	a0,s6
     faa:	d2fff0ef          	jal	cd8 <putc>
  putc(fd, 'x');
     fae:	07800593          	li	a1,120
     fb2:	855a                	mv	a0,s6
     fb4:	d25ff0ef          	jal	cd8 <putc>
     fb8:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
     fba:	00000b97          	auipc	s7,0x0
     fbe:	5c6b8b93          	addi	s7,s7,1478 # 1580 <digits>
     fc2:	03c9d793          	srli	a5,s3,0x3c
     fc6:	97de                	add	a5,a5,s7
     fc8:	0007c583          	lbu	a1,0(a5)
     fcc:	855a                	mv	a0,s6
     fce:	d0bff0ef          	jal	cd8 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
     fd2:	0992                	slli	s3,s3,0x4
     fd4:	34fd                	addiw	s1,s1,-1
     fd6:	f4f5                	bnez	s1,fc2 <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
     fd8:	8be6                	mv	s7,s9
      state = 0;
     fda:	4981                	li	s3,0
     fdc:	6ca2                	ld	s9,8(sp)
     fde:	b511                	j	de2 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
     fe0:	008b8993          	addi	s3,s7,8
     fe4:	000bb483          	ld	s1,0(s7)
     fe8:	cc91                	beqz	s1,1004 <vprintf+0x266>
        for(; *s; s++)
     fea:	0004c583          	lbu	a1,0(s1)
     fee:	c195                	beqz	a1,1012 <vprintf+0x274>
          putc(fd, *s);
     ff0:	855a                	mv	a0,s6
     ff2:	ce7ff0ef          	jal	cd8 <putc>
        for(; *s; s++)
     ff6:	0485                	addi	s1,s1,1
     ff8:	0004c583          	lbu	a1,0(s1)
     ffc:	f9f5                	bnez	a1,ff0 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
     ffe:	8bce                	mv	s7,s3
      state = 0;
    1000:	4981                	li	s3,0
    1002:	b3c5                	j	de2 <vprintf+0x44>
          s = "(null)";
    1004:	00000497          	auipc	s1,0x0
    1008:	51c48493          	addi	s1,s1,1308 # 1520 <thread_switch+0x186>
        for(; *s; s++)
    100c:	02800593          	li	a1,40
    1010:	b7c5                	j	ff0 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
    1012:	8bce                	mv	s7,s3
      state = 0;
    1014:	4981                	li	s3,0
    1016:	b3f1                	j	de2 <vprintf+0x44>
        putc(fd, '%');
    1018:	85be                	mv	a1,a5
    101a:	855a                	mv	a0,s6
    101c:	cbdff0ef          	jal	cd8 <putc>
    1020:	bd49                	j	eb2 <vprintf+0x114>
    1022:	6906                	ld	s2,64(sp)
    1024:	79e2                	ld	s3,56(sp)
    1026:	7a42                	ld	s4,48(sp)
    1028:	7aa2                	ld	s5,40(sp)
    102a:	7b02                	ld	s6,32(sp)
    102c:	6be2                	ld	s7,24(sp)
    102e:	6c42                	ld	s8,16(sp)
    }
  }
}
    1030:	60e6                	ld	ra,88(sp)
    1032:	6446                	ld	s0,80(sp)
    1034:	64a6                	ld	s1,72(sp)
    1036:	6125                	addi	sp,sp,96
    1038:	8082                	ret
      if(c0 == 'd'){
    103a:	06400713          	li	a4,100
    103e:	e6e78ce3          	beq	a5,a4,eb6 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
    1042:	f9478693          	addi	a3,a5,-108
    1046:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
    104a:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    104c:	4701                	li	a4,0
    104e:	bbdd                	j	e44 <vprintf+0xa6>

0000000000001050 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
    1050:	715d                	addi	sp,sp,-80
    1052:	ec06                	sd	ra,24(sp)
    1054:	e822                	sd	s0,16(sp)
    1056:	1000                	addi	s0,sp,32
    1058:	e010                	sd	a2,0(s0)
    105a:	e414                	sd	a3,8(s0)
    105c:	e818                	sd	a4,16(s0)
    105e:	ec1c                	sd	a5,24(s0)
    1060:	03043023          	sd	a6,32(s0)
    1064:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
    1068:	8622                	mv	a2,s0
    106a:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
    106e:	d31ff0ef          	jal	d9e <vprintf>
}
    1072:	60e2                	ld	ra,24(sp)
    1074:	6442                	ld	s0,16(sp)
    1076:	6161                	addi	sp,sp,80
    1078:	8082                	ret

000000000000107a <printf>:

void
printf(const char *fmt, ...)
{
    107a:	711d                	addi	sp,sp,-96
    107c:	ec06                	sd	ra,24(sp)
    107e:	e822                	sd	s0,16(sp)
    1080:	1000                	addi	s0,sp,32
    1082:	e40c                	sd	a1,8(s0)
    1084:	e810                	sd	a2,16(s0)
    1086:	ec14                	sd	a3,24(s0)
    1088:	f018                	sd	a4,32(s0)
    108a:	f41c                	sd	a5,40(s0)
    108c:	03043823          	sd	a6,48(s0)
    1090:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
    1094:	00840613          	addi	a2,s0,8
    1098:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
    109c:	85aa                	mv	a1,a0
    109e:	4505                	li	a0,1
    10a0:	cffff0ef          	jal	d9e <vprintf>
}
    10a4:	60e2                	ld	ra,24(sp)
    10a6:	6442                	ld	s0,16(sp)
    10a8:	6125                	addi	sp,sp,96
    10aa:	8082                	ret

00000000000010ac <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
    10ac:	1141                	addi	sp,sp,-16
    10ae:	e406                	sd	ra,8(sp)
    10b0:	e022                	sd	s0,0(sp)
    10b2:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
    10b4:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    10b8:	00001797          	auipc	a5,0x1
    10bc:	f587b783          	ld	a5,-168(a5) # 2010 <freep>
    10c0:	a095                	j	1124 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    10c2:	ff852583          	lw	a1,-8(a0)
    10c6:	6390                	ld	a2,0(a5)
    10c8:	02059813          	slli	a6,a1,0x20
    10cc:	01c85693          	srli	a3,a6,0x1c
    10d0:	96ba                	add	a3,a3,a4
    10d2:	02d60563          	beq	a2,a3,10fc <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
    10d6:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    10da:	4790                	lw	a2,8(a5)
    10dc:	02061593          	slli	a1,a2,0x20
    10e0:	01c5d693          	srli	a3,a1,0x1c
    10e4:	96be                	add	a3,a3,a5
    10e6:	02d70263          	beq	a4,a3,110a <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
    10ea:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
    10ec:	00001717          	auipc	a4,0x1
    10f0:	f2f73223          	sd	a5,-220(a4) # 2010 <freep>
}
    10f4:	60a2                	ld	ra,8(sp)
    10f6:	6402                	ld	s0,0(sp)
    10f8:	0141                	addi	sp,sp,16
    10fa:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
    10fc:	4614                	lw	a3,8(a2)
    10fe:	9ead                	addw	a3,a3,a1
    1100:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
    1104:	6394                	ld	a3,0(a5)
    1106:	6290                	ld	a2,0(a3)
    1108:	b7f9                	j	10d6 <free+0x2a>
    p->s.size += bp->s.size;
    110a:	ff852703          	lw	a4,-8(a0)
    110e:	9f31                	addw	a4,a4,a2
    1110:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
    1112:	ff053703          	ld	a4,-16(a0)
    1116:	bfd1                	j	10ea <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    1118:	6394                	ld	a3,0(a5)
    111a:	00d7e463          	bltu	a5,a3,1122 <free+0x76>
    111e:	fad762e3          	bltu	a4,a3,10c2 <free+0x16>
    1122:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    1124:	fee7fae3          	bgeu	a5,a4,1118 <free+0x6c>
    1128:	6394                	ld	a3,0(a5)
    112a:	f8d76ce3          	bltu	a4,a3,10c2 <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    112e:	f8d7fae3          	bgeu	a5,a3,10c2 <free+0x16>
    1132:	87b6                	mv	a5,a3
    1134:	bfc5                	j	1124 <free+0x78>

0000000000001136 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
    1136:	7139                	addi	sp,sp,-64
    1138:	fc06                	sd	ra,56(sp)
    113a:	f822                	sd	s0,48(sp)
    113c:	f04a                	sd	s2,32(sp)
    113e:	ec4e                	sd	s3,24(sp)
    1140:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    1142:	02051993          	slli	s3,a0,0x20
    1146:	0209d993          	srli	s3,s3,0x20
    114a:	09bd                	addi	s3,s3,15
    114c:	0049d993          	srli	s3,s3,0x4
    1150:	2985                	addiw	s3,s3,1
    1152:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
    1154:	00001517          	auipc	a0,0x1
    1158:	ebc53503          	ld	a0,-324(a0) # 2010 <freep>
    115c:	c905                	beqz	a0,118c <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    115e:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    1160:	4798                	lw	a4,8(a5)
    1162:	09377663          	bgeu	a4,s3,11ee <malloc+0xb8>
    1166:	f426                	sd	s1,40(sp)
    1168:	e852                	sd	s4,16(sp)
    116a:	e456                	sd	s5,8(sp)
    116c:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
    116e:	8a4e                	mv	s4,s3
    1170:	6705                	lui	a4,0x1
    1172:	00e9f363          	bgeu	s3,a4,1178 <malloc+0x42>
    1176:	6a05                	lui	s4,0x1
    1178:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
    117c:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
    1180:	00001497          	auipc	s1,0x1
    1184:	e9048493          	addi	s1,s1,-368 # 2010 <freep>
  if(p == (char*)-1)
    1188:	5afd                	li	s5,-1
    118a:	a83d                	j	11c8 <malloc+0x92>
    118c:	f426                	sd	s1,40(sp)
    118e:	e852                	sd	s4,16(sp)
    1190:	e456                	sd	s5,8(sp)
    1192:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
    1194:	00001797          	auipc	a5,0x1
    1198:	ef478793          	addi	a5,a5,-268 # 2088 <base>
    119c:	00001717          	auipc	a4,0x1
    11a0:	e6f73a23          	sd	a5,-396(a4) # 2010 <freep>
    11a4:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
    11a6:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
    11aa:	b7d1                	j	116e <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
    11ac:	6398                	ld	a4,0(a5)
    11ae:	e118                	sd	a4,0(a0)
    11b0:	a899                	j	1206 <malloc+0xd0>
  hp->s.size = nu;
    11b2:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
    11b6:	0541                	addi	a0,a0,16
    11b8:	ef5ff0ef          	jal	10ac <free>
  return freep;
    11bc:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
    11be:	c125                	beqz	a0,121e <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    11c0:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    11c2:	4798                	lw	a4,8(a5)
    11c4:	03277163          	bgeu	a4,s2,11e6 <malloc+0xb0>
    if(p == freep)
    11c8:	6098                	ld	a4,0(s1)
    11ca:	853e                	mv	a0,a5
    11cc:	fef71ae3          	bne	a4,a5,11c0 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
    11d0:	8552                	mv	a0,s4
    11d2:	aefff0ef          	jal	cc0 <sbrk>
  if(p == (char*)-1)
    11d6:	fd551ee3          	bne	a0,s5,11b2 <malloc+0x7c>
        return 0;
    11da:	4501                	li	a0,0
    11dc:	74a2                	ld	s1,40(sp)
    11de:	6a42                	ld	s4,16(sp)
    11e0:	6aa2                	ld	s5,8(sp)
    11e2:	6b02                	ld	s6,0(sp)
    11e4:	a03d                	j	1212 <malloc+0xdc>
    11e6:	74a2                	ld	s1,40(sp)
    11e8:	6a42                	ld	s4,16(sp)
    11ea:	6aa2                	ld	s5,8(sp)
    11ec:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
    11ee:	fae90fe3          	beq	s2,a4,11ac <malloc+0x76>
        p->s.size -= nunits;
    11f2:	4137073b          	subw	a4,a4,s3
    11f6:	c798                	sw	a4,8(a5)
        p += p->s.size;
    11f8:	02071693          	slli	a3,a4,0x20
    11fc:	01c6d713          	srli	a4,a3,0x1c
    1200:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
    1202:	0137a423          	sw	s3,8(a5)
      freep = prevp;
    1206:	00001717          	auipc	a4,0x1
    120a:	e0a73523          	sd	a0,-502(a4) # 2010 <freep>
      return (void*)(p + 1);
    120e:	01078513          	addi	a0,a5,16
  }
}
    1212:	70e2                	ld	ra,56(sp)
    1214:	7442                	ld	s0,48(sp)
    1216:	7902                	ld	s2,32(sp)
    1218:	69e2                	ld	s3,24(sp)
    121a:	6121                	addi	sp,sp,64
    121c:	8082                	ret
    121e:	74a2                	ld	s1,40(sp)
    1220:	6a42                	ld	s4,16(sp)
    1222:	6aa2                	ld	s5,8(sp)
    1224:	6b02                	ld	s6,0(sp)
    1226:	b7f5                	j	1212 <malloc+0xdc>

0000000000001228 <thread_init>:
struct thread *current_thread;
extern void thread_switch(uint64, uint64);
              
void 
thread_init(void)
{
    1228:	1141                	addi	sp,sp,-16
    122a:	e406                	sd	ra,8(sp)
    122c:	e022                	sd	s0,0(sp)
    122e:	0800                	addi	s0,sp,16
  // main() is thread 0, which will make the first invocation to
  // thread_schedule(). It needs a stack so that the first thread_switch() can
  // save thread 0's state.
  current_thread = &all_thread[0];
    1230:	00001797          	auipc	a5,0x1
    1234:	e6878793          	addi	a5,a5,-408 # 2098 <all_thread>
    1238:	00001717          	auipc	a4,0x1
    123c:	def73023          	sd	a5,-544(a4) # 2018 <current_thread>
  current_thread->state = RUNNING;
    1240:	00003717          	auipc	a4,0x3
    1244:	e5870713          	addi	a4,a4,-424 # 4098 <all_thread+0x2000>
    1248:	4785                	li	a5,1
    124a:	c31c                	sw	a5,0(a4)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
    124c:	00003797          	auipc	a5,0x3
    1250:	ddc78793          	addi	a5,a5,-548 # 4028 <all_thread+0x1f90>
  return (struct context *)(top & ~(uint64)0xf);
    1254:	9bc1                	andi	a5,a5,-16
  // Thread 0 runs on the process's own stack, but the first thread_switch()
  // still needs a writable place to save its context.
  current_thread->context = thread_context_slot(current_thread);
    1256:	e71c                	sd	a5,8(a4)
}
    1258:	60a2                	ld	ra,8(sp)
    125a:	6402                	ld	s0,0(sp)
    125c:	0141                	addi	sp,sp,16
    125e:	8082                	ret

0000000000001260 <thread_schedule>:

void 
thread_schedule(void)
{
    1260:	1141                	addi	sp,sp,-16
    1262:	e406                	sd	ra,8(sp)
    1264:	e022                	sd	s0,0(sp)
    1266:	0800                	addi	s0,sp,16
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
    1268:	00001597          	auipc	a1,0x1
    126c:	db05b583          	ld	a1,-592(a1) # 2018 <current_thread>
    1270:	6789                	lui	a5,0x2
    1272:	07c1                	addi	a5,a5,16 # 2010 <freep>
    1274:	97ae                	add	a5,a5,a1
    1276:	4711                	li	a4,4
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
    1278:	00009897          	auipc	a7,0x9
    127c:	e6088893          	addi	a7,a7,-416 # a0d8 <all_thread+0x8040>
      t = all_thread;
    if(t->state == RUNNABLE) {
    1280:	6809                	lui	a6,0x2
    1282:	4509                	li	a0,2
      next_thread = t;
      break;
    }
    t = t + 1;
    1284:	01080613          	addi	a2,a6,16 # 2010 <freep>
    1288:	a809                	j	129a <thread_schedule+0x3a>
    if(t->state == RUNNABLE) {
    128a:	010786b3          	add	a3,a5,a6
    128e:	4294                	lw	a3,0(a3)
    1290:	02a68563          	beq	a3,a0,12ba <thread_schedule+0x5a>
    t = t + 1;
    1294:	97b2                	add	a5,a5,a2
  for(int i = 0; i < MAX_THREAD; i++){
    1296:	377d                	addiw	a4,a4,-1
    1298:	cb01                	beqz	a4,12a8 <thread_schedule+0x48>
    if(t >= all_thread + MAX_THREAD)
    129a:	ff17e8e3          	bltu	a5,a7,128a <thread_schedule+0x2a>
      t = all_thread;
    129e:	00001797          	auipc	a5,0x1
    12a2:	dfa78793          	addi	a5,a5,-518 # 2098 <all_thread>
    12a6:	b7d5                	j	128a <thread_schedule+0x2a>
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
    12a8:	00000517          	auipc	a0,0x0
    12ac:	28050513          	addi	a0,a0,640 # 1528 <thread_switch+0x18e>
    12b0:	dcbff0ef          	jal	107a <printf>
    exit(-1);
    12b4:	557d                	li	a0,-1
    12b6:	983ff0ef          	jal	c38 <exit>
  }

  if (current_thread != next_thread) {         /* switch threads?  */
    12ba:	02f58163          	beq	a1,a5,12dc <thread_schedule+0x7c>
    next_thread->state = RUNNING;
    12be:	6689                	lui	a3,0x2
    12c0:	00d78733          	add	a4,a5,a3
    12c4:	4605                	li	a2,1
    12c6:	c310                	sw	a2,0(a4)
    t = current_thread;
    current_thread = next_thread;
    12c8:	00001617          	auipc	a2,0x1
    12cc:	d4f63823          	sd	a5,-688(a2) # 2018 <current_thread>
    thread_switch((uint64)t->context, (uint64)next_thread->context);
    12d0:	00d587b3          	add	a5,a1,a3
    12d4:	670c                	ld	a1,8(a4)
    12d6:	6788                	ld	a0,8(a5)
    12d8:	0c2000ef          	jal	139a <thread_switch>
  } else
    next_thread = 0;
}
    12dc:	60a2                	ld	ra,8(sp)
    12de:	6402                	ld	s0,0(sp)
    12e0:	0141                	addi	sp,sp,16
    12e2:	8082                	ret

00000000000012e4 <thread_create>:

void 
thread_create(void (*func)())
{
    12e4:	1101                	addi	sp,sp,-32
    12e6:	ec06                	sd	ra,24(sp)
    12e8:	e822                	sd	s0,16(sp)
    12ea:	e426                	sd	s1,8(sp)
    12ec:	e04a                	sd	s2,0(sp)
    12ee:	1000                	addi	s0,sp,32
    12f0:	892a                	mv	s2,a0
  struct thread *t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
    12f2:	00003797          	auipc	a5,0x3
    12f6:	db678793          	addi	a5,a5,-586 # 40a8 <all_thread+0x2010>
    12fa:	0000b597          	auipc	a1,0xb
    12fe:	dee58593          	addi	a1,a1,-530 # c0e8 <all_thread+0xa050>
    1302:	6609                	lui	a2,0x2
    1304:	0641                	addi	a2,a2,16 # 2010 <freep>
    if (t->state == FREE) break;
    1306:	873e                	mv	a4,a5
    1308:	ff07a683          	lw	a3,-16(a5)
    130c:	ce9d                	beqz	a3,134a <thread_create+0x66>
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
    130e:	97b2                	add	a5,a5,a2
    1310:	feb79be3          	bne	a5,a1,1306 <thread_create+0x22>
  }
  t->state = RUNNABLE;
    1314:	6489                	lui	s1,0x2
    1316:	94ba                	add	s1,s1,a4
    1318:	4789                	li	a5,2
    131a:	c09c                	sw	a5,0(s1)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
    131c:	6789                	lui	a5,0x2
    131e:	f9078793          	addi	a5,a5,-112 # 1f90 <digits+0xa10>
    1322:	973e                	add	a4,a4,a5
  return (struct context *)(top & ~(uint64)0xf);
    1324:	ff077513          	andi	a0,a4,-16
  // A never-run thread has no saved state, so construct one: thread_switch()
  // restores ra and sp, and `ret` then starts func on this thread's own stack.
  t->context = thread_context_slot(t);
    1328:	e488                	sd	a0,8(s1)
  memset(t->context, 0, sizeof(struct context));
    132a:	07000613          	li	a2,112
    132e:	4581                	li	a1,0
    1330:	f0aff0ef          	jal	a3a <memset>
  t->context->ra = (uint64)func;
    1334:	649c                	ld	a5,8(s1)
    1336:	0127b023          	sd	s2,0(a5)
  t->context->sp = (uint64)t->context;   // 16-byte aligned, grows down
    133a:	649c                	ld	a5,8(s1)
    133c:	e79c                	sd	a5,8(a5)
}
    133e:	60e2                	ld	ra,24(sp)
    1340:	6442                	ld	s0,16(sp)
    1342:	64a2                	ld	s1,8(sp)
    1344:	6902                	ld	s2,0(sp)
    1346:	6105                	addi	sp,sp,32
    1348:	8082                	ret
    134a:	7779                	lui	a4,0xffffe
    134c:	1741                	addi	a4,a4,-16 # ffffffffffffdff0 <all_thread+0xffffffffffffbf58>
    134e:	973e                	add	a4,a4,a5
    1350:	b7d1                	j	1314 <thread_create+0x30>

0000000000001352 <thread_yield>:

void 
thread_yield(void)
{
    1352:	1141                	addi	sp,sp,-16
    1354:	e406                	sd	ra,8(sp)
    1356:	e022                	sd	s0,0(sp)
    1358:	0800                	addi	s0,sp,16
  current_thread->state = RUNNABLE;
    135a:	00001797          	auipc	a5,0x1
    135e:	cbe7b783          	ld	a5,-834(a5) # 2018 <current_thread>
    1362:	6709                	lui	a4,0x2
    1364:	97ba                	add	a5,a5,a4
    1366:	4709                	li	a4,2
    1368:	c398                	sw	a4,0(a5)
  thread_schedule();
    136a:	ef7ff0ef          	jal	1260 <thread_schedule>
}
    136e:	60a2                	ld	ra,8(sp)
    1370:	6402                	ld	s0,0(sp)
    1372:	0141                	addi	sp,sp,16
    1374:	8082                	ret

0000000000001376 <thread_exit>:

void thread_exit(void) {
    1376:	1141                	addi	sp,sp,-16
    1378:	e406                	sd	ra,8(sp)
    137a:	e022                	sd	s0,0(sp)
    137c:	0800                	addi	s0,sp,16
  current_thread->state = FREE;
    137e:	00001797          	auipc	a5,0x1
    1382:	c9a7b783          	ld	a5,-870(a5) # 2018 <current_thread>
    1386:	6709                	lui	a4,0x2
    1388:	97ba                	add	a5,a5,a4
    138a:	0007a023          	sw	zero,0(a5)
  thread_schedule();
    138e:	ed3ff0ef          	jal	1260 <thread_schedule>
}
    1392:	60a2                	ld	ra,8(sp)
    1394:	6402                	ld	s0,0(sp)
    1396:	0141                	addi	sp,sp,16
    1398:	8082                	ret

000000000000139a <thread_switch>:
    139a:	00153023          	sd	ra,0(a0)
    139e:	00253423          	sd	sp,8(a0)
    13a2:	e900                	sd	s0,16(a0)
    13a4:	ed04                	sd	s1,24(a0)
    13a6:	03253023          	sd	s2,32(a0)
    13aa:	03353423          	sd	s3,40(a0)
    13ae:	03453823          	sd	s4,48(a0)
    13b2:	03553c23          	sd	s5,56(a0)
    13b6:	05653023          	sd	s6,64(a0)
    13ba:	05753423          	sd	s7,72(a0)
    13be:	05853823          	sd	s8,80(a0)
    13c2:	05953c23          	sd	s9,88(a0)
    13c6:	07a53023          	sd	s10,96(a0)
    13ca:	07b53423          	sd	s11,104(a0)
    13ce:	0005b083          	ld	ra,0(a1)
    13d2:	0085b103          	ld	sp,8(a1)
    13d6:	6980                	ld	s0,16(a1)
    13d8:	6d84                	ld	s1,24(a1)
    13da:	0205b903          	ld	s2,32(a1)
    13de:	0285b983          	ld	s3,40(a1)
    13e2:	0305ba03          	ld	s4,48(a1)
    13e6:	0385ba83          	ld	s5,56(a1)
    13ea:	0405bb03          	ld	s6,64(a1)
    13ee:	0485bb83          	ld	s7,72(a1)
    13f2:	0505bc03          	ld	s8,80(a1)
    13f6:	0585bc83          	ld	s9,88(a1)
    13fa:	0605bd03          	ld	s10,96(a1)
    13fe:	0685bd83          	ld	s11,104(a1)
    1402:	8082                	ret
