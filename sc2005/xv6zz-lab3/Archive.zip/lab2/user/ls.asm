
user/_ls:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <fmtname>:
#include "kernel/fs.h"
#include "kernel/fcntl.h"

char*
fmtname(char *path)
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	e426                	sd	s1,8(sp)
   8:	1000                	addi	s0,sp,32
   a:	84aa                	mv	s1,a0
  static char buf[DIRSIZ+1];
  char *p;

  // Find first character after last slash.
  for(p=path+strlen(path); p >= path && *p != '/'; p--)
   c:	2ae000ef          	jal	2ba <strlen>
  10:	02051793          	slli	a5,a0,0x20
  14:	9381                	srli	a5,a5,0x20
  16:	97a6                	add	a5,a5,s1
  18:	02f00693          	li	a3,47
  1c:	0097e963          	bltu	a5,s1,2e <fmtname+0x2e>
  20:	0007c703          	lbu	a4,0(a5)
  24:	00d70563          	beq	a4,a3,2e <fmtname+0x2e>
  28:	17fd                	addi	a5,a5,-1
  2a:	fe97fbe3          	bgeu	a5,s1,20 <fmtname+0x20>
    ;
  p++;
  2e:	00178493          	addi	s1,a5,1

  // Return blank-padded name.
  if(strlen(p) >= DIRSIZ)
  32:	8526                	mv	a0,s1
  34:	286000ef          	jal	2ba <strlen>
  38:	47b5                	li	a5,13
  3a:	00a7f863          	bgeu	a5,a0,4a <fmtname+0x4a>
    return p;
  memmove(buf, p, strlen(p));
  memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));
  return buf;
}
  3e:	8526                	mv	a0,s1
  40:	60e2                	ld	ra,24(sp)
  42:	6442                	ld	s0,16(sp)
  44:	64a2                	ld	s1,8(sp)
  46:	6105                	addi	sp,sp,32
  48:	8082                	ret
  4a:	e04a                	sd	s2,0(sp)
  memmove(buf, p, strlen(p));
  4c:	8526                	mv	a0,s1
  4e:	26c000ef          	jal	2ba <strlen>
  52:	862a                	mv	a2,a0
  54:	85a6                	mv	a1,s1
  56:	00001517          	auipc	a0,0x1
  5a:	fba50513          	addi	a0,a0,-70 # 1010 <buf.0>
  5e:	3d8000ef          	jal	436 <memmove>
  memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));
  62:	8526                	mv	a0,s1
  64:	256000ef          	jal	2ba <strlen>
  68:	892a                	mv	s2,a0
  6a:	8526                	mv	a0,s1
  6c:	24e000ef          	jal	2ba <strlen>
  70:	02091793          	slli	a5,s2,0x20
  74:	9381                	srli	a5,a5,0x20
  76:	4639                	li	a2,14
  78:	9e09                	subw	a2,a2,a0
  7a:	02000593          	li	a1,32
  7e:	00001517          	auipc	a0,0x1
  82:	f9250513          	addi	a0,a0,-110 # 1010 <buf.0>
  86:	953e                	add	a0,a0,a5
  88:	25e000ef          	jal	2e6 <memset>
  return buf;
  8c:	00001497          	auipc	s1,0x1
  90:	f8448493          	addi	s1,s1,-124 # 1010 <buf.0>
  94:	6902                	ld	s2,0(sp)
  96:	b765                	j	3e <fmtname+0x3e>

0000000000000098 <ls>:

void
ls(char *path)
{
  98:	da010113          	addi	sp,sp,-608
  9c:	24113c23          	sd	ra,600(sp)
  a0:	24813823          	sd	s0,592(sp)
  a4:	25213023          	sd	s2,576(sp)
  a8:	1480                	addi	s0,sp,608
  aa:	892a                	mv	s2,a0
  char buf[512], *p;
  int fd;
  struct dirent de;
  struct stat st;

  if((fd = open(path, O_RDONLY)) < 0){
  ac:	4581                	li	a1,0
  ae:	476000ef          	jal	524 <open>
  b2:	06054363          	bltz	a0,118 <ls+0x80>
  b6:	24913423          	sd	s1,584(sp)
  ba:	84aa                	mv	s1,a0
    fprintf(2, "ls: cannot open %s\n", path);
    return;
  }

  if(fstat(fd, &st) < 0){
  bc:	da840593          	addi	a1,s0,-600
  c0:	47c000ef          	jal	53c <fstat>
  c4:	06054363          	bltz	a0,12a <ls+0x92>
    fprintf(2, "ls: cannot stat %s\n", path);
    close(fd);
    return;
  }

  switch(st.type){
  c8:	db041783          	lh	a5,-592(s0)
  cc:	4705                	li	a4,1
  ce:	06e78c63          	beq	a5,a4,146 <ls+0xae>
  d2:	37f9                	addiw	a5,a5,-2
  d4:	17c2                	slli	a5,a5,0x30
  d6:	93c1                	srli	a5,a5,0x30
  d8:	02f76263          	bltu	a4,a5,fc <ls+0x64>
  case T_DEVICE:
  case T_FILE:
    printf("%s %d %d %d\n", fmtname(path), st.type, st.ino, (int) st.size);
  dc:	854a                	mv	a0,s2
  de:	f23ff0ef          	jal	0 <fmtname>
  e2:	85aa                	mv	a1,a0
  e4:	db842703          	lw	a4,-584(s0)
  e8:	dac42683          	lw	a3,-596(s0)
  ec:	db041603          	lh	a2,-592(s0)
  f0:	00001517          	auipc	a0,0x1
  f4:	bf050513          	addi	a0,a0,-1040 # ce0 <thread_switch+0x9a>
  f8:	02f000ef          	jal	926 <printf>
      }
      printf("%s %d %d %d\n", fmtname(buf), st.type, st.ino, (int) st.size);
    }
    break;
  }
  close(fd);
  fc:	8526                	mv	a0,s1
  fe:	40e000ef          	jal	50c <close>
 102:	24813483          	ld	s1,584(sp)
}
 106:	25813083          	ld	ra,600(sp)
 10a:	25013403          	ld	s0,592(sp)
 10e:	24013903          	ld	s2,576(sp)
 112:	26010113          	addi	sp,sp,608
 116:	8082                	ret
    fprintf(2, "ls: cannot open %s\n", path);
 118:	864a                	mv	a2,s2
 11a:	00001597          	auipc	a1,0x1
 11e:	b9658593          	addi	a1,a1,-1130 # cb0 <thread_switch+0x6a>
 122:	4509                	li	a0,2
 124:	7d8000ef          	jal	8fc <fprintf>
    return;
 128:	bff9                	j	106 <ls+0x6e>
    fprintf(2, "ls: cannot stat %s\n", path);
 12a:	864a                	mv	a2,s2
 12c:	00001597          	auipc	a1,0x1
 130:	b9c58593          	addi	a1,a1,-1124 # cc8 <thread_switch+0x82>
 134:	4509                	li	a0,2
 136:	7c6000ef          	jal	8fc <fprintf>
    close(fd);
 13a:	8526                	mv	a0,s1
 13c:	3d0000ef          	jal	50c <close>
    return;
 140:	24813483          	ld	s1,584(sp)
 144:	b7c9                	j	106 <ls+0x6e>
    if(strlen(path) + 1 + DIRSIZ + 1 > sizeof buf){
 146:	854a                	mv	a0,s2
 148:	172000ef          	jal	2ba <strlen>
 14c:	2541                	addiw	a0,a0,16
 14e:	20000793          	li	a5,512
 152:	00a7f963          	bgeu	a5,a0,164 <ls+0xcc>
      printf("ls: path too long\n");
 156:	00001517          	auipc	a0,0x1
 15a:	b9a50513          	addi	a0,a0,-1126 # cf0 <thread_switch+0xaa>
 15e:	7c8000ef          	jal	926 <printf>
      break;
 162:	bf69                	j	fc <ls+0x64>
 164:	23313c23          	sd	s3,568(sp)
    strcpy(buf, path);
 168:	85ca                	mv	a1,s2
 16a:	dd040513          	addi	a0,s0,-560
 16e:	0fc000ef          	jal	26a <strcpy>
    p = buf+strlen(buf);
 172:	dd040513          	addi	a0,s0,-560
 176:	144000ef          	jal	2ba <strlen>
 17a:	1502                	slli	a0,a0,0x20
 17c:	9101                	srli	a0,a0,0x20
 17e:	dd040793          	addi	a5,s0,-560
 182:	00a78733          	add	a4,a5,a0
 186:	893a                	mv	s2,a4
    *p++ = '/';
 188:	00170793          	addi	a5,a4,1
 18c:	89be                	mv	s3,a5
 18e:	02f00793          	li	a5,47
 192:	00f70023          	sb	a5,0(a4)
    while(read(fd, &de, sizeof(de)) == sizeof(de)){
 196:	a809                	j	1a8 <ls+0x110>
        printf("ls: cannot stat %s\n", buf);
 198:	dd040593          	addi	a1,s0,-560
 19c:	00001517          	auipc	a0,0x1
 1a0:	b2c50513          	addi	a0,a0,-1236 # cc8 <thread_switch+0x82>
 1a4:	782000ef          	jal	926 <printf>
    while(read(fd, &de, sizeof(de)) == sizeof(de)){
 1a8:	4641                	li	a2,16
 1aa:	dc040593          	addi	a1,s0,-576
 1ae:	8526                	mv	a0,s1
 1b0:	34c000ef          	jal	4fc <read>
 1b4:	47c1                	li	a5,16
 1b6:	04f51763          	bne	a0,a5,204 <ls+0x16c>
      if(de.inum == 0)
 1ba:	dc045783          	lhu	a5,-576(s0)
 1be:	d7ed                	beqz	a5,1a8 <ls+0x110>
      memmove(p, de.name, DIRSIZ);
 1c0:	4639                	li	a2,14
 1c2:	dc240593          	addi	a1,s0,-574
 1c6:	854e                	mv	a0,s3
 1c8:	26e000ef          	jal	436 <memmove>
      p[DIRSIZ] = 0;
 1cc:	000907a3          	sb	zero,15(s2)
      if(stat(buf, &st) < 0){
 1d0:	da840593          	addi	a1,s0,-600
 1d4:	dd040513          	addi	a0,s0,-560
 1d8:	1d6000ef          	jal	3ae <stat>
 1dc:	fa054ee3          	bltz	a0,198 <ls+0x100>
      printf("%s %d %d %d\n", fmtname(buf), st.type, st.ino, (int) st.size);
 1e0:	dd040513          	addi	a0,s0,-560
 1e4:	e1dff0ef          	jal	0 <fmtname>
 1e8:	85aa                	mv	a1,a0
 1ea:	db842703          	lw	a4,-584(s0)
 1ee:	dac42683          	lw	a3,-596(s0)
 1f2:	db041603          	lh	a2,-592(s0)
 1f6:	00001517          	auipc	a0,0x1
 1fa:	aea50513          	addi	a0,a0,-1302 # ce0 <thread_switch+0x9a>
 1fe:	728000ef          	jal	926 <printf>
 202:	b75d                	j	1a8 <ls+0x110>
 204:	23813983          	ld	s3,568(sp)
 208:	bdd5                	j	fc <ls+0x64>

000000000000020a <main>:

int
main(int argc, char *argv[])
{
 20a:	1101                	addi	sp,sp,-32
 20c:	ec06                	sd	ra,24(sp)
 20e:	e822                	sd	s0,16(sp)
 210:	1000                	addi	s0,sp,32
  int i;

  if(argc < 2){
 212:	4785                	li	a5,1
 214:	02a7d763          	bge	a5,a0,242 <main+0x38>
 218:	e426                	sd	s1,8(sp)
 21a:	e04a                	sd	s2,0(sp)
 21c:	00858493          	addi	s1,a1,8
 220:	ffe5091b          	addiw	s2,a0,-2
 224:	02091793          	slli	a5,s2,0x20
 228:	01d7d913          	srli	s2,a5,0x1d
 22c:	05c1                	addi	a1,a1,16
 22e:	992e                	add	s2,s2,a1
    ls(".");
    exit(0);
  }
  for(i=1; i<argc; i++)
    ls(argv[i]);
 230:	6088                	ld	a0,0(s1)
 232:	e67ff0ef          	jal	98 <ls>
  for(i=1; i<argc; i++)
 236:	04a1                	addi	s1,s1,8
 238:	ff249ce3          	bne	s1,s2,230 <main+0x26>
  exit(0);
 23c:	4501                	li	a0,0
 23e:	2a6000ef          	jal	4e4 <exit>
 242:	e426                	sd	s1,8(sp)
 244:	e04a                	sd	s2,0(sp)
    ls(".");
 246:	00001517          	auipc	a0,0x1
 24a:	ac250513          	addi	a0,a0,-1342 # d08 <thread_switch+0xc2>
 24e:	e4bff0ef          	jal	98 <ls>
    exit(0);
 252:	4501                	li	a0,0
 254:	290000ef          	jal	4e4 <exit>

0000000000000258 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 258:	1141                	addi	sp,sp,-16
 25a:	e406                	sd	ra,8(sp)
 25c:	e022                	sd	s0,0(sp)
 25e:	0800                	addi	s0,sp,16
  extern int main();
  main();
 260:	fabff0ef          	jal	20a <main>
  exit(0);
 264:	4501                	li	a0,0
 266:	27e000ef          	jal	4e4 <exit>

000000000000026a <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 26a:	1141                	addi	sp,sp,-16
 26c:	e406                	sd	ra,8(sp)
 26e:	e022                	sd	s0,0(sp)
 270:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 272:	87aa                	mv	a5,a0
 274:	0585                	addi	a1,a1,1
 276:	0785                	addi	a5,a5,1
 278:	fff5c703          	lbu	a4,-1(a1)
 27c:	fee78fa3          	sb	a4,-1(a5)
 280:	fb75                	bnez	a4,274 <strcpy+0xa>
    ;
  return os;
}
 282:	60a2                	ld	ra,8(sp)
 284:	6402                	ld	s0,0(sp)
 286:	0141                	addi	sp,sp,16
 288:	8082                	ret

000000000000028a <strcmp>:

int
strcmp(const char *p, const char *q)
{
 28a:	1141                	addi	sp,sp,-16
 28c:	e406                	sd	ra,8(sp)
 28e:	e022                	sd	s0,0(sp)
 290:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 292:	00054783          	lbu	a5,0(a0)
 296:	cb91                	beqz	a5,2aa <strcmp+0x20>
 298:	0005c703          	lbu	a4,0(a1)
 29c:	00f71763          	bne	a4,a5,2aa <strcmp+0x20>
    p++, q++;
 2a0:	0505                	addi	a0,a0,1
 2a2:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 2a4:	00054783          	lbu	a5,0(a0)
 2a8:	fbe5                	bnez	a5,298 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 2aa:	0005c503          	lbu	a0,0(a1)
}
 2ae:	40a7853b          	subw	a0,a5,a0
 2b2:	60a2                	ld	ra,8(sp)
 2b4:	6402                	ld	s0,0(sp)
 2b6:	0141                	addi	sp,sp,16
 2b8:	8082                	ret

00000000000002ba <strlen>:

uint
strlen(const char *s)
{
 2ba:	1141                	addi	sp,sp,-16
 2bc:	e406                	sd	ra,8(sp)
 2be:	e022                	sd	s0,0(sp)
 2c0:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 2c2:	00054783          	lbu	a5,0(a0)
 2c6:	cf91                	beqz	a5,2e2 <strlen+0x28>
 2c8:	00150793          	addi	a5,a0,1
 2cc:	86be                	mv	a3,a5
 2ce:	0785                	addi	a5,a5,1
 2d0:	fff7c703          	lbu	a4,-1(a5)
 2d4:	ff65                	bnez	a4,2cc <strlen+0x12>
 2d6:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 2da:	60a2                	ld	ra,8(sp)
 2dc:	6402                	ld	s0,0(sp)
 2de:	0141                	addi	sp,sp,16
 2e0:	8082                	ret
  for(n = 0; s[n]; n++)
 2e2:	4501                	li	a0,0
 2e4:	bfdd                	j	2da <strlen+0x20>

00000000000002e6 <memset>:

void*
memset(void *dst, int c, uint n)
{
 2e6:	1141                	addi	sp,sp,-16
 2e8:	e406                	sd	ra,8(sp)
 2ea:	e022                	sd	s0,0(sp)
 2ec:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 2ee:	ca19                	beqz	a2,304 <memset+0x1e>
 2f0:	87aa                	mv	a5,a0
 2f2:	1602                	slli	a2,a2,0x20
 2f4:	9201                	srli	a2,a2,0x20
 2f6:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 2fa:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 2fe:	0785                	addi	a5,a5,1
 300:	fee79de3          	bne	a5,a4,2fa <memset+0x14>
  }
  return dst;
}
 304:	60a2                	ld	ra,8(sp)
 306:	6402                	ld	s0,0(sp)
 308:	0141                	addi	sp,sp,16
 30a:	8082                	ret

000000000000030c <strchr>:

char*
strchr(const char *s, char c)
{
 30c:	1141                	addi	sp,sp,-16
 30e:	e406                	sd	ra,8(sp)
 310:	e022                	sd	s0,0(sp)
 312:	0800                	addi	s0,sp,16
  for(; *s; s++)
 314:	00054783          	lbu	a5,0(a0)
 318:	c799                	beqz	a5,326 <strchr+0x1a>
    if(*s == c)
 31a:	00f58763          	beq	a1,a5,328 <strchr+0x1c>
  for(; *s; s++)
 31e:	0505                	addi	a0,a0,1
 320:	00054783          	lbu	a5,0(a0)
 324:	fbfd                	bnez	a5,31a <strchr+0xe>
      return (char*)s;
  return 0;
 326:	4501                	li	a0,0
}
 328:	60a2                	ld	ra,8(sp)
 32a:	6402                	ld	s0,0(sp)
 32c:	0141                	addi	sp,sp,16
 32e:	8082                	ret

0000000000000330 <gets>:

char*
gets(char *buf, int max)
{
 330:	711d                	addi	sp,sp,-96
 332:	ec86                	sd	ra,88(sp)
 334:	e8a2                	sd	s0,80(sp)
 336:	e4a6                	sd	s1,72(sp)
 338:	e0ca                	sd	s2,64(sp)
 33a:	fc4e                	sd	s3,56(sp)
 33c:	f852                	sd	s4,48(sp)
 33e:	f456                	sd	s5,40(sp)
 340:	f05a                	sd	s6,32(sp)
 342:	ec5e                	sd	s7,24(sp)
 344:	e862                	sd	s8,16(sp)
 346:	1080                	addi	s0,sp,96
 348:	8baa                	mv	s7,a0
 34a:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 34c:	892a                	mv	s2,a0
 34e:	4481                	li	s1,0
    cc = read(0, &c, 1);
 350:	faf40b13          	addi	s6,s0,-81
 354:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 356:	8c26                	mv	s8,s1
 358:	0014899b          	addiw	s3,s1,1
 35c:	84ce                	mv	s1,s3
 35e:	0349d863          	bge	s3,s4,38e <gets+0x5e>
    cc = read(0, &c, 1);
 362:	8656                	mv	a2,s5
 364:	85da                	mv	a1,s6
 366:	4501                	li	a0,0
 368:	194000ef          	jal	4fc <read>
    if(cc < 1)
 36c:	02a05163          	blez	a0,38e <gets+0x5e>
      break;
    buf[i++] = c;
 370:	faf44783          	lbu	a5,-81(s0)
 374:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 378:	0905                	addi	s2,s2,1
 37a:	ff678713          	addi	a4,a5,-10
 37e:	00173713          	seqz	a4,a4
 382:	17cd                	addi	a5,a5,-13
 384:	0017b793          	seqz	a5,a5
 388:	8fd9                	or	a5,a5,a4
 38a:	d7f1                	beqz	a5,356 <gets+0x26>
    buf[i++] = c;
 38c:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 38e:	9c5e                	add	s8,s8,s7
 390:	000c0023          	sb	zero,0(s8)
  return buf;
}
 394:	855e                	mv	a0,s7
 396:	60e6                	ld	ra,88(sp)
 398:	6446                	ld	s0,80(sp)
 39a:	64a6                	ld	s1,72(sp)
 39c:	6906                	ld	s2,64(sp)
 39e:	79e2                	ld	s3,56(sp)
 3a0:	7a42                	ld	s4,48(sp)
 3a2:	7aa2                	ld	s5,40(sp)
 3a4:	7b02                	ld	s6,32(sp)
 3a6:	6be2                	ld	s7,24(sp)
 3a8:	6c42                	ld	s8,16(sp)
 3aa:	6125                	addi	sp,sp,96
 3ac:	8082                	ret

00000000000003ae <stat>:

int
stat(const char *n, struct stat *st)
{
 3ae:	1101                	addi	sp,sp,-32
 3b0:	ec06                	sd	ra,24(sp)
 3b2:	e822                	sd	s0,16(sp)
 3b4:	e04a                	sd	s2,0(sp)
 3b6:	1000                	addi	s0,sp,32
 3b8:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 3ba:	4581                	li	a1,0
 3bc:	168000ef          	jal	524 <open>
  if(fd < 0)
 3c0:	02054263          	bltz	a0,3e4 <stat+0x36>
 3c4:	e426                	sd	s1,8(sp)
 3c6:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 3c8:	85ca                	mv	a1,s2
 3ca:	172000ef          	jal	53c <fstat>
 3ce:	892a                	mv	s2,a0
  close(fd);
 3d0:	8526                	mv	a0,s1
 3d2:	13a000ef          	jal	50c <close>
  return r;
 3d6:	64a2                	ld	s1,8(sp)
}
 3d8:	854a                	mv	a0,s2
 3da:	60e2                	ld	ra,24(sp)
 3dc:	6442                	ld	s0,16(sp)
 3de:	6902                	ld	s2,0(sp)
 3e0:	6105                	addi	sp,sp,32
 3e2:	8082                	ret
    return -1;
 3e4:	57fd                	li	a5,-1
 3e6:	893e                	mv	s2,a5
 3e8:	bfc5                	j	3d8 <stat+0x2a>

00000000000003ea <atoi>:

int
atoi(const char *s)
{
 3ea:	1141                	addi	sp,sp,-16
 3ec:	e406                	sd	ra,8(sp)
 3ee:	e022                	sd	s0,0(sp)
 3f0:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 3f2:	00054683          	lbu	a3,0(a0)
 3f6:	fd06879b          	addiw	a5,a3,-48
 3fa:	0ff7f793          	zext.b	a5,a5
 3fe:	4625                	li	a2,9
 400:	02f66963          	bltu	a2,a5,432 <atoi+0x48>
 404:	872a                	mv	a4,a0
  n = 0;
 406:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 408:	0705                	addi	a4,a4,1
 40a:	0025179b          	slliw	a5,a0,0x2
 40e:	9fa9                	addw	a5,a5,a0
 410:	0017979b          	slliw	a5,a5,0x1
 414:	9fb5                	addw	a5,a5,a3
 416:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 41a:	00074683          	lbu	a3,0(a4)
 41e:	fd06879b          	addiw	a5,a3,-48
 422:	0ff7f793          	zext.b	a5,a5
 426:	fef671e3          	bgeu	a2,a5,408 <atoi+0x1e>
  return n;
}
 42a:	60a2                	ld	ra,8(sp)
 42c:	6402                	ld	s0,0(sp)
 42e:	0141                	addi	sp,sp,16
 430:	8082                	ret
  n = 0;
 432:	4501                	li	a0,0
 434:	bfdd                	j	42a <atoi+0x40>

0000000000000436 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 436:	1141                	addi	sp,sp,-16
 438:	e406                	sd	ra,8(sp)
 43a:	e022                	sd	s0,0(sp)
 43c:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 43e:	02b57563          	bgeu	a0,a1,468 <memmove+0x32>
    while(n-- > 0)
 442:	00c05f63          	blez	a2,460 <memmove+0x2a>
 446:	1602                	slli	a2,a2,0x20
 448:	9201                	srli	a2,a2,0x20
 44a:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 44e:	872a                	mv	a4,a0
      *dst++ = *src++;
 450:	0585                	addi	a1,a1,1
 452:	0705                	addi	a4,a4,1
 454:	fff5c683          	lbu	a3,-1(a1)
 458:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 45c:	fee79ae3          	bne	a5,a4,450 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 460:	60a2                	ld	ra,8(sp)
 462:	6402                	ld	s0,0(sp)
 464:	0141                	addi	sp,sp,16
 466:	8082                	ret
    while(n-- > 0)
 468:	fec05ce3          	blez	a2,460 <memmove+0x2a>
    dst += n;
 46c:	00c50733          	add	a4,a0,a2
    src += n;
 470:	95b2                	add	a1,a1,a2
 472:	fff6079b          	addiw	a5,a2,-1
 476:	1782                	slli	a5,a5,0x20
 478:	9381                	srli	a5,a5,0x20
 47a:	fff7c793          	not	a5,a5
 47e:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 480:	15fd                	addi	a1,a1,-1
 482:	177d                	addi	a4,a4,-1
 484:	0005c683          	lbu	a3,0(a1)
 488:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 48c:	fef71ae3          	bne	a4,a5,480 <memmove+0x4a>
 490:	bfc1                	j	460 <memmove+0x2a>

0000000000000492 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 492:	1141                	addi	sp,sp,-16
 494:	e406                	sd	ra,8(sp)
 496:	e022                	sd	s0,0(sp)
 498:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 49a:	ce19                	beqz	a2,4b8 <memcmp+0x26>
 49c:	1602                	slli	a2,a2,0x20
 49e:	9201                	srli	a2,a2,0x20
 4a0:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 4a4:	00054783          	lbu	a5,0(a0)
 4a8:	0005c703          	lbu	a4,0(a1)
 4ac:	00e79b63          	bne	a5,a4,4c2 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 4b0:	0505                	addi	a0,a0,1
    p2++;
 4b2:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 4b4:	fed518e3          	bne	a0,a3,4a4 <memcmp+0x12>
  }
  return 0;
 4b8:	4501                	li	a0,0
}
 4ba:	60a2                	ld	ra,8(sp)
 4bc:	6402                	ld	s0,0(sp)
 4be:	0141                	addi	sp,sp,16
 4c0:	8082                	ret
      return *p1 - *p2;
 4c2:	40e7853b          	subw	a0,a5,a4
 4c6:	bfd5                	j	4ba <memcmp+0x28>

00000000000004c8 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 4c8:	1141                	addi	sp,sp,-16
 4ca:	e406                	sd	ra,8(sp)
 4cc:	e022                	sd	s0,0(sp)
 4ce:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 4d0:	f67ff0ef          	jal	436 <memmove>
}
 4d4:	60a2                	ld	ra,8(sp)
 4d6:	6402                	ld	s0,0(sp)
 4d8:	0141                	addi	sp,sp,16
 4da:	8082                	ret

00000000000004dc <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 4dc:	4885                	li	a7,1
 ecall
 4de:	00000073          	ecall
 ret
 4e2:	8082                	ret

00000000000004e4 <exit>:
.global exit
exit:
 li a7, SYS_exit
 4e4:	4889                	li	a7,2
 ecall
 4e6:	00000073          	ecall
 ret
 4ea:	8082                	ret

00000000000004ec <wait>:
.global wait
wait:
 li a7, SYS_wait
 4ec:	488d                	li	a7,3
 ecall
 4ee:	00000073          	ecall
 ret
 4f2:	8082                	ret

00000000000004f4 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 4f4:	4891                	li	a7,4
 ecall
 4f6:	00000073          	ecall
 ret
 4fa:	8082                	ret

00000000000004fc <read>:
.global read
read:
 li a7, SYS_read
 4fc:	4895                	li	a7,5
 ecall
 4fe:	00000073          	ecall
 ret
 502:	8082                	ret

0000000000000504 <write>:
.global write
write:
 li a7, SYS_write
 504:	48c1                	li	a7,16
 ecall
 506:	00000073          	ecall
 ret
 50a:	8082                	ret

000000000000050c <close>:
.global close
close:
 li a7, SYS_close
 50c:	48d5                	li	a7,21
 ecall
 50e:	00000073          	ecall
 ret
 512:	8082                	ret

0000000000000514 <kill>:
.global kill
kill:
 li a7, SYS_kill
 514:	4899                	li	a7,6
 ecall
 516:	00000073          	ecall
 ret
 51a:	8082                	ret

000000000000051c <exec>:
.global exec
exec:
 li a7, SYS_exec
 51c:	489d                	li	a7,7
 ecall
 51e:	00000073          	ecall
 ret
 522:	8082                	ret

0000000000000524 <open>:
.global open
open:
 li a7, SYS_open
 524:	48bd                	li	a7,15
 ecall
 526:	00000073          	ecall
 ret
 52a:	8082                	ret

000000000000052c <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 52c:	48c5                	li	a7,17
 ecall
 52e:	00000073          	ecall
 ret
 532:	8082                	ret

0000000000000534 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 534:	48c9                	li	a7,18
 ecall
 536:	00000073          	ecall
 ret
 53a:	8082                	ret

000000000000053c <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 53c:	48a1                	li	a7,8
 ecall
 53e:	00000073          	ecall
 ret
 542:	8082                	ret

0000000000000544 <link>:
.global link
link:
 li a7, SYS_link
 544:	48cd                	li	a7,19
 ecall
 546:	00000073          	ecall
 ret
 54a:	8082                	ret

000000000000054c <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 54c:	48d1                	li	a7,20
 ecall
 54e:	00000073          	ecall
 ret
 552:	8082                	ret

0000000000000554 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 554:	48a5                	li	a7,9
 ecall
 556:	00000073          	ecall
 ret
 55a:	8082                	ret

000000000000055c <dup>:
.global dup
dup:
 li a7, SYS_dup
 55c:	48a9                	li	a7,10
 ecall
 55e:	00000073          	ecall
 ret
 562:	8082                	ret

0000000000000564 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 564:	48ad                	li	a7,11
 ecall
 566:	00000073          	ecall
 ret
 56a:	8082                	ret

000000000000056c <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 56c:	48b1                	li	a7,12
 ecall
 56e:	00000073          	ecall
 ret
 572:	8082                	ret

0000000000000574 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 574:	48b5                	li	a7,13
 ecall
 576:	00000073          	ecall
 ret
 57a:	8082                	ret

000000000000057c <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 57c:	48b9                	li	a7,14
 ecall
 57e:	00000073          	ecall
 ret
 582:	8082                	ret

0000000000000584 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 584:	1101                	addi	sp,sp,-32
 586:	ec06                	sd	ra,24(sp)
 588:	e822                	sd	s0,16(sp)
 58a:	1000                	addi	s0,sp,32
 58c:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 590:	4605                	li	a2,1
 592:	fef40593          	addi	a1,s0,-17
 596:	f6fff0ef          	jal	504 <write>
}
 59a:	60e2                	ld	ra,24(sp)
 59c:	6442                	ld	s0,16(sp)
 59e:	6105                	addi	sp,sp,32
 5a0:	8082                	ret

00000000000005a2 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 5a2:	715d                	addi	sp,sp,-80
 5a4:	e486                	sd	ra,72(sp)
 5a6:	e0a2                	sd	s0,64(sp)
 5a8:	f84a                	sd	s2,48(sp)
 5aa:	f44e                	sd	s3,40(sp)
 5ac:	0880                	addi	s0,sp,80
 5ae:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 5b0:	00d036b3          	snez	a3,a3
 5b4:	03f5d793          	srli	a5,a1,0x3f
 5b8:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 5ba:	0005871b          	sext.w	a4,a1
  neg = 0;
 5be:	4301                	li	t1,0
  if(sgn && xx < 0){
 5c0:	c681                	beqz	a3,5c8 <printint+0x26>
    x = -xx;
 5c2:	40b0073b          	negw	a4,a1
    neg = 1;
 5c6:	4305                	li	t1,1
  }

  i = 0;
 5c8:	fb840993          	addi	s3,s0,-72
  neg = 0;
 5cc:	85ce                	mv	a1,s3
  i = 0;
 5ce:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 5d0:	00000817          	auipc	a6,0x0
 5d4:	77080813          	addi	a6,a6,1904 # d40 <digits>
 5d8:	88b6                	mv	a7,a3
 5da:	0016851b          	addiw	a0,a3,1
 5de:	86aa                	mv	a3,a0
 5e0:	02c777bb          	remuw	a5,a4,a2
 5e4:	1782                	slli	a5,a5,0x20
 5e6:	9381                	srli	a5,a5,0x20
 5e8:	97c2                	add	a5,a5,a6
 5ea:	0007c783          	lbu	a5,0(a5)
 5ee:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 5f2:	87ba                	mv	a5,a4
 5f4:	02c7573b          	divuw	a4,a4,a2
 5f8:	0585                	addi	a1,a1,1
 5fa:	fcc7ffe3          	bgeu	a5,a2,5d8 <printint+0x36>
  if(neg)
 5fe:	00030b63          	beqz	t1,614 <printint+0x72>
    buf[i++] = '-';
 602:	fd040793          	addi	a5,s0,-48
 606:	953e                	add	a0,a0,a5
 608:	02d00793          	li	a5,45
 60c:	fef50423          	sb	a5,-24(a0)
 610:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 614:	02d05563          	blez	a3,63e <printint+0x9c>
 618:	fc26                	sd	s1,56(sp)
 61a:	36fd                	addiw	a3,a3,-1
 61c:	00d984b3          	add	s1,s3,a3
 620:	19fd                	addi	s3,s3,-1
 622:	99b6                	add	s3,s3,a3
 624:	1682                	slli	a3,a3,0x20
 626:	9281                	srli	a3,a3,0x20
 628:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 62c:	0004c583          	lbu	a1,0(s1)
 630:	854a                	mv	a0,s2
 632:	f53ff0ef          	jal	584 <putc>
  while(--i >= 0)
 636:	14fd                	addi	s1,s1,-1
 638:	ff349ae3          	bne	s1,s3,62c <printint+0x8a>
 63c:	74e2                	ld	s1,56(sp)
}
 63e:	60a6                	ld	ra,72(sp)
 640:	6406                	ld	s0,64(sp)
 642:	7942                	ld	s2,48(sp)
 644:	79a2                	ld	s3,40(sp)
 646:	6161                	addi	sp,sp,80
 648:	8082                	ret

000000000000064a <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 64a:	711d                	addi	sp,sp,-96
 64c:	ec86                	sd	ra,88(sp)
 64e:	e8a2                	sd	s0,80(sp)
 650:	e4a6                	sd	s1,72(sp)
 652:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 654:	0005c483          	lbu	s1,0(a1)
 658:	28048263          	beqz	s1,8dc <vprintf+0x292>
 65c:	e0ca                	sd	s2,64(sp)
 65e:	fc4e                	sd	s3,56(sp)
 660:	f852                	sd	s4,48(sp)
 662:	f456                	sd	s5,40(sp)
 664:	f05a                	sd	s6,32(sp)
 666:	ec5e                	sd	s7,24(sp)
 668:	e862                	sd	s8,16(sp)
 66a:	8b2a                	mv	s6,a0
 66c:	8a2e                	mv	s4,a1
 66e:	8bb2                	mv	s7,a2
  state = 0;
 670:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 672:	4901                	li	s2,0
 674:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 676:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 67a:	06400c13          	li	s8,100
 67e:	a00d                	j	6a0 <vprintf+0x56>
        putc(fd, c0);
 680:	85a6                	mv	a1,s1
 682:	855a                	mv	a0,s6
 684:	f01ff0ef          	jal	584 <putc>
 688:	a019                	j	68e <vprintf+0x44>
    } else if(state == '%'){
 68a:	03598363          	beq	s3,s5,6b0 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 68e:	0019079b          	addiw	a5,s2,1
 692:	893e                	mv	s2,a5
 694:	873e                	mv	a4,a5
 696:	97d2                	add	a5,a5,s4
 698:	0007c483          	lbu	s1,0(a5)
 69c:	22048963          	beqz	s1,8ce <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 6a0:	0004879b          	sext.w	a5,s1
    if(state == 0){
 6a4:	fe0993e3          	bnez	s3,68a <vprintf+0x40>
      if(c0 == '%'){
 6a8:	fd579ce3          	bne	a5,s5,680 <vprintf+0x36>
        state = '%';
 6ac:	89be                	mv	s3,a5
 6ae:	b7c5                	j	68e <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 6b0:	00ea06b3          	add	a3,s4,a4
 6b4:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 6b8:	22060763          	beqz	a2,8e6 <vprintf+0x29c>
      if(c0 == 'd'){
 6bc:	0b878363          	beq	a5,s8,762 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 6c0:	f9478693          	addi	a3,a5,-108
 6c4:	0016b693          	seqz	a3,a3
 6c8:	f9c60593          	addi	a1,a2,-100
 6cc:	0015b593          	seqz	a1,a1
 6d0:	8df5                	and	a1,a1,a3
 6d2:	e5c5                	bnez	a1,77a <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 6d4:	9752                	add	a4,a4,s4
 6d6:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 6da:	f9460713          	addi	a4,a2,-108
 6de:	00173713          	seqz	a4,a4
 6e2:	8f75                	and	a4,a4,a3
 6e4:	f9c50593          	addi	a1,a0,-100
 6e8:	0015b593          	seqz	a1,a1
 6ec:	8df9                	and	a1,a1,a4
 6ee:	e1dd                	bnez	a1,794 <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 6f0:	07500593          	li	a1,117
 6f4:	0ab78d63          	beq	a5,a1,7ae <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 6f8:	f8b60593          	addi	a1,a2,-117
 6fc:	0015b593          	seqz	a1,a1
 700:	8df5                	and	a1,a1,a3
 702:	e1f1                	bnez	a1,7c6 <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 704:	f8b50593          	addi	a1,a0,-117
 708:	0015b593          	seqz	a1,a1
 70c:	8df9                	and	a1,a1,a4
 70e:	e9e9                	bnez	a1,7e0 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 710:	07800593          	li	a1,120
 714:	0eb78363          	beq	a5,a1,7fa <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 718:	f8860613          	addi	a2,a2,-120
 71c:	00163613          	seqz	a2,a2
 720:	8ef1                	and	a3,a3,a2
 722:	0e069863          	bnez	a3,812 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 726:	f8850513          	addi	a0,a0,-120
 72a:	00153513          	seqz	a0,a0
 72e:	8f69                	and	a4,a4,a0
 730:	0e071e63          	bnez	a4,82c <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 734:	07000713          	li	a4,112
 738:	10e78663          	beq	a5,a4,844 <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 73c:	07300713          	li	a4,115
 740:	14e78663          	beq	a5,a4,88c <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 744:	02500713          	li	a4,37
 748:	16e78e63          	beq	a5,a4,8c4 <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 74c:	02500593          	li	a1,37
 750:	855a                	mv	a0,s6
 752:	e33ff0ef          	jal	584 <putc>
        putc(fd, c0);
 756:	85a6                	mv	a1,s1
 758:	855a                	mv	a0,s6
 75a:	e2bff0ef          	jal	584 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 75e:	4981                	li	s3,0
 760:	b73d                	j	68e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 762:	008b8493          	addi	s1,s7,8
 766:	4685                	li	a3,1
 768:	4629                	li	a2,10
 76a:	000ba583          	lw	a1,0(s7)
 76e:	855a                	mv	a0,s6
 770:	e33ff0ef          	jal	5a2 <printint>
 774:	8ba6                	mv	s7,s1
      state = 0;
 776:	4981                	li	s3,0
 778:	bf19                	j	68e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 77a:	008b8493          	addi	s1,s7,8
 77e:	4685                	li	a3,1
 780:	4629                	li	a2,10
 782:	000bb583          	ld	a1,0(s7)
 786:	855a                	mv	a0,s6
 788:	e1bff0ef          	jal	5a2 <printint>
        i += 1;
 78c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 78e:	8ba6                	mv	s7,s1
      state = 0;
 790:	4981                	li	s3,0
 792:	bdf5                	j	68e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 794:	008b8493          	addi	s1,s7,8
 798:	4685                	li	a3,1
 79a:	4629                	li	a2,10
 79c:	000bb583          	ld	a1,0(s7)
 7a0:	855a                	mv	a0,s6
 7a2:	e01ff0ef          	jal	5a2 <printint>
        i += 2;
 7a6:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 7a8:	8ba6                	mv	s7,s1
      state = 0;
 7aa:	4981                	li	s3,0
        i += 2;
 7ac:	b5cd                	j	68e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 7ae:	008b8493          	addi	s1,s7,8
 7b2:	4681                	li	a3,0
 7b4:	4629                	li	a2,10
 7b6:	000ba583          	lw	a1,0(s7)
 7ba:	855a                	mv	a0,s6
 7bc:	de7ff0ef          	jal	5a2 <printint>
 7c0:	8ba6                	mv	s7,s1
      state = 0;
 7c2:	4981                	li	s3,0
 7c4:	b5e9                	j	68e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7c6:	008b8493          	addi	s1,s7,8
 7ca:	4681                	li	a3,0
 7cc:	4629                	li	a2,10
 7ce:	000bb583          	ld	a1,0(s7)
 7d2:	855a                	mv	a0,s6
 7d4:	dcfff0ef          	jal	5a2 <printint>
        i += 1;
 7d8:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 7da:	8ba6                	mv	s7,s1
      state = 0;
 7dc:	4981                	li	s3,0
 7de:	bd45                	j	68e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7e0:	008b8493          	addi	s1,s7,8
 7e4:	4681                	li	a3,0
 7e6:	4629                	li	a2,10
 7e8:	000bb583          	ld	a1,0(s7)
 7ec:	855a                	mv	a0,s6
 7ee:	db5ff0ef          	jal	5a2 <printint>
        i += 2;
 7f2:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 7f4:	8ba6                	mv	s7,s1
      state = 0;
 7f6:	4981                	li	s3,0
        i += 2;
 7f8:	bd59                	j	68e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 7fa:	008b8493          	addi	s1,s7,8
 7fe:	4681                	li	a3,0
 800:	4641                	li	a2,16
 802:	000ba583          	lw	a1,0(s7)
 806:	855a                	mv	a0,s6
 808:	d9bff0ef          	jal	5a2 <printint>
 80c:	8ba6                	mv	s7,s1
      state = 0;
 80e:	4981                	li	s3,0
 810:	bdbd                	j	68e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 812:	008b8493          	addi	s1,s7,8
 816:	4681                	li	a3,0
 818:	4641                	li	a2,16
 81a:	000bb583          	ld	a1,0(s7)
 81e:	855a                	mv	a0,s6
 820:	d83ff0ef          	jal	5a2 <printint>
        i += 1;
 824:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 826:	8ba6                	mv	s7,s1
      state = 0;
 828:	4981                	li	s3,0
 82a:	b595                	j	68e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 82c:	008b8493          	addi	s1,s7,8
 830:	4641                	li	a2,16
 832:	000bb583          	ld	a1,0(s7)
 836:	855a                	mv	a0,s6
 838:	d6bff0ef          	jal	5a2 <printint>
        i += 2;
 83c:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 83e:	8ba6                	mv	s7,s1
      state = 0;
 840:	4981                	li	s3,0
        i += 2;
 842:	b5b1                	j	68e <vprintf+0x44>
 844:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 846:	008b8793          	addi	a5,s7,8
 84a:	8cbe                	mv	s9,a5
 84c:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 850:	03000593          	li	a1,48
 854:	855a                	mv	a0,s6
 856:	d2fff0ef          	jal	584 <putc>
  putc(fd, 'x');
 85a:	07800593          	li	a1,120
 85e:	855a                	mv	a0,s6
 860:	d25ff0ef          	jal	584 <putc>
 864:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 866:	00000b97          	auipc	s7,0x0
 86a:	4dab8b93          	addi	s7,s7,1242 # d40 <digits>
 86e:	03c9d793          	srli	a5,s3,0x3c
 872:	97de                	add	a5,a5,s7
 874:	0007c583          	lbu	a1,0(a5)
 878:	855a                	mv	a0,s6
 87a:	d0bff0ef          	jal	584 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 87e:	0992                	slli	s3,s3,0x4
 880:	34fd                	addiw	s1,s1,-1
 882:	f4f5                	bnez	s1,86e <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 884:	8be6                	mv	s7,s9
      state = 0;
 886:	4981                	li	s3,0
 888:	6ca2                	ld	s9,8(sp)
 88a:	b511                	j	68e <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 88c:	008b8993          	addi	s3,s7,8
 890:	000bb483          	ld	s1,0(s7)
 894:	cc91                	beqz	s1,8b0 <vprintf+0x266>
        for(; *s; s++)
 896:	0004c583          	lbu	a1,0(s1)
 89a:	c195                	beqz	a1,8be <vprintf+0x274>
          putc(fd, *s);
 89c:	855a                	mv	a0,s6
 89e:	ce7ff0ef          	jal	584 <putc>
        for(; *s; s++)
 8a2:	0485                	addi	s1,s1,1
 8a4:	0004c583          	lbu	a1,0(s1)
 8a8:	f9f5                	bnez	a1,89c <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 8aa:	8bce                	mv	s7,s3
      state = 0;
 8ac:	4981                	li	s3,0
 8ae:	b3c5                	j	68e <vprintf+0x44>
          s = "(null)";
 8b0:	00000497          	auipc	s1,0x0
 8b4:	46048493          	addi	s1,s1,1120 # d10 <thread_switch+0xca>
        for(; *s; s++)
 8b8:	02800593          	li	a1,40
 8bc:	b7c5                	j	89c <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 8be:	8bce                	mv	s7,s3
      state = 0;
 8c0:	4981                	li	s3,0
 8c2:	b3f1                	j	68e <vprintf+0x44>
        putc(fd, '%');
 8c4:	85be                	mv	a1,a5
 8c6:	855a                	mv	a0,s6
 8c8:	cbdff0ef          	jal	584 <putc>
 8cc:	bd49                	j	75e <vprintf+0x114>
 8ce:	6906                	ld	s2,64(sp)
 8d0:	79e2                	ld	s3,56(sp)
 8d2:	7a42                	ld	s4,48(sp)
 8d4:	7aa2                	ld	s5,40(sp)
 8d6:	7b02                	ld	s6,32(sp)
 8d8:	6be2                	ld	s7,24(sp)
 8da:	6c42                	ld	s8,16(sp)
    }
  }
}
 8dc:	60e6                	ld	ra,88(sp)
 8de:	6446                	ld	s0,80(sp)
 8e0:	64a6                	ld	s1,72(sp)
 8e2:	6125                	addi	sp,sp,96
 8e4:	8082                	ret
      if(c0 == 'd'){
 8e6:	06400713          	li	a4,100
 8ea:	e6e78ce3          	beq	a5,a4,762 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 8ee:	f9478693          	addi	a3,a5,-108
 8f2:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 8f6:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 8f8:	4701                	li	a4,0
 8fa:	bbdd                	j	6f0 <vprintf+0xa6>

00000000000008fc <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 8fc:	715d                	addi	sp,sp,-80
 8fe:	ec06                	sd	ra,24(sp)
 900:	e822                	sd	s0,16(sp)
 902:	1000                	addi	s0,sp,32
 904:	e010                	sd	a2,0(s0)
 906:	e414                	sd	a3,8(s0)
 908:	e818                	sd	a4,16(s0)
 90a:	ec1c                	sd	a5,24(s0)
 90c:	03043023          	sd	a6,32(s0)
 910:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 914:	8622                	mv	a2,s0
 916:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 91a:	d31ff0ef          	jal	64a <vprintf>
}
 91e:	60e2                	ld	ra,24(sp)
 920:	6442                	ld	s0,16(sp)
 922:	6161                	addi	sp,sp,80
 924:	8082                	ret

0000000000000926 <printf>:

void
printf(const char *fmt, ...)
{
 926:	711d                	addi	sp,sp,-96
 928:	ec06                	sd	ra,24(sp)
 92a:	e822                	sd	s0,16(sp)
 92c:	1000                	addi	s0,sp,32
 92e:	e40c                	sd	a1,8(s0)
 930:	e810                	sd	a2,16(s0)
 932:	ec14                	sd	a3,24(s0)
 934:	f018                	sd	a4,32(s0)
 936:	f41c                	sd	a5,40(s0)
 938:	03043823          	sd	a6,48(s0)
 93c:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 940:	00840613          	addi	a2,s0,8
 944:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 948:	85aa                	mv	a1,a0
 94a:	4505                	li	a0,1
 94c:	cffff0ef          	jal	64a <vprintf>
}
 950:	60e2                	ld	ra,24(sp)
 952:	6442                	ld	s0,16(sp)
 954:	6125                	addi	sp,sp,96
 956:	8082                	ret

0000000000000958 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 958:	1141                	addi	sp,sp,-16
 95a:	e406                	sd	ra,8(sp)
 95c:	e022                	sd	s0,0(sp)
 95e:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 960:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 964:	00000797          	auipc	a5,0x0
 968:	69c7b783          	ld	a5,1692(a5) # 1000 <freep>
 96c:	a095                	j	9d0 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 96e:	ff852583          	lw	a1,-8(a0)
 972:	6390                	ld	a2,0(a5)
 974:	02059813          	slli	a6,a1,0x20
 978:	01c85693          	srli	a3,a6,0x1c
 97c:	96ba                	add	a3,a3,a4
 97e:	02d60563          	beq	a2,a3,9a8 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 982:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 986:	4790                	lw	a2,8(a5)
 988:	02061593          	slli	a1,a2,0x20
 98c:	01c5d693          	srli	a3,a1,0x1c
 990:	96be                	add	a3,a3,a5
 992:	02d70263          	beq	a4,a3,9b6 <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 996:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 998:	00000717          	auipc	a4,0x0
 99c:	66f73423          	sd	a5,1640(a4) # 1000 <freep>
}
 9a0:	60a2                	ld	ra,8(sp)
 9a2:	6402                	ld	s0,0(sp)
 9a4:	0141                	addi	sp,sp,16
 9a6:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 9a8:	4614                	lw	a3,8(a2)
 9aa:	9ead                	addw	a3,a3,a1
 9ac:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 9b0:	6394                	ld	a3,0(a5)
 9b2:	6290                	ld	a2,0(a3)
 9b4:	b7f9                	j	982 <free+0x2a>
    p->s.size += bp->s.size;
 9b6:	ff852703          	lw	a4,-8(a0)
 9ba:	9f31                	addw	a4,a4,a2
 9bc:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 9be:	ff053703          	ld	a4,-16(a0)
 9c2:	bfd1                	j	996 <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9c4:	6394                	ld	a3,0(a5)
 9c6:	00d7e463          	bltu	a5,a3,9ce <free+0x76>
 9ca:	fad762e3          	bltu	a4,a3,96e <free+0x16>
 9ce:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9d0:	fee7fae3          	bgeu	a5,a4,9c4 <free+0x6c>
 9d4:	6394                	ld	a3,0(a5)
 9d6:	f8d76ce3          	bltu	a4,a3,96e <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9da:	f8d7fae3          	bgeu	a5,a3,96e <free+0x16>
 9de:	87b6                	mv	a5,a3
 9e0:	bfc5                	j	9d0 <free+0x78>

00000000000009e2 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 9e2:	7139                	addi	sp,sp,-64
 9e4:	fc06                	sd	ra,56(sp)
 9e6:	f822                	sd	s0,48(sp)
 9e8:	f04a                	sd	s2,32(sp)
 9ea:	ec4e                	sd	s3,24(sp)
 9ec:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 9ee:	02051993          	slli	s3,a0,0x20
 9f2:	0209d993          	srli	s3,s3,0x20
 9f6:	09bd                	addi	s3,s3,15
 9f8:	0049d993          	srli	s3,s3,0x4
 9fc:	2985                	addiw	s3,s3,1
 9fe:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 a00:	00000517          	auipc	a0,0x0
 a04:	60053503          	ld	a0,1536(a0) # 1000 <freep>
 a08:	c905                	beqz	a0,a38 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a0a:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a0c:	4798                	lw	a4,8(a5)
 a0e:	09377663          	bgeu	a4,s3,a9a <malloc+0xb8>
 a12:	f426                	sd	s1,40(sp)
 a14:	e852                	sd	s4,16(sp)
 a16:	e456                	sd	s5,8(sp)
 a18:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 a1a:	8a4e                	mv	s4,s3
 a1c:	6705                	lui	a4,0x1
 a1e:	00e9f363          	bgeu	s3,a4,a24 <malloc+0x42>
 a22:	6a05                	lui	s4,0x1
 a24:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 a28:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 a2c:	00000497          	auipc	s1,0x0
 a30:	5d448493          	addi	s1,s1,1492 # 1000 <freep>
  if(p == (char*)-1)
 a34:	5afd                	li	s5,-1
 a36:	a83d                	j	a74 <malloc+0x92>
 a38:	f426                	sd	s1,40(sp)
 a3a:	e852                	sd	s4,16(sp)
 a3c:	e456                	sd	s5,8(sp)
 a3e:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 a40:	00000797          	auipc	a5,0x0
 a44:	5e078793          	addi	a5,a5,1504 # 1020 <base>
 a48:	00000717          	auipc	a4,0x0
 a4c:	5af73c23          	sd	a5,1464(a4) # 1000 <freep>
 a50:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 a52:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 a56:	b7d1                	j	a1a <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 a58:	6398                	ld	a4,0(a5)
 a5a:	e118                	sd	a4,0(a0)
 a5c:	a899                	j	ab2 <malloc+0xd0>
  hp->s.size = nu;
 a5e:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 a62:	0541                	addi	a0,a0,16
 a64:	ef5ff0ef          	jal	958 <free>
  return freep;
 a68:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 a6a:	c125                	beqz	a0,aca <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a6c:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a6e:	4798                	lw	a4,8(a5)
 a70:	03277163          	bgeu	a4,s2,a92 <malloc+0xb0>
    if(p == freep)
 a74:	6098                	ld	a4,0(s1)
 a76:	853e                	mv	a0,a5
 a78:	fef71ae3          	bne	a4,a5,a6c <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 a7c:	8552                	mv	a0,s4
 a7e:	aefff0ef          	jal	56c <sbrk>
  if(p == (char*)-1)
 a82:	fd551ee3          	bne	a0,s5,a5e <malloc+0x7c>
        return 0;
 a86:	4501                	li	a0,0
 a88:	74a2                	ld	s1,40(sp)
 a8a:	6a42                	ld	s4,16(sp)
 a8c:	6aa2                	ld	s5,8(sp)
 a8e:	6b02                	ld	s6,0(sp)
 a90:	a03d                	j	abe <malloc+0xdc>
 a92:	74a2                	ld	s1,40(sp)
 a94:	6a42                	ld	s4,16(sp)
 a96:	6aa2                	ld	s5,8(sp)
 a98:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 a9a:	fae90fe3          	beq	s2,a4,a58 <malloc+0x76>
        p->s.size -= nunits;
 a9e:	4137073b          	subw	a4,a4,s3
 aa2:	c798                	sw	a4,8(a5)
        p += p->s.size;
 aa4:	02071693          	slli	a3,a4,0x20
 aa8:	01c6d713          	srli	a4,a3,0x1c
 aac:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 aae:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 ab2:	00000717          	auipc	a4,0x0
 ab6:	54a73723          	sd	a0,1358(a4) # 1000 <freep>
      return (void*)(p + 1);
 aba:	01078513          	addi	a0,a5,16
  }
}
 abe:	70e2                	ld	ra,56(sp)
 ac0:	7442                	ld	s0,48(sp)
 ac2:	7902                	ld	s2,32(sp)
 ac4:	69e2                	ld	s3,24(sp)
 ac6:	6121                	addi	sp,sp,64
 ac8:	8082                	ret
 aca:	74a2                	ld	s1,40(sp)
 acc:	6a42                	ld	s4,16(sp)
 ace:	6aa2                	ld	s5,8(sp)
 ad0:	6b02                	ld	s6,0(sp)
 ad2:	b7f5                	j	abe <malloc+0xdc>

0000000000000ad4 <thread_init>:
struct thread *current_thread;
extern void thread_switch(uint64, uint64);
              
void 
thread_init(void)
{
 ad4:	1141                	addi	sp,sp,-16
 ad6:	e406                	sd	ra,8(sp)
 ad8:	e022                	sd	s0,0(sp)
 ada:	0800                	addi	s0,sp,16
  // main() is thread 0, which will make the first invocation to
  // thread_schedule(). It needs a stack so that the first thread_switch() can
  // save thread 0's state.
  current_thread = &all_thread[0];
 adc:	00000797          	auipc	a5,0x0
 ae0:	55478793          	addi	a5,a5,1364 # 1030 <all_thread>
 ae4:	00000717          	auipc	a4,0x0
 ae8:	52f73223          	sd	a5,1316(a4) # 1008 <current_thread>
  current_thread->state = RUNNING;
 aec:	00002717          	auipc	a4,0x2
 af0:	54470713          	addi	a4,a4,1348 # 3030 <all_thread+0x2000>
 af4:	4785                	li	a5,1
 af6:	c31c                	sw	a5,0(a4)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 af8:	00002797          	auipc	a5,0x2
 afc:	4c878793          	addi	a5,a5,1224 # 2fc0 <all_thread+0x1f90>
  return (struct context *)(top & ~(uint64)0xf);
 b00:	9bc1                	andi	a5,a5,-16
  // Thread 0 runs on the process's own stack, but the first thread_switch()
  // still needs a writable place to save its context.
  current_thread->context = thread_context_slot(current_thread);
 b02:	e71c                	sd	a5,8(a4)
}
 b04:	60a2                	ld	ra,8(sp)
 b06:	6402                	ld	s0,0(sp)
 b08:	0141                	addi	sp,sp,16
 b0a:	8082                	ret

0000000000000b0c <thread_schedule>:

void 
thread_schedule(void)
{
 b0c:	1141                	addi	sp,sp,-16
 b0e:	e406                	sd	ra,8(sp)
 b10:	e022                	sd	s0,0(sp)
 b12:	0800                	addi	s0,sp,16
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
 b14:	00000597          	auipc	a1,0x0
 b18:	4f45b583          	ld	a1,1268(a1) # 1008 <current_thread>
 b1c:	6789                	lui	a5,0x2
 b1e:	07c1                	addi	a5,a5,16 # 2010 <all_thread+0xfe0>
 b20:	97ae                	add	a5,a5,a1
 b22:	4711                	li	a4,4
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
 b24:	00008897          	auipc	a7,0x8
 b28:	54c88893          	addi	a7,a7,1356 # 9070 <all_thread+0x8040>
      t = all_thread;
    if(t->state == RUNNABLE) {
 b2c:	6809                	lui	a6,0x2
 b2e:	4509                	li	a0,2
      next_thread = t;
      break;
    }
    t = t + 1;
 b30:	01080613          	addi	a2,a6,16 # 2010 <all_thread+0xfe0>
 b34:	a809                	j	b46 <thread_schedule+0x3a>
    if(t->state == RUNNABLE) {
 b36:	010786b3          	add	a3,a5,a6
 b3a:	4294                	lw	a3,0(a3)
 b3c:	02a68563          	beq	a3,a0,b66 <thread_schedule+0x5a>
    t = t + 1;
 b40:	97b2                	add	a5,a5,a2
  for(int i = 0; i < MAX_THREAD; i++){
 b42:	377d                	addiw	a4,a4,-1
 b44:	cb01                	beqz	a4,b54 <thread_schedule+0x48>
    if(t >= all_thread + MAX_THREAD)
 b46:	ff17e8e3          	bltu	a5,a7,b36 <thread_schedule+0x2a>
      t = all_thread;
 b4a:	00000797          	auipc	a5,0x0
 b4e:	4e678793          	addi	a5,a5,1254 # 1030 <all_thread>
 b52:	b7d5                	j	b36 <thread_schedule+0x2a>
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
 b54:	00000517          	auipc	a0,0x0
 b58:	1c450513          	addi	a0,a0,452 # d18 <thread_switch+0xd2>
 b5c:	dcbff0ef          	jal	926 <printf>
    exit(-1);
 b60:	557d                	li	a0,-1
 b62:	983ff0ef          	jal	4e4 <exit>
  }

  if (current_thread != next_thread) {         /* switch threads?  */
 b66:	02f58163          	beq	a1,a5,b88 <thread_schedule+0x7c>
    next_thread->state = RUNNING;
 b6a:	6689                	lui	a3,0x2
 b6c:	00d78733          	add	a4,a5,a3
 b70:	4605                	li	a2,1
 b72:	c310                	sw	a2,0(a4)
    t = current_thread;
    current_thread = next_thread;
 b74:	00000617          	auipc	a2,0x0
 b78:	48f63a23          	sd	a5,1172(a2) # 1008 <current_thread>
    thread_switch((uint64)t->context, (uint64)next_thread->context);
 b7c:	00d587b3          	add	a5,a1,a3
 b80:	670c                	ld	a1,8(a4)
 b82:	6788                	ld	a0,8(a5)
 b84:	0c2000ef          	jal	c46 <thread_switch>
  } else
    next_thread = 0;
}
 b88:	60a2                	ld	ra,8(sp)
 b8a:	6402                	ld	s0,0(sp)
 b8c:	0141                	addi	sp,sp,16
 b8e:	8082                	ret

0000000000000b90 <thread_create>:

void 
thread_create(void (*func)())
{
 b90:	1101                	addi	sp,sp,-32
 b92:	ec06                	sd	ra,24(sp)
 b94:	e822                	sd	s0,16(sp)
 b96:	e426                	sd	s1,8(sp)
 b98:	e04a                	sd	s2,0(sp)
 b9a:	1000                	addi	s0,sp,32
 b9c:	892a                	mv	s2,a0
  struct thread *t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 b9e:	00002797          	auipc	a5,0x2
 ba2:	4a278793          	addi	a5,a5,1186 # 3040 <all_thread+0x2010>
 ba6:	0000a597          	auipc	a1,0xa
 baa:	4da58593          	addi	a1,a1,1242 # b080 <all_thread+0xa050>
 bae:	6609                	lui	a2,0x2
 bb0:	0641                	addi	a2,a2,16 # 2010 <all_thread+0xfe0>
    if (t->state == FREE) break;
 bb2:	873e                	mv	a4,a5
 bb4:	ff07a683          	lw	a3,-16(a5)
 bb8:	ce9d                	beqz	a3,bf6 <thread_create+0x66>
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 bba:	97b2                	add	a5,a5,a2
 bbc:	feb79be3          	bne	a5,a1,bb2 <thread_create+0x22>
  }
  t->state = RUNNABLE;
 bc0:	6489                	lui	s1,0x2
 bc2:	94ba                	add	s1,s1,a4
 bc4:	4789                	li	a5,2
 bc6:	c09c                	sw	a5,0(s1)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 bc8:	6789                	lui	a5,0x2
 bca:	f9078793          	addi	a5,a5,-112 # 1f90 <all_thread+0xf60>
 bce:	973e                	add	a4,a4,a5
  return (struct context *)(top & ~(uint64)0xf);
 bd0:	ff077513          	andi	a0,a4,-16
  // A never-run thread has no saved state, so construct one: thread_switch()
  // restores ra and sp, and `ret` then starts func on this thread's own stack.
  t->context = thread_context_slot(t);
 bd4:	e488                	sd	a0,8(s1)
  memset(t->context, 0, sizeof(struct context));
 bd6:	07000613          	li	a2,112
 bda:	4581                	li	a1,0
 bdc:	f0aff0ef          	jal	2e6 <memset>
  t->context->ra = (uint64)func;
 be0:	649c                	ld	a5,8(s1)
 be2:	0127b023          	sd	s2,0(a5)
  t->context->sp = (uint64)t->context;   // 16-byte aligned, grows down
 be6:	649c                	ld	a5,8(s1)
 be8:	e79c                	sd	a5,8(a5)
}
 bea:	60e2                	ld	ra,24(sp)
 bec:	6442                	ld	s0,16(sp)
 bee:	64a2                	ld	s1,8(sp)
 bf0:	6902                	ld	s2,0(sp)
 bf2:	6105                	addi	sp,sp,32
 bf4:	8082                	ret
 bf6:	7779                	lui	a4,0xffffe
 bf8:	1741                	addi	a4,a4,-16 # ffffffffffffdff0 <all_thread+0xffffffffffffcfc0>
 bfa:	973e                	add	a4,a4,a5
 bfc:	b7d1                	j	bc0 <thread_create+0x30>

0000000000000bfe <thread_yield>:

void 
thread_yield(void)
{
 bfe:	1141                	addi	sp,sp,-16
 c00:	e406                	sd	ra,8(sp)
 c02:	e022                	sd	s0,0(sp)
 c04:	0800                	addi	s0,sp,16
  current_thread->state = RUNNABLE;
 c06:	00000797          	auipc	a5,0x0
 c0a:	4027b783          	ld	a5,1026(a5) # 1008 <current_thread>
 c0e:	6709                	lui	a4,0x2
 c10:	97ba                	add	a5,a5,a4
 c12:	4709                	li	a4,2
 c14:	c398                	sw	a4,0(a5)
  thread_schedule();
 c16:	ef7ff0ef          	jal	b0c <thread_schedule>
}
 c1a:	60a2                	ld	ra,8(sp)
 c1c:	6402                	ld	s0,0(sp)
 c1e:	0141                	addi	sp,sp,16
 c20:	8082                	ret

0000000000000c22 <thread_exit>:

void thread_exit(void) {
 c22:	1141                	addi	sp,sp,-16
 c24:	e406                	sd	ra,8(sp)
 c26:	e022                	sd	s0,0(sp)
 c28:	0800                	addi	s0,sp,16
  current_thread->state = FREE;
 c2a:	00000797          	auipc	a5,0x0
 c2e:	3de7b783          	ld	a5,990(a5) # 1008 <current_thread>
 c32:	6709                	lui	a4,0x2
 c34:	97ba                	add	a5,a5,a4
 c36:	0007a023          	sw	zero,0(a5)
  thread_schedule();
 c3a:	ed3ff0ef          	jal	b0c <thread_schedule>
}
 c3e:	60a2                	ld	ra,8(sp)
 c40:	6402                	ld	s0,0(sp)
 c42:	0141                	addi	sp,sp,16
 c44:	8082                	ret

0000000000000c46 <thread_switch>:
 c46:	00153023          	sd	ra,0(a0)
 c4a:	00253423          	sd	sp,8(a0)
 c4e:	e900                	sd	s0,16(a0)
 c50:	ed04                	sd	s1,24(a0)
 c52:	03253023          	sd	s2,32(a0)
 c56:	03353423          	sd	s3,40(a0)
 c5a:	03453823          	sd	s4,48(a0)
 c5e:	03553c23          	sd	s5,56(a0)
 c62:	05653023          	sd	s6,64(a0)
 c66:	05753423          	sd	s7,72(a0)
 c6a:	05853823          	sd	s8,80(a0)
 c6e:	05953c23          	sd	s9,88(a0)
 c72:	07a53023          	sd	s10,96(a0)
 c76:	07b53423          	sd	s11,104(a0)
 c7a:	0005b083          	ld	ra,0(a1)
 c7e:	0085b103          	ld	sp,8(a1)
 c82:	6980                	ld	s0,16(a1)
 c84:	6d84                	ld	s1,24(a1)
 c86:	0205b903          	ld	s2,32(a1)
 c8a:	0285b983          	ld	s3,40(a1)
 c8e:	0305ba03          	ld	s4,48(a1)
 c92:	0385ba83          	ld	s5,56(a1)
 c96:	0405bb03          	ld	s6,64(a1)
 c9a:	0485bb83          	ld	s7,72(a1)
 c9e:	0505bc03          	ld	s8,80(a1)
 ca2:	0585bc83          	ld	s9,88(a1)
 ca6:	0605bd03          	ld	s10,96(a1)
 caa:	0685bd83          	ld	s11,104(a1)
 cae:	8082                	ret
