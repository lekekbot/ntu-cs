
user/_zombie:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(void)
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
  if(fork() > 0)
   8:	29a000ef          	jal	2a2 <fork>
   c:	00a04563          	bgtz	a0,16 <main+0x16>
    sleep(5);  // Let child exit before parent.
  exit(0);
  10:	4501                	li	a0,0
  12:	298000ef          	jal	2aa <exit>
    sleep(5);  // Let child exit before parent.
  16:	4515                	li	a0,5
  18:	322000ef          	jal	33a <sleep>
  1c:	bfd5                	j	10 <main+0x10>

000000000000001e <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  1e:	1141                	addi	sp,sp,-16
  20:	e406                	sd	ra,8(sp)
  22:	e022                	sd	s0,0(sp)
  24:	0800                	addi	s0,sp,16
  extern int main();
  main();
  26:	fdbff0ef          	jal	0 <main>
  exit(0);
  2a:	4501                	li	a0,0
  2c:	27e000ef          	jal	2aa <exit>

0000000000000030 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  30:	1141                	addi	sp,sp,-16
  32:	e406                	sd	ra,8(sp)
  34:	e022                	sd	s0,0(sp)
  36:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  38:	87aa                	mv	a5,a0
  3a:	0585                	addi	a1,a1,1
  3c:	0785                	addi	a5,a5,1
  3e:	fff5c703          	lbu	a4,-1(a1)
  42:	fee78fa3          	sb	a4,-1(a5)
  46:	fb75                	bnez	a4,3a <strcpy+0xa>
    ;
  return os;
}
  48:	60a2                	ld	ra,8(sp)
  4a:	6402                	ld	s0,0(sp)
  4c:	0141                	addi	sp,sp,16
  4e:	8082                	ret

0000000000000050 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  50:	1141                	addi	sp,sp,-16
  52:	e406                	sd	ra,8(sp)
  54:	e022                	sd	s0,0(sp)
  56:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  58:	00054783          	lbu	a5,0(a0)
  5c:	cb91                	beqz	a5,70 <strcmp+0x20>
  5e:	0005c703          	lbu	a4,0(a1)
  62:	00f71763          	bne	a4,a5,70 <strcmp+0x20>
    p++, q++;
  66:	0505                	addi	a0,a0,1
  68:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
  6a:	00054783          	lbu	a5,0(a0)
  6e:	fbe5                	bnez	a5,5e <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
  70:	0005c503          	lbu	a0,0(a1)
}
  74:	40a7853b          	subw	a0,a5,a0
  78:	60a2                	ld	ra,8(sp)
  7a:	6402                	ld	s0,0(sp)
  7c:	0141                	addi	sp,sp,16
  7e:	8082                	ret

0000000000000080 <strlen>:

uint
strlen(const char *s)
{
  80:	1141                	addi	sp,sp,-16
  82:	e406                	sd	ra,8(sp)
  84:	e022                	sd	s0,0(sp)
  86:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
  88:	00054783          	lbu	a5,0(a0)
  8c:	cf91                	beqz	a5,a8 <strlen+0x28>
  8e:	00150793          	addi	a5,a0,1
  92:	86be                	mv	a3,a5
  94:	0785                	addi	a5,a5,1
  96:	fff7c703          	lbu	a4,-1(a5)
  9a:	ff65                	bnez	a4,92 <strlen+0x12>
  9c:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
  a0:	60a2                	ld	ra,8(sp)
  a2:	6402                	ld	s0,0(sp)
  a4:	0141                	addi	sp,sp,16
  a6:	8082                	ret
  for(n = 0; s[n]; n++)
  a8:	4501                	li	a0,0
  aa:	bfdd                	j	a0 <strlen+0x20>

00000000000000ac <memset>:

void*
memset(void *dst, int c, uint n)
{
  ac:	1141                	addi	sp,sp,-16
  ae:	e406                	sd	ra,8(sp)
  b0:	e022                	sd	s0,0(sp)
  b2:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
  b4:	ca19                	beqz	a2,ca <memset+0x1e>
  b6:	87aa                	mv	a5,a0
  b8:	1602                	slli	a2,a2,0x20
  ba:	9201                	srli	a2,a2,0x20
  bc:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
  c0:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
  c4:	0785                	addi	a5,a5,1
  c6:	fee79de3          	bne	a5,a4,c0 <memset+0x14>
  }
  return dst;
}
  ca:	60a2                	ld	ra,8(sp)
  cc:	6402                	ld	s0,0(sp)
  ce:	0141                	addi	sp,sp,16
  d0:	8082                	ret

00000000000000d2 <strchr>:

char*
strchr(const char *s, char c)
{
  d2:	1141                	addi	sp,sp,-16
  d4:	e406                	sd	ra,8(sp)
  d6:	e022                	sd	s0,0(sp)
  d8:	0800                	addi	s0,sp,16
  for(; *s; s++)
  da:	00054783          	lbu	a5,0(a0)
  de:	c799                	beqz	a5,ec <strchr+0x1a>
    if(*s == c)
  e0:	00f58763          	beq	a1,a5,ee <strchr+0x1c>
  for(; *s; s++)
  e4:	0505                	addi	a0,a0,1
  e6:	00054783          	lbu	a5,0(a0)
  ea:	fbfd                	bnez	a5,e0 <strchr+0xe>
      return (char*)s;
  return 0;
  ec:	4501                	li	a0,0
}
  ee:	60a2                	ld	ra,8(sp)
  f0:	6402                	ld	s0,0(sp)
  f2:	0141                	addi	sp,sp,16
  f4:	8082                	ret

00000000000000f6 <gets>:

char*
gets(char *buf, int max)
{
  f6:	711d                	addi	sp,sp,-96
  f8:	ec86                	sd	ra,88(sp)
  fa:	e8a2                	sd	s0,80(sp)
  fc:	e4a6                	sd	s1,72(sp)
  fe:	e0ca                	sd	s2,64(sp)
 100:	fc4e                	sd	s3,56(sp)
 102:	f852                	sd	s4,48(sp)
 104:	f456                	sd	s5,40(sp)
 106:	f05a                	sd	s6,32(sp)
 108:	ec5e                	sd	s7,24(sp)
 10a:	e862                	sd	s8,16(sp)
 10c:	1080                	addi	s0,sp,96
 10e:	8baa                	mv	s7,a0
 110:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 112:	892a                	mv	s2,a0
 114:	4481                	li	s1,0
    cc = read(0, &c, 1);
 116:	faf40b13          	addi	s6,s0,-81
 11a:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 11c:	8c26                	mv	s8,s1
 11e:	0014899b          	addiw	s3,s1,1
 122:	84ce                	mv	s1,s3
 124:	0349d863          	bge	s3,s4,154 <gets+0x5e>
    cc = read(0, &c, 1);
 128:	8656                	mv	a2,s5
 12a:	85da                	mv	a1,s6
 12c:	4501                	li	a0,0
 12e:	194000ef          	jal	2c2 <read>
    if(cc < 1)
 132:	02a05163          	blez	a0,154 <gets+0x5e>
      break;
    buf[i++] = c;
 136:	faf44783          	lbu	a5,-81(s0)
 13a:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 13e:	0905                	addi	s2,s2,1
 140:	ff678713          	addi	a4,a5,-10
 144:	00173713          	seqz	a4,a4
 148:	17cd                	addi	a5,a5,-13
 14a:	0017b793          	seqz	a5,a5
 14e:	8fd9                	or	a5,a5,a4
 150:	d7f1                	beqz	a5,11c <gets+0x26>
    buf[i++] = c;
 152:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 154:	9c5e                	add	s8,s8,s7
 156:	000c0023          	sb	zero,0(s8)
  return buf;
}
 15a:	855e                	mv	a0,s7
 15c:	60e6                	ld	ra,88(sp)
 15e:	6446                	ld	s0,80(sp)
 160:	64a6                	ld	s1,72(sp)
 162:	6906                	ld	s2,64(sp)
 164:	79e2                	ld	s3,56(sp)
 166:	7a42                	ld	s4,48(sp)
 168:	7aa2                	ld	s5,40(sp)
 16a:	7b02                	ld	s6,32(sp)
 16c:	6be2                	ld	s7,24(sp)
 16e:	6c42                	ld	s8,16(sp)
 170:	6125                	addi	sp,sp,96
 172:	8082                	ret

0000000000000174 <stat>:

int
stat(const char *n, struct stat *st)
{
 174:	1101                	addi	sp,sp,-32
 176:	ec06                	sd	ra,24(sp)
 178:	e822                	sd	s0,16(sp)
 17a:	e04a                	sd	s2,0(sp)
 17c:	1000                	addi	s0,sp,32
 17e:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 180:	4581                	li	a1,0
 182:	168000ef          	jal	2ea <open>
  if(fd < 0)
 186:	02054263          	bltz	a0,1aa <stat+0x36>
 18a:	e426                	sd	s1,8(sp)
 18c:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 18e:	85ca                	mv	a1,s2
 190:	172000ef          	jal	302 <fstat>
 194:	892a                	mv	s2,a0
  close(fd);
 196:	8526                	mv	a0,s1
 198:	13a000ef          	jal	2d2 <close>
  return r;
 19c:	64a2                	ld	s1,8(sp)
}
 19e:	854a                	mv	a0,s2
 1a0:	60e2                	ld	ra,24(sp)
 1a2:	6442                	ld	s0,16(sp)
 1a4:	6902                	ld	s2,0(sp)
 1a6:	6105                	addi	sp,sp,32
 1a8:	8082                	ret
    return -1;
 1aa:	57fd                	li	a5,-1
 1ac:	893e                	mv	s2,a5
 1ae:	bfc5                	j	19e <stat+0x2a>

00000000000001b0 <atoi>:

int
atoi(const char *s)
{
 1b0:	1141                	addi	sp,sp,-16
 1b2:	e406                	sd	ra,8(sp)
 1b4:	e022                	sd	s0,0(sp)
 1b6:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 1b8:	00054683          	lbu	a3,0(a0)
 1bc:	fd06879b          	addiw	a5,a3,-48
 1c0:	0ff7f793          	zext.b	a5,a5
 1c4:	4625                	li	a2,9
 1c6:	02f66963          	bltu	a2,a5,1f8 <atoi+0x48>
 1ca:	872a                	mv	a4,a0
  n = 0;
 1cc:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 1ce:	0705                	addi	a4,a4,1
 1d0:	0025179b          	slliw	a5,a0,0x2
 1d4:	9fa9                	addw	a5,a5,a0
 1d6:	0017979b          	slliw	a5,a5,0x1
 1da:	9fb5                	addw	a5,a5,a3
 1dc:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 1e0:	00074683          	lbu	a3,0(a4)
 1e4:	fd06879b          	addiw	a5,a3,-48
 1e8:	0ff7f793          	zext.b	a5,a5
 1ec:	fef671e3          	bgeu	a2,a5,1ce <atoi+0x1e>
  return n;
}
 1f0:	60a2                	ld	ra,8(sp)
 1f2:	6402                	ld	s0,0(sp)
 1f4:	0141                	addi	sp,sp,16
 1f6:	8082                	ret
  n = 0;
 1f8:	4501                	li	a0,0
 1fa:	bfdd                	j	1f0 <atoi+0x40>

00000000000001fc <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 1fc:	1141                	addi	sp,sp,-16
 1fe:	e406                	sd	ra,8(sp)
 200:	e022                	sd	s0,0(sp)
 202:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 204:	02b57563          	bgeu	a0,a1,22e <memmove+0x32>
    while(n-- > 0)
 208:	00c05f63          	blez	a2,226 <memmove+0x2a>
 20c:	1602                	slli	a2,a2,0x20
 20e:	9201                	srli	a2,a2,0x20
 210:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 214:	872a                	mv	a4,a0
      *dst++ = *src++;
 216:	0585                	addi	a1,a1,1
 218:	0705                	addi	a4,a4,1
 21a:	fff5c683          	lbu	a3,-1(a1)
 21e:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 222:	fee79ae3          	bne	a5,a4,216 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 226:	60a2                	ld	ra,8(sp)
 228:	6402                	ld	s0,0(sp)
 22a:	0141                	addi	sp,sp,16
 22c:	8082                	ret
    while(n-- > 0)
 22e:	fec05ce3          	blez	a2,226 <memmove+0x2a>
    dst += n;
 232:	00c50733          	add	a4,a0,a2
    src += n;
 236:	95b2                	add	a1,a1,a2
 238:	fff6079b          	addiw	a5,a2,-1
 23c:	1782                	slli	a5,a5,0x20
 23e:	9381                	srli	a5,a5,0x20
 240:	fff7c793          	not	a5,a5
 244:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 246:	15fd                	addi	a1,a1,-1
 248:	177d                	addi	a4,a4,-1
 24a:	0005c683          	lbu	a3,0(a1)
 24e:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 252:	fef71ae3          	bne	a4,a5,246 <memmove+0x4a>
 256:	bfc1                	j	226 <memmove+0x2a>

0000000000000258 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 258:	1141                	addi	sp,sp,-16
 25a:	e406                	sd	ra,8(sp)
 25c:	e022                	sd	s0,0(sp)
 25e:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 260:	ce19                	beqz	a2,27e <memcmp+0x26>
 262:	1602                	slli	a2,a2,0x20
 264:	9201                	srli	a2,a2,0x20
 266:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 26a:	00054783          	lbu	a5,0(a0)
 26e:	0005c703          	lbu	a4,0(a1)
 272:	00e79b63          	bne	a5,a4,288 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 276:	0505                	addi	a0,a0,1
    p2++;
 278:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 27a:	fed518e3          	bne	a0,a3,26a <memcmp+0x12>
  }
  return 0;
 27e:	4501                	li	a0,0
}
 280:	60a2                	ld	ra,8(sp)
 282:	6402                	ld	s0,0(sp)
 284:	0141                	addi	sp,sp,16
 286:	8082                	ret
      return *p1 - *p2;
 288:	40e7853b          	subw	a0,a5,a4
 28c:	bfd5                	j	280 <memcmp+0x28>

000000000000028e <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 28e:	1141                	addi	sp,sp,-16
 290:	e406                	sd	ra,8(sp)
 292:	e022                	sd	s0,0(sp)
 294:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 296:	f67ff0ef          	jal	1fc <memmove>
}
 29a:	60a2                	ld	ra,8(sp)
 29c:	6402                	ld	s0,0(sp)
 29e:	0141                	addi	sp,sp,16
 2a0:	8082                	ret

00000000000002a2 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 2a2:	4885                	li	a7,1
 ecall
 2a4:	00000073          	ecall
 ret
 2a8:	8082                	ret

00000000000002aa <exit>:
.global exit
exit:
 li a7, SYS_exit
 2aa:	4889                	li	a7,2
 ecall
 2ac:	00000073          	ecall
 ret
 2b0:	8082                	ret

00000000000002b2 <wait>:
.global wait
wait:
 li a7, SYS_wait
 2b2:	488d                	li	a7,3
 ecall
 2b4:	00000073          	ecall
 ret
 2b8:	8082                	ret

00000000000002ba <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 2ba:	4891                	li	a7,4
 ecall
 2bc:	00000073          	ecall
 ret
 2c0:	8082                	ret

00000000000002c2 <read>:
.global read
read:
 li a7, SYS_read
 2c2:	4895                	li	a7,5
 ecall
 2c4:	00000073          	ecall
 ret
 2c8:	8082                	ret

00000000000002ca <write>:
.global write
write:
 li a7, SYS_write
 2ca:	48c1                	li	a7,16
 ecall
 2cc:	00000073          	ecall
 ret
 2d0:	8082                	ret

00000000000002d2 <close>:
.global close
close:
 li a7, SYS_close
 2d2:	48d5                	li	a7,21
 ecall
 2d4:	00000073          	ecall
 ret
 2d8:	8082                	ret

00000000000002da <kill>:
.global kill
kill:
 li a7, SYS_kill
 2da:	4899                	li	a7,6
 ecall
 2dc:	00000073          	ecall
 ret
 2e0:	8082                	ret

00000000000002e2 <exec>:
.global exec
exec:
 li a7, SYS_exec
 2e2:	489d                	li	a7,7
 ecall
 2e4:	00000073          	ecall
 ret
 2e8:	8082                	ret

00000000000002ea <open>:
.global open
open:
 li a7, SYS_open
 2ea:	48bd                	li	a7,15
 ecall
 2ec:	00000073          	ecall
 ret
 2f0:	8082                	ret

00000000000002f2 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 2f2:	48c5                	li	a7,17
 ecall
 2f4:	00000073          	ecall
 ret
 2f8:	8082                	ret

00000000000002fa <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 2fa:	48c9                	li	a7,18
 ecall
 2fc:	00000073          	ecall
 ret
 300:	8082                	ret

0000000000000302 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 302:	48a1                	li	a7,8
 ecall
 304:	00000073          	ecall
 ret
 308:	8082                	ret

000000000000030a <link>:
.global link
link:
 li a7, SYS_link
 30a:	48cd                	li	a7,19
 ecall
 30c:	00000073          	ecall
 ret
 310:	8082                	ret

0000000000000312 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 312:	48d1                	li	a7,20
 ecall
 314:	00000073          	ecall
 ret
 318:	8082                	ret

000000000000031a <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 31a:	48a5                	li	a7,9
 ecall
 31c:	00000073          	ecall
 ret
 320:	8082                	ret

0000000000000322 <dup>:
.global dup
dup:
 li a7, SYS_dup
 322:	48a9                	li	a7,10
 ecall
 324:	00000073          	ecall
 ret
 328:	8082                	ret

000000000000032a <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 32a:	48ad                	li	a7,11
 ecall
 32c:	00000073          	ecall
 ret
 330:	8082                	ret

0000000000000332 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 332:	48b1                	li	a7,12
 ecall
 334:	00000073          	ecall
 ret
 338:	8082                	ret

000000000000033a <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 33a:	48b5                	li	a7,13
 ecall
 33c:	00000073          	ecall
 ret
 340:	8082                	ret

0000000000000342 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 342:	48b9                	li	a7,14
 ecall
 344:	00000073          	ecall
 ret
 348:	8082                	ret

000000000000034a <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 34a:	1101                	addi	sp,sp,-32
 34c:	ec06                	sd	ra,24(sp)
 34e:	e822                	sd	s0,16(sp)
 350:	1000                	addi	s0,sp,32
 352:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 356:	4605                	li	a2,1
 358:	fef40593          	addi	a1,s0,-17
 35c:	f6fff0ef          	jal	2ca <write>
}
 360:	60e2                	ld	ra,24(sp)
 362:	6442                	ld	s0,16(sp)
 364:	6105                	addi	sp,sp,32
 366:	8082                	ret

0000000000000368 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 368:	715d                	addi	sp,sp,-80
 36a:	e486                	sd	ra,72(sp)
 36c:	e0a2                	sd	s0,64(sp)
 36e:	f84a                	sd	s2,48(sp)
 370:	f44e                	sd	s3,40(sp)
 372:	0880                	addi	s0,sp,80
 374:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 376:	00d036b3          	snez	a3,a3
 37a:	03f5d793          	srli	a5,a1,0x3f
 37e:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 380:	0005871b          	sext.w	a4,a1
  neg = 0;
 384:	4301                	li	t1,0
  if(sgn && xx < 0){
 386:	c681                	beqz	a3,38e <printint+0x26>
    x = -xx;
 388:	40b0073b          	negw	a4,a1
    neg = 1;
 38c:	4305                	li	t1,1
  }

  i = 0;
 38e:	fb840993          	addi	s3,s0,-72
  neg = 0;
 392:	85ce                	mv	a1,s3
  i = 0;
 394:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 396:	00000817          	auipc	a6,0x0
 39a:	71a80813          	addi	a6,a6,1818 # ab0 <digits>
 39e:	88b6                	mv	a7,a3
 3a0:	0016851b          	addiw	a0,a3,1
 3a4:	86aa                	mv	a3,a0
 3a6:	02c777bb          	remuw	a5,a4,a2
 3aa:	1782                	slli	a5,a5,0x20
 3ac:	9381                	srli	a5,a5,0x20
 3ae:	97c2                	add	a5,a5,a6
 3b0:	0007c783          	lbu	a5,0(a5)
 3b4:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 3b8:	87ba                	mv	a5,a4
 3ba:	02c7573b          	divuw	a4,a4,a2
 3be:	0585                	addi	a1,a1,1
 3c0:	fcc7ffe3          	bgeu	a5,a2,39e <printint+0x36>
  if(neg)
 3c4:	00030b63          	beqz	t1,3da <printint+0x72>
    buf[i++] = '-';
 3c8:	fd040793          	addi	a5,s0,-48
 3cc:	953e                	add	a0,a0,a5
 3ce:	02d00793          	li	a5,45
 3d2:	fef50423          	sb	a5,-24(a0)
 3d6:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 3da:	02d05563          	blez	a3,404 <printint+0x9c>
 3de:	fc26                	sd	s1,56(sp)
 3e0:	36fd                	addiw	a3,a3,-1
 3e2:	00d984b3          	add	s1,s3,a3
 3e6:	19fd                	addi	s3,s3,-1
 3e8:	99b6                	add	s3,s3,a3
 3ea:	1682                	slli	a3,a3,0x20
 3ec:	9281                	srli	a3,a3,0x20
 3ee:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 3f2:	0004c583          	lbu	a1,0(s1)
 3f6:	854a                	mv	a0,s2
 3f8:	f53ff0ef          	jal	34a <putc>
  while(--i >= 0)
 3fc:	14fd                	addi	s1,s1,-1
 3fe:	ff349ae3          	bne	s1,s3,3f2 <printint+0x8a>
 402:	74e2                	ld	s1,56(sp)
}
 404:	60a6                	ld	ra,72(sp)
 406:	6406                	ld	s0,64(sp)
 408:	7942                	ld	s2,48(sp)
 40a:	79a2                	ld	s3,40(sp)
 40c:	6161                	addi	sp,sp,80
 40e:	8082                	ret

0000000000000410 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 410:	711d                	addi	sp,sp,-96
 412:	ec86                	sd	ra,88(sp)
 414:	e8a2                	sd	s0,80(sp)
 416:	e4a6                	sd	s1,72(sp)
 418:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 41a:	0005c483          	lbu	s1,0(a1)
 41e:	28048263          	beqz	s1,6a2 <vprintf+0x292>
 422:	e0ca                	sd	s2,64(sp)
 424:	fc4e                	sd	s3,56(sp)
 426:	f852                	sd	s4,48(sp)
 428:	f456                	sd	s5,40(sp)
 42a:	f05a                	sd	s6,32(sp)
 42c:	ec5e                	sd	s7,24(sp)
 42e:	e862                	sd	s8,16(sp)
 430:	8b2a                	mv	s6,a0
 432:	8a2e                	mv	s4,a1
 434:	8bb2                	mv	s7,a2
  state = 0;
 436:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 438:	4901                	li	s2,0
 43a:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 43c:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 440:	06400c13          	li	s8,100
 444:	a00d                	j	466 <vprintf+0x56>
        putc(fd, c0);
 446:	85a6                	mv	a1,s1
 448:	855a                	mv	a0,s6
 44a:	f01ff0ef          	jal	34a <putc>
 44e:	a019                	j	454 <vprintf+0x44>
    } else if(state == '%'){
 450:	03598363          	beq	s3,s5,476 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 454:	0019079b          	addiw	a5,s2,1
 458:	893e                	mv	s2,a5
 45a:	873e                	mv	a4,a5
 45c:	97d2                	add	a5,a5,s4
 45e:	0007c483          	lbu	s1,0(a5)
 462:	22048963          	beqz	s1,694 <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 466:	0004879b          	sext.w	a5,s1
    if(state == 0){
 46a:	fe0993e3          	bnez	s3,450 <vprintf+0x40>
      if(c0 == '%'){
 46e:	fd579ce3          	bne	a5,s5,446 <vprintf+0x36>
        state = '%';
 472:	89be                	mv	s3,a5
 474:	b7c5                	j	454 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 476:	00ea06b3          	add	a3,s4,a4
 47a:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 47e:	22060763          	beqz	a2,6ac <vprintf+0x29c>
      if(c0 == 'd'){
 482:	0b878363          	beq	a5,s8,528 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 486:	f9478693          	addi	a3,a5,-108
 48a:	0016b693          	seqz	a3,a3
 48e:	f9c60593          	addi	a1,a2,-100
 492:	0015b593          	seqz	a1,a1
 496:	8df5                	and	a1,a1,a3
 498:	e5c5                	bnez	a1,540 <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 49a:	9752                	add	a4,a4,s4
 49c:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 4a0:	f9460713          	addi	a4,a2,-108
 4a4:	00173713          	seqz	a4,a4
 4a8:	8f75                	and	a4,a4,a3
 4aa:	f9c50593          	addi	a1,a0,-100
 4ae:	0015b593          	seqz	a1,a1
 4b2:	8df9                	and	a1,a1,a4
 4b4:	e1dd                	bnez	a1,55a <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 4b6:	07500593          	li	a1,117
 4ba:	0ab78d63          	beq	a5,a1,574 <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 4be:	f8b60593          	addi	a1,a2,-117
 4c2:	0015b593          	seqz	a1,a1
 4c6:	8df5                	and	a1,a1,a3
 4c8:	e1f1                	bnez	a1,58c <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 4ca:	f8b50593          	addi	a1,a0,-117
 4ce:	0015b593          	seqz	a1,a1
 4d2:	8df9                	and	a1,a1,a4
 4d4:	e9e9                	bnez	a1,5a6 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 4d6:	07800593          	li	a1,120
 4da:	0eb78363          	beq	a5,a1,5c0 <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 4de:	f8860613          	addi	a2,a2,-120
 4e2:	00163613          	seqz	a2,a2
 4e6:	8ef1                	and	a3,a3,a2
 4e8:	0e069863          	bnez	a3,5d8 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 4ec:	f8850513          	addi	a0,a0,-120
 4f0:	00153513          	seqz	a0,a0
 4f4:	8f69                	and	a4,a4,a0
 4f6:	0e071e63          	bnez	a4,5f2 <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 4fa:	07000713          	li	a4,112
 4fe:	10e78663          	beq	a5,a4,60a <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 502:	07300713          	li	a4,115
 506:	14e78663          	beq	a5,a4,652 <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 50a:	02500713          	li	a4,37
 50e:	16e78e63          	beq	a5,a4,68a <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 512:	02500593          	li	a1,37
 516:	855a                	mv	a0,s6
 518:	e33ff0ef          	jal	34a <putc>
        putc(fd, c0);
 51c:	85a6                	mv	a1,s1
 51e:	855a                	mv	a0,s6
 520:	e2bff0ef          	jal	34a <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 524:	4981                	li	s3,0
 526:	b73d                	j	454 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 528:	008b8493          	addi	s1,s7,8
 52c:	4685                	li	a3,1
 52e:	4629                	li	a2,10
 530:	000ba583          	lw	a1,0(s7)
 534:	855a                	mv	a0,s6
 536:	e33ff0ef          	jal	368 <printint>
 53a:	8ba6                	mv	s7,s1
      state = 0;
 53c:	4981                	li	s3,0
 53e:	bf19                	j	454 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 540:	008b8493          	addi	s1,s7,8
 544:	4685                	li	a3,1
 546:	4629                	li	a2,10
 548:	000bb583          	ld	a1,0(s7)
 54c:	855a                	mv	a0,s6
 54e:	e1bff0ef          	jal	368 <printint>
        i += 1;
 552:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 554:	8ba6                	mv	s7,s1
      state = 0;
 556:	4981                	li	s3,0
 558:	bdf5                	j	454 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 55a:	008b8493          	addi	s1,s7,8
 55e:	4685                	li	a3,1
 560:	4629                	li	a2,10
 562:	000bb583          	ld	a1,0(s7)
 566:	855a                	mv	a0,s6
 568:	e01ff0ef          	jal	368 <printint>
        i += 2;
 56c:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 56e:	8ba6                	mv	s7,s1
      state = 0;
 570:	4981                	li	s3,0
        i += 2;
 572:	b5cd                	j	454 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 574:	008b8493          	addi	s1,s7,8
 578:	4681                	li	a3,0
 57a:	4629                	li	a2,10
 57c:	000ba583          	lw	a1,0(s7)
 580:	855a                	mv	a0,s6
 582:	de7ff0ef          	jal	368 <printint>
 586:	8ba6                	mv	s7,s1
      state = 0;
 588:	4981                	li	s3,0
 58a:	b5e9                	j	454 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 58c:	008b8493          	addi	s1,s7,8
 590:	4681                	li	a3,0
 592:	4629                	li	a2,10
 594:	000bb583          	ld	a1,0(s7)
 598:	855a                	mv	a0,s6
 59a:	dcfff0ef          	jal	368 <printint>
        i += 1;
 59e:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 5a0:	8ba6                	mv	s7,s1
      state = 0;
 5a2:	4981                	li	s3,0
 5a4:	bd45                	j	454 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 5a6:	008b8493          	addi	s1,s7,8
 5aa:	4681                	li	a3,0
 5ac:	4629                	li	a2,10
 5ae:	000bb583          	ld	a1,0(s7)
 5b2:	855a                	mv	a0,s6
 5b4:	db5ff0ef          	jal	368 <printint>
        i += 2;
 5b8:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 5ba:	8ba6                	mv	s7,s1
      state = 0;
 5bc:	4981                	li	s3,0
        i += 2;
 5be:	bd59                	j	454 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 5c0:	008b8493          	addi	s1,s7,8
 5c4:	4681                	li	a3,0
 5c6:	4641                	li	a2,16
 5c8:	000ba583          	lw	a1,0(s7)
 5cc:	855a                	mv	a0,s6
 5ce:	d9bff0ef          	jal	368 <printint>
 5d2:	8ba6                	mv	s7,s1
      state = 0;
 5d4:	4981                	li	s3,0
 5d6:	bdbd                	j	454 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 5d8:	008b8493          	addi	s1,s7,8
 5dc:	4681                	li	a3,0
 5de:	4641                	li	a2,16
 5e0:	000bb583          	ld	a1,0(s7)
 5e4:	855a                	mv	a0,s6
 5e6:	d83ff0ef          	jal	368 <printint>
        i += 1;
 5ea:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 5ec:	8ba6                	mv	s7,s1
      state = 0;
 5ee:	4981                	li	s3,0
 5f0:	b595                	j	454 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 5f2:	008b8493          	addi	s1,s7,8
 5f6:	4641                	li	a2,16
 5f8:	000bb583          	ld	a1,0(s7)
 5fc:	855a                	mv	a0,s6
 5fe:	d6bff0ef          	jal	368 <printint>
        i += 2;
 602:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 604:	8ba6                	mv	s7,s1
      state = 0;
 606:	4981                	li	s3,0
        i += 2;
 608:	b5b1                	j	454 <vprintf+0x44>
 60a:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 60c:	008b8793          	addi	a5,s7,8
 610:	8cbe                	mv	s9,a5
 612:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 616:	03000593          	li	a1,48
 61a:	855a                	mv	a0,s6
 61c:	d2fff0ef          	jal	34a <putc>
  putc(fd, 'x');
 620:	07800593          	li	a1,120
 624:	855a                	mv	a0,s6
 626:	d25ff0ef          	jal	34a <putc>
 62a:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 62c:	00000b97          	auipc	s7,0x0
 630:	484b8b93          	addi	s7,s7,1156 # ab0 <digits>
 634:	03c9d793          	srli	a5,s3,0x3c
 638:	97de                	add	a5,a5,s7
 63a:	0007c583          	lbu	a1,0(a5)
 63e:	855a                	mv	a0,s6
 640:	d0bff0ef          	jal	34a <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 644:	0992                	slli	s3,s3,0x4
 646:	34fd                	addiw	s1,s1,-1
 648:	f4f5                	bnez	s1,634 <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 64a:	8be6                	mv	s7,s9
      state = 0;
 64c:	4981                	li	s3,0
 64e:	6ca2                	ld	s9,8(sp)
 650:	b511                	j	454 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 652:	008b8993          	addi	s3,s7,8
 656:	000bb483          	ld	s1,0(s7)
 65a:	cc91                	beqz	s1,676 <vprintf+0x266>
        for(; *s; s++)
 65c:	0004c583          	lbu	a1,0(s1)
 660:	c195                	beqz	a1,684 <vprintf+0x274>
          putc(fd, *s);
 662:	855a                	mv	a0,s6
 664:	ce7ff0ef          	jal	34a <putc>
        for(; *s; s++)
 668:	0485                	addi	s1,s1,1
 66a:	0004c583          	lbu	a1,0(s1)
 66e:	f9f5                	bnez	a1,662 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 670:	8bce                	mv	s7,s3
      state = 0;
 672:	4981                	li	s3,0
 674:	b3c5                	j	454 <vprintf+0x44>
          s = "(null)";
 676:	00000497          	auipc	s1,0x0
 67a:	40a48493          	addi	s1,s1,1034 # a80 <thread_switch+0x74>
        for(; *s; s++)
 67e:	02800593          	li	a1,40
 682:	b7c5                	j	662 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 684:	8bce                	mv	s7,s3
      state = 0;
 686:	4981                	li	s3,0
 688:	b3f1                	j	454 <vprintf+0x44>
        putc(fd, '%');
 68a:	85be                	mv	a1,a5
 68c:	855a                	mv	a0,s6
 68e:	cbdff0ef          	jal	34a <putc>
 692:	bd49                	j	524 <vprintf+0x114>
 694:	6906                	ld	s2,64(sp)
 696:	79e2                	ld	s3,56(sp)
 698:	7a42                	ld	s4,48(sp)
 69a:	7aa2                	ld	s5,40(sp)
 69c:	7b02                	ld	s6,32(sp)
 69e:	6be2                	ld	s7,24(sp)
 6a0:	6c42                	ld	s8,16(sp)
    }
  }
}
 6a2:	60e6                	ld	ra,88(sp)
 6a4:	6446                	ld	s0,80(sp)
 6a6:	64a6                	ld	s1,72(sp)
 6a8:	6125                	addi	sp,sp,96
 6aa:	8082                	ret
      if(c0 == 'd'){
 6ac:	06400713          	li	a4,100
 6b0:	e6e78ce3          	beq	a5,a4,528 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 6b4:	f9478693          	addi	a3,a5,-108
 6b8:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 6bc:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 6be:	4701                	li	a4,0
 6c0:	bbdd                	j	4b6 <vprintf+0xa6>

00000000000006c2 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 6c2:	715d                	addi	sp,sp,-80
 6c4:	ec06                	sd	ra,24(sp)
 6c6:	e822                	sd	s0,16(sp)
 6c8:	1000                	addi	s0,sp,32
 6ca:	e010                	sd	a2,0(s0)
 6cc:	e414                	sd	a3,8(s0)
 6ce:	e818                	sd	a4,16(s0)
 6d0:	ec1c                	sd	a5,24(s0)
 6d2:	03043023          	sd	a6,32(s0)
 6d6:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 6da:	8622                	mv	a2,s0
 6dc:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 6e0:	d31ff0ef          	jal	410 <vprintf>
}
 6e4:	60e2                	ld	ra,24(sp)
 6e6:	6442                	ld	s0,16(sp)
 6e8:	6161                	addi	sp,sp,80
 6ea:	8082                	ret

00000000000006ec <printf>:

void
printf(const char *fmt, ...)
{
 6ec:	711d                	addi	sp,sp,-96
 6ee:	ec06                	sd	ra,24(sp)
 6f0:	e822                	sd	s0,16(sp)
 6f2:	1000                	addi	s0,sp,32
 6f4:	e40c                	sd	a1,8(s0)
 6f6:	e810                	sd	a2,16(s0)
 6f8:	ec14                	sd	a3,24(s0)
 6fa:	f018                	sd	a4,32(s0)
 6fc:	f41c                	sd	a5,40(s0)
 6fe:	03043823          	sd	a6,48(s0)
 702:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 706:	00840613          	addi	a2,s0,8
 70a:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 70e:	85aa                	mv	a1,a0
 710:	4505                	li	a0,1
 712:	cffff0ef          	jal	410 <vprintf>
}
 716:	60e2                	ld	ra,24(sp)
 718:	6442                	ld	s0,16(sp)
 71a:	6125                	addi	sp,sp,96
 71c:	8082                	ret

000000000000071e <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 71e:	1141                	addi	sp,sp,-16
 720:	e406                	sd	ra,8(sp)
 722:	e022                	sd	s0,0(sp)
 724:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 726:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 72a:	00001797          	auipc	a5,0x1
 72e:	8d67b783          	ld	a5,-1834(a5) # 1000 <freep>
 732:	a095                	j	796 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 734:	ff852583          	lw	a1,-8(a0)
 738:	6390                	ld	a2,0(a5)
 73a:	02059813          	slli	a6,a1,0x20
 73e:	01c85693          	srli	a3,a6,0x1c
 742:	96ba                	add	a3,a3,a4
 744:	02d60563          	beq	a2,a3,76e <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 748:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 74c:	4790                	lw	a2,8(a5)
 74e:	02061593          	slli	a1,a2,0x20
 752:	01c5d693          	srli	a3,a1,0x1c
 756:	96be                	add	a3,a3,a5
 758:	02d70263          	beq	a4,a3,77c <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 75c:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 75e:	00001717          	auipc	a4,0x1
 762:	8af73123          	sd	a5,-1886(a4) # 1000 <freep>
}
 766:	60a2                	ld	ra,8(sp)
 768:	6402                	ld	s0,0(sp)
 76a:	0141                	addi	sp,sp,16
 76c:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 76e:	4614                	lw	a3,8(a2)
 770:	9ead                	addw	a3,a3,a1
 772:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 776:	6394                	ld	a3,0(a5)
 778:	6290                	ld	a2,0(a3)
 77a:	b7f9                	j	748 <free+0x2a>
    p->s.size += bp->s.size;
 77c:	ff852703          	lw	a4,-8(a0)
 780:	9f31                	addw	a4,a4,a2
 782:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 784:	ff053703          	ld	a4,-16(a0)
 788:	bfd1                	j	75c <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 78a:	6394                	ld	a3,0(a5)
 78c:	00d7e463          	bltu	a5,a3,794 <free+0x76>
 790:	fad762e3          	bltu	a4,a3,734 <free+0x16>
 794:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 796:	fee7fae3          	bgeu	a5,a4,78a <free+0x6c>
 79a:	6394                	ld	a3,0(a5)
 79c:	f8d76ce3          	bltu	a4,a3,734 <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 7a0:	f8d7fae3          	bgeu	a5,a3,734 <free+0x16>
 7a4:	87b6                	mv	a5,a3
 7a6:	bfc5                	j	796 <free+0x78>

00000000000007a8 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 7a8:	7139                	addi	sp,sp,-64
 7aa:	fc06                	sd	ra,56(sp)
 7ac:	f822                	sd	s0,48(sp)
 7ae:	f04a                	sd	s2,32(sp)
 7b0:	ec4e                	sd	s3,24(sp)
 7b2:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 7b4:	02051993          	slli	s3,a0,0x20
 7b8:	0209d993          	srli	s3,s3,0x20
 7bc:	09bd                	addi	s3,s3,15
 7be:	0049d993          	srli	s3,s3,0x4
 7c2:	2985                	addiw	s3,s3,1
 7c4:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 7c6:	00001517          	auipc	a0,0x1
 7ca:	83a53503          	ld	a0,-1990(a0) # 1000 <freep>
 7ce:	c905                	beqz	a0,7fe <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7d0:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 7d2:	4798                	lw	a4,8(a5)
 7d4:	09377663          	bgeu	a4,s3,860 <malloc+0xb8>
 7d8:	f426                	sd	s1,40(sp)
 7da:	e852                	sd	s4,16(sp)
 7dc:	e456                	sd	s5,8(sp)
 7de:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 7e0:	8a4e                	mv	s4,s3
 7e2:	6705                	lui	a4,0x1
 7e4:	00e9f363          	bgeu	s3,a4,7ea <malloc+0x42>
 7e8:	6a05                	lui	s4,0x1
 7ea:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 7ee:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 7f2:	00001497          	auipc	s1,0x1
 7f6:	80e48493          	addi	s1,s1,-2034 # 1000 <freep>
  if(p == (char*)-1)
 7fa:	5afd                	li	s5,-1
 7fc:	a83d                	j	83a <malloc+0x92>
 7fe:	f426                	sd	s1,40(sp)
 800:	e852                	sd	s4,16(sp)
 802:	e456                	sd	s5,8(sp)
 804:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 806:	00001797          	auipc	a5,0x1
 80a:	80a78793          	addi	a5,a5,-2038 # 1010 <base>
 80e:	00000717          	auipc	a4,0x0
 812:	7ef73923          	sd	a5,2034(a4) # 1000 <freep>
 816:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 818:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 81c:	b7d1                	j	7e0 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 81e:	6398                	ld	a4,0(a5)
 820:	e118                	sd	a4,0(a0)
 822:	a899                	j	878 <malloc+0xd0>
  hp->s.size = nu;
 824:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 828:	0541                	addi	a0,a0,16
 82a:	ef5ff0ef          	jal	71e <free>
  return freep;
 82e:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 830:	c125                	beqz	a0,890 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 832:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 834:	4798                	lw	a4,8(a5)
 836:	03277163          	bgeu	a4,s2,858 <malloc+0xb0>
    if(p == freep)
 83a:	6098                	ld	a4,0(s1)
 83c:	853e                	mv	a0,a5
 83e:	fef71ae3          	bne	a4,a5,832 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 842:	8552                	mv	a0,s4
 844:	aefff0ef          	jal	332 <sbrk>
  if(p == (char*)-1)
 848:	fd551ee3          	bne	a0,s5,824 <malloc+0x7c>
        return 0;
 84c:	4501                	li	a0,0
 84e:	74a2                	ld	s1,40(sp)
 850:	6a42                	ld	s4,16(sp)
 852:	6aa2                	ld	s5,8(sp)
 854:	6b02                	ld	s6,0(sp)
 856:	a03d                	j	884 <malloc+0xdc>
 858:	74a2                	ld	s1,40(sp)
 85a:	6a42                	ld	s4,16(sp)
 85c:	6aa2                	ld	s5,8(sp)
 85e:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 860:	fae90fe3          	beq	s2,a4,81e <malloc+0x76>
        p->s.size -= nunits;
 864:	4137073b          	subw	a4,a4,s3
 868:	c798                	sw	a4,8(a5)
        p += p->s.size;
 86a:	02071693          	slli	a3,a4,0x20
 86e:	01c6d713          	srli	a4,a3,0x1c
 872:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 874:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 878:	00000717          	auipc	a4,0x0
 87c:	78a73423          	sd	a0,1928(a4) # 1000 <freep>
      return (void*)(p + 1);
 880:	01078513          	addi	a0,a5,16
  }
}
 884:	70e2                	ld	ra,56(sp)
 886:	7442                	ld	s0,48(sp)
 888:	7902                	ld	s2,32(sp)
 88a:	69e2                	ld	s3,24(sp)
 88c:	6121                	addi	sp,sp,64
 88e:	8082                	ret
 890:	74a2                	ld	s1,40(sp)
 892:	6a42                	ld	s4,16(sp)
 894:	6aa2                	ld	s5,8(sp)
 896:	6b02                	ld	s6,0(sp)
 898:	b7f5                	j	884 <malloc+0xdc>

000000000000089a <thread_init>:
struct thread *current_thread;
extern void thread_switch(uint64, uint64);
              
void 
thread_init(void)
{
 89a:	1141                	addi	sp,sp,-16
 89c:	e406                	sd	ra,8(sp)
 89e:	e022                	sd	s0,0(sp)
 8a0:	0800                	addi	s0,sp,16
  // main() is thread 0, which will make the first invocation to
  // thread_schedule(). It needs a stack so that the first thread_switch() can
  // save thread 0's state.
  current_thread = &all_thread[0];
 8a2:	00000797          	auipc	a5,0x0
 8a6:	77e78793          	addi	a5,a5,1918 # 1020 <all_thread>
 8aa:	00000717          	auipc	a4,0x0
 8ae:	74f73f23          	sd	a5,1886(a4) # 1008 <current_thread>
  current_thread->state = RUNNING;
 8b2:	00002717          	auipc	a4,0x2
 8b6:	76e70713          	addi	a4,a4,1902 # 3020 <all_thread+0x2000>
 8ba:	4785                	li	a5,1
 8bc:	c31c                	sw	a5,0(a4)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 8be:	00002797          	auipc	a5,0x2
 8c2:	6f278793          	addi	a5,a5,1778 # 2fb0 <all_thread+0x1f90>
  return (struct context *)(top & ~(uint64)0xf);
 8c6:	9bc1                	andi	a5,a5,-16
  // Thread 0 runs on the process's own stack, but the first thread_switch()
  // still needs a writable place to save its context.
  current_thread->context = thread_context_slot(current_thread);
 8c8:	e71c                	sd	a5,8(a4)
}
 8ca:	60a2                	ld	ra,8(sp)
 8cc:	6402                	ld	s0,0(sp)
 8ce:	0141                	addi	sp,sp,16
 8d0:	8082                	ret

00000000000008d2 <thread_schedule>:

void 
thread_schedule(void)
{
 8d2:	1141                	addi	sp,sp,-16
 8d4:	e406                	sd	ra,8(sp)
 8d6:	e022                	sd	s0,0(sp)
 8d8:	0800                	addi	s0,sp,16
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
 8da:	00000597          	auipc	a1,0x0
 8de:	72e5b583          	ld	a1,1838(a1) # 1008 <current_thread>
 8e2:	6789                	lui	a5,0x2
 8e4:	07c1                	addi	a5,a5,16 # 2010 <all_thread+0xff0>
 8e6:	97ae                	add	a5,a5,a1
 8e8:	4711                	li	a4,4
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
 8ea:	00008897          	auipc	a7,0x8
 8ee:	77688893          	addi	a7,a7,1910 # 9060 <all_thread+0x8040>
      t = all_thread;
    if(t->state == RUNNABLE) {
 8f2:	6809                	lui	a6,0x2
 8f4:	4509                	li	a0,2
      next_thread = t;
      break;
    }
    t = t + 1;
 8f6:	01080613          	addi	a2,a6,16 # 2010 <all_thread+0xff0>
 8fa:	a809                	j	90c <thread_schedule+0x3a>
    if(t->state == RUNNABLE) {
 8fc:	010786b3          	add	a3,a5,a6
 900:	4294                	lw	a3,0(a3)
 902:	02a68563          	beq	a3,a0,92c <thread_schedule+0x5a>
    t = t + 1;
 906:	97b2                	add	a5,a5,a2
  for(int i = 0; i < MAX_THREAD; i++){
 908:	377d                	addiw	a4,a4,-1
 90a:	cb01                	beqz	a4,91a <thread_schedule+0x48>
    if(t >= all_thread + MAX_THREAD)
 90c:	ff17e8e3          	bltu	a5,a7,8fc <thread_schedule+0x2a>
      t = all_thread;
 910:	00000797          	auipc	a5,0x0
 914:	71078793          	addi	a5,a5,1808 # 1020 <all_thread>
 918:	b7d5                	j	8fc <thread_schedule+0x2a>
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
 91a:	00000517          	auipc	a0,0x0
 91e:	16e50513          	addi	a0,a0,366 # a88 <thread_switch+0x7c>
 922:	dcbff0ef          	jal	6ec <printf>
    exit(-1);
 926:	557d                	li	a0,-1
 928:	983ff0ef          	jal	2aa <exit>
  }

  if (current_thread != next_thread) {         /* switch threads?  */
 92c:	02f58163          	beq	a1,a5,94e <thread_schedule+0x7c>
    next_thread->state = RUNNING;
 930:	6689                	lui	a3,0x2
 932:	00d78733          	add	a4,a5,a3
 936:	4605                	li	a2,1
 938:	c310                	sw	a2,0(a4)
    t = current_thread;
    current_thread = next_thread;
 93a:	00000617          	auipc	a2,0x0
 93e:	6cf63723          	sd	a5,1742(a2) # 1008 <current_thread>
    thread_switch((uint64)t->context, (uint64)next_thread->context);
 942:	00d587b3          	add	a5,a1,a3
 946:	670c                	ld	a1,8(a4)
 948:	6788                	ld	a0,8(a5)
 94a:	0c2000ef          	jal	a0c <thread_switch>
  } else
    next_thread = 0;
}
 94e:	60a2                	ld	ra,8(sp)
 950:	6402                	ld	s0,0(sp)
 952:	0141                	addi	sp,sp,16
 954:	8082                	ret

0000000000000956 <thread_create>:

void 
thread_create(void (*func)())
{
 956:	1101                	addi	sp,sp,-32
 958:	ec06                	sd	ra,24(sp)
 95a:	e822                	sd	s0,16(sp)
 95c:	e426                	sd	s1,8(sp)
 95e:	e04a                	sd	s2,0(sp)
 960:	1000                	addi	s0,sp,32
 962:	892a                	mv	s2,a0
  struct thread *t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 964:	00002797          	auipc	a5,0x2
 968:	6cc78793          	addi	a5,a5,1740 # 3030 <all_thread+0x2010>
 96c:	0000a597          	auipc	a1,0xa
 970:	70458593          	addi	a1,a1,1796 # b070 <all_thread+0xa050>
 974:	6609                	lui	a2,0x2
 976:	0641                	addi	a2,a2,16 # 2010 <all_thread+0xff0>
    if (t->state == FREE) break;
 978:	873e                	mv	a4,a5
 97a:	ff07a683          	lw	a3,-16(a5)
 97e:	ce9d                	beqz	a3,9bc <thread_create+0x66>
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 980:	97b2                	add	a5,a5,a2
 982:	feb79be3          	bne	a5,a1,978 <thread_create+0x22>
  }
  t->state = RUNNABLE;
 986:	6489                	lui	s1,0x2
 988:	94ba                	add	s1,s1,a4
 98a:	4789                	li	a5,2
 98c:	c09c                	sw	a5,0(s1)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 98e:	6789                	lui	a5,0x2
 990:	f9078793          	addi	a5,a5,-112 # 1f90 <all_thread+0xf70>
 994:	973e                	add	a4,a4,a5
  return (struct context *)(top & ~(uint64)0xf);
 996:	ff077513          	andi	a0,a4,-16
  // A never-run thread has no saved state, so construct one: thread_switch()
  // restores ra and sp, and `ret` then starts func on this thread's own stack.
  t->context = thread_context_slot(t);
 99a:	e488                	sd	a0,8(s1)
  memset(t->context, 0, sizeof(struct context));
 99c:	07000613          	li	a2,112
 9a0:	4581                	li	a1,0
 9a2:	f0aff0ef          	jal	ac <memset>
  t->context->ra = (uint64)func;
 9a6:	649c                	ld	a5,8(s1)
 9a8:	0127b023          	sd	s2,0(a5)
  t->context->sp = (uint64)t->context;   // 16-byte aligned, grows down
 9ac:	649c                	ld	a5,8(s1)
 9ae:	e79c                	sd	a5,8(a5)
}
 9b0:	60e2                	ld	ra,24(sp)
 9b2:	6442                	ld	s0,16(sp)
 9b4:	64a2                	ld	s1,8(sp)
 9b6:	6902                	ld	s2,0(sp)
 9b8:	6105                	addi	sp,sp,32
 9ba:	8082                	ret
 9bc:	7779                	lui	a4,0xffffe
 9be:	1741                	addi	a4,a4,-16 # ffffffffffffdff0 <all_thread+0xffffffffffffcfd0>
 9c0:	973e                	add	a4,a4,a5
 9c2:	b7d1                	j	986 <thread_create+0x30>

00000000000009c4 <thread_yield>:

void 
thread_yield(void)
{
 9c4:	1141                	addi	sp,sp,-16
 9c6:	e406                	sd	ra,8(sp)
 9c8:	e022                	sd	s0,0(sp)
 9ca:	0800                	addi	s0,sp,16
  current_thread->state = RUNNABLE;
 9cc:	00000797          	auipc	a5,0x0
 9d0:	63c7b783          	ld	a5,1596(a5) # 1008 <current_thread>
 9d4:	6709                	lui	a4,0x2
 9d6:	97ba                	add	a5,a5,a4
 9d8:	4709                	li	a4,2
 9da:	c398                	sw	a4,0(a5)
  thread_schedule();
 9dc:	ef7ff0ef          	jal	8d2 <thread_schedule>
}
 9e0:	60a2                	ld	ra,8(sp)
 9e2:	6402                	ld	s0,0(sp)
 9e4:	0141                	addi	sp,sp,16
 9e6:	8082                	ret

00000000000009e8 <thread_exit>:

void thread_exit(void) {
 9e8:	1141                	addi	sp,sp,-16
 9ea:	e406                	sd	ra,8(sp)
 9ec:	e022                	sd	s0,0(sp)
 9ee:	0800                	addi	s0,sp,16
  current_thread->state = FREE;
 9f0:	00000797          	auipc	a5,0x0
 9f4:	6187b783          	ld	a5,1560(a5) # 1008 <current_thread>
 9f8:	6709                	lui	a4,0x2
 9fa:	97ba                	add	a5,a5,a4
 9fc:	0007a023          	sw	zero,0(a5)
  thread_schedule();
 a00:	ed3ff0ef          	jal	8d2 <thread_schedule>
}
 a04:	60a2                	ld	ra,8(sp)
 a06:	6402                	ld	s0,0(sp)
 a08:	0141                	addi	sp,sp,16
 a0a:	8082                	ret

0000000000000a0c <thread_switch>:
 a0c:	00153023          	sd	ra,0(a0)
 a10:	00253423          	sd	sp,8(a0)
 a14:	e900                	sd	s0,16(a0)
 a16:	ed04                	sd	s1,24(a0)
 a18:	03253023          	sd	s2,32(a0)
 a1c:	03353423          	sd	s3,40(a0)
 a20:	03453823          	sd	s4,48(a0)
 a24:	03553c23          	sd	s5,56(a0)
 a28:	05653023          	sd	s6,64(a0)
 a2c:	05753423          	sd	s7,72(a0)
 a30:	05853823          	sd	s8,80(a0)
 a34:	05953c23          	sd	s9,88(a0)
 a38:	07a53023          	sd	s10,96(a0)
 a3c:	07b53423          	sd	s11,104(a0)
 a40:	0005b083          	ld	ra,0(a1)
 a44:	0085b103          	ld	sp,8(a1)
 a48:	6980                	ld	s0,16(a1)
 a4a:	6d84                	ld	s1,24(a1)
 a4c:	0205b903          	ld	s2,32(a1)
 a50:	0285b983          	ld	s3,40(a1)
 a54:	0305ba03          	ld	s4,48(a1)
 a58:	0385ba83          	ld	s5,56(a1)
 a5c:	0405bb03          	ld	s6,64(a1)
 a60:	0485bb83          	ld	s7,72(a1)
 a64:	0505bc03          	ld	s8,80(a1)
 a68:	0585bc83          	ld	s9,88(a1)
 a6c:	0605bd03          	ld	s10,96(a1)
 a70:	0685bd83          	ld	s11,104(a1)
 a74:	8082                	ret
