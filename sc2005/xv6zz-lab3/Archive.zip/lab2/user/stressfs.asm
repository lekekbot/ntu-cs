
user/_stressfs:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/fs.h"
#include "kernel/fcntl.h"

int
main(int argc, char *argv[])
{
   0:	dc010113          	addi	sp,sp,-576
   4:	22113c23          	sd	ra,568(sp)
   8:	22813823          	sd	s0,560(sp)
   c:	22913423          	sd	s1,552(sp)
  10:	23213023          	sd	s2,544(sp)
  14:	21313c23          	sd	s3,536(sp)
  18:	21413823          	sd	s4,528(sp)
  1c:	0480                	addi	s0,sp,576
  int fd, i;
  char path[] = "stressfs0";
  1e:	00001797          	auipc	a5,0x1
  22:	b5278793          	addi	a5,a5,-1198 # b70 <thread_switch+0x9a>
  26:	6398                	ld	a4,0(a5)
  28:	fce43023          	sd	a4,-64(s0)
  2c:	0087d783          	lhu	a5,8(a5)
  30:	fcf41423          	sh	a5,-56(s0)
  char data[512];

  printf("stressfs starting\n");
  34:	00001517          	auipc	a0,0x1
  38:	b0c50513          	addi	a0,a0,-1268 # b40 <thread_switch+0x6a>
  3c:	77a000ef          	jal	7b6 <printf>
  memset(data, 'a', sizeof(data));
  40:	20000613          	li	a2,512
  44:	06100593          	li	a1,97
  48:	dc040513          	addi	a0,s0,-576
  4c:	12a000ef          	jal	176 <memset>

  for(i = 0; i < 4; i++)
  50:	4481                	li	s1,0
  52:	4911                	li	s2,4
    if(fork() > 0)
  54:	318000ef          	jal	36c <fork>
  58:	00a04563          	bgtz	a0,62 <main+0x62>
  for(i = 0; i < 4; i++)
  5c:	2485                	addiw	s1,s1,1
  5e:	ff249be3          	bne	s1,s2,54 <main+0x54>
      break;

  printf("write %d\n", i);
  62:	85a6                	mv	a1,s1
  64:	00001517          	auipc	a0,0x1
  68:	af450513          	addi	a0,a0,-1292 # b58 <thread_switch+0x82>
  6c:	74a000ef          	jal	7b6 <printf>

  path[8] += i;
  70:	fc844783          	lbu	a5,-56(s0)
  74:	9fa5                	addw	a5,a5,s1
  76:	fcf40423          	sb	a5,-56(s0)
  fd = open(path, O_CREATE | O_RDWR);
  7a:	20200593          	li	a1,514
  7e:	fc040513          	addi	a0,s0,-64
  82:	332000ef          	jal	3b4 <open>
  86:	892a                	mv	s2,a0
  88:	44d1                	li	s1,20
  for(i = 0; i < 20; i++)
//    printf(fd, "%d\n", i);
    write(fd, data, sizeof(data));
  8a:	dc040a13          	addi	s4,s0,-576
  8e:	20000993          	li	s3,512
  92:	864e                	mv	a2,s3
  94:	85d2                	mv	a1,s4
  96:	854a                	mv	a0,s2
  98:	2fc000ef          	jal	394 <write>
  for(i = 0; i < 20; i++)
  9c:	34fd                	addiw	s1,s1,-1
  9e:	f8f5                	bnez	s1,92 <main+0x92>
  close(fd);
  a0:	854a                	mv	a0,s2
  a2:	2fa000ef          	jal	39c <close>

  printf("read\n");
  a6:	00001517          	auipc	a0,0x1
  aa:	ac250513          	addi	a0,a0,-1342 # b68 <thread_switch+0x92>
  ae:	708000ef          	jal	7b6 <printf>

  fd = open(path, O_RDONLY);
  b2:	4581                	li	a1,0
  b4:	fc040513          	addi	a0,s0,-64
  b8:	2fc000ef          	jal	3b4 <open>
  bc:	892a                	mv	s2,a0
  be:	44d1                	li	s1,20
  for (i = 0; i < 20; i++)
    read(fd, data, sizeof(data));
  c0:	dc040a13          	addi	s4,s0,-576
  c4:	20000993          	li	s3,512
  c8:	864e                	mv	a2,s3
  ca:	85d2                	mv	a1,s4
  cc:	854a                	mv	a0,s2
  ce:	2be000ef          	jal	38c <read>
  for (i = 0; i < 20; i++)
  d2:	34fd                	addiw	s1,s1,-1
  d4:	f8f5                	bnez	s1,c8 <main+0xc8>
  close(fd);
  d6:	854a                	mv	a0,s2
  d8:	2c4000ef          	jal	39c <close>

  wait(0);
  dc:	4501                	li	a0,0
  de:	29e000ef          	jal	37c <wait>

  exit(0);
  e2:	4501                	li	a0,0
  e4:	290000ef          	jal	374 <exit>

00000000000000e8 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  e8:	1141                	addi	sp,sp,-16
  ea:	e406                	sd	ra,8(sp)
  ec:	e022                	sd	s0,0(sp)
  ee:	0800                	addi	s0,sp,16
  extern int main();
  main();
  f0:	f11ff0ef          	jal	0 <main>
  exit(0);
  f4:	4501                	li	a0,0
  f6:	27e000ef          	jal	374 <exit>

00000000000000fa <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  fa:	1141                	addi	sp,sp,-16
  fc:	e406                	sd	ra,8(sp)
  fe:	e022                	sd	s0,0(sp)
 100:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 102:	87aa                	mv	a5,a0
 104:	0585                	addi	a1,a1,1
 106:	0785                	addi	a5,a5,1
 108:	fff5c703          	lbu	a4,-1(a1)
 10c:	fee78fa3          	sb	a4,-1(a5)
 110:	fb75                	bnez	a4,104 <strcpy+0xa>
    ;
  return os;
}
 112:	60a2                	ld	ra,8(sp)
 114:	6402                	ld	s0,0(sp)
 116:	0141                	addi	sp,sp,16
 118:	8082                	ret

000000000000011a <strcmp>:

int
strcmp(const char *p, const char *q)
{
 11a:	1141                	addi	sp,sp,-16
 11c:	e406                	sd	ra,8(sp)
 11e:	e022                	sd	s0,0(sp)
 120:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 122:	00054783          	lbu	a5,0(a0)
 126:	cb91                	beqz	a5,13a <strcmp+0x20>
 128:	0005c703          	lbu	a4,0(a1)
 12c:	00f71763          	bne	a4,a5,13a <strcmp+0x20>
    p++, q++;
 130:	0505                	addi	a0,a0,1
 132:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 134:	00054783          	lbu	a5,0(a0)
 138:	fbe5                	bnez	a5,128 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 13a:	0005c503          	lbu	a0,0(a1)
}
 13e:	40a7853b          	subw	a0,a5,a0
 142:	60a2                	ld	ra,8(sp)
 144:	6402                	ld	s0,0(sp)
 146:	0141                	addi	sp,sp,16
 148:	8082                	ret

000000000000014a <strlen>:

uint
strlen(const char *s)
{
 14a:	1141                	addi	sp,sp,-16
 14c:	e406                	sd	ra,8(sp)
 14e:	e022                	sd	s0,0(sp)
 150:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 152:	00054783          	lbu	a5,0(a0)
 156:	cf91                	beqz	a5,172 <strlen+0x28>
 158:	00150793          	addi	a5,a0,1
 15c:	86be                	mv	a3,a5
 15e:	0785                	addi	a5,a5,1
 160:	fff7c703          	lbu	a4,-1(a5)
 164:	ff65                	bnez	a4,15c <strlen+0x12>
 166:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 16a:	60a2                	ld	ra,8(sp)
 16c:	6402                	ld	s0,0(sp)
 16e:	0141                	addi	sp,sp,16
 170:	8082                	ret
  for(n = 0; s[n]; n++)
 172:	4501                	li	a0,0
 174:	bfdd                	j	16a <strlen+0x20>

0000000000000176 <memset>:

void*
memset(void *dst, int c, uint n)
{
 176:	1141                	addi	sp,sp,-16
 178:	e406                	sd	ra,8(sp)
 17a:	e022                	sd	s0,0(sp)
 17c:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 17e:	ca19                	beqz	a2,194 <memset+0x1e>
 180:	87aa                	mv	a5,a0
 182:	1602                	slli	a2,a2,0x20
 184:	9201                	srli	a2,a2,0x20
 186:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 18a:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 18e:	0785                	addi	a5,a5,1
 190:	fee79de3          	bne	a5,a4,18a <memset+0x14>
  }
  return dst;
}
 194:	60a2                	ld	ra,8(sp)
 196:	6402                	ld	s0,0(sp)
 198:	0141                	addi	sp,sp,16
 19a:	8082                	ret

000000000000019c <strchr>:

char*
strchr(const char *s, char c)
{
 19c:	1141                	addi	sp,sp,-16
 19e:	e406                	sd	ra,8(sp)
 1a0:	e022                	sd	s0,0(sp)
 1a2:	0800                	addi	s0,sp,16
  for(; *s; s++)
 1a4:	00054783          	lbu	a5,0(a0)
 1a8:	c799                	beqz	a5,1b6 <strchr+0x1a>
    if(*s == c)
 1aa:	00f58763          	beq	a1,a5,1b8 <strchr+0x1c>
  for(; *s; s++)
 1ae:	0505                	addi	a0,a0,1
 1b0:	00054783          	lbu	a5,0(a0)
 1b4:	fbfd                	bnez	a5,1aa <strchr+0xe>
      return (char*)s;
  return 0;
 1b6:	4501                	li	a0,0
}
 1b8:	60a2                	ld	ra,8(sp)
 1ba:	6402                	ld	s0,0(sp)
 1bc:	0141                	addi	sp,sp,16
 1be:	8082                	ret

00000000000001c0 <gets>:

char*
gets(char *buf, int max)
{
 1c0:	711d                	addi	sp,sp,-96
 1c2:	ec86                	sd	ra,88(sp)
 1c4:	e8a2                	sd	s0,80(sp)
 1c6:	e4a6                	sd	s1,72(sp)
 1c8:	e0ca                	sd	s2,64(sp)
 1ca:	fc4e                	sd	s3,56(sp)
 1cc:	f852                	sd	s4,48(sp)
 1ce:	f456                	sd	s5,40(sp)
 1d0:	f05a                	sd	s6,32(sp)
 1d2:	ec5e                	sd	s7,24(sp)
 1d4:	e862                	sd	s8,16(sp)
 1d6:	1080                	addi	s0,sp,96
 1d8:	8baa                	mv	s7,a0
 1da:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 1dc:	892a                	mv	s2,a0
 1de:	4481                	li	s1,0
    cc = read(0, &c, 1);
 1e0:	faf40b13          	addi	s6,s0,-81
 1e4:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 1e6:	8c26                	mv	s8,s1
 1e8:	0014899b          	addiw	s3,s1,1
 1ec:	84ce                	mv	s1,s3
 1ee:	0349d863          	bge	s3,s4,21e <gets+0x5e>
    cc = read(0, &c, 1);
 1f2:	8656                	mv	a2,s5
 1f4:	85da                	mv	a1,s6
 1f6:	4501                	li	a0,0
 1f8:	194000ef          	jal	38c <read>
    if(cc < 1)
 1fc:	02a05163          	blez	a0,21e <gets+0x5e>
      break;
    buf[i++] = c;
 200:	faf44783          	lbu	a5,-81(s0)
 204:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 208:	0905                	addi	s2,s2,1
 20a:	ff678713          	addi	a4,a5,-10
 20e:	00173713          	seqz	a4,a4
 212:	17cd                	addi	a5,a5,-13
 214:	0017b793          	seqz	a5,a5
 218:	8fd9                	or	a5,a5,a4
 21a:	d7f1                	beqz	a5,1e6 <gets+0x26>
    buf[i++] = c;
 21c:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 21e:	9c5e                	add	s8,s8,s7
 220:	000c0023          	sb	zero,0(s8)
  return buf;
}
 224:	855e                	mv	a0,s7
 226:	60e6                	ld	ra,88(sp)
 228:	6446                	ld	s0,80(sp)
 22a:	64a6                	ld	s1,72(sp)
 22c:	6906                	ld	s2,64(sp)
 22e:	79e2                	ld	s3,56(sp)
 230:	7a42                	ld	s4,48(sp)
 232:	7aa2                	ld	s5,40(sp)
 234:	7b02                	ld	s6,32(sp)
 236:	6be2                	ld	s7,24(sp)
 238:	6c42                	ld	s8,16(sp)
 23a:	6125                	addi	sp,sp,96
 23c:	8082                	ret

000000000000023e <stat>:

int
stat(const char *n, struct stat *st)
{
 23e:	1101                	addi	sp,sp,-32
 240:	ec06                	sd	ra,24(sp)
 242:	e822                	sd	s0,16(sp)
 244:	e04a                	sd	s2,0(sp)
 246:	1000                	addi	s0,sp,32
 248:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 24a:	4581                	li	a1,0
 24c:	168000ef          	jal	3b4 <open>
  if(fd < 0)
 250:	02054263          	bltz	a0,274 <stat+0x36>
 254:	e426                	sd	s1,8(sp)
 256:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 258:	85ca                	mv	a1,s2
 25a:	172000ef          	jal	3cc <fstat>
 25e:	892a                	mv	s2,a0
  close(fd);
 260:	8526                	mv	a0,s1
 262:	13a000ef          	jal	39c <close>
  return r;
 266:	64a2                	ld	s1,8(sp)
}
 268:	854a                	mv	a0,s2
 26a:	60e2                	ld	ra,24(sp)
 26c:	6442                	ld	s0,16(sp)
 26e:	6902                	ld	s2,0(sp)
 270:	6105                	addi	sp,sp,32
 272:	8082                	ret
    return -1;
 274:	57fd                	li	a5,-1
 276:	893e                	mv	s2,a5
 278:	bfc5                	j	268 <stat+0x2a>

000000000000027a <atoi>:

int
atoi(const char *s)
{
 27a:	1141                	addi	sp,sp,-16
 27c:	e406                	sd	ra,8(sp)
 27e:	e022                	sd	s0,0(sp)
 280:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 282:	00054683          	lbu	a3,0(a0)
 286:	fd06879b          	addiw	a5,a3,-48
 28a:	0ff7f793          	zext.b	a5,a5
 28e:	4625                	li	a2,9
 290:	02f66963          	bltu	a2,a5,2c2 <atoi+0x48>
 294:	872a                	mv	a4,a0
  n = 0;
 296:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 298:	0705                	addi	a4,a4,1
 29a:	0025179b          	slliw	a5,a0,0x2
 29e:	9fa9                	addw	a5,a5,a0
 2a0:	0017979b          	slliw	a5,a5,0x1
 2a4:	9fb5                	addw	a5,a5,a3
 2a6:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 2aa:	00074683          	lbu	a3,0(a4)
 2ae:	fd06879b          	addiw	a5,a3,-48
 2b2:	0ff7f793          	zext.b	a5,a5
 2b6:	fef671e3          	bgeu	a2,a5,298 <atoi+0x1e>
  return n;
}
 2ba:	60a2                	ld	ra,8(sp)
 2bc:	6402                	ld	s0,0(sp)
 2be:	0141                	addi	sp,sp,16
 2c0:	8082                	ret
  n = 0;
 2c2:	4501                	li	a0,0
 2c4:	bfdd                	j	2ba <atoi+0x40>

00000000000002c6 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 2c6:	1141                	addi	sp,sp,-16
 2c8:	e406                	sd	ra,8(sp)
 2ca:	e022                	sd	s0,0(sp)
 2cc:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 2ce:	02b57563          	bgeu	a0,a1,2f8 <memmove+0x32>
    while(n-- > 0)
 2d2:	00c05f63          	blez	a2,2f0 <memmove+0x2a>
 2d6:	1602                	slli	a2,a2,0x20
 2d8:	9201                	srli	a2,a2,0x20
 2da:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 2de:	872a                	mv	a4,a0
      *dst++ = *src++;
 2e0:	0585                	addi	a1,a1,1
 2e2:	0705                	addi	a4,a4,1
 2e4:	fff5c683          	lbu	a3,-1(a1)
 2e8:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 2ec:	fee79ae3          	bne	a5,a4,2e0 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 2f0:	60a2                	ld	ra,8(sp)
 2f2:	6402                	ld	s0,0(sp)
 2f4:	0141                	addi	sp,sp,16
 2f6:	8082                	ret
    while(n-- > 0)
 2f8:	fec05ce3          	blez	a2,2f0 <memmove+0x2a>
    dst += n;
 2fc:	00c50733          	add	a4,a0,a2
    src += n;
 300:	95b2                	add	a1,a1,a2
 302:	fff6079b          	addiw	a5,a2,-1
 306:	1782                	slli	a5,a5,0x20
 308:	9381                	srli	a5,a5,0x20
 30a:	fff7c793          	not	a5,a5
 30e:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 310:	15fd                	addi	a1,a1,-1
 312:	177d                	addi	a4,a4,-1
 314:	0005c683          	lbu	a3,0(a1)
 318:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 31c:	fef71ae3          	bne	a4,a5,310 <memmove+0x4a>
 320:	bfc1                	j	2f0 <memmove+0x2a>

0000000000000322 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 322:	1141                	addi	sp,sp,-16
 324:	e406                	sd	ra,8(sp)
 326:	e022                	sd	s0,0(sp)
 328:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 32a:	ce19                	beqz	a2,348 <memcmp+0x26>
 32c:	1602                	slli	a2,a2,0x20
 32e:	9201                	srli	a2,a2,0x20
 330:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 334:	00054783          	lbu	a5,0(a0)
 338:	0005c703          	lbu	a4,0(a1)
 33c:	00e79b63          	bne	a5,a4,352 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 340:	0505                	addi	a0,a0,1
    p2++;
 342:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 344:	fed518e3          	bne	a0,a3,334 <memcmp+0x12>
  }
  return 0;
 348:	4501                	li	a0,0
}
 34a:	60a2                	ld	ra,8(sp)
 34c:	6402                	ld	s0,0(sp)
 34e:	0141                	addi	sp,sp,16
 350:	8082                	ret
      return *p1 - *p2;
 352:	40e7853b          	subw	a0,a5,a4
 356:	bfd5                	j	34a <memcmp+0x28>

0000000000000358 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 358:	1141                	addi	sp,sp,-16
 35a:	e406                	sd	ra,8(sp)
 35c:	e022                	sd	s0,0(sp)
 35e:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 360:	f67ff0ef          	jal	2c6 <memmove>
}
 364:	60a2                	ld	ra,8(sp)
 366:	6402                	ld	s0,0(sp)
 368:	0141                	addi	sp,sp,16
 36a:	8082                	ret

000000000000036c <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 36c:	4885                	li	a7,1
 ecall
 36e:	00000073          	ecall
 ret
 372:	8082                	ret

0000000000000374 <exit>:
.global exit
exit:
 li a7, SYS_exit
 374:	4889                	li	a7,2
 ecall
 376:	00000073          	ecall
 ret
 37a:	8082                	ret

000000000000037c <wait>:
.global wait
wait:
 li a7, SYS_wait
 37c:	488d                	li	a7,3
 ecall
 37e:	00000073          	ecall
 ret
 382:	8082                	ret

0000000000000384 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 384:	4891                	li	a7,4
 ecall
 386:	00000073          	ecall
 ret
 38a:	8082                	ret

000000000000038c <read>:
.global read
read:
 li a7, SYS_read
 38c:	4895                	li	a7,5
 ecall
 38e:	00000073          	ecall
 ret
 392:	8082                	ret

0000000000000394 <write>:
.global write
write:
 li a7, SYS_write
 394:	48c1                	li	a7,16
 ecall
 396:	00000073          	ecall
 ret
 39a:	8082                	ret

000000000000039c <close>:
.global close
close:
 li a7, SYS_close
 39c:	48d5                	li	a7,21
 ecall
 39e:	00000073          	ecall
 ret
 3a2:	8082                	ret

00000000000003a4 <kill>:
.global kill
kill:
 li a7, SYS_kill
 3a4:	4899                	li	a7,6
 ecall
 3a6:	00000073          	ecall
 ret
 3aa:	8082                	ret

00000000000003ac <exec>:
.global exec
exec:
 li a7, SYS_exec
 3ac:	489d                	li	a7,7
 ecall
 3ae:	00000073          	ecall
 ret
 3b2:	8082                	ret

00000000000003b4 <open>:
.global open
open:
 li a7, SYS_open
 3b4:	48bd                	li	a7,15
 ecall
 3b6:	00000073          	ecall
 ret
 3ba:	8082                	ret

00000000000003bc <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 3bc:	48c5                	li	a7,17
 ecall
 3be:	00000073          	ecall
 ret
 3c2:	8082                	ret

00000000000003c4 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 3c4:	48c9                	li	a7,18
 ecall
 3c6:	00000073          	ecall
 ret
 3ca:	8082                	ret

00000000000003cc <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 3cc:	48a1                	li	a7,8
 ecall
 3ce:	00000073          	ecall
 ret
 3d2:	8082                	ret

00000000000003d4 <link>:
.global link
link:
 li a7, SYS_link
 3d4:	48cd                	li	a7,19
 ecall
 3d6:	00000073          	ecall
 ret
 3da:	8082                	ret

00000000000003dc <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 3dc:	48d1                	li	a7,20
 ecall
 3de:	00000073          	ecall
 ret
 3e2:	8082                	ret

00000000000003e4 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 3e4:	48a5                	li	a7,9
 ecall
 3e6:	00000073          	ecall
 ret
 3ea:	8082                	ret

00000000000003ec <dup>:
.global dup
dup:
 li a7, SYS_dup
 3ec:	48a9                	li	a7,10
 ecall
 3ee:	00000073          	ecall
 ret
 3f2:	8082                	ret

00000000000003f4 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 3f4:	48ad                	li	a7,11
 ecall
 3f6:	00000073          	ecall
 ret
 3fa:	8082                	ret

00000000000003fc <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 3fc:	48b1                	li	a7,12
 ecall
 3fe:	00000073          	ecall
 ret
 402:	8082                	ret

0000000000000404 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 404:	48b5                	li	a7,13
 ecall
 406:	00000073          	ecall
 ret
 40a:	8082                	ret

000000000000040c <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 40c:	48b9                	li	a7,14
 ecall
 40e:	00000073          	ecall
 ret
 412:	8082                	ret

0000000000000414 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 414:	1101                	addi	sp,sp,-32
 416:	ec06                	sd	ra,24(sp)
 418:	e822                	sd	s0,16(sp)
 41a:	1000                	addi	s0,sp,32
 41c:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 420:	4605                	li	a2,1
 422:	fef40593          	addi	a1,s0,-17
 426:	f6fff0ef          	jal	394 <write>
}
 42a:	60e2                	ld	ra,24(sp)
 42c:	6442                	ld	s0,16(sp)
 42e:	6105                	addi	sp,sp,32
 430:	8082                	ret

0000000000000432 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 432:	715d                	addi	sp,sp,-80
 434:	e486                	sd	ra,72(sp)
 436:	e0a2                	sd	s0,64(sp)
 438:	f84a                	sd	s2,48(sp)
 43a:	f44e                	sd	s3,40(sp)
 43c:	0880                	addi	s0,sp,80
 43e:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 440:	00d036b3          	snez	a3,a3
 444:	03f5d793          	srli	a5,a1,0x3f
 448:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 44a:	0005871b          	sext.w	a4,a1
  neg = 0;
 44e:	4301                	li	t1,0
  if(sgn && xx < 0){
 450:	c681                	beqz	a3,458 <printint+0x26>
    x = -xx;
 452:	40b0073b          	negw	a4,a1
    neg = 1;
 456:	4305                	li	t1,1
  }

  i = 0;
 458:	fb840993          	addi	s3,s0,-72
  neg = 0;
 45c:	85ce                	mv	a1,s3
  i = 0;
 45e:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 460:	00000817          	auipc	a6,0x0
 464:	75080813          	addi	a6,a6,1872 # bb0 <digits>
 468:	88b6                	mv	a7,a3
 46a:	0016851b          	addiw	a0,a3,1
 46e:	86aa                	mv	a3,a0
 470:	02c777bb          	remuw	a5,a4,a2
 474:	1782                	slli	a5,a5,0x20
 476:	9381                	srli	a5,a5,0x20
 478:	97c2                	add	a5,a5,a6
 47a:	0007c783          	lbu	a5,0(a5)
 47e:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 482:	87ba                	mv	a5,a4
 484:	02c7573b          	divuw	a4,a4,a2
 488:	0585                	addi	a1,a1,1
 48a:	fcc7ffe3          	bgeu	a5,a2,468 <printint+0x36>
  if(neg)
 48e:	00030b63          	beqz	t1,4a4 <printint+0x72>
    buf[i++] = '-';
 492:	fd040793          	addi	a5,s0,-48
 496:	953e                	add	a0,a0,a5
 498:	02d00793          	li	a5,45
 49c:	fef50423          	sb	a5,-24(a0)
 4a0:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 4a4:	02d05563          	blez	a3,4ce <printint+0x9c>
 4a8:	fc26                	sd	s1,56(sp)
 4aa:	36fd                	addiw	a3,a3,-1
 4ac:	00d984b3          	add	s1,s3,a3
 4b0:	19fd                	addi	s3,s3,-1
 4b2:	99b6                	add	s3,s3,a3
 4b4:	1682                	slli	a3,a3,0x20
 4b6:	9281                	srli	a3,a3,0x20
 4b8:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 4bc:	0004c583          	lbu	a1,0(s1)
 4c0:	854a                	mv	a0,s2
 4c2:	f53ff0ef          	jal	414 <putc>
  while(--i >= 0)
 4c6:	14fd                	addi	s1,s1,-1
 4c8:	ff349ae3          	bne	s1,s3,4bc <printint+0x8a>
 4cc:	74e2                	ld	s1,56(sp)
}
 4ce:	60a6                	ld	ra,72(sp)
 4d0:	6406                	ld	s0,64(sp)
 4d2:	7942                	ld	s2,48(sp)
 4d4:	79a2                	ld	s3,40(sp)
 4d6:	6161                	addi	sp,sp,80
 4d8:	8082                	ret

00000000000004da <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 4da:	711d                	addi	sp,sp,-96
 4dc:	ec86                	sd	ra,88(sp)
 4de:	e8a2                	sd	s0,80(sp)
 4e0:	e4a6                	sd	s1,72(sp)
 4e2:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 4e4:	0005c483          	lbu	s1,0(a1)
 4e8:	28048263          	beqz	s1,76c <vprintf+0x292>
 4ec:	e0ca                	sd	s2,64(sp)
 4ee:	fc4e                	sd	s3,56(sp)
 4f0:	f852                	sd	s4,48(sp)
 4f2:	f456                	sd	s5,40(sp)
 4f4:	f05a                	sd	s6,32(sp)
 4f6:	ec5e                	sd	s7,24(sp)
 4f8:	e862                	sd	s8,16(sp)
 4fa:	8b2a                	mv	s6,a0
 4fc:	8a2e                	mv	s4,a1
 4fe:	8bb2                	mv	s7,a2
  state = 0;
 500:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 502:	4901                	li	s2,0
 504:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 506:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 50a:	06400c13          	li	s8,100
 50e:	a00d                	j	530 <vprintf+0x56>
        putc(fd, c0);
 510:	85a6                	mv	a1,s1
 512:	855a                	mv	a0,s6
 514:	f01ff0ef          	jal	414 <putc>
 518:	a019                	j	51e <vprintf+0x44>
    } else if(state == '%'){
 51a:	03598363          	beq	s3,s5,540 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 51e:	0019079b          	addiw	a5,s2,1
 522:	893e                	mv	s2,a5
 524:	873e                	mv	a4,a5
 526:	97d2                	add	a5,a5,s4
 528:	0007c483          	lbu	s1,0(a5)
 52c:	22048963          	beqz	s1,75e <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 530:	0004879b          	sext.w	a5,s1
    if(state == 0){
 534:	fe0993e3          	bnez	s3,51a <vprintf+0x40>
      if(c0 == '%'){
 538:	fd579ce3          	bne	a5,s5,510 <vprintf+0x36>
        state = '%';
 53c:	89be                	mv	s3,a5
 53e:	b7c5                	j	51e <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 540:	00ea06b3          	add	a3,s4,a4
 544:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 548:	22060763          	beqz	a2,776 <vprintf+0x29c>
      if(c0 == 'd'){
 54c:	0b878363          	beq	a5,s8,5f2 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 550:	f9478693          	addi	a3,a5,-108
 554:	0016b693          	seqz	a3,a3
 558:	f9c60593          	addi	a1,a2,-100
 55c:	0015b593          	seqz	a1,a1
 560:	8df5                	and	a1,a1,a3
 562:	e5c5                	bnez	a1,60a <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 564:	9752                	add	a4,a4,s4
 566:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 56a:	f9460713          	addi	a4,a2,-108
 56e:	00173713          	seqz	a4,a4
 572:	8f75                	and	a4,a4,a3
 574:	f9c50593          	addi	a1,a0,-100
 578:	0015b593          	seqz	a1,a1
 57c:	8df9                	and	a1,a1,a4
 57e:	e1dd                	bnez	a1,624 <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 580:	07500593          	li	a1,117
 584:	0ab78d63          	beq	a5,a1,63e <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 588:	f8b60593          	addi	a1,a2,-117
 58c:	0015b593          	seqz	a1,a1
 590:	8df5                	and	a1,a1,a3
 592:	e1f1                	bnez	a1,656 <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 594:	f8b50593          	addi	a1,a0,-117
 598:	0015b593          	seqz	a1,a1
 59c:	8df9                	and	a1,a1,a4
 59e:	e9e9                	bnez	a1,670 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 5a0:	07800593          	li	a1,120
 5a4:	0eb78363          	beq	a5,a1,68a <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 5a8:	f8860613          	addi	a2,a2,-120
 5ac:	00163613          	seqz	a2,a2
 5b0:	8ef1                	and	a3,a3,a2
 5b2:	0e069863          	bnez	a3,6a2 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 5b6:	f8850513          	addi	a0,a0,-120
 5ba:	00153513          	seqz	a0,a0
 5be:	8f69                	and	a4,a4,a0
 5c0:	0e071e63          	bnez	a4,6bc <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 5c4:	07000713          	li	a4,112
 5c8:	10e78663          	beq	a5,a4,6d4 <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 5cc:	07300713          	li	a4,115
 5d0:	14e78663          	beq	a5,a4,71c <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 5d4:	02500713          	li	a4,37
 5d8:	16e78e63          	beq	a5,a4,754 <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 5dc:	02500593          	li	a1,37
 5e0:	855a                	mv	a0,s6
 5e2:	e33ff0ef          	jal	414 <putc>
        putc(fd, c0);
 5e6:	85a6                	mv	a1,s1
 5e8:	855a                	mv	a0,s6
 5ea:	e2bff0ef          	jal	414 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 5ee:	4981                	li	s3,0
 5f0:	b73d                	j	51e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 5f2:	008b8493          	addi	s1,s7,8
 5f6:	4685                	li	a3,1
 5f8:	4629                	li	a2,10
 5fa:	000ba583          	lw	a1,0(s7)
 5fe:	855a                	mv	a0,s6
 600:	e33ff0ef          	jal	432 <printint>
 604:	8ba6                	mv	s7,s1
      state = 0;
 606:	4981                	li	s3,0
 608:	bf19                	j	51e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 60a:	008b8493          	addi	s1,s7,8
 60e:	4685                	li	a3,1
 610:	4629                	li	a2,10
 612:	000bb583          	ld	a1,0(s7)
 616:	855a                	mv	a0,s6
 618:	e1bff0ef          	jal	432 <printint>
        i += 1;
 61c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 61e:	8ba6                	mv	s7,s1
      state = 0;
 620:	4981                	li	s3,0
 622:	bdf5                	j	51e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 624:	008b8493          	addi	s1,s7,8
 628:	4685                	li	a3,1
 62a:	4629                	li	a2,10
 62c:	000bb583          	ld	a1,0(s7)
 630:	855a                	mv	a0,s6
 632:	e01ff0ef          	jal	432 <printint>
        i += 2;
 636:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 638:	8ba6                	mv	s7,s1
      state = 0;
 63a:	4981                	li	s3,0
        i += 2;
 63c:	b5cd                	j	51e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 63e:	008b8493          	addi	s1,s7,8
 642:	4681                	li	a3,0
 644:	4629                	li	a2,10
 646:	000ba583          	lw	a1,0(s7)
 64a:	855a                	mv	a0,s6
 64c:	de7ff0ef          	jal	432 <printint>
 650:	8ba6                	mv	s7,s1
      state = 0;
 652:	4981                	li	s3,0
 654:	b5e9                	j	51e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 656:	008b8493          	addi	s1,s7,8
 65a:	4681                	li	a3,0
 65c:	4629                	li	a2,10
 65e:	000bb583          	ld	a1,0(s7)
 662:	855a                	mv	a0,s6
 664:	dcfff0ef          	jal	432 <printint>
        i += 1;
 668:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 66a:	8ba6                	mv	s7,s1
      state = 0;
 66c:	4981                	li	s3,0
 66e:	bd45                	j	51e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 670:	008b8493          	addi	s1,s7,8
 674:	4681                	li	a3,0
 676:	4629                	li	a2,10
 678:	000bb583          	ld	a1,0(s7)
 67c:	855a                	mv	a0,s6
 67e:	db5ff0ef          	jal	432 <printint>
        i += 2;
 682:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 684:	8ba6                	mv	s7,s1
      state = 0;
 686:	4981                	li	s3,0
        i += 2;
 688:	bd59                	j	51e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 68a:	008b8493          	addi	s1,s7,8
 68e:	4681                	li	a3,0
 690:	4641                	li	a2,16
 692:	000ba583          	lw	a1,0(s7)
 696:	855a                	mv	a0,s6
 698:	d9bff0ef          	jal	432 <printint>
 69c:	8ba6                	mv	s7,s1
      state = 0;
 69e:	4981                	li	s3,0
 6a0:	bdbd                	j	51e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6a2:	008b8493          	addi	s1,s7,8
 6a6:	4681                	li	a3,0
 6a8:	4641                	li	a2,16
 6aa:	000bb583          	ld	a1,0(s7)
 6ae:	855a                	mv	a0,s6
 6b0:	d83ff0ef          	jal	432 <printint>
        i += 1;
 6b4:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 6b6:	8ba6                	mv	s7,s1
      state = 0;
 6b8:	4981                	li	s3,0
 6ba:	b595                	j	51e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6bc:	008b8493          	addi	s1,s7,8
 6c0:	4641                	li	a2,16
 6c2:	000bb583          	ld	a1,0(s7)
 6c6:	855a                	mv	a0,s6
 6c8:	d6bff0ef          	jal	432 <printint>
        i += 2;
 6cc:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 6ce:	8ba6                	mv	s7,s1
      state = 0;
 6d0:	4981                	li	s3,0
        i += 2;
 6d2:	b5b1                	j	51e <vprintf+0x44>
 6d4:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 6d6:	008b8793          	addi	a5,s7,8
 6da:	8cbe                	mv	s9,a5
 6dc:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 6e0:	03000593          	li	a1,48
 6e4:	855a                	mv	a0,s6
 6e6:	d2fff0ef          	jal	414 <putc>
  putc(fd, 'x');
 6ea:	07800593          	li	a1,120
 6ee:	855a                	mv	a0,s6
 6f0:	d25ff0ef          	jal	414 <putc>
 6f4:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 6f6:	00000b97          	auipc	s7,0x0
 6fa:	4bab8b93          	addi	s7,s7,1210 # bb0 <digits>
 6fe:	03c9d793          	srli	a5,s3,0x3c
 702:	97de                	add	a5,a5,s7
 704:	0007c583          	lbu	a1,0(a5)
 708:	855a                	mv	a0,s6
 70a:	d0bff0ef          	jal	414 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 70e:	0992                	slli	s3,s3,0x4
 710:	34fd                	addiw	s1,s1,-1
 712:	f4f5                	bnez	s1,6fe <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 714:	8be6                	mv	s7,s9
      state = 0;
 716:	4981                	li	s3,0
 718:	6ca2                	ld	s9,8(sp)
 71a:	b511                	j	51e <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 71c:	008b8993          	addi	s3,s7,8
 720:	000bb483          	ld	s1,0(s7)
 724:	cc91                	beqz	s1,740 <vprintf+0x266>
        for(; *s; s++)
 726:	0004c583          	lbu	a1,0(s1)
 72a:	c195                	beqz	a1,74e <vprintf+0x274>
          putc(fd, *s);
 72c:	855a                	mv	a0,s6
 72e:	ce7ff0ef          	jal	414 <putc>
        for(; *s; s++)
 732:	0485                	addi	s1,s1,1
 734:	0004c583          	lbu	a1,0(s1)
 738:	f9f5                	bnez	a1,72c <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 73a:	8bce                	mv	s7,s3
      state = 0;
 73c:	4981                	li	s3,0
 73e:	b3c5                	j	51e <vprintf+0x44>
          s = "(null)";
 740:	00000497          	auipc	s1,0x0
 744:	44048493          	addi	s1,s1,1088 # b80 <thread_switch+0xaa>
        for(; *s; s++)
 748:	02800593          	li	a1,40
 74c:	b7c5                	j	72c <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 74e:	8bce                	mv	s7,s3
      state = 0;
 750:	4981                	li	s3,0
 752:	b3f1                	j	51e <vprintf+0x44>
        putc(fd, '%');
 754:	85be                	mv	a1,a5
 756:	855a                	mv	a0,s6
 758:	cbdff0ef          	jal	414 <putc>
 75c:	bd49                	j	5ee <vprintf+0x114>
 75e:	6906                	ld	s2,64(sp)
 760:	79e2                	ld	s3,56(sp)
 762:	7a42                	ld	s4,48(sp)
 764:	7aa2                	ld	s5,40(sp)
 766:	7b02                	ld	s6,32(sp)
 768:	6be2                	ld	s7,24(sp)
 76a:	6c42                	ld	s8,16(sp)
    }
  }
}
 76c:	60e6                	ld	ra,88(sp)
 76e:	6446                	ld	s0,80(sp)
 770:	64a6                	ld	s1,72(sp)
 772:	6125                	addi	sp,sp,96
 774:	8082                	ret
      if(c0 == 'd'){
 776:	06400713          	li	a4,100
 77a:	e6e78ce3          	beq	a5,a4,5f2 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 77e:	f9478693          	addi	a3,a5,-108
 782:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 786:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 788:	4701                	li	a4,0
 78a:	bbdd                	j	580 <vprintf+0xa6>

000000000000078c <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 78c:	715d                	addi	sp,sp,-80
 78e:	ec06                	sd	ra,24(sp)
 790:	e822                	sd	s0,16(sp)
 792:	1000                	addi	s0,sp,32
 794:	e010                	sd	a2,0(s0)
 796:	e414                	sd	a3,8(s0)
 798:	e818                	sd	a4,16(s0)
 79a:	ec1c                	sd	a5,24(s0)
 79c:	03043023          	sd	a6,32(s0)
 7a0:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 7a4:	8622                	mv	a2,s0
 7a6:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 7aa:	d31ff0ef          	jal	4da <vprintf>
}
 7ae:	60e2                	ld	ra,24(sp)
 7b0:	6442                	ld	s0,16(sp)
 7b2:	6161                	addi	sp,sp,80
 7b4:	8082                	ret

00000000000007b6 <printf>:

void
printf(const char *fmt, ...)
{
 7b6:	711d                	addi	sp,sp,-96
 7b8:	ec06                	sd	ra,24(sp)
 7ba:	e822                	sd	s0,16(sp)
 7bc:	1000                	addi	s0,sp,32
 7be:	e40c                	sd	a1,8(s0)
 7c0:	e810                	sd	a2,16(s0)
 7c2:	ec14                	sd	a3,24(s0)
 7c4:	f018                	sd	a4,32(s0)
 7c6:	f41c                	sd	a5,40(s0)
 7c8:	03043823          	sd	a6,48(s0)
 7cc:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 7d0:	00840613          	addi	a2,s0,8
 7d4:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 7d8:	85aa                	mv	a1,a0
 7da:	4505                	li	a0,1
 7dc:	cffff0ef          	jal	4da <vprintf>
}
 7e0:	60e2                	ld	ra,24(sp)
 7e2:	6442                	ld	s0,16(sp)
 7e4:	6125                	addi	sp,sp,96
 7e6:	8082                	ret

00000000000007e8 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 7e8:	1141                	addi	sp,sp,-16
 7ea:	e406                	sd	ra,8(sp)
 7ec:	e022                	sd	s0,0(sp)
 7ee:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 7f0:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 7f4:	00001797          	auipc	a5,0x1
 7f8:	80c7b783          	ld	a5,-2036(a5) # 1000 <freep>
 7fc:	a095                	j	860 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 7fe:	ff852583          	lw	a1,-8(a0)
 802:	6390                	ld	a2,0(a5)
 804:	02059813          	slli	a6,a1,0x20
 808:	01c85693          	srli	a3,a6,0x1c
 80c:	96ba                	add	a3,a3,a4
 80e:	02d60563          	beq	a2,a3,838 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 812:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 816:	4790                	lw	a2,8(a5)
 818:	02061593          	slli	a1,a2,0x20
 81c:	01c5d693          	srli	a3,a1,0x1c
 820:	96be                	add	a3,a3,a5
 822:	02d70263          	beq	a4,a3,846 <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 826:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 828:	00000717          	auipc	a4,0x0
 82c:	7cf73c23          	sd	a5,2008(a4) # 1000 <freep>
}
 830:	60a2                	ld	ra,8(sp)
 832:	6402                	ld	s0,0(sp)
 834:	0141                	addi	sp,sp,16
 836:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 838:	4614                	lw	a3,8(a2)
 83a:	9ead                	addw	a3,a3,a1
 83c:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 840:	6394                	ld	a3,0(a5)
 842:	6290                	ld	a2,0(a3)
 844:	b7f9                	j	812 <free+0x2a>
    p->s.size += bp->s.size;
 846:	ff852703          	lw	a4,-8(a0)
 84a:	9f31                	addw	a4,a4,a2
 84c:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 84e:	ff053703          	ld	a4,-16(a0)
 852:	bfd1                	j	826 <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 854:	6394                	ld	a3,0(a5)
 856:	00d7e463          	bltu	a5,a3,85e <free+0x76>
 85a:	fad762e3          	bltu	a4,a3,7fe <free+0x16>
 85e:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 860:	fee7fae3          	bgeu	a5,a4,854 <free+0x6c>
 864:	6394                	ld	a3,0(a5)
 866:	f8d76ce3          	bltu	a4,a3,7fe <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 86a:	f8d7fae3          	bgeu	a5,a3,7fe <free+0x16>
 86e:	87b6                	mv	a5,a3
 870:	bfc5                	j	860 <free+0x78>

0000000000000872 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 872:	7139                	addi	sp,sp,-64
 874:	fc06                	sd	ra,56(sp)
 876:	f822                	sd	s0,48(sp)
 878:	f04a                	sd	s2,32(sp)
 87a:	ec4e                	sd	s3,24(sp)
 87c:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 87e:	02051993          	slli	s3,a0,0x20
 882:	0209d993          	srli	s3,s3,0x20
 886:	09bd                	addi	s3,s3,15
 888:	0049d993          	srli	s3,s3,0x4
 88c:	2985                	addiw	s3,s3,1
 88e:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 890:	00000517          	auipc	a0,0x0
 894:	77053503          	ld	a0,1904(a0) # 1000 <freep>
 898:	c905                	beqz	a0,8c8 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 89a:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 89c:	4798                	lw	a4,8(a5)
 89e:	09377663          	bgeu	a4,s3,92a <malloc+0xb8>
 8a2:	f426                	sd	s1,40(sp)
 8a4:	e852                	sd	s4,16(sp)
 8a6:	e456                	sd	s5,8(sp)
 8a8:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 8aa:	8a4e                	mv	s4,s3
 8ac:	6705                	lui	a4,0x1
 8ae:	00e9f363          	bgeu	s3,a4,8b4 <malloc+0x42>
 8b2:	6a05                	lui	s4,0x1
 8b4:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 8b8:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 8bc:	00000497          	auipc	s1,0x0
 8c0:	74448493          	addi	s1,s1,1860 # 1000 <freep>
  if(p == (char*)-1)
 8c4:	5afd                	li	s5,-1
 8c6:	a83d                	j	904 <malloc+0x92>
 8c8:	f426                	sd	s1,40(sp)
 8ca:	e852                	sd	s4,16(sp)
 8cc:	e456                	sd	s5,8(sp)
 8ce:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 8d0:	00000797          	auipc	a5,0x0
 8d4:	74078793          	addi	a5,a5,1856 # 1010 <base>
 8d8:	00000717          	auipc	a4,0x0
 8dc:	72f73423          	sd	a5,1832(a4) # 1000 <freep>
 8e0:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 8e2:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 8e6:	b7d1                	j	8aa <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 8e8:	6398                	ld	a4,0(a5)
 8ea:	e118                	sd	a4,0(a0)
 8ec:	a899                	j	942 <malloc+0xd0>
  hp->s.size = nu;
 8ee:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 8f2:	0541                	addi	a0,a0,16
 8f4:	ef5ff0ef          	jal	7e8 <free>
  return freep;
 8f8:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 8fa:	c125                	beqz	a0,95a <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 8fc:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 8fe:	4798                	lw	a4,8(a5)
 900:	03277163          	bgeu	a4,s2,922 <malloc+0xb0>
    if(p == freep)
 904:	6098                	ld	a4,0(s1)
 906:	853e                	mv	a0,a5
 908:	fef71ae3          	bne	a4,a5,8fc <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 90c:	8552                	mv	a0,s4
 90e:	aefff0ef          	jal	3fc <sbrk>
  if(p == (char*)-1)
 912:	fd551ee3          	bne	a0,s5,8ee <malloc+0x7c>
        return 0;
 916:	4501                	li	a0,0
 918:	74a2                	ld	s1,40(sp)
 91a:	6a42                	ld	s4,16(sp)
 91c:	6aa2                	ld	s5,8(sp)
 91e:	6b02                	ld	s6,0(sp)
 920:	a03d                	j	94e <malloc+0xdc>
 922:	74a2                	ld	s1,40(sp)
 924:	6a42                	ld	s4,16(sp)
 926:	6aa2                	ld	s5,8(sp)
 928:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 92a:	fae90fe3          	beq	s2,a4,8e8 <malloc+0x76>
        p->s.size -= nunits;
 92e:	4137073b          	subw	a4,a4,s3
 932:	c798                	sw	a4,8(a5)
        p += p->s.size;
 934:	02071693          	slli	a3,a4,0x20
 938:	01c6d713          	srli	a4,a3,0x1c
 93c:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 93e:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 942:	00000717          	auipc	a4,0x0
 946:	6aa73f23          	sd	a0,1726(a4) # 1000 <freep>
      return (void*)(p + 1);
 94a:	01078513          	addi	a0,a5,16
  }
}
 94e:	70e2                	ld	ra,56(sp)
 950:	7442                	ld	s0,48(sp)
 952:	7902                	ld	s2,32(sp)
 954:	69e2                	ld	s3,24(sp)
 956:	6121                	addi	sp,sp,64
 958:	8082                	ret
 95a:	74a2                	ld	s1,40(sp)
 95c:	6a42                	ld	s4,16(sp)
 95e:	6aa2                	ld	s5,8(sp)
 960:	6b02                	ld	s6,0(sp)
 962:	b7f5                	j	94e <malloc+0xdc>

0000000000000964 <thread_init>:
struct thread *current_thread;
extern void thread_switch(uint64, uint64);
              
void 
thread_init(void)
{
 964:	1141                	addi	sp,sp,-16
 966:	e406                	sd	ra,8(sp)
 968:	e022                	sd	s0,0(sp)
 96a:	0800                	addi	s0,sp,16
  // main() is thread 0, which will make the first invocation to
  // thread_schedule(). It needs a stack so that the first thread_switch() can
  // save thread 0's state.
  current_thread = &all_thread[0];
 96c:	00000797          	auipc	a5,0x0
 970:	6b478793          	addi	a5,a5,1716 # 1020 <all_thread>
 974:	00000717          	auipc	a4,0x0
 978:	68f73a23          	sd	a5,1684(a4) # 1008 <current_thread>
  current_thread->state = RUNNING;
 97c:	00002717          	auipc	a4,0x2
 980:	6a470713          	addi	a4,a4,1700 # 3020 <all_thread+0x2000>
 984:	4785                	li	a5,1
 986:	c31c                	sw	a5,0(a4)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 988:	00002797          	auipc	a5,0x2
 98c:	62878793          	addi	a5,a5,1576 # 2fb0 <all_thread+0x1f90>
  return (struct context *)(top & ~(uint64)0xf);
 990:	9bc1                	andi	a5,a5,-16
  // Thread 0 runs on the process's own stack, but the first thread_switch()
  // still needs a writable place to save its context.
  current_thread->context = thread_context_slot(current_thread);
 992:	e71c                	sd	a5,8(a4)
}
 994:	60a2                	ld	ra,8(sp)
 996:	6402                	ld	s0,0(sp)
 998:	0141                	addi	sp,sp,16
 99a:	8082                	ret

000000000000099c <thread_schedule>:

void 
thread_schedule(void)
{
 99c:	1141                	addi	sp,sp,-16
 99e:	e406                	sd	ra,8(sp)
 9a0:	e022                	sd	s0,0(sp)
 9a2:	0800                	addi	s0,sp,16
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
 9a4:	00000597          	auipc	a1,0x0
 9a8:	6645b583          	ld	a1,1636(a1) # 1008 <current_thread>
 9ac:	6789                	lui	a5,0x2
 9ae:	07c1                	addi	a5,a5,16 # 2010 <all_thread+0xff0>
 9b0:	97ae                	add	a5,a5,a1
 9b2:	4711                	li	a4,4
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
 9b4:	00008897          	auipc	a7,0x8
 9b8:	6ac88893          	addi	a7,a7,1708 # 9060 <all_thread+0x8040>
      t = all_thread;
    if(t->state == RUNNABLE) {
 9bc:	6809                	lui	a6,0x2
 9be:	4509                	li	a0,2
      next_thread = t;
      break;
    }
    t = t + 1;
 9c0:	01080613          	addi	a2,a6,16 # 2010 <all_thread+0xff0>
 9c4:	a809                	j	9d6 <thread_schedule+0x3a>
    if(t->state == RUNNABLE) {
 9c6:	010786b3          	add	a3,a5,a6
 9ca:	4294                	lw	a3,0(a3)
 9cc:	02a68563          	beq	a3,a0,9f6 <thread_schedule+0x5a>
    t = t + 1;
 9d0:	97b2                	add	a5,a5,a2
  for(int i = 0; i < MAX_THREAD; i++){
 9d2:	377d                	addiw	a4,a4,-1
 9d4:	cb01                	beqz	a4,9e4 <thread_schedule+0x48>
    if(t >= all_thread + MAX_THREAD)
 9d6:	ff17e8e3          	bltu	a5,a7,9c6 <thread_schedule+0x2a>
      t = all_thread;
 9da:	00000797          	auipc	a5,0x0
 9de:	64678793          	addi	a5,a5,1606 # 1020 <all_thread>
 9e2:	b7d5                	j	9c6 <thread_schedule+0x2a>
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
 9e4:	00000517          	auipc	a0,0x0
 9e8:	1a450513          	addi	a0,a0,420 # b88 <thread_switch+0xb2>
 9ec:	dcbff0ef          	jal	7b6 <printf>
    exit(-1);
 9f0:	557d                	li	a0,-1
 9f2:	983ff0ef          	jal	374 <exit>
  }

  if (current_thread != next_thread) {         /* switch threads?  */
 9f6:	02f58163          	beq	a1,a5,a18 <thread_schedule+0x7c>
    next_thread->state = RUNNING;
 9fa:	6689                	lui	a3,0x2
 9fc:	00d78733          	add	a4,a5,a3
 a00:	4605                	li	a2,1
 a02:	c310                	sw	a2,0(a4)
    t = current_thread;
    current_thread = next_thread;
 a04:	00000617          	auipc	a2,0x0
 a08:	60f63223          	sd	a5,1540(a2) # 1008 <current_thread>
    thread_switch((uint64)t->context, (uint64)next_thread->context);
 a0c:	00d587b3          	add	a5,a1,a3
 a10:	670c                	ld	a1,8(a4)
 a12:	6788                	ld	a0,8(a5)
 a14:	0c2000ef          	jal	ad6 <thread_switch>
  } else
    next_thread = 0;
}
 a18:	60a2                	ld	ra,8(sp)
 a1a:	6402                	ld	s0,0(sp)
 a1c:	0141                	addi	sp,sp,16
 a1e:	8082                	ret

0000000000000a20 <thread_create>:

void 
thread_create(void (*func)())
{
 a20:	1101                	addi	sp,sp,-32
 a22:	ec06                	sd	ra,24(sp)
 a24:	e822                	sd	s0,16(sp)
 a26:	e426                	sd	s1,8(sp)
 a28:	e04a                	sd	s2,0(sp)
 a2a:	1000                	addi	s0,sp,32
 a2c:	892a                	mv	s2,a0
  struct thread *t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 a2e:	00002797          	auipc	a5,0x2
 a32:	60278793          	addi	a5,a5,1538 # 3030 <all_thread+0x2010>
 a36:	0000a597          	auipc	a1,0xa
 a3a:	63a58593          	addi	a1,a1,1594 # b070 <all_thread+0xa050>
 a3e:	6609                	lui	a2,0x2
 a40:	0641                	addi	a2,a2,16 # 2010 <all_thread+0xff0>
    if (t->state == FREE) break;
 a42:	873e                	mv	a4,a5
 a44:	ff07a683          	lw	a3,-16(a5)
 a48:	ce9d                	beqz	a3,a86 <thread_create+0x66>
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 a4a:	97b2                	add	a5,a5,a2
 a4c:	feb79be3          	bne	a5,a1,a42 <thread_create+0x22>
  }
  t->state = RUNNABLE;
 a50:	6489                	lui	s1,0x2
 a52:	94ba                	add	s1,s1,a4
 a54:	4789                	li	a5,2
 a56:	c09c                	sw	a5,0(s1)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 a58:	6789                	lui	a5,0x2
 a5a:	f9078793          	addi	a5,a5,-112 # 1f90 <all_thread+0xf70>
 a5e:	973e                	add	a4,a4,a5
  return (struct context *)(top & ~(uint64)0xf);
 a60:	ff077513          	andi	a0,a4,-16
  // A never-run thread has no saved state, so construct one: thread_switch()
  // restores ra and sp, and `ret` then starts func on this thread's own stack.
  t->context = thread_context_slot(t);
 a64:	e488                	sd	a0,8(s1)
  memset(t->context, 0, sizeof(struct context));
 a66:	07000613          	li	a2,112
 a6a:	4581                	li	a1,0
 a6c:	f0aff0ef          	jal	176 <memset>
  t->context->ra = (uint64)func;
 a70:	649c                	ld	a5,8(s1)
 a72:	0127b023          	sd	s2,0(a5)
  t->context->sp = (uint64)t->context;   // 16-byte aligned, grows down
 a76:	649c                	ld	a5,8(s1)
 a78:	e79c                	sd	a5,8(a5)
}
 a7a:	60e2                	ld	ra,24(sp)
 a7c:	6442                	ld	s0,16(sp)
 a7e:	64a2                	ld	s1,8(sp)
 a80:	6902                	ld	s2,0(sp)
 a82:	6105                	addi	sp,sp,32
 a84:	8082                	ret
 a86:	7779                	lui	a4,0xffffe
 a88:	1741                	addi	a4,a4,-16 # ffffffffffffdff0 <all_thread+0xffffffffffffcfd0>
 a8a:	973e                	add	a4,a4,a5
 a8c:	b7d1                	j	a50 <thread_create+0x30>

0000000000000a8e <thread_yield>:

void 
thread_yield(void)
{
 a8e:	1141                	addi	sp,sp,-16
 a90:	e406                	sd	ra,8(sp)
 a92:	e022                	sd	s0,0(sp)
 a94:	0800                	addi	s0,sp,16
  current_thread->state = RUNNABLE;
 a96:	00000797          	auipc	a5,0x0
 a9a:	5727b783          	ld	a5,1394(a5) # 1008 <current_thread>
 a9e:	6709                	lui	a4,0x2
 aa0:	97ba                	add	a5,a5,a4
 aa2:	4709                	li	a4,2
 aa4:	c398                	sw	a4,0(a5)
  thread_schedule();
 aa6:	ef7ff0ef          	jal	99c <thread_schedule>
}
 aaa:	60a2                	ld	ra,8(sp)
 aac:	6402                	ld	s0,0(sp)
 aae:	0141                	addi	sp,sp,16
 ab0:	8082                	ret

0000000000000ab2 <thread_exit>:

void thread_exit(void) {
 ab2:	1141                	addi	sp,sp,-16
 ab4:	e406                	sd	ra,8(sp)
 ab6:	e022                	sd	s0,0(sp)
 ab8:	0800                	addi	s0,sp,16
  current_thread->state = FREE;
 aba:	00000797          	auipc	a5,0x0
 abe:	54e7b783          	ld	a5,1358(a5) # 1008 <current_thread>
 ac2:	6709                	lui	a4,0x2
 ac4:	97ba                	add	a5,a5,a4
 ac6:	0007a023          	sw	zero,0(a5)
  thread_schedule();
 aca:	ed3ff0ef          	jal	99c <thread_schedule>
}
 ace:	60a2                	ld	ra,8(sp)
 ad0:	6402                	ld	s0,0(sp)
 ad2:	0141                	addi	sp,sp,16
 ad4:	8082                	ret

0000000000000ad6 <thread_switch>:
 ad6:	00153023          	sd	ra,0(a0)
 ada:	00253423          	sd	sp,8(a0)
 ade:	e900                	sd	s0,16(a0)
 ae0:	ed04                	sd	s1,24(a0)
 ae2:	03253023          	sd	s2,32(a0)
 ae6:	03353423          	sd	s3,40(a0)
 aea:	03453823          	sd	s4,48(a0)
 aee:	03553c23          	sd	s5,56(a0)
 af2:	05653023          	sd	s6,64(a0)
 af6:	05753423          	sd	s7,72(a0)
 afa:	05853823          	sd	s8,80(a0)
 afe:	05953c23          	sd	s9,88(a0)
 b02:	07a53023          	sd	s10,96(a0)
 b06:	07b53423          	sd	s11,104(a0)
 b0a:	0005b083          	ld	ra,0(a1)
 b0e:	0085b103          	ld	sp,8(a1)
 b12:	6980                	ld	s0,16(a1)
 b14:	6d84                	ld	s1,24(a1)
 b16:	0205b903          	ld	s2,32(a1)
 b1a:	0285b983          	ld	s3,40(a1)
 b1e:	0305ba03          	ld	s4,48(a1)
 b22:	0385ba83          	ld	s5,56(a1)
 b26:	0405bb03          	ld	s6,64(a1)
 b2a:	0485bb83          	ld	s7,72(a1)
 b2e:	0505bc03          	ld	s8,80(a1)
 b32:	0585bc83          	ld	s9,88(a1)
 b36:	0605bd03          	ld	s10,96(a1)
 b3a:	0685bd83          	ld	s11,104(a1)
 b3e:	8082                	ret
