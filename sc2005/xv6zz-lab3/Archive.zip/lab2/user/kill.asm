
user/_kill:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char **argv)
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	1000                	addi	s0,sp,32
  int i;

  if(argc < 2){
   8:	4785                	li	a5,1
   a:	02a7d963          	bge	a5,a0,3c <main+0x3c>
   e:	e426                	sd	s1,8(sp)
  10:	e04a                	sd	s2,0(sp)
  12:	00858493          	addi	s1,a1,8
  16:	ffe5091b          	addiw	s2,a0,-2
  1a:	02091793          	slli	a5,s2,0x20
  1e:	01d7d913          	srli	s2,a5,0x1d
  22:	05c1                	addi	a1,a1,16
  24:	992e                	add	s2,s2,a1
    fprintf(2, "usage: kill pid...\n");
    exit(1);
  }
  for(i=1; i<argc; i++)
    kill(atoi(argv[i]));
  26:	6088                	ld	a0,0(s1)
  28:	1be000ef          	jal	1e6 <atoi>
  2c:	2e4000ef          	jal	310 <kill>
  for(i=1; i<argc; i++)
  30:	04a1                	addi	s1,s1,8
  32:	ff249ae3          	bne	s1,s2,26 <main+0x26>
  exit(0);
  36:	4501                	li	a0,0
  38:	2a8000ef          	jal	2e0 <exit>
  3c:	e426                	sd	s1,8(sp)
  3e:	e04a                	sd	s2,0(sp)
    fprintf(2, "usage: kill pid...\n");
  40:	00001597          	auipc	a1,0x1
  44:	a7058593          	addi	a1,a1,-1424 # ab0 <thread_switch+0x6e>
  48:	4509                	li	a0,2
  4a:	6ae000ef          	jal	6f8 <fprintf>
    exit(1);
  4e:	4505                	li	a0,1
  50:	290000ef          	jal	2e0 <exit>

0000000000000054 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  54:	1141                	addi	sp,sp,-16
  56:	e406                	sd	ra,8(sp)
  58:	e022                	sd	s0,0(sp)
  5a:	0800                	addi	s0,sp,16
  extern int main();
  main();
  5c:	fa5ff0ef          	jal	0 <main>
  exit(0);
  60:	4501                	li	a0,0
  62:	27e000ef          	jal	2e0 <exit>

0000000000000066 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  66:	1141                	addi	sp,sp,-16
  68:	e406                	sd	ra,8(sp)
  6a:	e022                	sd	s0,0(sp)
  6c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  6e:	87aa                	mv	a5,a0
  70:	0585                	addi	a1,a1,1
  72:	0785                	addi	a5,a5,1
  74:	fff5c703          	lbu	a4,-1(a1)
  78:	fee78fa3          	sb	a4,-1(a5)
  7c:	fb75                	bnez	a4,70 <strcpy+0xa>
    ;
  return os;
}
  7e:	60a2                	ld	ra,8(sp)
  80:	6402                	ld	s0,0(sp)
  82:	0141                	addi	sp,sp,16
  84:	8082                	ret

0000000000000086 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  86:	1141                	addi	sp,sp,-16
  88:	e406                	sd	ra,8(sp)
  8a:	e022                	sd	s0,0(sp)
  8c:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  8e:	00054783          	lbu	a5,0(a0)
  92:	cb91                	beqz	a5,a6 <strcmp+0x20>
  94:	0005c703          	lbu	a4,0(a1)
  98:	00f71763          	bne	a4,a5,a6 <strcmp+0x20>
    p++, q++;
  9c:	0505                	addi	a0,a0,1
  9e:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
  a0:	00054783          	lbu	a5,0(a0)
  a4:	fbe5                	bnez	a5,94 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
  a6:	0005c503          	lbu	a0,0(a1)
}
  aa:	40a7853b          	subw	a0,a5,a0
  ae:	60a2                	ld	ra,8(sp)
  b0:	6402                	ld	s0,0(sp)
  b2:	0141                	addi	sp,sp,16
  b4:	8082                	ret

00000000000000b6 <strlen>:

uint
strlen(const char *s)
{
  b6:	1141                	addi	sp,sp,-16
  b8:	e406                	sd	ra,8(sp)
  ba:	e022                	sd	s0,0(sp)
  bc:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
  be:	00054783          	lbu	a5,0(a0)
  c2:	cf91                	beqz	a5,de <strlen+0x28>
  c4:	00150793          	addi	a5,a0,1
  c8:	86be                	mv	a3,a5
  ca:	0785                	addi	a5,a5,1
  cc:	fff7c703          	lbu	a4,-1(a5)
  d0:	ff65                	bnez	a4,c8 <strlen+0x12>
  d2:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
  d6:	60a2                	ld	ra,8(sp)
  d8:	6402                	ld	s0,0(sp)
  da:	0141                	addi	sp,sp,16
  dc:	8082                	ret
  for(n = 0; s[n]; n++)
  de:	4501                	li	a0,0
  e0:	bfdd                	j	d6 <strlen+0x20>

00000000000000e2 <memset>:

void*
memset(void *dst, int c, uint n)
{
  e2:	1141                	addi	sp,sp,-16
  e4:	e406                	sd	ra,8(sp)
  e6:	e022                	sd	s0,0(sp)
  e8:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
  ea:	ca19                	beqz	a2,100 <memset+0x1e>
  ec:	87aa                	mv	a5,a0
  ee:	1602                	slli	a2,a2,0x20
  f0:	9201                	srli	a2,a2,0x20
  f2:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
  f6:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
  fa:	0785                	addi	a5,a5,1
  fc:	fee79de3          	bne	a5,a4,f6 <memset+0x14>
  }
  return dst;
}
 100:	60a2                	ld	ra,8(sp)
 102:	6402                	ld	s0,0(sp)
 104:	0141                	addi	sp,sp,16
 106:	8082                	ret

0000000000000108 <strchr>:

char*
strchr(const char *s, char c)
{
 108:	1141                	addi	sp,sp,-16
 10a:	e406                	sd	ra,8(sp)
 10c:	e022                	sd	s0,0(sp)
 10e:	0800                	addi	s0,sp,16
  for(; *s; s++)
 110:	00054783          	lbu	a5,0(a0)
 114:	c799                	beqz	a5,122 <strchr+0x1a>
    if(*s == c)
 116:	00f58763          	beq	a1,a5,124 <strchr+0x1c>
  for(; *s; s++)
 11a:	0505                	addi	a0,a0,1
 11c:	00054783          	lbu	a5,0(a0)
 120:	fbfd                	bnez	a5,116 <strchr+0xe>
      return (char*)s;
  return 0;
 122:	4501                	li	a0,0
}
 124:	60a2                	ld	ra,8(sp)
 126:	6402                	ld	s0,0(sp)
 128:	0141                	addi	sp,sp,16
 12a:	8082                	ret

000000000000012c <gets>:

char*
gets(char *buf, int max)
{
 12c:	711d                	addi	sp,sp,-96
 12e:	ec86                	sd	ra,88(sp)
 130:	e8a2                	sd	s0,80(sp)
 132:	e4a6                	sd	s1,72(sp)
 134:	e0ca                	sd	s2,64(sp)
 136:	fc4e                	sd	s3,56(sp)
 138:	f852                	sd	s4,48(sp)
 13a:	f456                	sd	s5,40(sp)
 13c:	f05a                	sd	s6,32(sp)
 13e:	ec5e                	sd	s7,24(sp)
 140:	e862                	sd	s8,16(sp)
 142:	1080                	addi	s0,sp,96
 144:	8baa                	mv	s7,a0
 146:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 148:	892a                	mv	s2,a0
 14a:	4481                	li	s1,0
    cc = read(0, &c, 1);
 14c:	faf40b13          	addi	s6,s0,-81
 150:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 152:	8c26                	mv	s8,s1
 154:	0014899b          	addiw	s3,s1,1
 158:	84ce                	mv	s1,s3
 15a:	0349d863          	bge	s3,s4,18a <gets+0x5e>
    cc = read(0, &c, 1);
 15e:	8656                	mv	a2,s5
 160:	85da                	mv	a1,s6
 162:	4501                	li	a0,0
 164:	194000ef          	jal	2f8 <read>
    if(cc < 1)
 168:	02a05163          	blez	a0,18a <gets+0x5e>
      break;
    buf[i++] = c;
 16c:	faf44783          	lbu	a5,-81(s0)
 170:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 174:	0905                	addi	s2,s2,1
 176:	ff678713          	addi	a4,a5,-10
 17a:	00173713          	seqz	a4,a4
 17e:	17cd                	addi	a5,a5,-13
 180:	0017b793          	seqz	a5,a5
 184:	8fd9                	or	a5,a5,a4
 186:	d7f1                	beqz	a5,152 <gets+0x26>
    buf[i++] = c;
 188:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 18a:	9c5e                	add	s8,s8,s7
 18c:	000c0023          	sb	zero,0(s8)
  return buf;
}
 190:	855e                	mv	a0,s7
 192:	60e6                	ld	ra,88(sp)
 194:	6446                	ld	s0,80(sp)
 196:	64a6                	ld	s1,72(sp)
 198:	6906                	ld	s2,64(sp)
 19a:	79e2                	ld	s3,56(sp)
 19c:	7a42                	ld	s4,48(sp)
 19e:	7aa2                	ld	s5,40(sp)
 1a0:	7b02                	ld	s6,32(sp)
 1a2:	6be2                	ld	s7,24(sp)
 1a4:	6c42                	ld	s8,16(sp)
 1a6:	6125                	addi	sp,sp,96
 1a8:	8082                	ret

00000000000001aa <stat>:

int
stat(const char *n, struct stat *st)
{
 1aa:	1101                	addi	sp,sp,-32
 1ac:	ec06                	sd	ra,24(sp)
 1ae:	e822                	sd	s0,16(sp)
 1b0:	e04a                	sd	s2,0(sp)
 1b2:	1000                	addi	s0,sp,32
 1b4:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 1b6:	4581                	li	a1,0
 1b8:	168000ef          	jal	320 <open>
  if(fd < 0)
 1bc:	02054263          	bltz	a0,1e0 <stat+0x36>
 1c0:	e426                	sd	s1,8(sp)
 1c2:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 1c4:	85ca                	mv	a1,s2
 1c6:	172000ef          	jal	338 <fstat>
 1ca:	892a                	mv	s2,a0
  close(fd);
 1cc:	8526                	mv	a0,s1
 1ce:	13a000ef          	jal	308 <close>
  return r;
 1d2:	64a2                	ld	s1,8(sp)
}
 1d4:	854a                	mv	a0,s2
 1d6:	60e2                	ld	ra,24(sp)
 1d8:	6442                	ld	s0,16(sp)
 1da:	6902                	ld	s2,0(sp)
 1dc:	6105                	addi	sp,sp,32
 1de:	8082                	ret
    return -1;
 1e0:	57fd                	li	a5,-1
 1e2:	893e                	mv	s2,a5
 1e4:	bfc5                	j	1d4 <stat+0x2a>

00000000000001e6 <atoi>:

int
atoi(const char *s)
{
 1e6:	1141                	addi	sp,sp,-16
 1e8:	e406                	sd	ra,8(sp)
 1ea:	e022                	sd	s0,0(sp)
 1ec:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 1ee:	00054683          	lbu	a3,0(a0)
 1f2:	fd06879b          	addiw	a5,a3,-48
 1f6:	0ff7f793          	zext.b	a5,a5
 1fa:	4625                	li	a2,9
 1fc:	02f66963          	bltu	a2,a5,22e <atoi+0x48>
 200:	872a                	mv	a4,a0
  n = 0;
 202:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 204:	0705                	addi	a4,a4,1
 206:	0025179b          	slliw	a5,a0,0x2
 20a:	9fa9                	addw	a5,a5,a0
 20c:	0017979b          	slliw	a5,a5,0x1
 210:	9fb5                	addw	a5,a5,a3
 212:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 216:	00074683          	lbu	a3,0(a4)
 21a:	fd06879b          	addiw	a5,a3,-48
 21e:	0ff7f793          	zext.b	a5,a5
 222:	fef671e3          	bgeu	a2,a5,204 <atoi+0x1e>
  return n;
}
 226:	60a2                	ld	ra,8(sp)
 228:	6402                	ld	s0,0(sp)
 22a:	0141                	addi	sp,sp,16
 22c:	8082                	ret
  n = 0;
 22e:	4501                	li	a0,0
 230:	bfdd                	j	226 <atoi+0x40>

0000000000000232 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 232:	1141                	addi	sp,sp,-16
 234:	e406                	sd	ra,8(sp)
 236:	e022                	sd	s0,0(sp)
 238:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 23a:	02b57563          	bgeu	a0,a1,264 <memmove+0x32>
    while(n-- > 0)
 23e:	00c05f63          	blez	a2,25c <memmove+0x2a>
 242:	1602                	slli	a2,a2,0x20
 244:	9201                	srli	a2,a2,0x20
 246:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 24a:	872a                	mv	a4,a0
      *dst++ = *src++;
 24c:	0585                	addi	a1,a1,1
 24e:	0705                	addi	a4,a4,1
 250:	fff5c683          	lbu	a3,-1(a1)
 254:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 258:	fee79ae3          	bne	a5,a4,24c <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 25c:	60a2                	ld	ra,8(sp)
 25e:	6402                	ld	s0,0(sp)
 260:	0141                	addi	sp,sp,16
 262:	8082                	ret
    while(n-- > 0)
 264:	fec05ce3          	blez	a2,25c <memmove+0x2a>
    dst += n;
 268:	00c50733          	add	a4,a0,a2
    src += n;
 26c:	95b2                	add	a1,a1,a2
 26e:	fff6079b          	addiw	a5,a2,-1
 272:	1782                	slli	a5,a5,0x20
 274:	9381                	srli	a5,a5,0x20
 276:	fff7c793          	not	a5,a5
 27a:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 27c:	15fd                	addi	a1,a1,-1
 27e:	177d                	addi	a4,a4,-1
 280:	0005c683          	lbu	a3,0(a1)
 284:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 288:	fef71ae3          	bne	a4,a5,27c <memmove+0x4a>
 28c:	bfc1                	j	25c <memmove+0x2a>

000000000000028e <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 28e:	1141                	addi	sp,sp,-16
 290:	e406                	sd	ra,8(sp)
 292:	e022                	sd	s0,0(sp)
 294:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 296:	ce19                	beqz	a2,2b4 <memcmp+0x26>
 298:	1602                	slli	a2,a2,0x20
 29a:	9201                	srli	a2,a2,0x20
 29c:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 2a0:	00054783          	lbu	a5,0(a0)
 2a4:	0005c703          	lbu	a4,0(a1)
 2a8:	00e79b63          	bne	a5,a4,2be <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 2ac:	0505                	addi	a0,a0,1
    p2++;
 2ae:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 2b0:	fed518e3          	bne	a0,a3,2a0 <memcmp+0x12>
  }
  return 0;
 2b4:	4501                	li	a0,0
}
 2b6:	60a2                	ld	ra,8(sp)
 2b8:	6402                	ld	s0,0(sp)
 2ba:	0141                	addi	sp,sp,16
 2bc:	8082                	ret
      return *p1 - *p2;
 2be:	40e7853b          	subw	a0,a5,a4
 2c2:	bfd5                	j	2b6 <memcmp+0x28>

00000000000002c4 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 2c4:	1141                	addi	sp,sp,-16
 2c6:	e406                	sd	ra,8(sp)
 2c8:	e022                	sd	s0,0(sp)
 2ca:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 2cc:	f67ff0ef          	jal	232 <memmove>
}
 2d0:	60a2                	ld	ra,8(sp)
 2d2:	6402                	ld	s0,0(sp)
 2d4:	0141                	addi	sp,sp,16
 2d6:	8082                	ret

00000000000002d8 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 2d8:	4885                	li	a7,1
 ecall
 2da:	00000073          	ecall
 ret
 2de:	8082                	ret

00000000000002e0 <exit>:
.global exit
exit:
 li a7, SYS_exit
 2e0:	4889                	li	a7,2
 ecall
 2e2:	00000073          	ecall
 ret
 2e6:	8082                	ret

00000000000002e8 <wait>:
.global wait
wait:
 li a7, SYS_wait
 2e8:	488d                	li	a7,3
 ecall
 2ea:	00000073          	ecall
 ret
 2ee:	8082                	ret

00000000000002f0 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 2f0:	4891                	li	a7,4
 ecall
 2f2:	00000073          	ecall
 ret
 2f6:	8082                	ret

00000000000002f8 <read>:
.global read
read:
 li a7, SYS_read
 2f8:	4895                	li	a7,5
 ecall
 2fa:	00000073          	ecall
 ret
 2fe:	8082                	ret

0000000000000300 <write>:
.global write
write:
 li a7, SYS_write
 300:	48c1                	li	a7,16
 ecall
 302:	00000073          	ecall
 ret
 306:	8082                	ret

0000000000000308 <close>:
.global close
close:
 li a7, SYS_close
 308:	48d5                	li	a7,21
 ecall
 30a:	00000073          	ecall
 ret
 30e:	8082                	ret

0000000000000310 <kill>:
.global kill
kill:
 li a7, SYS_kill
 310:	4899                	li	a7,6
 ecall
 312:	00000073          	ecall
 ret
 316:	8082                	ret

0000000000000318 <exec>:
.global exec
exec:
 li a7, SYS_exec
 318:	489d                	li	a7,7
 ecall
 31a:	00000073          	ecall
 ret
 31e:	8082                	ret

0000000000000320 <open>:
.global open
open:
 li a7, SYS_open
 320:	48bd                	li	a7,15
 ecall
 322:	00000073          	ecall
 ret
 326:	8082                	ret

0000000000000328 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 328:	48c5                	li	a7,17
 ecall
 32a:	00000073          	ecall
 ret
 32e:	8082                	ret

0000000000000330 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 330:	48c9                	li	a7,18
 ecall
 332:	00000073          	ecall
 ret
 336:	8082                	ret

0000000000000338 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 338:	48a1                	li	a7,8
 ecall
 33a:	00000073          	ecall
 ret
 33e:	8082                	ret

0000000000000340 <link>:
.global link
link:
 li a7, SYS_link
 340:	48cd                	li	a7,19
 ecall
 342:	00000073          	ecall
 ret
 346:	8082                	ret

0000000000000348 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 348:	48d1                	li	a7,20
 ecall
 34a:	00000073          	ecall
 ret
 34e:	8082                	ret

0000000000000350 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 350:	48a5                	li	a7,9
 ecall
 352:	00000073          	ecall
 ret
 356:	8082                	ret

0000000000000358 <dup>:
.global dup
dup:
 li a7, SYS_dup
 358:	48a9                	li	a7,10
 ecall
 35a:	00000073          	ecall
 ret
 35e:	8082                	ret

0000000000000360 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 360:	48ad                	li	a7,11
 ecall
 362:	00000073          	ecall
 ret
 366:	8082                	ret

0000000000000368 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 368:	48b1                	li	a7,12
 ecall
 36a:	00000073          	ecall
 ret
 36e:	8082                	ret

0000000000000370 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 370:	48b5                	li	a7,13
 ecall
 372:	00000073          	ecall
 ret
 376:	8082                	ret

0000000000000378 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 378:	48b9                	li	a7,14
 ecall
 37a:	00000073          	ecall
 ret
 37e:	8082                	ret

0000000000000380 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 380:	1101                	addi	sp,sp,-32
 382:	ec06                	sd	ra,24(sp)
 384:	e822                	sd	s0,16(sp)
 386:	1000                	addi	s0,sp,32
 388:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 38c:	4605                	li	a2,1
 38e:	fef40593          	addi	a1,s0,-17
 392:	f6fff0ef          	jal	300 <write>
}
 396:	60e2                	ld	ra,24(sp)
 398:	6442                	ld	s0,16(sp)
 39a:	6105                	addi	sp,sp,32
 39c:	8082                	ret

000000000000039e <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 39e:	715d                	addi	sp,sp,-80
 3a0:	e486                	sd	ra,72(sp)
 3a2:	e0a2                	sd	s0,64(sp)
 3a4:	f84a                	sd	s2,48(sp)
 3a6:	f44e                	sd	s3,40(sp)
 3a8:	0880                	addi	s0,sp,80
 3aa:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 3ac:	00d036b3          	snez	a3,a3
 3b0:	03f5d793          	srli	a5,a1,0x3f
 3b4:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 3b6:	0005871b          	sext.w	a4,a1
  neg = 0;
 3ba:	4301                	li	t1,0
  if(sgn && xx < 0){
 3bc:	c681                	beqz	a3,3c4 <printint+0x26>
    x = -xx;
 3be:	40b0073b          	negw	a4,a1
    neg = 1;
 3c2:	4305                	li	t1,1
  }

  i = 0;
 3c4:	fb840993          	addi	s3,s0,-72
  neg = 0;
 3c8:	85ce                	mv	a1,s3
  i = 0;
 3ca:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 3cc:	00000817          	auipc	a6,0x0
 3d0:	72c80813          	addi	a6,a6,1836 # af8 <digits>
 3d4:	88b6                	mv	a7,a3
 3d6:	0016851b          	addiw	a0,a3,1
 3da:	86aa                	mv	a3,a0
 3dc:	02c777bb          	remuw	a5,a4,a2
 3e0:	1782                	slli	a5,a5,0x20
 3e2:	9381                	srli	a5,a5,0x20
 3e4:	97c2                	add	a5,a5,a6
 3e6:	0007c783          	lbu	a5,0(a5)
 3ea:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 3ee:	87ba                	mv	a5,a4
 3f0:	02c7573b          	divuw	a4,a4,a2
 3f4:	0585                	addi	a1,a1,1
 3f6:	fcc7ffe3          	bgeu	a5,a2,3d4 <printint+0x36>
  if(neg)
 3fa:	00030b63          	beqz	t1,410 <printint+0x72>
    buf[i++] = '-';
 3fe:	fd040793          	addi	a5,s0,-48
 402:	953e                	add	a0,a0,a5
 404:	02d00793          	li	a5,45
 408:	fef50423          	sb	a5,-24(a0)
 40c:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 410:	02d05563          	blez	a3,43a <printint+0x9c>
 414:	fc26                	sd	s1,56(sp)
 416:	36fd                	addiw	a3,a3,-1
 418:	00d984b3          	add	s1,s3,a3
 41c:	19fd                	addi	s3,s3,-1
 41e:	99b6                	add	s3,s3,a3
 420:	1682                	slli	a3,a3,0x20
 422:	9281                	srli	a3,a3,0x20
 424:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 428:	0004c583          	lbu	a1,0(s1)
 42c:	854a                	mv	a0,s2
 42e:	f53ff0ef          	jal	380 <putc>
  while(--i >= 0)
 432:	14fd                	addi	s1,s1,-1
 434:	ff349ae3          	bne	s1,s3,428 <printint+0x8a>
 438:	74e2                	ld	s1,56(sp)
}
 43a:	60a6                	ld	ra,72(sp)
 43c:	6406                	ld	s0,64(sp)
 43e:	7942                	ld	s2,48(sp)
 440:	79a2                	ld	s3,40(sp)
 442:	6161                	addi	sp,sp,80
 444:	8082                	ret

0000000000000446 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 446:	711d                	addi	sp,sp,-96
 448:	ec86                	sd	ra,88(sp)
 44a:	e8a2                	sd	s0,80(sp)
 44c:	e4a6                	sd	s1,72(sp)
 44e:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 450:	0005c483          	lbu	s1,0(a1)
 454:	28048263          	beqz	s1,6d8 <vprintf+0x292>
 458:	e0ca                	sd	s2,64(sp)
 45a:	fc4e                	sd	s3,56(sp)
 45c:	f852                	sd	s4,48(sp)
 45e:	f456                	sd	s5,40(sp)
 460:	f05a                	sd	s6,32(sp)
 462:	ec5e                	sd	s7,24(sp)
 464:	e862                	sd	s8,16(sp)
 466:	8b2a                	mv	s6,a0
 468:	8a2e                	mv	s4,a1
 46a:	8bb2                	mv	s7,a2
  state = 0;
 46c:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 46e:	4901                	li	s2,0
 470:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 472:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 476:	06400c13          	li	s8,100
 47a:	a00d                	j	49c <vprintf+0x56>
        putc(fd, c0);
 47c:	85a6                	mv	a1,s1
 47e:	855a                	mv	a0,s6
 480:	f01ff0ef          	jal	380 <putc>
 484:	a019                	j	48a <vprintf+0x44>
    } else if(state == '%'){
 486:	03598363          	beq	s3,s5,4ac <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 48a:	0019079b          	addiw	a5,s2,1
 48e:	893e                	mv	s2,a5
 490:	873e                	mv	a4,a5
 492:	97d2                	add	a5,a5,s4
 494:	0007c483          	lbu	s1,0(a5)
 498:	22048963          	beqz	s1,6ca <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 49c:	0004879b          	sext.w	a5,s1
    if(state == 0){
 4a0:	fe0993e3          	bnez	s3,486 <vprintf+0x40>
      if(c0 == '%'){
 4a4:	fd579ce3          	bne	a5,s5,47c <vprintf+0x36>
        state = '%';
 4a8:	89be                	mv	s3,a5
 4aa:	b7c5                	j	48a <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 4ac:	00ea06b3          	add	a3,s4,a4
 4b0:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 4b4:	22060763          	beqz	a2,6e2 <vprintf+0x29c>
      if(c0 == 'd'){
 4b8:	0b878363          	beq	a5,s8,55e <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 4bc:	f9478693          	addi	a3,a5,-108
 4c0:	0016b693          	seqz	a3,a3
 4c4:	f9c60593          	addi	a1,a2,-100
 4c8:	0015b593          	seqz	a1,a1
 4cc:	8df5                	and	a1,a1,a3
 4ce:	e5c5                	bnez	a1,576 <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 4d0:	9752                	add	a4,a4,s4
 4d2:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 4d6:	f9460713          	addi	a4,a2,-108
 4da:	00173713          	seqz	a4,a4
 4de:	8f75                	and	a4,a4,a3
 4e0:	f9c50593          	addi	a1,a0,-100
 4e4:	0015b593          	seqz	a1,a1
 4e8:	8df9                	and	a1,a1,a4
 4ea:	e1dd                	bnez	a1,590 <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 4ec:	07500593          	li	a1,117
 4f0:	0ab78d63          	beq	a5,a1,5aa <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 4f4:	f8b60593          	addi	a1,a2,-117
 4f8:	0015b593          	seqz	a1,a1
 4fc:	8df5                	and	a1,a1,a3
 4fe:	e1f1                	bnez	a1,5c2 <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 500:	f8b50593          	addi	a1,a0,-117
 504:	0015b593          	seqz	a1,a1
 508:	8df9                	and	a1,a1,a4
 50a:	e9e9                	bnez	a1,5dc <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 50c:	07800593          	li	a1,120
 510:	0eb78363          	beq	a5,a1,5f6 <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 514:	f8860613          	addi	a2,a2,-120
 518:	00163613          	seqz	a2,a2
 51c:	8ef1                	and	a3,a3,a2
 51e:	0e069863          	bnez	a3,60e <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 522:	f8850513          	addi	a0,a0,-120
 526:	00153513          	seqz	a0,a0
 52a:	8f69                	and	a4,a4,a0
 52c:	0e071e63          	bnez	a4,628 <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 530:	07000713          	li	a4,112
 534:	10e78663          	beq	a5,a4,640 <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 538:	07300713          	li	a4,115
 53c:	14e78663          	beq	a5,a4,688 <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 540:	02500713          	li	a4,37
 544:	16e78e63          	beq	a5,a4,6c0 <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 548:	02500593          	li	a1,37
 54c:	855a                	mv	a0,s6
 54e:	e33ff0ef          	jal	380 <putc>
        putc(fd, c0);
 552:	85a6                	mv	a1,s1
 554:	855a                	mv	a0,s6
 556:	e2bff0ef          	jal	380 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 55a:	4981                	li	s3,0
 55c:	b73d                	j	48a <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 55e:	008b8493          	addi	s1,s7,8
 562:	4685                	li	a3,1
 564:	4629                	li	a2,10
 566:	000ba583          	lw	a1,0(s7)
 56a:	855a                	mv	a0,s6
 56c:	e33ff0ef          	jal	39e <printint>
 570:	8ba6                	mv	s7,s1
      state = 0;
 572:	4981                	li	s3,0
 574:	bf19                	j	48a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 576:	008b8493          	addi	s1,s7,8
 57a:	4685                	li	a3,1
 57c:	4629                	li	a2,10
 57e:	000bb583          	ld	a1,0(s7)
 582:	855a                	mv	a0,s6
 584:	e1bff0ef          	jal	39e <printint>
        i += 1;
 588:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 58a:	8ba6                	mv	s7,s1
      state = 0;
 58c:	4981                	li	s3,0
 58e:	bdf5                	j	48a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 590:	008b8493          	addi	s1,s7,8
 594:	4685                	li	a3,1
 596:	4629                	li	a2,10
 598:	000bb583          	ld	a1,0(s7)
 59c:	855a                	mv	a0,s6
 59e:	e01ff0ef          	jal	39e <printint>
        i += 2;
 5a2:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 5a4:	8ba6                	mv	s7,s1
      state = 0;
 5a6:	4981                	li	s3,0
        i += 2;
 5a8:	b5cd                	j	48a <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 5aa:	008b8493          	addi	s1,s7,8
 5ae:	4681                	li	a3,0
 5b0:	4629                	li	a2,10
 5b2:	000ba583          	lw	a1,0(s7)
 5b6:	855a                	mv	a0,s6
 5b8:	de7ff0ef          	jal	39e <printint>
 5bc:	8ba6                	mv	s7,s1
      state = 0;
 5be:	4981                	li	s3,0
 5c0:	b5e9                	j	48a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 5c2:	008b8493          	addi	s1,s7,8
 5c6:	4681                	li	a3,0
 5c8:	4629                	li	a2,10
 5ca:	000bb583          	ld	a1,0(s7)
 5ce:	855a                	mv	a0,s6
 5d0:	dcfff0ef          	jal	39e <printint>
        i += 1;
 5d4:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 5d6:	8ba6                	mv	s7,s1
      state = 0;
 5d8:	4981                	li	s3,0
 5da:	bd45                	j	48a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 5dc:	008b8493          	addi	s1,s7,8
 5e0:	4681                	li	a3,0
 5e2:	4629                	li	a2,10
 5e4:	000bb583          	ld	a1,0(s7)
 5e8:	855a                	mv	a0,s6
 5ea:	db5ff0ef          	jal	39e <printint>
        i += 2;
 5ee:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 5f0:	8ba6                	mv	s7,s1
      state = 0;
 5f2:	4981                	li	s3,0
        i += 2;
 5f4:	bd59                	j	48a <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 5f6:	008b8493          	addi	s1,s7,8
 5fa:	4681                	li	a3,0
 5fc:	4641                	li	a2,16
 5fe:	000ba583          	lw	a1,0(s7)
 602:	855a                	mv	a0,s6
 604:	d9bff0ef          	jal	39e <printint>
 608:	8ba6                	mv	s7,s1
      state = 0;
 60a:	4981                	li	s3,0
 60c:	bdbd                	j	48a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 60e:	008b8493          	addi	s1,s7,8
 612:	4681                	li	a3,0
 614:	4641                	li	a2,16
 616:	000bb583          	ld	a1,0(s7)
 61a:	855a                	mv	a0,s6
 61c:	d83ff0ef          	jal	39e <printint>
        i += 1;
 620:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 622:	8ba6                	mv	s7,s1
      state = 0;
 624:	4981                	li	s3,0
 626:	b595                	j	48a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 628:	008b8493          	addi	s1,s7,8
 62c:	4641                	li	a2,16
 62e:	000bb583          	ld	a1,0(s7)
 632:	855a                	mv	a0,s6
 634:	d6bff0ef          	jal	39e <printint>
        i += 2;
 638:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 63a:	8ba6                	mv	s7,s1
      state = 0;
 63c:	4981                	li	s3,0
        i += 2;
 63e:	b5b1                	j	48a <vprintf+0x44>
 640:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 642:	008b8793          	addi	a5,s7,8
 646:	8cbe                	mv	s9,a5
 648:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 64c:	03000593          	li	a1,48
 650:	855a                	mv	a0,s6
 652:	d2fff0ef          	jal	380 <putc>
  putc(fd, 'x');
 656:	07800593          	li	a1,120
 65a:	855a                	mv	a0,s6
 65c:	d25ff0ef          	jal	380 <putc>
 660:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 662:	00000b97          	auipc	s7,0x0
 666:	496b8b93          	addi	s7,s7,1174 # af8 <digits>
 66a:	03c9d793          	srli	a5,s3,0x3c
 66e:	97de                	add	a5,a5,s7
 670:	0007c583          	lbu	a1,0(a5)
 674:	855a                	mv	a0,s6
 676:	d0bff0ef          	jal	380 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 67a:	0992                	slli	s3,s3,0x4
 67c:	34fd                	addiw	s1,s1,-1
 67e:	f4f5                	bnez	s1,66a <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 680:	8be6                	mv	s7,s9
      state = 0;
 682:	4981                	li	s3,0
 684:	6ca2                	ld	s9,8(sp)
 686:	b511                	j	48a <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 688:	008b8993          	addi	s3,s7,8
 68c:	000bb483          	ld	s1,0(s7)
 690:	cc91                	beqz	s1,6ac <vprintf+0x266>
        for(; *s; s++)
 692:	0004c583          	lbu	a1,0(s1)
 696:	c195                	beqz	a1,6ba <vprintf+0x274>
          putc(fd, *s);
 698:	855a                	mv	a0,s6
 69a:	ce7ff0ef          	jal	380 <putc>
        for(; *s; s++)
 69e:	0485                	addi	s1,s1,1
 6a0:	0004c583          	lbu	a1,0(s1)
 6a4:	f9f5                	bnez	a1,698 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 6a6:	8bce                	mv	s7,s3
      state = 0;
 6a8:	4981                	li	s3,0
 6aa:	b3c5                	j	48a <vprintf+0x44>
          s = "(null)";
 6ac:	00000497          	auipc	s1,0x0
 6b0:	41c48493          	addi	s1,s1,1052 # ac8 <thread_switch+0x86>
        for(; *s; s++)
 6b4:	02800593          	li	a1,40
 6b8:	b7c5                	j	698 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 6ba:	8bce                	mv	s7,s3
      state = 0;
 6bc:	4981                	li	s3,0
 6be:	b3f1                	j	48a <vprintf+0x44>
        putc(fd, '%');
 6c0:	85be                	mv	a1,a5
 6c2:	855a                	mv	a0,s6
 6c4:	cbdff0ef          	jal	380 <putc>
 6c8:	bd49                	j	55a <vprintf+0x114>
 6ca:	6906                	ld	s2,64(sp)
 6cc:	79e2                	ld	s3,56(sp)
 6ce:	7a42                	ld	s4,48(sp)
 6d0:	7aa2                	ld	s5,40(sp)
 6d2:	7b02                	ld	s6,32(sp)
 6d4:	6be2                	ld	s7,24(sp)
 6d6:	6c42                	ld	s8,16(sp)
    }
  }
}
 6d8:	60e6                	ld	ra,88(sp)
 6da:	6446                	ld	s0,80(sp)
 6dc:	64a6                	ld	s1,72(sp)
 6de:	6125                	addi	sp,sp,96
 6e0:	8082                	ret
      if(c0 == 'd'){
 6e2:	06400713          	li	a4,100
 6e6:	e6e78ce3          	beq	a5,a4,55e <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 6ea:	f9478693          	addi	a3,a5,-108
 6ee:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 6f2:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 6f4:	4701                	li	a4,0
 6f6:	bbdd                	j	4ec <vprintf+0xa6>

00000000000006f8 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 6f8:	715d                	addi	sp,sp,-80
 6fa:	ec06                	sd	ra,24(sp)
 6fc:	e822                	sd	s0,16(sp)
 6fe:	1000                	addi	s0,sp,32
 700:	e010                	sd	a2,0(s0)
 702:	e414                	sd	a3,8(s0)
 704:	e818                	sd	a4,16(s0)
 706:	ec1c                	sd	a5,24(s0)
 708:	03043023          	sd	a6,32(s0)
 70c:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 710:	8622                	mv	a2,s0
 712:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 716:	d31ff0ef          	jal	446 <vprintf>
}
 71a:	60e2                	ld	ra,24(sp)
 71c:	6442                	ld	s0,16(sp)
 71e:	6161                	addi	sp,sp,80
 720:	8082                	ret

0000000000000722 <printf>:

void
printf(const char *fmt, ...)
{
 722:	711d                	addi	sp,sp,-96
 724:	ec06                	sd	ra,24(sp)
 726:	e822                	sd	s0,16(sp)
 728:	1000                	addi	s0,sp,32
 72a:	e40c                	sd	a1,8(s0)
 72c:	e810                	sd	a2,16(s0)
 72e:	ec14                	sd	a3,24(s0)
 730:	f018                	sd	a4,32(s0)
 732:	f41c                	sd	a5,40(s0)
 734:	03043823          	sd	a6,48(s0)
 738:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 73c:	00840613          	addi	a2,s0,8
 740:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 744:	85aa                	mv	a1,a0
 746:	4505                	li	a0,1
 748:	cffff0ef          	jal	446 <vprintf>
}
 74c:	60e2                	ld	ra,24(sp)
 74e:	6442                	ld	s0,16(sp)
 750:	6125                	addi	sp,sp,96
 752:	8082                	ret

0000000000000754 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 754:	1141                	addi	sp,sp,-16
 756:	e406                	sd	ra,8(sp)
 758:	e022                	sd	s0,0(sp)
 75a:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 75c:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 760:	00001797          	auipc	a5,0x1
 764:	8a07b783          	ld	a5,-1888(a5) # 1000 <freep>
 768:	a095                	j	7cc <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 76a:	ff852583          	lw	a1,-8(a0)
 76e:	6390                	ld	a2,0(a5)
 770:	02059813          	slli	a6,a1,0x20
 774:	01c85693          	srli	a3,a6,0x1c
 778:	96ba                	add	a3,a3,a4
 77a:	02d60563          	beq	a2,a3,7a4 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 77e:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 782:	4790                	lw	a2,8(a5)
 784:	02061593          	slli	a1,a2,0x20
 788:	01c5d693          	srli	a3,a1,0x1c
 78c:	96be                	add	a3,a3,a5
 78e:	02d70263          	beq	a4,a3,7b2 <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 792:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 794:	00001717          	auipc	a4,0x1
 798:	86f73623          	sd	a5,-1940(a4) # 1000 <freep>
}
 79c:	60a2                	ld	ra,8(sp)
 79e:	6402                	ld	s0,0(sp)
 7a0:	0141                	addi	sp,sp,16
 7a2:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 7a4:	4614                	lw	a3,8(a2)
 7a6:	9ead                	addw	a3,a3,a1
 7a8:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 7ac:	6394                	ld	a3,0(a5)
 7ae:	6290                	ld	a2,0(a3)
 7b0:	b7f9                	j	77e <free+0x2a>
    p->s.size += bp->s.size;
 7b2:	ff852703          	lw	a4,-8(a0)
 7b6:	9f31                	addw	a4,a4,a2
 7b8:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 7ba:	ff053703          	ld	a4,-16(a0)
 7be:	bfd1                	j	792 <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 7c0:	6394                	ld	a3,0(a5)
 7c2:	00d7e463          	bltu	a5,a3,7ca <free+0x76>
 7c6:	fad762e3          	bltu	a4,a3,76a <free+0x16>
 7ca:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 7cc:	fee7fae3          	bgeu	a5,a4,7c0 <free+0x6c>
 7d0:	6394                	ld	a3,0(a5)
 7d2:	f8d76ce3          	bltu	a4,a3,76a <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 7d6:	f8d7fae3          	bgeu	a5,a3,76a <free+0x16>
 7da:	87b6                	mv	a5,a3
 7dc:	bfc5                	j	7cc <free+0x78>

00000000000007de <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 7de:	7139                	addi	sp,sp,-64
 7e0:	fc06                	sd	ra,56(sp)
 7e2:	f822                	sd	s0,48(sp)
 7e4:	f04a                	sd	s2,32(sp)
 7e6:	ec4e                	sd	s3,24(sp)
 7e8:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 7ea:	02051993          	slli	s3,a0,0x20
 7ee:	0209d993          	srli	s3,s3,0x20
 7f2:	09bd                	addi	s3,s3,15
 7f4:	0049d993          	srli	s3,s3,0x4
 7f8:	2985                	addiw	s3,s3,1
 7fa:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 7fc:	00001517          	auipc	a0,0x1
 800:	80453503          	ld	a0,-2044(a0) # 1000 <freep>
 804:	c905                	beqz	a0,834 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 806:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 808:	4798                	lw	a4,8(a5)
 80a:	09377663          	bgeu	a4,s3,896 <malloc+0xb8>
 80e:	f426                	sd	s1,40(sp)
 810:	e852                	sd	s4,16(sp)
 812:	e456                	sd	s5,8(sp)
 814:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 816:	8a4e                	mv	s4,s3
 818:	6705                	lui	a4,0x1
 81a:	00e9f363          	bgeu	s3,a4,820 <malloc+0x42>
 81e:	6a05                	lui	s4,0x1
 820:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 824:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 828:	00000497          	auipc	s1,0x0
 82c:	7d848493          	addi	s1,s1,2008 # 1000 <freep>
  if(p == (char*)-1)
 830:	5afd                	li	s5,-1
 832:	a83d                	j	870 <malloc+0x92>
 834:	f426                	sd	s1,40(sp)
 836:	e852                	sd	s4,16(sp)
 838:	e456                	sd	s5,8(sp)
 83a:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 83c:	00000797          	auipc	a5,0x0
 840:	7d478793          	addi	a5,a5,2004 # 1010 <base>
 844:	00000717          	auipc	a4,0x0
 848:	7af73e23          	sd	a5,1980(a4) # 1000 <freep>
 84c:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 84e:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 852:	b7d1                	j	816 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 854:	6398                	ld	a4,0(a5)
 856:	e118                	sd	a4,0(a0)
 858:	a899                	j	8ae <malloc+0xd0>
  hp->s.size = nu;
 85a:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 85e:	0541                	addi	a0,a0,16
 860:	ef5ff0ef          	jal	754 <free>
  return freep;
 864:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 866:	c125                	beqz	a0,8c6 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 868:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 86a:	4798                	lw	a4,8(a5)
 86c:	03277163          	bgeu	a4,s2,88e <malloc+0xb0>
    if(p == freep)
 870:	6098                	ld	a4,0(s1)
 872:	853e                	mv	a0,a5
 874:	fef71ae3          	bne	a4,a5,868 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 878:	8552                	mv	a0,s4
 87a:	aefff0ef          	jal	368 <sbrk>
  if(p == (char*)-1)
 87e:	fd551ee3          	bne	a0,s5,85a <malloc+0x7c>
        return 0;
 882:	4501                	li	a0,0
 884:	74a2                	ld	s1,40(sp)
 886:	6a42                	ld	s4,16(sp)
 888:	6aa2                	ld	s5,8(sp)
 88a:	6b02                	ld	s6,0(sp)
 88c:	a03d                	j	8ba <malloc+0xdc>
 88e:	74a2                	ld	s1,40(sp)
 890:	6a42                	ld	s4,16(sp)
 892:	6aa2                	ld	s5,8(sp)
 894:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 896:	fae90fe3          	beq	s2,a4,854 <malloc+0x76>
        p->s.size -= nunits;
 89a:	4137073b          	subw	a4,a4,s3
 89e:	c798                	sw	a4,8(a5)
        p += p->s.size;
 8a0:	02071693          	slli	a3,a4,0x20
 8a4:	01c6d713          	srli	a4,a3,0x1c
 8a8:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 8aa:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 8ae:	00000717          	auipc	a4,0x0
 8b2:	74a73923          	sd	a0,1874(a4) # 1000 <freep>
      return (void*)(p + 1);
 8b6:	01078513          	addi	a0,a5,16
  }
}
 8ba:	70e2                	ld	ra,56(sp)
 8bc:	7442                	ld	s0,48(sp)
 8be:	7902                	ld	s2,32(sp)
 8c0:	69e2                	ld	s3,24(sp)
 8c2:	6121                	addi	sp,sp,64
 8c4:	8082                	ret
 8c6:	74a2                	ld	s1,40(sp)
 8c8:	6a42                	ld	s4,16(sp)
 8ca:	6aa2                	ld	s5,8(sp)
 8cc:	6b02                	ld	s6,0(sp)
 8ce:	b7f5                	j	8ba <malloc+0xdc>

00000000000008d0 <thread_init>:
struct thread *current_thread;
extern void thread_switch(uint64, uint64);
              
void 
thread_init(void)
{
 8d0:	1141                	addi	sp,sp,-16
 8d2:	e406                	sd	ra,8(sp)
 8d4:	e022                	sd	s0,0(sp)
 8d6:	0800                	addi	s0,sp,16
  // main() is thread 0, which will make the first invocation to
  // thread_schedule(). It needs a stack so that the first thread_switch() can
  // save thread 0's state.
  current_thread = &all_thread[0];
 8d8:	00000797          	auipc	a5,0x0
 8dc:	74878793          	addi	a5,a5,1864 # 1020 <all_thread>
 8e0:	00000717          	auipc	a4,0x0
 8e4:	72f73423          	sd	a5,1832(a4) # 1008 <current_thread>
  current_thread->state = RUNNING;
 8e8:	00002717          	auipc	a4,0x2
 8ec:	73870713          	addi	a4,a4,1848 # 3020 <all_thread+0x2000>
 8f0:	4785                	li	a5,1
 8f2:	c31c                	sw	a5,0(a4)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 8f4:	00002797          	auipc	a5,0x2
 8f8:	6bc78793          	addi	a5,a5,1724 # 2fb0 <all_thread+0x1f90>
  return (struct context *)(top & ~(uint64)0xf);
 8fc:	9bc1                	andi	a5,a5,-16
  // Thread 0 runs on the process's own stack, but the first thread_switch()
  // still needs a writable place to save its context.
  current_thread->context = thread_context_slot(current_thread);
 8fe:	e71c                	sd	a5,8(a4)
}
 900:	60a2                	ld	ra,8(sp)
 902:	6402                	ld	s0,0(sp)
 904:	0141                	addi	sp,sp,16
 906:	8082                	ret

0000000000000908 <thread_schedule>:

void 
thread_schedule(void)
{
 908:	1141                	addi	sp,sp,-16
 90a:	e406                	sd	ra,8(sp)
 90c:	e022                	sd	s0,0(sp)
 90e:	0800                	addi	s0,sp,16
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
 910:	00000597          	auipc	a1,0x0
 914:	6f85b583          	ld	a1,1784(a1) # 1008 <current_thread>
 918:	6789                	lui	a5,0x2
 91a:	07c1                	addi	a5,a5,16 # 2010 <all_thread+0xff0>
 91c:	97ae                	add	a5,a5,a1
 91e:	4711                	li	a4,4
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
 920:	00008897          	auipc	a7,0x8
 924:	74088893          	addi	a7,a7,1856 # 9060 <all_thread+0x8040>
      t = all_thread;
    if(t->state == RUNNABLE) {
 928:	6809                	lui	a6,0x2
 92a:	4509                	li	a0,2
      next_thread = t;
      break;
    }
    t = t + 1;
 92c:	01080613          	addi	a2,a6,16 # 2010 <all_thread+0xff0>
 930:	a809                	j	942 <thread_schedule+0x3a>
    if(t->state == RUNNABLE) {
 932:	010786b3          	add	a3,a5,a6
 936:	4294                	lw	a3,0(a3)
 938:	02a68563          	beq	a3,a0,962 <thread_schedule+0x5a>
    t = t + 1;
 93c:	97b2                	add	a5,a5,a2
  for(int i = 0; i < MAX_THREAD; i++){
 93e:	377d                	addiw	a4,a4,-1
 940:	cb01                	beqz	a4,950 <thread_schedule+0x48>
    if(t >= all_thread + MAX_THREAD)
 942:	ff17e8e3          	bltu	a5,a7,932 <thread_schedule+0x2a>
      t = all_thread;
 946:	00000797          	auipc	a5,0x0
 94a:	6da78793          	addi	a5,a5,1754 # 1020 <all_thread>
 94e:	b7d5                	j	932 <thread_schedule+0x2a>
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
 950:	00000517          	auipc	a0,0x0
 954:	18050513          	addi	a0,a0,384 # ad0 <thread_switch+0x8e>
 958:	dcbff0ef          	jal	722 <printf>
    exit(-1);
 95c:	557d                	li	a0,-1
 95e:	983ff0ef          	jal	2e0 <exit>
  }

  if (current_thread != next_thread) {         /* switch threads?  */
 962:	02f58163          	beq	a1,a5,984 <thread_schedule+0x7c>
    next_thread->state = RUNNING;
 966:	6689                	lui	a3,0x2
 968:	00d78733          	add	a4,a5,a3
 96c:	4605                	li	a2,1
 96e:	c310                	sw	a2,0(a4)
    t = current_thread;
    current_thread = next_thread;
 970:	00000617          	auipc	a2,0x0
 974:	68f63c23          	sd	a5,1688(a2) # 1008 <current_thread>
    thread_switch((uint64)t->context, (uint64)next_thread->context);
 978:	00d587b3          	add	a5,a1,a3
 97c:	670c                	ld	a1,8(a4)
 97e:	6788                	ld	a0,8(a5)
 980:	0c2000ef          	jal	a42 <thread_switch>
  } else
    next_thread = 0;
}
 984:	60a2                	ld	ra,8(sp)
 986:	6402                	ld	s0,0(sp)
 988:	0141                	addi	sp,sp,16
 98a:	8082                	ret

000000000000098c <thread_create>:

void 
thread_create(void (*func)())
{
 98c:	1101                	addi	sp,sp,-32
 98e:	ec06                	sd	ra,24(sp)
 990:	e822                	sd	s0,16(sp)
 992:	e426                	sd	s1,8(sp)
 994:	e04a                	sd	s2,0(sp)
 996:	1000                	addi	s0,sp,32
 998:	892a                	mv	s2,a0
  struct thread *t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 99a:	00002797          	auipc	a5,0x2
 99e:	69678793          	addi	a5,a5,1686 # 3030 <all_thread+0x2010>
 9a2:	0000a597          	auipc	a1,0xa
 9a6:	6ce58593          	addi	a1,a1,1742 # b070 <all_thread+0xa050>
 9aa:	6609                	lui	a2,0x2
 9ac:	0641                	addi	a2,a2,16 # 2010 <all_thread+0xff0>
    if (t->state == FREE) break;
 9ae:	873e                	mv	a4,a5
 9b0:	ff07a683          	lw	a3,-16(a5)
 9b4:	ce9d                	beqz	a3,9f2 <thread_create+0x66>
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 9b6:	97b2                	add	a5,a5,a2
 9b8:	feb79be3          	bne	a5,a1,9ae <thread_create+0x22>
  }
  t->state = RUNNABLE;
 9bc:	6489                	lui	s1,0x2
 9be:	94ba                	add	s1,s1,a4
 9c0:	4789                	li	a5,2
 9c2:	c09c                	sw	a5,0(s1)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 9c4:	6789                	lui	a5,0x2
 9c6:	f9078793          	addi	a5,a5,-112 # 1f90 <all_thread+0xf70>
 9ca:	973e                	add	a4,a4,a5
  return (struct context *)(top & ~(uint64)0xf);
 9cc:	ff077513          	andi	a0,a4,-16
  // A never-run thread has no saved state, so construct one: thread_switch()
  // restores ra and sp, and `ret` then starts func on this thread's own stack.
  t->context = thread_context_slot(t);
 9d0:	e488                	sd	a0,8(s1)
  memset(t->context, 0, sizeof(struct context));
 9d2:	07000613          	li	a2,112
 9d6:	4581                	li	a1,0
 9d8:	f0aff0ef          	jal	e2 <memset>
  t->context->ra = (uint64)func;
 9dc:	649c                	ld	a5,8(s1)
 9de:	0127b023          	sd	s2,0(a5)
  t->context->sp = (uint64)t->context;   // 16-byte aligned, grows down
 9e2:	649c                	ld	a5,8(s1)
 9e4:	e79c                	sd	a5,8(a5)
}
 9e6:	60e2                	ld	ra,24(sp)
 9e8:	6442                	ld	s0,16(sp)
 9ea:	64a2                	ld	s1,8(sp)
 9ec:	6902                	ld	s2,0(sp)
 9ee:	6105                	addi	sp,sp,32
 9f0:	8082                	ret
 9f2:	7779                	lui	a4,0xffffe
 9f4:	1741                	addi	a4,a4,-16 # ffffffffffffdff0 <all_thread+0xffffffffffffcfd0>
 9f6:	973e                	add	a4,a4,a5
 9f8:	b7d1                	j	9bc <thread_create+0x30>

00000000000009fa <thread_yield>:

void 
thread_yield(void)
{
 9fa:	1141                	addi	sp,sp,-16
 9fc:	e406                	sd	ra,8(sp)
 9fe:	e022                	sd	s0,0(sp)
 a00:	0800                	addi	s0,sp,16
  current_thread->state = RUNNABLE;
 a02:	00000797          	auipc	a5,0x0
 a06:	6067b783          	ld	a5,1542(a5) # 1008 <current_thread>
 a0a:	6709                	lui	a4,0x2
 a0c:	97ba                	add	a5,a5,a4
 a0e:	4709                	li	a4,2
 a10:	c398                	sw	a4,0(a5)
  thread_schedule();
 a12:	ef7ff0ef          	jal	908 <thread_schedule>
}
 a16:	60a2                	ld	ra,8(sp)
 a18:	6402                	ld	s0,0(sp)
 a1a:	0141                	addi	sp,sp,16
 a1c:	8082                	ret

0000000000000a1e <thread_exit>:

void thread_exit(void) {
 a1e:	1141                	addi	sp,sp,-16
 a20:	e406                	sd	ra,8(sp)
 a22:	e022                	sd	s0,0(sp)
 a24:	0800                	addi	s0,sp,16
  current_thread->state = FREE;
 a26:	00000797          	auipc	a5,0x0
 a2a:	5e27b783          	ld	a5,1506(a5) # 1008 <current_thread>
 a2e:	6709                	lui	a4,0x2
 a30:	97ba                	add	a5,a5,a4
 a32:	0007a023          	sw	zero,0(a5)
  thread_schedule();
 a36:	ed3ff0ef          	jal	908 <thread_schedule>
}
 a3a:	60a2                	ld	ra,8(sp)
 a3c:	6402                	ld	s0,0(sp)
 a3e:	0141                	addi	sp,sp,16
 a40:	8082                	ret

0000000000000a42 <thread_switch>:
 a42:	00153023          	sd	ra,0(a0)
 a46:	00253423          	sd	sp,8(a0)
 a4a:	e900                	sd	s0,16(a0)
 a4c:	ed04                	sd	s1,24(a0)
 a4e:	03253023          	sd	s2,32(a0)
 a52:	03353423          	sd	s3,40(a0)
 a56:	03453823          	sd	s4,48(a0)
 a5a:	03553c23          	sd	s5,56(a0)
 a5e:	05653023          	sd	s6,64(a0)
 a62:	05753423          	sd	s7,72(a0)
 a66:	05853823          	sd	s8,80(a0)
 a6a:	05953c23          	sd	s9,88(a0)
 a6e:	07a53023          	sd	s10,96(a0)
 a72:	07b53423          	sd	s11,104(a0)
 a76:	0005b083          	ld	ra,0(a1)
 a7a:	0085b103          	ld	sp,8(a1)
 a7e:	6980                	ld	s0,16(a1)
 a80:	6d84                	ld	s1,24(a1)
 a82:	0205b903          	ld	s2,32(a1)
 a86:	0285b983          	ld	s3,40(a1)
 a8a:	0305ba03          	ld	s4,48(a1)
 a8e:	0385ba83          	ld	s5,56(a1)
 a92:	0405bb03          	ld	s6,64(a1)
 a96:	0485bb83          	ld	s7,72(a1)
 a9a:	0505bc03          	ld	s8,80(a1)
 a9e:	0585bc83          	ld	s9,88(a1)
 aa2:	0605bd03          	ld	s10,96(a1)
 aa6:	0685bd83          	ld	s11,104(a1)
 aaa:	8082                	ret
