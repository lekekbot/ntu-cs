
user/_starvetest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "user/user.h"

/* Supplied observation workload. Run with CPUS=1; exit QEMU with Ctrl-a x. */
int
main(void)
{
   0:	711d                	addi	sp,sp,-96
   2:	ec86                	sd	ra,88(sp)
   4:	e8a2                	sd	s0,80(sp)
   6:	1080                	addi	s0,sp,96
  int gate[2], ready[2], pid[2];
  char token;

  if(pipe(gate) < 0 || pipe(ready) < 0){
   8:	fb840513          	addi	a0,s0,-72
   c:	48a000ef          	jal	496 <pipe>
  10:	0e054063          	bltz	a0,f0 <main+0xf0>
  14:	fb040513          	addi	a0,s0,-80
  18:	47e000ef          	jal	496 <pipe>
  1c:	0c054a63          	bltz	a0,f0 <main+0xf0>
  20:	e0ca                	sd	s2,64(sp)
  22:	fc4e                	sd	s3,56(sp)
    printf("starvetest: pipe failed\n");
    exit(1);
  }

  for(int i = 0; i < 2; i++){
    pid[i] = fork();
  24:	45a000ef          	jal	47e <fork>
  28:	892a                	mv	s2,a0
    if(pid[i] < 0){
  2a:	0e054363          	bltz	a0,110 <main+0x110>
        wait(0);
      printf("starvetest: fork failed\n");
      exit(1);
    }

    if(pid[i] == 0){
  2e:	12050663          	beqz	a0,15a <main+0x15a>
    pid[i] = fork();
  32:	44c000ef          	jal	47e <fork>
  36:	89aa                	mv	s3,a0
    if(pid[i] < 0){
  38:	0c054a63          	bltz	a0,10c <main+0x10c>
    if(pid[i] == 0){
  3c:	10050f63          	beqz	a0,15a <main+0x15a>
  40:	e4a6                	sd	s1,72(sp)
  42:	f852                	sd	s4,48(sp)
  44:	f456                	sd	s5,40(sp)
      for(;;)
        value = value * 1664525 + 1013904223;
    }
  }

  close(gate[0]);
  46:	fb842503          	lw	a0,-72(s0)
  4a:	464000ef          	jal	4ae <close>
  close(ready[1]);
  4e:	fb442503          	lw	a0,-76(s0)
  52:	45c000ef          	jal	4ae <close>
  int ok = ((pid[0] & 1) != (pid[1] & 1));
  56:	0129c4b3          	xor	s1,s3,s2
  5a:	8885                	andi	s1,s1,1
  5c:	4a09                	li	s4,2
  for(int i = 0; i < 2; i++)
    if(read(ready[0], &token, 1) != 1)
  5e:	faf40a93          	addi	s5,s0,-81
  62:	4605                	li	a2,1
  64:	85d6                	mv	a1,s5
  66:	fb042503          	lw	a0,-80(s0)
  6a:	434000ef          	jal	49e <read>
  6e:	fff50793          	addi	a5,a0,-1
  72:	0017b793          	seqz	a5,a5
  76:	8cfd                	and	s1,s1,a5
  for(int i = 0; i < 2; i++)
  78:	3a7d                	addiw	s4,s4,-1
  7a:	fe0a14e3          	bnez	s4,62 <main+0x62>
      ok = 0;
  close(ready[0]);
  7e:	fb042503          	lw	a0,-80(s0)
  82:	42c000ef          	jal	4ae <close>

  if(ok){
  86:	14048f63          	beqz	s1,1e4 <main+0x1e4>
    int even = (pid[0] & 1) ? pid[1] : pid[0];
  8a:	00197793          	andi	a5,s2,1
  8e:	e781                	bnez	a5,96 <main+0x96>
  90:	87ca                	mv	a5,s2
    int odd = (pid[0] & 1) ? pid[0] : pid[1];
  92:	894e                	mv	s2,s3
    int even = (pid[0] & 1) ? pid[1] : pid[0];
  94:	89be                	mv	s3,a5
    printf("starvetest: even pid %d; odd pid %d\n", even, odd);
  96:	864a                	mv	a2,s2
  98:	85ce                	mv	a1,s3
  9a:	00001517          	auipc	a0,0x1
  9e:	c0e50513          	addi	a0,a0,-1010 # ca8 <thread_switch+0xc0>
  a2:	027000ef          	jal	8c8 <printf>
    printf("starvetest: releasing children; Ctrl-p to inspect; Ctrl-a x to stop\n");
  a6:	00001517          	auipc	a0,0x1
  aa:	c2a50513          	addi	a0,a0,-982 # cd0 <thread_switch+0xe8>
  ae:	01b000ef          	jal	8c8 <printf>
    if(write(gate[1], "gg", 2) != 2)
  b2:	4609                	li	a2,2
  b4:	00001597          	auipc	a1,0x1
  b8:	c6458593          	addi	a1,a1,-924 # d18 <thread_switch+0x130>
  bc:	fbc42503          	lw	a0,-68(s0)
  c0:	3e6000ef          	jal	4a6 <write>
  c4:	892a                	mv	s2,a0
  c6:	4989                	li	s3,2
  c8:	ffe50493          	addi	s1,a0,-2
  cc:	0014b493          	seqz	s1,s1
      ok = 0;
  }
  close(gate[1]);
  d0:	fbc42503          	lw	a0,-68(s0)
  d4:	3da000ef          	jal	4ae <close>
  if(!ok)
  d8:	11391a63          	bne	s2,s3,1ec <main+0x1ec>
    printf("starvetest: startup failed; restart in a fresh xv6 session\n");

  /* Normally blocks forever; the host ends this observation by exiting QEMU. */
  wait(0);
  dc:	4501                	li	a0,0
  de:	3b0000ef          	jal	48e <wait>
  wait(0);
  e2:	4501                	li	a0,0
  e4:	3aa000ef          	jal	48e <wait>
  exit(ok ? 0 : 1);
  e8:	0014c513          	xori	a0,s1,1
  ec:	39a000ef          	jal	486 <exit>
  f0:	e4a6                	sd	s1,72(sp)
  f2:	e0ca                	sd	s2,64(sp)
  f4:	fc4e                	sd	s3,56(sp)
  f6:	f852                	sd	s4,48(sp)
  f8:	f456                	sd	s5,40(sp)
    printf("starvetest: pipe failed\n");
  fa:	00001517          	auipc	a0,0x1
  fe:	b6650513          	addi	a0,a0,-1178 # c60 <thread_switch+0x78>
 102:	7c6000ef          	jal	8c8 <printf>
    exit(1);
 106:	4505                	li	a0,1
 108:	37e000ef          	jal	486 <exit>
    if(pid[i] < 0){
 10c:	4905                	li	s2,1
 10e:	a011                	j	112 <main+0x112>
  for(int i = 0; i < 2; i++){
 110:	4901                	li	s2,0
 112:	e4a6                	sd	s1,72(sp)
 114:	f852                	sd	s4,48(sp)
 116:	f456                	sd	s5,40(sp)
      close(gate[1]);
 118:	fbc42503          	lw	a0,-68(s0)
 11c:	392000ef          	jal	4ae <close>
      close(gate[0]);
 120:	fb842503          	lw	a0,-72(s0)
 124:	38a000ef          	jal	4ae <close>
      close(ready[1]);
 128:	fb442503          	lw	a0,-76(s0)
 12c:	382000ef          	jal	4ae <close>
      close(ready[0]);
 130:	fb042503          	lw	a0,-80(s0)
 134:	37a000ef          	jal	4ae <close>
      for(int j = 0; j < i; j++)
 138:	4481                	li	s1,0
 13a:	0124cb63          	blt	s1,s2,150 <main+0x150>
      printf("starvetest: fork failed\n");
 13e:	00001517          	auipc	a0,0x1
 142:	b4250513          	addi	a0,a0,-1214 # c80 <thread_switch+0x98>
 146:	782000ef          	jal	8c8 <printf>
      exit(1);
 14a:	4505                	li	a0,1
 14c:	33a000ef          	jal	486 <exit>
        wait(0);
 150:	4501                	li	a0,0
 152:	33c000ef          	jal	48e <wait>
      for(int j = 0; j < i; j++)
 156:	2485                	addiw	s1,s1,1
 158:	b7cd                	j	13a <main+0x13a>
      close(gate[1]);
 15a:	fbc42503          	lw	a0,-68(s0)
 15e:	350000ef          	jal	4ae <close>
      close(ready[0]);
 162:	fb042503          	lw	a0,-80(s0)
 166:	348000ef          	jal	4ae <close>
      if(write(ready[1], "r", 1) != 1)
 16a:	4605                	li	a2,1
 16c:	00001597          	auipc	a1,0x1
 170:	b3458593          	addi	a1,a1,-1228 # ca0 <thread_switch+0xb8>
 174:	fb442503          	lw	a0,-76(s0)
 178:	32e000ef          	jal	4a6 <write>
 17c:	4785                	li	a5,1
 17e:	00f50863          	beq	a0,a5,18e <main+0x18e>
 182:	e4a6                	sd	s1,72(sp)
 184:	f852                	sd	s4,48(sp)
 186:	f456                	sd	s5,40(sp)
        exit(1);
 188:	853e                	mv	a0,a5
 18a:	2fc000ef          	jal	486 <exit>
      close(ready[1]);
 18e:	fb442503          	lw	a0,-76(s0)
 192:	31c000ef          	jal	4ae <close>
      if(read(gate[0], &token, 1) != 1)
 196:	4605                	li	a2,1
 198:	faf40593          	addi	a1,s0,-81
 19c:	fb842503          	lw	a0,-72(s0)
 1a0:	2fe000ef          	jal	49e <read>
 1a4:	4785                	li	a5,1
 1a6:	00f50863          	beq	a0,a5,1b6 <main+0x1b6>
 1aa:	e4a6                	sd	s1,72(sp)
 1ac:	f852                	sd	s4,48(sp)
 1ae:	f456                	sd	s5,40(sp)
        exit(1);
 1b0:	853e                	mv	a0,a5
 1b2:	2d4000ef          	jal	486 <exit>
      close(gate[0]);
 1b6:	fb842503          	lw	a0,-72(s0)
 1ba:	2f4000ef          	jal	4ae <close>
      volatile uint64 value = 1;
 1be:	4785                	li	a5,1
 1c0:	faf43023          	sd	a5,-96(s0)
        value = value * 1664525 + 1013904223;
 1c4:	001966b7          	lui	a3,0x196
 1c8:	60d68693          	addi	a3,a3,1549 # 19660d <all_thread+0x1955ed>
 1cc:	3c6ef737          	lui	a4,0x3c6ef
 1d0:	35f70713          	addi	a4,a4,863 # 3c6ef35f <all_thread+0x3c6ee33f>
 1d4:	fa043783          	ld	a5,-96(s0)
 1d8:	02d787b3          	mul	a5,a5,a3
 1dc:	97ba                	add	a5,a5,a4
 1de:	faf43023          	sd	a5,-96(s0)
      for(;;)
 1e2:	bfcd                	j	1d4 <main+0x1d4>
  close(gate[1]);
 1e4:	fbc42503          	lw	a0,-68(s0)
 1e8:	2c6000ef          	jal	4ae <close>
    printf("starvetest: startup failed; restart in a fresh xv6 session\n");
 1ec:	00001517          	auipc	a0,0x1
 1f0:	b3450513          	addi	a0,a0,-1228 # d20 <thread_switch+0x138>
 1f4:	6d4000ef          	jal	8c8 <printf>
 1f8:	b5d5                	j	dc <main+0xdc>

00000000000001fa <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 1fa:	1141                	addi	sp,sp,-16
 1fc:	e406                	sd	ra,8(sp)
 1fe:	e022                	sd	s0,0(sp)
 200:	0800                	addi	s0,sp,16
  extern int main();
  main();
 202:	dffff0ef          	jal	0 <main>
  exit(0);
 206:	4501                	li	a0,0
 208:	27e000ef          	jal	486 <exit>

000000000000020c <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 20c:	1141                	addi	sp,sp,-16
 20e:	e406                	sd	ra,8(sp)
 210:	e022                	sd	s0,0(sp)
 212:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 214:	87aa                	mv	a5,a0
 216:	0585                	addi	a1,a1,1
 218:	0785                	addi	a5,a5,1
 21a:	fff5c703          	lbu	a4,-1(a1)
 21e:	fee78fa3          	sb	a4,-1(a5)
 222:	fb75                	bnez	a4,216 <strcpy+0xa>
    ;
  return os;
}
 224:	60a2                	ld	ra,8(sp)
 226:	6402                	ld	s0,0(sp)
 228:	0141                	addi	sp,sp,16
 22a:	8082                	ret

000000000000022c <strcmp>:

int
strcmp(const char *p, const char *q)
{
 22c:	1141                	addi	sp,sp,-16
 22e:	e406                	sd	ra,8(sp)
 230:	e022                	sd	s0,0(sp)
 232:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 234:	00054783          	lbu	a5,0(a0)
 238:	cb91                	beqz	a5,24c <strcmp+0x20>
 23a:	0005c703          	lbu	a4,0(a1)
 23e:	00f71763          	bne	a4,a5,24c <strcmp+0x20>
    p++, q++;
 242:	0505                	addi	a0,a0,1
 244:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 246:	00054783          	lbu	a5,0(a0)
 24a:	fbe5                	bnez	a5,23a <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 24c:	0005c503          	lbu	a0,0(a1)
}
 250:	40a7853b          	subw	a0,a5,a0
 254:	60a2                	ld	ra,8(sp)
 256:	6402                	ld	s0,0(sp)
 258:	0141                	addi	sp,sp,16
 25a:	8082                	ret

000000000000025c <strlen>:

uint
strlen(const char *s)
{
 25c:	1141                	addi	sp,sp,-16
 25e:	e406                	sd	ra,8(sp)
 260:	e022                	sd	s0,0(sp)
 262:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 264:	00054783          	lbu	a5,0(a0)
 268:	cf91                	beqz	a5,284 <strlen+0x28>
 26a:	00150793          	addi	a5,a0,1
 26e:	86be                	mv	a3,a5
 270:	0785                	addi	a5,a5,1
 272:	fff7c703          	lbu	a4,-1(a5)
 276:	ff65                	bnez	a4,26e <strlen+0x12>
 278:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 27c:	60a2                	ld	ra,8(sp)
 27e:	6402                	ld	s0,0(sp)
 280:	0141                	addi	sp,sp,16
 282:	8082                	ret
  for(n = 0; s[n]; n++)
 284:	4501                	li	a0,0
 286:	bfdd                	j	27c <strlen+0x20>

0000000000000288 <memset>:

void*
memset(void *dst, int c, uint n)
{
 288:	1141                	addi	sp,sp,-16
 28a:	e406                	sd	ra,8(sp)
 28c:	e022                	sd	s0,0(sp)
 28e:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 290:	ca19                	beqz	a2,2a6 <memset+0x1e>
 292:	87aa                	mv	a5,a0
 294:	1602                	slli	a2,a2,0x20
 296:	9201                	srli	a2,a2,0x20
 298:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 29c:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 2a0:	0785                	addi	a5,a5,1
 2a2:	fee79de3          	bne	a5,a4,29c <memset+0x14>
  }
  return dst;
}
 2a6:	60a2                	ld	ra,8(sp)
 2a8:	6402                	ld	s0,0(sp)
 2aa:	0141                	addi	sp,sp,16
 2ac:	8082                	ret

00000000000002ae <strchr>:

char*
strchr(const char *s, char c)
{
 2ae:	1141                	addi	sp,sp,-16
 2b0:	e406                	sd	ra,8(sp)
 2b2:	e022                	sd	s0,0(sp)
 2b4:	0800                	addi	s0,sp,16
  for(; *s; s++)
 2b6:	00054783          	lbu	a5,0(a0)
 2ba:	c799                	beqz	a5,2c8 <strchr+0x1a>
    if(*s == c)
 2bc:	00f58763          	beq	a1,a5,2ca <strchr+0x1c>
  for(; *s; s++)
 2c0:	0505                	addi	a0,a0,1
 2c2:	00054783          	lbu	a5,0(a0)
 2c6:	fbfd                	bnez	a5,2bc <strchr+0xe>
      return (char*)s;
  return 0;
 2c8:	4501                	li	a0,0
}
 2ca:	60a2                	ld	ra,8(sp)
 2cc:	6402                	ld	s0,0(sp)
 2ce:	0141                	addi	sp,sp,16
 2d0:	8082                	ret

00000000000002d2 <gets>:

char*
gets(char *buf, int max)
{
 2d2:	711d                	addi	sp,sp,-96
 2d4:	ec86                	sd	ra,88(sp)
 2d6:	e8a2                	sd	s0,80(sp)
 2d8:	e4a6                	sd	s1,72(sp)
 2da:	e0ca                	sd	s2,64(sp)
 2dc:	fc4e                	sd	s3,56(sp)
 2de:	f852                	sd	s4,48(sp)
 2e0:	f456                	sd	s5,40(sp)
 2e2:	f05a                	sd	s6,32(sp)
 2e4:	ec5e                	sd	s7,24(sp)
 2e6:	e862                	sd	s8,16(sp)
 2e8:	1080                	addi	s0,sp,96
 2ea:	8baa                	mv	s7,a0
 2ec:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 2ee:	892a                	mv	s2,a0
 2f0:	4481                	li	s1,0
    cc = read(0, &c, 1);
 2f2:	faf40b13          	addi	s6,s0,-81
 2f6:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 2f8:	8c26                	mv	s8,s1
 2fa:	0014899b          	addiw	s3,s1,1
 2fe:	84ce                	mv	s1,s3
 300:	0349d863          	bge	s3,s4,330 <gets+0x5e>
    cc = read(0, &c, 1);
 304:	8656                	mv	a2,s5
 306:	85da                	mv	a1,s6
 308:	4501                	li	a0,0
 30a:	194000ef          	jal	49e <read>
    if(cc < 1)
 30e:	02a05163          	blez	a0,330 <gets+0x5e>
      break;
    buf[i++] = c;
 312:	faf44783          	lbu	a5,-81(s0)
 316:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 31a:	0905                	addi	s2,s2,1
 31c:	ff678713          	addi	a4,a5,-10
 320:	00173713          	seqz	a4,a4
 324:	17cd                	addi	a5,a5,-13
 326:	0017b793          	seqz	a5,a5
 32a:	8fd9                	or	a5,a5,a4
 32c:	d7f1                	beqz	a5,2f8 <gets+0x26>
    buf[i++] = c;
 32e:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 330:	9c5e                	add	s8,s8,s7
 332:	000c0023          	sb	zero,0(s8)
  return buf;
}
 336:	855e                	mv	a0,s7
 338:	60e6                	ld	ra,88(sp)
 33a:	6446                	ld	s0,80(sp)
 33c:	64a6                	ld	s1,72(sp)
 33e:	6906                	ld	s2,64(sp)
 340:	79e2                	ld	s3,56(sp)
 342:	7a42                	ld	s4,48(sp)
 344:	7aa2                	ld	s5,40(sp)
 346:	7b02                	ld	s6,32(sp)
 348:	6be2                	ld	s7,24(sp)
 34a:	6c42                	ld	s8,16(sp)
 34c:	6125                	addi	sp,sp,96
 34e:	8082                	ret

0000000000000350 <stat>:

int
stat(const char *n, struct stat *st)
{
 350:	1101                	addi	sp,sp,-32
 352:	ec06                	sd	ra,24(sp)
 354:	e822                	sd	s0,16(sp)
 356:	e04a                	sd	s2,0(sp)
 358:	1000                	addi	s0,sp,32
 35a:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 35c:	4581                	li	a1,0
 35e:	168000ef          	jal	4c6 <open>
  if(fd < 0)
 362:	02054263          	bltz	a0,386 <stat+0x36>
 366:	e426                	sd	s1,8(sp)
 368:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 36a:	85ca                	mv	a1,s2
 36c:	172000ef          	jal	4de <fstat>
 370:	892a                	mv	s2,a0
  close(fd);
 372:	8526                	mv	a0,s1
 374:	13a000ef          	jal	4ae <close>
  return r;
 378:	64a2                	ld	s1,8(sp)
}
 37a:	854a                	mv	a0,s2
 37c:	60e2                	ld	ra,24(sp)
 37e:	6442                	ld	s0,16(sp)
 380:	6902                	ld	s2,0(sp)
 382:	6105                	addi	sp,sp,32
 384:	8082                	ret
    return -1;
 386:	57fd                	li	a5,-1
 388:	893e                	mv	s2,a5
 38a:	bfc5                	j	37a <stat+0x2a>

000000000000038c <atoi>:

int
atoi(const char *s)
{
 38c:	1141                	addi	sp,sp,-16
 38e:	e406                	sd	ra,8(sp)
 390:	e022                	sd	s0,0(sp)
 392:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 394:	00054683          	lbu	a3,0(a0)
 398:	fd06879b          	addiw	a5,a3,-48
 39c:	0ff7f793          	zext.b	a5,a5
 3a0:	4625                	li	a2,9
 3a2:	02f66963          	bltu	a2,a5,3d4 <atoi+0x48>
 3a6:	872a                	mv	a4,a0
  n = 0;
 3a8:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 3aa:	0705                	addi	a4,a4,1
 3ac:	0025179b          	slliw	a5,a0,0x2
 3b0:	9fa9                	addw	a5,a5,a0
 3b2:	0017979b          	slliw	a5,a5,0x1
 3b6:	9fb5                	addw	a5,a5,a3
 3b8:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 3bc:	00074683          	lbu	a3,0(a4)
 3c0:	fd06879b          	addiw	a5,a3,-48
 3c4:	0ff7f793          	zext.b	a5,a5
 3c8:	fef671e3          	bgeu	a2,a5,3aa <atoi+0x1e>
  return n;
}
 3cc:	60a2                	ld	ra,8(sp)
 3ce:	6402                	ld	s0,0(sp)
 3d0:	0141                	addi	sp,sp,16
 3d2:	8082                	ret
  n = 0;
 3d4:	4501                	li	a0,0
 3d6:	bfdd                	j	3cc <atoi+0x40>

00000000000003d8 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 3d8:	1141                	addi	sp,sp,-16
 3da:	e406                	sd	ra,8(sp)
 3dc:	e022                	sd	s0,0(sp)
 3de:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 3e0:	02b57563          	bgeu	a0,a1,40a <memmove+0x32>
    while(n-- > 0)
 3e4:	00c05f63          	blez	a2,402 <memmove+0x2a>
 3e8:	1602                	slli	a2,a2,0x20
 3ea:	9201                	srli	a2,a2,0x20
 3ec:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 3f0:	872a                	mv	a4,a0
      *dst++ = *src++;
 3f2:	0585                	addi	a1,a1,1
 3f4:	0705                	addi	a4,a4,1
 3f6:	fff5c683          	lbu	a3,-1(a1)
 3fa:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 3fe:	fee79ae3          	bne	a5,a4,3f2 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 402:	60a2                	ld	ra,8(sp)
 404:	6402                	ld	s0,0(sp)
 406:	0141                	addi	sp,sp,16
 408:	8082                	ret
    while(n-- > 0)
 40a:	fec05ce3          	blez	a2,402 <memmove+0x2a>
    dst += n;
 40e:	00c50733          	add	a4,a0,a2
    src += n;
 412:	95b2                	add	a1,a1,a2
 414:	fff6079b          	addiw	a5,a2,-1
 418:	1782                	slli	a5,a5,0x20
 41a:	9381                	srli	a5,a5,0x20
 41c:	fff7c793          	not	a5,a5
 420:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 422:	15fd                	addi	a1,a1,-1
 424:	177d                	addi	a4,a4,-1
 426:	0005c683          	lbu	a3,0(a1)
 42a:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 42e:	fef71ae3          	bne	a4,a5,422 <memmove+0x4a>
 432:	bfc1                	j	402 <memmove+0x2a>

0000000000000434 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 434:	1141                	addi	sp,sp,-16
 436:	e406                	sd	ra,8(sp)
 438:	e022                	sd	s0,0(sp)
 43a:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 43c:	ce19                	beqz	a2,45a <memcmp+0x26>
 43e:	1602                	slli	a2,a2,0x20
 440:	9201                	srli	a2,a2,0x20
 442:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 446:	00054783          	lbu	a5,0(a0)
 44a:	0005c703          	lbu	a4,0(a1)
 44e:	00e79b63          	bne	a5,a4,464 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 452:	0505                	addi	a0,a0,1
    p2++;
 454:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 456:	fed518e3          	bne	a0,a3,446 <memcmp+0x12>
  }
  return 0;
 45a:	4501                	li	a0,0
}
 45c:	60a2                	ld	ra,8(sp)
 45e:	6402                	ld	s0,0(sp)
 460:	0141                	addi	sp,sp,16
 462:	8082                	ret
      return *p1 - *p2;
 464:	40e7853b          	subw	a0,a5,a4
 468:	bfd5                	j	45c <memcmp+0x28>

000000000000046a <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 46a:	1141                	addi	sp,sp,-16
 46c:	e406                	sd	ra,8(sp)
 46e:	e022                	sd	s0,0(sp)
 470:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 472:	f67ff0ef          	jal	3d8 <memmove>
}
 476:	60a2                	ld	ra,8(sp)
 478:	6402                	ld	s0,0(sp)
 47a:	0141                	addi	sp,sp,16
 47c:	8082                	ret

000000000000047e <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 47e:	4885                	li	a7,1
 ecall
 480:	00000073          	ecall
 ret
 484:	8082                	ret

0000000000000486 <exit>:
.global exit
exit:
 li a7, SYS_exit
 486:	4889                	li	a7,2
 ecall
 488:	00000073          	ecall
 ret
 48c:	8082                	ret

000000000000048e <wait>:
.global wait
wait:
 li a7, SYS_wait
 48e:	488d                	li	a7,3
 ecall
 490:	00000073          	ecall
 ret
 494:	8082                	ret

0000000000000496 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 496:	4891                	li	a7,4
 ecall
 498:	00000073          	ecall
 ret
 49c:	8082                	ret

000000000000049e <read>:
.global read
read:
 li a7, SYS_read
 49e:	4895                	li	a7,5
 ecall
 4a0:	00000073          	ecall
 ret
 4a4:	8082                	ret

00000000000004a6 <write>:
.global write
write:
 li a7, SYS_write
 4a6:	48c1                	li	a7,16
 ecall
 4a8:	00000073          	ecall
 ret
 4ac:	8082                	ret

00000000000004ae <close>:
.global close
close:
 li a7, SYS_close
 4ae:	48d5                	li	a7,21
 ecall
 4b0:	00000073          	ecall
 ret
 4b4:	8082                	ret

00000000000004b6 <kill>:
.global kill
kill:
 li a7, SYS_kill
 4b6:	4899                	li	a7,6
 ecall
 4b8:	00000073          	ecall
 ret
 4bc:	8082                	ret

00000000000004be <exec>:
.global exec
exec:
 li a7, SYS_exec
 4be:	489d                	li	a7,7
 ecall
 4c0:	00000073          	ecall
 ret
 4c4:	8082                	ret

00000000000004c6 <open>:
.global open
open:
 li a7, SYS_open
 4c6:	48bd                	li	a7,15
 ecall
 4c8:	00000073          	ecall
 ret
 4cc:	8082                	ret

00000000000004ce <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 4ce:	48c5                	li	a7,17
 ecall
 4d0:	00000073          	ecall
 ret
 4d4:	8082                	ret

00000000000004d6 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 4d6:	48c9                	li	a7,18
 ecall
 4d8:	00000073          	ecall
 ret
 4dc:	8082                	ret

00000000000004de <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 4de:	48a1                	li	a7,8
 ecall
 4e0:	00000073          	ecall
 ret
 4e4:	8082                	ret

00000000000004e6 <link>:
.global link
link:
 li a7, SYS_link
 4e6:	48cd                	li	a7,19
 ecall
 4e8:	00000073          	ecall
 ret
 4ec:	8082                	ret

00000000000004ee <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 4ee:	48d1                	li	a7,20
 ecall
 4f0:	00000073          	ecall
 ret
 4f4:	8082                	ret

00000000000004f6 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 4f6:	48a5                	li	a7,9
 ecall
 4f8:	00000073          	ecall
 ret
 4fc:	8082                	ret

00000000000004fe <dup>:
.global dup
dup:
 li a7, SYS_dup
 4fe:	48a9                	li	a7,10
 ecall
 500:	00000073          	ecall
 ret
 504:	8082                	ret

0000000000000506 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 506:	48ad                	li	a7,11
 ecall
 508:	00000073          	ecall
 ret
 50c:	8082                	ret

000000000000050e <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 50e:	48b1                	li	a7,12
 ecall
 510:	00000073          	ecall
 ret
 514:	8082                	ret

0000000000000516 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 516:	48b5                	li	a7,13
 ecall
 518:	00000073          	ecall
 ret
 51c:	8082                	ret

000000000000051e <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 51e:	48b9                	li	a7,14
 ecall
 520:	00000073          	ecall
 ret
 524:	8082                	ret

0000000000000526 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 526:	1101                	addi	sp,sp,-32
 528:	ec06                	sd	ra,24(sp)
 52a:	e822                	sd	s0,16(sp)
 52c:	1000                	addi	s0,sp,32
 52e:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 532:	4605                	li	a2,1
 534:	fef40593          	addi	a1,s0,-17
 538:	f6fff0ef          	jal	4a6 <write>
}
 53c:	60e2                	ld	ra,24(sp)
 53e:	6442                	ld	s0,16(sp)
 540:	6105                	addi	sp,sp,32
 542:	8082                	ret

0000000000000544 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 544:	715d                	addi	sp,sp,-80
 546:	e486                	sd	ra,72(sp)
 548:	e0a2                	sd	s0,64(sp)
 54a:	f84a                	sd	s2,48(sp)
 54c:	f44e                	sd	s3,40(sp)
 54e:	0880                	addi	s0,sp,80
 550:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 552:	00d036b3          	snez	a3,a3
 556:	03f5d793          	srli	a5,a1,0x3f
 55a:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 55c:	0005871b          	sext.w	a4,a1
  neg = 0;
 560:	4301                	li	t1,0
  if(sgn && xx < 0){
 562:	c681                	beqz	a3,56a <printint+0x26>
    x = -xx;
 564:	40b0073b          	negw	a4,a1
    neg = 1;
 568:	4305                	li	t1,1
  }

  i = 0;
 56a:	fb840993          	addi	s3,s0,-72
  neg = 0;
 56e:	85ce                	mv	a1,s3
  i = 0;
 570:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 572:	00001817          	auipc	a6,0x1
 576:	81e80813          	addi	a6,a6,-2018 # d90 <digits>
 57a:	88b6                	mv	a7,a3
 57c:	0016851b          	addiw	a0,a3,1
 580:	86aa                	mv	a3,a0
 582:	02c777bb          	remuw	a5,a4,a2
 586:	1782                	slli	a5,a5,0x20
 588:	9381                	srli	a5,a5,0x20
 58a:	97c2                	add	a5,a5,a6
 58c:	0007c783          	lbu	a5,0(a5)
 590:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 594:	87ba                	mv	a5,a4
 596:	02c7573b          	divuw	a4,a4,a2
 59a:	0585                	addi	a1,a1,1
 59c:	fcc7ffe3          	bgeu	a5,a2,57a <printint+0x36>
  if(neg)
 5a0:	00030b63          	beqz	t1,5b6 <printint+0x72>
    buf[i++] = '-';
 5a4:	fd040793          	addi	a5,s0,-48
 5a8:	953e                	add	a0,a0,a5
 5aa:	02d00793          	li	a5,45
 5ae:	fef50423          	sb	a5,-24(a0)
 5b2:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 5b6:	02d05563          	blez	a3,5e0 <printint+0x9c>
 5ba:	fc26                	sd	s1,56(sp)
 5bc:	36fd                	addiw	a3,a3,-1
 5be:	00d984b3          	add	s1,s3,a3
 5c2:	19fd                	addi	s3,s3,-1
 5c4:	99b6                	add	s3,s3,a3
 5c6:	1682                	slli	a3,a3,0x20
 5c8:	9281                	srli	a3,a3,0x20
 5ca:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 5ce:	0004c583          	lbu	a1,0(s1)
 5d2:	854a                	mv	a0,s2
 5d4:	f53ff0ef          	jal	526 <putc>
  while(--i >= 0)
 5d8:	14fd                	addi	s1,s1,-1
 5da:	ff349ae3          	bne	s1,s3,5ce <printint+0x8a>
 5de:	74e2                	ld	s1,56(sp)
}
 5e0:	60a6                	ld	ra,72(sp)
 5e2:	6406                	ld	s0,64(sp)
 5e4:	7942                	ld	s2,48(sp)
 5e6:	79a2                	ld	s3,40(sp)
 5e8:	6161                	addi	sp,sp,80
 5ea:	8082                	ret

00000000000005ec <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 5ec:	711d                	addi	sp,sp,-96
 5ee:	ec86                	sd	ra,88(sp)
 5f0:	e8a2                	sd	s0,80(sp)
 5f2:	e4a6                	sd	s1,72(sp)
 5f4:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 5f6:	0005c483          	lbu	s1,0(a1)
 5fa:	28048263          	beqz	s1,87e <vprintf+0x292>
 5fe:	e0ca                	sd	s2,64(sp)
 600:	fc4e                	sd	s3,56(sp)
 602:	f852                	sd	s4,48(sp)
 604:	f456                	sd	s5,40(sp)
 606:	f05a                	sd	s6,32(sp)
 608:	ec5e                	sd	s7,24(sp)
 60a:	e862                	sd	s8,16(sp)
 60c:	8b2a                	mv	s6,a0
 60e:	8a2e                	mv	s4,a1
 610:	8bb2                	mv	s7,a2
  state = 0;
 612:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 614:	4901                	li	s2,0
 616:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 618:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 61c:	06400c13          	li	s8,100
 620:	a00d                	j	642 <vprintf+0x56>
        putc(fd, c0);
 622:	85a6                	mv	a1,s1
 624:	855a                	mv	a0,s6
 626:	f01ff0ef          	jal	526 <putc>
 62a:	a019                	j	630 <vprintf+0x44>
    } else if(state == '%'){
 62c:	03598363          	beq	s3,s5,652 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 630:	0019079b          	addiw	a5,s2,1
 634:	893e                	mv	s2,a5
 636:	873e                	mv	a4,a5
 638:	97d2                	add	a5,a5,s4
 63a:	0007c483          	lbu	s1,0(a5)
 63e:	22048963          	beqz	s1,870 <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 642:	0004879b          	sext.w	a5,s1
    if(state == 0){
 646:	fe0993e3          	bnez	s3,62c <vprintf+0x40>
      if(c0 == '%'){
 64a:	fd579ce3          	bne	a5,s5,622 <vprintf+0x36>
        state = '%';
 64e:	89be                	mv	s3,a5
 650:	b7c5                	j	630 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 652:	00ea06b3          	add	a3,s4,a4
 656:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 65a:	22060763          	beqz	a2,888 <vprintf+0x29c>
      if(c0 == 'd'){
 65e:	0b878363          	beq	a5,s8,704 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 662:	f9478693          	addi	a3,a5,-108
 666:	0016b693          	seqz	a3,a3
 66a:	f9c60593          	addi	a1,a2,-100
 66e:	0015b593          	seqz	a1,a1
 672:	8df5                	and	a1,a1,a3
 674:	e5c5                	bnez	a1,71c <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 676:	9752                	add	a4,a4,s4
 678:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 67c:	f9460713          	addi	a4,a2,-108
 680:	00173713          	seqz	a4,a4
 684:	8f75                	and	a4,a4,a3
 686:	f9c50593          	addi	a1,a0,-100
 68a:	0015b593          	seqz	a1,a1
 68e:	8df9                	and	a1,a1,a4
 690:	e1dd                	bnez	a1,736 <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 692:	07500593          	li	a1,117
 696:	0ab78d63          	beq	a5,a1,750 <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 69a:	f8b60593          	addi	a1,a2,-117
 69e:	0015b593          	seqz	a1,a1
 6a2:	8df5                	and	a1,a1,a3
 6a4:	e1f1                	bnez	a1,768 <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 6a6:	f8b50593          	addi	a1,a0,-117
 6aa:	0015b593          	seqz	a1,a1
 6ae:	8df9                	and	a1,a1,a4
 6b0:	e9e9                	bnez	a1,782 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 6b2:	07800593          	li	a1,120
 6b6:	0eb78363          	beq	a5,a1,79c <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 6ba:	f8860613          	addi	a2,a2,-120
 6be:	00163613          	seqz	a2,a2
 6c2:	8ef1                	and	a3,a3,a2
 6c4:	0e069863          	bnez	a3,7b4 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 6c8:	f8850513          	addi	a0,a0,-120
 6cc:	00153513          	seqz	a0,a0
 6d0:	8f69                	and	a4,a4,a0
 6d2:	0e071e63          	bnez	a4,7ce <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 6d6:	07000713          	li	a4,112
 6da:	10e78663          	beq	a5,a4,7e6 <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 6de:	07300713          	li	a4,115
 6e2:	14e78663          	beq	a5,a4,82e <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 6e6:	02500713          	li	a4,37
 6ea:	16e78e63          	beq	a5,a4,866 <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 6ee:	02500593          	li	a1,37
 6f2:	855a                	mv	a0,s6
 6f4:	e33ff0ef          	jal	526 <putc>
        putc(fd, c0);
 6f8:	85a6                	mv	a1,s1
 6fa:	855a                	mv	a0,s6
 6fc:	e2bff0ef          	jal	526 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 700:	4981                	li	s3,0
 702:	b73d                	j	630 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 704:	008b8493          	addi	s1,s7,8
 708:	4685                	li	a3,1
 70a:	4629                	li	a2,10
 70c:	000ba583          	lw	a1,0(s7)
 710:	855a                	mv	a0,s6
 712:	e33ff0ef          	jal	544 <printint>
 716:	8ba6                	mv	s7,s1
      state = 0;
 718:	4981                	li	s3,0
 71a:	bf19                	j	630 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 71c:	008b8493          	addi	s1,s7,8
 720:	4685                	li	a3,1
 722:	4629                	li	a2,10
 724:	000bb583          	ld	a1,0(s7)
 728:	855a                	mv	a0,s6
 72a:	e1bff0ef          	jal	544 <printint>
        i += 1;
 72e:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 730:	8ba6                	mv	s7,s1
      state = 0;
 732:	4981                	li	s3,0
 734:	bdf5                	j	630 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 736:	008b8493          	addi	s1,s7,8
 73a:	4685                	li	a3,1
 73c:	4629                	li	a2,10
 73e:	000bb583          	ld	a1,0(s7)
 742:	855a                	mv	a0,s6
 744:	e01ff0ef          	jal	544 <printint>
        i += 2;
 748:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 74a:	8ba6                	mv	s7,s1
      state = 0;
 74c:	4981                	li	s3,0
        i += 2;
 74e:	b5cd                	j	630 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 750:	008b8493          	addi	s1,s7,8
 754:	4681                	li	a3,0
 756:	4629                	li	a2,10
 758:	000ba583          	lw	a1,0(s7)
 75c:	855a                	mv	a0,s6
 75e:	de7ff0ef          	jal	544 <printint>
 762:	8ba6                	mv	s7,s1
      state = 0;
 764:	4981                	li	s3,0
 766:	b5e9                	j	630 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 768:	008b8493          	addi	s1,s7,8
 76c:	4681                	li	a3,0
 76e:	4629                	li	a2,10
 770:	000bb583          	ld	a1,0(s7)
 774:	855a                	mv	a0,s6
 776:	dcfff0ef          	jal	544 <printint>
        i += 1;
 77a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 77c:	8ba6                	mv	s7,s1
      state = 0;
 77e:	4981                	li	s3,0
 780:	bd45                	j	630 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 782:	008b8493          	addi	s1,s7,8
 786:	4681                	li	a3,0
 788:	4629                	li	a2,10
 78a:	000bb583          	ld	a1,0(s7)
 78e:	855a                	mv	a0,s6
 790:	db5ff0ef          	jal	544 <printint>
        i += 2;
 794:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 796:	8ba6                	mv	s7,s1
      state = 0;
 798:	4981                	li	s3,0
        i += 2;
 79a:	bd59                	j	630 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 79c:	008b8493          	addi	s1,s7,8
 7a0:	4681                	li	a3,0
 7a2:	4641                	li	a2,16
 7a4:	000ba583          	lw	a1,0(s7)
 7a8:	855a                	mv	a0,s6
 7aa:	d9bff0ef          	jal	544 <printint>
 7ae:	8ba6                	mv	s7,s1
      state = 0;
 7b0:	4981                	li	s3,0
 7b2:	bdbd                	j	630 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 7b4:	008b8493          	addi	s1,s7,8
 7b8:	4681                	li	a3,0
 7ba:	4641                	li	a2,16
 7bc:	000bb583          	ld	a1,0(s7)
 7c0:	855a                	mv	a0,s6
 7c2:	d83ff0ef          	jal	544 <printint>
        i += 1;
 7c6:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 7c8:	8ba6                	mv	s7,s1
      state = 0;
 7ca:	4981                	li	s3,0
 7cc:	b595                	j	630 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 7ce:	008b8493          	addi	s1,s7,8
 7d2:	4641                	li	a2,16
 7d4:	000bb583          	ld	a1,0(s7)
 7d8:	855a                	mv	a0,s6
 7da:	d6bff0ef          	jal	544 <printint>
        i += 2;
 7de:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 7e0:	8ba6                	mv	s7,s1
      state = 0;
 7e2:	4981                	li	s3,0
        i += 2;
 7e4:	b5b1                	j	630 <vprintf+0x44>
 7e6:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 7e8:	008b8793          	addi	a5,s7,8
 7ec:	8cbe                	mv	s9,a5
 7ee:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 7f2:	03000593          	li	a1,48
 7f6:	855a                	mv	a0,s6
 7f8:	d2fff0ef          	jal	526 <putc>
  putc(fd, 'x');
 7fc:	07800593          	li	a1,120
 800:	855a                	mv	a0,s6
 802:	d25ff0ef          	jal	526 <putc>
 806:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 808:	00000b97          	auipc	s7,0x0
 80c:	588b8b93          	addi	s7,s7,1416 # d90 <digits>
 810:	03c9d793          	srli	a5,s3,0x3c
 814:	97de                	add	a5,a5,s7
 816:	0007c583          	lbu	a1,0(a5)
 81a:	855a                	mv	a0,s6
 81c:	d0bff0ef          	jal	526 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 820:	0992                	slli	s3,s3,0x4
 822:	34fd                	addiw	s1,s1,-1
 824:	f4f5                	bnez	s1,810 <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 826:	8be6                	mv	s7,s9
      state = 0;
 828:	4981                	li	s3,0
 82a:	6ca2                	ld	s9,8(sp)
 82c:	b511                	j	630 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 82e:	008b8993          	addi	s3,s7,8
 832:	000bb483          	ld	s1,0(s7)
 836:	cc91                	beqz	s1,852 <vprintf+0x266>
        for(; *s; s++)
 838:	0004c583          	lbu	a1,0(s1)
 83c:	c195                	beqz	a1,860 <vprintf+0x274>
          putc(fd, *s);
 83e:	855a                	mv	a0,s6
 840:	ce7ff0ef          	jal	526 <putc>
        for(; *s; s++)
 844:	0485                	addi	s1,s1,1
 846:	0004c583          	lbu	a1,0(s1)
 84a:	f9f5                	bnez	a1,83e <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 84c:	8bce                	mv	s7,s3
      state = 0;
 84e:	4981                	li	s3,0
 850:	b3c5                	j	630 <vprintf+0x44>
          s = "(null)";
 852:	00000497          	auipc	s1,0x0
 856:	50e48493          	addi	s1,s1,1294 # d60 <thread_switch+0x178>
        for(; *s; s++)
 85a:	02800593          	li	a1,40
 85e:	b7c5                	j	83e <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 860:	8bce                	mv	s7,s3
      state = 0;
 862:	4981                	li	s3,0
 864:	b3f1                	j	630 <vprintf+0x44>
        putc(fd, '%');
 866:	85be                	mv	a1,a5
 868:	855a                	mv	a0,s6
 86a:	cbdff0ef          	jal	526 <putc>
 86e:	bd49                	j	700 <vprintf+0x114>
 870:	6906                	ld	s2,64(sp)
 872:	79e2                	ld	s3,56(sp)
 874:	7a42                	ld	s4,48(sp)
 876:	7aa2                	ld	s5,40(sp)
 878:	7b02                	ld	s6,32(sp)
 87a:	6be2                	ld	s7,24(sp)
 87c:	6c42                	ld	s8,16(sp)
    }
  }
}
 87e:	60e6                	ld	ra,88(sp)
 880:	6446                	ld	s0,80(sp)
 882:	64a6                	ld	s1,72(sp)
 884:	6125                	addi	sp,sp,96
 886:	8082                	ret
      if(c0 == 'd'){
 888:	06400713          	li	a4,100
 88c:	e6e78ce3          	beq	a5,a4,704 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 890:	f9478693          	addi	a3,a5,-108
 894:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 898:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 89a:	4701                	li	a4,0
 89c:	bbdd                	j	692 <vprintf+0xa6>

000000000000089e <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 89e:	715d                	addi	sp,sp,-80
 8a0:	ec06                	sd	ra,24(sp)
 8a2:	e822                	sd	s0,16(sp)
 8a4:	1000                	addi	s0,sp,32
 8a6:	e010                	sd	a2,0(s0)
 8a8:	e414                	sd	a3,8(s0)
 8aa:	e818                	sd	a4,16(s0)
 8ac:	ec1c                	sd	a5,24(s0)
 8ae:	03043023          	sd	a6,32(s0)
 8b2:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 8b6:	8622                	mv	a2,s0
 8b8:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 8bc:	d31ff0ef          	jal	5ec <vprintf>
}
 8c0:	60e2                	ld	ra,24(sp)
 8c2:	6442                	ld	s0,16(sp)
 8c4:	6161                	addi	sp,sp,80
 8c6:	8082                	ret

00000000000008c8 <printf>:

void
printf(const char *fmt, ...)
{
 8c8:	711d                	addi	sp,sp,-96
 8ca:	ec06                	sd	ra,24(sp)
 8cc:	e822                	sd	s0,16(sp)
 8ce:	1000                	addi	s0,sp,32
 8d0:	e40c                	sd	a1,8(s0)
 8d2:	e810                	sd	a2,16(s0)
 8d4:	ec14                	sd	a3,24(s0)
 8d6:	f018                	sd	a4,32(s0)
 8d8:	f41c                	sd	a5,40(s0)
 8da:	03043823          	sd	a6,48(s0)
 8de:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 8e2:	00840613          	addi	a2,s0,8
 8e6:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 8ea:	85aa                	mv	a1,a0
 8ec:	4505                	li	a0,1
 8ee:	cffff0ef          	jal	5ec <vprintf>
}
 8f2:	60e2                	ld	ra,24(sp)
 8f4:	6442                	ld	s0,16(sp)
 8f6:	6125                	addi	sp,sp,96
 8f8:	8082                	ret

00000000000008fa <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 8fa:	1141                	addi	sp,sp,-16
 8fc:	e406                	sd	ra,8(sp)
 8fe:	e022                	sd	s0,0(sp)
 900:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 902:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 906:	00000797          	auipc	a5,0x0
 90a:	6fa7b783          	ld	a5,1786(a5) # 1000 <freep>
 90e:	a095                	j	972 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 910:	ff852583          	lw	a1,-8(a0)
 914:	6390                	ld	a2,0(a5)
 916:	02059813          	slli	a6,a1,0x20
 91a:	01c85693          	srli	a3,a6,0x1c
 91e:	96ba                	add	a3,a3,a4
 920:	02d60563          	beq	a2,a3,94a <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 924:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 928:	4790                	lw	a2,8(a5)
 92a:	02061593          	slli	a1,a2,0x20
 92e:	01c5d693          	srli	a3,a1,0x1c
 932:	96be                	add	a3,a3,a5
 934:	02d70263          	beq	a4,a3,958 <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 938:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 93a:	00000717          	auipc	a4,0x0
 93e:	6cf73323          	sd	a5,1734(a4) # 1000 <freep>
}
 942:	60a2                	ld	ra,8(sp)
 944:	6402                	ld	s0,0(sp)
 946:	0141                	addi	sp,sp,16
 948:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 94a:	4614                	lw	a3,8(a2)
 94c:	9ead                	addw	a3,a3,a1
 94e:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 952:	6394                	ld	a3,0(a5)
 954:	6290                	ld	a2,0(a3)
 956:	b7f9                	j	924 <free+0x2a>
    p->s.size += bp->s.size;
 958:	ff852703          	lw	a4,-8(a0)
 95c:	9f31                	addw	a4,a4,a2
 95e:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 960:	ff053703          	ld	a4,-16(a0)
 964:	bfd1                	j	938 <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 966:	6394                	ld	a3,0(a5)
 968:	00d7e463          	bltu	a5,a3,970 <free+0x76>
 96c:	fad762e3          	bltu	a4,a3,910 <free+0x16>
 970:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 972:	fee7fae3          	bgeu	a5,a4,966 <free+0x6c>
 976:	6394                	ld	a3,0(a5)
 978:	f8d76ce3          	bltu	a4,a3,910 <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 97c:	f8d7fae3          	bgeu	a5,a3,910 <free+0x16>
 980:	87b6                	mv	a5,a3
 982:	bfc5                	j	972 <free+0x78>

0000000000000984 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 984:	7139                	addi	sp,sp,-64
 986:	fc06                	sd	ra,56(sp)
 988:	f822                	sd	s0,48(sp)
 98a:	f04a                	sd	s2,32(sp)
 98c:	ec4e                	sd	s3,24(sp)
 98e:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 990:	02051993          	slli	s3,a0,0x20
 994:	0209d993          	srli	s3,s3,0x20
 998:	09bd                	addi	s3,s3,15
 99a:	0049d993          	srli	s3,s3,0x4
 99e:	2985                	addiw	s3,s3,1
 9a0:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 9a2:	00000517          	auipc	a0,0x0
 9a6:	65e53503          	ld	a0,1630(a0) # 1000 <freep>
 9aa:	c905                	beqz	a0,9da <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 9ac:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 9ae:	4798                	lw	a4,8(a5)
 9b0:	09377663          	bgeu	a4,s3,a3c <malloc+0xb8>
 9b4:	f426                	sd	s1,40(sp)
 9b6:	e852                	sd	s4,16(sp)
 9b8:	e456                	sd	s5,8(sp)
 9ba:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 9bc:	8a4e                	mv	s4,s3
 9be:	6705                	lui	a4,0x1
 9c0:	00e9f363          	bgeu	s3,a4,9c6 <malloc+0x42>
 9c4:	6a05                	lui	s4,0x1
 9c6:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 9ca:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 9ce:	00000497          	auipc	s1,0x0
 9d2:	63248493          	addi	s1,s1,1586 # 1000 <freep>
  if(p == (char*)-1)
 9d6:	5afd                	li	s5,-1
 9d8:	a83d                	j	a16 <malloc+0x92>
 9da:	f426                	sd	s1,40(sp)
 9dc:	e852                	sd	s4,16(sp)
 9de:	e456                	sd	s5,8(sp)
 9e0:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 9e2:	00000797          	auipc	a5,0x0
 9e6:	62e78793          	addi	a5,a5,1582 # 1010 <base>
 9ea:	00000717          	auipc	a4,0x0
 9ee:	60f73b23          	sd	a5,1558(a4) # 1000 <freep>
 9f2:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 9f4:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 9f8:	b7d1                	j	9bc <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 9fa:	6398                	ld	a4,0(a5)
 9fc:	e118                	sd	a4,0(a0)
 9fe:	a899                	j	a54 <malloc+0xd0>
  hp->s.size = nu;
 a00:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 a04:	0541                	addi	a0,a0,16
 a06:	ef5ff0ef          	jal	8fa <free>
  return freep;
 a0a:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 a0c:	c125                	beqz	a0,a6c <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a0e:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a10:	4798                	lw	a4,8(a5)
 a12:	03277163          	bgeu	a4,s2,a34 <malloc+0xb0>
    if(p == freep)
 a16:	6098                	ld	a4,0(s1)
 a18:	853e                	mv	a0,a5
 a1a:	fef71ae3          	bne	a4,a5,a0e <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 a1e:	8552                	mv	a0,s4
 a20:	aefff0ef          	jal	50e <sbrk>
  if(p == (char*)-1)
 a24:	fd551ee3          	bne	a0,s5,a00 <malloc+0x7c>
        return 0;
 a28:	4501                	li	a0,0
 a2a:	74a2                	ld	s1,40(sp)
 a2c:	6a42                	ld	s4,16(sp)
 a2e:	6aa2                	ld	s5,8(sp)
 a30:	6b02                	ld	s6,0(sp)
 a32:	a03d                	j	a60 <malloc+0xdc>
 a34:	74a2                	ld	s1,40(sp)
 a36:	6a42                	ld	s4,16(sp)
 a38:	6aa2                	ld	s5,8(sp)
 a3a:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 a3c:	fae90fe3          	beq	s2,a4,9fa <malloc+0x76>
        p->s.size -= nunits;
 a40:	4137073b          	subw	a4,a4,s3
 a44:	c798                	sw	a4,8(a5)
        p += p->s.size;
 a46:	02071693          	slli	a3,a4,0x20
 a4a:	01c6d713          	srli	a4,a3,0x1c
 a4e:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 a50:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 a54:	00000717          	auipc	a4,0x0
 a58:	5aa73623          	sd	a0,1452(a4) # 1000 <freep>
      return (void*)(p + 1);
 a5c:	01078513          	addi	a0,a5,16
  }
}
 a60:	70e2                	ld	ra,56(sp)
 a62:	7442                	ld	s0,48(sp)
 a64:	7902                	ld	s2,32(sp)
 a66:	69e2                	ld	s3,24(sp)
 a68:	6121                	addi	sp,sp,64
 a6a:	8082                	ret
 a6c:	74a2                	ld	s1,40(sp)
 a6e:	6a42                	ld	s4,16(sp)
 a70:	6aa2                	ld	s5,8(sp)
 a72:	6b02                	ld	s6,0(sp)
 a74:	b7f5                	j	a60 <malloc+0xdc>

0000000000000a76 <thread_init>:
struct thread *current_thread;
extern void thread_switch(uint64, uint64);
              
void 
thread_init(void)
{
 a76:	1141                	addi	sp,sp,-16
 a78:	e406                	sd	ra,8(sp)
 a7a:	e022                	sd	s0,0(sp)
 a7c:	0800                	addi	s0,sp,16
  // main() is thread 0, which will make the first invocation to
  // thread_schedule(). It needs a stack so that the first thread_switch() can
  // save thread 0's state.
  current_thread = &all_thread[0];
 a7e:	00000797          	auipc	a5,0x0
 a82:	5a278793          	addi	a5,a5,1442 # 1020 <all_thread>
 a86:	00000717          	auipc	a4,0x0
 a8a:	58f73123          	sd	a5,1410(a4) # 1008 <current_thread>
  current_thread->state = RUNNING;
 a8e:	00002717          	auipc	a4,0x2
 a92:	59270713          	addi	a4,a4,1426 # 3020 <all_thread+0x2000>
 a96:	4785                	li	a5,1
 a98:	c31c                	sw	a5,0(a4)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 a9a:	00002797          	auipc	a5,0x2
 a9e:	51678793          	addi	a5,a5,1302 # 2fb0 <all_thread+0x1f90>
  return (struct context *)(top & ~(uint64)0xf);
 aa2:	9bc1                	andi	a5,a5,-16
  // Thread 0 runs on the process's own stack, but the first thread_switch()
  // still needs a writable place to save its context.
  current_thread->context = thread_context_slot(current_thread);
 aa4:	e71c                	sd	a5,8(a4)
}
 aa6:	60a2                	ld	ra,8(sp)
 aa8:	6402                	ld	s0,0(sp)
 aaa:	0141                	addi	sp,sp,16
 aac:	8082                	ret

0000000000000aae <thread_schedule>:

void 
thread_schedule(void)
{
 aae:	1141                	addi	sp,sp,-16
 ab0:	e406                	sd	ra,8(sp)
 ab2:	e022                	sd	s0,0(sp)
 ab4:	0800                	addi	s0,sp,16
  struct thread *t, *next_thread;

  /* Find another runnable thread. */
  next_thread = 0;
  t = current_thread + 1;
 ab6:	00000597          	auipc	a1,0x0
 aba:	5525b583          	ld	a1,1362(a1) # 1008 <current_thread>
 abe:	6789                	lui	a5,0x2
 ac0:	07c1                	addi	a5,a5,16 # 2010 <all_thread+0xff0>
 ac2:	97ae                	add	a5,a5,a1
 ac4:	4711                	li	a4,4
  for(int i = 0; i < MAX_THREAD; i++){
    if(t >= all_thread + MAX_THREAD)
 ac6:	00008897          	auipc	a7,0x8
 aca:	59a88893          	addi	a7,a7,1434 # 9060 <all_thread+0x8040>
      t = all_thread;
    if(t->state == RUNNABLE) {
 ace:	6809                	lui	a6,0x2
 ad0:	4509                	li	a0,2
      next_thread = t;
      break;
    }
    t = t + 1;
 ad2:	01080613          	addi	a2,a6,16 # 2010 <all_thread+0xff0>
 ad6:	a809                	j	ae8 <thread_schedule+0x3a>
    if(t->state == RUNNABLE) {
 ad8:	010786b3          	add	a3,a5,a6
 adc:	4294                	lw	a3,0(a3)
 ade:	02a68563          	beq	a3,a0,b08 <thread_schedule+0x5a>
    t = t + 1;
 ae2:	97b2                	add	a5,a5,a2
  for(int i = 0; i < MAX_THREAD; i++){
 ae4:	377d                	addiw	a4,a4,-1
 ae6:	cb01                	beqz	a4,af6 <thread_schedule+0x48>
    if(t >= all_thread + MAX_THREAD)
 ae8:	ff17e8e3          	bltu	a5,a7,ad8 <thread_schedule+0x2a>
      t = all_thread;
 aec:	00000797          	auipc	a5,0x0
 af0:	53478793          	addi	a5,a5,1332 # 1020 <all_thread>
 af4:	b7d5                	j	ad8 <thread_schedule+0x2a>
  }

  if (next_thread == 0) {
    printf("thread_schedule: no runnable threads\n");
 af6:	00000517          	auipc	a0,0x0
 afa:	27250513          	addi	a0,a0,626 # d68 <thread_switch+0x180>
 afe:	dcbff0ef          	jal	8c8 <printf>
    exit(-1);
 b02:	557d                	li	a0,-1
 b04:	983ff0ef          	jal	486 <exit>
  }

  if (current_thread != next_thread) {         /* switch threads?  */
 b08:	02f58163          	beq	a1,a5,b2a <thread_schedule+0x7c>
    next_thread->state = RUNNING;
 b0c:	6689                	lui	a3,0x2
 b0e:	00d78733          	add	a4,a5,a3
 b12:	4605                	li	a2,1
 b14:	c310                	sw	a2,0(a4)
    t = current_thread;
    current_thread = next_thread;
 b16:	00000617          	auipc	a2,0x0
 b1a:	4ef63923          	sd	a5,1266(a2) # 1008 <current_thread>
    thread_switch((uint64)t->context, (uint64)next_thread->context);
 b1e:	00d587b3          	add	a5,a1,a3
 b22:	670c                	ld	a1,8(a4)
 b24:	6788                	ld	a0,8(a5)
 b26:	0c2000ef          	jal	be8 <thread_switch>
  } else
    next_thread = 0;
}
 b2a:	60a2                	ld	ra,8(sp)
 b2c:	6402                	ld	s0,0(sp)
 b2e:	0141                	addi	sp,sp,16
 b30:	8082                	ret

0000000000000b32 <thread_create>:

void 
thread_create(void (*func)())
{
 b32:	1101                	addi	sp,sp,-32
 b34:	ec06                	sd	ra,24(sp)
 b36:	e822                	sd	s0,16(sp)
 b38:	e426                	sd	s1,8(sp)
 b3a:	e04a                	sd	s2,0(sp)
 b3c:	1000                	addi	s0,sp,32
 b3e:	892a                	mv	s2,a0
  struct thread *t;

  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 b40:	00002797          	auipc	a5,0x2
 b44:	4f078793          	addi	a5,a5,1264 # 3030 <all_thread+0x2010>
 b48:	0000a597          	auipc	a1,0xa
 b4c:	52858593          	addi	a1,a1,1320 # b070 <all_thread+0xa050>
 b50:	6609                	lui	a2,0x2
 b52:	0641                	addi	a2,a2,16 # 2010 <all_thread+0xff0>
    if (t->state == FREE) break;
 b54:	873e                	mv	a4,a5
 b56:	ff07a683          	lw	a3,-16(a5)
 b5a:	ce9d                	beqz	a3,b98 <thread_create+0x66>
  for (t = all_thread; t < all_thread + MAX_THREAD; t++) {
 b5c:	97b2                	add	a5,a5,a2
 b5e:	feb79be3          	bne	a5,a1,b54 <thread_create+0x22>
  }
  t->state = RUNNABLE;
 b62:	6489                	lui	s1,0x2
 b64:	94ba                	add	s1,s1,a4
 b66:	4789                	li	a5,2
 b68:	c09c                	sw	a5,0(s1)
  uint64 top = (uint64)t->stack + STACK_SIZE - sizeof(struct context);
 b6a:	6789                	lui	a5,0x2
 b6c:	f9078793          	addi	a5,a5,-112 # 1f90 <all_thread+0xf70>
 b70:	973e                	add	a4,a4,a5
  return (struct context *)(top & ~(uint64)0xf);
 b72:	ff077513          	andi	a0,a4,-16
  // A never-run thread has no saved state, so construct one: thread_switch()
  // restores ra and sp, and `ret` then starts func on this thread's own stack.
  t->context = thread_context_slot(t);
 b76:	e488                	sd	a0,8(s1)
  memset(t->context, 0, sizeof(struct context));
 b78:	07000613          	li	a2,112
 b7c:	4581                	li	a1,0
 b7e:	f0aff0ef          	jal	288 <memset>
  t->context->ra = (uint64)func;
 b82:	649c                	ld	a5,8(s1)
 b84:	0127b023          	sd	s2,0(a5)
  t->context->sp = (uint64)t->context;   // 16-byte aligned, grows down
 b88:	649c                	ld	a5,8(s1)
 b8a:	e79c                	sd	a5,8(a5)
}
 b8c:	60e2                	ld	ra,24(sp)
 b8e:	6442                	ld	s0,16(sp)
 b90:	64a2                	ld	s1,8(sp)
 b92:	6902                	ld	s2,0(sp)
 b94:	6105                	addi	sp,sp,32
 b96:	8082                	ret
 b98:	7779                	lui	a4,0xffffe
 b9a:	1741                	addi	a4,a4,-16 # ffffffffffffdff0 <all_thread+0xffffffffffffcfd0>
 b9c:	973e                	add	a4,a4,a5
 b9e:	b7d1                	j	b62 <thread_create+0x30>

0000000000000ba0 <thread_yield>:

void 
thread_yield(void)
{
 ba0:	1141                	addi	sp,sp,-16
 ba2:	e406                	sd	ra,8(sp)
 ba4:	e022                	sd	s0,0(sp)
 ba6:	0800                	addi	s0,sp,16
  current_thread->state = RUNNABLE;
 ba8:	00000797          	auipc	a5,0x0
 bac:	4607b783          	ld	a5,1120(a5) # 1008 <current_thread>
 bb0:	6709                	lui	a4,0x2
 bb2:	97ba                	add	a5,a5,a4
 bb4:	4709                	li	a4,2
 bb6:	c398                	sw	a4,0(a5)
  thread_schedule();
 bb8:	ef7ff0ef          	jal	aae <thread_schedule>
}
 bbc:	60a2                	ld	ra,8(sp)
 bbe:	6402                	ld	s0,0(sp)
 bc0:	0141                	addi	sp,sp,16
 bc2:	8082                	ret

0000000000000bc4 <thread_exit>:

void thread_exit(void) {
 bc4:	1141                	addi	sp,sp,-16
 bc6:	e406                	sd	ra,8(sp)
 bc8:	e022                	sd	s0,0(sp)
 bca:	0800                	addi	s0,sp,16
  current_thread->state = FREE;
 bcc:	00000797          	auipc	a5,0x0
 bd0:	43c7b783          	ld	a5,1084(a5) # 1008 <current_thread>
 bd4:	6709                	lui	a4,0x2
 bd6:	97ba                	add	a5,a5,a4
 bd8:	0007a023          	sw	zero,0(a5)
  thread_schedule();
 bdc:	ed3ff0ef          	jal	aae <thread_schedule>
}
 be0:	60a2                	ld	ra,8(sp)
 be2:	6402                	ld	s0,0(sp)
 be4:	0141                	addi	sp,sp,16
 be6:	8082                	ret

0000000000000be8 <thread_switch>:
 be8:	00153023          	sd	ra,0(a0)
 bec:	00253423          	sd	sp,8(a0)
 bf0:	e900                	sd	s0,16(a0)
 bf2:	ed04                	sd	s1,24(a0)
 bf4:	03253023          	sd	s2,32(a0)
 bf8:	03353423          	sd	s3,40(a0)
 bfc:	03453823          	sd	s4,48(a0)
 c00:	03553c23          	sd	s5,56(a0)
 c04:	05653023          	sd	s6,64(a0)
 c08:	05753423          	sd	s7,72(a0)
 c0c:	05853823          	sd	s8,80(a0)
 c10:	05953c23          	sd	s9,88(a0)
 c14:	07a53023          	sd	s10,96(a0)
 c18:	07b53423          	sd	s11,104(a0)
 c1c:	0005b083          	ld	ra,0(a1)
 c20:	0085b103          	ld	sp,8(a1)
 c24:	6980                	ld	s0,16(a1)
 c26:	6d84                	ld	s1,24(a1)
 c28:	0205b903          	ld	s2,32(a1)
 c2c:	0285b983          	ld	s3,40(a1)
 c30:	0305ba03          	ld	s4,48(a1)
 c34:	0385ba83          	ld	s5,56(a1)
 c38:	0405bb03          	ld	s6,64(a1)
 c3c:	0485bb83          	ld	s7,72(a1)
 c40:	0505bc03          	ld	s8,80(a1)
 c44:	0585bc83          	ld	s9,88(a1)
 c48:	0605bd03          	ld	s10,96(a1)
 c4c:	0685bd83          	ld	s11,104(a1)
 c50:	8082                	ret
