
user/_ls:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <fmtname>:
#include "kernel/fs.h"
#include "kernel/fcntl.h"

char*
fmtname(char *path)
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	e426                	sd	s1,8(sp)
   8:	1000                	addi	s0,sp,32
   a:	84aa                	mv	s1,a0
  static char buf[DIRSIZ+1];
  char *p;

  // Find first character after last slash.
  for(p=path+strlen(path); p >= path && *p != '/'; p--)
   c:	2ae000ef          	jal	2ba <strlen>
  10:	02051793          	slli	a5,a0,0x20
  14:	9381                	srli	a5,a5,0x20
  16:	97a6                	add	a5,a5,s1
  18:	02f00693          	li	a3,47
  1c:	0097e963          	bltu	a5,s1,2e <fmtname+0x2e>
  20:	0007c703          	lbu	a4,0(a5)
  24:	00d70563          	beq	a4,a3,2e <fmtname+0x2e>
  28:	17fd                	addi	a5,a5,-1
  2a:	fe97fbe3          	bgeu	a5,s1,20 <fmtname+0x20>
    ;
  p++;
  2e:	00178493          	addi	s1,a5,1

  // Return blank-padded name.
  if(strlen(p) >= DIRSIZ)
  32:	8526                	mv	a0,s1
  34:	286000ef          	jal	2ba <strlen>
  38:	47b5                	li	a5,13
  3a:	00a7f863          	bgeu	a5,a0,4a <fmtname+0x4a>
    return p;
  memmove(buf, p, strlen(p));
  memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));
  return buf;
}
  3e:	8526                	mv	a0,s1
  40:	60e2                	ld	ra,24(sp)
  42:	6442                	ld	s0,16(sp)
  44:	64a2                	ld	s1,8(sp)
  46:	6105                	addi	sp,sp,32
  48:	8082                	ret
  4a:	e04a                	sd	s2,0(sp)
  memmove(buf, p, strlen(p));
  4c:	8526                	mv	a0,s1
  4e:	26c000ef          	jal	2ba <strlen>
  52:	862a                	mv	a2,a0
  54:	85a6                	mv	a1,s1
  56:	00001517          	auipc	a0,0x1
  5a:	fba50513          	addi	a0,a0,-70 # 1010 <buf.0>
  5e:	3d8000ef          	jal	436 <memmove>
  memset(buf+strlen(p), ' ', DIRSIZ-strlen(p));
  62:	8526                	mv	a0,s1
  64:	256000ef          	jal	2ba <strlen>
  68:	892a                	mv	s2,a0
  6a:	8526                	mv	a0,s1
  6c:	24e000ef          	jal	2ba <strlen>
  70:	02091793          	slli	a5,s2,0x20
  74:	9381                	srli	a5,a5,0x20
  76:	4639                	li	a2,14
  78:	9e09                	subw	a2,a2,a0
  7a:	02000593          	li	a1,32
  7e:	00001517          	auipc	a0,0x1
  82:	f9250513          	addi	a0,a0,-110 # 1010 <buf.0>
  86:	953e                	add	a0,a0,a5
  88:	25e000ef          	jal	2e6 <memset>
  return buf;
  8c:	00001497          	auipc	s1,0x1
  90:	f8448493          	addi	s1,s1,-124 # 1010 <buf.0>
  94:	6902                	ld	s2,0(sp)
  96:	b765                	j	3e <fmtname+0x3e>

0000000000000098 <ls>:

void
ls(char *path)
{
  98:	da010113          	addi	sp,sp,-608
  9c:	24113c23          	sd	ra,600(sp)
  a0:	24813823          	sd	s0,592(sp)
  a4:	25213023          	sd	s2,576(sp)
  a8:	1480                	addi	s0,sp,608
  aa:	892a                	mv	s2,a0
  char buf[512], *p;
  int fd;
  struct dirent de;
  struct stat st;

  if((fd = open(path, O_RDONLY)) < 0){
  ac:	4581                	li	a1,0
  ae:	476000ef          	jal	524 <open>
  b2:	06054363          	bltz	a0,118 <ls+0x80>
  b6:	24913423          	sd	s1,584(sp)
  ba:	84aa                	mv	s1,a0
    fprintf(2, "ls: cannot open %s\n", path);
    return;
  }

  if(fstat(fd, &st) < 0){
  bc:	da840593          	addi	a1,s0,-600
  c0:	47c000ef          	jal	53c <fstat>
  c4:	06054363          	bltz	a0,12a <ls+0x92>
    fprintf(2, "ls: cannot stat %s\n", path);
    close(fd);
    return;
  }

  switch(st.type){
  c8:	db041783          	lh	a5,-592(s0)
  cc:	4705                	li	a4,1
  ce:	06e78c63          	beq	a5,a4,146 <ls+0xae>
  d2:	37f9                	addiw	a5,a5,-2
  d4:	17c2                	slli	a5,a5,0x30
  d6:	93c1                	srli	a5,a5,0x30
  d8:	02f76263          	bltu	a4,a5,fc <ls+0x64>
  case T_DEVICE:
  case T_FILE:
    printf("%s %d %d %d\n", fmtname(path), st.type, st.ino, (int) st.size);
  dc:	854a                	mv	a0,s2
  de:	f23ff0ef          	jal	0 <fmtname>
  e2:	85aa                	mv	a1,a0
  e4:	db842703          	lw	a4,-584(s0)
  e8:	dac42683          	lw	a3,-596(s0)
  ec:	db041603          	lh	a2,-592(s0)
  f0:	00001517          	auipc	a0,0x1
  f4:	a2050513          	addi	a0,a0,-1504 # b10 <malloc+0x126>
  f8:	037000ef          	jal	92e <printf>
      }
      printf("%s %d %d %d\n", fmtname(buf), st.type, st.ino, (int) st.size);
    }
    break;
  }
  close(fd);
  fc:	8526                	mv	a0,s1
  fe:	40e000ef          	jal	50c <close>
 102:	24813483          	ld	s1,584(sp)
}
 106:	25813083          	ld	ra,600(sp)
 10a:	25013403          	ld	s0,592(sp)
 10e:	24013903          	ld	s2,576(sp)
 112:	26010113          	addi	sp,sp,608
 116:	8082                	ret
    fprintf(2, "ls: cannot open %s\n", path);
 118:	864a                	mv	a2,s2
 11a:	00001597          	auipc	a1,0x1
 11e:	9c658593          	addi	a1,a1,-1594 # ae0 <malloc+0xf6>
 122:	4509                	li	a0,2
 124:	7e0000ef          	jal	904 <fprintf>
    return;
 128:	bff9                	j	106 <ls+0x6e>
    fprintf(2, "ls: cannot stat %s\n", path);
 12a:	864a                	mv	a2,s2
 12c:	00001597          	auipc	a1,0x1
 130:	9cc58593          	addi	a1,a1,-1588 # af8 <malloc+0x10e>
 134:	4509                	li	a0,2
 136:	7ce000ef          	jal	904 <fprintf>
    close(fd);
 13a:	8526                	mv	a0,s1
 13c:	3d0000ef          	jal	50c <close>
    return;
 140:	24813483          	ld	s1,584(sp)
 144:	b7c9                	j	106 <ls+0x6e>
    if(strlen(path) + 1 + DIRSIZ + 1 > sizeof buf){
 146:	854a                	mv	a0,s2
 148:	172000ef          	jal	2ba <strlen>
 14c:	2541                	addiw	a0,a0,16
 14e:	20000793          	li	a5,512
 152:	00a7f963          	bgeu	a5,a0,164 <ls+0xcc>
      printf("ls: path too long\n");
 156:	00001517          	auipc	a0,0x1
 15a:	9ca50513          	addi	a0,a0,-1590 # b20 <malloc+0x136>
 15e:	7d0000ef          	jal	92e <printf>
      break;
 162:	bf69                	j	fc <ls+0x64>
 164:	23313c23          	sd	s3,568(sp)
    strcpy(buf, path);
 168:	85ca                	mv	a1,s2
 16a:	dd040513          	addi	a0,s0,-560
 16e:	0fc000ef          	jal	26a <strcpy>
    p = buf+strlen(buf);
 172:	dd040513          	addi	a0,s0,-560
 176:	144000ef          	jal	2ba <strlen>
 17a:	1502                	slli	a0,a0,0x20
 17c:	9101                	srli	a0,a0,0x20
 17e:	dd040793          	addi	a5,s0,-560
 182:	00a78733          	add	a4,a5,a0
 186:	893a                	mv	s2,a4
    *p++ = '/';
 188:	00170793          	addi	a5,a4,1
 18c:	89be                	mv	s3,a5
 18e:	02f00793          	li	a5,47
 192:	00f70023          	sb	a5,0(a4)
    while(read(fd, &de, sizeof(de)) == sizeof(de)){
 196:	a809                	j	1a8 <ls+0x110>
        printf("ls: cannot stat %s\n", buf);
 198:	dd040593          	addi	a1,s0,-560
 19c:	00001517          	auipc	a0,0x1
 1a0:	95c50513          	addi	a0,a0,-1700 # af8 <malloc+0x10e>
 1a4:	78a000ef          	jal	92e <printf>
    while(read(fd, &de, sizeof(de)) == sizeof(de)){
 1a8:	4641                	li	a2,16
 1aa:	dc040593          	addi	a1,s0,-576
 1ae:	8526                	mv	a0,s1
 1b0:	34c000ef          	jal	4fc <read>
 1b4:	47c1                	li	a5,16
 1b6:	04f51763          	bne	a0,a5,204 <ls+0x16c>
      if(de.inum == 0)
 1ba:	dc045783          	lhu	a5,-576(s0)
 1be:	d7ed                	beqz	a5,1a8 <ls+0x110>
      memmove(p, de.name, DIRSIZ);
 1c0:	4639                	li	a2,14
 1c2:	dc240593          	addi	a1,s0,-574
 1c6:	854e                	mv	a0,s3
 1c8:	26e000ef          	jal	436 <memmove>
      p[DIRSIZ] = 0;
 1cc:	000907a3          	sb	zero,15(s2)
      if(stat(buf, &st) < 0){
 1d0:	da840593          	addi	a1,s0,-600
 1d4:	dd040513          	addi	a0,s0,-560
 1d8:	1d6000ef          	jal	3ae <stat>
 1dc:	fa054ee3          	bltz	a0,198 <ls+0x100>
      printf("%s %d %d %d\n", fmtname(buf), st.type, st.ino, (int) st.size);
 1e0:	dd040513          	addi	a0,s0,-560
 1e4:	e1dff0ef          	jal	0 <fmtname>
 1e8:	85aa                	mv	a1,a0
 1ea:	db842703          	lw	a4,-584(s0)
 1ee:	dac42683          	lw	a3,-596(s0)
 1f2:	db041603          	lh	a2,-592(s0)
 1f6:	00001517          	auipc	a0,0x1
 1fa:	91a50513          	addi	a0,a0,-1766 # b10 <malloc+0x126>
 1fe:	730000ef          	jal	92e <printf>
 202:	b75d                	j	1a8 <ls+0x110>
 204:	23813983          	ld	s3,568(sp)
 208:	bdd5                	j	fc <ls+0x64>

000000000000020a <main>:

int
main(int argc, char *argv[])
{
 20a:	1101                	addi	sp,sp,-32
 20c:	ec06                	sd	ra,24(sp)
 20e:	e822                	sd	s0,16(sp)
 210:	1000                	addi	s0,sp,32
  int i;

  if(argc < 2){
 212:	4785                	li	a5,1
 214:	02a7d763          	bge	a5,a0,242 <main+0x38>
 218:	e426                	sd	s1,8(sp)
 21a:	e04a                	sd	s2,0(sp)
 21c:	00858493          	addi	s1,a1,8
 220:	ffe5091b          	addiw	s2,a0,-2
 224:	02091793          	slli	a5,s2,0x20
 228:	01d7d913          	srli	s2,a5,0x1d
 22c:	05c1                	addi	a1,a1,16
 22e:	992e                	add	s2,s2,a1
    ls(".");
    exit(0);
  }
  for(i=1; i<argc; i++)
    ls(argv[i]);
 230:	6088                	ld	a0,0(s1)
 232:	e67ff0ef          	jal	98 <ls>
  for(i=1; i<argc; i++)
 236:	04a1                	addi	s1,s1,8
 238:	ff249ce3          	bne	s1,s2,230 <main+0x26>
  exit(0);
 23c:	4501                	li	a0,0
 23e:	2a6000ef          	jal	4e4 <exit>
 242:	e426                	sd	s1,8(sp)
 244:	e04a                	sd	s2,0(sp)
    ls(".");
 246:	00001517          	auipc	a0,0x1
 24a:	8f250513          	addi	a0,a0,-1806 # b38 <malloc+0x14e>
 24e:	e4bff0ef          	jal	98 <ls>
    exit(0);
 252:	4501                	li	a0,0
 254:	290000ef          	jal	4e4 <exit>

0000000000000258 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 258:	1141                	addi	sp,sp,-16
 25a:	e406                	sd	ra,8(sp)
 25c:	e022                	sd	s0,0(sp)
 25e:	0800                	addi	s0,sp,16
  extern int main();
  main();
 260:	fabff0ef          	jal	20a <main>
  exit(0);
 264:	4501                	li	a0,0
 266:	27e000ef          	jal	4e4 <exit>

000000000000026a <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 26a:	1141                	addi	sp,sp,-16
 26c:	e406                	sd	ra,8(sp)
 26e:	e022                	sd	s0,0(sp)
 270:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 272:	87aa                	mv	a5,a0
 274:	0585                	addi	a1,a1,1
 276:	0785                	addi	a5,a5,1
 278:	fff5c703          	lbu	a4,-1(a1)
 27c:	fee78fa3          	sb	a4,-1(a5)
 280:	fb75                	bnez	a4,274 <strcpy+0xa>
    ;
  return os;
}
 282:	60a2                	ld	ra,8(sp)
 284:	6402                	ld	s0,0(sp)
 286:	0141                	addi	sp,sp,16
 288:	8082                	ret

000000000000028a <strcmp>:

int
strcmp(const char *p, const char *q)
{
 28a:	1141                	addi	sp,sp,-16
 28c:	e406                	sd	ra,8(sp)
 28e:	e022                	sd	s0,0(sp)
 290:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 292:	00054783          	lbu	a5,0(a0)
 296:	cb91                	beqz	a5,2aa <strcmp+0x20>
 298:	0005c703          	lbu	a4,0(a1)
 29c:	00f71763          	bne	a4,a5,2aa <strcmp+0x20>
    p++, q++;
 2a0:	0505                	addi	a0,a0,1
 2a2:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 2a4:	00054783          	lbu	a5,0(a0)
 2a8:	fbe5                	bnez	a5,298 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 2aa:	0005c503          	lbu	a0,0(a1)
}
 2ae:	40a7853b          	subw	a0,a5,a0
 2b2:	60a2                	ld	ra,8(sp)
 2b4:	6402                	ld	s0,0(sp)
 2b6:	0141                	addi	sp,sp,16
 2b8:	8082                	ret

00000000000002ba <strlen>:

uint
strlen(const char *s)
{
 2ba:	1141                	addi	sp,sp,-16
 2bc:	e406                	sd	ra,8(sp)
 2be:	e022                	sd	s0,0(sp)
 2c0:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 2c2:	00054783          	lbu	a5,0(a0)
 2c6:	cf91                	beqz	a5,2e2 <strlen+0x28>
 2c8:	00150793          	addi	a5,a0,1
 2cc:	86be                	mv	a3,a5
 2ce:	0785                	addi	a5,a5,1
 2d0:	fff7c703          	lbu	a4,-1(a5)
 2d4:	ff65                	bnez	a4,2cc <strlen+0x12>
 2d6:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 2da:	60a2                	ld	ra,8(sp)
 2dc:	6402                	ld	s0,0(sp)
 2de:	0141                	addi	sp,sp,16
 2e0:	8082                	ret
  for(n = 0; s[n]; n++)
 2e2:	4501                	li	a0,0
 2e4:	bfdd                	j	2da <strlen+0x20>

00000000000002e6 <memset>:

void*
memset(void *dst, int c, uint n)
{
 2e6:	1141                	addi	sp,sp,-16
 2e8:	e406                	sd	ra,8(sp)
 2ea:	e022                	sd	s0,0(sp)
 2ec:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 2ee:	ca19                	beqz	a2,304 <memset+0x1e>
 2f0:	87aa                	mv	a5,a0
 2f2:	1602                	slli	a2,a2,0x20
 2f4:	9201                	srli	a2,a2,0x20
 2f6:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 2fa:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 2fe:	0785                	addi	a5,a5,1
 300:	fee79de3          	bne	a5,a4,2fa <memset+0x14>
  }
  return dst;
}
 304:	60a2                	ld	ra,8(sp)
 306:	6402                	ld	s0,0(sp)
 308:	0141                	addi	sp,sp,16
 30a:	8082                	ret

000000000000030c <strchr>:

char*
strchr(const char *s, char c)
{
 30c:	1141                	addi	sp,sp,-16
 30e:	e406                	sd	ra,8(sp)
 310:	e022                	sd	s0,0(sp)
 312:	0800                	addi	s0,sp,16
  for(; *s; s++)
 314:	00054783          	lbu	a5,0(a0)
 318:	c799                	beqz	a5,326 <strchr+0x1a>
    if(*s == c)
 31a:	00f58763          	beq	a1,a5,328 <strchr+0x1c>
  for(; *s; s++)
 31e:	0505                	addi	a0,a0,1
 320:	00054783          	lbu	a5,0(a0)
 324:	fbfd                	bnez	a5,31a <strchr+0xe>
      return (char*)s;
  return 0;
 326:	4501                	li	a0,0
}
 328:	60a2                	ld	ra,8(sp)
 32a:	6402                	ld	s0,0(sp)
 32c:	0141                	addi	sp,sp,16
 32e:	8082                	ret

0000000000000330 <gets>:

char*
gets(char *buf, int max)
{
 330:	711d                	addi	sp,sp,-96
 332:	ec86                	sd	ra,88(sp)
 334:	e8a2                	sd	s0,80(sp)
 336:	e4a6                	sd	s1,72(sp)
 338:	e0ca                	sd	s2,64(sp)
 33a:	fc4e                	sd	s3,56(sp)
 33c:	f852                	sd	s4,48(sp)
 33e:	f456                	sd	s5,40(sp)
 340:	f05a                	sd	s6,32(sp)
 342:	ec5e                	sd	s7,24(sp)
 344:	e862                	sd	s8,16(sp)
 346:	1080                	addi	s0,sp,96
 348:	8baa                	mv	s7,a0
 34a:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 34c:	892a                	mv	s2,a0
 34e:	4481                	li	s1,0
    cc = read(0, &c, 1);
 350:	faf40b13          	addi	s6,s0,-81
 354:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 356:	8c26                	mv	s8,s1
 358:	0014899b          	addiw	s3,s1,1
 35c:	84ce                	mv	s1,s3
 35e:	0349d863          	bge	s3,s4,38e <gets+0x5e>
    cc = read(0, &c, 1);
 362:	8656                	mv	a2,s5
 364:	85da                	mv	a1,s6
 366:	4501                	li	a0,0
 368:	194000ef          	jal	4fc <read>
    if(cc < 1)
 36c:	02a05163          	blez	a0,38e <gets+0x5e>
      break;
    buf[i++] = c;
 370:	faf44783          	lbu	a5,-81(s0)
 374:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 378:	0905                	addi	s2,s2,1
 37a:	ff678713          	addi	a4,a5,-10
 37e:	00173713          	seqz	a4,a4
 382:	17cd                	addi	a5,a5,-13
 384:	0017b793          	seqz	a5,a5
 388:	8fd9                	or	a5,a5,a4
 38a:	d7f1                	beqz	a5,356 <gets+0x26>
    buf[i++] = c;
 38c:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 38e:	9c5e                	add	s8,s8,s7
 390:	000c0023          	sb	zero,0(s8)
  return buf;
}
 394:	855e                	mv	a0,s7
 396:	60e6                	ld	ra,88(sp)
 398:	6446                	ld	s0,80(sp)
 39a:	64a6                	ld	s1,72(sp)
 39c:	6906                	ld	s2,64(sp)
 39e:	79e2                	ld	s3,56(sp)
 3a0:	7a42                	ld	s4,48(sp)
 3a2:	7aa2                	ld	s5,40(sp)
 3a4:	7b02                	ld	s6,32(sp)
 3a6:	6be2                	ld	s7,24(sp)
 3a8:	6c42                	ld	s8,16(sp)
 3aa:	6125                	addi	sp,sp,96
 3ac:	8082                	ret

00000000000003ae <stat>:

int
stat(const char *n, struct stat *st)
{
 3ae:	1101                	addi	sp,sp,-32
 3b0:	ec06                	sd	ra,24(sp)
 3b2:	e822                	sd	s0,16(sp)
 3b4:	e04a                	sd	s2,0(sp)
 3b6:	1000                	addi	s0,sp,32
 3b8:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 3ba:	4581                	li	a1,0
 3bc:	168000ef          	jal	524 <open>
  if(fd < 0)
 3c0:	02054263          	bltz	a0,3e4 <stat+0x36>
 3c4:	e426                	sd	s1,8(sp)
 3c6:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 3c8:	85ca                	mv	a1,s2
 3ca:	172000ef          	jal	53c <fstat>
 3ce:	892a                	mv	s2,a0
  close(fd);
 3d0:	8526                	mv	a0,s1
 3d2:	13a000ef          	jal	50c <close>
  return r;
 3d6:	64a2                	ld	s1,8(sp)
}
 3d8:	854a                	mv	a0,s2
 3da:	60e2                	ld	ra,24(sp)
 3dc:	6442                	ld	s0,16(sp)
 3de:	6902                	ld	s2,0(sp)
 3e0:	6105                	addi	sp,sp,32
 3e2:	8082                	ret
    return -1;
 3e4:	57fd                	li	a5,-1
 3e6:	893e                	mv	s2,a5
 3e8:	bfc5                	j	3d8 <stat+0x2a>

00000000000003ea <atoi>:

int
atoi(const char *s)
{
 3ea:	1141                	addi	sp,sp,-16
 3ec:	e406                	sd	ra,8(sp)
 3ee:	e022                	sd	s0,0(sp)
 3f0:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 3f2:	00054683          	lbu	a3,0(a0)
 3f6:	fd06879b          	addiw	a5,a3,-48
 3fa:	0ff7f793          	zext.b	a5,a5
 3fe:	4625                	li	a2,9
 400:	02f66963          	bltu	a2,a5,432 <atoi+0x48>
 404:	872a                	mv	a4,a0
  n = 0;
 406:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 408:	0705                	addi	a4,a4,1
 40a:	0025179b          	slliw	a5,a0,0x2
 40e:	9fa9                	addw	a5,a5,a0
 410:	0017979b          	slliw	a5,a5,0x1
 414:	9fb5                	addw	a5,a5,a3
 416:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 41a:	00074683          	lbu	a3,0(a4)
 41e:	fd06879b          	addiw	a5,a3,-48
 422:	0ff7f793          	zext.b	a5,a5
 426:	fef671e3          	bgeu	a2,a5,408 <atoi+0x1e>
  return n;
}
 42a:	60a2                	ld	ra,8(sp)
 42c:	6402                	ld	s0,0(sp)
 42e:	0141                	addi	sp,sp,16
 430:	8082                	ret
  n = 0;
 432:	4501                	li	a0,0
 434:	bfdd                	j	42a <atoi+0x40>

0000000000000436 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 436:	1141                	addi	sp,sp,-16
 438:	e406                	sd	ra,8(sp)
 43a:	e022                	sd	s0,0(sp)
 43c:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 43e:	02b57563          	bgeu	a0,a1,468 <memmove+0x32>
    while(n-- > 0)
 442:	00c05f63          	blez	a2,460 <memmove+0x2a>
 446:	1602                	slli	a2,a2,0x20
 448:	9201                	srli	a2,a2,0x20
 44a:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 44e:	872a                	mv	a4,a0
      *dst++ = *src++;
 450:	0585                	addi	a1,a1,1
 452:	0705                	addi	a4,a4,1
 454:	fff5c683          	lbu	a3,-1(a1)
 458:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 45c:	fee79ae3          	bne	a5,a4,450 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 460:	60a2                	ld	ra,8(sp)
 462:	6402                	ld	s0,0(sp)
 464:	0141                	addi	sp,sp,16
 466:	8082                	ret
    while(n-- > 0)
 468:	fec05ce3          	blez	a2,460 <memmove+0x2a>
    dst += n;
 46c:	00c50733          	add	a4,a0,a2
    src += n;
 470:	95b2                	add	a1,a1,a2
 472:	fff6079b          	addiw	a5,a2,-1
 476:	1782                	slli	a5,a5,0x20
 478:	9381                	srli	a5,a5,0x20
 47a:	fff7c793          	not	a5,a5
 47e:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 480:	15fd                	addi	a1,a1,-1
 482:	177d                	addi	a4,a4,-1
 484:	0005c683          	lbu	a3,0(a1)
 488:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 48c:	fef71ae3          	bne	a4,a5,480 <memmove+0x4a>
 490:	bfc1                	j	460 <memmove+0x2a>

0000000000000492 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 492:	1141                	addi	sp,sp,-16
 494:	e406                	sd	ra,8(sp)
 496:	e022                	sd	s0,0(sp)
 498:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 49a:	ce19                	beqz	a2,4b8 <memcmp+0x26>
 49c:	1602                	slli	a2,a2,0x20
 49e:	9201                	srli	a2,a2,0x20
 4a0:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 4a4:	00054783          	lbu	a5,0(a0)
 4a8:	0005c703          	lbu	a4,0(a1)
 4ac:	00e79b63          	bne	a5,a4,4c2 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 4b0:	0505                	addi	a0,a0,1
    p2++;
 4b2:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 4b4:	fed518e3          	bne	a0,a3,4a4 <memcmp+0x12>
  }
  return 0;
 4b8:	4501                	li	a0,0
}
 4ba:	60a2                	ld	ra,8(sp)
 4bc:	6402                	ld	s0,0(sp)
 4be:	0141                	addi	sp,sp,16
 4c0:	8082                	ret
      return *p1 - *p2;
 4c2:	40e7853b          	subw	a0,a5,a4
 4c6:	bfd5                	j	4ba <memcmp+0x28>

00000000000004c8 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 4c8:	1141                	addi	sp,sp,-16
 4ca:	e406                	sd	ra,8(sp)
 4cc:	e022                	sd	s0,0(sp)
 4ce:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 4d0:	f67ff0ef          	jal	436 <memmove>
}
 4d4:	60a2                	ld	ra,8(sp)
 4d6:	6402                	ld	s0,0(sp)
 4d8:	0141                	addi	sp,sp,16
 4da:	8082                	ret

00000000000004dc <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 4dc:	4885                	li	a7,1
 ecall
 4de:	00000073          	ecall
 ret
 4e2:	8082                	ret

00000000000004e4 <exit>:
.global exit
exit:
 li a7, SYS_exit
 4e4:	4889                	li	a7,2
 ecall
 4e6:	00000073          	ecall
 ret
 4ea:	8082                	ret

00000000000004ec <wait>:
.global wait
wait:
 li a7, SYS_wait
 4ec:	488d                	li	a7,3
 ecall
 4ee:	00000073          	ecall
 ret
 4f2:	8082                	ret

00000000000004f4 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 4f4:	4891                	li	a7,4
 ecall
 4f6:	00000073          	ecall
 ret
 4fa:	8082                	ret

00000000000004fc <read>:
.global read
read:
 li a7, SYS_read
 4fc:	4895                	li	a7,5
 ecall
 4fe:	00000073          	ecall
 ret
 502:	8082                	ret

0000000000000504 <write>:
.global write
write:
 li a7, SYS_write
 504:	48c1                	li	a7,16
 ecall
 506:	00000073          	ecall
 ret
 50a:	8082                	ret

000000000000050c <close>:
.global close
close:
 li a7, SYS_close
 50c:	48d5                	li	a7,21
 ecall
 50e:	00000073          	ecall
 ret
 512:	8082                	ret

0000000000000514 <kill>:
.global kill
kill:
 li a7, SYS_kill
 514:	4899                	li	a7,6
 ecall
 516:	00000073          	ecall
 ret
 51a:	8082                	ret

000000000000051c <exec>:
.global exec
exec:
 li a7, SYS_exec
 51c:	489d                	li	a7,7
 ecall
 51e:	00000073          	ecall
 ret
 522:	8082                	ret

0000000000000524 <open>:
.global open
open:
 li a7, SYS_open
 524:	48bd                	li	a7,15
 ecall
 526:	00000073          	ecall
 ret
 52a:	8082                	ret

000000000000052c <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 52c:	48c5                	li	a7,17
 ecall
 52e:	00000073          	ecall
 ret
 532:	8082                	ret

0000000000000534 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 534:	48c9                	li	a7,18
 ecall
 536:	00000073          	ecall
 ret
 53a:	8082                	ret

000000000000053c <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 53c:	48a1                	li	a7,8
 ecall
 53e:	00000073          	ecall
 ret
 542:	8082                	ret

0000000000000544 <link>:
.global link
link:
 li a7, SYS_link
 544:	48cd                	li	a7,19
 ecall
 546:	00000073          	ecall
 ret
 54a:	8082                	ret

000000000000054c <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 54c:	48d1                	li	a7,20
 ecall
 54e:	00000073          	ecall
 ret
 552:	8082                	ret

0000000000000554 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 554:	48a5                	li	a7,9
 ecall
 556:	00000073          	ecall
 ret
 55a:	8082                	ret

000000000000055c <dup>:
.global dup
dup:
 li a7, SYS_dup
 55c:	48a9                	li	a7,10
 ecall
 55e:	00000073          	ecall
 ret
 562:	8082                	ret

0000000000000564 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 564:	48ad                	li	a7,11
 ecall
 566:	00000073          	ecall
 ret
 56a:	8082                	ret

000000000000056c <getproccount>:
.global getproccount
getproccount:
 li a7, SYS_getproccount
 56c:	48d9                	li	a7,22
 ecall
 56e:	00000073          	ecall
 ret
 572:	8082                	ret

0000000000000574 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 574:	48b1                	li	a7,12
 ecall
 576:	00000073          	ecall
 ret
 57a:	8082                	ret

000000000000057c <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 57c:	48b5                	li	a7,13
 ecall
 57e:	00000073          	ecall
 ret
 582:	8082                	ret

0000000000000584 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 584:	48b9                	li	a7,14
 ecall
 586:	00000073          	ecall
 ret
 58a:	8082                	ret

000000000000058c <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 58c:	1101                	addi	sp,sp,-32
 58e:	ec06                	sd	ra,24(sp)
 590:	e822                	sd	s0,16(sp)
 592:	1000                	addi	s0,sp,32
 594:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 598:	4605                	li	a2,1
 59a:	fef40593          	addi	a1,s0,-17
 59e:	f67ff0ef          	jal	504 <write>
}
 5a2:	60e2                	ld	ra,24(sp)
 5a4:	6442                	ld	s0,16(sp)
 5a6:	6105                	addi	sp,sp,32
 5a8:	8082                	ret

00000000000005aa <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 5aa:	715d                	addi	sp,sp,-80
 5ac:	e486                	sd	ra,72(sp)
 5ae:	e0a2                	sd	s0,64(sp)
 5b0:	f84a                	sd	s2,48(sp)
 5b2:	f44e                	sd	s3,40(sp)
 5b4:	0880                	addi	s0,sp,80
 5b6:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 5b8:	00d036b3          	snez	a3,a3
 5bc:	03f5d793          	srli	a5,a1,0x3f
 5c0:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 5c2:	0005871b          	sext.w	a4,a1
  neg = 0;
 5c6:	4301                	li	t1,0
  if(sgn && xx < 0){
 5c8:	c681                	beqz	a3,5d0 <printint+0x26>
    x = -xx;
 5ca:	40b0073b          	negw	a4,a1
    neg = 1;
 5ce:	4305                	li	t1,1
  }

  i = 0;
 5d0:	fb840993          	addi	s3,s0,-72
  neg = 0;
 5d4:	85ce                	mv	a1,s3
  i = 0;
 5d6:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 5d8:	00000817          	auipc	a6,0x0
 5dc:	57080813          	addi	a6,a6,1392 # b48 <digits>
 5e0:	88b6                	mv	a7,a3
 5e2:	0016851b          	addiw	a0,a3,1
 5e6:	86aa                	mv	a3,a0
 5e8:	02c777bb          	remuw	a5,a4,a2
 5ec:	1782                	slli	a5,a5,0x20
 5ee:	9381                	srli	a5,a5,0x20
 5f0:	97c2                	add	a5,a5,a6
 5f2:	0007c783          	lbu	a5,0(a5)
 5f6:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 5fa:	87ba                	mv	a5,a4
 5fc:	02c7573b          	divuw	a4,a4,a2
 600:	0585                	addi	a1,a1,1
 602:	fcc7ffe3          	bgeu	a5,a2,5e0 <printint+0x36>
  if(neg)
 606:	00030b63          	beqz	t1,61c <printint+0x72>
    buf[i++] = '-';
 60a:	fd040793          	addi	a5,s0,-48
 60e:	953e                	add	a0,a0,a5
 610:	02d00793          	li	a5,45
 614:	fef50423          	sb	a5,-24(a0)
 618:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 61c:	02d05563          	blez	a3,646 <printint+0x9c>
 620:	fc26                	sd	s1,56(sp)
 622:	36fd                	addiw	a3,a3,-1
 624:	00d984b3          	add	s1,s3,a3
 628:	19fd                	addi	s3,s3,-1
 62a:	99b6                	add	s3,s3,a3
 62c:	1682                	slli	a3,a3,0x20
 62e:	9281                	srli	a3,a3,0x20
 630:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 634:	0004c583          	lbu	a1,0(s1)
 638:	854a                	mv	a0,s2
 63a:	f53ff0ef          	jal	58c <putc>
  while(--i >= 0)
 63e:	14fd                	addi	s1,s1,-1
 640:	ff349ae3          	bne	s1,s3,634 <printint+0x8a>
 644:	74e2                	ld	s1,56(sp)
}
 646:	60a6                	ld	ra,72(sp)
 648:	6406                	ld	s0,64(sp)
 64a:	7942                	ld	s2,48(sp)
 64c:	79a2                	ld	s3,40(sp)
 64e:	6161                	addi	sp,sp,80
 650:	8082                	ret

0000000000000652 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 652:	711d                	addi	sp,sp,-96
 654:	ec86                	sd	ra,88(sp)
 656:	e8a2                	sd	s0,80(sp)
 658:	e4a6                	sd	s1,72(sp)
 65a:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 65c:	0005c483          	lbu	s1,0(a1)
 660:	28048263          	beqz	s1,8e4 <vprintf+0x292>
 664:	e0ca                	sd	s2,64(sp)
 666:	fc4e                	sd	s3,56(sp)
 668:	f852                	sd	s4,48(sp)
 66a:	f456                	sd	s5,40(sp)
 66c:	f05a                	sd	s6,32(sp)
 66e:	ec5e                	sd	s7,24(sp)
 670:	e862                	sd	s8,16(sp)
 672:	8b2a                	mv	s6,a0
 674:	8a2e                	mv	s4,a1
 676:	8bb2                	mv	s7,a2
  state = 0;
 678:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 67a:	4901                	li	s2,0
 67c:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 67e:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 682:	06400c13          	li	s8,100
 686:	a00d                	j	6a8 <vprintf+0x56>
        putc(fd, c0);
 688:	85a6                	mv	a1,s1
 68a:	855a                	mv	a0,s6
 68c:	f01ff0ef          	jal	58c <putc>
 690:	a019                	j	696 <vprintf+0x44>
    } else if(state == '%'){
 692:	03598363          	beq	s3,s5,6b8 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 696:	0019079b          	addiw	a5,s2,1
 69a:	893e                	mv	s2,a5
 69c:	873e                	mv	a4,a5
 69e:	97d2                	add	a5,a5,s4
 6a0:	0007c483          	lbu	s1,0(a5)
 6a4:	22048963          	beqz	s1,8d6 <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 6a8:	0004879b          	sext.w	a5,s1
    if(state == 0){
 6ac:	fe0993e3          	bnez	s3,692 <vprintf+0x40>
      if(c0 == '%'){
 6b0:	fd579ce3          	bne	a5,s5,688 <vprintf+0x36>
        state = '%';
 6b4:	89be                	mv	s3,a5
 6b6:	b7c5                	j	696 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 6b8:	00ea06b3          	add	a3,s4,a4
 6bc:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 6c0:	22060763          	beqz	a2,8ee <vprintf+0x29c>
      if(c0 == 'd'){
 6c4:	0b878363          	beq	a5,s8,76a <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 6c8:	f9478693          	addi	a3,a5,-108
 6cc:	0016b693          	seqz	a3,a3
 6d0:	f9c60593          	addi	a1,a2,-100
 6d4:	0015b593          	seqz	a1,a1
 6d8:	8df5                	and	a1,a1,a3
 6da:	e5c5                	bnez	a1,782 <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 6dc:	9752                	add	a4,a4,s4
 6de:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 6e2:	f9460713          	addi	a4,a2,-108
 6e6:	00173713          	seqz	a4,a4
 6ea:	8f75                	and	a4,a4,a3
 6ec:	f9c50593          	addi	a1,a0,-100
 6f0:	0015b593          	seqz	a1,a1
 6f4:	8df9                	and	a1,a1,a4
 6f6:	e1dd                	bnez	a1,79c <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 6f8:	07500593          	li	a1,117
 6fc:	0ab78d63          	beq	a5,a1,7b6 <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 700:	f8b60593          	addi	a1,a2,-117
 704:	0015b593          	seqz	a1,a1
 708:	8df5                	and	a1,a1,a3
 70a:	e1f1                	bnez	a1,7ce <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 70c:	f8b50593          	addi	a1,a0,-117
 710:	0015b593          	seqz	a1,a1
 714:	8df9                	and	a1,a1,a4
 716:	e9e9                	bnez	a1,7e8 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 718:	07800593          	li	a1,120
 71c:	0eb78363          	beq	a5,a1,802 <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 720:	f8860613          	addi	a2,a2,-120
 724:	00163613          	seqz	a2,a2
 728:	8ef1                	and	a3,a3,a2
 72a:	0e069863          	bnez	a3,81a <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 72e:	f8850513          	addi	a0,a0,-120
 732:	00153513          	seqz	a0,a0
 736:	8f69                	and	a4,a4,a0
 738:	0e071e63          	bnez	a4,834 <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 73c:	07000713          	li	a4,112
 740:	10e78663          	beq	a5,a4,84c <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 744:	07300713          	li	a4,115
 748:	14e78663          	beq	a5,a4,894 <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 74c:	02500713          	li	a4,37
 750:	16e78e63          	beq	a5,a4,8cc <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 754:	02500593          	li	a1,37
 758:	855a                	mv	a0,s6
 75a:	e33ff0ef          	jal	58c <putc>
        putc(fd, c0);
 75e:	85a6                	mv	a1,s1
 760:	855a                	mv	a0,s6
 762:	e2bff0ef          	jal	58c <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 766:	4981                	li	s3,0
 768:	b73d                	j	696 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 76a:	008b8493          	addi	s1,s7,8
 76e:	4685                	li	a3,1
 770:	4629                	li	a2,10
 772:	000ba583          	lw	a1,0(s7)
 776:	855a                	mv	a0,s6
 778:	e33ff0ef          	jal	5aa <printint>
 77c:	8ba6                	mv	s7,s1
      state = 0;
 77e:	4981                	li	s3,0
 780:	bf19                	j	696 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 782:	008b8493          	addi	s1,s7,8
 786:	4685                	li	a3,1
 788:	4629                	li	a2,10
 78a:	000bb583          	ld	a1,0(s7)
 78e:	855a                	mv	a0,s6
 790:	e1bff0ef          	jal	5aa <printint>
        i += 1;
 794:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 796:	8ba6                	mv	s7,s1
      state = 0;
 798:	4981                	li	s3,0
 79a:	bdf5                	j	696 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 79c:	008b8493          	addi	s1,s7,8
 7a0:	4685                	li	a3,1
 7a2:	4629                	li	a2,10
 7a4:	000bb583          	ld	a1,0(s7)
 7a8:	855a                	mv	a0,s6
 7aa:	e01ff0ef          	jal	5aa <printint>
        i += 2;
 7ae:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 7b0:	8ba6                	mv	s7,s1
      state = 0;
 7b2:	4981                	li	s3,0
        i += 2;
 7b4:	b5cd                	j	696 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 7b6:	008b8493          	addi	s1,s7,8
 7ba:	4681                	li	a3,0
 7bc:	4629                	li	a2,10
 7be:	000ba583          	lw	a1,0(s7)
 7c2:	855a                	mv	a0,s6
 7c4:	de7ff0ef          	jal	5aa <printint>
 7c8:	8ba6                	mv	s7,s1
      state = 0;
 7ca:	4981                	li	s3,0
 7cc:	b5e9                	j	696 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7ce:	008b8493          	addi	s1,s7,8
 7d2:	4681                	li	a3,0
 7d4:	4629                	li	a2,10
 7d6:	000bb583          	ld	a1,0(s7)
 7da:	855a                	mv	a0,s6
 7dc:	dcfff0ef          	jal	5aa <printint>
        i += 1;
 7e0:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 7e2:	8ba6                	mv	s7,s1
      state = 0;
 7e4:	4981                	li	s3,0
 7e6:	bd45                	j	696 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7e8:	008b8493          	addi	s1,s7,8
 7ec:	4681                	li	a3,0
 7ee:	4629                	li	a2,10
 7f0:	000bb583          	ld	a1,0(s7)
 7f4:	855a                	mv	a0,s6
 7f6:	db5ff0ef          	jal	5aa <printint>
        i += 2;
 7fa:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 7fc:	8ba6                	mv	s7,s1
      state = 0;
 7fe:	4981                	li	s3,0
        i += 2;
 800:	bd59                	j	696 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 802:	008b8493          	addi	s1,s7,8
 806:	4681                	li	a3,0
 808:	4641                	li	a2,16
 80a:	000ba583          	lw	a1,0(s7)
 80e:	855a                	mv	a0,s6
 810:	d9bff0ef          	jal	5aa <printint>
 814:	8ba6                	mv	s7,s1
      state = 0;
 816:	4981                	li	s3,0
 818:	bdbd                	j	696 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 81a:	008b8493          	addi	s1,s7,8
 81e:	4681                	li	a3,0
 820:	4641                	li	a2,16
 822:	000bb583          	ld	a1,0(s7)
 826:	855a                	mv	a0,s6
 828:	d83ff0ef          	jal	5aa <printint>
        i += 1;
 82c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 82e:	8ba6                	mv	s7,s1
      state = 0;
 830:	4981                	li	s3,0
 832:	b595                	j	696 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 834:	008b8493          	addi	s1,s7,8
 838:	4641                	li	a2,16
 83a:	000bb583          	ld	a1,0(s7)
 83e:	855a                	mv	a0,s6
 840:	d6bff0ef          	jal	5aa <printint>
        i += 2;
 844:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 846:	8ba6                	mv	s7,s1
      state = 0;
 848:	4981                	li	s3,0
        i += 2;
 84a:	b5b1                	j	696 <vprintf+0x44>
 84c:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 84e:	008b8793          	addi	a5,s7,8
 852:	8cbe                	mv	s9,a5
 854:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 858:	03000593          	li	a1,48
 85c:	855a                	mv	a0,s6
 85e:	d2fff0ef          	jal	58c <putc>
  putc(fd, 'x');
 862:	07800593          	li	a1,120
 866:	855a                	mv	a0,s6
 868:	d25ff0ef          	jal	58c <putc>
 86c:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 86e:	00000b97          	auipc	s7,0x0
 872:	2dab8b93          	addi	s7,s7,730 # b48 <digits>
 876:	03c9d793          	srli	a5,s3,0x3c
 87a:	97de                	add	a5,a5,s7
 87c:	0007c583          	lbu	a1,0(a5)
 880:	855a                	mv	a0,s6
 882:	d0bff0ef          	jal	58c <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 886:	0992                	slli	s3,s3,0x4
 888:	34fd                	addiw	s1,s1,-1
 88a:	f4f5                	bnez	s1,876 <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 88c:	8be6                	mv	s7,s9
      state = 0;
 88e:	4981                	li	s3,0
 890:	6ca2                	ld	s9,8(sp)
 892:	b511                	j	696 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 894:	008b8993          	addi	s3,s7,8
 898:	000bb483          	ld	s1,0(s7)
 89c:	cc91                	beqz	s1,8b8 <vprintf+0x266>
        for(; *s; s++)
 89e:	0004c583          	lbu	a1,0(s1)
 8a2:	c195                	beqz	a1,8c6 <vprintf+0x274>
          putc(fd, *s);
 8a4:	855a                	mv	a0,s6
 8a6:	ce7ff0ef          	jal	58c <putc>
        for(; *s; s++)
 8aa:	0485                	addi	s1,s1,1
 8ac:	0004c583          	lbu	a1,0(s1)
 8b0:	f9f5                	bnez	a1,8a4 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 8b2:	8bce                	mv	s7,s3
      state = 0;
 8b4:	4981                	li	s3,0
 8b6:	b3c5                	j	696 <vprintf+0x44>
          s = "(null)";
 8b8:	00000497          	auipc	s1,0x0
 8bc:	28848493          	addi	s1,s1,648 # b40 <malloc+0x156>
        for(; *s; s++)
 8c0:	02800593          	li	a1,40
 8c4:	b7c5                	j	8a4 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 8c6:	8bce                	mv	s7,s3
      state = 0;
 8c8:	4981                	li	s3,0
 8ca:	b3f1                	j	696 <vprintf+0x44>
        putc(fd, '%');
 8cc:	85be                	mv	a1,a5
 8ce:	855a                	mv	a0,s6
 8d0:	cbdff0ef          	jal	58c <putc>
 8d4:	bd49                	j	766 <vprintf+0x114>
 8d6:	6906                	ld	s2,64(sp)
 8d8:	79e2                	ld	s3,56(sp)
 8da:	7a42                	ld	s4,48(sp)
 8dc:	7aa2                	ld	s5,40(sp)
 8de:	7b02                	ld	s6,32(sp)
 8e0:	6be2                	ld	s7,24(sp)
 8e2:	6c42                	ld	s8,16(sp)
    }
  }
}
 8e4:	60e6                	ld	ra,88(sp)
 8e6:	6446                	ld	s0,80(sp)
 8e8:	64a6                	ld	s1,72(sp)
 8ea:	6125                	addi	sp,sp,96
 8ec:	8082                	ret
      if(c0 == 'd'){
 8ee:	06400713          	li	a4,100
 8f2:	e6e78ce3          	beq	a5,a4,76a <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 8f6:	f9478693          	addi	a3,a5,-108
 8fa:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 8fe:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 900:	4701                	li	a4,0
 902:	bbdd                	j	6f8 <vprintf+0xa6>

0000000000000904 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 904:	715d                	addi	sp,sp,-80
 906:	ec06                	sd	ra,24(sp)
 908:	e822                	sd	s0,16(sp)
 90a:	1000                	addi	s0,sp,32
 90c:	e010                	sd	a2,0(s0)
 90e:	e414                	sd	a3,8(s0)
 910:	e818                	sd	a4,16(s0)
 912:	ec1c                	sd	a5,24(s0)
 914:	03043023          	sd	a6,32(s0)
 918:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 91c:	8622                	mv	a2,s0
 91e:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 922:	d31ff0ef          	jal	652 <vprintf>
}
 926:	60e2                	ld	ra,24(sp)
 928:	6442                	ld	s0,16(sp)
 92a:	6161                	addi	sp,sp,80
 92c:	8082                	ret

000000000000092e <printf>:

void
printf(const char *fmt, ...)
{
 92e:	711d                	addi	sp,sp,-96
 930:	ec06                	sd	ra,24(sp)
 932:	e822                	sd	s0,16(sp)
 934:	1000                	addi	s0,sp,32
 936:	e40c                	sd	a1,8(s0)
 938:	e810                	sd	a2,16(s0)
 93a:	ec14                	sd	a3,24(s0)
 93c:	f018                	sd	a4,32(s0)
 93e:	f41c                	sd	a5,40(s0)
 940:	03043823          	sd	a6,48(s0)
 944:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 948:	00840613          	addi	a2,s0,8
 94c:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 950:	85aa                	mv	a1,a0
 952:	4505                	li	a0,1
 954:	cffff0ef          	jal	652 <vprintf>
}
 958:	60e2                	ld	ra,24(sp)
 95a:	6442                	ld	s0,16(sp)
 95c:	6125                	addi	sp,sp,96
 95e:	8082                	ret

0000000000000960 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 960:	1141                	addi	sp,sp,-16
 962:	e406                	sd	ra,8(sp)
 964:	e022                	sd	s0,0(sp)
 966:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 968:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 96c:	00000797          	auipc	a5,0x0
 970:	6947b783          	ld	a5,1684(a5) # 1000 <freep>
 974:	a095                	j	9d8 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 976:	ff852583          	lw	a1,-8(a0)
 97a:	6390                	ld	a2,0(a5)
 97c:	02059813          	slli	a6,a1,0x20
 980:	01c85693          	srli	a3,a6,0x1c
 984:	96ba                	add	a3,a3,a4
 986:	02d60563          	beq	a2,a3,9b0 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 98a:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 98e:	4790                	lw	a2,8(a5)
 990:	02061593          	slli	a1,a2,0x20
 994:	01c5d693          	srli	a3,a1,0x1c
 998:	96be                	add	a3,a3,a5
 99a:	02d70263          	beq	a4,a3,9be <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 99e:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 9a0:	00000717          	auipc	a4,0x0
 9a4:	66f73023          	sd	a5,1632(a4) # 1000 <freep>
}
 9a8:	60a2                	ld	ra,8(sp)
 9aa:	6402                	ld	s0,0(sp)
 9ac:	0141                	addi	sp,sp,16
 9ae:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 9b0:	4614                	lw	a3,8(a2)
 9b2:	9ead                	addw	a3,a3,a1
 9b4:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 9b8:	6394                	ld	a3,0(a5)
 9ba:	6290                	ld	a2,0(a3)
 9bc:	b7f9                	j	98a <free+0x2a>
    p->s.size += bp->s.size;
 9be:	ff852703          	lw	a4,-8(a0)
 9c2:	9f31                	addw	a4,a4,a2
 9c4:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 9c6:	ff053703          	ld	a4,-16(a0)
 9ca:	bfd1                	j	99e <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9cc:	6394                	ld	a3,0(a5)
 9ce:	00d7e463          	bltu	a5,a3,9d6 <free+0x76>
 9d2:	fad762e3          	bltu	a4,a3,976 <free+0x16>
 9d6:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9d8:	fee7fae3          	bgeu	a5,a4,9cc <free+0x6c>
 9dc:	6394                	ld	a3,0(a5)
 9de:	f8d76ce3          	bltu	a4,a3,976 <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9e2:	f8d7fae3          	bgeu	a5,a3,976 <free+0x16>
 9e6:	87b6                	mv	a5,a3
 9e8:	bfc5                	j	9d8 <free+0x78>

00000000000009ea <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 9ea:	7139                	addi	sp,sp,-64
 9ec:	fc06                	sd	ra,56(sp)
 9ee:	f822                	sd	s0,48(sp)
 9f0:	f04a                	sd	s2,32(sp)
 9f2:	ec4e                	sd	s3,24(sp)
 9f4:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 9f6:	02051993          	slli	s3,a0,0x20
 9fa:	0209d993          	srli	s3,s3,0x20
 9fe:	09bd                	addi	s3,s3,15
 a00:	0049d993          	srli	s3,s3,0x4
 a04:	2985                	addiw	s3,s3,1
 a06:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 a08:	00000517          	auipc	a0,0x0
 a0c:	5f853503          	ld	a0,1528(a0) # 1000 <freep>
 a10:	c905                	beqz	a0,a40 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a12:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a14:	4798                	lw	a4,8(a5)
 a16:	09377663          	bgeu	a4,s3,aa2 <malloc+0xb8>
 a1a:	f426                	sd	s1,40(sp)
 a1c:	e852                	sd	s4,16(sp)
 a1e:	e456                	sd	s5,8(sp)
 a20:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 a22:	8a4e                	mv	s4,s3
 a24:	6705                	lui	a4,0x1
 a26:	00e9f363          	bgeu	s3,a4,a2c <malloc+0x42>
 a2a:	6a05                	lui	s4,0x1
 a2c:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 a30:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 a34:	00000497          	auipc	s1,0x0
 a38:	5cc48493          	addi	s1,s1,1484 # 1000 <freep>
  if(p == (char*)-1)
 a3c:	5afd                	li	s5,-1
 a3e:	a83d                	j	a7c <malloc+0x92>
 a40:	f426                	sd	s1,40(sp)
 a42:	e852                	sd	s4,16(sp)
 a44:	e456                	sd	s5,8(sp)
 a46:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 a48:	00000797          	auipc	a5,0x0
 a4c:	5d878793          	addi	a5,a5,1496 # 1020 <base>
 a50:	00000717          	auipc	a4,0x0
 a54:	5af73823          	sd	a5,1456(a4) # 1000 <freep>
 a58:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 a5a:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 a5e:	b7d1                	j	a22 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 a60:	6398                	ld	a4,0(a5)
 a62:	e118                	sd	a4,0(a0)
 a64:	a899                	j	aba <malloc+0xd0>
  hp->s.size = nu;
 a66:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 a6a:	0541                	addi	a0,a0,16
 a6c:	ef5ff0ef          	jal	960 <free>
  return freep;
 a70:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 a72:	c125                	beqz	a0,ad2 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a74:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a76:	4798                	lw	a4,8(a5)
 a78:	03277163          	bgeu	a4,s2,a9a <malloc+0xb0>
    if(p == freep)
 a7c:	6098                	ld	a4,0(s1)
 a7e:	853e                	mv	a0,a5
 a80:	fef71ae3          	bne	a4,a5,a74 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 a84:	8552                	mv	a0,s4
 a86:	aefff0ef          	jal	574 <sbrk>
  if(p == (char*)-1)
 a8a:	fd551ee3          	bne	a0,s5,a66 <malloc+0x7c>
        return 0;
 a8e:	4501                	li	a0,0
 a90:	74a2                	ld	s1,40(sp)
 a92:	6a42                	ld	s4,16(sp)
 a94:	6aa2                	ld	s5,8(sp)
 a96:	6b02                	ld	s6,0(sp)
 a98:	a03d                	j	ac6 <malloc+0xdc>
 a9a:	74a2                	ld	s1,40(sp)
 a9c:	6a42                	ld	s4,16(sp)
 a9e:	6aa2                	ld	s5,8(sp)
 aa0:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 aa2:	fae90fe3          	beq	s2,a4,a60 <malloc+0x76>
        p->s.size -= nunits;
 aa6:	4137073b          	subw	a4,a4,s3
 aaa:	c798                	sw	a4,8(a5)
        p += p->s.size;
 aac:	02071693          	slli	a3,a4,0x20
 ab0:	01c6d713          	srli	a4,a3,0x1c
 ab4:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 ab6:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 aba:	00000717          	auipc	a4,0x0
 abe:	54a73323          	sd	a0,1350(a4) # 1000 <freep>
      return (void*)(p + 1);
 ac2:	01078513          	addi	a0,a5,16
  }
}
 ac6:	70e2                	ld	ra,56(sp)
 ac8:	7442                	ld	s0,48(sp)
 aca:	7902                	ld	s2,32(sp)
 acc:	69e2                	ld	s3,24(sp)
 ace:	6121                	addi	sp,sp,64
 ad0:	8082                	ret
 ad2:	74a2                	ld	s1,40(sp)
 ad4:	6a42                	ld	s4,16(sp)
 ad6:	6aa2                	ld	s5,8(sp)
 ad8:	6b02                	ld	s6,0(sp)
 ada:	b7f5                	j	ac6 <malloc+0xdc>
