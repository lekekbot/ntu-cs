
user/_pingpong:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/types.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
   0:	715d                	addi	sp,sp,-80
   2:	e486                	sd	ra,72(sp)
   4:	e0a2                	sd	s0,64(sp)
   6:	0880                	addi	s0,sp,80
  int p[2];
  char buf[5];
  
  pipe(p);
   8:	fb840513          	addi	a0,s0,-72
   c:	348000ef          	jal	354 <pipe>
  if(fork() == 0){
  10:	32c000ef          	jal	33c <fork>
  14:	e921                	bnez	a0,64 <main+0x64>
  16:	fc26                	sd	s1,56(sp)
  18:	f84a                	sd	s2,48(sp)
  1a:	f44e                	sd	s3,40(sp)
  1c:	f052                	sd	s4,32(sp)
  1e:	ec56                	sd	s5,24(sp)
  20:	84aa                	mv	s1,a0
      if ((j % 2) == 0) {
        buf = "ping";
        write(p[1], buf, 4);
      } else {
        buf = "pong";
        write(p[1], buf, 4);
  22:	4911                	li	s2,4
  24:	00001a97          	auipc	s5,0x1
  28:	924a8a93          	addi	s5,s5,-1756 # 948 <malloc+0xfe>
        write(p[1], buf, 4);
  2c:	00001a17          	auipc	s4,0x1
  30:	914a0a13          	addi	s4,s4,-1772 # 940 <malloc+0xf6>
    for (int j=0; j<5; j++) {
  34:	4995                	li	s3,5
  36:	a801                	j	46 <main+0x46>
        write(p[1], buf, 4);
  38:	864a                	mv	a2,s2
  3a:	85d6                	mv	a1,s5
  3c:	fbc42503          	lw	a0,-68(s0)
  40:	324000ef          	jal	364 <write>
    for (int j=0; j<5; j++) {
  44:	2485                	addiw	s1,s1,1
      if ((j % 2) == 0) {
  46:	0014f793          	andi	a5,s1,1
  4a:	f7fd                	bnez	a5,38 <main+0x38>
        write(p[1], buf, 4);
  4c:	864a                	mv	a2,s2
  4e:	85d2                	mv	a1,s4
  50:	fbc42503          	lw	a0,-68(s0)
  54:	310000ef          	jal	364 <write>
    for (int j=0; j<5; j++) {
  58:	2485                	addiw	s1,s1,1
  5a:	ff3496e3          	bne	s1,s3,46 <main+0x46>
      }
    }
    exit(0);
  5e:	4501                	li	a0,0
  60:	2e4000ef          	jal	344 <exit>
  64:	fc26                	sd	s1,56(sp)
  66:	f84a                	sd	s2,48(sp)
  68:	f44e                	sd	s3,40(sp)
  6a:	f052                	sd	s4,32(sp)
  6c:	ec56                	sd	s5,24(sp)
  if(fork() == 0){
  6e:	4495                	li	s1,5
  } else {
    // Parent
    for (int j=0; j<5; j++) {
      read(p[0], buf, 4);
  70:	fb040913          	addi	s2,s0,-80
  74:	4a11                	li	s4,4
      printf("%d: received %s\n", getpid(), buf);
  76:	00001997          	auipc	s3,0x1
  7a:	8da98993          	addi	s3,s3,-1830 # 950 <malloc+0x106>
      read(p[0], buf, 4);
  7e:	8652                	mv	a2,s4
  80:	85ca                	mv	a1,s2
  82:	fb842503          	lw	a0,-72(s0)
  86:	2d6000ef          	jal	35c <read>
      printf("%d: received %s\n", getpid(), buf);
  8a:	33a000ef          	jal	3c4 <getpid>
  8e:	85aa                	mv	a1,a0
  90:	864a                	mv	a2,s2
  92:	854e                	mv	a0,s3
  94:	6fa000ef          	jal	78e <printf>
    for (int j=0; j<5; j++) {
  98:	34fd                	addiw	s1,s1,-1
  9a:	f0f5                	bnez	s1,7e <main+0x7e>
    }

    close(p[0]);
  9c:	fb842503          	lw	a0,-72(s0)
  a0:	2cc000ef          	jal	36c <close>
    close(p[1]);
  a4:	fbc42503          	lw	a0,-68(s0)
  a8:	2c4000ef          	jal	36c <close>
    wait(0);
  ac:	4501                	li	a0,0
  ae:	29e000ef          	jal	34c <wait>
    exit(0);
  b2:	4501                	li	a0,0
  b4:	290000ef          	jal	344 <exit>

00000000000000b8 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  b8:	1141                	addi	sp,sp,-16
  ba:	e406                	sd	ra,8(sp)
  bc:	e022                	sd	s0,0(sp)
  be:	0800                	addi	s0,sp,16
  extern int main();
  main();
  c0:	f41ff0ef          	jal	0 <main>
  exit(0);
  c4:	4501                	li	a0,0
  c6:	27e000ef          	jal	344 <exit>

00000000000000ca <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  ca:	1141                	addi	sp,sp,-16
  cc:	e406                	sd	ra,8(sp)
  ce:	e022                	sd	s0,0(sp)
  d0:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  d2:	87aa                	mv	a5,a0
  d4:	0585                	addi	a1,a1,1
  d6:	0785                	addi	a5,a5,1
  d8:	fff5c703          	lbu	a4,-1(a1)
  dc:	fee78fa3          	sb	a4,-1(a5)
  e0:	fb75                	bnez	a4,d4 <strcpy+0xa>
    ;
  return os;
}
  e2:	60a2                	ld	ra,8(sp)
  e4:	6402                	ld	s0,0(sp)
  e6:	0141                	addi	sp,sp,16
  e8:	8082                	ret

00000000000000ea <strcmp>:

int
strcmp(const char *p, const char *q)
{
  ea:	1141                	addi	sp,sp,-16
  ec:	e406                	sd	ra,8(sp)
  ee:	e022                	sd	s0,0(sp)
  f0:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  f2:	00054783          	lbu	a5,0(a0)
  f6:	cb91                	beqz	a5,10a <strcmp+0x20>
  f8:	0005c703          	lbu	a4,0(a1)
  fc:	00f71763          	bne	a4,a5,10a <strcmp+0x20>
    p++, q++;
 100:	0505                	addi	a0,a0,1
 102:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 104:	00054783          	lbu	a5,0(a0)
 108:	fbe5                	bnez	a5,f8 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 10a:	0005c503          	lbu	a0,0(a1)
}
 10e:	40a7853b          	subw	a0,a5,a0
 112:	60a2                	ld	ra,8(sp)
 114:	6402                	ld	s0,0(sp)
 116:	0141                	addi	sp,sp,16
 118:	8082                	ret

000000000000011a <strlen>:

uint
strlen(const char *s)
{
 11a:	1141                	addi	sp,sp,-16
 11c:	e406                	sd	ra,8(sp)
 11e:	e022                	sd	s0,0(sp)
 120:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 122:	00054783          	lbu	a5,0(a0)
 126:	cf91                	beqz	a5,142 <strlen+0x28>
 128:	00150793          	addi	a5,a0,1
 12c:	86be                	mv	a3,a5
 12e:	0785                	addi	a5,a5,1
 130:	fff7c703          	lbu	a4,-1(a5)
 134:	ff65                	bnez	a4,12c <strlen+0x12>
 136:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 13a:	60a2                	ld	ra,8(sp)
 13c:	6402                	ld	s0,0(sp)
 13e:	0141                	addi	sp,sp,16
 140:	8082                	ret
  for(n = 0; s[n]; n++)
 142:	4501                	li	a0,0
 144:	bfdd                	j	13a <strlen+0x20>

0000000000000146 <memset>:

void*
memset(void *dst, int c, uint n)
{
 146:	1141                	addi	sp,sp,-16
 148:	e406                	sd	ra,8(sp)
 14a:	e022                	sd	s0,0(sp)
 14c:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 14e:	ca19                	beqz	a2,164 <memset+0x1e>
 150:	87aa                	mv	a5,a0
 152:	1602                	slli	a2,a2,0x20
 154:	9201                	srli	a2,a2,0x20
 156:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 15a:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 15e:	0785                	addi	a5,a5,1
 160:	fee79de3          	bne	a5,a4,15a <memset+0x14>
  }
  return dst;
}
 164:	60a2                	ld	ra,8(sp)
 166:	6402                	ld	s0,0(sp)
 168:	0141                	addi	sp,sp,16
 16a:	8082                	ret

000000000000016c <strchr>:

char*
strchr(const char *s, char c)
{
 16c:	1141                	addi	sp,sp,-16
 16e:	e406                	sd	ra,8(sp)
 170:	e022                	sd	s0,0(sp)
 172:	0800                	addi	s0,sp,16
  for(; *s; s++)
 174:	00054783          	lbu	a5,0(a0)
 178:	c799                	beqz	a5,186 <strchr+0x1a>
    if(*s == c)
 17a:	00f58763          	beq	a1,a5,188 <strchr+0x1c>
  for(; *s; s++)
 17e:	0505                	addi	a0,a0,1
 180:	00054783          	lbu	a5,0(a0)
 184:	fbfd                	bnez	a5,17a <strchr+0xe>
      return (char*)s;
  return 0;
 186:	4501                	li	a0,0
}
 188:	60a2                	ld	ra,8(sp)
 18a:	6402                	ld	s0,0(sp)
 18c:	0141                	addi	sp,sp,16
 18e:	8082                	ret

0000000000000190 <gets>:

char*
gets(char *buf, int max)
{
 190:	711d                	addi	sp,sp,-96
 192:	ec86                	sd	ra,88(sp)
 194:	e8a2                	sd	s0,80(sp)
 196:	e4a6                	sd	s1,72(sp)
 198:	e0ca                	sd	s2,64(sp)
 19a:	fc4e                	sd	s3,56(sp)
 19c:	f852                	sd	s4,48(sp)
 19e:	f456                	sd	s5,40(sp)
 1a0:	f05a                	sd	s6,32(sp)
 1a2:	ec5e                	sd	s7,24(sp)
 1a4:	e862                	sd	s8,16(sp)
 1a6:	1080                	addi	s0,sp,96
 1a8:	8baa                	mv	s7,a0
 1aa:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 1ac:	892a                	mv	s2,a0
 1ae:	4481                	li	s1,0
    cc = read(0, &c, 1);
 1b0:	faf40b13          	addi	s6,s0,-81
 1b4:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 1b6:	8c26                	mv	s8,s1
 1b8:	0014899b          	addiw	s3,s1,1
 1bc:	84ce                	mv	s1,s3
 1be:	0349d863          	bge	s3,s4,1ee <gets+0x5e>
    cc = read(0, &c, 1);
 1c2:	8656                	mv	a2,s5
 1c4:	85da                	mv	a1,s6
 1c6:	4501                	li	a0,0
 1c8:	194000ef          	jal	35c <read>
    if(cc < 1)
 1cc:	02a05163          	blez	a0,1ee <gets+0x5e>
      break;
    buf[i++] = c;
 1d0:	faf44783          	lbu	a5,-81(s0)
 1d4:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 1d8:	0905                	addi	s2,s2,1
 1da:	ff678713          	addi	a4,a5,-10
 1de:	00173713          	seqz	a4,a4
 1e2:	17cd                	addi	a5,a5,-13
 1e4:	0017b793          	seqz	a5,a5
 1e8:	8fd9                	or	a5,a5,a4
 1ea:	d7f1                	beqz	a5,1b6 <gets+0x26>
    buf[i++] = c;
 1ec:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 1ee:	9c5e                	add	s8,s8,s7
 1f0:	000c0023          	sb	zero,0(s8)
  return buf;
}
 1f4:	855e                	mv	a0,s7
 1f6:	60e6                	ld	ra,88(sp)
 1f8:	6446                	ld	s0,80(sp)
 1fa:	64a6                	ld	s1,72(sp)
 1fc:	6906                	ld	s2,64(sp)
 1fe:	79e2                	ld	s3,56(sp)
 200:	7a42                	ld	s4,48(sp)
 202:	7aa2                	ld	s5,40(sp)
 204:	7b02                	ld	s6,32(sp)
 206:	6be2                	ld	s7,24(sp)
 208:	6c42                	ld	s8,16(sp)
 20a:	6125                	addi	sp,sp,96
 20c:	8082                	ret

000000000000020e <stat>:

int
stat(const char *n, struct stat *st)
{
 20e:	1101                	addi	sp,sp,-32
 210:	ec06                	sd	ra,24(sp)
 212:	e822                	sd	s0,16(sp)
 214:	e04a                	sd	s2,0(sp)
 216:	1000                	addi	s0,sp,32
 218:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 21a:	4581                	li	a1,0
 21c:	168000ef          	jal	384 <open>
  if(fd < 0)
 220:	02054263          	bltz	a0,244 <stat+0x36>
 224:	e426                	sd	s1,8(sp)
 226:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 228:	85ca                	mv	a1,s2
 22a:	172000ef          	jal	39c <fstat>
 22e:	892a                	mv	s2,a0
  close(fd);
 230:	8526                	mv	a0,s1
 232:	13a000ef          	jal	36c <close>
  return r;
 236:	64a2                	ld	s1,8(sp)
}
 238:	854a                	mv	a0,s2
 23a:	60e2                	ld	ra,24(sp)
 23c:	6442                	ld	s0,16(sp)
 23e:	6902                	ld	s2,0(sp)
 240:	6105                	addi	sp,sp,32
 242:	8082                	ret
    return -1;
 244:	57fd                	li	a5,-1
 246:	893e                	mv	s2,a5
 248:	bfc5                	j	238 <stat+0x2a>

000000000000024a <atoi>:

int
atoi(const char *s)
{
 24a:	1141                	addi	sp,sp,-16
 24c:	e406                	sd	ra,8(sp)
 24e:	e022                	sd	s0,0(sp)
 250:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 252:	00054683          	lbu	a3,0(a0)
 256:	fd06879b          	addiw	a5,a3,-48
 25a:	0ff7f793          	zext.b	a5,a5
 25e:	4625                	li	a2,9
 260:	02f66963          	bltu	a2,a5,292 <atoi+0x48>
 264:	872a                	mv	a4,a0
  n = 0;
 266:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 268:	0705                	addi	a4,a4,1
 26a:	0025179b          	slliw	a5,a0,0x2
 26e:	9fa9                	addw	a5,a5,a0
 270:	0017979b          	slliw	a5,a5,0x1
 274:	9fb5                	addw	a5,a5,a3
 276:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 27a:	00074683          	lbu	a3,0(a4)
 27e:	fd06879b          	addiw	a5,a3,-48
 282:	0ff7f793          	zext.b	a5,a5
 286:	fef671e3          	bgeu	a2,a5,268 <atoi+0x1e>
  return n;
}
 28a:	60a2                	ld	ra,8(sp)
 28c:	6402                	ld	s0,0(sp)
 28e:	0141                	addi	sp,sp,16
 290:	8082                	ret
  n = 0;
 292:	4501                	li	a0,0
 294:	bfdd                	j	28a <atoi+0x40>

0000000000000296 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 296:	1141                	addi	sp,sp,-16
 298:	e406                	sd	ra,8(sp)
 29a:	e022                	sd	s0,0(sp)
 29c:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 29e:	02b57563          	bgeu	a0,a1,2c8 <memmove+0x32>
    while(n-- > 0)
 2a2:	00c05f63          	blez	a2,2c0 <memmove+0x2a>
 2a6:	1602                	slli	a2,a2,0x20
 2a8:	9201                	srli	a2,a2,0x20
 2aa:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 2ae:	872a                	mv	a4,a0
      *dst++ = *src++;
 2b0:	0585                	addi	a1,a1,1
 2b2:	0705                	addi	a4,a4,1
 2b4:	fff5c683          	lbu	a3,-1(a1)
 2b8:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 2bc:	fee79ae3          	bne	a5,a4,2b0 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 2c0:	60a2                	ld	ra,8(sp)
 2c2:	6402                	ld	s0,0(sp)
 2c4:	0141                	addi	sp,sp,16
 2c6:	8082                	ret
    while(n-- > 0)
 2c8:	fec05ce3          	blez	a2,2c0 <memmove+0x2a>
    dst += n;
 2cc:	00c50733          	add	a4,a0,a2
    src += n;
 2d0:	95b2                	add	a1,a1,a2
 2d2:	fff6079b          	addiw	a5,a2,-1
 2d6:	1782                	slli	a5,a5,0x20
 2d8:	9381                	srli	a5,a5,0x20
 2da:	fff7c793          	not	a5,a5
 2de:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 2e0:	15fd                	addi	a1,a1,-1
 2e2:	177d                	addi	a4,a4,-1
 2e4:	0005c683          	lbu	a3,0(a1)
 2e8:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 2ec:	fef71ae3          	bne	a4,a5,2e0 <memmove+0x4a>
 2f0:	bfc1                	j	2c0 <memmove+0x2a>

00000000000002f2 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 2f2:	1141                	addi	sp,sp,-16
 2f4:	e406                	sd	ra,8(sp)
 2f6:	e022                	sd	s0,0(sp)
 2f8:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 2fa:	ce19                	beqz	a2,318 <memcmp+0x26>
 2fc:	1602                	slli	a2,a2,0x20
 2fe:	9201                	srli	a2,a2,0x20
 300:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 304:	00054783          	lbu	a5,0(a0)
 308:	0005c703          	lbu	a4,0(a1)
 30c:	00e79b63          	bne	a5,a4,322 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 310:	0505                	addi	a0,a0,1
    p2++;
 312:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 314:	fed518e3          	bne	a0,a3,304 <memcmp+0x12>
  }
  return 0;
 318:	4501                	li	a0,0
}
 31a:	60a2                	ld	ra,8(sp)
 31c:	6402                	ld	s0,0(sp)
 31e:	0141                	addi	sp,sp,16
 320:	8082                	ret
      return *p1 - *p2;
 322:	40e7853b          	subw	a0,a5,a4
 326:	bfd5                	j	31a <memcmp+0x28>

0000000000000328 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 328:	1141                	addi	sp,sp,-16
 32a:	e406                	sd	ra,8(sp)
 32c:	e022                	sd	s0,0(sp)
 32e:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 330:	f67ff0ef          	jal	296 <memmove>
}
 334:	60a2                	ld	ra,8(sp)
 336:	6402                	ld	s0,0(sp)
 338:	0141                	addi	sp,sp,16
 33a:	8082                	ret

000000000000033c <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 33c:	4885                	li	a7,1
 ecall
 33e:	00000073          	ecall
 ret
 342:	8082                	ret

0000000000000344 <exit>:
.global exit
exit:
 li a7, SYS_exit
 344:	4889                	li	a7,2
 ecall
 346:	00000073          	ecall
 ret
 34a:	8082                	ret

000000000000034c <wait>:
.global wait
wait:
 li a7, SYS_wait
 34c:	488d                	li	a7,3
 ecall
 34e:	00000073          	ecall
 ret
 352:	8082                	ret

0000000000000354 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 354:	4891                	li	a7,4
 ecall
 356:	00000073          	ecall
 ret
 35a:	8082                	ret

000000000000035c <read>:
.global read
read:
 li a7, SYS_read
 35c:	4895                	li	a7,5
 ecall
 35e:	00000073          	ecall
 ret
 362:	8082                	ret

0000000000000364 <write>:
.global write
write:
 li a7, SYS_write
 364:	48c1                	li	a7,16
 ecall
 366:	00000073          	ecall
 ret
 36a:	8082                	ret

000000000000036c <close>:
.global close
close:
 li a7, SYS_close
 36c:	48d5                	li	a7,21
 ecall
 36e:	00000073          	ecall
 ret
 372:	8082                	ret

0000000000000374 <kill>:
.global kill
kill:
 li a7, SYS_kill
 374:	4899                	li	a7,6
 ecall
 376:	00000073          	ecall
 ret
 37a:	8082                	ret

000000000000037c <exec>:
.global exec
exec:
 li a7, SYS_exec
 37c:	489d                	li	a7,7
 ecall
 37e:	00000073          	ecall
 ret
 382:	8082                	ret

0000000000000384 <open>:
.global open
open:
 li a7, SYS_open
 384:	48bd                	li	a7,15
 ecall
 386:	00000073          	ecall
 ret
 38a:	8082                	ret

000000000000038c <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 38c:	48c5                	li	a7,17
 ecall
 38e:	00000073          	ecall
 ret
 392:	8082                	ret

0000000000000394 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 394:	48c9                	li	a7,18
 ecall
 396:	00000073          	ecall
 ret
 39a:	8082                	ret

000000000000039c <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 39c:	48a1                	li	a7,8
 ecall
 39e:	00000073          	ecall
 ret
 3a2:	8082                	ret

00000000000003a4 <link>:
.global link
link:
 li a7, SYS_link
 3a4:	48cd                	li	a7,19
 ecall
 3a6:	00000073          	ecall
 ret
 3aa:	8082                	ret

00000000000003ac <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 3ac:	48d1                	li	a7,20
 ecall
 3ae:	00000073          	ecall
 ret
 3b2:	8082                	ret

00000000000003b4 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 3b4:	48a5                	li	a7,9
 ecall
 3b6:	00000073          	ecall
 ret
 3ba:	8082                	ret

00000000000003bc <dup>:
.global dup
dup:
 li a7, SYS_dup
 3bc:	48a9                	li	a7,10
 ecall
 3be:	00000073          	ecall
 ret
 3c2:	8082                	ret

00000000000003c4 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 3c4:	48ad                	li	a7,11
 ecall
 3c6:	00000073          	ecall
 ret
 3ca:	8082                	ret

00000000000003cc <getproccount>:
.global getproccount
getproccount:
 li a7, SYS_getproccount
 3cc:	48d9                	li	a7,22
 ecall
 3ce:	00000073          	ecall
 ret
 3d2:	8082                	ret

00000000000003d4 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 3d4:	48b1                	li	a7,12
 ecall
 3d6:	00000073          	ecall
 ret
 3da:	8082                	ret

00000000000003dc <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 3dc:	48b5                	li	a7,13
 ecall
 3de:	00000073          	ecall
 ret
 3e2:	8082                	ret

00000000000003e4 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 3e4:	48b9                	li	a7,14
 ecall
 3e6:	00000073          	ecall
 ret
 3ea:	8082                	ret

00000000000003ec <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 3ec:	1101                	addi	sp,sp,-32
 3ee:	ec06                	sd	ra,24(sp)
 3f0:	e822                	sd	s0,16(sp)
 3f2:	1000                	addi	s0,sp,32
 3f4:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 3f8:	4605                	li	a2,1
 3fa:	fef40593          	addi	a1,s0,-17
 3fe:	f67ff0ef          	jal	364 <write>
}
 402:	60e2                	ld	ra,24(sp)
 404:	6442                	ld	s0,16(sp)
 406:	6105                	addi	sp,sp,32
 408:	8082                	ret

000000000000040a <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 40a:	715d                	addi	sp,sp,-80
 40c:	e486                	sd	ra,72(sp)
 40e:	e0a2                	sd	s0,64(sp)
 410:	f84a                	sd	s2,48(sp)
 412:	f44e                	sd	s3,40(sp)
 414:	0880                	addi	s0,sp,80
 416:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 418:	00d036b3          	snez	a3,a3
 41c:	03f5d793          	srli	a5,a1,0x3f
 420:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 422:	0005871b          	sext.w	a4,a1
  neg = 0;
 426:	4301                	li	t1,0
  if(sgn && xx < 0){
 428:	c681                	beqz	a3,430 <printint+0x26>
    x = -xx;
 42a:	40b0073b          	negw	a4,a1
    neg = 1;
 42e:	4305                	li	t1,1
  }

  i = 0;
 430:	fb840993          	addi	s3,s0,-72
  neg = 0;
 434:	85ce                	mv	a1,s3
  i = 0;
 436:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 438:	00000817          	auipc	a6,0x0
 43c:	53880813          	addi	a6,a6,1336 # 970 <digits>
 440:	88b6                	mv	a7,a3
 442:	0016851b          	addiw	a0,a3,1
 446:	86aa                	mv	a3,a0
 448:	02c777bb          	remuw	a5,a4,a2
 44c:	1782                	slli	a5,a5,0x20
 44e:	9381                	srli	a5,a5,0x20
 450:	97c2                	add	a5,a5,a6
 452:	0007c783          	lbu	a5,0(a5)
 456:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 45a:	87ba                	mv	a5,a4
 45c:	02c7573b          	divuw	a4,a4,a2
 460:	0585                	addi	a1,a1,1
 462:	fcc7ffe3          	bgeu	a5,a2,440 <printint+0x36>
  if(neg)
 466:	00030b63          	beqz	t1,47c <printint+0x72>
    buf[i++] = '-';
 46a:	fd040793          	addi	a5,s0,-48
 46e:	953e                	add	a0,a0,a5
 470:	02d00793          	li	a5,45
 474:	fef50423          	sb	a5,-24(a0)
 478:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 47c:	02d05563          	blez	a3,4a6 <printint+0x9c>
 480:	fc26                	sd	s1,56(sp)
 482:	36fd                	addiw	a3,a3,-1
 484:	00d984b3          	add	s1,s3,a3
 488:	19fd                	addi	s3,s3,-1
 48a:	99b6                	add	s3,s3,a3
 48c:	1682                	slli	a3,a3,0x20
 48e:	9281                	srli	a3,a3,0x20
 490:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 494:	0004c583          	lbu	a1,0(s1)
 498:	854a                	mv	a0,s2
 49a:	f53ff0ef          	jal	3ec <putc>
  while(--i >= 0)
 49e:	14fd                	addi	s1,s1,-1
 4a0:	ff349ae3          	bne	s1,s3,494 <printint+0x8a>
 4a4:	74e2                	ld	s1,56(sp)
}
 4a6:	60a6                	ld	ra,72(sp)
 4a8:	6406                	ld	s0,64(sp)
 4aa:	7942                	ld	s2,48(sp)
 4ac:	79a2                	ld	s3,40(sp)
 4ae:	6161                	addi	sp,sp,80
 4b0:	8082                	ret

00000000000004b2 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 4b2:	711d                	addi	sp,sp,-96
 4b4:	ec86                	sd	ra,88(sp)
 4b6:	e8a2                	sd	s0,80(sp)
 4b8:	e4a6                	sd	s1,72(sp)
 4ba:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 4bc:	0005c483          	lbu	s1,0(a1)
 4c0:	28048263          	beqz	s1,744 <vprintf+0x292>
 4c4:	e0ca                	sd	s2,64(sp)
 4c6:	fc4e                	sd	s3,56(sp)
 4c8:	f852                	sd	s4,48(sp)
 4ca:	f456                	sd	s5,40(sp)
 4cc:	f05a                	sd	s6,32(sp)
 4ce:	ec5e                	sd	s7,24(sp)
 4d0:	e862                	sd	s8,16(sp)
 4d2:	8b2a                	mv	s6,a0
 4d4:	8a2e                	mv	s4,a1
 4d6:	8bb2                	mv	s7,a2
  state = 0;
 4d8:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 4da:	4901                	li	s2,0
 4dc:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 4de:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 4e2:	06400c13          	li	s8,100
 4e6:	a00d                	j	508 <vprintf+0x56>
        putc(fd, c0);
 4e8:	85a6                	mv	a1,s1
 4ea:	855a                	mv	a0,s6
 4ec:	f01ff0ef          	jal	3ec <putc>
 4f0:	a019                	j	4f6 <vprintf+0x44>
    } else if(state == '%'){
 4f2:	03598363          	beq	s3,s5,518 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 4f6:	0019079b          	addiw	a5,s2,1
 4fa:	893e                	mv	s2,a5
 4fc:	873e                	mv	a4,a5
 4fe:	97d2                	add	a5,a5,s4
 500:	0007c483          	lbu	s1,0(a5)
 504:	22048963          	beqz	s1,736 <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 508:	0004879b          	sext.w	a5,s1
    if(state == 0){
 50c:	fe0993e3          	bnez	s3,4f2 <vprintf+0x40>
      if(c0 == '%'){
 510:	fd579ce3          	bne	a5,s5,4e8 <vprintf+0x36>
        state = '%';
 514:	89be                	mv	s3,a5
 516:	b7c5                	j	4f6 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 518:	00ea06b3          	add	a3,s4,a4
 51c:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 520:	22060763          	beqz	a2,74e <vprintf+0x29c>
      if(c0 == 'd'){
 524:	0b878363          	beq	a5,s8,5ca <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 528:	f9478693          	addi	a3,a5,-108
 52c:	0016b693          	seqz	a3,a3
 530:	f9c60593          	addi	a1,a2,-100
 534:	0015b593          	seqz	a1,a1
 538:	8df5                	and	a1,a1,a3
 53a:	e5c5                	bnez	a1,5e2 <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 53c:	9752                	add	a4,a4,s4
 53e:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 542:	f9460713          	addi	a4,a2,-108
 546:	00173713          	seqz	a4,a4
 54a:	8f75                	and	a4,a4,a3
 54c:	f9c50593          	addi	a1,a0,-100
 550:	0015b593          	seqz	a1,a1
 554:	8df9                	and	a1,a1,a4
 556:	e1dd                	bnez	a1,5fc <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 558:	07500593          	li	a1,117
 55c:	0ab78d63          	beq	a5,a1,616 <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 560:	f8b60593          	addi	a1,a2,-117
 564:	0015b593          	seqz	a1,a1
 568:	8df5                	and	a1,a1,a3
 56a:	e1f1                	bnez	a1,62e <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 56c:	f8b50593          	addi	a1,a0,-117
 570:	0015b593          	seqz	a1,a1
 574:	8df9                	and	a1,a1,a4
 576:	e9e9                	bnez	a1,648 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 578:	07800593          	li	a1,120
 57c:	0eb78363          	beq	a5,a1,662 <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 580:	f8860613          	addi	a2,a2,-120
 584:	00163613          	seqz	a2,a2
 588:	8ef1                	and	a3,a3,a2
 58a:	0e069863          	bnez	a3,67a <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 58e:	f8850513          	addi	a0,a0,-120
 592:	00153513          	seqz	a0,a0
 596:	8f69                	and	a4,a4,a0
 598:	0e071e63          	bnez	a4,694 <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 59c:	07000713          	li	a4,112
 5a0:	10e78663          	beq	a5,a4,6ac <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 5a4:	07300713          	li	a4,115
 5a8:	14e78663          	beq	a5,a4,6f4 <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 5ac:	02500713          	li	a4,37
 5b0:	16e78e63          	beq	a5,a4,72c <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 5b4:	02500593          	li	a1,37
 5b8:	855a                	mv	a0,s6
 5ba:	e33ff0ef          	jal	3ec <putc>
        putc(fd, c0);
 5be:	85a6                	mv	a1,s1
 5c0:	855a                	mv	a0,s6
 5c2:	e2bff0ef          	jal	3ec <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 5c6:	4981                	li	s3,0
 5c8:	b73d                	j	4f6 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 5ca:	008b8493          	addi	s1,s7,8
 5ce:	4685                	li	a3,1
 5d0:	4629                	li	a2,10
 5d2:	000ba583          	lw	a1,0(s7)
 5d6:	855a                	mv	a0,s6
 5d8:	e33ff0ef          	jal	40a <printint>
 5dc:	8ba6                	mv	s7,s1
      state = 0;
 5de:	4981                	li	s3,0
 5e0:	bf19                	j	4f6 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 5e2:	008b8493          	addi	s1,s7,8
 5e6:	4685                	li	a3,1
 5e8:	4629                	li	a2,10
 5ea:	000bb583          	ld	a1,0(s7)
 5ee:	855a                	mv	a0,s6
 5f0:	e1bff0ef          	jal	40a <printint>
        i += 1;
 5f4:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 5f6:	8ba6                	mv	s7,s1
      state = 0;
 5f8:	4981                	li	s3,0
 5fa:	bdf5                	j	4f6 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 5fc:	008b8493          	addi	s1,s7,8
 600:	4685                	li	a3,1
 602:	4629                	li	a2,10
 604:	000bb583          	ld	a1,0(s7)
 608:	855a                	mv	a0,s6
 60a:	e01ff0ef          	jal	40a <printint>
        i += 2;
 60e:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 610:	8ba6                	mv	s7,s1
      state = 0;
 612:	4981                	li	s3,0
        i += 2;
 614:	b5cd                	j	4f6 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 616:	008b8493          	addi	s1,s7,8
 61a:	4681                	li	a3,0
 61c:	4629                	li	a2,10
 61e:	000ba583          	lw	a1,0(s7)
 622:	855a                	mv	a0,s6
 624:	de7ff0ef          	jal	40a <printint>
 628:	8ba6                	mv	s7,s1
      state = 0;
 62a:	4981                	li	s3,0
 62c:	b5e9                	j	4f6 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 62e:	008b8493          	addi	s1,s7,8
 632:	4681                	li	a3,0
 634:	4629                	li	a2,10
 636:	000bb583          	ld	a1,0(s7)
 63a:	855a                	mv	a0,s6
 63c:	dcfff0ef          	jal	40a <printint>
        i += 1;
 640:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 642:	8ba6                	mv	s7,s1
      state = 0;
 644:	4981                	li	s3,0
 646:	bd45                	j	4f6 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 648:	008b8493          	addi	s1,s7,8
 64c:	4681                	li	a3,0
 64e:	4629                	li	a2,10
 650:	000bb583          	ld	a1,0(s7)
 654:	855a                	mv	a0,s6
 656:	db5ff0ef          	jal	40a <printint>
        i += 2;
 65a:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 65c:	8ba6                	mv	s7,s1
      state = 0;
 65e:	4981                	li	s3,0
        i += 2;
 660:	bd59                	j	4f6 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 662:	008b8493          	addi	s1,s7,8
 666:	4681                	li	a3,0
 668:	4641                	li	a2,16
 66a:	000ba583          	lw	a1,0(s7)
 66e:	855a                	mv	a0,s6
 670:	d9bff0ef          	jal	40a <printint>
 674:	8ba6                	mv	s7,s1
      state = 0;
 676:	4981                	li	s3,0
 678:	bdbd                	j	4f6 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 67a:	008b8493          	addi	s1,s7,8
 67e:	4681                	li	a3,0
 680:	4641                	li	a2,16
 682:	000bb583          	ld	a1,0(s7)
 686:	855a                	mv	a0,s6
 688:	d83ff0ef          	jal	40a <printint>
        i += 1;
 68c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 68e:	8ba6                	mv	s7,s1
      state = 0;
 690:	4981                	li	s3,0
 692:	b595                	j	4f6 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 694:	008b8493          	addi	s1,s7,8
 698:	4641                	li	a2,16
 69a:	000bb583          	ld	a1,0(s7)
 69e:	855a                	mv	a0,s6
 6a0:	d6bff0ef          	jal	40a <printint>
        i += 2;
 6a4:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 6a6:	8ba6                	mv	s7,s1
      state = 0;
 6a8:	4981                	li	s3,0
        i += 2;
 6aa:	b5b1                	j	4f6 <vprintf+0x44>
 6ac:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 6ae:	008b8793          	addi	a5,s7,8
 6b2:	8cbe                	mv	s9,a5
 6b4:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 6b8:	03000593          	li	a1,48
 6bc:	855a                	mv	a0,s6
 6be:	d2fff0ef          	jal	3ec <putc>
  putc(fd, 'x');
 6c2:	07800593          	li	a1,120
 6c6:	855a                	mv	a0,s6
 6c8:	d25ff0ef          	jal	3ec <putc>
 6cc:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 6ce:	00000b97          	auipc	s7,0x0
 6d2:	2a2b8b93          	addi	s7,s7,674 # 970 <digits>
 6d6:	03c9d793          	srli	a5,s3,0x3c
 6da:	97de                	add	a5,a5,s7
 6dc:	0007c583          	lbu	a1,0(a5)
 6e0:	855a                	mv	a0,s6
 6e2:	d0bff0ef          	jal	3ec <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 6e6:	0992                	slli	s3,s3,0x4
 6e8:	34fd                	addiw	s1,s1,-1
 6ea:	f4f5                	bnez	s1,6d6 <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 6ec:	8be6                	mv	s7,s9
      state = 0;
 6ee:	4981                	li	s3,0
 6f0:	6ca2                	ld	s9,8(sp)
 6f2:	b511                	j	4f6 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 6f4:	008b8993          	addi	s3,s7,8
 6f8:	000bb483          	ld	s1,0(s7)
 6fc:	cc91                	beqz	s1,718 <vprintf+0x266>
        for(; *s; s++)
 6fe:	0004c583          	lbu	a1,0(s1)
 702:	c195                	beqz	a1,726 <vprintf+0x274>
          putc(fd, *s);
 704:	855a                	mv	a0,s6
 706:	ce7ff0ef          	jal	3ec <putc>
        for(; *s; s++)
 70a:	0485                	addi	s1,s1,1
 70c:	0004c583          	lbu	a1,0(s1)
 710:	f9f5                	bnez	a1,704 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 712:	8bce                	mv	s7,s3
      state = 0;
 714:	4981                	li	s3,0
 716:	b3c5                	j	4f6 <vprintf+0x44>
          s = "(null)";
 718:	00000497          	auipc	s1,0x0
 71c:	25048493          	addi	s1,s1,592 # 968 <malloc+0x11e>
        for(; *s; s++)
 720:	02800593          	li	a1,40
 724:	b7c5                	j	704 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 726:	8bce                	mv	s7,s3
      state = 0;
 728:	4981                	li	s3,0
 72a:	b3f1                	j	4f6 <vprintf+0x44>
        putc(fd, '%');
 72c:	85be                	mv	a1,a5
 72e:	855a                	mv	a0,s6
 730:	cbdff0ef          	jal	3ec <putc>
 734:	bd49                	j	5c6 <vprintf+0x114>
 736:	6906                	ld	s2,64(sp)
 738:	79e2                	ld	s3,56(sp)
 73a:	7a42                	ld	s4,48(sp)
 73c:	7aa2                	ld	s5,40(sp)
 73e:	7b02                	ld	s6,32(sp)
 740:	6be2                	ld	s7,24(sp)
 742:	6c42                	ld	s8,16(sp)
    }
  }
}
 744:	60e6                	ld	ra,88(sp)
 746:	6446                	ld	s0,80(sp)
 748:	64a6                	ld	s1,72(sp)
 74a:	6125                	addi	sp,sp,96
 74c:	8082                	ret
      if(c0 == 'd'){
 74e:	06400713          	li	a4,100
 752:	e6e78ce3          	beq	a5,a4,5ca <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 756:	f9478693          	addi	a3,a5,-108
 75a:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 75e:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 760:	4701                	li	a4,0
 762:	bbdd                	j	558 <vprintf+0xa6>

0000000000000764 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 764:	715d                	addi	sp,sp,-80
 766:	ec06                	sd	ra,24(sp)
 768:	e822                	sd	s0,16(sp)
 76a:	1000                	addi	s0,sp,32
 76c:	e010                	sd	a2,0(s0)
 76e:	e414                	sd	a3,8(s0)
 770:	e818                	sd	a4,16(s0)
 772:	ec1c                	sd	a5,24(s0)
 774:	03043023          	sd	a6,32(s0)
 778:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 77c:	8622                	mv	a2,s0
 77e:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 782:	d31ff0ef          	jal	4b2 <vprintf>
}
 786:	60e2                	ld	ra,24(sp)
 788:	6442                	ld	s0,16(sp)
 78a:	6161                	addi	sp,sp,80
 78c:	8082                	ret

000000000000078e <printf>:

void
printf(const char *fmt, ...)
{
 78e:	711d                	addi	sp,sp,-96
 790:	ec06                	sd	ra,24(sp)
 792:	e822                	sd	s0,16(sp)
 794:	1000                	addi	s0,sp,32
 796:	e40c                	sd	a1,8(s0)
 798:	e810                	sd	a2,16(s0)
 79a:	ec14                	sd	a3,24(s0)
 79c:	f018                	sd	a4,32(s0)
 79e:	f41c                	sd	a5,40(s0)
 7a0:	03043823          	sd	a6,48(s0)
 7a4:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 7a8:	00840613          	addi	a2,s0,8
 7ac:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 7b0:	85aa                	mv	a1,a0
 7b2:	4505                	li	a0,1
 7b4:	cffff0ef          	jal	4b2 <vprintf>
}
 7b8:	60e2                	ld	ra,24(sp)
 7ba:	6442                	ld	s0,16(sp)
 7bc:	6125                	addi	sp,sp,96
 7be:	8082                	ret

00000000000007c0 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 7c0:	1141                	addi	sp,sp,-16
 7c2:	e406                	sd	ra,8(sp)
 7c4:	e022                	sd	s0,0(sp)
 7c6:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 7c8:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 7cc:	00001797          	auipc	a5,0x1
 7d0:	8347b783          	ld	a5,-1996(a5) # 1000 <freep>
 7d4:	a095                	j	838 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 7d6:	ff852583          	lw	a1,-8(a0)
 7da:	6390                	ld	a2,0(a5)
 7dc:	02059813          	slli	a6,a1,0x20
 7e0:	01c85693          	srli	a3,a6,0x1c
 7e4:	96ba                	add	a3,a3,a4
 7e6:	02d60563          	beq	a2,a3,810 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 7ea:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 7ee:	4790                	lw	a2,8(a5)
 7f0:	02061593          	slli	a1,a2,0x20
 7f4:	01c5d693          	srli	a3,a1,0x1c
 7f8:	96be                	add	a3,a3,a5
 7fa:	02d70263          	beq	a4,a3,81e <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 7fe:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 800:	00001717          	auipc	a4,0x1
 804:	80f73023          	sd	a5,-2048(a4) # 1000 <freep>
}
 808:	60a2                	ld	ra,8(sp)
 80a:	6402                	ld	s0,0(sp)
 80c:	0141                	addi	sp,sp,16
 80e:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 810:	4614                	lw	a3,8(a2)
 812:	9ead                	addw	a3,a3,a1
 814:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 818:	6394                	ld	a3,0(a5)
 81a:	6290                	ld	a2,0(a3)
 81c:	b7f9                	j	7ea <free+0x2a>
    p->s.size += bp->s.size;
 81e:	ff852703          	lw	a4,-8(a0)
 822:	9f31                	addw	a4,a4,a2
 824:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 826:	ff053703          	ld	a4,-16(a0)
 82a:	bfd1                	j	7fe <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 82c:	6394                	ld	a3,0(a5)
 82e:	00d7e463          	bltu	a5,a3,836 <free+0x76>
 832:	fad762e3          	bltu	a4,a3,7d6 <free+0x16>
 836:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 838:	fee7fae3          	bgeu	a5,a4,82c <free+0x6c>
 83c:	6394                	ld	a3,0(a5)
 83e:	f8d76ce3          	bltu	a4,a3,7d6 <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 842:	f8d7fae3          	bgeu	a5,a3,7d6 <free+0x16>
 846:	87b6                	mv	a5,a3
 848:	bfc5                	j	838 <free+0x78>

000000000000084a <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 84a:	7139                	addi	sp,sp,-64
 84c:	fc06                	sd	ra,56(sp)
 84e:	f822                	sd	s0,48(sp)
 850:	f04a                	sd	s2,32(sp)
 852:	ec4e                	sd	s3,24(sp)
 854:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 856:	02051993          	slli	s3,a0,0x20
 85a:	0209d993          	srli	s3,s3,0x20
 85e:	09bd                	addi	s3,s3,15
 860:	0049d993          	srli	s3,s3,0x4
 864:	2985                	addiw	s3,s3,1
 866:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 868:	00000517          	auipc	a0,0x0
 86c:	79853503          	ld	a0,1944(a0) # 1000 <freep>
 870:	c905                	beqz	a0,8a0 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 872:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 874:	4798                	lw	a4,8(a5)
 876:	09377663          	bgeu	a4,s3,902 <malloc+0xb8>
 87a:	f426                	sd	s1,40(sp)
 87c:	e852                	sd	s4,16(sp)
 87e:	e456                	sd	s5,8(sp)
 880:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 882:	8a4e                	mv	s4,s3
 884:	6705                	lui	a4,0x1
 886:	00e9f363          	bgeu	s3,a4,88c <malloc+0x42>
 88a:	6a05                	lui	s4,0x1
 88c:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 890:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 894:	00000497          	auipc	s1,0x0
 898:	76c48493          	addi	s1,s1,1900 # 1000 <freep>
  if(p == (char*)-1)
 89c:	5afd                	li	s5,-1
 89e:	a83d                	j	8dc <malloc+0x92>
 8a0:	f426                	sd	s1,40(sp)
 8a2:	e852                	sd	s4,16(sp)
 8a4:	e456                	sd	s5,8(sp)
 8a6:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 8a8:	00000797          	auipc	a5,0x0
 8ac:	76878793          	addi	a5,a5,1896 # 1010 <base>
 8b0:	00000717          	auipc	a4,0x0
 8b4:	74f73823          	sd	a5,1872(a4) # 1000 <freep>
 8b8:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 8ba:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 8be:	b7d1                	j	882 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 8c0:	6398                	ld	a4,0(a5)
 8c2:	e118                	sd	a4,0(a0)
 8c4:	a899                	j	91a <malloc+0xd0>
  hp->s.size = nu;
 8c6:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 8ca:	0541                	addi	a0,a0,16
 8cc:	ef5ff0ef          	jal	7c0 <free>
  return freep;
 8d0:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 8d2:	c125                	beqz	a0,932 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 8d4:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 8d6:	4798                	lw	a4,8(a5)
 8d8:	03277163          	bgeu	a4,s2,8fa <malloc+0xb0>
    if(p == freep)
 8dc:	6098                	ld	a4,0(s1)
 8de:	853e                	mv	a0,a5
 8e0:	fef71ae3          	bne	a4,a5,8d4 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 8e4:	8552                	mv	a0,s4
 8e6:	aefff0ef          	jal	3d4 <sbrk>
  if(p == (char*)-1)
 8ea:	fd551ee3          	bne	a0,s5,8c6 <malloc+0x7c>
        return 0;
 8ee:	4501                	li	a0,0
 8f0:	74a2                	ld	s1,40(sp)
 8f2:	6a42                	ld	s4,16(sp)
 8f4:	6aa2                	ld	s5,8(sp)
 8f6:	6b02                	ld	s6,0(sp)
 8f8:	a03d                	j	926 <malloc+0xdc>
 8fa:	74a2                	ld	s1,40(sp)
 8fc:	6a42                	ld	s4,16(sp)
 8fe:	6aa2                	ld	s5,8(sp)
 900:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 902:	fae90fe3          	beq	s2,a4,8c0 <malloc+0x76>
        p->s.size -= nunits;
 906:	4137073b          	subw	a4,a4,s3
 90a:	c798                	sw	a4,8(a5)
        p += p->s.size;
 90c:	02071693          	slli	a3,a4,0x20
 910:	01c6d713          	srli	a4,a3,0x1c
 914:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 916:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 91a:	00000717          	auipc	a4,0x0
 91e:	6ea73323          	sd	a0,1766(a4) # 1000 <freep>
      return (void*)(p + 1);
 922:	01078513          	addi	a0,a5,16
  }
}
 926:	70e2                	ld	ra,56(sp)
 928:	7442                	ld	s0,48(sp)
 92a:	7902                	ld	s2,32(sp)
 92c:	69e2                	ld	s3,24(sp)
 92e:	6121                	addi	sp,sp,64
 930:	8082                	ret
 932:	74a2                	ld	s1,40(sp)
 934:	6a42                	ld	s4,16(sp)
 936:	6aa2                	ld	s5,8(sp)
 938:	6b02                	ld	s6,0(sp)
 93a:	b7f5                	j	926 <malloc+0xdc>
