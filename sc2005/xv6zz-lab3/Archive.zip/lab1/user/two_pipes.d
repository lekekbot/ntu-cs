user/two_pipes.o: user/two_pipes.c kernel/types.h kernel/stat.h \
 user/user.h
