
user/_two_pipes:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <sendmsg>:
#define BUFSZ  (MSGLEN + 1)

// Write the whole string or report failure.
static int
sendmsg(int fd, const char *s)
{
   0:	7179                	addi	sp,sp,-48
   2:	f406                	sd	ra,40(sp)
   4:	f022                	sd	s0,32(sp)
   6:	ec26                	sd	s1,24(sp)
   8:	e84a                	sd	s2,16(sp)
   a:	e44e                	sd	s3,8(sp)
   c:	1800                	addi	s0,sp,48
   e:	89aa                	mv	s3,a0
  10:	892e                	mv	s2,a1
  int len = strlen(s);
  12:	852e                	mv	a0,a1
  14:	20e000ef          	jal	222 <strlen>
  18:	84aa                	mv	s1,a0

  if(write(fd, s, len) != len){
  1a:	862a                	mv	a2,a0
  1c:	85ca                	mv	a1,s2
  1e:	854e                	mv	a0,s3
  20:	44c000ef          	jal	46c <write>
  24:	00951a63          	bne	a0,s1,38 <sendmsg+0x38>
    fprintf(2, "two_pipes: write of %s failed\n", s);
    return -1;
  }
  return 0;
  28:	4501                	li	a0,0
}
  2a:	70a2                	ld	ra,40(sp)
  2c:	7402                	ld	s0,32(sp)
  2e:	64e2                	ld	s1,24(sp)
  30:	6942                	ld	s2,16(sp)
  32:	69a2                	ld	s3,8(sp)
  34:	6145                	addi	sp,sp,48
  36:	8082                	ret
    fprintf(2, "two_pipes: write of %s failed\n", s);
  38:	864a                	mv	a2,s2
  3a:	00001597          	auipc	a1,0x1
  3e:	a1658593          	addi	a1,a1,-1514 # a50 <malloc+0xfe>
  42:	4509                	li	a0,2
  44:	029000ef          	jal	86c <fprintf>
    return -1;
  48:	557d                	li	a0,-1
  4a:	b7c5                	j	2a <sendmsg+0x2a>

000000000000004c <main>:

int
main(int argc, char *argv[])
{
  4c:	7179                	addi	sp,sp,-48
  4e:	f406                	sd	ra,40(sp)
  50:	f022                	sd	s0,32(sp)
  52:	1800                	addi	s0,sp,48
  int p2c[2];  // parent -> child
  int c2p[2];  // child  -> parent
  char buf[BUFSZ];
  int n;

  if(pipe(p2c) < 0 || pipe(c2p) < 0){
  54:	fe840513          	addi	a0,s0,-24
  58:	404000ef          	jal	45c <pipe>
  5c:	00054863          	bltz	a0,6c <main+0x20>
  60:	fe040513          	addi	a0,s0,-32
  64:	3f8000ef          	jal	45c <pipe>
  68:	00055c63          	bgez	a0,80 <main+0x34>
    fprintf(2, "two_pipes: pipe failed\n");
  6c:	00001597          	auipc	a1,0x1
  70:	a0458593          	addi	a1,a1,-1532 # a70 <malloc+0x11e>
  74:	4509                	li	a0,2
  76:	7f6000ef          	jal	86c <fprintf>
    exit(1);
  7a:	4505                	li	a0,1
  7c:	3d0000ef          	jal	44c <exit>
  }

  int pid = fork();
  80:	3c4000ef          	jal	444 <fork>
  if(pid < 0){
  84:	04054163          	bltz	a0,c6 <main+0x7a>
    fprintf(2, "two_pipes: fork failed\n");
    exit(1);
  }

  if(pid == 0){
  88:	ed51                	bnez	a0,124 <main+0xd8>
    // Child: read ping from p2c[0], reply pong on c2p[1].
    close(p2c[1]);   // child never writes to p2c
  8a:	fec42503          	lw	a0,-20(s0)
  8e:	3e6000ef          	jal	474 <close>
    close(c2p[0]);   // child never reads from c2p
  92:	fe042503          	lw	a0,-32(s0)
  96:	3de000ef          	jal	474 <close>

    if((n = read(p2c[0], buf, MSGLEN)) != MSGLEN){
  9a:	4611                	li	a2,4
  9c:	fd840593          	addi	a1,s0,-40
  a0:	fe842503          	lw	a0,-24(s0)
  a4:	3c0000ef          	jal	464 <read>
  a8:	862a                	mv	a2,a0
  aa:	4791                	li	a5,4
  ac:	02f50763          	beq	a0,a5,da <main+0x8e>
      fprintf(2, "two_pipes: child read %d bytes, expected %d\n", n, MSGLEN);
  b0:	86be                	mv	a3,a5
  b2:	00001597          	auipc	a1,0x1
  b6:	9ee58593          	addi	a1,a1,-1554 # aa0 <malloc+0x14e>
  ba:	4509                	li	a0,2
  bc:	7b0000ef          	jal	86c <fprintf>
      exit(1);
  c0:	4505                	li	a0,1
  c2:	38a000ef          	jal	44c <exit>
    fprintf(2, "two_pipes: fork failed\n");
  c6:	00001597          	auipc	a1,0x1
  ca:	9c258593          	addi	a1,a1,-1598 # a88 <malloc+0x136>
  ce:	4509                	li	a0,2
  d0:	79c000ef          	jal	86c <fprintf>
    exit(1);
  d4:	4505                	li	a0,1
  d6:	376000ef          	jal	44c <exit>
    }
    buf[n] = '\0';
  da:	fc040e23          	sb	zero,-36(s0)
    printf("%d: received %s\n", getpid(), buf);
  de:	3ee000ef          	jal	4cc <getpid>
  e2:	85aa                	mv	a1,a0
  e4:	fd840613          	addi	a2,s0,-40
  e8:	00001517          	auipc	a0,0x1
  ec:	9e850513          	addi	a0,a0,-1560 # ad0 <malloc+0x17e>
  f0:	7a6000ef          	jal	896 <printf>

    if(sendmsg(c2p[1], "pong") < 0)
  f4:	00001597          	auipc	a1,0x1
  f8:	9f458593          	addi	a1,a1,-1548 # ae8 <malloc+0x196>
  fc:	fe442503          	lw	a0,-28(s0)
 100:	f01ff0ef          	jal	0 <sendmsg>
 104:	00054d63          	bltz	a0,11e <main+0xd2>
      exit(1);

    close(p2c[0]);
 108:	fe842503          	lw	a0,-24(s0)
 10c:	368000ef          	jal	474 <close>
    close(c2p[1]);
 110:	fe442503          	lw	a0,-28(s0)
 114:	360000ef          	jal	474 <close>
    exit(0);
 118:	4501                	li	a0,0
 11a:	332000ef          	jal	44c <exit>
      exit(1);
 11e:	4505                	li	a0,1
 120:	32c000ef          	jal	44c <exit>
  }

  // Parent: send ping on p2c[1], read pong from c2p[0].
  close(p2c[0]);     // parent never reads from p2c
 124:	fe842503          	lw	a0,-24(s0)
 128:	34c000ef          	jal	474 <close>
  close(c2p[1]);     // parent never writes to c2p
 12c:	fe442503          	lw	a0,-28(s0)
 130:	344000ef          	jal	474 <close>

  if(sendmsg(p2c[1], "ping") < 0){
 134:	00001597          	auipc	a1,0x1
 138:	9bc58593          	addi	a1,a1,-1604 # af0 <malloc+0x19e>
 13c:	fec42503          	lw	a0,-20(s0)
 140:	ec1ff0ef          	jal	0 <sendmsg>
 144:	02054c63          	bltz	a0,17c <main+0x130>
    close(p2c[1]);
    close(c2p[0]);
    exit(1);
  }
  close(p2c[1]);     // let the child see EOF once the byte is consumed
 148:	fec42503          	lw	a0,-20(s0)
 14c:	328000ef          	jal	474 <close>

  if((n = read(c2p[0], buf, MSGLEN)) != MSGLEN){
 150:	4611                	li	a2,4
 152:	fd840593          	addi	a1,s0,-40
 156:	fe042503          	lw	a0,-32(s0)
 15a:	30a000ef          	jal	464 <read>
 15e:	862a                	mv	a2,a0
 160:	4791                	li	a5,4
 162:	02f50863          	beq	a0,a5,192 <main+0x146>
    fprintf(2, "two_pipes: parent read %d bytes, expected %d\n", n, MSGLEN);
 166:	86be                	mv	a3,a5
 168:	00001597          	auipc	a1,0x1
 16c:	99058593          	addi	a1,a1,-1648 # af8 <malloc+0x1a6>
 170:	4509                	li	a0,2
 172:	6fa000ef          	jal	86c <fprintf>
    exit(1);
 176:	4505                	li	a0,1
 178:	2d4000ef          	jal	44c <exit>
    close(p2c[1]);
 17c:	fec42503          	lw	a0,-20(s0)
 180:	2f4000ef          	jal	474 <close>
    close(c2p[0]);
 184:	fe042503          	lw	a0,-32(s0)
 188:	2ec000ef          	jal	474 <close>
    exit(1);
 18c:	4505                	li	a0,1
 18e:	2be000ef          	jal	44c <exit>
  }
  buf[n] = '\0';
 192:	fc040e23          	sb	zero,-36(s0)
  printf("%d: received %s\n", getpid(), buf);
 196:	336000ef          	jal	4cc <getpid>
 19a:	85aa                	mv	a1,a0
 19c:	fd840613          	addi	a2,s0,-40
 1a0:	00001517          	auipc	a0,0x1
 1a4:	93050513          	addi	a0,a0,-1744 # ad0 <malloc+0x17e>
 1a8:	6ee000ef          	jal	896 <printf>

  close(c2p[0]);
 1ac:	fe042503          	lw	a0,-32(s0)
 1b0:	2c4000ef          	jal	474 <close>
  wait(0);
 1b4:	4501                	li	a0,0
 1b6:	29e000ef          	jal	454 <wait>
  exit(0);
 1ba:	4501                	li	a0,0
 1bc:	290000ef          	jal	44c <exit>

00000000000001c0 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 1c0:	1141                	addi	sp,sp,-16
 1c2:	e406                	sd	ra,8(sp)
 1c4:	e022                	sd	s0,0(sp)
 1c6:	0800                	addi	s0,sp,16
  extern int main();
  main();
 1c8:	e85ff0ef          	jal	4c <main>
  exit(0);
 1cc:	4501                	li	a0,0
 1ce:	27e000ef          	jal	44c <exit>

00000000000001d2 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 1d2:	1141                	addi	sp,sp,-16
 1d4:	e406                	sd	ra,8(sp)
 1d6:	e022                	sd	s0,0(sp)
 1d8:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 1da:	87aa                	mv	a5,a0
 1dc:	0585                	addi	a1,a1,1
 1de:	0785                	addi	a5,a5,1
 1e0:	fff5c703          	lbu	a4,-1(a1)
 1e4:	fee78fa3          	sb	a4,-1(a5)
 1e8:	fb75                	bnez	a4,1dc <strcpy+0xa>
    ;
  return os;
}
 1ea:	60a2                	ld	ra,8(sp)
 1ec:	6402                	ld	s0,0(sp)
 1ee:	0141                	addi	sp,sp,16
 1f0:	8082                	ret

00000000000001f2 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 1f2:	1141                	addi	sp,sp,-16
 1f4:	e406                	sd	ra,8(sp)
 1f6:	e022                	sd	s0,0(sp)
 1f8:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 1fa:	00054783          	lbu	a5,0(a0)
 1fe:	cb91                	beqz	a5,212 <strcmp+0x20>
 200:	0005c703          	lbu	a4,0(a1)
 204:	00f71763          	bne	a4,a5,212 <strcmp+0x20>
    p++, q++;
 208:	0505                	addi	a0,a0,1
 20a:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 20c:	00054783          	lbu	a5,0(a0)
 210:	fbe5                	bnez	a5,200 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 212:	0005c503          	lbu	a0,0(a1)
}
 216:	40a7853b          	subw	a0,a5,a0
 21a:	60a2                	ld	ra,8(sp)
 21c:	6402                	ld	s0,0(sp)
 21e:	0141                	addi	sp,sp,16
 220:	8082                	ret

0000000000000222 <strlen>:

uint
strlen(const char *s)
{
 222:	1141                	addi	sp,sp,-16
 224:	e406                	sd	ra,8(sp)
 226:	e022                	sd	s0,0(sp)
 228:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 22a:	00054783          	lbu	a5,0(a0)
 22e:	cf91                	beqz	a5,24a <strlen+0x28>
 230:	00150793          	addi	a5,a0,1
 234:	86be                	mv	a3,a5
 236:	0785                	addi	a5,a5,1
 238:	fff7c703          	lbu	a4,-1(a5)
 23c:	ff65                	bnez	a4,234 <strlen+0x12>
 23e:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 242:	60a2                	ld	ra,8(sp)
 244:	6402                	ld	s0,0(sp)
 246:	0141                	addi	sp,sp,16
 248:	8082                	ret
  for(n = 0; s[n]; n++)
 24a:	4501                	li	a0,0
 24c:	bfdd                	j	242 <strlen+0x20>

000000000000024e <memset>:

void*
memset(void *dst, int c, uint n)
{
 24e:	1141                	addi	sp,sp,-16
 250:	e406                	sd	ra,8(sp)
 252:	e022                	sd	s0,0(sp)
 254:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 256:	ca19                	beqz	a2,26c <memset+0x1e>
 258:	87aa                	mv	a5,a0
 25a:	1602                	slli	a2,a2,0x20
 25c:	9201                	srli	a2,a2,0x20
 25e:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 262:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 266:	0785                	addi	a5,a5,1
 268:	fee79de3          	bne	a5,a4,262 <memset+0x14>
  }
  return dst;
}
 26c:	60a2                	ld	ra,8(sp)
 26e:	6402                	ld	s0,0(sp)
 270:	0141                	addi	sp,sp,16
 272:	8082                	ret

0000000000000274 <strchr>:

char*
strchr(const char *s, char c)
{
 274:	1141                	addi	sp,sp,-16
 276:	e406                	sd	ra,8(sp)
 278:	e022                	sd	s0,0(sp)
 27a:	0800                	addi	s0,sp,16
  for(; *s; s++)
 27c:	00054783          	lbu	a5,0(a0)
 280:	c799                	beqz	a5,28e <strchr+0x1a>
    if(*s == c)
 282:	00f58763          	beq	a1,a5,290 <strchr+0x1c>
  for(; *s; s++)
 286:	0505                	addi	a0,a0,1
 288:	00054783          	lbu	a5,0(a0)
 28c:	fbfd                	bnez	a5,282 <strchr+0xe>
      return (char*)s;
  return 0;
 28e:	4501                	li	a0,0
}
 290:	60a2                	ld	ra,8(sp)
 292:	6402                	ld	s0,0(sp)
 294:	0141                	addi	sp,sp,16
 296:	8082                	ret

0000000000000298 <gets>:

char*
gets(char *buf, int max)
{
 298:	711d                	addi	sp,sp,-96
 29a:	ec86                	sd	ra,88(sp)
 29c:	e8a2                	sd	s0,80(sp)
 29e:	e4a6                	sd	s1,72(sp)
 2a0:	e0ca                	sd	s2,64(sp)
 2a2:	fc4e                	sd	s3,56(sp)
 2a4:	f852                	sd	s4,48(sp)
 2a6:	f456                	sd	s5,40(sp)
 2a8:	f05a                	sd	s6,32(sp)
 2aa:	ec5e                	sd	s7,24(sp)
 2ac:	e862                	sd	s8,16(sp)
 2ae:	1080                	addi	s0,sp,96
 2b0:	8baa                	mv	s7,a0
 2b2:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 2b4:	892a                	mv	s2,a0
 2b6:	4481                	li	s1,0
    cc = read(0, &c, 1);
 2b8:	faf40b13          	addi	s6,s0,-81
 2bc:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 2be:	8c26                	mv	s8,s1
 2c0:	0014899b          	addiw	s3,s1,1
 2c4:	84ce                	mv	s1,s3
 2c6:	0349d863          	bge	s3,s4,2f6 <gets+0x5e>
    cc = read(0, &c, 1);
 2ca:	8656                	mv	a2,s5
 2cc:	85da                	mv	a1,s6
 2ce:	4501                	li	a0,0
 2d0:	194000ef          	jal	464 <read>
    if(cc < 1)
 2d4:	02a05163          	blez	a0,2f6 <gets+0x5e>
      break;
    buf[i++] = c;
 2d8:	faf44783          	lbu	a5,-81(s0)
 2dc:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 2e0:	0905                	addi	s2,s2,1
 2e2:	ff678713          	addi	a4,a5,-10
 2e6:	00173713          	seqz	a4,a4
 2ea:	17cd                	addi	a5,a5,-13
 2ec:	0017b793          	seqz	a5,a5
 2f0:	8fd9                	or	a5,a5,a4
 2f2:	d7f1                	beqz	a5,2be <gets+0x26>
    buf[i++] = c;
 2f4:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 2f6:	9c5e                	add	s8,s8,s7
 2f8:	000c0023          	sb	zero,0(s8)
  return buf;
}
 2fc:	855e                	mv	a0,s7
 2fe:	60e6                	ld	ra,88(sp)
 300:	6446                	ld	s0,80(sp)
 302:	64a6                	ld	s1,72(sp)
 304:	6906                	ld	s2,64(sp)
 306:	79e2                	ld	s3,56(sp)
 308:	7a42                	ld	s4,48(sp)
 30a:	7aa2                	ld	s5,40(sp)
 30c:	7b02                	ld	s6,32(sp)
 30e:	6be2                	ld	s7,24(sp)
 310:	6c42                	ld	s8,16(sp)
 312:	6125                	addi	sp,sp,96
 314:	8082                	ret

0000000000000316 <stat>:

int
stat(const char *n, struct stat *st)
{
 316:	1101                	addi	sp,sp,-32
 318:	ec06                	sd	ra,24(sp)
 31a:	e822                	sd	s0,16(sp)
 31c:	e04a                	sd	s2,0(sp)
 31e:	1000                	addi	s0,sp,32
 320:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 322:	4581                	li	a1,0
 324:	168000ef          	jal	48c <open>
  if(fd < 0)
 328:	02054263          	bltz	a0,34c <stat+0x36>
 32c:	e426                	sd	s1,8(sp)
 32e:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 330:	85ca                	mv	a1,s2
 332:	172000ef          	jal	4a4 <fstat>
 336:	892a                	mv	s2,a0
  close(fd);
 338:	8526                	mv	a0,s1
 33a:	13a000ef          	jal	474 <close>
  return r;
 33e:	64a2                	ld	s1,8(sp)
}
 340:	854a                	mv	a0,s2
 342:	60e2                	ld	ra,24(sp)
 344:	6442                	ld	s0,16(sp)
 346:	6902                	ld	s2,0(sp)
 348:	6105                	addi	sp,sp,32
 34a:	8082                	ret
    return -1;
 34c:	57fd                	li	a5,-1
 34e:	893e                	mv	s2,a5
 350:	bfc5                	j	340 <stat+0x2a>

0000000000000352 <atoi>:

int
atoi(const char *s)
{
 352:	1141                	addi	sp,sp,-16
 354:	e406                	sd	ra,8(sp)
 356:	e022                	sd	s0,0(sp)
 358:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 35a:	00054683          	lbu	a3,0(a0)
 35e:	fd06879b          	addiw	a5,a3,-48
 362:	0ff7f793          	zext.b	a5,a5
 366:	4625                	li	a2,9
 368:	02f66963          	bltu	a2,a5,39a <atoi+0x48>
 36c:	872a                	mv	a4,a0
  n = 0;
 36e:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 370:	0705                	addi	a4,a4,1
 372:	0025179b          	slliw	a5,a0,0x2
 376:	9fa9                	addw	a5,a5,a0
 378:	0017979b          	slliw	a5,a5,0x1
 37c:	9fb5                	addw	a5,a5,a3
 37e:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 382:	00074683          	lbu	a3,0(a4)
 386:	fd06879b          	addiw	a5,a3,-48
 38a:	0ff7f793          	zext.b	a5,a5
 38e:	fef671e3          	bgeu	a2,a5,370 <atoi+0x1e>
  return n;
}
 392:	60a2                	ld	ra,8(sp)
 394:	6402                	ld	s0,0(sp)
 396:	0141                	addi	sp,sp,16
 398:	8082                	ret
  n = 0;
 39a:	4501                	li	a0,0
 39c:	bfdd                	j	392 <atoi+0x40>

000000000000039e <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 39e:	1141                	addi	sp,sp,-16
 3a0:	e406                	sd	ra,8(sp)
 3a2:	e022                	sd	s0,0(sp)
 3a4:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 3a6:	02b57563          	bgeu	a0,a1,3d0 <memmove+0x32>
    while(n-- > 0)
 3aa:	00c05f63          	blez	a2,3c8 <memmove+0x2a>
 3ae:	1602                	slli	a2,a2,0x20
 3b0:	9201                	srli	a2,a2,0x20
 3b2:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 3b6:	872a                	mv	a4,a0
      *dst++ = *src++;
 3b8:	0585                	addi	a1,a1,1
 3ba:	0705                	addi	a4,a4,1
 3bc:	fff5c683          	lbu	a3,-1(a1)
 3c0:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 3c4:	fee79ae3          	bne	a5,a4,3b8 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 3c8:	60a2                	ld	ra,8(sp)
 3ca:	6402                	ld	s0,0(sp)
 3cc:	0141                	addi	sp,sp,16
 3ce:	8082                	ret
    while(n-- > 0)
 3d0:	fec05ce3          	blez	a2,3c8 <memmove+0x2a>
    dst += n;
 3d4:	00c50733          	add	a4,a0,a2
    src += n;
 3d8:	95b2                	add	a1,a1,a2
 3da:	fff6079b          	addiw	a5,a2,-1
 3de:	1782                	slli	a5,a5,0x20
 3e0:	9381                	srli	a5,a5,0x20
 3e2:	fff7c793          	not	a5,a5
 3e6:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 3e8:	15fd                	addi	a1,a1,-1
 3ea:	177d                	addi	a4,a4,-1
 3ec:	0005c683          	lbu	a3,0(a1)
 3f0:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 3f4:	fef71ae3          	bne	a4,a5,3e8 <memmove+0x4a>
 3f8:	bfc1                	j	3c8 <memmove+0x2a>

00000000000003fa <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 3fa:	1141                	addi	sp,sp,-16
 3fc:	e406                	sd	ra,8(sp)
 3fe:	e022                	sd	s0,0(sp)
 400:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 402:	ce19                	beqz	a2,420 <memcmp+0x26>
 404:	1602                	slli	a2,a2,0x20
 406:	9201                	srli	a2,a2,0x20
 408:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 40c:	00054783          	lbu	a5,0(a0)
 410:	0005c703          	lbu	a4,0(a1)
 414:	00e79b63          	bne	a5,a4,42a <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 418:	0505                	addi	a0,a0,1
    p2++;
 41a:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 41c:	fed518e3          	bne	a0,a3,40c <memcmp+0x12>
  }
  return 0;
 420:	4501                	li	a0,0
}
 422:	60a2                	ld	ra,8(sp)
 424:	6402                	ld	s0,0(sp)
 426:	0141                	addi	sp,sp,16
 428:	8082                	ret
      return *p1 - *p2;
 42a:	40e7853b          	subw	a0,a5,a4
 42e:	bfd5                	j	422 <memcmp+0x28>

0000000000000430 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 430:	1141                	addi	sp,sp,-16
 432:	e406                	sd	ra,8(sp)
 434:	e022                	sd	s0,0(sp)
 436:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 438:	f67ff0ef          	jal	39e <memmove>
}
 43c:	60a2                	ld	ra,8(sp)
 43e:	6402                	ld	s0,0(sp)
 440:	0141                	addi	sp,sp,16
 442:	8082                	ret

0000000000000444 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 444:	4885                	li	a7,1
 ecall
 446:	00000073          	ecall
 ret
 44a:	8082                	ret

000000000000044c <exit>:
.global exit
exit:
 li a7, SYS_exit
 44c:	4889                	li	a7,2
 ecall
 44e:	00000073          	ecall
 ret
 452:	8082                	ret

0000000000000454 <wait>:
.global wait
wait:
 li a7, SYS_wait
 454:	488d                	li	a7,3
 ecall
 456:	00000073          	ecall
 ret
 45a:	8082                	ret

000000000000045c <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 45c:	4891                	li	a7,4
 ecall
 45e:	00000073          	ecall
 ret
 462:	8082                	ret

0000000000000464 <read>:
.global read
read:
 li a7, SYS_read
 464:	4895                	li	a7,5
 ecall
 466:	00000073          	ecall
 ret
 46a:	8082                	ret

000000000000046c <write>:
.global write
write:
 li a7, SYS_write
 46c:	48c1                	li	a7,16
 ecall
 46e:	00000073          	ecall
 ret
 472:	8082                	ret

0000000000000474 <close>:
.global close
close:
 li a7, SYS_close
 474:	48d5                	li	a7,21
 ecall
 476:	00000073          	ecall
 ret
 47a:	8082                	ret

000000000000047c <kill>:
.global kill
kill:
 li a7, SYS_kill
 47c:	4899                	li	a7,6
 ecall
 47e:	00000073          	ecall
 ret
 482:	8082                	ret

0000000000000484 <exec>:
.global exec
exec:
 li a7, SYS_exec
 484:	489d                	li	a7,7
 ecall
 486:	00000073          	ecall
 ret
 48a:	8082                	ret

000000000000048c <open>:
.global open
open:
 li a7, SYS_open
 48c:	48bd                	li	a7,15
 ecall
 48e:	00000073          	ecall
 ret
 492:	8082                	ret

0000000000000494 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 494:	48c5                	li	a7,17
 ecall
 496:	00000073          	ecall
 ret
 49a:	8082                	ret

000000000000049c <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 49c:	48c9                	li	a7,18
 ecall
 49e:	00000073          	ecall
 ret
 4a2:	8082                	ret

00000000000004a4 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 4a4:	48a1                	li	a7,8
 ecall
 4a6:	00000073          	ecall
 ret
 4aa:	8082                	ret

00000000000004ac <link>:
.global link
link:
 li a7, SYS_link
 4ac:	48cd                	li	a7,19
 ecall
 4ae:	00000073          	ecall
 ret
 4b2:	8082                	ret

00000000000004b4 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 4b4:	48d1                	li	a7,20
 ecall
 4b6:	00000073          	ecall
 ret
 4ba:	8082                	ret

00000000000004bc <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 4bc:	48a5                	li	a7,9
 ecall
 4be:	00000073          	ecall
 ret
 4c2:	8082                	ret

00000000000004c4 <dup>:
.global dup
dup:
 li a7, SYS_dup
 4c4:	48a9                	li	a7,10
 ecall
 4c6:	00000073          	ecall
 ret
 4ca:	8082                	ret

00000000000004cc <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 4cc:	48ad                	li	a7,11
 ecall
 4ce:	00000073          	ecall
 ret
 4d2:	8082                	ret

00000000000004d4 <getproccount>:
.global getproccount
getproccount:
 li a7, SYS_getproccount
 4d4:	48d9                	li	a7,22
 ecall
 4d6:	00000073          	ecall
 ret
 4da:	8082                	ret

00000000000004dc <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 4dc:	48b1                	li	a7,12
 ecall
 4de:	00000073          	ecall
 ret
 4e2:	8082                	ret

00000000000004e4 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 4e4:	48b5                	li	a7,13
 ecall
 4e6:	00000073          	ecall
 ret
 4ea:	8082                	ret

00000000000004ec <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 4ec:	48b9                	li	a7,14
 ecall
 4ee:	00000073          	ecall
 ret
 4f2:	8082                	ret

00000000000004f4 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 4f4:	1101                	addi	sp,sp,-32
 4f6:	ec06                	sd	ra,24(sp)
 4f8:	e822                	sd	s0,16(sp)
 4fa:	1000                	addi	s0,sp,32
 4fc:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 500:	4605                	li	a2,1
 502:	fef40593          	addi	a1,s0,-17
 506:	f67ff0ef          	jal	46c <write>
}
 50a:	60e2                	ld	ra,24(sp)
 50c:	6442                	ld	s0,16(sp)
 50e:	6105                	addi	sp,sp,32
 510:	8082                	ret

0000000000000512 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 512:	715d                	addi	sp,sp,-80
 514:	e486                	sd	ra,72(sp)
 516:	e0a2                	sd	s0,64(sp)
 518:	f84a                	sd	s2,48(sp)
 51a:	f44e                	sd	s3,40(sp)
 51c:	0880                	addi	s0,sp,80
 51e:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 520:	00d036b3          	snez	a3,a3
 524:	03f5d793          	srli	a5,a1,0x3f
 528:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 52a:	0005871b          	sext.w	a4,a1
  neg = 0;
 52e:	4301                	li	t1,0
  if(sgn && xx < 0){
 530:	c681                	beqz	a3,538 <printint+0x26>
    x = -xx;
 532:	40b0073b          	negw	a4,a1
    neg = 1;
 536:	4305                	li	t1,1
  }

  i = 0;
 538:	fb840993          	addi	s3,s0,-72
  neg = 0;
 53c:	85ce                	mv	a1,s3
  i = 0;
 53e:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 540:	00000817          	auipc	a6,0x0
 544:	5f080813          	addi	a6,a6,1520 # b30 <digits>
 548:	88b6                	mv	a7,a3
 54a:	0016851b          	addiw	a0,a3,1
 54e:	86aa                	mv	a3,a0
 550:	02c777bb          	remuw	a5,a4,a2
 554:	1782                	slli	a5,a5,0x20
 556:	9381                	srli	a5,a5,0x20
 558:	97c2                	add	a5,a5,a6
 55a:	0007c783          	lbu	a5,0(a5)
 55e:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 562:	87ba                	mv	a5,a4
 564:	02c7573b          	divuw	a4,a4,a2
 568:	0585                	addi	a1,a1,1
 56a:	fcc7ffe3          	bgeu	a5,a2,548 <printint+0x36>
  if(neg)
 56e:	00030b63          	beqz	t1,584 <printint+0x72>
    buf[i++] = '-';
 572:	fd040793          	addi	a5,s0,-48
 576:	953e                	add	a0,a0,a5
 578:	02d00793          	li	a5,45
 57c:	fef50423          	sb	a5,-24(a0)
 580:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 584:	02d05563          	blez	a3,5ae <printint+0x9c>
 588:	fc26                	sd	s1,56(sp)
 58a:	36fd                	addiw	a3,a3,-1
 58c:	00d984b3          	add	s1,s3,a3
 590:	19fd                	addi	s3,s3,-1
 592:	99b6                	add	s3,s3,a3
 594:	1682                	slli	a3,a3,0x20
 596:	9281                	srli	a3,a3,0x20
 598:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 59c:	0004c583          	lbu	a1,0(s1)
 5a0:	854a                	mv	a0,s2
 5a2:	f53ff0ef          	jal	4f4 <putc>
  while(--i >= 0)
 5a6:	14fd                	addi	s1,s1,-1
 5a8:	ff349ae3          	bne	s1,s3,59c <printint+0x8a>
 5ac:	74e2                	ld	s1,56(sp)
}
 5ae:	60a6                	ld	ra,72(sp)
 5b0:	6406                	ld	s0,64(sp)
 5b2:	7942                	ld	s2,48(sp)
 5b4:	79a2                	ld	s3,40(sp)
 5b6:	6161                	addi	sp,sp,80
 5b8:	8082                	ret

00000000000005ba <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 5ba:	711d                	addi	sp,sp,-96
 5bc:	ec86                	sd	ra,88(sp)
 5be:	e8a2                	sd	s0,80(sp)
 5c0:	e4a6                	sd	s1,72(sp)
 5c2:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 5c4:	0005c483          	lbu	s1,0(a1)
 5c8:	28048263          	beqz	s1,84c <vprintf+0x292>
 5cc:	e0ca                	sd	s2,64(sp)
 5ce:	fc4e                	sd	s3,56(sp)
 5d0:	f852                	sd	s4,48(sp)
 5d2:	f456                	sd	s5,40(sp)
 5d4:	f05a                	sd	s6,32(sp)
 5d6:	ec5e                	sd	s7,24(sp)
 5d8:	e862                	sd	s8,16(sp)
 5da:	8b2a                	mv	s6,a0
 5dc:	8a2e                	mv	s4,a1
 5de:	8bb2                	mv	s7,a2
  state = 0;
 5e0:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 5e2:	4901                	li	s2,0
 5e4:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 5e6:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 5ea:	06400c13          	li	s8,100
 5ee:	a00d                	j	610 <vprintf+0x56>
        putc(fd, c0);
 5f0:	85a6                	mv	a1,s1
 5f2:	855a                	mv	a0,s6
 5f4:	f01ff0ef          	jal	4f4 <putc>
 5f8:	a019                	j	5fe <vprintf+0x44>
    } else if(state == '%'){
 5fa:	03598363          	beq	s3,s5,620 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 5fe:	0019079b          	addiw	a5,s2,1
 602:	893e                	mv	s2,a5
 604:	873e                	mv	a4,a5
 606:	97d2                	add	a5,a5,s4
 608:	0007c483          	lbu	s1,0(a5)
 60c:	22048963          	beqz	s1,83e <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 610:	0004879b          	sext.w	a5,s1
    if(state == 0){
 614:	fe0993e3          	bnez	s3,5fa <vprintf+0x40>
      if(c0 == '%'){
 618:	fd579ce3          	bne	a5,s5,5f0 <vprintf+0x36>
        state = '%';
 61c:	89be                	mv	s3,a5
 61e:	b7c5                	j	5fe <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 620:	00ea06b3          	add	a3,s4,a4
 624:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 628:	22060763          	beqz	a2,856 <vprintf+0x29c>
      if(c0 == 'd'){
 62c:	0b878363          	beq	a5,s8,6d2 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 630:	f9478693          	addi	a3,a5,-108
 634:	0016b693          	seqz	a3,a3
 638:	f9c60593          	addi	a1,a2,-100
 63c:	0015b593          	seqz	a1,a1
 640:	8df5                	and	a1,a1,a3
 642:	e5c5                	bnez	a1,6ea <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 644:	9752                	add	a4,a4,s4
 646:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 64a:	f9460713          	addi	a4,a2,-108
 64e:	00173713          	seqz	a4,a4
 652:	8f75                	and	a4,a4,a3
 654:	f9c50593          	addi	a1,a0,-100
 658:	0015b593          	seqz	a1,a1
 65c:	8df9                	and	a1,a1,a4
 65e:	e1dd                	bnez	a1,704 <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 660:	07500593          	li	a1,117
 664:	0ab78d63          	beq	a5,a1,71e <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 668:	f8b60593          	addi	a1,a2,-117
 66c:	0015b593          	seqz	a1,a1
 670:	8df5                	and	a1,a1,a3
 672:	e1f1                	bnez	a1,736 <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 674:	f8b50593          	addi	a1,a0,-117
 678:	0015b593          	seqz	a1,a1
 67c:	8df9                	and	a1,a1,a4
 67e:	e9e9                	bnez	a1,750 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 680:	07800593          	li	a1,120
 684:	0eb78363          	beq	a5,a1,76a <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 688:	f8860613          	addi	a2,a2,-120
 68c:	00163613          	seqz	a2,a2
 690:	8ef1                	and	a3,a3,a2
 692:	0e069863          	bnez	a3,782 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 696:	f8850513          	addi	a0,a0,-120
 69a:	00153513          	seqz	a0,a0
 69e:	8f69                	and	a4,a4,a0
 6a0:	0e071e63          	bnez	a4,79c <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 6a4:	07000713          	li	a4,112
 6a8:	10e78663          	beq	a5,a4,7b4 <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 6ac:	07300713          	li	a4,115
 6b0:	14e78663          	beq	a5,a4,7fc <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 6b4:	02500713          	li	a4,37
 6b8:	16e78e63          	beq	a5,a4,834 <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 6bc:	02500593          	li	a1,37
 6c0:	855a                	mv	a0,s6
 6c2:	e33ff0ef          	jal	4f4 <putc>
        putc(fd, c0);
 6c6:	85a6                	mv	a1,s1
 6c8:	855a                	mv	a0,s6
 6ca:	e2bff0ef          	jal	4f4 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 6ce:	4981                	li	s3,0
 6d0:	b73d                	j	5fe <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 6d2:	008b8493          	addi	s1,s7,8
 6d6:	4685                	li	a3,1
 6d8:	4629                	li	a2,10
 6da:	000ba583          	lw	a1,0(s7)
 6de:	855a                	mv	a0,s6
 6e0:	e33ff0ef          	jal	512 <printint>
 6e4:	8ba6                	mv	s7,s1
      state = 0;
 6e6:	4981                	li	s3,0
 6e8:	bf19                	j	5fe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 6ea:	008b8493          	addi	s1,s7,8
 6ee:	4685                	li	a3,1
 6f0:	4629                	li	a2,10
 6f2:	000bb583          	ld	a1,0(s7)
 6f6:	855a                	mv	a0,s6
 6f8:	e1bff0ef          	jal	512 <printint>
        i += 1;
 6fc:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 6fe:	8ba6                	mv	s7,s1
      state = 0;
 700:	4981                	li	s3,0
 702:	bdf5                	j	5fe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 704:	008b8493          	addi	s1,s7,8
 708:	4685                	li	a3,1
 70a:	4629                	li	a2,10
 70c:	000bb583          	ld	a1,0(s7)
 710:	855a                	mv	a0,s6
 712:	e01ff0ef          	jal	512 <printint>
        i += 2;
 716:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 718:	8ba6                	mv	s7,s1
      state = 0;
 71a:	4981                	li	s3,0
        i += 2;
 71c:	b5cd                	j	5fe <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 71e:	008b8493          	addi	s1,s7,8
 722:	4681                	li	a3,0
 724:	4629                	li	a2,10
 726:	000ba583          	lw	a1,0(s7)
 72a:	855a                	mv	a0,s6
 72c:	de7ff0ef          	jal	512 <printint>
 730:	8ba6                	mv	s7,s1
      state = 0;
 732:	4981                	li	s3,0
 734:	b5e9                	j	5fe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 736:	008b8493          	addi	s1,s7,8
 73a:	4681                	li	a3,0
 73c:	4629                	li	a2,10
 73e:	000bb583          	ld	a1,0(s7)
 742:	855a                	mv	a0,s6
 744:	dcfff0ef          	jal	512 <printint>
        i += 1;
 748:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 74a:	8ba6                	mv	s7,s1
      state = 0;
 74c:	4981                	li	s3,0
 74e:	bd45                	j	5fe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 750:	008b8493          	addi	s1,s7,8
 754:	4681                	li	a3,0
 756:	4629                	li	a2,10
 758:	000bb583          	ld	a1,0(s7)
 75c:	855a                	mv	a0,s6
 75e:	db5ff0ef          	jal	512 <printint>
        i += 2;
 762:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 764:	8ba6                	mv	s7,s1
      state = 0;
 766:	4981                	li	s3,0
        i += 2;
 768:	bd59                	j	5fe <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 76a:	008b8493          	addi	s1,s7,8
 76e:	4681                	li	a3,0
 770:	4641                	li	a2,16
 772:	000ba583          	lw	a1,0(s7)
 776:	855a                	mv	a0,s6
 778:	d9bff0ef          	jal	512 <printint>
 77c:	8ba6                	mv	s7,s1
      state = 0;
 77e:	4981                	li	s3,0
 780:	bdbd                	j	5fe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 782:	008b8493          	addi	s1,s7,8
 786:	4681                	li	a3,0
 788:	4641                	li	a2,16
 78a:	000bb583          	ld	a1,0(s7)
 78e:	855a                	mv	a0,s6
 790:	d83ff0ef          	jal	512 <printint>
        i += 1;
 794:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 796:	8ba6                	mv	s7,s1
      state = 0;
 798:	4981                	li	s3,0
 79a:	b595                	j	5fe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 79c:	008b8493          	addi	s1,s7,8
 7a0:	4641                	li	a2,16
 7a2:	000bb583          	ld	a1,0(s7)
 7a6:	855a                	mv	a0,s6
 7a8:	d6bff0ef          	jal	512 <printint>
        i += 2;
 7ac:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 7ae:	8ba6                	mv	s7,s1
      state = 0;
 7b0:	4981                	li	s3,0
        i += 2;
 7b2:	b5b1                	j	5fe <vprintf+0x44>
 7b4:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 7b6:	008b8793          	addi	a5,s7,8
 7ba:	8cbe                	mv	s9,a5
 7bc:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 7c0:	03000593          	li	a1,48
 7c4:	855a                	mv	a0,s6
 7c6:	d2fff0ef          	jal	4f4 <putc>
  putc(fd, 'x');
 7ca:	07800593          	li	a1,120
 7ce:	855a                	mv	a0,s6
 7d0:	d25ff0ef          	jal	4f4 <putc>
 7d4:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 7d6:	00000b97          	auipc	s7,0x0
 7da:	35ab8b93          	addi	s7,s7,858 # b30 <digits>
 7de:	03c9d793          	srli	a5,s3,0x3c
 7e2:	97de                	add	a5,a5,s7
 7e4:	0007c583          	lbu	a1,0(a5)
 7e8:	855a                	mv	a0,s6
 7ea:	d0bff0ef          	jal	4f4 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 7ee:	0992                	slli	s3,s3,0x4
 7f0:	34fd                	addiw	s1,s1,-1
 7f2:	f4f5                	bnez	s1,7de <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 7f4:	8be6                	mv	s7,s9
      state = 0;
 7f6:	4981                	li	s3,0
 7f8:	6ca2                	ld	s9,8(sp)
 7fa:	b511                	j	5fe <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 7fc:	008b8993          	addi	s3,s7,8
 800:	000bb483          	ld	s1,0(s7)
 804:	cc91                	beqz	s1,820 <vprintf+0x266>
        for(; *s; s++)
 806:	0004c583          	lbu	a1,0(s1)
 80a:	c195                	beqz	a1,82e <vprintf+0x274>
          putc(fd, *s);
 80c:	855a                	mv	a0,s6
 80e:	ce7ff0ef          	jal	4f4 <putc>
        for(; *s; s++)
 812:	0485                	addi	s1,s1,1
 814:	0004c583          	lbu	a1,0(s1)
 818:	f9f5                	bnez	a1,80c <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 81a:	8bce                	mv	s7,s3
      state = 0;
 81c:	4981                	li	s3,0
 81e:	b3c5                	j	5fe <vprintf+0x44>
          s = "(null)";
 820:	00000497          	auipc	s1,0x0
 824:	30848493          	addi	s1,s1,776 # b28 <malloc+0x1d6>
        for(; *s; s++)
 828:	02800593          	li	a1,40
 82c:	b7c5                	j	80c <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 82e:	8bce                	mv	s7,s3
      state = 0;
 830:	4981                	li	s3,0
 832:	b3f1                	j	5fe <vprintf+0x44>
        putc(fd, '%');
 834:	85be                	mv	a1,a5
 836:	855a                	mv	a0,s6
 838:	cbdff0ef          	jal	4f4 <putc>
 83c:	bd49                	j	6ce <vprintf+0x114>
 83e:	6906                	ld	s2,64(sp)
 840:	79e2                	ld	s3,56(sp)
 842:	7a42                	ld	s4,48(sp)
 844:	7aa2                	ld	s5,40(sp)
 846:	7b02                	ld	s6,32(sp)
 848:	6be2                	ld	s7,24(sp)
 84a:	6c42                	ld	s8,16(sp)
    }
  }
}
 84c:	60e6                	ld	ra,88(sp)
 84e:	6446                	ld	s0,80(sp)
 850:	64a6                	ld	s1,72(sp)
 852:	6125                	addi	sp,sp,96
 854:	8082                	ret
      if(c0 == 'd'){
 856:	06400713          	li	a4,100
 85a:	e6e78ce3          	beq	a5,a4,6d2 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 85e:	f9478693          	addi	a3,a5,-108
 862:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 866:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 868:	4701                	li	a4,0
 86a:	bbdd                	j	660 <vprintf+0xa6>

000000000000086c <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 86c:	715d                	addi	sp,sp,-80
 86e:	ec06                	sd	ra,24(sp)
 870:	e822                	sd	s0,16(sp)
 872:	1000                	addi	s0,sp,32
 874:	e010                	sd	a2,0(s0)
 876:	e414                	sd	a3,8(s0)
 878:	e818                	sd	a4,16(s0)
 87a:	ec1c                	sd	a5,24(s0)
 87c:	03043023          	sd	a6,32(s0)
 880:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 884:	8622                	mv	a2,s0
 886:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 88a:	d31ff0ef          	jal	5ba <vprintf>
}
 88e:	60e2                	ld	ra,24(sp)
 890:	6442                	ld	s0,16(sp)
 892:	6161                	addi	sp,sp,80
 894:	8082                	ret

0000000000000896 <printf>:

void
printf(const char *fmt, ...)
{
 896:	711d                	addi	sp,sp,-96
 898:	ec06                	sd	ra,24(sp)
 89a:	e822                	sd	s0,16(sp)
 89c:	1000                	addi	s0,sp,32
 89e:	e40c                	sd	a1,8(s0)
 8a0:	e810                	sd	a2,16(s0)
 8a2:	ec14                	sd	a3,24(s0)
 8a4:	f018                	sd	a4,32(s0)
 8a6:	f41c                	sd	a5,40(s0)
 8a8:	03043823          	sd	a6,48(s0)
 8ac:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 8b0:	00840613          	addi	a2,s0,8
 8b4:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 8b8:	85aa                	mv	a1,a0
 8ba:	4505                	li	a0,1
 8bc:	cffff0ef          	jal	5ba <vprintf>
}
 8c0:	60e2                	ld	ra,24(sp)
 8c2:	6442                	ld	s0,16(sp)
 8c4:	6125                	addi	sp,sp,96
 8c6:	8082                	ret

00000000000008c8 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 8c8:	1141                	addi	sp,sp,-16
 8ca:	e406                	sd	ra,8(sp)
 8cc:	e022                	sd	s0,0(sp)
 8ce:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 8d0:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8d4:	00000797          	auipc	a5,0x0
 8d8:	72c7b783          	ld	a5,1836(a5) # 1000 <freep>
 8dc:	a095                	j	940 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 8de:	ff852583          	lw	a1,-8(a0)
 8e2:	6390                	ld	a2,0(a5)
 8e4:	02059813          	slli	a6,a1,0x20
 8e8:	01c85693          	srli	a3,a6,0x1c
 8ec:	96ba                	add	a3,a3,a4
 8ee:	02d60563          	beq	a2,a3,918 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 8f2:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 8f6:	4790                	lw	a2,8(a5)
 8f8:	02061593          	slli	a1,a2,0x20
 8fc:	01c5d693          	srli	a3,a1,0x1c
 900:	96be                	add	a3,a3,a5
 902:	02d70263          	beq	a4,a3,926 <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 906:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 908:	00000717          	auipc	a4,0x0
 90c:	6ef73c23          	sd	a5,1784(a4) # 1000 <freep>
}
 910:	60a2                	ld	ra,8(sp)
 912:	6402                	ld	s0,0(sp)
 914:	0141                	addi	sp,sp,16
 916:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 918:	4614                	lw	a3,8(a2)
 91a:	9ead                	addw	a3,a3,a1
 91c:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 920:	6394                	ld	a3,0(a5)
 922:	6290                	ld	a2,0(a3)
 924:	b7f9                	j	8f2 <free+0x2a>
    p->s.size += bp->s.size;
 926:	ff852703          	lw	a4,-8(a0)
 92a:	9f31                	addw	a4,a4,a2
 92c:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 92e:	ff053703          	ld	a4,-16(a0)
 932:	bfd1                	j	906 <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 934:	6394                	ld	a3,0(a5)
 936:	00d7e463          	bltu	a5,a3,93e <free+0x76>
 93a:	fad762e3          	bltu	a4,a3,8de <free+0x16>
 93e:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 940:	fee7fae3          	bgeu	a5,a4,934 <free+0x6c>
 944:	6394                	ld	a3,0(a5)
 946:	f8d76ce3          	bltu	a4,a3,8de <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 94a:	f8d7fae3          	bgeu	a5,a3,8de <free+0x16>
 94e:	87b6                	mv	a5,a3
 950:	bfc5                	j	940 <free+0x78>

0000000000000952 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 952:	7139                	addi	sp,sp,-64
 954:	fc06                	sd	ra,56(sp)
 956:	f822                	sd	s0,48(sp)
 958:	f04a                	sd	s2,32(sp)
 95a:	ec4e                	sd	s3,24(sp)
 95c:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 95e:	02051993          	slli	s3,a0,0x20
 962:	0209d993          	srli	s3,s3,0x20
 966:	09bd                	addi	s3,s3,15
 968:	0049d993          	srli	s3,s3,0x4
 96c:	2985                	addiw	s3,s3,1
 96e:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 970:	00000517          	auipc	a0,0x0
 974:	69053503          	ld	a0,1680(a0) # 1000 <freep>
 978:	c905                	beqz	a0,9a8 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 97a:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 97c:	4798                	lw	a4,8(a5)
 97e:	09377663          	bgeu	a4,s3,a0a <malloc+0xb8>
 982:	f426                	sd	s1,40(sp)
 984:	e852                	sd	s4,16(sp)
 986:	e456                	sd	s5,8(sp)
 988:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 98a:	8a4e                	mv	s4,s3
 98c:	6705                	lui	a4,0x1
 98e:	00e9f363          	bgeu	s3,a4,994 <malloc+0x42>
 992:	6a05                	lui	s4,0x1
 994:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 998:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 99c:	00000497          	auipc	s1,0x0
 9a0:	66448493          	addi	s1,s1,1636 # 1000 <freep>
  if(p == (char*)-1)
 9a4:	5afd                	li	s5,-1
 9a6:	a83d                	j	9e4 <malloc+0x92>
 9a8:	f426                	sd	s1,40(sp)
 9aa:	e852                	sd	s4,16(sp)
 9ac:	e456                	sd	s5,8(sp)
 9ae:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 9b0:	00000797          	auipc	a5,0x0
 9b4:	66078793          	addi	a5,a5,1632 # 1010 <base>
 9b8:	00000717          	auipc	a4,0x0
 9bc:	64f73423          	sd	a5,1608(a4) # 1000 <freep>
 9c0:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 9c2:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 9c6:	b7d1                	j	98a <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 9c8:	6398                	ld	a4,0(a5)
 9ca:	e118                	sd	a4,0(a0)
 9cc:	a899                	j	a22 <malloc+0xd0>
  hp->s.size = nu;
 9ce:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 9d2:	0541                	addi	a0,a0,16
 9d4:	ef5ff0ef          	jal	8c8 <free>
  return freep;
 9d8:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 9da:	c125                	beqz	a0,a3a <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 9dc:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 9de:	4798                	lw	a4,8(a5)
 9e0:	03277163          	bgeu	a4,s2,a02 <malloc+0xb0>
    if(p == freep)
 9e4:	6098                	ld	a4,0(s1)
 9e6:	853e                	mv	a0,a5
 9e8:	fef71ae3          	bne	a4,a5,9dc <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 9ec:	8552                	mv	a0,s4
 9ee:	aefff0ef          	jal	4dc <sbrk>
  if(p == (char*)-1)
 9f2:	fd551ee3          	bne	a0,s5,9ce <malloc+0x7c>
        return 0;
 9f6:	4501                	li	a0,0
 9f8:	74a2                	ld	s1,40(sp)
 9fa:	6a42                	ld	s4,16(sp)
 9fc:	6aa2                	ld	s5,8(sp)
 9fe:	6b02                	ld	s6,0(sp)
 a00:	a03d                	j	a2e <malloc+0xdc>
 a02:	74a2                	ld	s1,40(sp)
 a04:	6a42                	ld	s4,16(sp)
 a06:	6aa2                	ld	s5,8(sp)
 a08:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 a0a:	fae90fe3          	beq	s2,a4,9c8 <malloc+0x76>
        p->s.size -= nunits;
 a0e:	4137073b          	subw	a4,a4,s3
 a12:	c798                	sw	a4,8(a5)
        p += p->s.size;
 a14:	02071693          	slli	a3,a4,0x20
 a18:	01c6d713          	srli	a4,a3,0x1c
 a1c:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 a1e:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 a22:	00000717          	auipc	a4,0x0
 a26:	5ca73f23          	sd	a0,1502(a4) # 1000 <freep>
      return (void*)(p + 1);
 a2a:	01078513          	addi	a0,a5,16
  }
}
 a2e:	70e2                	ld	ra,56(sp)
 a30:	7442                	ld	s0,48(sp)
 a32:	7902                	ld	s2,32(sp)
 a34:	69e2                	ld	s3,24(sp)
 a36:	6121                	addi	sp,sp,64
 a38:	8082                	ret
 a3a:	74a2                	ld	s1,40(sp)
 a3c:	6a42                	ld	s4,16(sp)
 a3e:	6aa2                	ld	s5,8(sp)
 a40:	6b02                	ld	s6,0(sp)
 a42:	b7f5                	j	a2e <malloc+0xdc>
