
user/_wc:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <wc>:

char buf[512];

void
wc(int fd, char *name)
{
   0:	7119                	addi	sp,sp,-128
   2:	fc86                	sd	ra,120(sp)
   4:	f8a2                	sd	s0,112(sp)
   6:	f4a6                	sd	s1,104(sp)
   8:	f0ca                	sd	s2,96(sp)
   a:	ecce                	sd	s3,88(sp)
   c:	e8d2                	sd	s4,80(sp)
   e:	e4d6                	sd	s5,72(sp)
  10:	e0da                	sd	s6,64(sp)
  12:	fc5e                	sd	s7,56(sp)
  14:	f862                	sd	s8,48(sp)
  16:	f466                	sd	s9,40(sp)
  18:	f06a                	sd	s10,32(sp)
  1a:	ec6e                	sd	s11,24(sp)
  1c:	0100                	addi	s0,sp,128
  1e:	f8a43423          	sd	a0,-120(s0)
  22:	f8b43023          	sd	a1,-128(s0)
  int i, n;
  int l, w, c, inword;

  l = w = c = 0;
  inword = 0;
  26:	4901                	li	s2,0
  l = w = c = 0;
  28:	4c81                	li	s9,0
  2a:	4c01                	li	s8,0
  2c:	4b81                	li	s7,0
  while((n = read(fd, buf, sizeof(buf))) > 0){
  2e:	20000d93          	li	s11,512
  32:	00001d17          	auipc	s10,0x1
  36:	fded0d13          	addi	s10,s10,-34 # 1010 <buf>
    for(i=0; i<n; i++){
      c++;
      if(buf[i] == '\n')
  3a:	4aa9                	li	s5,10
        l++;
      if(strchr(" \r\t\n\v", buf[i]))
  3c:	00001a17          	auipc	s4,0x1
  40:	9a4a0a13          	addi	s4,s4,-1628 # 9e0 <malloc+0xf2>
  while((n = read(fd, buf, sizeof(buf))) > 0){
  44:	a035                	j	70 <wc+0x70>
      if(strchr(" \r\t\n\v", buf[i]))
  46:	8552                	mv	a0,s4
  48:	1c8000ef          	jal	210 <strchr>
  4c:	c919                	beqz	a0,62 <wc+0x62>
        inword = 0;
  4e:	4901                	li	s2,0
    for(i=0; i<n; i++){
  50:	0485                	addi	s1,s1,1
  52:	01348d63          	beq	s1,s3,6c <wc+0x6c>
      if(buf[i] == '\n')
  56:	0004c583          	lbu	a1,0(s1)
  5a:	ff5596e3          	bne	a1,s5,46 <wc+0x46>
        l++;
  5e:	2b85                	addiw	s7,s7,1
  60:	b7dd                	j	46 <wc+0x46>
      else if(!inword){
  62:	fe0917e3          	bnez	s2,50 <wc+0x50>
        w++;
  66:	2c05                	addiw	s8,s8,1
        inword = 1;
  68:	4905                	li	s2,1
  6a:	b7dd                	j	50 <wc+0x50>
  6c:	019b0cbb          	addw	s9,s6,s9
  while((n = read(fd, buf, sizeof(buf))) > 0){
  70:	866e                	mv	a2,s11
  72:	85ea                	mv	a1,s10
  74:	f8843503          	ld	a0,-120(s0)
  78:	388000ef          	jal	400 <read>
  7c:	8b2a                	mv	s6,a0
  7e:	00a05963          	blez	a0,90 <wc+0x90>
  82:	00001497          	auipc	s1,0x1
  86:	f8e48493          	addi	s1,s1,-114 # 1010 <buf>
  8a:	009b09b3          	add	s3,s6,s1
  8e:	b7e1                	j	56 <wc+0x56>
      }
    }
  }
  if(n < 0){
  90:	02054c63          	bltz	a0,c8 <wc+0xc8>
    printf("wc: read error\n");
    exit(1);
  }
  printf("%d %d %d %s\n", l, w, c, name);
  94:	f8043703          	ld	a4,-128(s0)
  98:	86e6                	mv	a3,s9
  9a:	8662                	mv	a2,s8
  9c:	85de                	mv	a1,s7
  9e:	00001517          	auipc	a0,0x1
  a2:	96250513          	addi	a0,a0,-1694 # a00 <malloc+0x112>
  a6:	78c000ef          	jal	832 <printf>
}
  aa:	70e6                	ld	ra,120(sp)
  ac:	7446                	ld	s0,112(sp)
  ae:	74a6                	ld	s1,104(sp)
  b0:	7906                	ld	s2,96(sp)
  b2:	69e6                	ld	s3,88(sp)
  b4:	6a46                	ld	s4,80(sp)
  b6:	6aa6                	ld	s5,72(sp)
  b8:	6b06                	ld	s6,64(sp)
  ba:	7be2                	ld	s7,56(sp)
  bc:	7c42                	ld	s8,48(sp)
  be:	7ca2                	ld	s9,40(sp)
  c0:	7d02                	ld	s10,32(sp)
  c2:	6de2                	ld	s11,24(sp)
  c4:	6109                	addi	sp,sp,128
  c6:	8082                	ret
    printf("wc: read error\n");
  c8:	00001517          	auipc	a0,0x1
  cc:	92850513          	addi	a0,a0,-1752 # 9f0 <malloc+0x102>
  d0:	762000ef          	jal	832 <printf>
    exit(1);
  d4:	4505                	li	a0,1
  d6:	312000ef          	jal	3e8 <exit>

00000000000000da <main>:

int
main(int argc, char *argv[])
{
  da:	7179                	addi	sp,sp,-48
  dc:	f406                	sd	ra,40(sp)
  de:	f022                	sd	s0,32(sp)
  e0:	1800                	addi	s0,sp,48
  int fd, i;

  if(argc <= 1){
  e2:	4785                	li	a5,1
  e4:	04a7d463          	bge	a5,a0,12c <main+0x52>
  e8:	ec26                	sd	s1,24(sp)
  ea:	e84a                	sd	s2,16(sp)
  ec:	e44e                	sd	s3,8(sp)
  ee:	00858913          	addi	s2,a1,8
  f2:	ffe5099b          	addiw	s3,a0,-2
  f6:	02099793          	slli	a5,s3,0x20
  fa:	01d7d993          	srli	s3,a5,0x1d
  fe:	05c1                	addi	a1,a1,16
 100:	99ae                	add	s3,s3,a1
    wc(0, "");
    exit(0);
  }

  for(i = 1; i < argc; i++){
    if((fd = open(argv[i], O_RDONLY)) < 0){
 102:	4581                	li	a1,0
 104:	00093503          	ld	a0,0(s2)
 108:	320000ef          	jal	428 <open>
 10c:	84aa                	mv	s1,a0
 10e:	02054c63          	bltz	a0,146 <main+0x6c>
      printf("wc: cannot open %s\n", argv[i]);
      exit(1);
    }
    wc(fd, argv[i]);
 112:	00093583          	ld	a1,0(s2)
 116:	eebff0ef          	jal	0 <wc>
    close(fd);
 11a:	8526                	mv	a0,s1
 11c:	2f4000ef          	jal	410 <close>
  for(i = 1; i < argc; i++){
 120:	0921                	addi	s2,s2,8
 122:	ff3910e3          	bne	s2,s3,102 <main+0x28>
  }
  exit(0);
 126:	4501                	li	a0,0
 128:	2c0000ef          	jal	3e8 <exit>
 12c:	ec26                	sd	s1,24(sp)
 12e:	e84a                	sd	s2,16(sp)
 130:	e44e                	sd	s3,8(sp)
    wc(0, "");
 132:	00001597          	auipc	a1,0x1
 136:	8b658593          	addi	a1,a1,-1866 # 9e8 <malloc+0xfa>
 13a:	4501                	li	a0,0
 13c:	ec5ff0ef          	jal	0 <wc>
    exit(0);
 140:	4501                	li	a0,0
 142:	2a6000ef          	jal	3e8 <exit>
      printf("wc: cannot open %s\n", argv[i]);
 146:	00093583          	ld	a1,0(s2)
 14a:	00001517          	auipc	a0,0x1
 14e:	8c650513          	addi	a0,a0,-1850 # a10 <malloc+0x122>
 152:	6e0000ef          	jal	832 <printf>
      exit(1);
 156:	4505                	li	a0,1
 158:	290000ef          	jal	3e8 <exit>

000000000000015c <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 15c:	1141                	addi	sp,sp,-16
 15e:	e406                	sd	ra,8(sp)
 160:	e022                	sd	s0,0(sp)
 162:	0800                	addi	s0,sp,16
  extern int main();
  main();
 164:	f77ff0ef          	jal	da <main>
  exit(0);
 168:	4501                	li	a0,0
 16a:	27e000ef          	jal	3e8 <exit>

000000000000016e <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 16e:	1141                	addi	sp,sp,-16
 170:	e406                	sd	ra,8(sp)
 172:	e022                	sd	s0,0(sp)
 174:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 176:	87aa                	mv	a5,a0
 178:	0585                	addi	a1,a1,1
 17a:	0785                	addi	a5,a5,1
 17c:	fff5c703          	lbu	a4,-1(a1)
 180:	fee78fa3          	sb	a4,-1(a5)
 184:	fb75                	bnez	a4,178 <strcpy+0xa>
    ;
  return os;
}
 186:	60a2                	ld	ra,8(sp)
 188:	6402                	ld	s0,0(sp)
 18a:	0141                	addi	sp,sp,16
 18c:	8082                	ret

000000000000018e <strcmp>:

int
strcmp(const char *p, const char *q)
{
 18e:	1141                	addi	sp,sp,-16
 190:	e406                	sd	ra,8(sp)
 192:	e022                	sd	s0,0(sp)
 194:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 196:	00054783          	lbu	a5,0(a0)
 19a:	cb91                	beqz	a5,1ae <strcmp+0x20>
 19c:	0005c703          	lbu	a4,0(a1)
 1a0:	00f71763          	bne	a4,a5,1ae <strcmp+0x20>
    p++, q++;
 1a4:	0505                	addi	a0,a0,1
 1a6:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 1a8:	00054783          	lbu	a5,0(a0)
 1ac:	fbe5                	bnez	a5,19c <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 1ae:	0005c503          	lbu	a0,0(a1)
}
 1b2:	40a7853b          	subw	a0,a5,a0
 1b6:	60a2                	ld	ra,8(sp)
 1b8:	6402                	ld	s0,0(sp)
 1ba:	0141                	addi	sp,sp,16
 1bc:	8082                	ret

00000000000001be <strlen>:

uint
strlen(const char *s)
{
 1be:	1141                	addi	sp,sp,-16
 1c0:	e406                	sd	ra,8(sp)
 1c2:	e022                	sd	s0,0(sp)
 1c4:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 1c6:	00054783          	lbu	a5,0(a0)
 1ca:	cf91                	beqz	a5,1e6 <strlen+0x28>
 1cc:	00150793          	addi	a5,a0,1
 1d0:	86be                	mv	a3,a5
 1d2:	0785                	addi	a5,a5,1
 1d4:	fff7c703          	lbu	a4,-1(a5)
 1d8:	ff65                	bnez	a4,1d0 <strlen+0x12>
 1da:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 1de:	60a2                	ld	ra,8(sp)
 1e0:	6402                	ld	s0,0(sp)
 1e2:	0141                	addi	sp,sp,16
 1e4:	8082                	ret
  for(n = 0; s[n]; n++)
 1e6:	4501                	li	a0,0
 1e8:	bfdd                	j	1de <strlen+0x20>

00000000000001ea <memset>:

void*
memset(void *dst, int c, uint n)
{
 1ea:	1141                	addi	sp,sp,-16
 1ec:	e406                	sd	ra,8(sp)
 1ee:	e022                	sd	s0,0(sp)
 1f0:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 1f2:	ca19                	beqz	a2,208 <memset+0x1e>
 1f4:	87aa                	mv	a5,a0
 1f6:	1602                	slli	a2,a2,0x20
 1f8:	9201                	srli	a2,a2,0x20
 1fa:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 1fe:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 202:	0785                	addi	a5,a5,1
 204:	fee79de3          	bne	a5,a4,1fe <memset+0x14>
  }
  return dst;
}
 208:	60a2                	ld	ra,8(sp)
 20a:	6402                	ld	s0,0(sp)
 20c:	0141                	addi	sp,sp,16
 20e:	8082                	ret

0000000000000210 <strchr>:

char*
strchr(const char *s, char c)
{
 210:	1141                	addi	sp,sp,-16
 212:	e406                	sd	ra,8(sp)
 214:	e022                	sd	s0,0(sp)
 216:	0800                	addi	s0,sp,16
  for(; *s; s++)
 218:	00054783          	lbu	a5,0(a0)
 21c:	c799                	beqz	a5,22a <strchr+0x1a>
    if(*s == c)
 21e:	00f58763          	beq	a1,a5,22c <strchr+0x1c>
  for(; *s; s++)
 222:	0505                	addi	a0,a0,1
 224:	00054783          	lbu	a5,0(a0)
 228:	fbfd                	bnez	a5,21e <strchr+0xe>
      return (char*)s;
  return 0;
 22a:	4501                	li	a0,0
}
 22c:	60a2                	ld	ra,8(sp)
 22e:	6402                	ld	s0,0(sp)
 230:	0141                	addi	sp,sp,16
 232:	8082                	ret

0000000000000234 <gets>:

char*
gets(char *buf, int max)
{
 234:	711d                	addi	sp,sp,-96
 236:	ec86                	sd	ra,88(sp)
 238:	e8a2                	sd	s0,80(sp)
 23a:	e4a6                	sd	s1,72(sp)
 23c:	e0ca                	sd	s2,64(sp)
 23e:	fc4e                	sd	s3,56(sp)
 240:	f852                	sd	s4,48(sp)
 242:	f456                	sd	s5,40(sp)
 244:	f05a                	sd	s6,32(sp)
 246:	ec5e                	sd	s7,24(sp)
 248:	e862                	sd	s8,16(sp)
 24a:	1080                	addi	s0,sp,96
 24c:	8baa                	mv	s7,a0
 24e:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 250:	892a                	mv	s2,a0
 252:	4481                	li	s1,0
    cc = read(0, &c, 1);
 254:	faf40b13          	addi	s6,s0,-81
 258:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 25a:	8c26                	mv	s8,s1
 25c:	0014899b          	addiw	s3,s1,1
 260:	84ce                	mv	s1,s3
 262:	0349d863          	bge	s3,s4,292 <gets+0x5e>
    cc = read(0, &c, 1);
 266:	8656                	mv	a2,s5
 268:	85da                	mv	a1,s6
 26a:	4501                	li	a0,0
 26c:	194000ef          	jal	400 <read>
    if(cc < 1)
 270:	02a05163          	blez	a0,292 <gets+0x5e>
      break;
    buf[i++] = c;
 274:	faf44783          	lbu	a5,-81(s0)
 278:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 27c:	0905                	addi	s2,s2,1
 27e:	ff678713          	addi	a4,a5,-10
 282:	00173713          	seqz	a4,a4
 286:	17cd                	addi	a5,a5,-13
 288:	0017b793          	seqz	a5,a5
 28c:	8fd9                	or	a5,a5,a4
 28e:	d7f1                	beqz	a5,25a <gets+0x26>
    buf[i++] = c;
 290:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 292:	9c5e                	add	s8,s8,s7
 294:	000c0023          	sb	zero,0(s8)
  return buf;
}
 298:	855e                	mv	a0,s7
 29a:	60e6                	ld	ra,88(sp)
 29c:	6446                	ld	s0,80(sp)
 29e:	64a6                	ld	s1,72(sp)
 2a0:	6906                	ld	s2,64(sp)
 2a2:	79e2                	ld	s3,56(sp)
 2a4:	7a42                	ld	s4,48(sp)
 2a6:	7aa2                	ld	s5,40(sp)
 2a8:	7b02                	ld	s6,32(sp)
 2aa:	6be2                	ld	s7,24(sp)
 2ac:	6c42                	ld	s8,16(sp)
 2ae:	6125                	addi	sp,sp,96
 2b0:	8082                	ret

00000000000002b2 <stat>:

int
stat(const char *n, struct stat *st)
{
 2b2:	1101                	addi	sp,sp,-32
 2b4:	ec06                	sd	ra,24(sp)
 2b6:	e822                	sd	s0,16(sp)
 2b8:	e04a                	sd	s2,0(sp)
 2ba:	1000                	addi	s0,sp,32
 2bc:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 2be:	4581                	li	a1,0
 2c0:	168000ef          	jal	428 <open>
  if(fd < 0)
 2c4:	02054263          	bltz	a0,2e8 <stat+0x36>
 2c8:	e426                	sd	s1,8(sp)
 2ca:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 2cc:	85ca                	mv	a1,s2
 2ce:	172000ef          	jal	440 <fstat>
 2d2:	892a                	mv	s2,a0
  close(fd);
 2d4:	8526                	mv	a0,s1
 2d6:	13a000ef          	jal	410 <close>
  return r;
 2da:	64a2                	ld	s1,8(sp)
}
 2dc:	854a                	mv	a0,s2
 2de:	60e2                	ld	ra,24(sp)
 2e0:	6442                	ld	s0,16(sp)
 2e2:	6902                	ld	s2,0(sp)
 2e4:	6105                	addi	sp,sp,32
 2e6:	8082                	ret
    return -1;
 2e8:	57fd                	li	a5,-1
 2ea:	893e                	mv	s2,a5
 2ec:	bfc5                	j	2dc <stat+0x2a>

00000000000002ee <atoi>:

int
atoi(const char *s)
{
 2ee:	1141                	addi	sp,sp,-16
 2f0:	e406                	sd	ra,8(sp)
 2f2:	e022                	sd	s0,0(sp)
 2f4:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 2f6:	00054683          	lbu	a3,0(a0)
 2fa:	fd06879b          	addiw	a5,a3,-48
 2fe:	0ff7f793          	zext.b	a5,a5
 302:	4625                	li	a2,9
 304:	02f66963          	bltu	a2,a5,336 <atoi+0x48>
 308:	872a                	mv	a4,a0
  n = 0;
 30a:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 30c:	0705                	addi	a4,a4,1
 30e:	0025179b          	slliw	a5,a0,0x2
 312:	9fa9                	addw	a5,a5,a0
 314:	0017979b          	slliw	a5,a5,0x1
 318:	9fb5                	addw	a5,a5,a3
 31a:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 31e:	00074683          	lbu	a3,0(a4)
 322:	fd06879b          	addiw	a5,a3,-48
 326:	0ff7f793          	zext.b	a5,a5
 32a:	fef671e3          	bgeu	a2,a5,30c <atoi+0x1e>
  return n;
}
 32e:	60a2                	ld	ra,8(sp)
 330:	6402                	ld	s0,0(sp)
 332:	0141                	addi	sp,sp,16
 334:	8082                	ret
  n = 0;
 336:	4501                	li	a0,0
 338:	bfdd                	j	32e <atoi+0x40>

000000000000033a <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 33a:	1141                	addi	sp,sp,-16
 33c:	e406                	sd	ra,8(sp)
 33e:	e022                	sd	s0,0(sp)
 340:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 342:	02b57563          	bgeu	a0,a1,36c <memmove+0x32>
    while(n-- > 0)
 346:	00c05f63          	blez	a2,364 <memmove+0x2a>
 34a:	1602                	slli	a2,a2,0x20
 34c:	9201                	srli	a2,a2,0x20
 34e:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 352:	872a                	mv	a4,a0
      *dst++ = *src++;
 354:	0585                	addi	a1,a1,1
 356:	0705                	addi	a4,a4,1
 358:	fff5c683          	lbu	a3,-1(a1)
 35c:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 360:	fee79ae3          	bne	a5,a4,354 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 364:	60a2                	ld	ra,8(sp)
 366:	6402                	ld	s0,0(sp)
 368:	0141                	addi	sp,sp,16
 36a:	8082                	ret
    while(n-- > 0)
 36c:	fec05ce3          	blez	a2,364 <memmove+0x2a>
    dst += n;
 370:	00c50733          	add	a4,a0,a2
    src += n;
 374:	95b2                	add	a1,a1,a2
 376:	fff6079b          	addiw	a5,a2,-1
 37a:	1782                	slli	a5,a5,0x20
 37c:	9381                	srli	a5,a5,0x20
 37e:	fff7c793          	not	a5,a5
 382:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 384:	15fd                	addi	a1,a1,-1
 386:	177d                	addi	a4,a4,-1
 388:	0005c683          	lbu	a3,0(a1)
 38c:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 390:	fef71ae3          	bne	a4,a5,384 <memmove+0x4a>
 394:	bfc1                	j	364 <memmove+0x2a>

0000000000000396 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 396:	1141                	addi	sp,sp,-16
 398:	e406                	sd	ra,8(sp)
 39a:	e022                	sd	s0,0(sp)
 39c:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 39e:	ce19                	beqz	a2,3bc <memcmp+0x26>
 3a0:	1602                	slli	a2,a2,0x20
 3a2:	9201                	srli	a2,a2,0x20
 3a4:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 3a8:	00054783          	lbu	a5,0(a0)
 3ac:	0005c703          	lbu	a4,0(a1)
 3b0:	00e79b63          	bne	a5,a4,3c6 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 3b4:	0505                	addi	a0,a0,1
    p2++;
 3b6:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 3b8:	fed518e3          	bne	a0,a3,3a8 <memcmp+0x12>
  }
  return 0;
 3bc:	4501                	li	a0,0
}
 3be:	60a2                	ld	ra,8(sp)
 3c0:	6402                	ld	s0,0(sp)
 3c2:	0141                	addi	sp,sp,16
 3c4:	8082                	ret
      return *p1 - *p2;
 3c6:	40e7853b          	subw	a0,a5,a4
 3ca:	bfd5                	j	3be <memcmp+0x28>

00000000000003cc <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 3cc:	1141                	addi	sp,sp,-16
 3ce:	e406                	sd	ra,8(sp)
 3d0:	e022                	sd	s0,0(sp)
 3d2:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 3d4:	f67ff0ef          	jal	33a <memmove>
}
 3d8:	60a2                	ld	ra,8(sp)
 3da:	6402                	ld	s0,0(sp)
 3dc:	0141                	addi	sp,sp,16
 3de:	8082                	ret

00000000000003e0 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 3e0:	4885                	li	a7,1
 ecall
 3e2:	00000073          	ecall
 ret
 3e6:	8082                	ret

00000000000003e8 <exit>:
.global exit
exit:
 li a7, SYS_exit
 3e8:	4889                	li	a7,2
 ecall
 3ea:	00000073          	ecall
 ret
 3ee:	8082                	ret

00000000000003f0 <wait>:
.global wait
wait:
 li a7, SYS_wait
 3f0:	488d                	li	a7,3
 ecall
 3f2:	00000073          	ecall
 ret
 3f6:	8082                	ret

00000000000003f8 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 3f8:	4891                	li	a7,4
 ecall
 3fa:	00000073          	ecall
 ret
 3fe:	8082                	ret

0000000000000400 <read>:
.global read
read:
 li a7, SYS_read
 400:	4895                	li	a7,5
 ecall
 402:	00000073          	ecall
 ret
 406:	8082                	ret

0000000000000408 <write>:
.global write
write:
 li a7, SYS_write
 408:	48c1                	li	a7,16
 ecall
 40a:	00000073          	ecall
 ret
 40e:	8082                	ret

0000000000000410 <close>:
.global close
close:
 li a7, SYS_close
 410:	48d5                	li	a7,21
 ecall
 412:	00000073          	ecall
 ret
 416:	8082                	ret

0000000000000418 <kill>:
.global kill
kill:
 li a7, SYS_kill
 418:	4899                	li	a7,6
 ecall
 41a:	00000073          	ecall
 ret
 41e:	8082                	ret

0000000000000420 <exec>:
.global exec
exec:
 li a7, SYS_exec
 420:	489d                	li	a7,7
 ecall
 422:	00000073          	ecall
 ret
 426:	8082                	ret

0000000000000428 <open>:
.global open
open:
 li a7, SYS_open
 428:	48bd                	li	a7,15
 ecall
 42a:	00000073          	ecall
 ret
 42e:	8082                	ret

0000000000000430 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 430:	48c5                	li	a7,17
 ecall
 432:	00000073          	ecall
 ret
 436:	8082                	ret

0000000000000438 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 438:	48c9                	li	a7,18
 ecall
 43a:	00000073          	ecall
 ret
 43e:	8082                	ret

0000000000000440 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 440:	48a1                	li	a7,8
 ecall
 442:	00000073          	ecall
 ret
 446:	8082                	ret

0000000000000448 <link>:
.global link
link:
 li a7, SYS_link
 448:	48cd                	li	a7,19
 ecall
 44a:	00000073          	ecall
 ret
 44e:	8082                	ret

0000000000000450 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 450:	48d1                	li	a7,20
 ecall
 452:	00000073          	ecall
 ret
 456:	8082                	ret

0000000000000458 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 458:	48a5                	li	a7,9
 ecall
 45a:	00000073          	ecall
 ret
 45e:	8082                	ret

0000000000000460 <dup>:
.global dup
dup:
 li a7, SYS_dup
 460:	48a9                	li	a7,10
 ecall
 462:	00000073          	ecall
 ret
 466:	8082                	ret

0000000000000468 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 468:	48ad                	li	a7,11
 ecall
 46a:	00000073          	ecall
 ret
 46e:	8082                	ret

0000000000000470 <getproccount>:
.global getproccount
getproccount:
 li a7, SYS_getproccount
 470:	48d9                	li	a7,22
 ecall
 472:	00000073          	ecall
 ret
 476:	8082                	ret

0000000000000478 <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 478:	48b1                	li	a7,12
 ecall
 47a:	00000073          	ecall
 ret
 47e:	8082                	ret

0000000000000480 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 480:	48b5                	li	a7,13
 ecall
 482:	00000073          	ecall
 ret
 486:	8082                	ret

0000000000000488 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 488:	48b9                	li	a7,14
 ecall
 48a:	00000073          	ecall
 ret
 48e:	8082                	ret

0000000000000490 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 490:	1101                	addi	sp,sp,-32
 492:	ec06                	sd	ra,24(sp)
 494:	e822                	sd	s0,16(sp)
 496:	1000                	addi	s0,sp,32
 498:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 49c:	4605                	li	a2,1
 49e:	fef40593          	addi	a1,s0,-17
 4a2:	f67ff0ef          	jal	408 <write>
}
 4a6:	60e2                	ld	ra,24(sp)
 4a8:	6442                	ld	s0,16(sp)
 4aa:	6105                	addi	sp,sp,32
 4ac:	8082                	ret

00000000000004ae <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 4ae:	715d                	addi	sp,sp,-80
 4b0:	e486                	sd	ra,72(sp)
 4b2:	e0a2                	sd	s0,64(sp)
 4b4:	f84a                	sd	s2,48(sp)
 4b6:	f44e                	sd	s3,40(sp)
 4b8:	0880                	addi	s0,sp,80
 4ba:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 4bc:	00d036b3          	snez	a3,a3
 4c0:	03f5d793          	srli	a5,a1,0x3f
 4c4:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 4c6:	0005871b          	sext.w	a4,a1
  neg = 0;
 4ca:	4301                	li	t1,0
  if(sgn && xx < 0){
 4cc:	c681                	beqz	a3,4d4 <printint+0x26>
    x = -xx;
 4ce:	40b0073b          	negw	a4,a1
    neg = 1;
 4d2:	4305                	li	t1,1
  }

  i = 0;
 4d4:	fb840993          	addi	s3,s0,-72
  neg = 0;
 4d8:	85ce                	mv	a1,s3
  i = 0;
 4da:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 4dc:	00000817          	auipc	a6,0x0
 4e0:	55480813          	addi	a6,a6,1364 # a30 <digits>
 4e4:	88b6                	mv	a7,a3
 4e6:	0016851b          	addiw	a0,a3,1
 4ea:	86aa                	mv	a3,a0
 4ec:	02c777bb          	remuw	a5,a4,a2
 4f0:	1782                	slli	a5,a5,0x20
 4f2:	9381                	srli	a5,a5,0x20
 4f4:	97c2                	add	a5,a5,a6
 4f6:	0007c783          	lbu	a5,0(a5)
 4fa:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 4fe:	87ba                	mv	a5,a4
 500:	02c7573b          	divuw	a4,a4,a2
 504:	0585                	addi	a1,a1,1
 506:	fcc7ffe3          	bgeu	a5,a2,4e4 <printint+0x36>
  if(neg)
 50a:	00030b63          	beqz	t1,520 <printint+0x72>
    buf[i++] = '-';
 50e:	fd040793          	addi	a5,s0,-48
 512:	953e                	add	a0,a0,a5
 514:	02d00793          	li	a5,45
 518:	fef50423          	sb	a5,-24(a0)
 51c:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 520:	02d05563          	blez	a3,54a <printint+0x9c>
 524:	fc26                	sd	s1,56(sp)
 526:	36fd                	addiw	a3,a3,-1
 528:	00d984b3          	add	s1,s3,a3
 52c:	19fd                	addi	s3,s3,-1
 52e:	99b6                	add	s3,s3,a3
 530:	1682                	slli	a3,a3,0x20
 532:	9281                	srli	a3,a3,0x20
 534:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 538:	0004c583          	lbu	a1,0(s1)
 53c:	854a                	mv	a0,s2
 53e:	f53ff0ef          	jal	490 <putc>
  while(--i >= 0)
 542:	14fd                	addi	s1,s1,-1
 544:	ff349ae3          	bne	s1,s3,538 <printint+0x8a>
 548:	74e2                	ld	s1,56(sp)
}
 54a:	60a6                	ld	ra,72(sp)
 54c:	6406                	ld	s0,64(sp)
 54e:	7942                	ld	s2,48(sp)
 550:	79a2                	ld	s3,40(sp)
 552:	6161                	addi	sp,sp,80
 554:	8082                	ret

0000000000000556 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 556:	711d                	addi	sp,sp,-96
 558:	ec86                	sd	ra,88(sp)
 55a:	e8a2                	sd	s0,80(sp)
 55c:	e4a6                	sd	s1,72(sp)
 55e:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 560:	0005c483          	lbu	s1,0(a1)
 564:	28048263          	beqz	s1,7e8 <vprintf+0x292>
 568:	e0ca                	sd	s2,64(sp)
 56a:	fc4e                	sd	s3,56(sp)
 56c:	f852                	sd	s4,48(sp)
 56e:	f456                	sd	s5,40(sp)
 570:	f05a                	sd	s6,32(sp)
 572:	ec5e                	sd	s7,24(sp)
 574:	e862                	sd	s8,16(sp)
 576:	8b2a                	mv	s6,a0
 578:	8a2e                	mv	s4,a1
 57a:	8bb2                	mv	s7,a2
  state = 0;
 57c:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 57e:	4901                	li	s2,0
 580:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 582:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 586:	06400c13          	li	s8,100
 58a:	a00d                	j	5ac <vprintf+0x56>
        putc(fd, c0);
 58c:	85a6                	mv	a1,s1
 58e:	855a                	mv	a0,s6
 590:	f01ff0ef          	jal	490 <putc>
 594:	a019                	j	59a <vprintf+0x44>
    } else if(state == '%'){
 596:	03598363          	beq	s3,s5,5bc <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 59a:	0019079b          	addiw	a5,s2,1
 59e:	893e                	mv	s2,a5
 5a0:	873e                	mv	a4,a5
 5a2:	97d2                	add	a5,a5,s4
 5a4:	0007c483          	lbu	s1,0(a5)
 5a8:	22048963          	beqz	s1,7da <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 5ac:	0004879b          	sext.w	a5,s1
    if(state == 0){
 5b0:	fe0993e3          	bnez	s3,596 <vprintf+0x40>
      if(c0 == '%'){
 5b4:	fd579ce3          	bne	a5,s5,58c <vprintf+0x36>
        state = '%';
 5b8:	89be                	mv	s3,a5
 5ba:	b7c5                	j	59a <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 5bc:	00ea06b3          	add	a3,s4,a4
 5c0:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 5c4:	22060763          	beqz	a2,7f2 <vprintf+0x29c>
      if(c0 == 'd'){
 5c8:	0b878363          	beq	a5,s8,66e <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 5cc:	f9478693          	addi	a3,a5,-108
 5d0:	0016b693          	seqz	a3,a3
 5d4:	f9c60593          	addi	a1,a2,-100
 5d8:	0015b593          	seqz	a1,a1
 5dc:	8df5                	and	a1,a1,a3
 5de:	e5c5                	bnez	a1,686 <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 5e0:	9752                	add	a4,a4,s4
 5e2:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 5e6:	f9460713          	addi	a4,a2,-108
 5ea:	00173713          	seqz	a4,a4
 5ee:	8f75                	and	a4,a4,a3
 5f0:	f9c50593          	addi	a1,a0,-100
 5f4:	0015b593          	seqz	a1,a1
 5f8:	8df9                	and	a1,a1,a4
 5fa:	e1dd                	bnez	a1,6a0 <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 5fc:	07500593          	li	a1,117
 600:	0ab78d63          	beq	a5,a1,6ba <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 604:	f8b60593          	addi	a1,a2,-117
 608:	0015b593          	seqz	a1,a1
 60c:	8df5                	and	a1,a1,a3
 60e:	e1f1                	bnez	a1,6d2 <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 610:	f8b50593          	addi	a1,a0,-117
 614:	0015b593          	seqz	a1,a1
 618:	8df9                	and	a1,a1,a4
 61a:	e9e9                	bnez	a1,6ec <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 61c:	07800593          	li	a1,120
 620:	0eb78363          	beq	a5,a1,706 <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 624:	f8860613          	addi	a2,a2,-120
 628:	00163613          	seqz	a2,a2
 62c:	8ef1                	and	a3,a3,a2
 62e:	0e069863          	bnez	a3,71e <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 632:	f8850513          	addi	a0,a0,-120
 636:	00153513          	seqz	a0,a0
 63a:	8f69                	and	a4,a4,a0
 63c:	0e071e63          	bnez	a4,738 <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 640:	07000713          	li	a4,112
 644:	10e78663          	beq	a5,a4,750 <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 648:	07300713          	li	a4,115
 64c:	14e78663          	beq	a5,a4,798 <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 650:	02500713          	li	a4,37
 654:	16e78e63          	beq	a5,a4,7d0 <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 658:	02500593          	li	a1,37
 65c:	855a                	mv	a0,s6
 65e:	e33ff0ef          	jal	490 <putc>
        putc(fd, c0);
 662:	85a6                	mv	a1,s1
 664:	855a                	mv	a0,s6
 666:	e2bff0ef          	jal	490 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 66a:	4981                	li	s3,0
 66c:	b73d                	j	59a <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 66e:	008b8493          	addi	s1,s7,8
 672:	4685                	li	a3,1
 674:	4629                	li	a2,10
 676:	000ba583          	lw	a1,0(s7)
 67a:	855a                	mv	a0,s6
 67c:	e33ff0ef          	jal	4ae <printint>
 680:	8ba6                	mv	s7,s1
      state = 0;
 682:	4981                	li	s3,0
 684:	bf19                	j	59a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 686:	008b8493          	addi	s1,s7,8
 68a:	4685                	li	a3,1
 68c:	4629                	li	a2,10
 68e:	000bb583          	ld	a1,0(s7)
 692:	855a                	mv	a0,s6
 694:	e1bff0ef          	jal	4ae <printint>
        i += 1;
 698:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 69a:	8ba6                	mv	s7,s1
      state = 0;
 69c:	4981                	li	s3,0
 69e:	bdf5                	j	59a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 6a0:	008b8493          	addi	s1,s7,8
 6a4:	4685                	li	a3,1
 6a6:	4629                	li	a2,10
 6a8:	000bb583          	ld	a1,0(s7)
 6ac:	855a                	mv	a0,s6
 6ae:	e01ff0ef          	jal	4ae <printint>
        i += 2;
 6b2:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 6b4:	8ba6                	mv	s7,s1
      state = 0;
 6b6:	4981                	li	s3,0
        i += 2;
 6b8:	b5cd                	j	59a <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 6ba:	008b8493          	addi	s1,s7,8
 6be:	4681                	li	a3,0
 6c0:	4629                	li	a2,10
 6c2:	000ba583          	lw	a1,0(s7)
 6c6:	855a                	mv	a0,s6
 6c8:	de7ff0ef          	jal	4ae <printint>
 6cc:	8ba6                	mv	s7,s1
      state = 0;
 6ce:	4981                	li	s3,0
 6d0:	b5e9                	j	59a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 6d2:	008b8493          	addi	s1,s7,8
 6d6:	4681                	li	a3,0
 6d8:	4629                	li	a2,10
 6da:	000bb583          	ld	a1,0(s7)
 6de:	855a                	mv	a0,s6
 6e0:	dcfff0ef          	jal	4ae <printint>
        i += 1;
 6e4:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 6e6:	8ba6                	mv	s7,s1
      state = 0;
 6e8:	4981                	li	s3,0
 6ea:	bd45                	j	59a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 6ec:	008b8493          	addi	s1,s7,8
 6f0:	4681                	li	a3,0
 6f2:	4629                	li	a2,10
 6f4:	000bb583          	ld	a1,0(s7)
 6f8:	855a                	mv	a0,s6
 6fa:	db5ff0ef          	jal	4ae <printint>
        i += 2;
 6fe:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 700:	8ba6                	mv	s7,s1
      state = 0;
 702:	4981                	li	s3,0
        i += 2;
 704:	bd59                	j	59a <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 706:	008b8493          	addi	s1,s7,8
 70a:	4681                	li	a3,0
 70c:	4641                	li	a2,16
 70e:	000ba583          	lw	a1,0(s7)
 712:	855a                	mv	a0,s6
 714:	d9bff0ef          	jal	4ae <printint>
 718:	8ba6                	mv	s7,s1
      state = 0;
 71a:	4981                	li	s3,0
 71c:	bdbd                	j	59a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 71e:	008b8493          	addi	s1,s7,8
 722:	4681                	li	a3,0
 724:	4641                	li	a2,16
 726:	000bb583          	ld	a1,0(s7)
 72a:	855a                	mv	a0,s6
 72c:	d83ff0ef          	jal	4ae <printint>
        i += 1;
 730:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 732:	8ba6                	mv	s7,s1
      state = 0;
 734:	4981                	li	s3,0
 736:	b595                	j	59a <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 738:	008b8493          	addi	s1,s7,8
 73c:	4641                	li	a2,16
 73e:	000bb583          	ld	a1,0(s7)
 742:	855a                	mv	a0,s6
 744:	d6bff0ef          	jal	4ae <printint>
        i += 2;
 748:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 74a:	8ba6                	mv	s7,s1
      state = 0;
 74c:	4981                	li	s3,0
        i += 2;
 74e:	b5b1                	j	59a <vprintf+0x44>
 750:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 752:	008b8793          	addi	a5,s7,8
 756:	8cbe                	mv	s9,a5
 758:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 75c:	03000593          	li	a1,48
 760:	855a                	mv	a0,s6
 762:	d2fff0ef          	jal	490 <putc>
  putc(fd, 'x');
 766:	07800593          	li	a1,120
 76a:	855a                	mv	a0,s6
 76c:	d25ff0ef          	jal	490 <putc>
 770:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 772:	00000b97          	auipc	s7,0x0
 776:	2beb8b93          	addi	s7,s7,702 # a30 <digits>
 77a:	03c9d793          	srli	a5,s3,0x3c
 77e:	97de                	add	a5,a5,s7
 780:	0007c583          	lbu	a1,0(a5)
 784:	855a                	mv	a0,s6
 786:	d0bff0ef          	jal	490 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 78a:	0992                	slli	s3,s3,0x4
 78c:	34fd                	addiw	s1,s1,-1
 78e:	f4f5                	bnez	s1,77a <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 790:	8be6                	mv	s7,s9
      state = 0;
 792:	4981                	li	s3,0
 794:	6ca2                	ld	s9,8(sp)
 796:	b511                	j	59a <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 798:	008b8993          	addi	s3,s7,8
 79c:	000bb483          	ld	s1,0(s7)
 7a0:	cc91                	beqz	s1,7bc <vprintf+0x266>
        for(; *s; s++)
 7a2:	0004c583          	lbu	a1,0(s1)
 7a6:	c195                	beqz	a1,7ca <vprintf+0x274>
          putc(fd, *s);
 7a8:	855a                	mv	a0,s6
 7aa:	ce7ff0ef          	jal	490 <putc>
        for(; *s; s++)
 7ae:	0485                	addi	s1,s1,1
 7b0:	0004c583          	lbu	a1,0(s1)
 7b4:	f9f5                	bnez	a1,7a8 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 7b6:	8bce                	mv	s7,s3
      state = 0;
 7b8:	4981                	li	s3,0
 7ba:	b3c5                	j	59a <vprintf+0x44>
          s = "(null)";
 7bc:	00000497          	auipc	s1,0x0
 7c0:	26c48493          	addi	s1,s1,620 # a28 <malloc+0x13a>
        for(; *s; s++)
 7c4:	02800593          	li	a1,40
 7c8:	b7c5                	j	7a8 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 7ca:	8bce                	mv	s7,s3
      state = 0;
 7cc:	4981                	li	s3,0
 7ce:	b3f1                	j	59a <vprintf+0x44>
        putc(fd, '%');
 7d0:	85be                	mv	a1,a5
 7d2:	855a                	mv	a0,s6
 7d4:	cbdff0ef          	jal	490 <putc>
 7d8:	bd49                	j	66a <vprintf+0x114>
 7da:	6906                	ld	s2,64(sp)
 7dc:	79e2                	ld	s3,56(sp)
 7de:	7a42                	ld	s4,48(sp)
 7e0:	7aa2                	ld	s5,40(sp)
 7e2:	7b02                	ld	s6,32(sp)
 7e4:	6be2                	ld	s7,24(sp)
 7e6:	6c42                	ld	s8,16(sp)
    }
  }
}
 7e8:	60e6                	ld	ra,88(sp)
 7ea:	6446                	ld	s0,80(sp)
 7ec:	64a6                	ld	s1,72(sp)
 7ee:	6125                	addi	sp,sp,96
 7f0:	8082                	ret
      if(c0 == 'd'){
 7f2:	06400713          	li	a4,100
 7f6:	e6e78ce3          	beq	a5,a4,66e <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 7fa:	f9478693          	addi	a3,a5,-108
 7fe:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 802:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 804:	4701                	li	a4,0
 806:	bbdd                	j	5fc <vprintf+0xa6>

0000000000000808 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 808:	715d                	addi	sp,sp,-80
 80a:	ec06                	sd	ra,24(sp)
 80c:	e822                	sd	s0,16(sp)
 80e:	1000                	addi	s0,sp,32
 810:	e010                	sd	a2,0(s0)
 812:	e414                	sd	a3,8(s0)
 814:	e818                	sd	a4,16(s0)
 816:	ec1c                	sd	a5,24(s0)
 818:	03043023          	sd	a6,32(s0)
 81c:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 820:	8622                	mv	a2,s0
 822:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 826:	d31ff0ef          	jal	556 <vprintf>
}
 82a:	60e2                	ld	ra,24(sp)
 82c:	6442                	ld	s0,16(sp)
 82e:	6161                	addi	sp,sp,80
 830:	8082                	ret

0000000000000832 <printf>:

void
printf(const char *fmt, ...)
{
 832:	711d                	addi	sp,sp,-96
 834:	ec06                	sd	ra,24(sp)
 836:	e822                	sd	s0,16(sp)
 838:	1000                	addi	s0,sp,32
 83a:	e40c                	sd	a1,8(s0)
 83c:	e810                	sd	a2,16(s0)
 83e:	ec14                	sd	a3,24(s0)
 840:	f018                	sd	a4,32(s0)
 842:	f41c                	sd	a5,40(s0)
 844:	03043823          	sd	a6,48(s0)
 848:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 84c:	00840613          	addi	a2,s0,8
 850:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 854:	85aa                	mv	a1,a0
 856:	4505                	li	a0,1
 858:	cffff0ef          	jal	556 <vprintf>
}
 85c:	60e2                	ld	ra,24(sp)
 85e:	6442                	ld	s0,16(sp)
 860:	6125                	addi	sp,sp,96
 862:	8082                	ret

0000000000000864 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 864:	1141                	addi	sp,sp,-16
 866:	e406                	sd	ra,8(sp)
 868:	e022                	sd	s0,0(sp)
 86a:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 86c:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 870:	00000797          	auipc	a5,0x0
 874:	7907b783          	ld	a5,1936(a5) # 1000 <freep>
 878:	a095                	j	8dc <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 87a:	ff852583          	lw	a1,-8(a0)
 87e:	6390                	ld	a2,0(a5)
 880:	02059813          	slli	a6,a1,0x20
 884:	01c85693          	srli	a3,a6,0x1c
 888:	96ba                	add	a3,a3,a4
 88a:	02d60563          	beq	a2,a3,8b4 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 88e:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 892:	4790                	lw	a2,8(a5)
 894:	02061593          	slli	a1,a2,0x20
 898:	01c5d693          	srli	a3,a1,0x1c
 89c:	96be                	add	a3,a3,a5
 89e:	02d70263          	beq	a4,a3,8c2 <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 8a2:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 8a4:	00000717          	auipc	a4,0x0
 8a8:	74f73e23          	sd	a5,1884(a4) # 1000 <freep>
}
 8ac:	60a2                	ld	ra,8(sp)
 8ae:	6402                	ld	s0,0(sp)
 8b0:	0141                	addi	sp,sp,16
 8b2:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 8b4:	4614                	lw	a3,8(a2)
 8b6:	9ead                	addw	a3,a3,a1
 8b8:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 8bc:	6394                	ld	a3,0(a5)
 8be:	6290                	ld	a2,0(a3)
 8c0:	b7f9                	j	88e <free+0x2a>
    p->s.size += bp->s.size;
 8c2:	ff852703          	lw	a4,-8(a0)
 8c6:	9f31                	addw	a4,a4,a2
 8c8:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 8ca:	ff053703          	ld	a4,-16(a0)
 8ce:	bfd1                	j	8a2 <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8d0:	6394                	ld	a3,0(a5)
 8d2:	00d7e463          	bltu	a5,a3,8da <free+0x76>
 8d6:	fad762e3          	bltu	a4,a3,87a <free+0x16>
 8da:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8dc:	fee7fae3          	bgeu	a5,a4,8d0 <free+0x6c>
 8e0:	6394                	ld	a3,0(a5)
 8e2:	f8d76ce3          	bltu	a4,a3,87a <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8e6:	f8d7fae3          	bgeu	a5,a3,87a <free+0x16>
 8ea:	87b6                	mv	a5,a3
 8ec:	bfc5                	j	8dc <free+0x78>

00000000000008ee <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 8ee:	7139                	addi	sp,sp,-64
 8f0:	fc06                	sd	ra,56(sp)
 8f2:	f822                	sd	s0,48(sp)
 8f4:	f04a                	sd	s2,32(sp)
 8f6:	ec4e                	sd	s3,24(sp)
 8f8:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 8fa:	02051993          	slli	s3,a0,0x20
 8fe:	0209d993          	srli	s3,s3,0x20
 902:	09bd                	addi	s3,s3,15
 904:	0049d993          	srli	s3,s3,0x4
 908:	2985                	addiw	s3,s3,1
 90a:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 90c:	00000517          	auipc	a0,0x0
 910:	6f453503          	ld	a0,1780(a0) # 1000 <freep>
 914:	c905                	beqz	a0,944 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 916:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 918:	4798                	lw	a4,8(a5)
 91a:	09377663          	bgeu	a4,s3,9a6 <malloc+0xb8>
 91e:	f426                	sd	s1,40(sp)
 920:	e852                	sd	s4,16(sp)
 922:	e456                	sd	s5,8(sp)
 924:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 926:	8a4e                	mv	s4,s3
 928:	6705                	lui	a4,0x1
 92a:	00e9f363          	bgeu	s3,a4,930 <malloc+0x42>
 92e:	6a05                	lui	s4,0x1
 930:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 934:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 938:	00000497          	auipc	s1,0x0
 93c:	6c848493          	addi	s1,s1,1736 # 1000 <freep>
  if(p == (char*)-1)
 940:	5afd                	li	s5,-1
 942:	a83d                	j	980 <malloc+0x92>
 944:	f426                	sd	s1,40(sp)
 946:	e852                	sd	s4,16(sp)
 948:	e456                	sd	s5,8(sp)
 94a:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 94c:	00001797          	auipc	a5,0x1
 950:	8c478793          	addi	a5,a5,-1852 # 1210 <base>
 954:	00000717          	auipc	a4,0x0
 958:	6af73623          	sd	a5,1708(a4) # 1000 <freep>
 95c:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 95e:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 962:	b7d1                	j	926 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 964:	6398                	ld	a4,0(a5)
 966:	e118                	sd	a4,0(a0)
 968:	a899                	j	9be <malloc+0xd0>
  hp->s.size = nu;
 96a:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 96e:	0541                	addi	a0,a0,16
 970:	ef5ff0ef          	jal	864 <free>
  return freep;
 974:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 976:	c125                	beqz	a0,9d6 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 978:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 97a:	4798                	lw	a4,8(a5)
 97c:	03277163          	bgeu	a4,s2,99e <malloc+0xb0>
    if(p == freep)
 980:	6098                	ld	a4,0(s1)
 982:	853e                	mv	a0,a5
 984:	fef71ae3          	bne	a4,a5,978 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 988:	8552                	mv	a0,s4
 98a:	aefff0ef          	jal	478 <sbrk>
  if(p == (char*)-1)
 98e:	fd551ee3          	bne	a0,s5,96a <malloc+0x7c>
        return 0;
 992:	4501                	li	a0,0
 994:	74a2                	ld	s1,40(sp)
 996:	6a42                	ld	s4,16(sp)
 998:	6aa2                	ld	s5,8(sp)
 99a:	6b02                	ld	s6,0(sp)
 99c:	a03d                	j	9ca <malloc+0xdc>
 99e:	74a2                	ld	s1,40(sp)
 9a0:	6a42                	ld	s4,16(sp)
 9a2:	6aa2                	ld	s5,8(sp)
 9a4:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 9a6:	fae90fe3          	beq	s2,a4,964 <malloc+0x76>
        p->s.size -= nunits;
 9aa:	4137073b          	subw	a4,a4,s3
 9ae:	c798                	sw	a4,8(a5)
        p += p->s.size;
 9b0:	02071693          	slli	a3,a4,0x20
 9b4:	01c6d713          	srli	a4,a3,0x1c
 9b8:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 9ba:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 9be:	00000717          	auipc	a4,0x0
 9c2:	64a73123          	sd	a0,1602(a4) # 1000 <freep>
      return (void*)(p + 1);
 9c6:	01078513          	addi	a0,a5,16
  }
}
 9ca:	70e2                	ld	ra,56(sp)
 9cc:	7442                	ld	s0,48(sp)
 9ce:	7902                	ld	s2,32(sp)
 9d0:	69e2                	ld	s3,24(sp)
 9d2:	6121                	addi	sp,sp,64
 9d4:	8082                	ret
 9d6:	74a2                	ld	s1,40(sp)
 9d8:	6a42                	ld	s4,16(sp)
 9da:	6aa2                	ld	s5,8(sp)
 9dc:	6b02                	ld	s6,0(sp)
 9de:	b7f5                	j	9ca <malloc+0xdc>
