
user/_zombie:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(void)
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
  if(fork() > 0)
   8:	29c000ef          	jal	2a4 <fork>
   c:	00a04563          	bgtz	a0,16 <main+0x16>
    sleep(100);  // Let child exit before parent.
  exit(0);
  10:	4501                	li	a0,0
  12:	29a000ef          	jal	2ac <exit>
    sleep(100);  // Let child exit before parent.
  16:	06400513          	li	a0,100
  1a:	32a000ef          	jal	344 <sleep>
  1e:	bfcd                	j	10 <main+0x10>

0000000000000020 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  20:	1141                	addi	sp,sp,-16
  22:	e406                	sd	ra,8(sp)
  24:	e022                	sd	s0,0(sp)
  26:	0800                	addi	s0,sp,16
  extern int main();
  main();
  28:	fd9ff0ef          	jal	0 <main>
  exit(0);
  2c:	4501                	li	a0,0
  2e:	27e000ef          	jal	2ac <exit>

0000000000000032 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  32:	1141                	addi	sp,sp,-16
  34:	e406                	sd	ra,8(sp)
  36:	e022                	sd	s0,0(sp)
  38:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  3a:	87aa                	mv	a5,a0
  3c:	0585                	addi	a1,a1,1
  3e:	0785                	addi	a5,a5,1
  40:	fff5c703          	lbu	a4,-1(a1)
  44:	fee78fa3          	sb	a4,-1(a5)
  48:	fb75                	bnez	a4,3c <strcpy+0xa>
    ;
  return os;
}
  4a:	60a2                	ld	ra,8(sp)
  4c:	6402                	ld	s0,0(sp)
  4e:	0141                	addi	sp,sp,16
  50:	8082                	ret

0000000000000052 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  52:	1141                	addi	sp,sp,-16
  54:	e406                	sd	ra,8(sp)
  56:	e022                	sd	s0,0(sp)
  58:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  5a:	00054783          	lbu	a5,0(a0)
  5e:	cb91                	beqz	a5,72 <strcmp+0x20>
  60:	0005c703          	lbu	a4,0(a1)
  64:	00f71763          	bne	a4,a5,72 <strcmp+0x20>
    p++, q++;
  68:	0505                	addi	a0,a0,1
  6a:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
  6c:	00054783          	lbu	a5,0(a0)
  70:	fbe5                	bnez	a5,60 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
  72:	0005c503          	lbu	a0,0(a1)
}
  76:	40a7853b          	subw	a0,a5,a0
  7a:	60a2                	ld	ra,8(sp)
  7c:	6402                	ld	s0,0(sp)
  7e:	0141                	addi	sp,sp,16
  80:	8082                	ret

0000000000000082 <strlen>:

uint
strlen(const char *s)
{
  82:	1141                	addi	sp,sp,-16
  84:	e406                	sd	ra,8(sp)
  86:	e022                	sd	s0,0(sp)
  88:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
  8a:	00054783          	lbu	a5,0(a0)
  8e:	cf91                	beqz	a5,aa <strlen+0x28>
  90:	00150793          	addi	a5,a0,1
  94:	86be                	mv	a3,a5
  96:	0785                	addi	a5,a5,1
  98:	fff7c703          	lbu	a4,-1(a5)
  9c:	ff65                	bnez	a4,94 <strlen+0x12>
  9e:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
  a2:	60a2                	ld	ra,8(sp)
  a4:	6402                	ld	s0,0(sp)
  a6:	0141                	addi	sp,sp,16
  a8:	8082                	ret
  for(n = 0; s[n]; n++)
  aa:	4501                	li	a0,0
  ac:	bfdd                	j	a2 <strlen+0x20>

00000000000000ae <memset>:

void*
memset(void *dst, int c, uint n)
{
  ae:	1141                	addi	sp,sp,-16
  b0:	e406                	sd	ra,8(sp)
  b2:	e022                	sd	s0,0(sp)
  b4:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
  b6:	ca19                	beqz	a2,cc <memset+0x1e>
  b8:	87aa                	mv	a5,a0
  ba:	1602                	slli	a2,a2,0x20
  bc:	9201                	srli	a2,a2,0x20
  be:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
  c2:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
  c6:	0785                	addi	a5,a5,1
  c8:	fee79de3          	bne	a5,a4,c2 <memset+0x14>
  }
  return dst;
}
  cc:	60a2                	ld	ra,8(sp)
  ce:	6402                	ld	s0,0(sp)
  d0:	0141                	addi	sp,sp,16
  d2:	8082                	ret

00000000000000d4 <strchr>:

char*
strchr(const char *s, char c)
{
  d4:	1141                	addi	sp,sp,-16
  d6:	e406                	sd	ra,8(sp)
  d8:	e022                	sd	s0,0(sp)
  da:	0800                	addi	s0,sp,16
  for(; *s; s++)
  dc:	00054783          	lbu	a5,0(a0)
  e0:	c799                	beqz	a5,ee <strchr+0x1a>
    if(*s == c)
  e2:	00f58763          	beq	a1,a5,f0 <strchr+0x1c>
  for(; *s; s++)
  e6:	0505                	addi	a0,a0,1
  e8:	00054783          	lbu	a5,0(a0)
  ec:	fbfd                	bnez	a5,e2 <strchr+0xe>
      return (char*)s;
  return 0;
  ee:	4501                	li	a0,0
}
  f0:	60a2                	ld	ra,8(sp)
  f2:	6402                	ld	s0,0(sp)
  f4:	0141                	addi	sp,sp,16
  f6:	8082                	ret

00000000000000f8 <gets>:

char*
gets(char *buf, int max)
{
  f8:	711d                	addi	sp,sp,-96
  fa:	ec86                	sd	ra,88(sp)
  fc:	e8a2                	sd	s0,80(sp)
  fe:	e4a6                	sd	s1,72(sp)
 100:	e0ca                	sd	s2,64(sp)
 102:	fc4e                	sd	s3,56(sp)
 104:	f852                	sd	s4,48(sp)
 106:	f456                	sd	s5,40(sp)
 108:	f05a                	sd	s6,32(sp)
 10a:	ec5e                	sd	s7,24(sp)
 10c:	e862                	sd	s8,16(sp)
 10e:	1080                	addi	s0,sp,96
 110:	8baa                	mv	s7,a0
 112:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 114:	892a                	mv	s2,a0
 116:	4481                	li	s1,0
    cc = read(0, &c, 1);
 118:	faf40b13          	addi	s6,s0,-81
 11c:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 11e:	8c26                	mv	s8,s1
 120:	0014899b          	addiw	s3,s1,1
 124:	84ce                	mv	s1,s3
 126:	0349d863          	bge	s3,s4,156 <gets+0x5e>
    cc = read(0, &c, 1);
 12a:	8656                	mv	a2,s5
 12c:	85da                	mv	a1,s6
 12e:	4501                	li	a0,0
 130:	194000ef          	jal	2c4 <read>
    if(cc < 1)
 134:	02a05163          	blez	a0,156 <gets+0x5e>
      break;
    buf[i++] = c;
 138:	faf44783          	lbu	a5,-81(s0)
 13c:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 140:	0905                	addi	s2,s2,1
 142:	ff678713          	addi	a4,a5,-10
 146:	00173713          	seqz	a4,a4
 14a:	17cd                	addi	a5,a5,-13
 14c:	0017b793          	seqz	a5,a5
 150:	8fd9                	or	a5,a5,a4
 152:	d7f1                	beqz	a5,11e <gets+0x26>
    buf[i++] = c;
 154:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 156:	9c5e                	add	s8,s8,s7
 158:	000c0023          	sb	zero,0(s8)
  return buf;
}
 15c:	855e                	mv	a0,s7
 15e:	60e6                	ld	ra,88(sp)
 160:	6446                	ld	s0,80(sp)
 162:	64a6                	ld	s1,72(sp)
 164:	6906                	ld	s2,64(sp)
 166:	79e2                	ld	s3,56(sp)
 168:	7a42                	ld	s4,48(sp)
 16a:	7aa2                	ld	s5,40(sp)
 16c:	7b02                	ld	s6,32(sp)
 16e:	6be2                	ld	s7,24(sp)
 170:	6c42                	ld	s8,16(sp)
 172:	6125                	addi	sp,sp,96
 174:	8082                	ret

0000000000000176 <stat>:

int
stat(const char *n, struct stat *st)
{
 176:	1101                	addi	sp,sp,-32
 178:	ec06                	sd	ra,24(sp)
 17a:	e822                	sd	s0,16(sp)
 17c:	e04a                	sd	s2,0(sp)
 17e:	1000                	addi	s0,sp,32
 180:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 182:	4581                	li	a1,0
 184:	168000ef          	jal	2ec <open>
  if(fd < 0)
 188:	02054263          	bltz	a0,1ac <stat+0x36>
 18c:	e426                	sd	s1,8(sp)
 18e:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 190:	85ca                	mv	a1,s2
 192:	172000ef          	jal	304 <fstat>
 196:	892a                	mv	s2,a0
  close(fd);
 198:	8526                	mv	a0,s1
 19a:	13a000ef          	jal	2d4 <close>
  return r;
 19e:	64a2                	ld	s1,8(sp)
}
 1a0:	854a                	mv	a0,s2
 1a2:	60e2                	ld	ra,24(sp)
 1a4:	6442                	ld	s0,16(sp)
 1a6:	6902                	ld	s2,0(sp)
 1a8:	6105                	addi	sp,sp,32
 1aa:	8082                	ret
    return -1;
 1ac:	57fd                	li	a5,-1
 1ae:	893e                	mv	s2,a5
 1b0:	bfc5                	j	1a0 <stat+0x2a>

00000000000001b2 <atoi>:

int
atoi(const char *s)
{
 1b2:	1141                	addi	sp,sp,-16
 1b4:	e406                	sd	ra,8(sp)
 1b6:	e022                	sd	s0,0(sp)
 1b8:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 1ba:	00054683          	lbu	a3,0(a0)
 1be:	fd06879b          	addiw	a5,a3,-48
 1c2:	0ff7f793          	zext.b	a5,a5
 1c6:	4625                	li	a2,9
 1c8:	02f66963          	bltu	a2,a5,1fa <atoi+0x48>
 1cc:	872a                	mv	a4,a0
  n = 0;
 1ce:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 1d0:	0705                	addi	a4,a4,1
 1d2:	0025179b          	slliw	a5,a0,0x2
 1d6:	9fa9                	addw	a5,a5,a0
 1d8:	0017979b          	slliw	a5,a5,0x1
 1dc:	9fb5                	addw	a5,a5,a3
 1de:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 1e2:	00074683          	lbu	a3,0(a4)
 1e6:	fd06879b          	addiw	a5,a3,-48
 1ea:	0ff7f793          	zext.b	a5,a5
 1ee:	fef671e3          	bgeu	a2,a5,1d0 <atoi+0x1e>
  return n;
}
 1f2:	60a2                	ld	ra,8(sp)
 1f4:	6402                	ld	s0,0(sp)
 1f6:	0141                	addi	sp,sp,16
 1f8:	8082                	ret
  n = 0;
 1fa:	4501                	li	a0,0
 1fc:	bfdd                	j	1f2 <atoi+0x40>

00000000000001fe <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 1fe:	1141                	addi	sp,sp,-16
 200:	e406                	sd	ra,8(sp)
 202:	e022                	sd	s0,0(sp)
 204:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 206:	02b57563          	bgeu	a0,a1,230 <memmove+0x32>
    while(n-- > 0)
 20a:	00c05f63          	blez	a2,228 <memmove+0x2a>
 20e:	1602                	slli	a2,a2,0x20
 210:	9201                	srli	a2,a2,0x20
 212:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 216:	872a                	mv	a4,a0
      *dst++ = *src++;
 218:	0585                	addi	a1,a1,1
 21a:	0705                	addi	a4,a4,1
 21c:	fff5c683          	lbu	a3,-1(a1)
 220:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 224:	fee79ae3          	bne	a5,a4,218 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 228:	60a2                	ld	ra,8(sp)
 22a:	6402                	ld	s0,0(sp)
 22c:	0141                	addi	sp,sp,16
 22e:	8082                	ret
    while(n-- > 0)
 230:	fec05ce3          	blez	a2,228 <memmove+0x2a>
    dst += n;
 234:	00c50733          	add	a4,a0,a2
    src += n;
 238:	95b2                	add	a1,a1,a2
 23a:	fff6079b          	addiw	a5,a2,-1
 23e:	1782                	slli	a5,a5,0x20
 240:	9381                	srli	a5,a5,0x20
 242:	fff7c793          	not	a5,a5
 246:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 248:	15fd                	addi	a1,a1,-1
 24a:	177d                	addi	a4,a4,-1
 24c:	0005c683          	lbu	a3,0(a1)
 250:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 254:	fef71ae3          	bne	a4,a5,248 <memmove+0x4a>
 258:	bfc1                	j	228 <memmove+0x2a>

000000000000025a <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 25a:	1141                	addi	sp,sp,-16
 25c:	e406                	sd	ra,8(sp)
 25e:	e022                	sd	s0,0(sp)
 260:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 262:	ce19                	beqz	a2,280 <memcmp+0x26>
 264:	1602                	slli	a2,a2,0x20
 266:	9201                	srli	a2,a2,0x20
 268:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 26c:	00054783          	lbu	a5,0(a0)
 270:	0005c703          	lbu	a4,0(a1)
 274:	00e79b63          	bne	a5,a4,28a <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 278:	0505                	addi	a0,a0,1
    p2++;
 27a:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 27c:	fed518e3          	bne	a0,a3,26c <memcmp+0x12>
  }
  return 0;
 280:	4501                	li	a0,0
}
 282:	60a2                	ld	ra,8(sp)
 284:	6402                	ld	s0,0(sp)
 286:	0141                	addi	sp,sp,16
 288:	8082                	ret
      return *p1 - *p2;
 28a:	40e7853b          	subw	a0,a5,a4
 28e:	bfd5                	j	282 <memcmp+0x28>

0000000000000290 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 290:	1141                	addi	sp,sp,-16
 292:	e406                	sd	ra,8(sp)
 294:	e022                	sd	s0,0(sp)
 296:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 298:	f67ff0ef          	jal	1fe <memmove>
}
 29c:	60a2                	ld	ra,8(sp)
 29e:	6402                	ld	s0,0(sp)
 2a0:	0141                	addi	sp,sp,16
 2a2:	8082                	ret

00000000000002a4 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 2a4:	4885                	li	a7,1
 ecall
 2a6:	00000073          	ecall
 ret
 2aa:	8082                	ret

00000000000002ac <exit>:
.global exit
exit:
 li a7, SYS_exit
 2ac:	4889                	li	a7,2
 ecall
 2ae:	00000073          	ecall
 ret
 2b2:	8082                	ret

00000000000002b4 <wait>:
.global wait
wait:
 li a7, SYS_wait
 2b4:	488d                	li	a7,3
 ecall
 2b6:	00000073          	ecall
 ret
 2ba:	8082                	ret

00000000000002bc <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 2bc:	4891                	li	a7,4
 ecall
 2be:	00000073          	ecall
 ret
 2c2:	8082                	ret

00000000000002c4 <read>:
.global read
read:
 li a7, SYS_read
 2c4:	4895                	li	a7,5
 ecall
 2c6:	00000073          	ecall
 ret
 2ca:	8082                	ret

00000000000002cc <write>:
.global write
write:
 li a7, SYS_write
 2cc:	48c1                	li	a7,16
 ecall
 2ce:	00000073          	ecall
 ret
 2d2:	8082                	ret

00000000000002d4 <close>:
.global close
close:
 li a7, SYS_close
 2d4:	48d5                	li	a7,21
 ecall
 2d6:	00000073          	ecall
 ret
 2da:	8082                	ret

00000000000002dc <kill>:
.global kill
kill:
 li a7, SYS_kill
 2dc:	4899                	li	a7,6
 ecall
 2de:	00000073          	ecall
 ret
 2e2:	8082                	ret

00000000000002e4 <exec>:
.global exec
exec:
 li a7, SYS_exec
 2e4:	489d                	li	a7,7
 ecall
 2e6:	00000073          	ecall
 ret
 2ea:	8082                	ret

00000000000002ec <open>:
.global open
open:
 li a7, SYS_open
 2ec:	48bd                	li	a7,15
 ecall
 2ee:	00000073          	ecall
 ret
 2f2:	8082                	ret

00000000000002f4 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 2f4:	48c5                	li	a7,17
 ecall
 2f6:	00000073          	ecall
 ret
 2fa:	8082                	ret

00000000000002fc <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 2fc:	48c9                	li	a7,18
 ecall
 2fe:	00000073          	ecall
 ret
 302:	8082                	ret

0000000000000304 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 304:	48a1                	li	a7,8
 ecall
 306:	00000073          	ecall
 ret
 30a:	8082                	ret

000000000000030c <link>:
.global link
link:
 li a7, SYS_link
 30c:	48cd                	li	a7,19
 ecall
 30e:	00000073          	ecall
 ret
 312:	8082                	ret

0000000000000314 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 314:	48d1                	li	a7,20
 ecall
 316:	00000073          	ecall
 ret
 31a:	8082                	ret

000000000000031c <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 31c:	48a5                	li	a7,9
 ecall
 31e:	00000073          	ecall
 ret
 322:	8082                	ret

0000000000000324 <dup>:
.global dup
dup:
 li a7, SYS_dup
 324:	48a9                	li	a7,10
 ecall
 326:	00000073          	ecall
 ret
 32a:	8082                	ret

000000000000032c <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 32c:	48ad                	li	a7,11
 ecall
 32e:	00000073          	ecall
 ret
 332:	8082                	ret

0000000000000334 <getproccount>:
.global getproccount
getproccount:
 li a7, SYS_getproccount
 334:	48d9                	li	a7,22
 ecall
 336:	00000073          	ecall
 ret
 33a:	8082                	ret

000000000000033c <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 33c:	48b1                	li	a7,12
 ecall
 33e:	00000073          	ecall
 ret
 342:	8082                	ret

0000000000000344 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 344:	48b5                	li	a7,13
 ecall
 346:	00000073          	ecall
 ret
 34a:	8082                	ret

000000000000034c <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 34c:	48b9                	li	a7,14
 ecall
 34e:	00000073          	ecall
 ret
 352:	8082                	ret

0000000000000354 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 354:	1101                	addi	sp,sp,-32
 356:	ec06                	sd	ra,24(sp)
 358:	e822                	sd	s0,16(sp)
 35a:	1000                	addi	s0,sp,32
 35c:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 360:	4605                	li	a2,1
 362:	fef40593          	addi	a1,s0,-17
 366:	f67ff0ef          	jal	2cc <write>
}
 36a:	60e2                	ld	ra,24(sp)
 36c:	6442                	ld	s0,16(sp)
 36e:	6105                	addi	sp,sp,32
 370:	8082                	ret

0000000000000372 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 372:	715d                	addi	sp,sp,-80
 374:	e486                	sd	ra,72(sp)
 376:	e0a2                	sd	s0,64(sp)
 378:	f84a                	sd	s2,48(sp)
 37a:	f44e                	sd	s3,40(sp)
 37c:	0880                	addi	s0,sp,80
 37e:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 380:	00d036b3          	snez	a3,a3
 384:	03f5d793          	srli	a5,a1,0x3f
 388:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 38a:	0005871b          	sext.w	a4,a1
  neg = 0;
 38e:	4301                	li	t1,0
  if(sgn && xx < 0){
 390:	c681                	beqz	a3,398 <printint+0x26>
    x = -xx;
 392:	40b0073b          	negw	a4,a1
    neg = 1;
 396:	4305                	li	t1,1
  }

  i = 0;
 398:	fb840993          	addi	s3,s0,-72
  neg = 0;
 39c:	85ce                	mv	a1,s3
  i = 0;
 39e:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 3a0:	00000817          	auipc	a6,0x0
 3a4:	51880813          	addi	a6,a6,1304 # 8b8 <digits>
 3a8:	88b6                	mv	a7,a3
 3aa:	0016851b          	addiw	a0,a3,1
 3ae:	86aa                	mv	a3,a0
 3b0:	02c777bb          	remuw	a5,a4,a2
 3b4:	1782                	slli	a5,a5,0x20
 3b6:	9381                	srli	a5,a5,0x20
 3b8:	97c2                	add	a5,a5,a6
 3ba:	0007c783          	lbu	a5,0(a5)
 3be:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 3c2:	87ba                	mv	a5,a4
 3c4:	02c7573b          	divuw	a4,a4,a2
 3c8:	0585                	addi	a1,a1,1
 3ca:	fcc7ffe3          	bgeu	a5,a2,3a8 <printint+0x36>
  if(neg)
 3ce:	00030b63          	beqz	t1,3e4 <printint+0x72>
    buf[i++] = '-';
 3d2:	fd040793          	addi	a5,s0,-48
 3d6:	953e                	add	a0,a0,a5
 3d8:	02d00793          	li	a5,45
 3dc:	fef50423          	sb	a5,-24(a0)
 3e0:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 3e4:	02d05563          	blez	a3,40e <printint+0x9c>
 3e8:	fc26                	sd	s1,56(sp)
 3ea:	36fd                	addiw	a3,a3,-1
 3ec:	00d984b3          	add	s1,s3,a3
 3f0:	19fd                	addi	s3,s3,-1
 3f2:	99b6                	add	s3,s3,a3
 3f4:	1682                	slli	a3,a3,0x20
 3f6:	9281                	srli	a3,a3,0x20
 3f8:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 3fc:	0004c583          	lbu	a1,0(s1)
 400:	854a                	mv	a0,s2
 402:	f53ff0ef          	jal	354 <putc>
  while(--i >= 0)
 406:	14fd                	addi	s1,s1,-1
 408:	ff349ae3          	bne	s1,s3,3fc <printint+0x8a>
 40c:	74e2                	ld	s1,56(sp)
}
 40e:	60a6                	ld	ra,72(sp)
 410:	6406                	ld	s0,64(sp)
 412:	7942                	ld	s2,48(sp)
 414:	79a2                	ld	s3,40(sp)
 416:	6161                	addi	sp,sp,80
 418:	8082                	ret

000000000000041a <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 41a:	711d                	addi	sp,sp,-96
 41c:	ec86                	sd	ra,88(sp)
 41e:	e8a2                	sd	s0,80(sp)
 420:	e4a6                	sd	s1,72(sp)
 422:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 424:	0005c483          	lbu	s1,0(a1)
 428:	28048263          	beqz	s1,6ac <vprintf+0x292>
 42c:	e0ca                	sd	s2,64(sp)
 42e:	fc4e                	sd	s3,56(sp)
 430:	f852                	sd	s4,48(sp)
 432:	f456                	sd	s5,40(sp)
 434:	f05a                	sd	s6,32(sp)
 436:	ec5e                	sd	s7,24(sp)
 438:	e862                	sd	s8,16(sp)
 43a:	8b2a                	mv	s6,a0
 43c:	8a2e                	mv	s4,a1
 43e:	8bb2                	mv	s7,a2
  state = 0;
 440:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 442:	4901                	li	s2,0
 444:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 446:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 44a:	06400c13          	li	s8,100
 44e:	a00d                	j	470 <vprintf+0x56>
        putc(fd, c0);
 450:	85a6                	mv	a1,s1
 452:	855a                	mv	a0,s6
 454:	f01ff0ef          	jal	354 <putc>
 458:	a019                	j	45e <vprintf+0x44>
    } else if(state == '%'){
 45a:	03598363          	beq	s3,s5,480 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 45e:	0019079b          	addiw	a5,s2,1
 462:	893e                	mv	s2,a5
 464:	873e                	mv	a4,a5
 466:	97d2                	add	a5,a5,s4
 468:	0007c483          	lbu	s1,0(a5)
 46c:	22048963          	beqz	s1,69e <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 470:	0004879b          	sext.w	a5,s1
    if(state == 0){
 474:	fe0993e3          	bnez	s3,45a <vprintf+0x40>
      if(c0 == '%'){
 478:	fd579ce3          	bne	a5,s5,450 <vprintf+0x36>
        state = '%';
 47c:	89be                	mv	s3,a5
 47e:	b7c5                	j	45e <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 480:	00ea06b3          	add	a3,s4,a4
 484:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 488:	22060763          	beqz	a2,6b6 <vprintf+0x29c>
      if(c0 == 'd'){
 48c:	0b878363          	beq	a5,s8,532 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 490:	f9478693          	addi	a3,a5,-108
 494:	0016b693          	seqz	a3,a3
 498:	f9c60593          	addi	a1,a2,-100
 49c:	0015b593          	seqz	a1,a1
 4a0:	8df5                	and	a1,a1,a3
 4a2:	e5c5                	bnez	a1,54a <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 4a4:	9752                	add	a4,a4,s4
 4a6:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 4aa:	f9460713          	addi	a4,a2,-108
 4ae:	00173713          	seqz	a4,a4
 4b2:	8f75                	and	a4,a4,a3
 4b4:	f9c50593          	addi	a1,a0,-100
 4b8:	0015b593          	seqz	a1,a1
 4bc:	8df9                	and	a1,a1,a4
 4be:	e1dd                	bnez	a1,564 <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 4c0:	07500593          	li	a1,117
 4c4:	0ab78d63          	beq	a5,a1,57e <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 4c8:	f8b60593          	addi	a1,a2,-117
 4cc:	0015b593          	seqz	a1,a1
 4d0:	8df5                	and	a1,a1,a3
 4d2:	e1f1                	bnez	a1,596 <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 4d4:	f8b50593          	addi	a1,a0,-117
 4d8:	0015b593          	seqz	a1,a1
 4dc:	8df9                	and	a1,a1,a4
 4de:	e9e9                	bnez	a1,5b0 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 4e0:	07800593          	li	a1,120
 4e4:	0eb78363          	beq	a5,a1,5ca <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 4e8:	f8860613          	addi	a2,a2,-120
 4ec:	00163613          	seqz	a2,a2
 4f0:	8ef1                	and	a3,a3,a2
 4f2:	0e069863          	bnez	a3,5e2 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 4f6:	f8850513          	addi	a0,a0,-120
 4fa:	00153513          	seqz	a0,a0
 4fe:	8f69                	and	a4,a4,a0
 500:	0e071e63          	bnez	a4,5fc <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 504:	07000713          	li	a4,112
 508:	10e78663          	beq	a5,a4,614 <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 50c:	07300713          	li	a4,115
 510:	14e78663          	beq	a5,a4,65c <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 514:	02500713          	li	a4,37
 518:	16e78e63          	beq	a5,a4,694 <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 51c:	02500593          	li	a1,37
 520:	855a                	mv	a0,s6
 522:	e33ff0ef          	jal	354 <putc>
        putc(fd, c0);
 526:	85a6                	mv	a1,s1
 528:	855a                	mv	a0,s6
 52a:	e2bff0ef          	jal	354 <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 52e:	4981                	li	s3,0
 530:	b73d                	j	45e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 532:	008b8493          	addi	s1,s7,8
 536:	4685                	li	a3,1
 538:	4629                	li	a2,10
 53a:	000ba583          	lw	a1,0(s7)
 53e:	855a                	mv	a0,s6
 540:	e33ff0ef          	jal	372 <printint>
 544:	8ba6                	mv	s7,s1
      state = 0;
 546:	4981                	li	s3,0
 548:	bf19                	j	45e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 54a:	008b8493          	addi	s1,s7,8
 54e:	4685                	li	a3,1
 550:	4629                	li	a2,10
 552:	000bb583          	ld	a1,0(s7)
 556:	855a                	mv	a0,s6
 558:	e1bff0ef          	jal	372 <printint>
        i += 1;
 55c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 55e:	8ba6                	mv	s7,s1
      state = 0;
 560:	4981                	li	s3,0
 562:	bdf5                	j	45e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 564:	008b8493          	addi	s1,s7,8
 568:	4685                	li	a3,1
 56a:	4629                	li	a2,10
 56c:	000bb583          	ld	a1,0(s7)
 570:	855a                	mv	a0,s6
 572:	e01ff0ef          	jal	372 <printint>
        i += 2;
 576:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 578:	8ba6                	mv	s7,s1
      state = 0;
 57a:	4981                	li	s3,0
        i += 2;
 57c:	b5cd                	j	45e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 57e:	008b8493          	addi	s1,s7,8
 582:	4681                	li	a3,0
 584:	4629                	li	a2,10
 586:	000ba583          	lw	a1,0(s7)
 58a:	855a                	mv	a0,s6
 58c:	de7ff0ef          	jal	372 <printint>
 590:	8ba6                	mv	s7,s1
      state = 0;
 592:	4981                	li	s3,0
 594:	b5e9                	j	45e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 596:	008b8493          	addi	s1,s7,8
 59a:	4681                	li	a3,0
 59c:	4629                	li	a2,10
 59e:	000bb583          	ld	a1,0(s7)
 5a2:	855a                	mv	a0,s6
 5a4:	dcfff0ef          	jal	372 <printint>
        i += 1;
 5a8:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 5aa:	8ba6                	mv	s7,s1
      state = 0;
 5ac:	4981                	li	s3,0
 5ae:	bd45                	j	45e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 5b0:	008b8493          	addi	s1,s7,8
 5b4:	4681                	li	a3,0
 5b6:	4629                	li	a2,10
 5b8:	000bb583          	ld	a1,0(s7)
 5bc:	855a                	mv	a0,s6
 5be:	db5ff0ef          	jal	372 <printint>
        i += 2;
 5c2:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 5c4:	8ba6                	mv	s7,s1
      state = 0;
 5c6:	4981                	li	s3,0
        i += 2;
 5c8:	bd59                	j	45e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 5ca:	008b8493          	addi	s1,s7,8
 5ce:	4681                	li	a3,0
 5d0:	4641                	li	a2,16
 5d2:	000ba583          	lw	a1,0(s7)
 5d6:	855a                	mv	a0,s6
 5d8:	d9bff0ef          	jal	372 <printint>
 5dc:	8ba6                	mv	s7,s1
      state = 0;
 5de:	4981                	li	s3,0
 5e0:	bdbd                	j	45e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 5e2:	008b8493          	addi	s1,s7,8
 5e6:	4681                	li	a3,0
 5e8:	4641                	li	a2,16
 5ea:	000bb583          	ld	a1,0(s7)
 5ee:	855a                	mv	a0,s6
 5f0:	d83ff0ef          	jal	372 <printint>
        i += 1;
 5f4:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 5f6:	8ba6                	mv	s7,s1
      state = 0;
 5f8:	4981                	li	s3,0
 5fa:	b595                	j	45e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 5fc:	008b8493          	addi	s1,s7,8
 600:	4641                	li	a2,16
 602:	000bb583          	ld	a1,0(s7)
 606:	855a                	mv	a0,s6
 608:	d6bff0ef          	jal	372 <printint>
        i += 2;
 60c:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 60e:	8ba6                	mv	s7,s1
      state = 0;
 610:	4981                	li	s3,0
        i += 2;
 612:	b5b1                	j	45e <vprintf+0x44>
 614:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 616:	008b8793          	addi	a5,s7,8
 61a:	8cbe                	mv	s9,a5
 61c:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 620:	03000593          	li	a1,48
 624:	855a                	mv	a0,s6
 626:	d2fff0ef          	jal	354 <putc>
  putc(fd, 'x');
 62a:	07800593          	li	a1,120
 62e:	855a                	mv	a0,s6
 630:	d25ff0ef          	jal	354 <putc>
 634:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 636:	00000b97          	auipc	s7,0x0
 63a:	282b8b93          	addi	s7,s7,642 # 8b8 <digits>
 63e:	03c9d793          	srli	a5,s3,0x3c
 642:	97de                	add	a5,a5,s7
 644:	0007c583          	lbu	a1,0(a5)
 648:	855a                	mv	a0,s6
 64a:	d0bff0ef          	jal	354 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 64e:	0992                	slli	s3,s3,0x4
 650:	34fd                	addiw	s1,s1,-1
 652:	f4f5                	bnez	s1,63e <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 654:	8be6                	mv	s7,s9
      state = 0;
 656:	4981                	li	s3,0
 658:	6ca2                	ld	s9,8(sp)
 65a:	b511                	j	45e <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 65c:	008b8993          	addi	s3,s7,8
 660:	000bb483          	ld	s1,0(s7)
 664:	cc91                	beqz	s1,680 <vprintf+0x266>
        for(; *s; s++)
 666:	0004c583          	lbu	a1,0(s1)
 66a:	c195                	beqz	a1,68e <vprintf+0x274>
          putc(fd, *s);
 66c:	855a                	mv	a0,s6
 66e:	ce7ff0ef          	jal	354 <putc>
        for(; *s; s++)
 672:	0485                	addi	s1,s1,1
 674:	0004c583          	lbu	a1,0(s1)
 678:	f9f5                	bnez	a1,66c <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 67a:	8bce                	mv	s7,s3
      state = 0;
 67c:	4981                	li	s3,0
 67e:	b3c5                	j	45e <vprintf+0x44>
          s = "(null)";
 680:	00000497          	auipc	s1,0x0
 684:	23048493          	addi	s1,s1,560 # 8b0 <malloc+0xfe>
        for(; *s; s++)
 688:	02800593          	li	a1,40
 68c:	b7c5                	j	66c <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 68e:	8bce                	mv	s7,s3
      state = 0;
 690:	4981                	li	s3,0
 692:	b3f1                	j	45e <vprintf+0x44>
        putc(fd, '%');
 694:	85be                	mv	a1,a5
 696:	855a                	mv	a0,s6
 698:	cbdff0ef          	jal	354 <putc>
 69c:	bd49                	j	52e <vprintf+0x114>
 69e:	6906                	ld	s2,64(sp)
 6a0:	79e2                	ld	s3,56(sp)
 6a2:	7a42                	ld	s4,48(sp)
 6a4:	7aa2                	ld	s5,40(sp)
 6a6:	7b02                	ld	s6,32(sp)
 6a8:	6be2                	ld	s7,24(sp)
 6aa:	6c42                	ld	s8,16(sp)
    }
  }
}
 6ac:	60e6                	ld	ra,88(sp)
 6ae:	6446                	ld	s0,80(sp)
 6b0:	64a6                	ld	s1,72(sp)
 6b2:	6125                	addi	sp,sp,96
 6b4:	8082                	ret
      if(c0 == 'd'){
 6b6:	06400713          	li	a4,100
 6ba:	e6e78ce3          	beq	a5,a4,532 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 6be:	f9478693          	addi	a3,a5,-108
 6c2:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 6c6:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 6c8:	4701                	li	a4,0
 6ca:	bbdd                	j	4c0 <vprintf+0xa6>

00000000000006cc <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 6cc:	715d                	addi	sp,sp,-80
 6ce:	ec06                	sd	ra,24(sp)
 6d0:	e822                	sd	s0,16(sp)
 6d2:	1000                	addi	s0,sp,32
 6d4:	e010                	sd	a2,0(s0)
 6d6:	e414                	sd	a3,8(s0)
 6d8:	e818                	sd	a4,16(s0)
 6da:	ec1c                	sd	a5,24(s0)
 6dc:	03043023          	sd	a6,32(s0)
 6e0:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 6e4:	8622                	mv	a2,s0
 6e6:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 6ea:	d31ff0ef          	jal	41a <vprintf>
}
 6ee:	60e2                	ld	ra,24(sp)
 6f0:	6442                	ld	s0,16(sp)
 6f2:	6161                	addi	sp,sp,80
 6f4:	8082                	ret

00000000000006f6 <printf>:

void
printf(const char *fmt, ...)
{
 6f6:	711d                	addi	sp,sp,-96
 6f8:	ec06                	sd	ra,24(sp)
 6fa:	e822                	sd	s0,16(sp)
 6fc:	1000                	addi	s0,sp,32
 6fe:	e40c                	sd	a1,8(s0)
 700:	e810                	sd	a2,16(s0)
 702:	ec14                	sd	a3,24(s0)
 704:	f018                	sd	a4,32(s0)
 706:	f41c                	sd	a5,40(s0)
 708:	03043823          	sd	a6,48(s0)
 70c:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 710:	00840613          	addi	a2,s0,8
 714:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 718:	85aa                	mv	a1,a0
 71a:	4505                	li	a0,1
 71c:	cffff0ef          	jal	41a <vprintf>
}
 720:	60e2                	ld	ra,24(sp)
 722:	6442                	ld	s0,16(sp)
 724:	6125                	addi	sp,sp,96
 726:	8082                	ret

0000000000000728 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 728:	1141                	addi	sp,sp,-16
 72a:	e406                	sd	ra,8(sp)
 72c:	e022                	sd	s0,0(sp)
 72e:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 730:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 734:	00001797          	auipc	a5,0x1
 738:	8cc7b783          	ld	a5,-1844(a5) # 1000 <freep>
 73c:	a095                	j	7a0 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 73e:	ff852583          	lw	a1,-8(a0)
 742:	6390                	ld	a2,0(a5)
 744:	02059813          	slli	a6,a1,0x20
 748:	01c85693          	srli	a3,a6,0x1c
 74c:	96ba                	add	a3,a3,a4
 74e:	02d60563          	beq	a2,a3,778 <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 752:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 756:	4790                	lw	a2,8(a5)
 758:	02061593          	slli	a1,a2,0x20
 75c:	01c5d693          	srli	a3,a1,0x1c
 760:	96be                	add	a3,a3,a5
 762:	02d70263          	beq	a4,a3,786 <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 766:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 768:	00001717          	auipc	a4,0x1
 76c:	88f73c23          	sd	a5,-1896(a4) # 1000 <freep>
}
 770:	60a2                	ld	ra,8(sp)
 772:	6402                	ld	s0,0(sp)
 774:	0141                	addi	sp,sp,16
 776:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 778:	4614                	lw	a3,8(a2)
 77a:	9ead                	addw	a3,a3,a1
 77c:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 780:	6394                	ld	a3,0(a5)
 782:	6290                	ld	a2,0(a3)
 784:	b7f9                	j	752 <free+0x2a>
    p->s.size += bp->s.size;
 786:	ff852703          	lw	a4,-8(a0)
 78a:	9f31                	addw	a4,a4,a2
 78c:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 78e:	ff053703          	ld	a4,-16(a0)
 792:	bfd1                	j	766 <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 794:	6394                	ld	a3,0(a5)
 796:	00d7e463          	bltu	a5,a3,79e <free+0x76>
 79a:	fad762e3          	bltu	a4,a3,73e <free+0x16>
 79e:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 7a0:	fee7fae3          	bgeu	a5,a4,794 <free+0x6c>
 7a4:	6394                	ld	a3,0(a5)
 7a6:	f8d76ce3          	bltu	a4,a3,73e <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 7aa:	f8d7fae3          	bgeu	a5,a3,73e <free+0x16>
 7ae:	87b6                	mv	a5,a3
 7b0:	bfc5                	j	7a0 <free+0x78>

00000000000007b2 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 7b2:	7139                	addi	sp,sp,-64
 7b4:	fc06                	sd	ra,56(sp)
 7b6:	f822                	sd	s0,48(sp)
 7b8:	f04a                	sd	s2,32(sp)
 7ba:	ec4e                	sd	s3,24(sp)
 7bc:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 7be:	02051993          	slli	s3,a0,0x20
 7c2:	0209d993          	srli	s3,s3,0x20
 7c6:	09bd                	addi	s3,s3,15
 7c8:	0049d993          	srli	s3,s3,0x4
 7cc:	2985                	addiw	s3,s3,1
 7ce:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 7d0:	00001517          	auipc	a0,0x1
 7d4:	83053503          	ld	a0,-2000(a0) # 1000 <freep>
 7d8:	c905                	beqz	a0,808 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7da:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 7dc:	4798                	lw	a4,8(a5)
 7de:	09377663          	bgeu	a4,s3,86a <malloc+0xb8>
 7e2:	f426                	sd	s1,40(sp)
 7e4:	e852                	sd	s4,16(sp)
 7e6:	e456                	sd	s5,8(sp)
 7e8:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 7ea:	8a4e                	mv	s4,s3
 7ec:	6705                	lui	a4,0x1
 7ee:	00e9f363          	bgeu	s3,a4,7f4 <malloc+0x42>
 7f2:	6a05                	lui	s4,0x1
 7f4:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 7f8:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 7fc:	00001497          	auipc	s1,0x1
 800:	80448493          	addi	s1,s1,-2044 # 1000 <freep>
  if(p == (char*)-1)
 804:	5afd                	li	s5,-1
 806:	a83d                	j	844 <malloc+0x92>
 808:	f426                	sd	s1,40(sp)
 80a:	e852                	sd	s4,16(sp)
 80c:	e456                	sd	s5,8(sp)
 80e:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 810:	00001797          	auipc	a5,0x1
 814:	80078793          	addi	a5,a5,-2048 # 1010 <base>
 818:	00000717          	auipc	a4,0x0
 81c:	7ef73423          	sd	a5,2024(a4) # 1000 <freep>
 820:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 822:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 826:	b7d1                	j	7ea <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 828:	6398                	ld	a4,0(a5)
 82a:	e118                	sd	a4,0(a0)
 82c:	a899                	j	882 <malloc+0xd0>
  hp->s.size = nu;
 82e:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 832:	0541                	addi	a0,a0,16
 834:	ef5ff0ef          	jal	728 <free>
  return freep;
 838:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 83a:	c125                	beqz	a0,89a <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 83c:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 83e:	4798                	lw	a4,8(a5)
 840:	03277163          	bgeu	a4,s2,862 <malloc+0xb0>
    if(p == freep)
 844:	6098                	ld	a4,0(s1)
 846:	853e                	mv	a0,a5
 848:	fef71ae3          	bne	a4,a5,83c <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 84c:	8552                	mv	a0,s4
 84e:	aefff0ef          	jal	33c <sbrk>
  if(p == (char*)-1)
 852:	fd551ee3          	bne	a0,s5,82e <malloc+0x7c>
        return 0;
 856:	4501                	li	a0,0
 858:	74a2                	ld	s1,40(sp)
 85a:	6a42                	ld	s4,16(sp)
 85c:	6aa2                	ld	s5,8(sp)
 85e:	6b02                	ld	s6,0(sp)
 860:	a03d                	j	88e <malloc+0xdc>
 862:	74a2                	ld	s1,40(sp)
 864:	6a42                	ld	s4,16(sp)
 866:	6aa2                	ld	s5,8(sp)
 868:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 86a:	fae90fe3          	beq	s2,a4,828 <malloc+0x76>
        p->s.size -= nunits;
 86e:	4137073b          	subw	a4,a4,s3
 872:	c798                	sw	a4,8(a5)
        p += p->s.size;
 874:	02071693          	slli	a3,a4,0x20
 878:	01c6d713          	srli	a4,a3,0x1c
 87c:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 87e:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 882:	00000717          	auipc	a4,0x0
 886:	76a73f23          	sd	a0,1918(a4) # 1000 <freep>
      return (void*)(p + 1);
 88a:	01078513          	addi	a0,a5,16
  }
}
 88e:	70e2                	ld	ra,56(sp)
 890:	7442                	ld	s0,48(sp)
 892:	7902                	ld	s2,32(sp)
 894:	69e2                	ld	s3,24(sp)
 896:	6121                	addi	sp,sp,64
 898:	8082                	ret
 89a:	74a2                	ld	s1,40(sp)
 89c:	6a42                	ld	s4,16(sp)
 89e:	6aa2                	ld	s5,8(sp)
 8a0:	6b02                	ld	s6,0(sp)
 8a2:	b7f5                	j	88e <malloc+0xdc>
