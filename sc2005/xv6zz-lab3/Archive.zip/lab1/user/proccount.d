user/proccount.o: user/proccount.c kernel/types.h kernel/stat.h \
 user/user.h
