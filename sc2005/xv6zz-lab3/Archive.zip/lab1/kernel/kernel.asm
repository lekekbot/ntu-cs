
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00008117          	auipc	sp,0x8
    80000004:	92010113          	addi	sp,sp,-1760 # 80007920 <stack0>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	04e000ef          	jal	80000064 <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e406                	sd	ra,8(sp)
    80000020:	e022                	sd	s0,0(sp)
    80000022:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000024:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000028:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002c:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80000030:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000034:	577d                	li	a4,-1
    80000036:	177e                	slli	a4,a4,0x3f
    80000038:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    8000003a:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003e:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000042:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000046:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    8000004a:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    8000004e:	000f4737          	lui	a4,0xf4
    80000052:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000056:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000058:	14d79073          	csrw	stimecmp,a5
}
    8000005c:	60a2                	ld	ra,8(sp)
    8000005e:	6402                	ld	s0,0(sp)
    80000060:	0141                	addi	sp,sp,16
    80000062:	8082                	ret

0000000080000064 <start>:
{
    80000064:	1141                	addi	sp,sp,-16
    80000066:	e406                	sd	ra,8(sp)
    80000068:	e022                	sd	s0,0(sp)
    8000006a:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    8000006c:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000070:	7779                	lui	a4,0xffffe
    80000072:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffddbaf>
    80000076:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000078:	6705                	lui	a4,0x1
    8000007a:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000007e:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80000080:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80000084:	00001797          	auipc	a5,0x1
    80000088:	e5878793          	addi	a5,a5,-424 # 80000edc <main>
    8000008c:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80000090:	4781                	li	a5,0
    80000092:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000096:	67c1                	lui	a5,0x10
    80000098:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000009a:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    8000009e:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    800000a2:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    800000a6:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r" (x));
    800000aa:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000ae:	57fd                	li	a5,-1
    800000b0:	83a9                	srli	a5,a5,0xa
    800000b2:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b6:	47bd                	li	a5,15
    800000b8:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000bc:	f61ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000c0:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c4:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c6:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c8:	30200073          	mret
}
    800000cc:	60a2                	ld	ra,8(sp)
    800000ce:	6402                	ld	s0,0(sp)
    800000d0:	0141                	addi	sp,sp,16
    800000d2:	8082                	ret

00000000800000d4 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d4:	711d                	addi	sp,sp,-96
    800000d6:	ec86                	sd	ra,88(sp)
    800000d8:	e8a2                	sd	s0,80(sp)
    800000da:	e0ca                	sd	s2,64(sp)
    800000dc:	1080                	addi	s0,sp,96
  int i;

  for(i = 0; i < n; i++){
    800000de:	04c05763          	blez	a2,8000012c <consolewrite+0x58>
    800000e2:	e4a6                	sd	s1,72(sp)
    800000e4:	fc4e                	sd	s3,56(sp)
    800000e6:	f852                	sd	s4,48(sp)
    800000e8:	f456                	sd	s5,40(sp)
    800000ea:	f05a                	sd	s6,32(sp)
    800000ec:	ec5e                	sd	s7,24(sp)
    800000ee:	8a2a                	mv	s4,a0
    800000f0:	84ae                	mv	s1,a1
    800000f2:	89b2                	mv	s3,a2
    800000f4:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    800000f6:	faf40b93          	addi	s7,s0,-81
    800000fa:	4b05                	li	s6,1
    800000fc:	5afd                	li	s5,-1
    800000fe:	86da                	mv	a3,s6
    80000100:	8626                	mv	a2,s1
    80000102:	85d2                	mv	a1,s4
    80000104:	855e                	mv	a0,s7
    80000106:	17c020ef          	jal	80002282 <either_copyin>
    8000010a:	03550363          	beq	a0,s5,80000130 <consolewrite+0x5c>
      break;
    uartputc(c);
    8000010e:	faf44503          	lbu	a0,-81(s0)
    80000112:	06b000ef          	jal	8000097c <uartputc>
  for(i = 0; i < n; i++){
    80000116:	2905                	addiw	s2,s2,1
    80000118:	0485                	addi	s1,s1,1
    8000011a:	ff2992e3          	bne	s3,s2,800000fe <consolewrite+0x2a>
    8000011e:	64a6                	ld	s1,72(sp)
    80000120:	79e2                	ld	s3,56(sp)
    80000122:	7a42                	ld	s4,48(sp)
    80000124:	7aa2                	ld	s5,40(sp)
    80000126:	7b02                	ld	s6,32(sp)
    80000128:	6be2                	ld	s7,24(sp)
    8000012a:	a809                	j	8000013c <consolewrite+0x68>
    8000012c:	4901                	li	s2,0
    8000012e:	a039                	j	8000013c <consolewrite+0x68>
    80000130:	64a6                	ld	s1,72(sp)
    80000132:	79e2                	ld	s3,56(sp)
    80000134:	7a42                	ld	s4,48(sp)
    80000136:	7aa2                	ld	s5,40(sp)
    80000138:	7b02                	ld	s6,32(sp)
    8000013a:	6be2                	ld	s7,24(sp)
  }

  return i;
}
    8000013c:	854a                	mv	a0,s2
    8000013e:	60e6                	ld	ra,88(sp)
    80000140:	6446                	ld	s0,80(sp)
    80000142:	6906                	ld	s2,64(sp)
    80000144:	6125                	addi	sp,sp,96
    80000146:	8082                	ret

0000000080000148 <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000148:	711d                	addi	sp,sp,-96
    8000014a:	ec86                	sd	ra,88(sp)
    8000014c:	e8a2                	sd	s0,80(sp)
    8000014e:	e4a6                	sd	s1,72(sp)
    80000150:	e0ca                	sd	s2,64(sp)
    80000152:	fc4e                	sd	s3,56(sp)
    80000154:	f852                	sd	s4,48(sp)
    80000156:	f05a                	sd	s6,32(sp)
    80000158:	ec5e                	sd	s7,24(sp)
    8000015a:	1080                	addi	s0,sp,96
    8000015c:	8b2a                	mv	s6,a0
    8000015e:	8a2e                	mv	s4,a1
    80000160:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000162:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80000164:	0000f517          	auipc	a0,0xf
    80000168:	7bc50513          	addi	a0,a0,1980 # 8000f920 <cons>
    8000016c:	2f9000ef          	jal	80000c64 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80000170:	0000f497          	auipc	s1,0xf
    80000174:	7b048493          	addi	s1,s1,1968 # 8000f920 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    80000178:	00010917          	auipc	s2,0x10
    8000017c:	84090913          	addi	s2,s2,-1984 # 8000f9b8 <cons+0x98>
  while(n > 0){
    80000180:	0b305b63          	blez	s3,80000236 <consoleread+0xee>
    while(cons.r == cons.w){
    80000184:	0984a783          	lw	a5,152(s1)
    80000188:	09c4a703          	lw	a4,156(s1)
    8000018c:	0af71063          	bne	a4,a5,8000022c <consoleread+0xe4>
      if(killed(myproc())){
    80000190:	794010ef          	jal	80001924 <myproc>
    80000194:	789010ef          	jal	8000211c <killed>
    80000198:	e12d                	bnez	a0,800001fa <consoleread+0xb2>
      sleep(&cons.r, &cons.lock);
    8000019a:	85a6                	mv	a1,s1
    8000019c:	854a                	mv	a0,s2
    8000019e:	543010ef          	jal	80001ee0 <sleep>
    while(cons.r == cons.w){
    800001a2:	0984a783          	lw	a5,152(s1)
    800001a6:	09c4a703          	lw	a4,156(s1)
    800001aa:	fef703e3          	beq	a4,a5,80000190 <consoleread+0x48>
    800001ae:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001b0:	0000f717          	auipc	a4,0xf
    800001b4:	77070713          	addi	a4,a4,1904 # 8000f920 <cons>
    800001b8:	0017869b          	addiw	a3,a5,1
    800001bc:	08d72c23          	sw	a3,152(a4)
    800001c0:	07f7f693          	andi	a3,a5,127
    800001c4:	9736                	add	a4,a4,a3
    800001c6:	01874703          	lbu	a4,24(a4)
    800001ca:	00070a9b          	sext.w	s5,a4

    if(c == C('D')){  // end-of-file
    800001ce:	4691                	li	a3,4
    800001d0:	04da8663          	beq	s5,a3,8000021c <consoleread+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    800001d4:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    800001d8:	4685                	li	a3,1
    800001da:	faf40613          	addi	a2,s0,-81
    800001de:	85d2                	mv	a1,s4
    800001e0:	855a                	mv	a0,s6
    800001e2:	056020ef          	jal	80002238 <either_copyout>
    800001e6:	57fd                	li	a5,-1
    800001e8:	04f50663          	beq	a0,a5,80000234 <consoleread+0xec>
      break;

    dst++;
    800001ec:	0a05                	addi	s4,s4,1
    --n;
    800001ee:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    800001f0:	47a9                	li	a5,10
    800001f2:	04fa8b63          	beq	s5,a5,80000248 <consoleread+0x100>
    800001f6:	7aa2                	ld	s5,40(sp)
    800001f8:	b761                	j	80000180 <consoleread+0x38>
        release(&cons.lock);
    800001fa:	0000f517          	auipc	a0,0xf
    800001fe:	72650513          	addi	a0,a0,1830 # 8000f920 <cons>
    80000202:	2f3000ef          	jal	80000cf4 <release>
        return -1;
    80000206:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000208:	60e6                	ld	ra,88(sp)
    8000020a:	6446                	ld	s0,80(sp)
    8000020c:	64a6                	ld	s1,72(sp)
    8000020e:	6906                	ld	s2,64(sp)
    80000210:	79e2                	ld	s3,56(sp)
    80000212:	7a42                	ld	s4,48(sp)
    80000214:	7b02                	ld	s6,32(sp)
    80000216:	6be2                	ld	s7,24(sp)
    80000218:	6125                	addi	sp,sp,96
    8000021a:	8082                	ret
      if(n < target){
    8000021c:	0179fa63          	bgeu	s3,s7,80000230 <consoleread+0xe8>
        cons.r--;
    80000220:	0000f717          	auipc	a4,0xf
    80000224:	78f72c23          	sw	a5,1944(a4) # 8000f9b8 <cons+0x98>
    80000228:	7aa2                	ld	s5,40(sp)
    8000022a:	a031                	j	80000236 <consoleread+0xee>
    8000022c:	f456                	sd	s5,40(sp)
    8000022e:	b749                	j	800001b0 <consoleread+0x68>
    80000230:	7aa2                	ld	s5,40(sp)
    80000232:	a011                	j	80000236 <consoleread+0xee>
    80000234:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80000236:	0000f517          	auipc	a0,0xf
    8000023a:	6ea50513          	addi	a0,a0,1770 # 8000f920 <cons>
    8000023e:	2b7000ef          	jal	80000cf4 <release>
  return target - n;
    80000242:	413b853b          	subw	a0,s7,s3
    80000246:	b7c9                	j	80000208 <consoleread+0xc0>
    80000248:	7aa2                	ld	s5,40(sp)
    8000024a:	b7f5                	j	80000236 <consoleread+0xee>

000000008000024c <consputc>:
{
    8000024c:	1141                	addi	sp,sp,-16
    8000024e:	e406                	sd	ra,8(sp)
    80000250:	e022                	sd	s0,0(sp)
    80000252:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000254:	10000793          	li	a5,256
    80000258:	00f50863          	beq	a0,a5,80000268 <consputc+0x1c>
    uartputc_sync(c);
    8000025c:	652000ef          	jal	800008ae <uartputc_sync>
}
    80000260:	60a2                	ld	ra,8(sp)
    80000262:	6402                	ld	s0,0(sp)
    80000264:	0141                	addi	sp,sp,16
    80000266:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80000268:	4521                	li	a0,8
    8000026a:	644000ef          	jal	800008ae <uartputc_sync>
    8000026e:	02000513          	li	a0,32
    80000272:	63c000ef          	jal	800008ae <uartputc_sync>
    80000276:	4521                	li	a0,8
    80000278:	636000ef          	jal	800008ae <uartputc_sync>
    8000027c:	b7d5                	j	80000260 <consputc+0x14>

000000008000027e <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    8000027e:	1101                	addi	sp,sp,-32
    80000280:	ec06                	sd	ra,24(sp)
    80000282:	e822                	sd	s0,16(sp)
    80000284:	e426                	sd	s1,8(sp)
    80000286:	1000                	addi	s0,sp,32
    80000288:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    8000028a:	0000f517          	auipc	a0,0xf
    8000028e:	69650513          	addi	a0,a0,1686 # 8000f920 <cons>
    80000292:	1d3000ef          	jal	80000c64 <acquire>

  switch(c){
    80000296:	47d5                	li	a5,21
    80000298:	0af48163          	beq	s1,a5,8000033a <consoleintr+0xbc>
    8000029c:	0297c563          	blt	a5,s1,800002c6 <consoleintr+0x48>
    800002a0:	47a1                	li	a5,8
    800002a2:	0ef48663          	beq	s1,a5,8000038e <consoleintr+0x110>
    800002a6:	47c1                	li	a5,16
    800002a8:	10f49763          	bne	s1,a5,800003b6 <consoleintr+0x138>
  case C('P'):  // Print process list.
    procdump();
    800002ac:	054020ef          	jal	80002300 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002b0:	0000f517          	auipc	a0,0xf
    800002b4:	67050513          	addi	a0,a0,1648 # 8000f920 <cons>
    800002b8:	23d000ef          	jal	80000cf4 <release>
}
    800002bc:	60e2                	ld	ra,24(sp)
    800002be:	6442                	ld	s0,16(sp)
    800002c0:	64a2                	ld	s1,8(sp)
    800002c2:	6105                	addi	sp,sp,32
    800002c4:	8082                	ret
  switch(c){
    800002c6:	07f00793          	li	a5,127
    800002ca:	0cf48263          	beq	s1,a5,8000038e <consoleintr+0x110>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002ce:	0000f717          	auipc	a4,0xf
    800002d2:	65270713          	addi	a4,a4,1618 # 8000f920 <cons>
    800002d6:	0a072783          	lw	a5,160(a4)
    800002da:	09872703          	lw	a4,152(a4)
    800002de:	9f99                	subw	a5,a5,a4
    800002e0:	07f00713          	li	a4,127
    800002e4:	fcf766e3          	bltu	a4,a5,800002b0 <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    800002e8:	47b5                	li	a5,13
    800002ea:	0cf48963          	beq	s1,a5,800003bc <consoleintr+0x13e>
      consputc(c);
    800002ee:	8526                	mv	a0,s1
    800002f0:	f5dff0ef          	jal	8000024c <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800002f4:	0000f717          	auipc	a4,0xf
    800002f8:	62c70713          	addi	a4,a4,1580 # 8000f920 <cons>
    800002fc:	0a072683          	lw	a3,160(a4)
    80000300:	0016879b          	addiw	a5,a3,1
    80000304:	863e                	mv	a2,a5
    80000306:	0af72023          	sw	a5,160(a4)
    8000030a:	07f6f693          	andi	a3,a3,127
    8000030e:	9736                	add	a4,a4,a3
    80000310:	00970c23          	sb	s1,24(a4)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80000314:	ff648713          	addi	a4,s1,-10
    80000318:	00173713          	seqz	a4,a4
    8000031c:	14f1                	addi	s1,s1,-4
    8000031e:	0014b493          	seqz	s1,s1
    80000322:	8f45                	or	a4,a4,s1
    80000324:	e361                	bnez	a4,800003e4 <consoleintr+0x166>
    80000326:	0000f717          	auipc	a4,0xf
    8000032a:	69272703          	lw	a4,1682(a4) # 8000f9b8 <cons+0x98>
    8000032e:	9f99                	subw	a5,a5,a4
    80000330:	08000713          	li	a4,128
    80000334:	f6e79ee3          	bne	a5,a4,800002b0 <consoleintr+0x32>
    80000338:	a075                	j	800003e4 <consoleintr+0x166>
    8000033a:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    8000033c:	0000f717          	auipc	a4,0xf
    80000340:	5e470713          	addi	a4,a4,1508 # 8000f920 <cons>
    80000344:	0a072783          	lw	a5,160(a4)
    80000348:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    8000034c:	0000f497          	auipc	s1,0xf
    80000350:	5d448493          	addi	s1,s1,1492 # 8000f920 <cons>
    while(cons.e != cons.w &&
    80000354:	4929                	li	s2,10
    80000356:	02f70863          	beq	a4,a5,80000386 <consoleintr+0x108>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    8000035a:	37fd                	addiw	a5,a5,-1
    8000035c:	07f7f713          	andi	a4,a5,127
    80000360:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    80000362:	01874703          	lbu	a4,24(a4)
    80000366:	03270263          	beq	a4,s2,8000038a <consoleintr+0x10c>
      cons.e--;
    8000036a:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    8000036e:	10000513          	li	a0,256
    80000372:	edbff0ef          	jal	8000024c <consputc>
    while(cons.e != cons.w &&
    80000376:	0a04a783          	lw	a5,160(s1)
    8000037a:	09c4a703          	lw	a4,156(s1)
    8000037e:	fcf71ee3          	bne	a4,a5,8000035a <consoleintr+0xdc>
    80000382:	6902                	ld	s2,0(sp)
    80000384:	b735                	j	800002b0 <consoleintr+0x32>
    80000386:	6902                	ld	s2,0(sp)
    80000388:	b725                	j	800002b0 <consoleintr+0x32>
    8000038a:	6902                	ld	s2,0(sp)
    8000038c:	b715                	j	800002b0 <consoleintr+0x32>
    if(cons.e != cons.w){
    8000038e:	0000f717          	auipc	a4,0xf
    80000392:	59270713          	addi	a4,a4,1426 # 8000f920 <cons>
    80000396:	0a072783          	lw	a5,160(a4)
    8000039a:	09c72703          	lw	a4,156(a4)
    8000039e:	f0f709e3          	beq	a4,a5,800002b0 <consoleintr+0x32>
      cons.e--;
    800003a2:	37fd                	addiw	a5,a5,-1
    800003a4:	0000f717          	auipc	a4,0xf
    800003a8:	60f72e23          	sw	a5,1564(a4) # 8000f9c0 <cons+0xa0>
      consputc(BACKSPACE);
    800003ac:	10000513          	li	a0,256
    800003b0:	e9dff0ef          	jal	8000024c <consputc>
    800003b4:	bdf5                	j	800002b0 <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800003b6:	ee048de3          	beqz	s1,800002b0 <consoleintr+0x32>
    800003ba:	bf11                	j	800002ce <consoleintr+0x50>
      consputc(c);
    800003bc:	4529                	li	a0,10
    800003be:	e8fff0ef          	jal	8000024c <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003c2:	0000f797          	auipc	a5,0xf
    800003c6:	55e78793          	addi	a5,a5,1374 # 8000f920 <cons>
    800003ca:	0a07a703          	lw	a4,160(a5)
    800003ce:	0017069b          	addiw	a3,a4,1
    800003d2:	8636                	mv	a2,a3
    800003d4:	0ad7a023          	sw	a3,160(a5)
    800003d8:	07f77713          	andi	a4,a4,127
    800003dc:	97ba                	add	a5,a5,a4
    800003de:	4729                	li	a4,10
    800003e0:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    800003e4:	0000f797          	auipc	a5,0xf
    800003e8:	5cc7ac23          	sw	a2,1496(a5) # 8000f9bc <cons+0x9c>
        wakeup(&cons.r);
    800003ec:	0000f517          	auipc	a0,0xf
    800003f0:	5cc50513          	addi	a0,a0,1484 # 8000f9b8 <cons+0x98>
    800003f4:	339010ef          	jal	80001f2c <wakeup>
    800003f8:	bd65                	j	800002b0 <consoleintr+0x32>

00000000800003fa <consoleinit>:

void
consoleinit(void)
{
    800003fa:	1141                	addi	sp,sp,-16
    800003fc:	e406                	sd	ra,8(sp)
    800003fe:	e022                	sd	s0,0(sp)
    80000400:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000402:	00007597          	auipc	a1,0x7
    80000406:	bfe58593          	addi	a1,a1,-1026 # 80007000 <etext>
    8000040a:	0000f517          	auipc	a0,0xf
    8000040e:	51650513          	addi	a0,a0,1302 # 8000f920 <cons>
    80000412:	7c8000ef          	jal	80000bda <initlock>

  uartinit();
    80000416:	442000ef          	jal	80000858 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    8000041a:	0001f797          	auipc	a5,0x1f
    8000041e:	69e78793          	addi	a5,a5,1694 # 8001fab8 <devsw>
    80000422:	00000717          	auipc	a4,0x0
    80000426:	d2670713          	addi	a4,a4,-730 # 80000148 <consoleread>
    8000042a:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    8000042c:	00000717          	auipc	a4,0x0
    80000430:	ca870713          	addi	a4,a4,-856 # 800000d4 <consolewrite>
    80000434:	ef98                	sd	a4,24(a5)
}
    80000436:	60a2                	ld	ra,8(sp)
    80000438:	6402                	ld	s0,0(sp)
    8000043a:	0141                	addi	sp,sp,16
    8000043c:	8082                	ret

000000008000043e <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    8000043e:	7139                	addi	sp,sp,-64
    80000440:	fc06                	sd	ra,56(sp)
    80000442:	f822                	sd	s0,48(sp)
    80000444:	f04a                	sd	s2,32(sp)
    80000446:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    80000448:	c219                	beqz	a2,8000044e <printint+0x10>
    8000044a:	08054063          	bltz	a0,800004ca <printint+0x8c>
    x = -xx;
  else
    x = xx;
    8000044e:	4301                	li	t1,0

  i = 0;
    80000450:	fc840913          	addi	s2,s0,-56
    x = xx;
    80000454:	86ca                	mv	a3,s2
  i = 0;
    80000456:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    80000458:	00007817          	auipc	a6,0x7
    8000045c:	31880813          	addi	a6,a6,792 # 80007770 <digits>
    80000460:	88ba                	mv	a7,a4
    80000462:	0017061b          	addiw	a2,a4,1
    80000466:	8732                	mv	a4,a2
    80000468:	02b577b3          	remu	a5,a0,a1
    8000046c:	97c2                	add	a5,a5,a6
    8000046e:	0007c783          	lbu	a5,0(a5)
    80000472:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    80000476:	87aa                	mv	a5,a0
    80000478:	02b55533          	divu	a0,a0,a1
    8000047c:	0685                	addi	a3,a3,1
    8000047e:	feb7f1e3          	bgeu	a5,a1,80000460 <printint+0x22>

  if(sign)
    80000482:	00030b63          	beqz	t1,80000498 <printint+0x5a>
    buf[i++] = '-';
    80000486:	fe040793          	addi	a5,s0,-32
    8000048a:	963e                	add	a2,a2,a5
    8000048c:	02d00793          	li	a5,45
    80000490:	fef60423          	sb	a5,-24(a2)
    80000494:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    80000498:	02e05463          	blez	a4,800004c0 <printint+0x82>
    8000049c:	f426                	sd	s1,40(sp)
    8000049e:	377d                	addiw	a4,a4,-1
    800004a0:	00e904b3          	add	s1,s2,a4
    800004a4:	197d                	addi	s2,s2,-1
    800004a6:	993a                	add	s2,s2,a4
    800004a8:	1702                	slli	a4,a4,0x20
    800004aa:	9301                	srli	a4,a4,0x20
    800004ac:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    800004b0:	0004c503          	lbu	a0,0(s1)
    800004b4:	d99ff0ef          	jal	8000024c <consputc>
  while(--i >= 0)
    800004b8:	14fd                	addi	s1,s1,-1
    800004ba:	ff249be3          	bne	s1,s2,800004b0 <printint+0x72>
    800004be:	74a2                	ld	s1,40(sp)
}
    800004c0:	70e2                	ld	ra,56(sp)
    800004c2:	7442                	ld	s0,48(sp)
    800004c4:	7902                	ld	s2,32(sp)
    800004c6:	6121                	addi	sp,sp,64
    800004c8:	8082                	ret
    x = -xx;
    800004ca:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800004ce:	4305                	li	t1,1
    x = -xx;
    800004d0:	b741                	j	80000450 <printint+0x12>

00000000800004d2 <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004d2:	7131                	addi	sp,sp,-192
    800004d4:	fc86                	sd	ra,120(sp)
    800004d6:	f8a2                	sd	s0,112(sp)
    800004d8:	f4a6                	sd	s1,104(sp)
    800004da:	ec6e                	sd	s11,24(sp)
    800004dc:	0100                	addi	s0,sp,128
    800004de:	84aa                	mv	s1,a0
    800004e0:	e40c                	sd	a1,8(s0)
    800004e2:	e810                	sd	a2,16(s0)
    800004e4:	ec14                	sd	a3,24(s0)
    800004e6:	f018                	sd	a4,32(s0)
    800004e8:	f41c                	sd	a5,40(s0)
    800004ea:	03043823          	sd	a6,48(s0)
    800004ee:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2, locking;
  char *s;

  locking = pr.locking;
    800004f2:	0000fd97          	auipc	s11,0xf
    800004f6:	4eedad83          	lw	s11,1262(s11) # 8000f9e0 <pr+0x18>
  if(locking)
    800004fa:	020d9d63          	bnez	s11,80000534 <printf+0x62>
    acquire(&pr.lock);

  va_start(ap, fmt);
    800004fe:	00840793          	addi	a5,s0,8
    80000502:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000506:	00054503          	lbu	a0,0(a0)
    8000050a:	20050c63          	beqz	a0,80000722 <printf+0x250>
    8000050e:	f0ca                	sd	s2,96(sp)
    80000510:	ecce                	sd	s3,88(sp)
    80000512:	e8d2                	sd	s4,80(sp)
    80000514:	e4d6                	sd	s5,72(sp)
    80000516:	e0da                	sd	s6,64(sp)
    80000518:	fc5e                	sd	s7,56(sp)
    8000051a:	f862                	sd	s8,48(sp)
    8000051c:	f06a                	sd	s10,32(sp)
    8000051e:	4a01                	li	s4,0
    if(cx != '%'){
    80000520:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    80000524:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    80000528:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 10, 0);
    8000052c:	4b29                	li	s6,10
    if(c0 == 'd'){
    8000052e:	06400b93          	li	s7,100
    80000532:	a80d                	j	80000564 <printf+0x92>
    acquire(&pr.lock);
    80000534:	0000f517          	auipc	a0,0xf
    80000538:	49450513          	addi	a0,a0,1172 # 8000f9c8 <pr>
    8000053c:	728000ef          	jal	80000c64 <acquire>
  va_start(ap, fmt);
    80000540:	00840793          	addi	a5,s0,8
    80000544:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000548:	0004c503          	lbu	a0,0(s1)
    8000054c:	f169                	bnez	a0,8000050e <printf+0x3c>
    8000054e:	aacd                	j	80000740 <printf+0x26e>
      consputc(cx);
    80000550:	cfdff0ef          	jal	8000024c <consputc>
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000554:	001a079b          	addiw	a5,s4,1
    80000558:	8a3e                	mv	s4,a5
    8000055a:	97a6                	add	a5,a5,s1
    8000055c:	0007c503          	lbu	a0,0(a5)
    80000560:	1a050763          	beqz	a0,8000070e <printf+0x23c>
    if(cx != '%'){
    80000564:	ff3516e3          	bne	a0,s3,80000550 <printf+0x7e>
    i++;
    80000568:	001a091b          	addiw	s2,s4,1
    c0 = fmt[i+0] & 0xff;
    8000056c:	012487b3          	add	a5,s1,s2
    80000570:	0007ca83          	lbu	s5,0(a5)
    if(c0) c1 = fmt[i+1] & 0xff;
    80000574:	1e0a8663          	beqz	s5,80000760 <printf+0x28e>
    80000578:	0017c703          	lbu	a4,1(a5)
    if(c1) c2 = fmt[i+2] & 0xff;
    8000057c:	1c070963          	beqz	a4,8000074e <printf+0x27c>
    if(c0 == 'd'){
    80000580:	037a8963          	beq	s5,s7,800005b2 <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80000584:	f94a8793          	addi	a5,s5,-108
    80000588:	0017b793          	seqz	a5,a5
    8000058c:	f9c70693          	addi	a3,a4,-100
    80000590:	0016b693          	seqz	a3,a3
    80000594:	8efd                	and	a3,a3,a5
    80000596:	ca9d                	beqz	a3,800005cc <printf+0xfa>
      printint(va_arg(ap, uint64), 10, 1);
    80000598:	f8843783          	ld	a5,-120(s0)
    8000059c:	00878713          	addi	a4,a5,8
    800005a0:	f8e43423          	sd	a4,-120(s0)
    800005a4:	4605                	li	a2,1
    800005a6:	85da                	mv	a1,s6
    800005a8:	6388                	ld	a0,0(a5)
    800005aa:	e95ff0ef          	jal	8000043e <printint>
      i += 1;
    800005ae:	2a09                	addiw	s4,s4,2
    800005b0:	b755                	j	80000554 <printf+0x82>
      printint(va_arg(ap, int), 10, 1);
    800005b2:	f8843783          	ld	a5,-120(s0)
    800005b6:	00878713          	addi	a4,a5,8
    800005ba:	f8e43423          	sd	a4,-120(s0)
    800005be:	4605                	li	a2,1
    800005c0:	85da                	mv	a1,s6
    800005c2:	4388                	lw	a0,0(a5)
    800005c4:	e7bff0ef          	jal	8000043e <printint>
    i++;
    800005c8:	8a4a                	mv	s4,s2
    800005ca:	b769                	j	80000554 <printf+0x82>
    if(c1) c2 = fmt[i+2] & 0xff;
    800005cc:	012486b3          	add	a3,s1,s2
    800005d0:	863a                	mv	a2,a4
    800005d2:	0026c703          	lbu	a4,2(a3)
    800005d6:	aa59                	j	8000076c <printf+0x29a>
      printint(va_arg(ap, uint64), 10, 1);
    800005d8:	f8843783          	ld	a5,-120(s0)
    800005dc:	00878713          	addi	a4,a5,8
    800005e0:	f8e43423          	sd	a4,-120(s0)
    800005e4:	4605                	li	a2,1
    800005e6:	45a9                	li	a1,10
    800005e8:	6388                	ld	a0,0(a5)
    800005ea:	e55ff0ef          	jal	8000043e <printint>
      i += 2;
    800005ee:	2a0d                	addiw	s4,s4,3
    800005f0:	b795                	j	80000554 <printf+0x82>
      printint(va_arg(ap, int), 10, 0);
    800005f2:	f8843783          	ld	a5,-120(s0)
    800005f6:	00878713          	addi	a4,a5,8
    800005fa:	f8e43423          	sd	a4,-120(s0)
    800005fe:	4601                	li	a2,0
    80000600:	85da                	mv	a1,s6
    80000602:	4388                	lw	a0,0(a5)
    80000604:	e3bff0ef          	jal	8000043e <printint>
    80000608:	b7c1                	j	800005c8 <printf+0xf6>
      printint(va_arg(ap, uint64), 10, 0);
    8000060a:	f8843783          	ld	a5,-120(s0)
    8000060e:	00878713          	addi	a4,a5,8
    80000612:	f8e43423          	sd	a4,-120(s0)
    80000616:	4601                	li	a2,0
    80000618:	85da                	mv	a1,s6
    8000061a:	6388                	ld	a0,0(a5)
    8000061c:	e23ff0ef          	jal	8000043e <printint>
      i += 1;
    80000620:	2a09                	addiw	s4,s4,2
    80000622:	bf0d                	j	80000554 <printf+0x82>
      printint(va_arg(ap, uint64), 10, 0);
    80000624:	f8843783          	ld	a5,-120(s0)
    80000628:	00878713          	addi	a4,a5,8
    8000062c:	f8e43423          	sd	a4,-120(s0)
    80000630:	4601                	li	a2,0
    80000632:	45a9                	li	a1,10
    80000634:	6388                	ld	a0,0(a5)
    80000636:	e09ff0ef          	jal	8000043e <printint>
      i += 2;
    8000063a:	2a0d                	addiw	s4,s4,3
    8000063c:	bf21                	j	80000554 <printf+0x82>
      printint(va_arg(ap, int), 16, 0);
    8000063e:	f8843783          	ld	a5,-120(s0)
    80000642:	00878713          	addi	a4,a5,8
    80000646:	f8e43423          	sd	a4,-120(s0)
    8000064a:	4601                	li	a2,0
    8000064c:	45c1                	li	a1,16
    8000064e:	4388                	lw	a0,0(a5)
    80000650:	defff0ef          	jal	8000043e <printint>
    80000654:	bf95                	j	800005c8 <printf+0xf6>
    } else if(c0 == 'l' && c1 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    80000656:	f8843783          	ld	a5,-120(s0)
    8000065a:	00878713          	addi	a4,a5,8
    8000065e:	f8e43423          	sd	a4,-120(s0)
    80000662:	4601                	li	a2,0
    80000664:	45c1                	li	a1,16
    80000666:	6388                	ld	a0,0(a5)
    80000668:	dd7ff0ef          	jal	8000043e <printint>
      i += 1;
    8000066c:	2a09                	addiw	s4,s4,2
    8000066e:	b5dd                	j	80000554 <printf+0x82>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    80000670:	f8843783          	ld	a5,-120(s0)
    80000674:	00878713          	addi	a4,a5,8
    80000678:	f8e43423          	sd	a4,-120(s0)
    8000067c:	45c1                	li	a1,16
    8000067e:	6388                	ld	a0,0(a5)
    80000680:	dbfff0ef          	jal	8000043e <printint>
      i += 2;
    80000684:	2a0d                	addiw	s4,s4,3
    80000686:	b5f9                	j	80000554 <printf+0x82>
    80000688:	f466                	sd	s9,40(sp)
    } else if(c0 == 'p'){
      printptr(va_arg(ap, uint64));
    8000068a:	f8843783          	ld	a5,-120(s0)
    8000068e:	00878713          	addi	a4,a5,8
    80000692:	f8e43423          	sd	a4,-120(s0)
    80000696:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    8000069a:	03000513          	li	a0,48
    8000069e:	bafff0ef          	jal	8000024c <consputc>
  consputc('x');
    800006a2:	07800513          	li	a0,120
    800006a6:	ba7ff0ef          	jal	8000024c <consputc>
    800006aa:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006ac:	00007c97          	auipc	s9,0x7
    800006b0:	0c4c8c93          	addi	s9,s9,196 # 80007770 <digits>
    800006b4:	03cad793          	srli	a5,s5,0x3c
    800006b8:	97e6                	add	a5,a5,s9
    800006ba:	0007c503          	lbu	a0,0(a5)
    800006be:	b8fff0ef          	jal	8000024c <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006c2:	0a92                	slli	s5,s5,0x4
    800006c4:	3a7d                	addiw	s4,s4,-1
    800006c6:	fe0a17e3          	bnez	s4,800006b4 <printf+0x1e2>
    800006ca:	7ca2                	ld	s9,40(sp)
    800006cc:	bdf5                	j	800005c8 <printf+0xf6>
    } else if(c0 == 's'){
      if((s = va_arg(ap, char*)) == 0)
    800006ce:	f8843783          	ld	a5,-120(s0)
    800006d2:	00878713          	addi	a4,a5,8
    800006d6:	f8e43423          	sd	a4,-120(s0)
    800006da:	0007ba03          	ld	s4,0(a5)
    800006de:	000a0d63          	beqz	s4,800006f8 <printf+0x226>
        s = "(null)";
      for(; *s; s++)
    800006e2:	000a4503          	lbu	a0,0(s4)
    800006e6:	ee0501e3          	beqz	a0,800005c8 <printf+0xf6>
        consputc(*s);
    800006ea:	b63ff0ef          	jal	8000024c <consputc>
      for(; *s; s++)
    800006ee:	0a05                	addi	s4,s4,1
    800006f0:	000a4503          	lbu	a0,0(s4)
    800006f4:	f97d                	bnez	a0,800006ea <printf+0x218>
    800006f6:	bdc9                	j	800005c8 <printf+0xf6>
        s = "(null)";
    800006f8:	00007a17          	auipc	s4,0x7
    800006fc:	910a0a13          	addi	s4,s4,-1776 # 80007008 <etext+0x8>
      for(; *s; s++)
    80000700:	02800513          	li	a0,40
    80000704:	b7dd                	j	800006ea <printf+0x218>
    } else if(c0 == '%'){
      consputc('%');
    80000706:	8556                	mv	a0,s5
    80000708:	b45ff0ef          	jal	8000024c <consputc>
    8000070c:	bd75                	j	800005c8 <printf+0xf6>
    }
#endif
  }
  va_end(ap);

  if(locking)
    8000070e:	020d9163          	bnez	s11,80000730 <printf+0x25e>
    80000712:	7906                	ld	s2,96(sp)
    80000714:	69e6                	ld	s3,88(sp)
    80000716:	6a46                	ld	s4,80(sp)
    80000718:	6aa6                	ld	s5,72(sp)
    8000071a:	6b06                	ld	s6,64(sp)
    8000071c:	7be2                	ld	s7,56(sp)
    8000071e:	7c42                	ld	s8,48(sp)
    80000720:	7d02                	ld	s10,32(sp)
    release(&pr.lock);

  return 0;
}
    80000722:	4501                	li	a0,0
    80000724:	70e6                	ld	ra,120(sp)
    80000726:	7446                	ld	s0,112(sp)
    80000728:	74a6                	ld	s1,104(sp)
    8000072a:	6de2                	ld	s11,24(sp)
    8000072c:	6129                	addi	sp,sp,192
    8000072e:	8082                	ret
    80000730:	7906                	ld	s2,96(sp)
    80000732:	69e6                	ld	s3,88(sp)
    80000734:	6a46                	ld	s4,80(sp)
    80000736:	6aa6                	ld	s5,72(sp)
    80000738:	6b06                	ld	s6,64(sp)
    8000073a:	7be2                	ld	s7,56(sp)
    8000073c:	7c42                	ld	s8,48(sp)
    8000073e:	7d02                	ld	s10,32(sp)
    release(&pr.lock);
    80000740:	0000f517          	auipc	a0,0xf
    80000744:	28850513          	addi	a0,a0,648 # 8000f9c8 <pr>
    80000748:	5ac000ef          	jal	80000cf4 <release>
    8000074c:	bfd9                	j	80000722 <printf+0x250>
    if(c0 == 'd'){
    8000074e:	e77a82e3          	beq	s5,s7,800005b2 <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80000752:	f94a8793          	addi	a5,s5,-108
    80000756:	0017b793          	seqz	a5,a5
    8000075a:	863a                	mv	a2,a4
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000075c:	4681                	li	a3,0
    8000075e:	a01d                	j	80000784 <printf+0x2b2>
    } else if(c0 == 'l' && c1 == 'd'){
    80000760:	f94a8793          	addi	a5,s5,-108
    80000764:	0017b793          	seqz	a5,a5
    c1 = c2 = 0;
    80000768:	8656                	mv	a2,s5
    8000076a:	8756                	mv	a4,s5
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000076c:	f9460693          	addi	a3,a2,-108
    80000770:	0016b693          	seqz	a3,a3
    80000774:	8efd                	and	a3,a3,a5
    80000776:	f9c70593          	addi	a1,a4,-100
    8000077a:	0015b593          	seqz	a1,a1
    8000077e:	8df5                	and	a1,a1,a3
    80000780:	e4059ce3          	bnez	a1,800005d8 <printf+0x106>
    } else if(c0 == 'u'){
    80000784:	e78a87e3          	beq	s5,s8,800005f2 <printf+0x120>
    } else if(c0 == 'l' && c1 == 'u'){
    80000788:	f8b60593          	addi	a1,a2,-117
    8000078c:	0015b593          	seqz	a1,a1
    80000790:	8dfd                	and	a1,a1,a5
    80000792:	e6059ce3          	bnez	a1,8000060a <printf+0x138>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80000796:	f8b70593          	addi	a1,a4,-117
    8000079a:	0015b593          	seqz	a1,a1
    8000079e:	8df5                	and	a1,a1,a3
    800007a0:	e80592e3          	bnez	a1,80000624 <printf+0x152>
    } else if(c0 == 'x'){
    800007a4:	e9aa8de3          	beq	s5,s10,8000063e <printf+0x16c>
    } else if(c0 == 'l' && c1 == 'x'){
    800007a8:	f8860613          	addi	a2,a2,-120
    800007ac:	00163613          	seqz	a2,a2
    800007b0:	8e7d                	and	a2,a2,a5
    800007b2:	ea0612e3          	bnez	a2,80000656 <printf+0x184>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    800007b6:	f8870713          	addi	a4,a4,-120
    800007ba:	00173713          	seqz	a4,a4
    800007be:	8f75                	and	a4,a4,a3
    800007c0:	ea0718e3          	bnez	a4,80000670 <printf+0x19e>
    } else if(c0 == 'p'){
    800007c4:	07000793          	li	a5,112
    800007c8:	ecfa80e3          	beq	s5,a5,80000688 <printf+0x1b6>
    } else if(c0 == 's'){
    800007cc:	07300793          	li	a5,115
    800007d0:	eefa8fe3          	beq	s5,a5,800006ce <printf+0x1fc>
    } else if(c0 == '%'){
    800007d4:	02500793          	li	a5,37
    800007d8:	f2fa87e3          	beq	s5,a5,80000706 <printf+0x234>
    } else if(c0 == 0){
    800007dc:	f20a89e3          	beqz	s5,8000070e <printf+0x23c>
      consputc('%');
    800007e0:	02500513          	li	a0,37
    800007e4:	a69ff0ef          	jal	8000024c <consputc>
      consputc(c0);
    800007e8:	8556                	mv	a0,s5
    800007ea:	a63ff0ef          	jal	8000024c <consputc>
    800007ee:	bbe9                	j	800005c8 <printf+0xf6>

00000000800007f0 <panic>:

void
panic(char *s)
{
    800007f0:	1101                	addi	sp,sp,-32
    800007f2:	ec06                	sd	ra,24(sp)
    800007f4:	e822                	sd	s0,16(sp)
    800007f6:	e426                	sd	s1,8(sp)
    800007f8:	1000                	addi	s0,sp,32
    800007fa:	84aa                	mv	s1,a0
  pr.locking = 0;
    800007fc:	0000f797          	auipc	a5,0xf
    80000800:	1e07a223          	sw	zero,484(a5) # 8000f9e0 <pr+0x18>
  printf("panic: ");
    80000804:	00007517          	auipc	a0,0x7
    80000808:	81450513          	addi	a0,a0,-2028 # 80007018 <etext+0x18>
    8000080c:	cc7ff0ef          	jal	800004d2 <printf>
  printf("%s\n", s);
    80000810:	85a6                	mv	a1,s1
    80000812:	00007517          	auipc	a0,0x7
    80000816:	80e50513          	addi	a0,a0,-2034 # 80007020 <etext+0x20>
    8000081a:	cb9ff0ef          	jal	800004d2 <printf>
  panicked = 1; // freeze uart output from other CPUs
    8000081e:	4785                	li	a5,1
    80000820:	00007717          	auipc	a4,0x7
    80000824:	0cf72023          	sw	a5,192(a4) # 800078e0 <panicked>
  for(;;)
    80000828:	a001                	j	80000828 <panic+0x38>

000000008000082a <printfinit>:
    ;
}

void
printfinit(void)
{
    8000082a:	1141                	addi	sp,sp,-16
    8000082c:	e406                	sd	ra,8(sp)
    8000082e:	e022                	sd	s0,0(sp)
    80000830:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000832:	00006597          	auipc	a1,0x6
    80000836:	7f658593          	addi	a1,a1,2038 # 80007028 <etext+0x28>
    8000083a:	0000f517          	auipc	a0,0xf
    8000083e:	18e50513          	addi	a0,a0,398 # 8000f9c8 <pr>
    80000842:	398000ef          	jal	80000bda <initlock>
  pr.locking = 1;
    80000846:	4785                	li	a5,1
    80000848:	0000f717          	auipc	a4,0xf
    8000084c:	18f72c23          	sw	a5,408(a4) # 8000f9e0 <pr+0x18>
}
    80000850:	60a2                	ld	ra,8(sp)
    80000852:	6402                	ld	s0,0(sp)
    80000854:	0141                	addi	sp,sp,16
    80000856:	8082                	ret

0000000080000858 <uartinit>:

void uartstart();

void
uartinit(void)
{
    80000858:	1141                	addi	sp,sp,-16
    8000085a:	e406                	sd	ra,8(sp)
    8000085c:	e022                	sd	s0,0(sp)
    8000085e:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80000860:	100007b7          	lui	a5,0x10000
    80000864:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000868:	10000737          	lui	a4,0x10000
    8000086c:	f8000693          	li	a3,-128
    80000870:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80000874:	468d                	li	a3,3
    80000876:	10000637          	lui	a2,0x10000
    8000087a:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    8000087e:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    80000882:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    80000886:	8732                	mv	a4,a2
    80000888:	461d                	li	a2,7
    8000088a:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    8000088e:	00d780a3          	sb	a3,1(a5)

  initlock(&uart_tx_lock, "uart");
    80000892:	00006597          	auipc	a1,0x6
    80000896:	79e58593          	addi	a1,a1,1950 # 80007030 <etext+0x30>
    8000089a:	0000f517          	auipc	a0,0xf
    8000089e:	14e50513          	addi	a0,a0,334 # 8000f9e8 <uart_tx_lock>
    800008a2:	338000ef          	jal	80000bda <initlock>
}
    800008a6:	60a2                	ld	ra,8(sp)
    800008a8:	6402                	ld	s0,0(sp)
    800008aa:	0141                	addi	sp,sp,16
    800008ac:	8082                	ret

00000000800008ae <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    800008ae:	1101                	addi	sp,sp,-32
    800008b0:	ec06                	sd	ra,24(sp)
    800008b2:	e822                	sd	s0,16(sp)
    800008b4:	e426                	sd	s1,8(sp)
    800008b6:	1000                	addi	s0,sp,32
    800008b8:	84aa                	mv	s1,a0
  push_off();
    800008ba:	366000ef          	jal	80000c20 <push_off>

  if(panicked){
    800008be:	00007797          	auipc	a5,0x7
    800008c2:	0227a783          	lw	a5,34(a5) # 800078e0 <panicked>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800008c6:	10000737          	lui	a4,0x10000
    800008ca:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
  if(panicked){
    800008cc:	c391                	beqz	a5,800008d0 <uartputc_sync+0x22>
    for(;;)
    800008ce:	a001                	j	800008ce <uartputc_sync+0x20>
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800008d0:	00074783          	lbu	a5,0(a4)
    800008d4:	0207f793          	andi	a5,a5,32
    800008d8:	dfe5                	beqz	a5,800008d0 <uartputc_sync+0x22>
    ;
  WriteReg(THR, c);
    800008da:	100007b7          	lui	a5,0x10000
    800008de:	00978023          	sb	s1,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    800008e2:	3c2000ef          	jal	80000ca4 <pop_off>
}
    800008e6:	60e2                	ld	ra,24(sp)
    800008e8:	6442                	ld	s0,16(sp)
    800008ea:	64a2                	ld	s1,8(sp)
    800008ec:	6105                	addi	sp,sp,32
    800008ee:	8082                	ret

00000000800008f0 <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    800008f0:	00007797          	auipc	a5,0x7
    800008f4:	ff87b783          	ld	a5,-8(a5) # 800078e8 <uart_tx_r>
    800008f8:	00007717          	auipc	a4,0x7
    800008fc:	ff873703          	ld	a4,-8(a4) # 800078f0 <uart_tx_w>
    80000900:	06f70d63          	beq	a4,a5,8000097a <uartstart+0x8a>
{
    80000904:	7139                	addi	sp,sp,-64
    80000906:	fc06                	sd	ra,56(sp)
    80000908:	f822                	sd	s0,48(sp)
    8000090a:	f426                	sd	s1,40(sp)
    8000090c:	f04a                	sd	s2,32(sp)
    8000090e:	ec4e                	sd	s3,24(sp)
    80000910:	e852                	sd	s4,16(sp)
    80000912:	e456                	sd	s5,8(sp)
    80000914:	e05a                	sd	s6,0(sp)
    80000916:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80000918:	10000937          	lui	s2,0x10000
    8000091c:	0915                	addi	s2,s2,5 # 10000005 <_entry-0x6ffffffb>
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    8000091e:	0000fa97          	auipc	s5,0xf
    80000922:	0caa8a93          	addi	s5,s5,202 # 8000f9e8 <uart_tx_lock>
    uart_tx_r += 1;
    80000926:	00007497          	auipc	s1,0x7
    8000092a:	fc248493          	addi	s1,s1,-62 # 800078e8 <uart_tx_r>
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    
    WriteReg(THR, c);
    8000092e:	10000a37          	lui	s4,0x10000
    if(uart_tx_w == uart_tx_r){
    80000932:	00007997          	auipc	s3,0x7
    80000936:	fbe98993          	addi	s3,s3,-66 # 800078f0 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    8000093a:	00094703          	lbu	a4,0(s2)
    8000093e:	02077713          	andi	a4,a4,32
    80000942:	c315                	beqz	a4,80000966 <uartstart+0x76>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80000944:	01f7f713          	andi	a4,a5,31
    80000948:	9756                	add	a4,a4,s5
    8000094a:	01874b03          	lbu	s6,24(a4)
    uart_tx_r += 1;
    8000094e:	0785                	addi	a5,a5,1
    80000950:	e09c                	sd	a5,0(s1)
    wakeup(&uart_tx_r);
    80000952:	8526                	mv	a0,s1
    80000954:	5d8010ef          	jal	80001f2c <wakeup>
    WriteReg(THR, c);
    80000958:	016a0023          	sb	s6,0(s4) # 10000000 <_entry-0x70000000>
    if(uart_tx_w == uart_tx_r){
    8000095c:	609c                	ld	a5,0(s1)
    8000095e:	0009b703          	ld	a4,0(s3)
    80000962:	fcf71ce3          	bne	a4,a5,8000093a <uartstart+0x4a>
  }
}
    80000966:	70e2                	ld	ra,56(sp)
    80000968:	7442                	ld	s0,48(sp)
    8000096a:	74a2                	ld	s1,40(sp)
    8000096c:	7902                	ld	s2,32(sp)
    8000096e:	69e2                	ld	s3,24(sp)
    80000970:	6a42                	ld	s4,16(sp)
    80000972:	6aa2                	ld	s5,8(sp)
    80000974:	6b02                	ld	s6,0(sp)
    80000976:	6121                	addi	sp,sp,64
    80000978:	8082                	ret
    8000097a:	8082                	ret

000000008000097c <uartputc>:
{
    8000097c:	7179                	addi	sp,sp,-48
    8000097e:	f406                	sd	ra,40(sp)
    80000980:	f022                	sd	s0,32(sp)
    80000982:	ec26                	sd	s1,24(sp)
    80000984:	e84a                	sd	s2,16(sp)
    80000986:	e44e                	sd	s3,8(sp)
    80000988:	e052                	sd	s4,0(sp)
    8000098a:	1800                	addi	s0,sp,48
    8000098c:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    8000098e:	0000f517          	auipc	a0,0xf
    80000992:	05a50513          	addi	a0,a0,90 # 8000f9e8 <uart_tx_lock>
    80000996:	2ce000ef          	jal	80000c64 <acquire>
  if(panicked){
    8000099a:	00007797          	auipc	a5,0x7
    8000099e:	f467a783          	lw	a5,-186(a5) # 800078e0 <panicked>
    800009a2:	e3d1                	bnez	a5,80000a26 <uartputc+0xaa>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800009a4:	00007717          	auipc	a4,0x7
    800009a8:	f4c73703          	ld	a4,-180(a4) # 800078f0 <uart_tx_w>
    800009ac:	00007797          	auipc	a5,0x7
    800009b0:	f3c7b783          	ld	a5,-196(a5) # 800078e8 <uart_tx_r>
    800009b4:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    800009b8:	0000f997          	auipc	s3,0xf
    800009bc:	03098993          	addi	s3,s3,48 # 8000f9e8 <uart_tx_lock>
    800009c0:	00007497          	auipc	s1,0x7
    800009c4:	f2848493          	addi	s1,s1,-216 # 800078e8 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800009c8:	00007917          	auipc	s2,0x7
    800009cc:	f2890913          	addi	s2,s2,-216 # 800078f0 <uart_tx_w>
    800009d0:	00e79d63          	bne	a5,a4,800009ea <uartputc+0x6e>
    sleep(&uart_tx_r, &uart_tx_lock);
    800009d4:	85ce                	mv	a1,s3
    800009d6:	8526                	mv	a0,s1
    800009d8:	508010ef          	jal	80001ee0 <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800009dc:	00093703          	ld	a4,0(s2)
    800009e0:	609c                	ld	a5,0(s1)
    800009e2:	02078793          	addi	a5,a5,32
    800009e6:	fee787e3          	beq	a5,a4,800009d4 <uartputc+0x58>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    800009ea:	01f77693          	andi	a3,a4,31
    800009ee:	0000f797          	auipc	a5,0xf
    800009f2:	ffa78793          	addi	a5,a5,-6 # 8000f9e8 <uart_tx_lock>
    800009f6:	97b6                	add	a5,a5,a3
    800009f8:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    800009fc:	0705                	addi	a4,a4,1
    800009fe:	00007797          	auipc	a5,0x7
    80000a02:	eee7b923          	sd	a4,-270(a5) # 800078f0 <uart_tx_w>
  uartstart();
    80000a06:	eebff0ef          	jal	800008f0 <uartstart>
  release(&uart_tx_lock);
    80000a0a:	0000f517          	auipc	a0,0xf
    80000a0e:	fde50513          	addi	a0,a0,-34 # 8000f9e8 <uart_tx_lock>
    80000a12:	2e2000ef          	jal	80000cf4 <release>
}
    80000a16:	70a2                	ld	ra,40(sp)
    80000a18:	7402                	ld	s0,32(sp)
    80000a1a:	64e2                	ld	s1,24(sp)
    80000a1c:	6942                	ld	s2,16(sp)
    80000a1e:	69a2                	ld	s3,8(sp)
    80000a20:	6a02                	ld	s4,0(sp)
    80000a22:	6145                	addi	sp,sp,48
    80000a24:	8082                	ret
    for(;;)
    80000a26:	a001                	j	80000a26 <uartputc+0xaa>

0000000080000a28 <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    80000a28:	1141                	addi	sp,sp,-16
    80000a2a:	e406                	sd	ra,8(sp)
    80000a2c:	e022                	sd	s0,0(sp)
    80000a2e:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    80000a30:	100007b7          	lui	a5,0x10000
    80000a34:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80000a38:	8b85                	andi	a5,a5,1
    80000a3a:	cb89                	beqz	a5,80000a4c <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    80000a3c:	100007b7          	lui	a5,0x10000
    80000a40:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    80000a44:	60a2                	ld	ra,8(sp)
    80000a46:	6402                	ld	s0,0(sp)
    80000a48:	0141                	addi	sp,sp,16
    80000a4a:	8082                	ret
    return -1;
    80000a4c:	557d                	li	a0,-1
    80000a4e:	bfdd                	j	80000a44 <uartgetc+0x1c>

0000000080000a50 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    80000a50:	1101                	addi	sp,sp,-32
    80000a52:	ec06                	sd	ra,24(sp)
    80000a54:	e822                	sd	s0,16(sp)
    80000a56:	e426                	sd	s1,8(sp)
    80000a58:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    80000a5a:	100007b7          	lui	a5,0x10000
    80000a5e:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>

  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80000a62:	54fd                	li	s1,-1
    int c = uartgetc();
    80000a64:	fc5ff0ef          	jal	80000a28 <uartgetc>
    if(c == -1)
    80000a68:	00950563          	beq	a0,s1,80000a72 <uartintr+0x22>
      break;
    consoleintr(c);
    80000a6c:	813ff0ef          	jal	8000027e <consoleintr>
  while(1){
    80000a70:	bfd5                	j	80000a64 <uartintr+0x14>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    80000a72:	0000f517          	auipc	a0,0xf
    80000a76:	f7650513          	addi	a0,a0,-138 # 8000f9e8 <uart_tx_lock>
    80000a7a:	1ea000ef          	jal	80000c64 <acquire>
  uartstart();
    80000a7e:	e73ff0ef          	jal	800008f0 <uartstart>
  release(&uart_tx_lock);
    80000a82:	0000f517          	auipc	a0,0xf
    80000a86:	f6650513          	addi	a0,a0,-154 # 8000f9e8 <uart_tx_lock>
    80000a8a:	26a000ef          	jal	80000cf4 <release>
}
    80000a8e:	60e2                	ld	ra,24(sp)
    80000a90:	6442                	ld	s0,16(sp)
    80000a92:	64a2                	ld	s1,8(sp)
    80000a94:	6105                	addi	sp,sp,32
    80000a96:	8082                	ret

0000000080000a98 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a98:	1101                	addi	sp,sp,-32
    80000a9a:	ec06                	sd	ra,24(sp)
    80000a9c:	e822                	sd	s0,16(sp)
    80000a9e:	e426                	sd	s1,8(sp)
    80000aa0:	e04a                	sd	s2,0(sp)
    80000aa2:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000aa4:	00020797          	auipc	a5,0x20
    80000aa8:	1ac78793          	addi	a5,a5,428 # 80020c50 <end>
    80000aac:	00f53733          	sltu	a4,a0,a5
    80000ab0:	47c5                	li	a5,17
    80000ab2:	07ee                	slli	a5,a5,0x1b
    80000ab4:	17fd                	addi	a5,a5,-1
    80000ab6:	00a7b7b3          	sltu	a5,a5,a0
    80000aba:	8fd9                	or	a5,a5,a4
    80000abc:	03451713          	slli	a4,a0,0x34
    80000ac0:	8fd9                	or	a5,a5,a4
    80000ac2:	eb9d                	bnez	a5,80000af8 <kfree+0x60>
    80000ac4:	84aa                	mv	s1,a0
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000ac6:	6605                	lui	a2,0x1
    80000ac8:	4585                	li	a1,1
    80000aca:	266000ef          	jal	80000d30 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000ace:	0000f917          	auipc	s2,0xf
    80000ad2:	f5290913          	addi	s2,s2,-174 # 8000fa20 <kmem>
    80000ad6:	854a                	mv	a0,s2
    80000ad8:	18c000ef          	jal	80000c64 <acquire>
  r->next = kmem.freelist;
    80000adc:	01893783          	ld	a5,24(s2)
    80000ae0:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000ae2:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000ae6:	854a                	mv	a0,s2
    80000ae8:	20c000ef          	jal	80000cf4 <release>
}
    80000aec:	60e2                	ld	ra,24(sp)
    80000aee:	6442                	ld	s0,16(sp)
    80000af0:	64a2                	ld	s1,8(sp)
    80000af2:	6902                	ld	s2,0(sp)
    80000af4:	6105                	addi	sp,sp,32
    80000af6:	8082                	ret
    panic("kfree");
    80000af8:	00006517          	auipc	a0,0x6
    80000afc:	54050513          	addi	a0,a0,1344 # 80007038 <etext+0x38>
    80000b00:	cf1ff0ef          	jal	800007f0 <panic>

0000000080000b04 <freerange>:
{
    80000b04:	7179                	addi	sp,sp,-48
    80000b06:	f406                	sd	ra,40(sp)
    80000b08:	f022                	sd	s0,32(sp)
    80000b0a:	ec26                	sd	s1,24(sp)
    80000b0c:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000b0e:	6785                	lui	a5,0x1
    80000b10:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000b14:	00e504b3          	add	s1,a0,a4
    80000b18:	777d                	lui	a4,0xfffff
    80000b1a:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000b1c:	94be                	add	s1,s1,a5
    80000b1e:	0295e263          	bltu	a1,s1,80000b42 <freerange+0x3e>
    80000b22:	e84a                	sd	s2,16(sp)
    80000b24:	e44e                	sd	s3,8(sp)
    80000b26:	e052                	sd	s4,0(sp)
    80000b28:	892e                	mv	s2,a1
    kfree(p);
    80000b2a:	8a3a                	mv	s4,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000b2c:	89be                	mv	s3,a5
    kfree(p);
    80000b2e:	01448533          	add	a0,s1,s4
    80000b32:	f67ff0ef          	jal	80000a98 <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000b36:	94ce                	add	s1,s1,s3
    80000b38:	fe997be3          	bgeu	s2,s1,80000b2e <freerange+0x2a>
    80000b3c:	6942                	ld	s2,16(sp)
    80000b3e:	69a2                	ld	s3,8(sp)
    80000b40:	6a02                	ld	s4,0(sp)
}
    80000b42:	70a2                	ld	ra,40(sp)
    80000b44:	7402                	ld	s0,32(sp)
    80000b46:	64e2                	ld	s1,24(sp)
    80000b48:	6145                	addi	sp,sp,48
    80000b4a:	8082                	ret

0000000080000b4c <kinit>:
{
    80000b4c:	1141                	addi	sp,sp,-16
    80000b4e:	e406                	sd	ra,8(sp)
    80000b50:	e022                	sd	s0,0(sp)
    80000b52:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000b54:	00006597          	auipc	a1,0x6
    80000b58:	4ec58593          	addi	a1,a1,1260 # 80007040 <etext+0x40>
    80000b5c:	0000f517          	auipc	a0,0xf
    80000b60:	ec450513          	addi	a0,a0,-316 # 8000fa20 <kmem>
    80000b64:	076000ef          	jal	80000bda <initlock>
  freerange(end, (void*)PHYSTOP);
    80000b68:	45c5                	li	a1,17
    80000b6a:	05ee                	slli	a1,a1,0x1b
    80000b6c:	00020517          	auipc	a0,0x20
    80000b70:	0e450513          	addi	a0,a0,228 # 80020c50 <end>
    80000b74:	f91ff0ef          	jal	80000b04 <freerange>
}
    80000b78:	60a2                	ld	ra,8(sp)
    80000b7a:	6402                	ld	s0,0(sp)
    80000b7c:	0141                	addi	sp,sp,16
    80000b7e:	8082                	ret

0000000080000b80 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000b80:	1101                	addi	sp,sp,-32
    80000b82:	ec06                	sd	ra,24(sp)
    80000b84:	e822                	sd	s0,16(sp)
    80000b86:	e426                	sd	s1,8(sp)
    80000b88:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b8a:	0000f517          	auipc	a0,0xf
    80000b8e:	e9650513          	addi	a0,a0,-362 # 8000fa20 <kmem>
    80000b92:	0d2000ef          	jal	80000c64 <acquire>
  r = kmem.freelist;
    80000b96:	0000f497          	auipc	s1,0xf
    80000b9a:	ea24b483          	ld	s1,-350(s1) # 8000fa38 <kmem+0x18>
  if(r)
    80000b9e:	c49d                	beqz	s1,80000bcc <kalloc+0x4c>
    kmem.freelist = r->next;
    80000ba0:	609c                	ld	a5,0(s1)
    80000ba2:	0000f717          	auipc	a4,0xf
    80000ba6:	e8f73b23          	sd	a5,-362(a4) # 8000fa38 <kmem+0x18>
  release(&kmem.lock);
    80000baa:	0000f517          	auipc	a0,0xf
    80000bae:	e7650513          	addi	a0,a0,-394 # 8000fa20 <kmem>
    80000bb2:	142000ef          	jal	80000cf4 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000bb6:	6605                	lui	a2,0x1
    80000bb8:	4595                	li	a1,5
    80000bba:	8526                	mv	a0,s1
    80000bbc:	174000ef          	jal	80000d30 <memset>
  return (void*)r;
}
    80000bc0:	8526                	mv	a0,s1
    80000bc2:	60e2                	ld	ra,24(sp)
    80000bc4:	6442                	ld	s0,16(sp)
    80000bc6:	64a2                	ld	s1,8(sp)
    80000bc8:	6105                	addi	sp,sp,32
    80000bca:	8082                	ret
  release(&kmem.lock);
    80000bcc:	0000f517          	auipc	a0,0xf
    80000bd0:	e5450513          	addi	a0,a0,-428 # 8000fa20 <kmem>
    80000bd4:	120000ef          	jal	80000cf4 <release>
  if(r)
    80000bd8:	b7e5                	j	80000bc0 <kalloc+0x40>

0000000080000bda <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000bda:	1141                	addi	sp,sp,-16
    80000bdc:	e406                	sd	ra,8(sp)
    80000bde:	e022                	sd	s0,0(sp)
    80000be0:	0800                	addi	s0,sp,16
  lk->name = name;
    80000be2:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000be4:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000be8:	00053823          	sd	zero,16(a0)
}
    80000bec:	60a2                	ld	ra,8(sp)
    80000bee:	6402                	ld	s0,0(sp)
    80000bf0:	0141                	addi	sp,sp,16
    80000bf2:	8082                	ret

0000000080000bf4 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000bf4:	411c                	lw	a5,0(a0)
    80000bf6:	e399                	bnez	a5,80000bfc <holding+0x8>
    80000bf8:	4501                	li	a0,0
  return r;
}
    80000bfa:	8082                	ret
{
    80000bfc:	1101                	addi	sp,sp,-32
    80000bfe:	ec06                	sd	ra,24(sp)
    80000c00:	e822                	sd	s0,16(sp)
    80000c02:	e426                	sd	s1,8(sp)
    80000c04:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000c06:	691c                	ld	a5,16(a0)
    80000c08:	84be                	mv	s1,a5
    80000c0a:	4fb000ef          	jal	80001904 <mycpu>
    80000c0e:	40a48533          	sub	a0,s1,a0
    80000c12:	00153513          	seqz	a0,a0
}
    80000c16:	60e2                	ld	ra,24(sp)
    80000c18:	6442                	ld	s0,16(sp)
    80000c1a:	64a2                	ld	s1,8(sp)
    80000c1c:	6105                	addi	sp,sp,32
    80000c1e:	8082                	ret

0000000080000c20 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000c20:	1101                	addi	sp,sp,-32
    80000c22:	ec06                	sd	ra,24(sp)
    80000c24:	e822                	sd	s0,16(sp)
    80000c26:	e426                	sd	s1,8(sp)
    80000c28:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c2a:	100027f3          	csrr	a5,sstatus
    80000c2e:	84be                	mv	s1,a5
  int old = intr_get();

  if(mycpu()->noff == 0){
    80000c30:	4d5000ef          	jal	80001904 <mycpu>
    80000c34:	5d3c                	lw	a5,120(a0)
    80000c36:	cb99                	beqz	a5,80000c4c <push_off+0x2c>
    intr_off();
    mycpu()->intena = old;
  }
  mycpu()->noff += 1;
    80000c38:	4cd000ef          	jal	80001904 <mycpu>
    80000c3c:	5d3c                	lw	a5,120(a0)
    80000c3e:	2785                	addiw	a5,a5,1
    80000c40:	dd3c                	sw	a5,120(a0)
}
    80000c42:	60e2                	ld	ra,24(sp)
    80000c44:	6442                	ld	s0,16(sp)
    80000c46:	64a2                	ld	s1,8(sp)
    80000c48:	6105                	addi	sp,sp,32
    80000c4a:	8082                	ret
    80000c4c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000c50:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c52:	10079073          	csrw	sstatus,a5
    mycpu()->intena = old;
    80000c56:	4af000ef          	jal	80001904 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000c5a:	0014d793          	srli	a5,s1,0x1
    80000c5e:	8b85                	andi	a5,a5,1
    80000c60:	dd7c                	sw	a5,124(a0)
    80000c62:	bfd9                	j	80000c38 <push_off+0x18>

0000000080000c64 <acquire>:
{
    80000c64:	1101                	addi	sp,sp,-32
    80000c66:	ec06                	sd	ra,24(sp)
    80000c68:	e822                	sd	s0,16(sp)
    80000c6a:	e426                	sd	s1,8(sp)
    80000c6c:	1000                	addi	s0,sp,32
    80000c6e:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000c70:	fb1ff0ef          	jal	80000c20 <push_off>
  if(holding(lk))
    80000c74:	8526                	mv	a0,s1
    80000c76:	f7fff0ef          	jal	80000bf4 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c7a:	4705                	li	a4,1
  if(holding(lk))
    80000c7c:	ed11                	bnez	a0,80000c98 <acquire+0x34>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c7e:	0ce4a7af          	amoswap.w.aq	a5,a4,(s1)
    80000c82:	fff5                	bnez	a5,80000c7e <acquire+0x1a>
  __sync_synchronize();
    80000c84:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80000c88:	47d000ef          	jal	80001904 <mycpu>
    80000c8c:	e888                	sd	a0,16(s1)
}
    80000c8e:	60e2                	ld	ra,24(sp)
    80000c90:	6442                	ld	s0,16(sp)
    80000c92:	64a2                	ld	s1,8(sp)
    80000c94:	6105                	addi	sp,sp,32
    80000c96:	8082                	ret
    panic("acquire");
    80000c98:	00006517          	auipc	a0,0x6
    80000c9c:	3b050513          	addi	a0,a0,944 # 80007048 <etext+0x48>
    80000ca0:	b51ff0ef          	jal	800007f0 <panic>

0000000080000ca4 <pop_off>:

void
pop_off(void)
{
    80000ca4:	1141                	addi	sp,sp,-16
    80000ca6:	e406                	sd	ra,8(sp)
    80000ca8:	e022                	sd	s0,0(sp)
    80000caa:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000cac:	459000ef          	jal	80001904 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000cb0:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000cb4:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000cb6:	e39d                	bnez	a5,80000cdc <pop_off+0x38>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000cb8:	5d3c                	lw	a5,120(a0)
    80000cba:	02f05763          	blez	a5,80000ce8 <pop_off+0x44>
    panic("pop_off");
  c->noff -= 1;
    80000cbe:	37fd                	addiw	a5,a5,-1
    80000cc0:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000cc2:	eb89                	bnez	a5,80000cd4 <pop_off+0x30>
    80000cc4:	5d7c                	lw	a5,124(a0)
    80000cc6:	c799                	beqz	a5,80000cd4 <pop_off+0x30>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000cc8:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000ccc:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000cd0:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000cd4:	60a2                	ld	ra,8(sp)
    80000cd6:	6402                	ld	s0,0(sp)
    80000cd8:	0141                	addi	sp,sp,16
    80000cda:	8082                	ret
    panic("pop_off - interruptible");
    80000cdc:	00006517          	auipc	a0,0x6
    80000ce0:	37450513          	addi	a0,a0,884 # 80007050 <etext+0x50>
    80000ce4:	b0dff0ef          	jal	800007f0 <panic>
    panic("pop_off");
    80000ce8:	00006517          	auipc	a0,0x6
    80000cec:	38050513          	addi	a0,a0,896 # 80007068 <etext+0x68>
    80000cf0:	b01ff0ef          	jal	800007f0 <panic>

0000000080000cf4 <release>:
{
    80000cf4:	1101                	addi	sp,sp,-32
    80000cf6:	ec06                	sd	ra,24(sp)
    80000cf8:	e822                	sd	s0,16(sp)
    80000cfa:	e426                	sd	s1,8(sp)
    80000cfc:	1000                	addi	s0,sp,32
    80000cfe:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000d00:	ef5ff0ef          	jal	80000bf4 <holding>
    80000d04:	c105                	beqz	a0,80000d24 <release+0x30>
  lk->cpu = 0;
    80000d06:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000d0a:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    80000d0e:	0310000f          	fence	rw,w
    80000d12:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000d16:	f8fff0ef          	jal	80000ca4 <pop_off>
}
    80000d1a:	60e2                	ld	ra,24(sp)
    80000d1c:	6442                	ld	s0,16(sp)
    80000d1e:	64a2                	ld	s1,8(sp)
    80000d20:	6105                	addi	sp,sp,32
    80000d22:	8082                	ret
    panic("release");
    80000d24:	00006517          	auipc	a0,0x6
    80000d28:	34c50513          	addi	a0,a0,844 # 80007070 <etext+0x70>
    80000d2c:	ac5ff0ef          	jal	800007f0 <panic>

0000000080000d30 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000d30:	1141                	addi	sp,sp,-16
    80000d32:	e406                	sd	ra,8(sp)
    80000d34:	e022                	sd	s0,0(sp)
    80000d36:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000d38:	ca19                	beqz	a2,80000d4e <memset+0x1e>
    80000d3a:	87aa                	mv	a5,a0
    80000d3c:	1602                	slli	a2,a2,0x20
    80000d3e:	9201                	srli	a2,a2,0x20
    80000d40:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000d44:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000d48:	0785                	addi	a5,a5,1
    80000d4a:	fee79de3          	bne	a5,a4,80000d44 <memset+0x14>
  }
  return dst;
}
    80000d4e:	60a2                	ld	ra,8(sp)
    80000d50:	6402                	ld	s0,0(sp)
    80000d52:	0141                	addi	sp,sp,16
    80000d54:	8082                	ret

0000000080000d56 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000d56:	1141                	addi	sp,sp,-16
    80000d58:	e406                	sd	ra,8(sp)
    80000d5a:	e022                	sd	s0,0(sp)
    80000d5c:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000d5e:	ce19                	beqz	a2,80000d7c <memcmp+0x26>
    80000d60:	1602                	slli	a2,a2,0x20
    80000d62:	9201                	srli	a2,a2,0x20
    80000d64:	00c506b3          	add	a3,a0,a2
    if(*s1 != *s2)
    80000d68:	00054783          	lbu	a5,0(a0)
    80000d6c:	0005c703          	lbu	a4,0(a1)
    80000d70:	00e79b63          	bne	a5,a4,80000d86 <memcmp+0x30>
      return *s1 - *s2;
    s1++, s2++;
    80000d74:	0505                	addi	a0,a0,1
    80000d76:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000d78:	fed518e3          	bne	a0,a3,80000d68 <memcmp+0x12>
  }

  return 0;
    80000d7c:	4501                	li	a0,0
}
    80000d7e:	60a2                	ld	ra,8(sp)
    80000d80:	6402                	ld	s0,0(sp)
    80000d82:	0141                	addi	sp,sp,16
    80000d84:	8082                	ret
      return *s1 - *s2;
    80000d86:	40e7853b          	subw	a0,a5,a4
    80000d8a:	bfd5                	j	80000d7e <memcmp+0x28>

0000000080000d8c <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000d8c:	1141                	addi	sp,sp,-16
    80000d8e:	e406                	sd	ra,8(sp)
    80000d90:	e022                	sd	s0,0(sp)
    80000d92:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d94:	c61d                	beqz	a2,80000dc2 <memmove+0x36>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d96:	00a5f963          	bgeu	a1,a0,80000da8 <memmove+0x1c>
    80000d9a:	02061693          	slli	a3,a2,0x20
    80000d9e:	9281                	srli	a3,a3,0x20
    80000da0:	00d58733          	add	a4,a1,a3
    80000da4:	02e56363          	bltu	a0,a4,80000dca <memmove+0x3e>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000da8:	1602                	slli	a2,a2,0x20
    80000daa:	9201                	srli	a2,a2,0x20
    80000dac:	00c587b3          	add	a5,a1,a2
{
    80000db0:	872a                	mv	a4,a0
      *d++ = *s++;
    80000db2:	0585                	addi	a1,a1,1
    80000db4:	0705                	addi	a4,a4,1
    80000db6:	fff5c683          	lbu	a3,-1(a1)
    80000dba:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000dbe:	fef59ae3          	bne	a1,a5,80000db2 <memmove+0x26>

  return dst;
}
    80000dc2:	60a2                	ld	ra,8(sp)
    80000dc4:	6402                	ld	s0,0(sp)
    80000dc6:	0141                	addi	sp,sp,16
    80000dc8:	8082                	ret
    d += n;
    80000dca:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000dcc:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000dd0:	1782                	slli	a5,a5,0x20
    80000dd2:	9381                	srli	a5,a5,0x20
    80000dd4:	fff7c793          	not	a5,a5
    80000dd8:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000dda:	177d                	addi	a4,a4,-1
    80000ddc:	16fd                	addi	a3,a3,-1
    80000dde:	00074603          	lbu	a2,0(a4)
    80000de2:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000de6:	fee79ae3          	bne	a5,a4,80000dda <memmove+0x4e>
    80000dea:	bfe1                	j	80000dc2 <memmove+0x36>

0000000080000dec <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000dec:	1141                	addi	sp,sp,-16
    80000dee:	e406                	sd	ra,8(sp)
    80000df0:	e022                	sd	s0,0(sp)
    80000df2:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000df4:	f99ff0ef          	jal	80000d8c <memmove>
}
    80000df8:	60a2                	ld	ra,8(sp)
    80000dfa:	6402                	ld	s0,0(sp)
    80000dfc:	0141                	addi	sp,sp,16
    80000dfe:	8082                	ret

0000000080000e00 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000e00:	1141                	addi	sp,sp,-16
    80000e02:	e406                	sd	ra,8(sp)
    80000e04:	e022                	sd	s0,0(sp)
    80000e06:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000e08:	ce01                	beqz	a2,80000e20 <strncmp+0x20>
    80000e0a:	00054783          	lbu	a5,0(a0)
    80000e0e:	cb99                	beqz	a5,80000e24 <strncmp+0x24>
    80000e10:	0005c703          	lbu	a4,0(a1)
    80000e14:	00f71863          	bne	a4,a5,80000e24 <strncmp+0x24>
    n--, p++, q++;
    80000e18:	367d                	addiw	a2,a2,-1
    80000e1a:	0505                	addi	a0,a0,1
    80000e1c:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000e1e:	f675                	bnez	a2,80000e0a <strncmp+0xa>
  if(n == 0)
    return 0;
    80000e20:	4501                	li	a0,0
    80000e22:	a031                	j	80000e2e <strncmp+0x2e>
  return (uchar)*p - (uchar)*q;
    80000e24:	00054503          	lbu	a0,0(a0)
    80000e28:	0005c783          	lbu	a5,0(a1)
    80000e2c:	9d1d                	subw	a0,a0,a5
}
    80000e2e:	60a2                	ld	ra,8(sp)
    80000e30:	6402                	ld	s0,0(sp)
    80000e32:	0141                	addi	sp,sp,16
    80000e34:	8082                	ret

0000000080000e36 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000e36:	1141                	addi	sp,sp,-16
    80000e38:	e406                	sd	ra,8(sp)
    80000e3a:	e022                	sd	s0,0(sp)
    80000e3c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000e3e:	87aa                	mv	a5,a0
    80000e40:	a011                	j	80000e44 <strncpy+0xe>
    80000e42:	8636                	mv	a2,a3
    80000e44:	02c05763          	blez	a2,80000e72 <strncpy+0x3c>
    80000e48:	fff6069b          	addiw	a3,a2,-1
    80000e4c:	0785                	addi	a5,a5,1
    80000e4e:	0005c703          	lbu	a4,0(a1)
    80000e52:	fee78fa3          	sb	a4,-1(a5)
    80000e56:	0585                	addi	a1,a1,1
    80000e58:	f76d                	bnez	a4,80000e42 <strncpy+0xc>
    ;
  while(n-- > 0)
    80000e5a:	873e                	mv	a4,a5
    80000e5c:	00d05b63          	blez	a3,80000e72 <strncpy+0x3c>
    80000e60:	9fb1                	addw	a5,a5,a2
    80000e62:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    80000e64:	0705                	addi	a4,a4,1
    80000e66:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    80000e6a:	40e786bb          	subw	a3,a5,a4
    80000e6e:	fed04be3          	bgtz	a3,80000e64 <strncpy+0x2e>
  return os;
}
    80000e72:	60a2                	ld	ra,8(sp)
    80000e74:	6402                	ld	s0,0(sp)
    80000e76:	0141                	addi	sp,sp,16
    80000e78:	8082                	ret

0000000080000e7a <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000e7a:	1141                	addi	sp,sp,-16
    80000e7c:	e406                	sd	ra,8(sp)
    80000e7e:	e022                	sd	s0,0(sp)
    80000e80:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000e82:	02c05363          	blez	a2,80000ea8 <safestrcpy+0x2e>
    80000e86:	fff6069b          	addiw	a3,a2,-1
    80000e8a:	1682                	slli	a3,a3,0x20
    80000e8c:	9281                	srli	a3,a3,0x20
    80000e8e:	96ae                	add	a3,a3,a1
    80000e90:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000e92:	00d58963          	beq	a1,a3,80000ea4 <safestrcpy+0x2a>
    80000e96:	0585                	addi	a1,a1,1
    80000e98:	0785                	addi	a5,a5,1
    80000e9a:	fff5c703          	lbu	a4,-1(a1)
    80000e9e:	fee78fa3          	sb	a4,-1(a5)
    80000ea2:	fb65                	bnez	a4,80000e92 <safestrcpy+0x18>
    ;
  *s = 0;
    80000ea4:	00078023          	sb	zero,0(a5)
  return os;
}
    80000ea8:	60a2                	ld	ra,8(sp)
    80000eaa:	6402                	ld	s0,0(sp)
    80000eac:	0141                	addi	sp,sp,16
    80000eae:	8082                	ret

0000000080000eb0 <strlen>:

int
strlen(const char *s)
{
    80000eb0:	1141                	addi	sp,sp,-16
    80000eb2:	e406                	sd	ra,8(sp)
    80000eb4:	e022                	sd	s0,0(sp)
    80000eb6:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000eb8:	00054783          	lbu	a5,0(a0)
    80000ebc:	cf91                	beqz	a5,80000ed8 <strlen+0x28>
    80000ebe:	00150793          	addi	a5,a0,1
    80000ec2:	86be                	mv	a3,a5
    80000ec4:	0785                	addi	a5,a5,1
    80000ec6:	fff7c703          	lbu	a4,-1(a5)
    80000eca:	ff65                	bnez	a4,80000ec2 <strlen+0x12>
    80000ecc:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000ed0:	60a2                	ld	ra,8(sp)
    80000ed2:	6402                	ld	s0,0(sp)
    80000ed4:	0141                	addi	sp,sp,16
    80000ed6:	8082                	ret
  for(n = 0; s[n]; n++)
    80000ed8:	4501                	li	a0,0
    80000eda:	bfdd                	j	80000ed0 <strlen+0x20>

0000000080000edc <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000edc:	1141                	addi	sp,sp,-16
    80000ede:	e406                	sd	ra,8(sp)
    80000ee0:	e022                	sd	s0,0(sp)
    80000ee2:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000ee4:	20d000ef          	jal	800018f0 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000ee8:	00007717          	auipc	a4,0x7
    80000eec:	a1070713          	addi	a4,a4,-1520 # 800078f8 <started>
  if(cpuid() == 0){
    80000ef0:	c515                	beqz	a0,80000f1c <main+0x40>
    while(started == 0)
    80000ef2:	431c                	lw	a5,0(a4)
    80000ef4:	dffd                	beqz	a5,80000ef2 <main+0x16>
      ;
    __sync_synchronize();
    80000ef6:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    80000efa:	1f7000ef          	jal	800018f0 <cpuid>
    80000efe:	85aa                	mv	a1,a0
    80000f00:	00006517          	auipc	a0,0x6
    80000f04:	19850513          	addi	a0,a0,408 # 80007098 <etext+0x98>
    80000f08:	dcaff0ef          	jal	800004d2 <printf>
    kvminithart();    // turn on paging
    80000f0c:	080000ef          	jal	80000f8c <kvminithart>
    trapinithart();   // install kernel trap vector
    80000f10:	51e010ef          	jal	8000242e <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000f14:	374040ef          	jal	80005288 <plicinithart>
  }

  scheduler();        
    80000f18:	63b000ef          	jal	80001d52 <scheduler>
    consoleinit();
    80000f1c:	cdeff0ef          	jal	800003fa <consoleinit>
    printfinit();
    80000f20:	90bff0ef          	jal	8000082a <printfinit>
    printf("\n");
    80000f24:	00006517          	auipc	a0,0x6
    80000f28:	15450513          	addi	a0,a0,340 # 80007078 <etext+0x78>
    80000f2c:	da6ff0ef          	jal	800004d2 <printf>
    printf("xv6 kernel is booting\n");
    80000f30:	00006517          	auipc	a0,0x6
    80000f34:	15050513          	addi	a0,a0,336 # 80007080 <etext+0x80>
    80000f38:	d9aff0ef          	jal	800004d2 <printf>
    printf("\n");
    80000f3c:	00006517          	auipc	a0,0x6
    80000f40:	13c50513          	addi	a0,a0,316 # 80007078 <etext+0x78>
    80000f44:	d8eff0ef          	jal	800004d2 <printf>
    kinit();         // physical page allocator
    80000f48:	c05ff0ef          	jal	80000b4c <kinit>
    kvminit();       // create kernel page table
    80000f4c:	2c0000ef          	jal	8000120c <kvminit>
    kvminithart();   // turn on paging
    80000f50:	03c000ef          	jal	80000f8c <kvminithart>
    procinit();      // process table
    80000f54:	0e5000ef          	jal	80001838 <procinit>
    trapinit();      // trap vectors
    80000f58:	4b2010ef          	jal	8000240a <trapinit>
    trapinithart();  // install kernel trap vector
    80000f5c:	4d2010ef          	jal	8000242e <trapinithart>
    plicinit();      // set up interrupt controller
    80000f60:	30e040ef          	jal	8000526e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000f64:	324040ef          	jal	80005288 <plicinithart>
    binit();         // buffer cache
    80000f68:	30b010ef          	jal	80002a72 <binit>
    iinit();         // inode table
    80000f6c:	0ce020ef          	jal	8000303a <iinit>
    fileinit();      // file table
    80000f70:	6bb020ef          	jal	80003e2a <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000f74:	404040ef          	jal	80005378 <virtio_disk_init>
    userinit();      // first user process
    80000f78:	415000ef          	jal	80001b8c <userinit>
    __sync_synchronize();
    80000f7c:	0330000f          	fence	rw,rw
    started = 1;
    80000f80:	4785                	li	a5,1
    80000f82:	00007717          	auipc	a4,0x7
    80000f86:	96f72b23          	sw	a5,-1674(a4) # 800078f8 <started>
    80000f8a:	b779                	j	80000f18 <main+0x3c>

0000000080000f8c <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    80000f8c:	1141                	addi	sp,sp,-16
    80000f8e:	e406                	sd	ra,8(sp)
    80000f90:	e022                	sd	s0,0(sp)
    80000f92:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000f94:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000f98:	00007797          	auipc	a5,0x7
    80000f9c:	9687b783          	ld	a5,-1688(a5) # 80007900 <kernel_pagetable>
    80000fa0:	83b1                	srli	a5,a5,0xc
    80000fa2:	577d                	li	a4,-1
    80000fa4:	177e                	slli	a4,a4,0x3f
    80000fa6:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000fa8:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000fac:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000fb0:	60a2                	ld	ra,8(sp)
    80000fb2:	6402                	ld	s0,0(sp)
    80000fb4:	0141                	addi	sp,sp,16
    80000fb6:	8082                	ret

0000000080000fb8 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000fb8:	7139                	addi	sp,sp,-64
    80000fba:	fc06                	sd	ra,56(sp)
    80000fbc:	f822                	sd	s0,48(sp)
    80000fbe:	f426                	sd	s1,40(sp)
    80000fc0:	f04a                	sd	s2,32(sp)
    80000fc2:	ec4e                	sd	s3,24(sp)
    80000fc4:	e852                	sd	s4,16(sp)
    80000fc6:	e456                	sd	s5,8(sp)
    80000fc8:	e05a                	sd	s6,0(sp)
    80000fca:	0080                	addi	s0,sp,64
    80000fcc:	84aa                	mv	s1,a0
    80000fce:	89ae                	mv	s3,a1
    80000fd0:	8b32                	mv	s6,a2
  if(va >= MAXVA)
    80000fd2:	57fd                	li	a5,-1
    80000fd4:	83e9                	srli	a5,a5,0x1a
    80000fd6:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000fd8:	4ab1                	li	s5,12
  if(va >= MAXVA)
    80000fda:	06b7e363          	bltu	a5,a1,80001040 <walk+0x88>
    pte_t *pte = &pagetable[PX(level, va)];
    80000fde:	0149d933          	srl	s2,s3,s4
    80000fe2:	1ff97913          	andi	s2,s2,511
    80000fe6:	090e                	slli	s2,s2,0x3
    80000fe8:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000fea:	00093483          	ld	s1,0(s2)
    80000fee:	0014f793          	andi	a5,s1,1
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000ff2:	80a9                	srli	s1,s1,0xa
    80000ff4:	04b2                	slli	s1,s1,0xc
    if(*pte & PTE_V) {
    80000ff6:	e395                	bnez	a5,8000101a <walk+0x62>
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80000ff8:	040b0a63          	beqz	s6,8000104c <walk+0x94>
    80000ffc:	b85ff0ef          	jal	80000b80 <kalloc>
    80001000:	84aa                	mv	s1,a0
    80001002:	c50d                	beqz	a0,8000102c <walk+0x74>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80001004:	6605                	lui	a2,0x1
    80001006:	4581                	li	a1,0
    80001008:	d29ff0ef          	jal	80000d30 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    8000100c:	00c4d793          	srli	a5,s1,0xc
    80001010:	07aa                	slli	a5,a5,0xa
    80001012:	0017e793          	ori	a5,a5,1
    80001016:	00f93023          	sd	a5,0(s2)
  for(int level = 2; level > 0; level--) {
    8000101a:	3a5d                	addiw	s4,s4,-9
    8000101c:	fd5a11e3          	bne	s4,s5,80000fde <walk+0x26>
    }
  }
  return &pagetable[PX(0, va)];
    80001020:	00c9d513          	srli	a0,s3,0xc
    80001024:	1ff57513          	andi	a0,a0,511
    80001028:	050e                	slli	a0,a0,0x3
    8000102a:	9526                	add	a0,a0,s1
}
    8000102c:	70e2                	ld	ra,56(sp)
    8000102e:	7442                	ld	s0,48(sp)
    80001030:	74a2                	ld	s1,40(sp)
    80001032:	7902                	ld	s2,32(sp)
    80001034:	69e2                	ld	s3,24(sp)
    80001036:	6a42                	ld	s4,16(sp)
    80001038:	6aa2                	ld	s5,8(sp)
    8000103a:	6b02                	ld	s6,0(sp)
    8000103c:	6121                	addi	sp,sp,64
    8000103e:	8082                	ret
    panic("walk");
    80001040:	00006517          	auipc	a0,0x6
    80001044:	07050513          	addi	a0,a0,112 # 800070b0 <etext+0xb0>
    80001048:	fa8ff0ef          	jal	800007f0 <panic>
        return 0;
    8000104c:	4501                	li	a0,0
    8000104e:	bff9                	j	8000102c <walk+0x74>

0000000080001050 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    80001050:	57fd                	li	a5,-1
    80001052:	83e9                	srli	a5,a5,0x1a
    80001054:	00b7f463          	bgeu	a5,a1,8000105c <walkaddr+0xc>
    return 0;
    80001058:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    8000105a:	8082                	ret
{
    8000105c:	1141                	addi	sp,sp,-16
    8000105e:	e406                	sd	ra,8(sp)
    80001060:	e022                	sd	s0,0(sp)
    80001062:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80001064:	4601                	li	a2,0
    80001066:	f53ff0ef          	jal	80000fb8 <walk>
  if(pte == 0)
    8000106a:	c519                	beqz	a0,80001078 <walkaddr+0x28>
  if((*pte & PTE_V) == 0)
    8000106c:	6108                	ld	a0,0(a0)
  if((*pte & PTE_U) == 0)
    8000106e:	01157713          	andi	a4,a0,17
    80001072:	47c5                	li	a5,17
    80001074:	00f70763          	beq	a4,a5,80001082 <walkaddr+0x32>
    return 0;
    80001078:	4501                	li	a0,0
}
    8000107a:	60a2                	ld	ra,8(sp)
    8000107c:	6402                	ld	s0,0(sp)
    8000107e:	0141                	addi	sp,sp,16
    80001080:	8082                	ret
  pa = PTE2PA(*pte);
    80001082:	8129                	srli	a0,a0,0xa
    80001084:	0532                	slli	a0,a0,0xc
  return pa;
    80001086:	bfd5                	j	8000107a <walkaddr+0x2a>

0000000080001088 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001088:	715d                	addi	sp,sp,-80
    8000108a:	e486                	sd	ra,72(sp)
    8000108c:	e0a2                	sd	s0,64(sp)
    8000108e:	fc26                	sd	s1,56(sp)
    80001090:	f84a                	sd	s2,48(sp)
    80001092:	f44e                	sd	s3,40(sp)
    80001094:	f052                	sd	s4,32(sp)
    80001096:	ec56                	sd	s5,24(sp)
    80001098:	e85a                	sd	s6,16(sp)
    8000109a:	e45e                	sd	s7,8(sp)
    8000109c:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    8000109e:	03459793          	slli	a5,a1,0x34
    800010a2:	e7b1                	bnez	a5,800010ee <mappages+0x66>
    800010a4:	8a2a                	mv	s4,a0
    800010a6:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    800010a8:	03461793          	slli	a5,a2,0x34
    800010ac:	e7b9                	bnez	a5,800010fa <mappages+0x72>
    panic("mappages: size not aligned");

  if(size == 0)
    800010ae:	ce21                	beqz	a2,80001106 <mappages+0x7e>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    800010b0:	77fd                	lui	a5,0xfffff
    800010b2:	963e                	add	a2,a2,a5
    800010b4:	00b60933          	add	s2,a2,a1
  a = va;
    800010b8:	84ae                	mv	s1,a1
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
    800010ba:	4b05                	li	s6,1
    800010bc:	40b689b3          	sub	s3,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    800010c0:	6b85                	lui	s7,0x1
    if((pte = walk(pagetable, a, 1)) == 0)
    800010c2:	865a                	mv	a2,s6
    800010c4:	85a6                	mv	a1,s1
    800010c6:	8552                	mv	a0,s4
    800010c8:	ef1ff0ef          	jal	80000fb8 <walk>
    800010cc:	c929                	beqz	a0,8000111e <mappages+0x96>
    if(*pte & PTE_V)
    800010ce:	611c                	ld	a5,0(a0)
    800010d0:	8b85                	andi	a5,a5,1
    800010d2:	e3a1                	bnez	a5,80001112 <mappages+0x8a>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800010d4:	013487b3          	add	a5,s1,s3
    800010d8:	83b1                	srli	a5,a5,0xc
    800010da:	07aa                	slli	a5,a5,0xa
    800010dc:	0157e7b3          	or	a5,a5,s5
    800010e0:	0017e793          	ori	a5,a5,1
    800010e4:	e11c                	sd	a5,0(a0)
    if(a == last)
    800010e6:	05248863          	beq	s1,s2,80001136 <mappages+0xae>
    a += PGSIZE;
    800010ea:	94de                	add	s1,s1,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    800010ec:	bfd9                	j	800010c2 <mappages+0x3a>
    panic("mappages: va not aligned");
    800010ee:	00006517          	auipc	a0,0x6
    800010f2:	fca50513          	addi	a0,a0,-54 # 800070b8 <etext+0xb8>
    800010f6:	efaff0ef          	jal	800007f0 <panic>
    panic("mappages: size not aligned");
    800010fa:	00006517          	auipc	a0,0x6
    800010fe:	fde50513          	addi	a0,a0,-34 # 800070d8 <etext+0xd8>
    80001102:	eeeff0ef          	jal	800007f0 <panic>
    panic("mappages: size");
    80001106:	00006517          	auipc	a0,0x6
    8000110a:	ff250513          	addi	a0,a0,-14 # 800070f8 <etext+0xf8>
    8000110e:	ee2ff0ef          	jal	800007f0 <panic>
      panic("mappages: remap");
    80001112:	00006517          	auipc	a0,0x6
    80001116:	ff650513          	addi	a0,a0,-10 # 80007108 <etext+0x108>
    8000111a:	ed6ff0ef          	jal	800007f0 <panic>
      return -1;
    8000111e:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80001120:	60a6                	ld	ra,72(sp)
    80001122:	6406                	ld	s0,64(sp)
    80001124:	74e2                	ld	s1,56(sp)
    80001126:	7942                	ld	s2,48(sp)
    80001128:	79a2                	ld	s3,40(sp)
    8000112a:	7a02                	ld	s4,32(sp)
    8000112c:	6ae2                	ld	s5,24(sp)
    8000112e:	6b42                	ld	s6,16(sp)
    80001130:	6ba2                	ld	s7,8(sp)
    80001132:	6161                	addi	sp,sp,80
    80001134:	8082                	ret
  return 0;
    80001136:	4501                	li	a0,0
    80001138:	b7e5                	j	80001120 <mappages+0x98>

000000008000113a <kvmmap>:
{
    8000113a:	1141                	addi	sp,sp,-16
    8000113c:	e406                	sd	ra,8(sp)
    8000113e:	e022                	sd	s0,0(sp)
    80001140:	0800                	addi	s0,sp,16
    80001142:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80001144:	86b2                	mv	a3,a2
    80001146:	863e                	mv	a2,a5
    80001148:	f41ff0ef          	jal	80001088 <mappages>
    8000114c:	e509                	bnez	a0,80001156 <kvmmap+0x1c>
}
    8000114e:	60a2                	ld	ra,8(sp)
    80001150:	6402                	ld	s0,0(sp)
    80001152:	0141                	addi	sp,sp,16
    80001154:	8082                	ret
    panic("kvmmap");
    80001156:	00006517          	auipc	a0,0x6
    8000115a:	fc250513          	addi	a0,a0,-62 # 80007118 <etext+0x118>
    8000115e:	e92ff0ef          	jal	800007f0 <panic>

0000000080001162 <kvmmake>:
{
    80001162:	1101                	addi	sp,sp,-32
    80001164:	ec06                	sd	ra,24(sp)
    80001166:	e822                	sd	s0,16(sp)
    80001168:	e426                	sd	s1,8(sp)
    8000116a:	e04a                	sd	s2,0(sp)
    8000116c:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    8000116e:	a13ff0ef          	jal	80000b80 <kalloc>
    80001172:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80001174:	6605                	lui	a2,0x1
    80001176:	4581                	li	a1,0
    80001178:	bb9ff0ef          	jal	80000d30 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    8000117c:	4719                	li	a4,6
    8000117e:	6685                	lui	a3,0x1
    80001180:	10000637          	lui	a2,0x10000
    80001184:	85b2                	mv	a1,a2
    80001186:	8526                	mv	a0,s1
    80001188:	fb3ff0ef          	jal	8000113a <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    8000118c:	4719                	li	a4,6
    8000118e:	6685                	lui	a3,0x1
    80001190:	10001637          	lui	a2,0x10001
    80001194:	85b2                	mv	a1,a2
    80001196:	8526                	mv	a0,s1
    80001198:	fa3ff0ef          	jal	8000113a <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    8000119c:	4719                	li	a4,6
    8000119e:	040006b7          	lui	a3,0x4000
    800011a2:	0c000637          	lui	a2,0xc000
    800011a6:	85b2                	mv	a1,a2
    800011a8:	8526                	mv	a0,s1
    800011aa:	f91ff0ef          	jal	8000113a <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    800011ae:	00006917          	auipc	s2,0x6
    800011b2:	e5290913          	addi	s2,s2,-430 # 80007000 <etext>
    800011b6:	4729                	li	a4,10
    800011b8:	800006b7          	lui	a3,0x80000
    800011bc:	96ca                	add	a3,a3,s2
    800011be:	4605                	li	a2,1
    800011c0:	067e                	slli	a2,a2,0x1f
    800011c2:	85b2                	mv	a1,a2
    800011c4:	8526                	mv	a0,s1
    800011c6:	f75ff0ef          	jal	8000113a <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    800011ca:	4719                	li	a4,6
    800011cc:	46c5                	li	a3,17
    800011ce:	06ee                	slli	a3,a3,0x1b
    800011d0:	412686b3          	sub	a3,a3,s2
    800011d4:	864a                	mv	a2,s2
    800011d6:	85ca                	mv	a1,s2
    800011d8:	8526                	mv	a0,s1
    800011da:	f61ff0ef          	jal	8000113a <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800011de:	4729                	li	a4,10
    800011e0:	6685                	lui	a3,0x1
    800011e2:	00005617          	auipc	a2,0x5
    800011e6:	e1e60613          	addi	a2,a2,-482 # 80006000 <_trampoline>
    800011ea:	040005b7          	lui	a1,0x4000
    800011ee:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800011f0:	05b2                	slli	a1,a1,0xc
    800011f2:	8526                	mv	a0,s1
    800011f4:	f47ff0ef          	jal	8000113a <kvmmap>
  proc_mapstacks(kpgtbl);
    800011f8:	8526                	mv	a0,s1
    800011fa:	5aa000ef          	jal	800017a4 <proc_mapstacks>
}
    800011fe:	8526                	mv	a0,s1
    80001200:	60e2                	ld	ra,24(sp)
    80001202:	6442                	ld	s0,16(sp)
    80001204:	64a2                	ld	s1,8(sp)
    80001206:	6902                	ld	s2,0(sp)
    80001208:	6105                	addi	sp,sp,32
    8000120a:	8082                	ret

000000008000120c <kvminit>:
{
    8000120c:	1141                	addi	sp,sp,-16
    8000120e:	e406                	sd	ra,8(sp)
    80001210:	e022                	sd	s0,0(sp)
    80001212:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    80001214:	f4fff0ef          	jal	80001162 <kvmmake>
    80001218:	00006797          	auipc	a5,0x6
    8000121c:	6ea7b423          	sd	a0,1768(a5) # 80007900 <kernel_pagetable>
}
    80001220:	60a2                	ld	ra,8(sp)
    80001222:	6402                	ld	s0,0(sp)
    80001224:	0141                	addi	sp,sp,16
    80001226:	8082                	ret

0000000080001228 <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    80001228:	715d                	addi	sp,sp,-80
    8000122a:	e486                	sd	ra,72(sp)
    8000122c:	e0a2                	sd	s0,64(sp)
    8000122e:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001230:	03459793          	slli	a5,a1,0x34
    80001234:	e39d                	bnez	a5,8000125a <uvmunmap+0x32>
    80001236:	f84a                	sd	s2,48(sp)
    80001238:	f44e                	sd	s3,40(sp)
    8000123a:	f052                	sd	s4,32(sp)
    8000123c:	ec56                	sd	s5,24(sp)
    8000123e:	e85a                	sd	s6,16(sp)
    80001240:	e45e                	sd	s7,8(sp)
    80001242:	8a2a                	mv	s4,a0
    80001244:	892e                	mv	s2,a1
    80001246:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001248:	0632                	slli	a2,a2,0xc
    8000124a:	00b609b3          	add	s3,a2,a1
    if((pte = walk(pagetable, a, 0)) == 0)
      panic("uvmunmap: walk");
    if((*pte & PTE_V) == 0)
      panic("uvmunmap: not mapped");
    if(PTE_FLAGS(*pte) == PTE_V)
    8000124e:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001250:	6b05                	lui	s6,0x1
    80001252:	0735ff63          	bgeu	a1,s3,800012d0 <uvmunmap+0xa8>
    80001256:	fc26                	sd	s1,56(sp)
    80001258:	a0a9                	j	800012a2 <uvmunmap+0x7a>
    8000125a:	fc26                	sd	s1,56(sp)
    8000125c:	f84a                	sd	s2,48(sp)
    8000125e:	f44e                	sd	s3,40(sp)
    80001260:	f052                	sd	s4,32(sp)
    80001262:	ec56                	sd	s5,24(sp)
    80001264:	e85a                	sd	s6,16(sp)
    80001266:	e45e                	sd	s7,8(sp)
    panic("uvmunmap: not aligned");
    80001268:	00006517          	auipc	a0,0x6
    8000126c:	eb850513          	addi	a0,a0,-328 # 80007120 <etext+0x120>
    80001270:	d80ff0ef          	jal	800007f0 <panic>
      panic("uvmunmap: walk");
    80001274:	00006517          	auipc	a0,0x6
    80001278:	ec450513          	addi	a0,a0,-316 # 80007138 <etext+0x138>
    8000127c:	d74ff0ef          	jal	800007f0 <panic>
      panic("uvmunmap: not mapped");
    80001280:	00006517          	auipc	a0,0x6
    80001284:	ec850513          	addi	a0,a0,-312 # 80007148 <etext+0x148>
    80001288:	d68ff0ef          	jal	800007f0 <panic>
      panic("uvmunmap: not a leaf");
    8000128c:	00006517          	auipc	a0,0x6
    80001290:	ed450513          	addi	a0,a0,-300 # 80007160 <etext+0x160>
    80001294:	d5cff0ef          	jal	800007f0 <panic>
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    80001298:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    8000129c:	995a                	add	s2,s2,s6
    8000129e:	03397863          	bgeu	s2,s3,800012ce <uvmunmap+0xa6>
    if((pte = walk(pagetable, a, 0)) == 0)
    800012a2:	4601                	li	a2,0
    800012a4:	85ca                	mv	a1,s2
    800012a6:	8552                	mv	a0,s4
    800012a8:	d11ff0ef          	jal	80000fb8 <walk>
    800012ac:	84aa                	mv	s1,a0
    800012ae:	d179                	beqz	a0,80001274 <uvmunmap+0x4c>
    if((*pte & PTE_V) == 0)
    800012b0:	6108                	ld	a0,0(a0)
    800012b2:	00157793          	andi	a5,a0,1
    800012b6:	d7e9                	beqz	a5,80001280 <uvmunmap+0x58>
    if(PTE_FLAGS(*pte) == PTE_V)
    800012b8:	3ff57793          	andi	a5,a0,1023
    800012bc:	fd7788e3          	beq	a5,s7,8000128c <uvmunmap+0x64>
    if(do_free){
    800012c0:	fc0a8ce3          	beqz	s5,80001298 <uvmunmap+0x70>
      uint64 pa = PTE2PA(*pte);
    800012c4:	8129                	srli	a0,a0,0xa
      kfree((void*)pa);
    800012c6:	0532                	slli	a0,a0,0xc
    800012c8:	fd0ff0ef          	jal	80000a98 <kfree>
    800012cc:	b7f1                	j	80001298 <uvmunmap+0x70>
    800012ce:	74e2                	ld	s1,56(sp)
    800012d0:	7942                	ld	s2,48(sp)
    800012d2:	79a2                	ld	s3,40(sp)
    800012d4:	7a02                	ld	s4,32(sp)
    800012d6:	6ae2                	ld	s5,24(sp)
    800012d8:	6b42                	ld	s6,16(sp)
    800012da:	6ba2                	ld	s7,8(sp)
  }
}
    800012dc:	60a6                	ld	ra,72(sp)
    800012de:	6406                	ld	s0,64(sp)
    800012e0:	6161                	addi	sp,sp,80
    800012e2:	8082                	ret

00000000800012e4 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    800012e4:	1101                	addi	sp,sp,-32
    800012e6:	ec06                	sd	ra,24(sp)
    800012e8:	e822                	sd	s0,16(sp)
    800012ea:	e426                	sd	s1,8(sp)
    800012ec:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    800012ee:	893ff0ef          	jal	80000b80 <kalloc>
    800012f2:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800012f4:	c509                	beqz	a0,800012fe <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    800012f6:	6605                	lui	a2,0x1
    800012f8:	4581                	li	a1,0
    800012fa:	a37ff0ef          	jal	80000d30 <memset>
  return pagetable;
}
    800012fe:	8526                	mv	a0,s1
    80001300:	60e2                	ld	ra,24(sp)
    80001302:	6442                	ld	s0,16(sp)
    80001304:	64a2                	ld	s1,8(sp)
    80001306:	6105                	addi	sp,sp,32
    80001308:	8082                	ret

000000008000130a <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    8000130a:	7179                	addi	sp,sp,-48
    8000130c:	f406                	sd	ra,40(sp)
    8000130e:	f022                	sd	s0,32(sp)
    80001310:	ec26                	sd	s1,24(sp)
    80001312:	e84a                	sd	s2,16(sp)
    80001314:	e44e                	sd	s3,8(sp)
    80001316:	e052                	sd	s4,0(sp)
    80001318:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    8000131a:	6785                	lui	a5,0x1
    8000131c:	04f67063          	bgeu	a2,a5,8000135c <uvmfirst+0x52>
    80001320:	89aa                	mv	s3,a0
    80001322:	8a2e                	mv	s4,a1
    80001324:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    80001326:	85bff0ef          	jal	80000b80 <kalloc>
    8000132a:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    8000132c:	6605                	lui	a2,0x1
    8000132e:	4581                	li	a1,0
    80001330:	a01ff0ef          	jal	80000d30 <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    80001334:	4779                	li	a4,30
    80001336:	86ca                	mv	a3,s2
    80001338:	6605                	lui	a2,0x1
    8000133a:	4581                	li	a1,0
    8000133c:	854e                	mv	a0,s3
    8000133e:	d4bff0ef          	jal	80001088 <mappages>
  memmove(mem, src, sz);
    80001342:	8626                	mv	a2,s1
    80001344:	85d2                	mv	a1,s4
    80001346:	854a                	mv	a0,s2
    80001348:	a45ff0ef          	jal	80000d8c <memmove>
}
    8000134c:	70a2                	ld	ra,40(sp)
    8000134e:	7402                	ld	s0,32(sp)
    80001350:	64e2                	ld	s1,24(sp)
    80001352:	6942                	ld	s2,16(sp)
    80001354:	69a2                	ld	s3,8(sp)
    80001356:	6a02                	ld	s4,0(sp)
    80001358:	6145                	addi	sp,sp,48
    8000135a:	8082                	ret
    panic("uvmfirst: more than a page");
    8000135c:	00006517          	auipc	a0,0x6
    80001360:	e1c50513          	addi	a0,a0,-484 # 80007178 <etext+0x178>
    80001364:	c8cff0ef          	jal	800007f0 <panic>

0000000080001368 <uvmdealloc>:
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
  if(newsz >= oldsz)
    80001368:	04b67163          	bgeu	a2,a1,800013aa <uvmdealloc+0x42>
{
    8000136c:	1101                	addi	sp,sp,-32
    8000136e:	ec06                	sd	ra,24(sp)
    80001370:	e822                	sd	s0,16(sp)
    80001372:	e426                	sd	s1,8(sp)
    80001374:	1000                	addi	s0,sp,32
    80001376:	84b2                	mv	s1,a2
    return oldsz;

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    80001378:	6785                	lui	a5,0x1
    8000137a:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000137c:	00f60733          	add	a4,a2,a5
    80001380:	76fd                	lui	a3,0xfffff
    80001382:	8f75                	and	a4,a4,a3
    80001384:	97ae                	add	a5,a5,a1
    80001386:	8ff5                	and	a5,a5,a3
    80001388:	00f76863          	bltu	a4,a5,80001398 <uvmdealloc+0x30>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
    8000138c:	8526                	mv	a0,s1
}
    8000138e:	60e2                	ld	ra,24(sp)
    80001390:	6442                	ld	s0,16(sp)
    80001392:	64a2                	ld	s1,8(sp)
    80001394:	6105                	addi	sp,sp,32
    80001396:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    80001398:	8f99                	sub	a5,a5,a4
    8000139a:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    8000139c:	4685                	li	a3,1
    8000139e:	0007861b          	sext.w	a2,a5
    800013a2:	85ba                	mv	a1,a4
    800013a4:	e85ff0ef          	jal	80001228 <uvmunmap>
    800013a8:	b7d5                	j	8000138c <uvmdealloc+0x24>
    return oldsz;
    800013aa:	852e                	mv	a0,a1
}
    800013ac:	8082                	ret

00000000800013ae <uvmalloc>:
  if(newsz < oldsz)
    800013ae:	08b66e63          	bltu	a2,a1,8000144a <uvmalloc+0x9c>
{
    800013b2:	715d                	addi	sp,sp,-80
    800013b4:	e486                	sd	ra,72(sp)
    800013b6:	e0a2                	sd	s0,64(sp)
    800013b8:	f052                	sd	s4,32(sp)
    800013ba:	ec56                	sd	s5,24(sp)
    800013bc:	e45e                	sd	s7,8(sp)
    800013be:	0880                	addi	s0,sp,80
    800013c0:	8aaa                	mv	s5,a0
    800013c2:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800013c4:	6785                	lui	a5,0x1
    800013c6:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800013c8:	95be                	add	a1,a1,a5
    800013ca:	77fd                	lui	a5,0xfffff
    800013cc:	8fed                	and	a5,a5,a1
    800013ce:	8bbe                	mv	s7,a5
  for(a = oldsz; a < newsz; a += PGSIZE){
    800013d0:	04c7f163          	bgeu	a5,a2,80001412 <uvmalloc+0x64>
    800013d4:	fc26                	sd	s1,56(sp)
    800013d6:	f84a                	sd	s2,48(sp)
    800013d8:	f44e                	sd	s3,40(sp)
    800013da:	e85a                	sd	s6,16(sp)
    800013dc:	893e                	mv	s2,a5
    memset(mem, 0, PGSIZE);
    800013de:	6985                	lui	s3,0x1
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800013e0:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    800013e4:	f9cff0ef          	jal	80000b80 <kalloc>
    800013e8:	84aa                	mv	s1,a0
    if(mem == 0){
    800013ea:	c515                	beqz	a0,80001416 <uvmalloc+0x68>
    memset(mem, 0, PGSIZE);
    800013ec:	864e                	mv	a2,s3
    800013ee:	4581                	li	a1,0
    800013f0:	941ff0ef          	jal	80000d30 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800013f4:	875a                	mv	a4,s6
    800013f6:	86a6                	mv	a3,s1
    800013f8:	864e                	mv	a2,s3
    800013fa:	85ca                	mv	a1,s2
    800013fc:	8556                	mv	a0,s5
    800013fe:	c8bff0ef          	jal	80001088 <mappages>
    80001402:	e91d                	bnez	a0,80001438 <uvmalloc+0x8a>
  for(a = oldsz; a < newsz; a += PGSIZE){
    80001404:	994e                	add	s2,s2,s3
    80001406:	fd496fe3          	bltu	s2,s4,800013e4 <uvmalloc+0x36>
    8000140a:	74e2                	ld	s1,56(sp)
    8000140c:	7942                	ld	s2,48(sp)
    8000140e:	79a2                	ld	s3,40(sp)
    80001410:	6b42                	ld	s6,16(sp)
  return newsz;
    80001412:	8552                	mv	a0,s4
    80001414:	a819                	j	8000142a <uvmalloc+0x7c>
      uvmdealloc(pagetable, a, oldsz);
    80001416:	865e                	mv	a2,s7
    80001418:	85ca                	mv	a1,s2
    8000141a:	8556                	mv	a0,s5
    8000141c:	f4dff0ef          	jal	80001368 <uvmdealloc>
      return 0;
    80001420:	4501                	li	a0,0
    80001422:	74e2                	ld	s1,56(sp)
    80001424:	7942                	ld	s2,48(sp)
    80001426:	79a2                	ld	s3,40(sp)
    80001428:	6b42                	ld	s6,16(sp)
}
    8000142a:	60a6                	ld	ra,72(sp)
    8000142c:	6406                	ld	s0,64(sp)
    8000142e:	7a02                	ld	s4,32(sp)
    80001430:	6ae2                	ld	s5,24(sp)
    80001432:	6ba2                	ld	s7,8(sp)
    80001434:	6161                	addi	sp,sp,80
    80001436:	8082                	ret
      kfree(mem);
    80001438:	8526                	mv	a0,s1
    8000143a:	e5eff0ef          	jal	80000a98 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    8000143e:	865e                	mv	a2,s7
    80001440:	85ca                	mv	a1,s2
    80001442:	8556                	mv	a0,s5
    80001444:	f25ff0ef          	jal	80001368 <uvmdealloc>
      return 0;
    80001448:	bfe1                	j	80001420 <uvmalloc+0x72>
    return oldsz;
    8000144a:	852e                	mv	a0,a1
}
    8000144c:	8082                	ret

000000008000144e <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    8000144e:	7179                	addi	sp,sp,-48
    80001450:	f406                	sd	ra,40(sp)
    80001452:	f022                	sd	s0,32(sp)
    80001454:	ec26                	sd	s1,24(sp)
    80001456:	e84a                	sd	s2,16(sp)
    80001458:	e44e                	sd	s3,8(sp)
    8000145a:	1800                	addi	s0,sp,48
    8000145c:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    8000145e:	84aa                	mv	s1,a0
    80001460:	6905                	lui	s2,0x1
    80001462:	992a                	add	s2,s2,a0
    80001464:	a811                	j	80001478 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      panic("freewalk: leaf");
    80001466:	00006517          	auipc	a0,0x6
    8000146a:	d3250513          	addi	a0,a0,-718 # 80007198 <etext+0x198>
    8000146e:	b82ff0ef          	jal	800007f0 <panic>
  for(int i = 0; i < 512; i++){
    80001472:	04a1                	addi	s1,s1,8
    80001474:	03248163          	beq	s1,s2,80001496 <freewalk+0x48>
    pte_t pte = pagetable[i];
    80001478:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    8000147a:	0017f713          	andi	a4,a5,1
    8000147e:	db75                	beqz	a4,80001472 <freewalk+0x24>
    80001480:	00e7f713          	andi	a4,a5,14
    80001484:	f36d                	bnez	a4,80001466 <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    80001486:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    80001488:	00c79513          	slli	a0,a5,0xc
    8000148c:	fc3ff0ef          	jal	8000144e <freewalk>
      pagetable[i] = 0;
    80001490:	0004b023          	sd	zero,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80001494:	bff9                	j	80001472 <freewalk+0x24>
    }
  }
  kfree((void*)pagetable);
    80001496:	854e                	mv	a0,s3
    80001498:	e00ff0ef          	jal	80000a98 <kfree>
}
    8000149c:	70a2                	ld	ra,40(sp)
    8000149e:	7402                	ld	s0,32(sp)
    800014a0:	64e2                	ld	s1,24(sp)
    800014a2:	6942                	ld	s2,16(sp)
    800014a4:	69a2                	ld	s3,8(sp)
    800014a6:	6145                	addi	sp,sp,48
    800014a8:	8082                	ret

00000000800014aa <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800014aa:	1101                	addi	sp,sp,-32
    800014ac:	ec06                	sd	ra,24(sp)
    800014ae:	e822                	sd	s0,16(sp)
    800014b0:	e426                	sd	s1,8(sp)
    800014b2:	1000                	addi	s0,sp,32
    800014b4:	84aa                	mv	s1,a0
  if(sz > 0)
    800014b6:	e989                	bnez	a1,800014c8 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    800014b8:	8526                	mv	a0,s1
    800014ba:	f95ff0ef          	jal	8000144e <freewalk>
}
    800014be:	60e2                	ld	ra,24(sp)
    800014c0:	6442                	ld	s0,16(sp)
    800014c2:	64a2                	ld	s1,8(sp)
    800014c4:	6105                	addi	sp,sp,32
    800014c6:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    800014c8:	6785                	lui	a5,0x1
    800014ca:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800014cc:	95be                	add	a1,a1,a5
    800014ce:	4685                	li	a3,1
    800014d0:	00c5d613          	srli	a2,a1,0xc
    800014d4:	4581                	li	a1,0
    800014d6:	d53ff0ef          	jal	80001228 <uvmunmap>
    800014da:	bff9                	j	800014b8 <uvmfree+0xe>

00000000800014dc <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    800014dc:	c64d                	beqz	a2,80001586 <uvmcopy+0xaa>
{
    800014de:	715d                	addi	sp,sp,-80
    800014e0:	e486                	sd	ra,72(sp)
    800014e2:	e0a2                	sd	s0,64(sp)
    800014e4:	fc26                	sd	s1,56(sp)
    800014e6:	f84a                	sd	s2,48(sp)
    800014e8:	f44e                	sd	s3,40(sp)
    800014ea:	f052                	sd	s4,32(sp)
    800014ec:	ec56                	sd	s5,24(sp)
    800014ee:	e85a                	sd	s6,16(sp)
    800014f0:	e45e                	sd	s7,8(sp)
    800014f2:	0880                	addi	s0,sp,80
    800014f4:	8b2a                	mv	s6,a0
    800014f6:	8aae                	mv	s5,a1
    800014f8:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    800014fa:	4901                	li	s2,0
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    800014fc:	6985                	lui	s3,0x1
    if((pte = walk(old, i, 0)) == 0)
    800014fe:	4601                	li	a2,0
    80001500:	85ca                	mv	a1,s2
    80001502:	855a                	mv	a0,s6
    80001504:	ab5ff0ef          	jal	80000fb8 <walk>
    80001508:	cd0d                	beqz	a0,80001542 <uvmcopy+0x66>
    if((*pte & PTE_V) == 0)
    8000150a:	00053b83          	ld	s7,0(a0)
    8000150e:	001bf793          	andi	a5,s7,1
    80001512:	cf95                	beqz	a5,8000154e <uvmcopy+0x72>
    if((mem = kalloc()) == 0)
    80001514:	e6cff0ef          	jal	80000b80 <kalloc>
    80001518:	84aa                	mv	s1,a0
    8000151a:	c139                	beqz	a0,80001560 <uvmcopy+0x84>
    pa = PTE2PA(*pte);
    8000151c:	00abd593          	srli	a1,s7,0xa
    memmove(mem, (char*)pa, PGSIZE);
    80001520:	864e                	mv	a2,s3
    80001522:	05b2                	slli	a1,a1,0xc
    80001524:	869ff0ef          	jal	80000d8c <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    80001528:	3ffbf713          	andi	a4,s7,1023
    8000152c:	86a6                	mv	a3,s1
    8000152e:	864e                	mv	a2,s3
    80001530:	85ca                	mv	a1,s2
    80001532:	8556                	mv	a0,s5
    80001534:	b55ff0ef          	jal	80001088 <mappages>
    80001538:	e10d                	bnez	a0,8000155a <uvmcopy+0x7e>
  for(i = 0; i < sz; i += PGSIZE){
    8000153a:	994e                	add	s2,s2,s3
    8000153c:	fd4961e3          	bltu	s2,s4,800014fe <uvmcopy+0x22>
    80001540:	a805                	j	80001570 <uvmcopy+0x94>
      panic("uvmcopy: pte should exist");
    80001542:	00006517          	auipc	a0,0x6
    80001546:	c6650513          	addi	a0,a0,-922 # 800071a8 <etext+0x1a8>
    8000154a:	aa6ff0ef          	jal	800007f0 <panic>
      panic("uvmcopy: page not present");
    8000154e:	00006517          	auipc	a0,0x6
    80001552:	c7a50513          	addi	a0,a0,-902 # 800071c8 <etext+0x1c8>
    80001556:	a9aff0ef          	jal	800007f0 <panic>
      kfree(mem);
    8000155a:	8526                	mv	a0,s1
    8000155c:	d3cff0ef          	jal	80000a98 <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    80001560:	4685                	li	a3,1
    80001562:	00c95613          	srli	a2,s2,0xc
    80001566:	4581                	li	a1,0
    80001568:	8556                	mv	a0,s5
    8000156a:	cbfff0ef          	jal	80001228 <uvmunmap>
  return -1;
    8000156e:	557d                	li	a0,-1
}
    80001570:	60a6                	ld	ra,72(sp)
    80001572:	6406                	ld	s0,64(sp)
    80001574:	74e2                	ld	s1,56(sp)
    80001576:	7942                	ld	s2,48(sp)
    80001578:	79a2                	ld	s3,40(sp)
    8000157a:	7a02                	ld	s4,32(sp)
    8000157c:	6ae2                	ld	s5,24(sp)
    8000157e:	6b42                	ld	s6,16(sp)
    80001580:	6ba2                	ld	s7,8(sp)
    80001582:	6161                	addi	sp,sp,80
    80001584:	8082                	ret
  return 0;
    80001586:	4501                	li	a0,0
}
    80001588:	8082                	ret

000000008000158a <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    8000158a:	1141                	addi	sp,sp,-16
    8000158c:	e406                	sd	ra,8(sp)
    8000158e:	e022                	sd	s0,0(sp)
    80001590:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    80001592:	4601                	li	a2,0
    80001594:	a25ff0ef          	jal	80000fb8 <walk>
  if(pte == 0)
    80001598:	c901                	beqz	a0,800015a8 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    8000159a:	611c                	ld	a5,0(a0)
    8000159c:	9bbd                	andi	a5,a5,-17
    8000159e:	e11c                	sd	a5,0(a0)
}
    800015a0:	60a2                	ld	ra,8(sp)
    800015a2:	6402                	ld	s0,0(sp)
    800015a4:	0141                	addi	sp,sp,16
    800015a6:	8082                	ret
    panic("uvmclear");
    800015a8:	00006517          	auipc	a0,0x6
    800015ac:	c4050513          	addi	a0,a0,-960 # 800071e8 <etext+0x1e8>
    800015b0:	a40ff0ef          	jal	800007f0 <panic>

00000000800015b4 <copyout>:
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  while(len > 0){
    800015b4:	c6cd                	beqz	a3,8000165e <copyout+0xaa>
{
    800015b6:	711d                	addi	sp,sp,-96
    800015b8:	ec86                	sd	ra,88(sp)
    800015ba:	e8a2                	sd	s0,80(sp)
    800015bc:	e4a6                	sd	s1,72(sp)
    800015be:	e0ca                	sd	s2,64(sp)
    800015c0:	fc4e                	sd	s3,56(sp)
    800015c2:	f852                	sd	s4,48(sp)
    800015c4:	f456                	sd	s5,40(sp)
    800015c6:	f05a                	sd	s6,32(sp)
    800015c8:	ec5e                	sd	s7,24(sp)
    800015ca:	e862                	sd	s8,16(sp)
    800015cc:	e466                	sd	s9,8(sp)
    800015ce:	1080                	addi	s0,sp,96
    800015d0:	8c2a                	mv	s8,a0
    800015d2:	84ae                	mv	s1,a1
    800015d4:	8ab2                	mv	s5,a2
    800015d6:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    800015d8:	7cfd                	lui	s9,0xfffff
    if(va0 >= MAXVA)
    800015da:	5bfd                	li	s7,-1
    800015dc:	01abdb93          	srli	s7,s7,0x1a
    pte = walk(pagetable, va0, 0);
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
       (*pte & PTE_W) == 0)
      return -1;
    pa0 = PTE2PA(*pte);
    n = PGSIZE - (dstva - va0);
    800015e0:	6b05                	lui	s6,0x1
    800015e2:	a089                	j	80001624 <copyout+0x70>
      return -1;
    800015e4:	557d                	li	a0,-1
    len -= n;
    src += n;
    dstva = va0 + PGSIZE;
  }
  return 0;
}
    800015e6:	60e6                	ld	ra,88(sp)
    800015e8:	6446                	ld	s0,80(sp)
    800015ea:	64a6                	ld	s1,72(sp)
    800015ec:	6906                	ld	s2,64(sp)
    800015ee:	79e2                	ld	s3,56(sp)
    800015f0:	7a42                	ld	s4,48(sp)
    800015f2:	7aa2                	ld	s5,40(sp)
    800015f4:	7b02                	ld	s6,32(sp)
    800015f6:	6be2                	ld	s7,24(sp)
    800015f8:	6c42                	ld	s8,16(sp)
    800015fa:	6ca2                	ld	s9,8(sp)
    800015fc:	6125                	addi	sp,sp,96
    800015fe:	8082                	ret
    pa0 = PTE2PA(*pte);
    80001600:	83a9                	srli	a5,a5,0xa
    80001602:	07b2                	slli	a5,a5,0xc
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001604:	03449513          	slli	a0,s1,0x34
    80001608:	9151                	srli	a0,a0,0x34
    8000160a:	0009061b          	sext.w	a2,s2
    8000160e:	85d6                	mv	a1,s5
    80001610:	953e                	add	a0,a0,a5
    80001612:	f7aff0ef          	jal	80000d8c <memmove>
    len -= n;
    80001616:	412a0a33          	sub	s4,s4,s2
    src += n;
    8000161a:	9aca                	add	s5,s5,s2
    dstva = va0 + PGSIZE;
    8000161c:	016984b3          	add	s1,s3,s6
  while(len > 0){
    80001620:	020a0d63          	beqz	s4,8000165a <copyout+0xa6>
    va0 = PGROUNDDOWN(dstva);
    80001624:	0194f9b3          	and	s3,s1,s9
    if(va0 >= MAXVA)
    80001628:	fb3beee3          	bltu	s7,s3,800015e4 <copyout+0x30>
    pte = walk(pagetable, va0, 0);
    8000162c:	4601                	li	a2,0
    8000162e:	85ce                	mv	a1,s3
    80001630:	8562                	mv	a0,s8
    80001632:	987ff0ef          	jal	80000fb8 <walk>
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80001636:	d55d                	beqz	a0,800015e4 <copyout+0x30>
    80001638:	611c                	ld	a5,0(a0)
    8000163a:	0017f713          	andi	a4,a5,1
    8000163e:	d35d                	beqz	a4,800015e4 <copyout+0x30>
    80001640:	0107f713          	andi	a4,a5,16
    80001644:	d345                	beqz	a4,800015e4 <copyout+0x30>
       (*pte & PTE_W) == 0)
    80001646:	0047f713          	andi	a4,a5,4
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    8000164a:	df49                	beqz	a4,800015e4 <copyout+0x30>
    n = PGSIZE - (dstva - va0);
    8000164c:	40998933          	sub	s2,s3,s1
    80001650:	995a                	add	s2,s2,s6
    if(n > len)
    80001652:	fb2a77e3          	bgeu	s4,s2,80001600 <copyout+0x4c>
    80001656:	8952                	mv	s2,s4
    80001658:	b765                	j	80001600 <copyout+0x4c>
  return 0;
    8000165a:	4501                	li	a0,0
    8000165c:	b769                	j	800015e6 <copyout+0x32>
    8000165e:	4501                	li	a0,0
}
    80001660:	8082                	ret

0000000080001662 <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    80001662:	c2c9                	beqz	a3,800016e4 <copyin+0x82>
{
    80001664:	715d                	addi	sp,sp,-80
    80001666:	e486                	sd	ra,72(sp)
    80001668:	e0a2                	sd	s0,64(sp)
    8000166a:	fc26                	sd	s1,56(sp)
    8000166c:	f84a                	sd	s2,48(sp)
    8000166e:	f44e                	sd	s3,40(sp)
    80001670:	f052                	sd	s4,32(sp)
    80001672:	ec56                	sd	s5,24(sp)
    80001674:	e85a                	sd	s6,16(sp)
    80001676:	e45e                	sd	s7,8(sp)
    80001678:	e062                	sd	s8,0(sp)
    8000167a:	0880                	addi	s0,sp,80
    8000167c:	8baa                	mv	s7,a0
    8000167e:	8aae                	mv	s5,a1
    80001680:	84b2                	mv	s1,a2
    80001682:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80001684:	7c7d                	lui	s8,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80001686:	6b05                	lui	s6,0x1
    80001688:	a00d                	j	800016aa <copyin+0x48>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    8000168a:	03449593          	slli	a1,s1,0x34
    8000168e:	91d1                	srli	a1,a1,0x34
    80001690:	0009061b          	sext.w	a2,s2
    80001694:	95aa                	add	a1,a1,a0
    80001696:	8556                	mv	a0,s5
    80001698:	ef4ff0ef          	jal	80000d8c <memmove>

    len -= n;
    8000169c:	412989b3          	sub	s3,s3,s2
    dst += n;
    800016a0:	9aca                	add	s5,s5,s2
    srcva = va0 + PGSIZE;
    800016a2:	016a04b3          	add	s1,s4,s6
  while(len > 0){
    800016a6:	02098063          	beqz	s3,800016c6 <copyin+0x64>
    va0 = PGROUNDDOWN(srcva);
    800016aa:	0184fa33          	and	s4,s1,s8
    pa0 = walkaddr(pagetable, va0);
    800016ae:	85d2                	mv	a1,s4
    800016b0:	855e                	mv	a0,s7
    800016b2:	99fff0ef          	jal	80001050 <walkaddr>
    if(pa0 == 0)
    800016b6:	c50d                	beqz	a0,800016e0 <copyin+0x7e>
    n = PGSIZE - (srcva - va0);
    800016b8:	409a0933          	sub	s2,s4,s1
    800016bc:	995a                	add	s2,s2,s6
    if(n > len)
    800016be:	fd29f6e3          	bgeu	s3,s2,8000168a <copyin+0x28>
    800016c2:	894e                	mv	s2,s3
    800016c4:	b7d9                	j	8000168a <copyin+0x28>
  }
  return 0;
    800016c6:	4501                	li	a0,0
}
    800016c8:	60a6                	ld	ra,72(sp)
    800016ca:	6406                	ld	s0,64(sp)
    800016cc:	74e2                	ld	s1,56(sp)
    800016ce:	7942                	ld	s2,48(sp)
    800016d0:	79a2                	ld	s3,40(sp)
    800016d2:	7a02                	ld	s4,32(sp)
    800016d4:	6ae2                	ld	s5,24(sp)
    800016d6:	6b42                	ld	s6,16(sp)
    800016d8:	6ba2                	ld	s7,8(sp)
    800016da:	6c02                	ld	s8,0(sp)
    800016dc:	6161                	addi	sp,sp,80
    800016de:	8082                	ret
      return -1;
    800016e0:	557d                	li	a0,-1
    800016e2:	b7dd                	j	800016c8 <copyin+0x66>
  return 0;
    800016e4:	4501                	li	a0,0
}
    800016e6:	8082                	ret

00000000800016e8 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    800016e8:	cac5                	beqz	a3,80001798 <copyinstr+0xb0>
{
    800016ea:	715d                	addi	sp,sp,-80
    800016ec:	e486                	sd	ra,72(sp)
    800016ee:	e0a2                	sd	s0,64(sp)
    800016f0:	fc26                	sd	s1,56(sp)
    800016f2:	f84a                	sd	s2,48(sp)
    800016f4:	f44e                	sd	s3,40(sp)
    800016f6:	f052                	sd	s4,32(sp)
    800016f8:	ec56                	sd	s5,24(sp)
    800016fa:	e85a                	sd	s6,16(sp)
    800016fc:	e45e                	sd	s7,8(sp)
    800016fe:	0880                	addi	s0,sp,80
    80001700:	8aaa                	mv	s5,a0
    80001702:	84ae                	mv	s1,a1
    80001704:	8bb2                	mv	s7,a2
    80001706:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80001708:	7b7d                	lui	s6,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    8000170a:	6a05                	lui	s4,0x1
    8000170c:	a82d                	j	80001746 <copyinstr+0x5e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    8000170e:	00078023          	sb	zero,0(a5)
        got_null = 1;
    80001712:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80001714:	0017c793          	xori	a5,a5,1
    80001718:	40f0053b          	negw	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    8000171c:	60a6                	ld	ra,72(sp)
    8000171e:	6406                	ld	s0,64(sp)
    80001720:	74e2                	ld	s1,56(sp)
    80001722:	7942                	ld	s2,48(sp)
    80001724:	79a2                	ld	s3,40(sp)
    80001726:	7a02                	ld	s4,32(sp)
    80001728:	6ae2                	ld	s5,24(sp)
    8000172a:	6b42                	ld	s6,16(sp)
    8000172c:	6ba2                	ld	s7,8(sp)
    8000172e:	6161                	addi	sp,sp,80
    80001730:	8082                	ret
    80001732:	fff98713          	addi	a4,s3,-1 # fff <_entry-0x7ffff001>
    80001736:	9726                	add	a4,a4,s1
      --max;
    80001738:	40b709b3          	sub	s3,a4,a1
    srcva = va0 + PGSIZE;
    8000173c:	01490bb3          	add	s7,s2,s4
  while(got_null == 0 && max > 0){
    80001740:	04e58463          	beq	a1,a4,80001788 <copyinstr+0xa0>
{
    80001744:	84be                	mv	s1,a5
    va0 = PGROUNDDOWN(srcva);
    80001746:	016bf933          	and	s2,s7,s6
    pa0 = walkaddr(pagetable, va0);
    8000174a:	85ca                	mv	a1,s2
    8000174c:	8556                	mv	a0,s5
    8000174e:	903ff0ef          	jal	80001050 <walkaddr>
    if(pa0 == 0)
    80001752:	cd0d                	beqz	a0,8000178c <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    80001754:	41790633          	sub	a2,s2,s7
    80001758:	9652                	add	a2,a2,s4
    if(n > max)
    8000175a:	00c9f363          	bgeu	s3,a2,80001760 <copyinstr+0x78>
    8000175e:	864e                	mv	a2,s3
    while(n > 0){
    80001760:	ca05                	beqz	a2,80001790 <copyinstr+0xa8>
    char *p = (char *) (pa0 + (srcva - va0));
    80001762:	034b9693          	slli	a3,s7,0x34
    80001766:	92d1                	srli	a3,a3,0x34
    80001768:	96aa                	add	a3,a3,a0
    8000176a:	87a6                	mv	a5,s1
      if(*p == '\0'){
    8000176c:	8e85                	sub	a3,a3,s1
    while(n > 0){
    8000176e:	9626                	add	a2,a2,s1
    80001770:	85be                	mv	a1,a5
      if(*p == '\0'){
    80001772:	00f68733          	add	a4,a3,a5
    80001776:	00074703          	lbu	a4,0(a4)
    8000177a:	db51                	beqz	a4,8000170e <copyinstr+0x26>
        *dst = *p;
    8000177c:	00e78023          	sb	a4,0(a5)
      dst++;
    80001780:	0785                	addi	a5,a5,1
    while(n > 0){
    80001782:	fec797e3          	bne	a5,a2,80001770 <copyinstr+0x88>
    80001786:	b775                	j	80001732 <copyinstr+0x4a>
    srcva = va0 + PGSIZE;
    80001788:	4781                	li	a5,0
    8000178a:	b769                	j	80001714 <copyinstr+0x2c>
      return -1;
    8000178c:	557d                	li	a0,-1
    8000178e:	b779                	j	8000171c <copyinstr+0x34>
    srcva = va0 + PGSIZE;
    80001790:	6b85                	lui	s7,0x1
    80001792:	9bca                	add	s7,s7,s2
    80001794:	87a6                	mv	a5,s1
    80001796:	b77d                	j	80001744 <copyinstr+0x5c>
    80001798:	4781                	li	a5,0
  if(got_null){
    8000179a:	0017c793          	xori	a5,a5,1
    8000179e:	40f0053b          	negw	a0,a5
}
    800017a2:	8082                	ret

00000000800017a4 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    800017a4:	715d                	addi	sp,sp,-80
    800017a6:	e486                	sd	ra,72(sp)
    800017a8:	e0a2                	sd	s0,64(sp)
    800017aa:	fc26                	sd	s1,56(sp)
    800017ac:	f84a                	sd	s2,48(sp)
    800017ae:	f44e                	sd	s3,40(sp)
    800017b0:	f052                	sd	s4,32(sp)
    800017b2:	ec56                	sd	s5,24(sp)
    800017b4:	e85a                	sd	s6,16(sp)
    800017b6:	e45e                	sd	s7,8(sp)
    800017b8:	0880                	addi	s0,sp,80
    800017ba:	8aaa                	mv	s5,a0
    800017bc:	4481                	li	s1,0
  
  for(p = proc; p < &proc[NPROC]; p++) {
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    800017be:	000a57b7          	lui	a5,0xa5
    800017c2:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    800017c6:	07b2                	slli	a5,a5,0xc
    800017c8:	fa578793          	addi	a5,a5,-91
    800017cc:	4fa50937          	lui	s2,0x4fa50
    800017d0:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    800017d4:	1902                	slli	s2,s2,0x20
    800017d6:	993e                	add	s2,s2,a5
    800017d8:	040009b7          	lui	s3,0x4000
    800017dc:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800017de:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017e0:	4b99                	li	s7,6
    800017e2:	6b05                	lui	s6,0x1
  for(p = proc; p < &proc[NPROC]; p++) {
    800017e4:	6a19                	lui	s4,0x6
    800017e6:	a00a0a13          	addi	s4,s4,-1536 # 5a00 <_entry-0x7fffa600>
    char *pa = kalloc();
    800017ea:	b96ff0ef          	jal	80000b80 <kalloc>
    800017ee:	862a                	mv	a2,a0
    if(pa == 0)
    800017f0:	cd15                	beqz	a0,8000182c <proc_mapstacks+0x88>
    uint64 va = KSTACK((int) (p - proc));
    800017f2:	4034d593          	srai	a1,s1,0x3
    800017f6:	032585b3          	mul	a1,a1,s2
    800017fa:	05b6                	slli	a1,a1,0xd
    800017fc:	6789                	lui	a5,0x2
    800017fe:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80001800:	875e                	mv	a4,s7
    80001802:	86da                	mv	a3,s6
    80001804:	40b985b3          	sub	a1,s3,a1
    80001808:	8556                	mv	a0,s5
    8000180a:	931ff0ef          	jal	8000113a <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000180e:	16848493          	addi	s1,s1,360
    80001812:	fd449ce3          	bne	s1,s4,800017ea <proc_mapstacks+0x46>
  }
}
    80001816:	60a6                	ld	ra,72(sp)
    80001818:	6406                	ld	s0,64(sp)
    8000181a:	74e2                	ld	s1,56(sp)
    8000181c:	7942                	ld	s2,48(sp)
    8000181e:	79a2                	ld	s3,40(sp)
    80001820:	7a02                	ld	s4,32(sp)
    80001822:	6ae2                	ld	s5,24(sp)
    80001824:	6b42                	ld	s6,16(sp)
    80001826:	6ba2                	ld	s7,8(sp)
    80001828:	6161                	addi	sp,sp,80
    8000182a:	8082                	ret
      panic("kalloc");
    8000182c:	00006517          	auipc	a0,0x6
    80001830:	9cc50513          	addi	a0,a0,-1588 # 800071f8 <etext+0x1f8>
    80001834:	fbdfe0ef          	jal	800007f0 <panic>

0000000080001838 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80001838:	7139                	addi	sp,sp,-64
    8000183a:	fc06                	sd	ra,56(sp)
    8000183c:	f822                	sd	s0,48(sp)
    8000183e:	f426                	sd	s1,40(sp)
    80001840:	f04a                	sd	s2,32(sp)
    80001842:	ec4e                	sd	s3,24(sp)
    80001844:	e852                	sd	s4,16(sp)
    80001846:	e456                	sd	s5,8(sp)
    80001848:	e05a                	sd	s6,0(sp)
    8000184a:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    8000184c:	00006597          	auipc	a1,0x6
    80001850:	9b458593          	addi	a1,a1,-1612 # 80007200 <etext+0x200>
    80001854:	0000e517          	auipc	a0,0xe
    80001858:	1ec50513          	addi	a0,a0,492 # 8000fa40 <pid_lock>
    8000185c:	b7eff0ef          	jal	80000bda <initlock>
  initlock(&wait_lock, "wait_lock");
    80001860:	00006597          	auipc	a1,0x6
    80001864:	9a858593          	addi	a1,a1,-1624 # 80007208 <etext+0x208>
    80001868:	0000e517          	auipc	a0,0xe
    8000186c:	1f050513          	addi	a0,a0,496 # 8000fa58 <wait_lock>
    80001870:	b6aff0ef          	jal	80000bda <initlock>
    80001874:	4901                	li	s2,0
  for(p = proc; p < &proc[NPROC]; p++) {
    80001876:	0000e497          	auipc	s1,0xe
    8000187a:	5fa48493          	addi	s1,s1,1530 # 8000fe70 <proc>
      initlock(&p->lock, "proc");
    8000187e:	00006a97          	auipc	s5,0x6
    80001882:	99aa8a93          	addi	s5,s5,-1638 # 80007218 <etext+0x218>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80001886:	000a57b7          	lui	a5,0xa5
    8000188a:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    8000188e:	07b2                	slli	a5,a5,0xc
    80001890:	fa578793          	addi	a5,a5,-91
    80001894:	4fa509b7          	lui	s3,0x4fa50
    80001898:	a4f98993          	addi	s3,s3,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    8000189c:	1982                	slli	s3,s3,0x20
    8000189e:	99be                	add	s3,s3,a5
    800018a0:	04000a37          	lui	s4,0x4000
    800018a4:	1a7d                	addi	s4,s4,-1 # 3ffffff <_entry-0x7c000001>
    800018a6:	0a32                	slli	s4,s4,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    800018a8:	00014b17          	auipc	s6,0x14
    800018ac:	fc8b0b13          	addi	s6,s6,-56 # 80015870 <tickslock>
      initlock(&p->lock, "proc");
    800018b0:	85d6                	mv	a1,s5
    800018b2:	8526                	mv	a0,s1
    800018b4:	b26ff0ef          	jal	80000bda <initlock>
      p->state = UNUSED;
    800018b8:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    800018bc:	40395793          	srai	a5,s2,0x3
    800018c0:	033787b3          	mul	a5,a5,s3
    800018c4:	07b6                	slli	a5,a5,0xd
    800018c6:	6709                	lui	a4,0x2
    800018c8:	9fb9                	addw	a5,a5,a4
    800018ca:	40fa07b3          	sub	a5,s4,a5
    800018ce:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    800018d0:	16848493          	addi	s1,s1,360
    800018d4:	16890913          	addi	s2,s2,360
    800018d8:	fd649ce3          	bne	s1,s6,800018b0 <procinit+0x78>
  }
}
    800018dc:	70e2                	ld	ra,56(sp)
    800018de:	7442                	ld	s0,48(sp)
    800018e0:	74a2                	ld	s1,40(sp)
    800018e2:	7902                	ld	s2,32(sp)
    800018e4:	69e2                	ld	s3,24(sp)
    800018e6:	6a42                	ld	s4,16(sp)
    800018e8:	6aa2                	ld	s5,8(sp)
    800018ea:	6b02                	ld	s6,0(sp)
    800018ec:	6121                	addi	sp,sp,64
    800018ee:	8082                	ret

00000000800018f0 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    800018f0:	1141                	addi	sp,sp,-16
    800018f2:	e406                	sd	ra,8(sp)
    800018f4:	e022                	sd	s0,0(sp)
    800018f6:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    800018f8:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    800018fa:	2501                	sext.w	a0,a0
    800018fc:	60a2                	ld	ra,8(sp)
    800018fe:	6402                	ld	s0,0(sp)
    80001900:	0141                	addi	sp,sp,16
    80001902:	8082                	ret

0000000080001904 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80001904:	1141                	addi	sp,sp,-16
    80001906:	e406                	sd	ra,8(sp)
    80001908:	e022                	sd	s0,0(sp)
    8000190a:	0800                	addi	s0,sp,16
    8000190c:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    8000190e:	2781                	sext.w	a5,a5
    80001910:	079e                	slli	a5,a5,0x7
  return c;
}
    80001912:	0000e517          	auipc	a0,0xe
    80001916:	15e50513          	addi	a0,a0,350 # 8000fa70 <cpus>
    8000191a:	953e                	add	a0,a0,a5
    8000191c:	60a2                	ld	ra,8(sp)
    8000191e:	6402                	ld	s0,0(sp)
    80001920:	0141                	addi	sp,sp,16
    80001922:	8082                	ret

0000000080001924 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80001924:	1101                	addi	sp,sp,-32
    80001926:	ec06                	sd	ra,24(sp)
    80001928:	e822                	sd	s0,16(sp)
    8000192a:	e426                	sd	s1,8(sp)
    8000192c:	1000                	addi	s0,sp,32
  push_off();
    8000192e:	af2ff0ef          	jal	80000c20 <push_off>
    80001932:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001934:	2781                	sext.w	a5,a5
    80001936:	079e                	slli	a5,a5,0x7
    80001938:	0000e717          	auipc	a4,0xe
    8000193c:	10870713          	addi	a4,a4,264 # 8000fa40 <pid_lock>
    80001940:	97ba                	add	a5,a5,a4
    80001942:	7b9c                	ld	a5,48(a5)
    80001944:	84be                	mv	s1,a5
  pop_off();
    80001946:	b5eff0ef          	jal	80000ca4 <pop_off>
  return p;
}
    8000194a:	8526                	mv	a0,s1
    8000194c:	60e2                	ld	ra,24(sp)
    8000194e:	6442                	ld	s0,16(sp)
    80001950:	64a2                	ld	s1,8(sp)
    80001952:	6105                	addi	sp,sp,32
    80001954:	8082                	ret

0000000080001956 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001956:	1141                	addi	sp,sp,-16
    80001958:	e406                	sd	ra,8(sp)
    8000195a:	e022                	sd	s0,0(sp)
    8000195c:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    8000195e:	fc7ff0ef          	jal	80001924 <myproc>
    80001962:	b92ff0ef          	jal	80000cf4 <release>

  if (first) {
    80001966:	00006797          	auipc	a5,0x6
    8000196a:	f2a7a783          	lw	a5,-214(a5) # 80007890 <first.1>
    8000196e:	e799                	bnez	a5,8000197c <forkret+0x26>
    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();
  }

  usertrapret();
    80001970:	2db000ef          	jal	8000244a <usertrapret>
}
    80001974:	60a2                	ld	ra,8(sp)
    80001976:	6402                	ld	s0,0(sp)
    80001978:	0141                	addi	sp,sp,16
    8000197a:	8082                	ret
    fsinit(ROOTDEV);
    8000197c:	4505                	li	a0,1
    8000197e:	652010ef          	jal	80002fd0 <fsinit>
    first = 0;
    80001982:	00006797          	auipc	a5,0x6
    80001986:	f007a723          	sw	zero,-242(a5) # 80007890 <first.1>
    __sync_synchronize();
    8000198a:	0330000f          	fence	rw,rw
    8000198e:	b7cd                	j	80001970 <forkret+0x1a>

0000000080001990 <allocpid>:
{
    80001990:	1101                	addi	sp,sp,-32
    80001992:	ec06                	sd	ra,24(sp)
    80001994:	e822                	sd	s0,16(sp)
    80001996:	e426                	sd	s1,8(sp)
    80001998:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    8000199a:	0000e517          	auipc	a0,0xe
    8000199e:	0a650513          	addi	a0,a0,166 # 8000fa40 <pid_lock>
    800019a2:	ac2ff0ef          	jal	80000c64 <acquire>
  pid = nextpid;
    800019a6:	00006797          	auipc	a5,0x6
    800019aa:	eee78793          	addi	a5,a5,-274 # 80007894 <nextpid>
    800019ae:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    800019b0:	0014871b          	addiw	a4,s1,1
    800019b4:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    800019b6:	0000e517          	auipc	a0,0xe
    800019ba:	08a50513          	addi	a0,a0,138 # 8000fa40 <pid_lock>
    800019be:	b36ff0ef          	jal	80000cf4 <release>
}
    800019c2:	8526                	mv	a0,s1
    800019c4:	60e2                	ld	ra,24(sp)
    800019c6:	6442                	ld	s0,16(sp)
    800019c8:	64a2                	ld	s1,8(sp)
    800019ca:	6105                	addi	sp,sp,32
    800019cc:	8082                	ret

00000000800019ce <proc_pagetable>:
{
    800019ce:	1101                	addi	sp,sp,-32
    800019d0:	ec06                	sd	ra,24(sp)
    800019d2:	e822                	sd	s0,16(sp)
    800019d4:	e426                	sd	s1,8(sp)
    800019d6:	e04a                	sd	s2,0(sp)
    800019d8:	1000                	addi	s0,sp,32
    800019da:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    800019dc:	909ff0ef          	jal	800012e4 <uvmcreate>
    800019e0:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800019e2:	cd05                	beqz	a0,80001a1a <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    800019e4:	4729                	li	a4,10
    800019e6:	00004697          	auipc	a3,0x4
    800019ea:	61a68693          	addi	a3,a3,1562 # 80006000 <_trampoline>
    800019ee:	6605                	lui	a2,0x1
    800019f0:	040005b7          	lui	a1,0x4000
    800019f4:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800019f6:	05b2                	slli	a1,a1,0xc
    800019f8:	e90ff0ef          	jal	80001088 <mappages>
    800019fc:	02054663          	bltz	a0,80001a28 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001a00:	4719                	li	a4,6
    80001a02:	05893683          	ld	a3,88(s2)
    80001a06:	6605                	lui	a2,0x1
    80001a08:	020005b7          	lui	a1,0x2000
    80001a0c:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a0e:	05b6                	slli	a1,a1,0xd
    80001a10:	8526                	mv	a0,s1
    80001a12:	e76ff0ef          	jal	80001088 <mappages>
    80001a16:	00054f63          	bltz	a0,80001a34 <proc_pagetable+0x66>
}
    80001a1a:	8526                	mv	a0,s1
    80001a1c:	60e2                	ld	ra,24(sp)
    80001a1e:	6442                	ld	s0,16(sp)
    80001a20:	64a2                	ld	s1,8(sp)
    80001a22:	6902                	ld	s2,0(sp)
    80001a24:	6105                	addi	sp,sp,32
    80001a26:	8082                	ret
    uvmfree(pagetable, 0);
    80001a28:	4581                	li	a1,0
    80001a2a:	8526                	mv	a0,s1
    80001a2c:	a7fff0ef          	jal	800014aa <uvmfree>
    return 0;
    80001a30:	4481                	li	s1,0
    80001a32:	b7e5                	j	80001a1a <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a34:	4681                	li	a3,0
    80001a36:	4605                	li	a2,1
    80001a38:	040005b7          	lui	a1,0x4000
    80001a3c:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a3e:	05b2                	slli	a1,a1,0xc
    80001a40:	8526                	mv	a0,s1
    80001a42:	fe6ff0ef          	jal	80001228 <uvmunmap>
    uvmfree(pagetable, 0);
    80001a46:	4581                	li	a1,0
    80001a48:	8526                	mv	a0,s1
    80001a4a:	a61ff0ef          	jal	800014aa <uvmfree>
    return 0;
    80001a4e:	b7cd                	j	80001a30 <proc_pagetable+0x62>

0000000080001a50 <proc_freepagetable>:
{
    80001a50:	1101                	addi	sp,sp,-32
    80001a52:	ec06                	sd	ra,24(sp)
    80001a54:	e822                	sd	s0,16(sp)
    80001a56:	e426                	sd	s1,8(sp)
    80001a58:	e04a                	sd	s2,0(sp)
    80001a5a:	1000                	addi	s0,sp,32
    80001a5c:	84aa                	mv	s1,a0
    80001a5e:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a60:	4681                	li	a3,0
    80001a62:	4605                	li	a2,1
    80001a64:	040005b7          	lui	a1,0x4000
    80001a68:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a6a:	05b2                	slli	a1,a1,0xc
    80001a6c:	fbcff0ef          	jal	80001228 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001a70:	4681                	li	a3,0
    80001a72:	4605                	li	a2,1
    80001a74:	020005b7          	lui	a1,0x2000
    80001a78:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a7a:	05b6                	slli	a1,a1,0xd
    80001a7c:	8526                	mv	a0,s1
    80001a7e:	faaff0ef          	jal	80001228 <uvmunmap>
  uvmfree(pagetable, sz);
    80001a82:	85ca                	mv	a1,s2
    80001a84:	8526                	mv	a0,s1
    80001a86:	a25ff0ef          	jal	800014aa <uvmfree>
}
    80001a8a:	60e2                	ld	ra,24(sp)
    80001a8c:	6442                	ld	s0,16(sp)
    80001a8e:	64a2                	ld	s1,8(sp)
    80001a90:	6902                	ld	s2,0(sp)
    80001a92:	6105                	addi	sp,sp,32
    80001a94:	8082                	ret

0000000080001a96 <freeproc>:
{
    80001a96:	1101                	addi	sp,sp,-32
    80001a98:	ec06                	sd	ra,24(sp)
    80001a9a:	e822                	sd	s0,16(sp)
    80001a9c:	e426                	sd	s1,8(sp)
    80001a9e:	1000                	addi	s0,sp,32
    80001aa0:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001aa2:	6d28                	ld	a0,88(a0)
    80001aa4:	c119                	beqz	a0,80001aaa <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001aa6:	ff3fe0ef          	jal	80000a98 <kfree>
  p->trapframe = 0;
    80001aaa:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001aae:	68a8                	ld	a0,80(s1)
    80001ab0:	c501                	beqz	a0,80001ab8 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001ab2:	64ac                	ld	a1,72(s1)
    80001ab4:	f9dff0ef          	jal	80001a50 <proc_freepagetable>
  p->pagetable = 0;
    80001ab8:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001abc:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001ac0:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001ac4:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001ac8:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001acc:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001ad0:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001ad4:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001ad8:	0004ac23          	sw	zero,24(s1)
}
    80001adc:	60e2                	ld	ra,24(sp)
    80001ade:	6442                	ld	s0,16(sp)
    80001ae0:	64a2                	ld	s1,8(sp)
    80001ae2:	6105                	addi	sp,sp,32
    80001ae4:	8082                	ret

0000000080001ae6 <allocproc>:
{
    80001ae6:	1101                	addi	sp,sp,-32
    80001ae8:	ec06                	sd	ra,24(sp)
    80001aea:	e822                	sd	s0,16(sp)
    80001aec:	e426                	sd	s1,8(sp)
    80001aee:	e04a                	sd	s2,0(sp)
    80001af0:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001af2:	0000e497          	auipc	s1,0xe
    80001af6:	37e48493          	addi	s1,s1,894 # 8000fe70 <proc>
    80001afa:	00014917          	auipc	s2,0x14
    80001afe:	d7690913          	addi	s2,s2,-650 # 80015870 <tickslock>
    acquire(&p->lock);
    80001b02:	8526                	mv	a0,s1
    80001b04:	960ff0ef          	jal	80000c64 <acquire>
    if(p->state == UNUSED) {
    80001b08:	4c9c                	lw	a5,24(s1)
    80001b0a:	cb91                	beqz	a5,80001b1e <allocproc+0x38>
      release(&p->lock);
    80001b0c:	8526                	mv	a0,s1
    80001b0e:	9e6ff0ef          	jal	80000cf4 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b12:	16848493          	addi	s1,s1,360
    80001b16:	ff2496e3          	bne	s1,s2,80001b02 <allocproc+0x1c>
  return 0;
    80001b1a:	4481                	li	s1,0
    80001b1c:	a089                	j	80001b5e <allocproc+0x78>
  p->pid = allocpid();
    80001b1e:	e73ff0ef          	jal	80001990 <allocpid>
    80001b22:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001b24:	4785                	li	a5,1
    80001b26:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001b28:	858ff0ef          	jal	80000b80 <kalloc>
    80001b2c:	892a                	mv	s2,a0
    80001b2e:	eca8                	sd	a0,88(s1)
    80001b30:	cd15                	beqz	a0,80001b6c <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    80001b32:	8526                	mv	a0,s1
    80001b34:	e9bff0ef          	jal	800019ce <proc_pagetable>
    80001b38:	892a                	mv	s2,a0
    80001b3a:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001b3c:	c121                	beqz	a0,80001b7c <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80001b3e:	07000613          	li	a2,112
    80001b42:	4581                	li	a1,0
    80001b44:	06048513          	addi	a0,s1,96
    80001b48:	9e8ff0ef          	jal	80000d30 <memset>
  p->context.ra = (uint64)forkret;
    80001b4c:	00000797          	auipc	a5,0x0
    80001b50:	e0a78793          	addi	a5,a5,-502 # 80001956 <forkret>
    80001b54:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001b56:	60bc                	ld	a5,64(s1)
    80001b58:	6705                	lui	a4,0x1
    80001b5a:	97ba                	add	a5,a5,a4
    80001b5c:	f4bc                	sd	a5,104(s1)
}
    80001b5e:	8526                	mv	a0,s1
    80001b60:	60e2                	ld	ra,24(sp)
    80001b62:	6442                	ld	s0,16(sp)
    80001b64:	64a2                	ld	s1,8(sp)
    80001b66:	6902                	ld	s2,0(sp)
    80001b68:	6105                	addi	sp,sp,32
    80001b6a:	8082                	ret
    freeproc(p);
    80001b6c:	8526                	mv	a0,s1
    80001b6e:	f29ff0ef          	jal	80001a96 <freeproc>
    release(&p->lock);
    80001b72:	8526                	mv	a0,s1
    80001b74:	980ff0ef          	jal	80000cf4 <release>
    return 0;
    80001b78:	84ca                	mv	s1,s2
    80001b7a:	b7d5                	j	80001b5e <allocproc+0x78>
    freeproc(p);
    80001b7c:	8526                	mv	a0,s1
    80001b7e:	f19ff0ef          	jal	80001a96 <freeproc>
    release(&p->lock);
    80001b82:	8526                	mv	a0,s1
    80001b84:	970ff0ef          	jal	80000cf4 <release>
    return 0;
    80001b88:	84ca                	mv	s1,s2
    80001b8a:	bfd1                	j	80001b5e <allocproc+0x78>

0000000080001b8c <userinit>:
{
    80001b8c:	1101                	addi	sp,sp,-32
    80001b8e:	ec06                	sd	ra,24(sp)
    80001b90:	e822                	sd	s0,16(sp)
    80001b92:	e426                	sd	s1,8(sp)
    80001b94:	1000                	addi	s0,sp,32
  p = allocproc();
    80001b96:	f51ff0ef          	jal	80001ae6 <allocproc>
    80001b9a:	84aa                	mv	s1,a0
  initproc = p;
    80001b9c:	00006797          	auipc	a5,0x6
    80001ba0:	d6a7b623          	sd	a0,-660(a5) # 80007908 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80001ba4:	03400613          	li	a2,52
    80001ba8:	00006597          	auipc	a1,0x6
    80001bac:	cf858593          	addi	a1,a1,-776 # 800078a0 <initcode>
    80001bb0:	6928                	ld	a0,80(a0)
    80001bb2:	f58ff0ef          	jal	8000130a <uvmfirst>
  p->sz = PGSIZE;
    80001bb6:	6785                	lui	a5,0x1
    80001bb8:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    80001bba:	6cb8                	ld	a4,88(s1)
    80001bbc:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    80001bc0:	6cb8                	ld	a4,88(s1)
    80001bc2:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    80001bc4:	4641                	li	a2,16
    80001bc6:	00005597          	auipc	a1,0x5
    80001bca:	65a58593          	addi	a1,a1,1626 # 80007220 <etext+0x220>
    80001bce:	15848513          	addi	a0,s1,344
    80001bd2:	aa8ff0ef          	jal	80000e7a <safestrcpy>
  p->cwd = namei("/");
    80001bd6:	00005517          	auipc	a0,0x5
    80001bda:	65a50513          	addi	a0,a0,1626 # 80007230 <etext+0x230>
    80001bde:	525010ef          	jal	80003902 <namei>
    80001be2:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001be6:	478d                	li	a5,3
    80001be8:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001bea:	8526                	mv	a0,s1
    80001bec:	908ff0ef          	jal	80000cf4 <release>
}
    80001bf0:	60e2                	ld	ra,24(sp)
    80001bf2:	6442                	ld	s0,16(sp)
    80001bf4:	64a2                	ld	s1,8(sp)
    80001bf6:	6105                	addi	sp,sp,32
    80001bf8:	8082                	ret

0000000080001bfa <growproc>:
{
    80001bfa:	1101                	addi	sp,sp,-32
    80001bfc:	ec06                	sd	ra,24(sp)
    80001bfe:	e822                	sd	s0,16(sp)
    80001c00:	e426                	sd	s1,8(sp)
    80001c02:	e04a                	sd	s2,0(sp)
    80001c04:	1000                	addi	s0,sp,32
    80001c06:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001c08:	d1dff0ef          	jal	80001924 <myproc>
    80001c0c:	84aa                	mv	s1,a0
  sz = p->sz;
    80001c0e:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001c10:	01204c63          	bgtz	s2,80001c28 <growproc+0x2e>
  } else if(n < 0){
    80001c14:	02094463          	bltz	s2,80001c3c <growproc+0x42>
  p->sz = sz;
    80001c18:	e4ac                	sd	a1,72(s1)
  return 0;
    80001c1a:	4501                	li	a0,0
}
    80001c1c:	60e2                	ld	ra,24(sp)
    80001c1e:	6442                	ld	s0,16(sp)
    80001c20:	64a2                	ld	s1,8(sp)
    80001c22:	6902                	ld	s2,0(sp)
    80001c24:	6105                	addi	sp,sp,32
    80001c26:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001c28:	4691                	li	a3,4
    80001c2a:	00b90633          	add	a2,s2,a1
    80001c2e:	6928                	ld	a0,80(a0)
    80001c30:	f7eff0ef          	jal	800013ae <uvmalloc>
    80001c34:	85aa                	mv	a1,a0
    80001c36:	f16d                	bnez	a0,80001c18 <growproc+0x1e>
      return -1;
    80001c38:	557d                	li	a0,-1
    80001c3a:	b7cd                	j	80001c1c <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001c3c:	00b90633          	add	a2,s2,a1
    80001c40:	6928                	ld	a0,80(a0)
    80001c42:	f26ff0ef          	jal	80001368 <uvmdealloc>
    80001c46:	85aa                	mv	a1,a0
    80001c48:	bfc1                	j	80001c18 <growproc+0x1e>

0000000080001c4a <fork>:
{
    80001c4a:	7139                	addi	sp,sp,-64
    80001c4c:	fc06                	sd	ra,56(sp)
    80001c4e:	f822                	sd	s0,48(sp)
    80001c50:	f426                	sd	s1,40(sp)
    80001c52:	e456                	sd	s5,8(sp)
    80001c54:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c56:	ccfff0ef          	jal	80001924 <myproc>
    80001c5a:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001c5c:	e8bff0ef          	jal	80001ae6 <allocproc>
    80001c60:	c92d                	beqz	a0,80001cd2 <fork+0x88>
    80001c62:	e852                	sd	s4,16(sp)
    80001c64:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001c66:	048ab603          	ld	a2,72(s5)
    80001c6a:	692c                	ld	a1,80(a0)
    80001c6c:	050ab503          	ld	a0,80(s5)
    80001c70:	86dff0ef          	jal	800014dc <uvmcopy>
    80001c74:	04054863          	bltz	a0,80001cc4 <fork+0x7a>
    80001c78:	f04a                	sd	s2,32(sp)
    80001c7a:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001c7c:	048ab783          	ld	a5,72(s5)
    80001c80:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001c84:	058ab683          	ld	a3,88(s5)
    80001c88:	87b6                	mv	a5,a3
    80001c8a:	058a3703          	ld	a4,88(s4)
    80001c8e:	12068693          	addi	a3,a3,288
    80001c92:	6388                	ld	a0,0(a5)
    80001c94:	678c                	ld	a1,8(a5)
    80001c96:	6b90                	ld	a2,16(a5)
    80001c98:	e308                	sd	a0,0(a4)
    80001c9a:	e70c                	sd	a1,8(a4)
    80001c9c:	eb10                	sd	a2,16(a4)
    80001c9e:	6f90                	ld	a2,24(a5)
    80001ca0:	ef10                	sd	a2,24(a4)
    80001ca2:	02078793          	addi	a5,a5,32 # 1020 <_entry-0x7fffefe0>
    80001ca6:	02070713          	addi	a4,a4,32
    80001caa:	fed794e3          	bne	a5,a3,80001c92 <fork+0x48>
  np->trapframe->a0 = 0;
    80001cae:	058a3783          	ld	a5,88(s4)
    80001cb2:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001cb6:	0d0a8493          	addi	s1,s5,208
    80001cba:	0d0a0913          	addi	s2,s4,208
    80001cbe:	150a8993          	addi	s3,s5,336
    80001cc2:	a831                	j	80001cde <fork+0x94>
    freeproc(np);
    80001cc4:	8552                	mv	a0,s4
    80001cc6:	dd1ff0ef          	jal	80001a96 <freeproc>
    release(&np->lock);
    80001cca:	8552                	mv	a0,s4
    80001ccc:	828ff0ef          	jal	80000cf4 <release>
    return -1;
    80001cd0:	6a42                	ld	s4,16(sp)
    return -1;
    80001cd2:	54fd                	li	s1,-1
    80001cd4:	a885                	j	80001d44 <fork+0xfa>
  for(i = 0; i < NOFILE; i++)
    80001cd6:	04a1                	addi	s1,s1,8
    80001cd8:	0921                	addi	s2,s2,8
    80001cda:	01348963          	beq	s1,s3,80001cec <fork+0xa2>
    if(p->ofile[i])
    80001cde:	6088                	ld	a0,0(s1)
    80001ce0:	d97d                	beqz	a0,80001cd6 <fork+0x8c>
      np->ofile[i] = filedup(p->ofile[i]);
    80001ce2:	1ca020ef          	jal	80003eac <filedup>
    80001ce6:	00a93023          	sd	a0,0(s2)
    80001cea:	b7f5                	j	80001cd6 <fork+0x8c>
  np->cwd = idup(p->cwd);
    80001cec:	150ab503          	ld	a0,336(s5)
    80001cf0:	4dc010ef          	jal	800031cc <idup>
    80001cf4:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001cf8:	4641                	li	a2,16
    80001cfa:	158a8593          	addi	a1,s5,344
    80001cfe:	158a0513          	addi	a0,s4,344
    80001d02:	978ff0ef          	jal	80000e7a <safestrcpy>
  pid = np->pid;
    80001d06:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    80001d0a:	8552                	mv	a0,s4
    80001d0c:	fe9fe0ef          	jal	80000cf4 <release>
  acquire(&wait_lock);
    80001d10:	0000e517          	auipc	a0,0xe
    80001d14:	d4850513          	addi	a0,a0,-696 # 8000fa58 <wait_lock>
    80001d18:	f4dfe0ef          	jal	80000c64 <acquire>
  np->parent = p;
    80001d1c:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001d20:	0000e517          	auipc	a0,0xe
    80001d24:	d3850513          	addi	a0,a0,-712 # 8000fa58 <wait_lock>
    80001d28:	fcdfe0ef          	jal	80000cf4 <release>
  acquire(&np->lock);
    80001d2c:	8552                	mv	a0,s4
    80001d2e:	f37fe0ef          	jal	80000c64 <acquire>
  np->state = RUNNABLE;
    80001d32:	478d                	li	a5,3
    80001d34:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001d38:	8552                	mv	a0,s4
    80001d3a:	fbbfe0ef          	jal	80000cf4 <release>
    80001d3e:	7902                	ld	s2,32(sp)
    80001d40:	69e2                	ld	s3,24(sp)
    80001d42:	6a42                	ld	s4,16(sp)
}
    80001d44:	8526                	mv	a0,s1
    80001d46:	70e2                	ld	ra,56(sp)
    80001d48:	7442                	ld	s0,48(sp)
    80001d4a:	74a2                	ld	s1,40(sp)
    80001d4c:	6aa2                	ld	s5,8(sp)
    80001d4e:	6121                	addi	sp,sp,64
    80001d50:	8082                	ret

0000000080001d52 <scheduler>:
{
    80001d52:	715d                	addi	sp,sp,-80
    80001d54:	e486                	sd	ra,72(sp)
    80001d56:	e0a2                	sd	s0,64(sp)
    80001d58:	fc26                	sd	s1,56(sp)
    80001d5a:	f84a                	sd	s2,48(sp)
    80001d5c:	f44e                	sd	s3,40(sp)
    80001d5e:	f052                	sd	s4,32(sp)
    80001d60:	ec56                	sd	s5,24(sp)
    80001d62:	e85a                	sd	s6,16(sp)
    80001d64:	e45e                	sd	s7,8(sp)
    80001d66:	e062                	sd	s8,0(sp)
    80001d68:	0880                	addi	s0,sp,80
    80001d6a:	8792                	mv	a5,tp
  int id = r_tp();
    80001d6c:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001d6e:	00779693          	slli	a3,a5,0x7
    80001d72:	0000e717          	auipc	a4,0xe
    80001d76:	cce70713          	addi	a4,a4,-818 # 8000fa40 <pid_lock>
    80001d7a:	9736                	add	a4,a4,a3
    80001d7c:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001d80:	0000eb17          	auipc	s6,0xe
    80001d84:	cf8b0b13          	addi	s6,s6,-776 # 8000fa78 <cpus+0x8>
    80001d88:	9b36                	add	s6,s6,a3
        p->state = RUNNING;
    80001d8a:	4c11                	li	s8,4
        c->proc = p;
    80001d8c:	8a3a                	mv	s4,a4
        found = 1;
    80001d8e:	4b85                	li	s7,1
    80001d90:	a83d                	j	80001dce <scheduler+0x7c>
      release(&p->lock);
    80001d92:	8526                	mv	a0,s1
    80001d94:	f61fe0ef          	jal	80000cf4 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001d98:	16848493          	addi	s1,s1,360
    80001d9c:	03248563          	beq	s1,s2,80001dc6 <scheduler+0x74>
      acquire(&p->lock);
    80001da0:	8526                	mv	a0,s1
    80001da2:	ec3fe0ef          	jal	80000c64 <acquire>
      if(p->state == RUNNABLE) {
    80001da6:	4c9c                	lw	a5,24(s1)
    80001da8:	ff3795e3          	bne	a5,s3,80001d92 <scheduler+0x40>
        p->state = RUNNING;
    80001dac:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001db0:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001db4:	06048593          	addi	a1,s1,96
    80001db8:	855a                	mv	a0,s6
    80001dba:	5e6000ef          	jal	800023a0 <swtch>
        c->proc = 0;
    80001dbe:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001dc2:	8ade                	mv	s5,s7
    80001dc4:	b7f9                	j	80001d92 <scheduler+0x40>
    if(found == 0) {
    80001dc6:	000a9463          	bnez	s5,80001dce <scheduler+0x7c>
      asm volatile("wfi");
    80001dca:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001dce:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001dd2:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001dd6:	10079073          	csrw	sstatus,a5
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001dda:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001dde:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001de0:	10079073          	csrw	sstatus,a5
    int found = 0;
    80001de4:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001de6:	0000e497          	auipc	s1,0xe
    80001dea:	08a48493          	addi	s1,s1,138 # 8000fe70 <proc>
      if(p->state == RUNNABLE) {
    80001dee:	498d                	li	s3,3
    for(p = proc; p < &proc[NPROC]; p++) {
    80001df0:	00014917          	auipc	s2,0x14
    80001df4:	a8090913          	addi	s2,s2,-1408 # 80015870 <tickslock>
    80001df8:	b765                	j	80001da0 <scheduler+0x4e>

0000000080001dfa <sched>:
{
    80001dfa:	7179                	addi	sp,sp,-48
    80001dfc:	f406                	sd	ra,40(sp)
    80001dfe:	f022                	sd	s0,32(sp)
    80001e00:	ec26                	sd	s1,24(sp)
    80001e02:	e84a                	sd	s2,16(sp)
    80001e04:	e44e                	sd	s3,8(sp)
    80001e06:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001e08:	b1dff0ef          	jal	80001924 <myproc>
    80001e0c:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001e0e:	de7fe0ef          	jal	80000bf4 <holding>
    80001e12:	c92d                	beqz	a0,80001e84 <sched+0x8a>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e14:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001e16:	2781                	sext.w	a5,a5
    80001e18:	079e                	slli	a5,a5,0x7
    80001e1a:	0000e717          	auipc	a4,0xe
    80001e1e:	c2670713          	addi	a4,a4,-986 # 8000fa40 <pid_lock>
    80001e22:	97ba                	add	a5,a5,a4
    80001e24:	0a87a703          	lw	a4,168(a5)
    80001e28:	4785                	li	a5,1
    80001e2a:	06f71363          	bne	a4,a5,80001e90 <sched+0x96>
  if(p->state == RUNNING)
    80001e2e:	4c98                	lw	a4,24(s1)
    80001e30:	4791                	li	a5,4
    80001e32:	06f70563          	beq	a4,a5,80001e9c <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e36:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001e3a:	8b89                	andi	a5,a5,2
  if(intr_get())
    80001e3c:	e7b5                	bnez	a5,80001ea8 <sched+0xae>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e3e:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001e40:	0000e917          	auipc	s2,0xe
    80001e44:	c0090913          	addi	s2,s2,-1024 # 8000fa40 <pid_lock>
    80001e48:	2781                	sext.w	a5,a5
    80001e4a:	079e                	slli	a5,a5,0x7
    80001e4c:	97ca                	add	a5,a5,s2
    80001e4e:	0ac7a983          	lw	s3,172(a5)
    80001e52:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001e54:	2781                	sext.w	a5,a5
    80001e56:	079e                	slli	a5,a5,0x7
    80001e58:	0000e597          	auipc	a1,0xe
    80001e5c:	c2058593          	addi	a1,a1,-992 # 8000fa78 <cpus+0x8>
    80001e60:	95be                	add	a1,a1,a5
    80001e62:	06048513          	addi	a0,s1,96
    80001e66:	53a000ef          	jal	800023a0 <swtch>
    80001e6a:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001e6c:	2781                	sext.w	a5,a5
    80001e6e:	079e                	slli	a5,a5,0x7
    80001e70:	993e                	add	s2,s2,a5
    80001e72:	0b392623          	sw	s3,172(s2)
}
    80001e76:	70a2                	ld	ra,40(sp)
    80001e78:	7402                	ld	s0,32(sp)
    80001e7a:	64e2                	ld	s1,24(sp)
    80001e7c:	6942                	ld	s2,16(sp)
    80001e7e:	69a2                	ld	s3,8(sp)
    80001e80:	6145                	addi	sp,sp,48
    80001e82:	8082                	ret
    panic("sched p->lock");
    80001e84:	00005517          	auipc	a0,0x5
    80001e88:	3b450513          	addi	a0,a0,948 # 80007238 <etext+0x238>
    80001e8c:	965fe0ef          	jal	800007f0 <panic>
    panic("sched locks");
    80001e90:	00005517          	auipc	a0,0x5
    80001e94:	3b850513          	addi	a0,a0,952 # 80007248 <etext+0x248>
    80001e98:	959fe0ef          	jal	800007f0 <panic>
    panic("sched RUNNING");
    80001e9c:	00005517          	auipc	a0,0x5
    80001ea0:	3bc50513          	addi	a0,a0,956 # 80007258 <etext+0x258>
    80001ea4:	94dfe0ef          	jal	800007f0 <panic>
    panic("sched interruptible");
    80001ea8:	00005517          	auipc	a0,0x5
    80001eac:	3c050513          	addi	a0,a0,960 # 80007268 <etext+0x268>
    80001eb0:	941fe0ef          	jal	800007f0 <panic>

0000000080001eb4 <yield>:
{
    80001eb4:	1101                	addi	sp,sp,-32
    80001eb6:	ec06                	sd	ra,24(sp)
    80001eb8:	e822                	sd	s0,16(sp)
    80001eba:	e426                	sd	s1,8(sp)
    80001ebc:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001ebe:	a67ff0ef          	jal	80001924 <myproc>
    80001ec2:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001ec4:	da1fe0ef          	jal	80000c64 <acquire>
  p->state = RUNNABLE;
    80001ec8:	478d                	li	a5,3
    80001eca:	cc9c                	sw	a5,24(s1)
  sched();
    80001ecc:	f2fff0ef          	jal	80001dfa <sched>
  release(&p->lock);
    80001ed0:	8526                	mv	a0,s1
    80001ed2:	e23fe0ef          	jal	80000cf4 <release>
}
    80001ed6:	60e2                	ld	ra,24(sp)
    80001ed8:	6442                	ld	s0,16(sp)
    80001eda:	64a2                	ld	s1,8(sp)
    80001edc:	6105                	addi	sp,sp,32
    80001ede:	8082                	ret

0000000080001ee0 <sleep>:

// Sleep on wait channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001ee0:	7179                	addi	sp,sp,-48
    80001ee2:	f406                	sd	ra,40(sp)
    80001ee4:	f022                	sd	s0,32(sp)
    80001ee6:	ec26                	sd	s1,24(sp)
    80001ee8:	e84a                	sd	s2,16(sp)
    80001eea:	e44e                	sd	s3,8(sp)
    80001eec:	1800                	addi	s0,sp,48
    80001eee:	89aa                	mv	s3,a0
    80001ef0:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001ef2:	a33ff0ef          	jal	80001924 <myproc>
    80001ef6:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80001ef8:	d6dfe0ef          	jal	80000c64 <acquire>
  release(lk);
    80001efc:	854a                	mv	a0,s2
    80001efe:	df7fe0ef          	jal	80000cf4 <release>

  // Go to sleep.
  p->chan = chan;
    80001f02:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80001f06:	4789                	li	a5,2
    80001f08:	cc9c                	sw	a5,24(s1)

  sched();
    80001f0a:	ef1ff0ef          	jal	80001dfa <sched>

  // Tidy up.
  p->chan = 0;
    80001f0e:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80001f12:	8526                	mv	a0,s1
    80001f14:	de1fe0ef          	jal	80000cf4 <release>
  acquire(lk);
    80001f18:	854a                	mv	a0,s2
    80001f1a:	d4bfe0ef          	jal	80000c64 <acquire>
}
    80001f1e:	70a2                	ld	ra,40(sp)
    80001f20:	7402                	ld	s0,32(sp)
    80001f22:	64e2                	ld	s1,24(sp)
    80001f24:	6942                	ld	s2,16(sp)
    80001f26:	69a2                	ld	s3,8(sp)
    80001f28:	6145                	addi	sp,sp,48
    80001f2a:	8082                	ret

0000000080001f2c <wakeup>:

// Wake up all processes sleeping on wait channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    80001f2c:	7139                	addi	sp,sp,-64
    80001f2e:	fc06                	sd	ra,56(sp)
    80001f30:	f822                	sd	s0,48(sp)
    80001f32:	f426                	sd	s1,40(sp)
    80001f34:	f04a                	sd	s2,32(sp)
    80001f36:	ec4e                	sd	s3,24(sp)
    80001f38:	e852                	sd	s4,16(sp)
    80001f3a:	e456                	sd	s5,8(sp)
    80001f3c:	0080                	addi	s0,sp,64
    80001f3e:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80001f40:	0000e497          	auipc	s1,0xe
    80001f44:	f3048493          	addi	s1,s1,-208 # 8000fe70 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80001f48:	4989                	li	s3,2
        p->state = RUNNABLE;
    80001f4a:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    80001f4c:	00014917          	auipc	s2,0x14
    80001f50:	92490913          	addi	s2,s2,-1756 # 80015870 <tickslock>
    80001f54:	a801                	j	80001f64 <wakeup+0x38>
      }
      release(&p->lock);
    80001f56:	8526                	mv	a0,s1
    80001f58:	d9dfe0ef          	jal	80000cf4 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001f5c:	16848493          	addi	s1,s1,360
    80001f60:	03248263          	beq	s1,s2,80001f84 <wakeup+0x58>
    if(p != myproc()){
    80001f64:	9c1ff0ef          	jal	80001924 <myproc>
    80001f68:	fe950ae3          	beq	a0,s1,80001f5c <wakeup+0x30>
      acquire(&p->lock);
    80001f6c:	8526                	mv	a0,s1
    80001f6e:	cf7fe0ef          	jal	80000c64 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80001f72:	4c9c                	lw	a5,24(s1)
    80001f74:	ff3791e3          	bne	a5,s3,80001f56 <wakeup+0x2a>
    80001f78:	709c                	ld	a5,32(s1)
    80001f7a:	fd479ee3          	bne	a5,s4,80001f56 <wakeup+0x2a>
        p->state = RUNNABLE;
    80001f7e:	0154ac23          	sw	s5,24(s1)
    80001f82:	bfd1                	j	80001f56 <wakeup+0x2a>
    }
  }
}
    80001f84:	70e2                	ld	ra,56(sp)
    80001f86:	7442                	ld	s0,48(sp)
    80001f88:	74a2                	ld	s1,40(sp)
    80001f8a:	7902                	ld	s2,32(sp)
    80001f8c:	69e2                	ld	s3,24(sp)
    80001f8e:	6a42                	ld	s4,16(sp)
    80001f90:	6aa2                	ld	s5,8(sp)
    80001f92:	6121                	addi	sp,sp,64
    80001f94:	8082                	ret

0000000080001f96 <reparent>:
{
    80001f96:	7179                	addi	sp,sp,-48
    80001f98:	f406                	sd	ra,40(sp)
    80001f9a:	f022                	sd	s0,32(sp)
    80001f9c:	ec26                	sd	s1,24(sp)
    80001f9e:	e84a                	sd	s2,16(sp)
    80001fa0:	e44e                	sd	s3,8(sp)
    80001fa2:	e052                	sd	s4,0(sp)
    80001fa4:	1800                	addi	s0,sp,48
    80001fa6:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001fa8:	0000e497          	auipc	s1,0xe
    80001fac:	ec848493          	addi	s1,s1,-312 # 8000fe70 <proc>
      pp->parent = initproc;
    80001fb0:	00006a17          	auipc	s4,0x6
    80001fb4:	958a0a13          	addi	s4,s4,-1704 # 80007908 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001fb8:	00014997          	auipc	s3,0x14
    80001fbc:	8b898993          	addi	s3,s3,-1864 # 80015870 <tickslock>
    80001fc0:	a029                	j	80001fca <reparent+0x34>
    80001fc2:	16848493          	addi	s1,s1,360
    80001fc6:	01348b63          	beq	s1,s3,80001fdc <reparent+0x46>
    if(pp->parent == p){
    80001fca:	7c9c                	ld	a5,56(s1)
    80001fcc:	ff279be3          	bne	a5,s2,80001fc2 <reparent+0x2c>
      pp->parent = initproc;
    80001fd0:	000a3503          	ld	a0,0(s4)
    80001fd4:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80001fd6:	f57ff0ef          	jal	80001f2c <wakeup>
    80001fda:	b7e5                	j	80001fc2 <reparent+0x2c>
}
    80001fdc:	70a2                	ld	ra,40(sp)
    80001fde:	7402                	ld	s0,32(sp)
    80001fe0:	64e2                	ld	s1,24(sp)
    80001fe2:	6942                	ld	s2,16(sp)
    80001fe4:	69a2                	ld	s3,8(sp)
    80001fe6:	6a02                	ld	s4,0(sp)
    80001fe8:	6145                	addi	sp,sp,48
    80001fea:	8082                	ret

0000000080001fec <exit>:
{
    80001fec:	7179                	addi	sp,sp,-48
    80001fee:	f406                	sd	ra,40(sp)
    80001ff0:	f022                	sd	s0,32(sp)
    80001ff2:	ec26                	sd	s1,24(sp)
    80001ff4:	e84a                	sd	s2,16(sp)
    80001ff6:	e44e                	sd	s3,8(sp)
    80001ff8:	e052                	sd	s4,0(sp)
    80001ffa:	1800                	addi	s0,sp,48
    80001ffc:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80001ffe:	927ff0ef          	jal	80001924 <myproc>
    80002002:	89aa                	mv	s3,a0
  if(p == initproc)
    80002004:	00006797          	auipc	a5,0x6
    80002008:	9047b783          	ld	a5,-1788(a5) # 80007908 <initproc>
    8000200c:	0d050493          	addi	s1,a0,208
    80002010:	15050913          	addi	s2,a0,336
    80002014:	00a79b63          	bne	a5,a0,8000202a <exit+0x3e>
    panic("init exiting");
    80002018:	00005517          	auipc	a0,0x5
    8000201c:	26850513          	addi	a0,a0,616 # 80007280 <etext+0x280>
    80002020:	fd0fe0ef          	jal	800007f0 <panic>
  for(int fd = 0; fd < NOFILE; fd++){
    80002024:	04a1                	addi	s1,s1,8
    80002026:	01248963          	beq	s1,s2,80002038 <exit+0x4c>
    if(p->ofile[fd]){
    8000202a:	6088                	ld	a0,0(s1)
    8000202c:	dd65                	beqz	a0,80002024 <exit+0x38>
      fileclose(f);
    8000202e:	6c5010ef          	jal	80003ef2 <fileclose>
      p->ofile[fd] = 0;
    80002032:	0004b023          	sd	zero,0(s1)
    80002036:	b7fd                	j	80002024 <exit+0x38>
  begin_op();
    80002038:	28d010ef          	jal	80003ac4 <begin_op>
  iput(p->cwd);
    8000203c:	1509b503          	ld	a0,336(s3)
    80002040:	344010ef          	jal	80003384 <iput>
  end_op();
    80002044:	2f1010ef          	jal	80003b34 <end_op>
  p->cwd = 0;
    80002048:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    8000204c:	0000e517          	auipc	a0,0xe
    80002050:	a0c50513          	addi	a0,a0,-1524 # 8000fa58 <wait_lock>
    80002054:	c11fe0ef          	jal	80000c64 <acquire>
  reparent(p);
    80002058:	854e                	mv	a0,s3
    8000205a:	f3dff0ef          	jal	80001f96 <reparent>
  wakeup(p->parent);
    8000205e:	0389b503          	ld	a0,56(s3)
    80002062:	ecbff0ef          	jal	80001f2c <wakeup>
  acquire(&p->lock);
    80002066:	854e                	mv	a0,s3
    80002068:	bfdfe0ef          	jal	80000c64 <acquire>
  p->xstate = status;
    8000206c:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    80002070:	4795                	li	a5,5
    80002072:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    80002076:	0000e517          	auipc	a0,0xe
    8000207a:	9e250513          	addi	a0,a0,-1566 # 8000fa58 <wait_lock>
    8000207e:	c77fe0ef          	jal	80000cf4 <release>
  sched();
    80002082:	d79ff0ef          	jal	80001dfa <sched>
  panic("zombie exit");
    80002086:	00005517          	auipc	a0,0x5
    8000208a:	20a50513          	addi	a0,a0,522 # 80007290 <etext+0x290>
    8000208e:	f62fe0ef          	jal	800007f0 <panic>

0000000080002092 <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    80002092:	7179                	addi	sp,sp,-48
    80002094:	f406                	sd	ra,40(sp)
    80002096:	f022                	sd	s0,32(sp)
    80002098:	ec26                	sd	s1,24(sp)
    8000209a:	e84a                	sd	s2,16(sp)
    8000209c:	e44e                	sd	s3,8(sp)
    8000209e:	1800                	addi	s0,sp,48
    800020a0:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    800020a2:	0000e497          	auipc	s1,0xe
    800020a6:	dce48493          	addi	s1,s1,-562 # 8000fe70 <proc>
    800020aa:	00013997          	auipc	s3,0x13
    800020ae:	7c698993          	addi	s3,s3,1990 # 80015870 <tickslock>
    acquire(&p->lock);
    800020b2:	8526                	mv	a0,s1
    800020b4:	bb1fe0ef          	jal	80000c64 <acquire>
    if(p->pid == pid){
    800020b8:	589c                	lw	a5,48(s1)
    800020ba:	01278b63          	beq	a5,s2,800020d0 <kill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    800020be:	8526                	mv	a0,s1
    800020c0:	c35fe0ef          	jal	80000cf4 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    800020c4:	16848493          	addi	s1,s1,360
    800020c8:	ff3495e3          	bne	s1,s3,800020b2 <kill+0x20>
  }
  return -1;
    800020cc:	557d                	li	a0,-1
    800020ce:	a819                	j	800020e4 <kill+0x52>
      p->killed = 1;
    800020d0:	4785                	li	a5,1
    800020d2:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    800020d4:	4c98                	lw	a4,24(s1)
    800020d6:	4789                	li	a5,2
    800020d8:	00f70d63          	beq	a4,a5,800020f2 <kill+0x60>
      release(&p->lock);
    800020dc:	8526                	mv	a0,s1
    800020de:	c17fe0ef          	jal	80000cf4 <release>
      return 0;
    800020e2:	4501                	li	a0,0
}
    800020e4:	70a2                	ld	ra,40(sp)
    800020e6:	7402                	ld	s0,32(sp)
    800020e8:	64e2                	ld	s1,24(sp)
    800020ea:	6942                	ld	s2,16(sp)
    800020ec:	69a2                	ld	s3,8(sp)
    800020ee:	6145                	addi	sp,sp,48
    800020f0:	8082                	ret
        p->state = RUNNABLE;
    800020f2:	478d                	li	a5,3
    800020f4:	cc9c                	sw	a5,24(s1)
    800020f6:	b7dd                	j	800020dc <kill+0x4a>

00000000800020f8 <setkilled>:

void
setkilled(struct proc *p)
{
    800020f8:	1101                	addi	sp,sp,-32
    800020fa:	ec06                	sd	ra,24(sp)
    800020fc:	e822                	sd	s0,16(sp)
    800020fe:	e426                	sd	s1,8(sp)
    80002100:	1000                	addi	s0,sp,32
    80002102:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002104:	b61fe0ef          	jal	80000c64 <acquire>
  p->killed = 1;
    80002108:	4785                	li	a5,1
    8000210a:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    8000210c:	8526                	mv	a0,s1
    8000210e:	be7fe0ef          	jal	80000cf4 <release>
}
    80002112:	60e2                	ld	ra,24(sp)
    80002114:	6442                	ld	s0,16(sp)
    80002116:	64a2                	ld	s1,8(sp)
    80002118:	6105                	addi	sp,sp,32
    8000211a:	8082                	ret

000000008000211c <killed>:

int
killed(struct proc *p)
{
    8000211c:	1101                	addi	sp,sp,-32
    8000211e:	ec06                	sd	ra,24(sp)
    80002120:	e822                	sd	s0,16(sp)
    80002122:	e426                	sd	s1,8(sp)
    80002124:	e04a                	sd	s2,0(sp)
    80002126:	1000                	addi	s0,sp,32
    80002128:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    8000212a:	b3bfe0ef          	jal	80000c64 <acquire>
  k = p->killed;
    8000212e:	549c                	lw	a5,40(s1)
    80002130:	893e                	mv	s2,a5
  release(&p->lock);
    80002132:	8526                	mv	a0,s1
    80002134:	bc1fe0ef          	jal	80000cf4 <release>
  return k;
}
    80002138:	854a                	mv	a0,s2
    8000213a:	60e2                	ld	ra,24(sp)
    8000213c:	6442                	ld	s0,16(sp)
    8000213e:	64a2                	ld	s1,8(sp)
    80002140:	6902                	ld	s2,0(sp)
    80002142:	6105                	addi	sp,sp,32
    80002144:	8082                	ret

0000000080002146 <wait>:
{
    80002146:	715d                	addi	sp,sp,-80
    80002148:	e486                	sd	ra,72(sp)
    8000214a:	e0a2                	sd	s0,64(sp)
    8000214c:	fc26                	sd	s1,56(sp)
    8000214e:	f84a                	sd	s2,48(sp)
    80002150:	f44e                	sd	s3,40(sp)
    80002152:	f052                	sd	s4,32(sp)
    80002154:	ec56                	sd	s5,24(sp)
    80002156:	e85a                	sd	s6,16(sp)
    80002158:	e45e                	sd	s7,8(sp)
    8000215a:	0880                	addi	s0,sp,80
    8000215c:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    8000215e:	fc6ff0ef          	jal	80001924 <myproc>
    80002162:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80002164:	0000e517          	auipc	a0,0xe
    80002168:	8f450513          	addi	a0,a0,-1804 # 8000fa58 <wait_lock>
    8000216c:	af9fe0ef          	jal	80000c64 <acquire>
        if(pp->state == ZOMBIE){
    80002170:	4a15                	li	s4,5
        havekids = 1;
    80002172:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002174:	00013997          	auipc	s3,0x13
    80002178:	6fc98993          	addi	s3,s3,1788 # 80015870 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    8000217c:	0000eb17          	auipc	s6,0xe
    80002180:	8dcb0b13          	addi	s6,s6,-1828 # 8000fa58 <wait_lock>
    80002184:	a861                	j	8000221c <wait+0xd6>
          pid = pp->pid;
    80002186:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    8000218a:	000b8c63          	beqz	s7,800021a2 <wait+0x5c>
    8000218e:	4691                	li	a3,4
    80002190:	02c48613          	addi	a2,s1,44
    80002194:	85de                	mv	a1,s7
    80002196:	05093503          	ld	a0,80(s2)
    8000219a:	c1aff0ef          	jal	800015b4 <copyout>
    8000219e:	02054a63          	bltz	a0,800021d2 <wait+0x8c>
          freeproc(pp);
    800021a2:	8526                	mv	a0,s1
    800021a4:	8f3ff0ef          	jal	80001a96 <freeproc>
          release(&pp->lock);
    800021a8:	8526                	mv	a0,s1
    800021aa:	b4bfe0ef          	jal	80000cf4 <release>
          release(&wait_lock);
    800021ae:	0000e517          	auipc	a0,0xe
    800021b2:	8aa50513          	addi	a0,a0,-1878 # 8000fa58 <wait_lock>
    800021b6:	b3ffe0ef          	jal	80000cf4 <release>
}
    800021ba:	854e                	mv	a0,s3
    800021bc:	60a6                	ld	ra,72(sp)
    800021be:	6406                	ld	s0,64(sp)
    800021c0:	74e2                	ld	s1,56(sp)
    800021c2:	7942                	ld	s2,48(sp)
    800021c4:	79a2                	ld	s3,40(sp)
    800021c6:	7a02                	ld	s4,32(sp)
    800021c8:	6ae2                	ld	s5,24(sp)
    800021ca:	6b42                	ld	s6,16(sp)
    800021cc:	6ba2                	ld	s7,8(sp)
    800021ce:	6161                	addi	sp,sp,80
    800021d0:	8082                	ret
            release(&pp->lock);
    800021d2:	8526                	mv	a0,s1
    800021d4:	b21fe0ef          	jal	80000cf4 <release>
            release(&wait_lock);
    800021d8:	0000e517          	auipc	a0,0xe
    800021dc:	88050513          	addi	a0,a0,-1920 # 8000fa58 <wait_lock>
    800021e0:	b15fe0ef          	jal	80000cf4 <release>
            return -1;
    800021e4:	a881                	j	80002234 <wait+0xee>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800021e6:	16848493          	addi	s1,s1,360
    800021ea:	03348063          	beq	s1,s3,8000220a <wait+0xc4>
      if(pp->parent == p){
    800021ee:	7c9c                	ld	a5,56(s1)
    800021f0:	ff279be3          	bne	a5,s2,800021e6 <wait+0xa0>
        acquire(&pp->lock);
    800021f4:	8526                	mv	a0,s1
    800021f6:	a6ffe0ef          	jal	80000c64 <acquire>
        if(pp->state == ZOMBIE){
    800021fa:	4c9c                	lw	a5,24(s1)
    800021fc:	f94785e3          	beq	a5,s4,80002186 <wait+0x40>
        release(&pp->lock);
    80002200:	8526                	mv	a0,s1
    80002202:	af3fe0ef          	jal	80000cf4 <release>
        havekids = 1;
    80002206:	8756                	mv	a4,s5
    80002208:	bff9                	j	800021e6 <wait+0xa0>
    if(!havekids || killed(p)){
    8000220a:	cf19                	beqz	a4,80002228 <wait+0xe2>
    8000220c:	854a                	mv	a0,s2
    8000220e:	f0fff0ef          	jal	8000211c <killed>
    80002212:	e919                	bnez	a0,80002228 <wait+0xe2>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002214:	85da                	mv	a1,s6
    80002216:	854a                	mv	a0,s2
    80002218:	cc9ff0ef          	jal	80001ee0 <sleep>
    havekids = 0;
    8000221c:	4701                	li	a4,0
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000221e:	0000e497          	auipc	s1,0xe
    80002222:	c5248493          	addi	s1,s1,-942 # 8000fe70 <proc>
    80002226:	b7e1                	j	800021ee <wait+0xa8>
      release(&wait_lock);
    80002228:	0000e517          	auipc	a0,0xe
    8000222c:	83050513          	addi	a0,a0,-2000 # 8000fa58 <wait_lock>
    80002230:	ac5fe0ef          	jal	80000cf4 <release>
            return -1;
    80002234:	59fd                	li	s3,-1
    80002236:	b751                	j	800021ba <wait+0x74>

0000000080002238 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80002238:	7179                	addi	sp,sp,-48
    8000223a:	f406                	sd	ra,40(sp)
    8000223c:	f022                	sd	s0,32(sp)
    8000223e:	ec26                	sd	s1,24(sp)
    80002240:	e84a                	sd	s2,16(sp)
    80002242:	e44e                	sd	s3,8(sp)
    80002244:	e052                	sd	s4,0(sp)
    80002246:	1800                	addi	s0,sp,48
    80002248:	84aa                	mv	s1,a0
    8000224a:	8a2e                	mv	s4,a1
    8000224c:	89b2                	mv	s3,a2
    8000224e:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80002250:	ed4ff0ef          	jal	80001924 <myproc>
  if(user_dst){
    80002254:	cc99                	beqz	s1,80002272 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    80002256:	86ca                	mv	a3,s2
    80002258:	864e                	mv	a2,s3
    8000225a:	85d2                	mv	a1,s4
    8000225c:	6928                	ld	a0,80(a0)
    8000225e:	b56ff0ef          	jal	800015b4 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    80002262:	70a2                	ld	ra,40(sp)
    80002264:	7402                	ld	s0,32(sp)
    80002266:	64e2                	ld	s1,24(sp)
    80002268:	6942                	ld	s2,16(sp)
    8000226a:	69a2                	ld	s3,8(sp)
    8000226c:	6a02                	ld	s4,0(sp)
    8000226e:	6145                	addi	sp,sp,48
    80002270:	8082                	ret
    memmove((char *)dst, src, len);
    80002272:	0009061b          	sext.w	a2,s2
    80002276:	85ce                	mv	a1,s3
    80002278:	8552                	mv	a0,s4
    8000227a:	b13fe0ef          	jal	80000d8c <memmove>
    return 0;
    8000227e:	8526                	mv	a0,s1
    80002280:	b7cd                	j	80002262 <either_copyout+0x2a>

0000000080002282 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    80002282:	7179                	addi	sp,sp,-48
    80002284:	f406                	sd	ra,40(sp)
    80002286:	f022                	sd	s0,32(sp)
    80002288:	ec26                	sd	s1,24(sp)
    8000228a:	e84a                	sd	s2,16(sp)
    8000228c:	e44e                	sd	s3,8(sp)
    8000228e:	e052                	sd	s4,0(sp)
    80002290:	1800                	addi	s0,sp,48
    80002292:	8a2a                	mv	s4,a0
    80002294:	84ae                	mv	s1,a1
    80002296:	89b2                	mv	s3,a2
    80002298:	8936                	mv	s2,a3
  struct proc *p = myproc();
    8000229a:	e8aff0ef          	jal	80001924 <myproc>
  if(user_src){
    8000229e:	cc99                	beqz	s1,800022bc <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    800022a0:	86ca                	mv	a3,s2
    800022a2:	864e                	mv	a2,s3
    800022a4:	85d2                	mv	a1,s4
    800022a6:	6928                	ld	a0,80(a0)
    800022a8:	bbaff0ef          	jal	80001662 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    800022ac:	70a2                	ld	ra,40(sp)
    800022ae:	7402                	ld	s0,32(sp)
    800022b0:	64e2                	ld	s1,24(sp)
    800022b2:	6942                	ld	s2,16(sp)
    800022b4:	69a2                	ld	s3,8(sp)
    800022b6:	6a02                	ld	s4,0(sp)
    800022b8:	6145                	addi	sp,sp,48
    800022ba:	8082                	ret
    memmove(dst, (char*)src, len);
    800022bc:	0009061b          	sext.w	a2,s2
    800022c0:	85ce                	mv	a1,s3
    800022c2:	8552                	mv	a0,s4
    800022c4:	ac9fe0ef          	jal	80000d8c <memmove>
    return 0;
    800022c8:	8526                	mv	a0,s1
    800022ca:	b7cd                	j	800022ac <either_copyin+0x2a>

00000000800022cc <proccount>:
// Count process-table entries that are not UNUSED.
// Mirrors procdump()'s scan: no lock, so the count is a snapshot
// taken one entry at a time and may be stale immediately.
int
proccount(void)
{
    800022cc:	1141                	addi	sp,sp,-16
    800022ce:	e406                	sd	ra,8(sp)
    800022d0:	e022                	sd	s0,0(sp)
    800022d2:	0800                	addi	s0,sp,16
  struct proc *p;
  int n = 0;
    800022d4:	4501                	li	a0,0

  for(p = proc; p < &proc[NPROC]; p++){
    800022d6:	0000e797          	auipc	a5,0xe
    800022da:	b9a78793          	addi	a5,a5,-1126 # 8000fe70 <proc>
    800022de:	00013697          	auipc	a3,0x13
    800022e2:	59268693          	addi	a3,a3,1426 # 80015870 <tickslock>
    800022e6:	a029                	j	800022f0 <proccount+0x24>
    800022e8:	16878793          	addi	a5,a5,360
    800022ec:	00d78663          	beq	a5,a3,800022f8 <proccount+0x2c>
    if(p->state != UNUSED)
    800022f0:	4f98                	lw	a4,24(a5)
    800022f2:	db7d                	beqz	a4,800022e8 <proccount+0x1c>
      n++;
    800022f4:	2505                	addiw	a0,a0,1
    800022f6:	bfcd                	j	800022e8 <proccount+0x1c>
  }
  return n;
}
    800022f8:	60a2                	ld	ra,8(sp)
    800022fa:	6402                	ld	s0,0(sp)
    800022fc:	0141                	addi	sp,sp,16
    800022fe:	8082                	ret

0000000080002300 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80002300:	715d                	addi	sp,sp,-80
    80002302:	e486                	sd	ra,72(sp)
    80002304:	e0a2                	sd	s0,64(sp)
    80002306:	fc26                	sd	s1,56(sp)
    80002308:	f84a                	sd	s2,48(sp)
    8000230a:	f44e                	sd	s3,40(sp)
    8000230c:	f052                	sd	s4,32(sp)
    8000230e:	ec56                	sd	s5,24(sp)
    80002310:	e85a                	sd	s6,16(sp)
    80002312:	e45e                	sd	s7,8(sp)
    80002314:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    80002316:	00005517          	auipc	a0,0x5
    8000231a:	d6250513          	addi	a0,a0,-670 # 80007078 <etext+0x78>
    8000231e:	9b4fe0ef          	jal	800004d2 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002322:	0000e497          	auipc	s1,0xe
    80002326:	ca648493          	addi	s1,s1,-858 # 8000ffc8 <proc+0x158>
    8000232a:	00013917          	auipc	s2,0x13
    8000232e:	69e90913          	addi	s2,s2,1694 # 800159c8 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002332:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80002334:	00005a97          	auipc	s5,0x5
    80002338:	f6ca8a93          	addi	s5,s5,-148 # 800072a0 <etext+0x2a0>
    printf("%d %s %s", p->pid, state, p->name);
    8000233c:	00005a17          	auipc	s4,0x5
    80002340:	f6ca0a13          	addi	s4,s4,-148 # 800072a8 <etext+0x2a8>
    printf("\n");
    80002344:	00005997          	auipc	s3,0x5
    80002348:	d3498993          	addi	s3,s3,-716 # 80007078 <etext+0x78>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000234c:	00005b97          	auipc	s7,0x5
    80002350:	43cb8b93          	addi	s7,s7,1084 # 80007788 <states.0>
    80002354:	a829                	j	8000236e <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    80002356:	ed86a583          	lw	a1,-296(a3)
    8000235a:	8552                	mv	a0,s4
    8000235c:	976fe0ef          	jal	800004d2 <printf>
    printf("\n");
    80002360:	854e                	mv	a0,s3
    80002362:	970fe0ef          	jal	800004d2 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002366:	16848493          	addi	s1,s1,360
    8000236a:	03248063          	beq	s1,s2,8000238a <procdump+0x8a>
    if(p->state == UNUSED)
    8000236e:	86a6                	mv	a3,s1
    80002370:	ec04a783          	lw	a5,-320(s1)
    80002374:	dbed                	beqz	a5,80002366 <procdump+0x66>
      state = "???";
    80002376:	8656                	mv	a2,s5
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002378:	fcfb6fe3          	bltu	s6,a5,80002356 <procdump+0x56>
    8000237c:	02079713          	slli	a4,a5,0x20
    80002380:	01d75793          	srli	a5,a4,0x1d
    80002384:	97de                	add	a5,a5,s7
    80002386:	6390                	ld	a2,0(a5)
      state = states[p->state];
    80002388:	b7f9                	j	80002356 <procdump+0x56>
  }
}
    8000238a:	60a6                	ld	ra,72(sp)
    8000238c:	6406                	ld	s0,64(sp)
    8000238e:	74e2                	ld	s1,56(sp)
    80002390:	7942                	ld	s2,48(sp)
    80002392:	79a2                	ld	s3,40(sp)
    80002394:	7a02                	ld	s4,32(sp)
    80002396:	6ae2                	ld	s5,24(sp)
    80002398:	6b42                	ld	s6,16(sp)
    8000239a:	6ba2                	ld	s7,8(sp)
    8000239c:	6161                	addi	sp,sp,80
    8000239e:	8082                	ret

00000000800023a0 <swtch>:
    800023a0:	00153023          	sd	ra,0(a0)
    800023a4:	00253423          	sd	sp,8(a0)
    800023a8:	e900                	sd	s0,16(a0)
    800023aa:	ed04                	sd	s1,24(a0)
    800023ac:	03253023          	sd	s2,32(a0)
    800023b0:	03353423          	sd	s3,40(a0)
    800023b4:	03453823          	sd	s4,48(a0)
    800023b8:	03553c23          	sd	s5,56(a0)
    800023bc:	05653023          	sd	s6,64(a0)
    800023c0:	05753423          	sd	s7,72(a0)
    800023c4:	05853823          	sd	s8,80(a0)
    800023c8:	05953c23          	sd	s9,88(a0)
    800023cc:	07a53023          	sd	s10,96(a0)
    800023d0:	07b53423          	sd	s11,104(a0)
    800023d4:	0005b083          	ld	ra,0(a1)
    800023d8:	0085b103          	ld	sp,8(a1)
    800023dc:	6980                	ld	s0,16(a1)
    800023de:	6d84                	ld	s1,24(a1)
    800023e0:	0205b903          	ld	s2,32(a1)
    800023e4:	0285b983          	ld	s3,40(a1)
    800023e8:	0305ba03          	ld	s4,48(a1)
    800023ec:	0385ba83          	ld	s5,56(a1)
    800023f0:	0405bb03          	ld	s6,64(a1)
    800023f4:	0485bb83          	ld	s7,72(a1)
    800023f8:	0505bc03          	ld	s8,80(a1)
    800023fc:	0585bc83          	ld	s9,88(a1)
    80002400:	0605bd03          	ld	s10,96(a1)
    80002404:	0685bd83          	ld	s11,104(a1)
    80002408:	8082                	ret

000000008000240a <trapinit>:

extern int devintr();

void
trapinit(void)
{
    8000240a:	1141                	addi	sp,sp,-16
    8000240c:	e406                	sd	ra,8(sp)
    8000240e:	e022                	sd	s0,0(sp)
    80002410:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80002412:	00005597          	auipc	a1,0x5
    80002416:	ed658593          	addi	a1,a1,-298 # 800072e8 <etext+0x2e8>
    8000241a:	00013517          	auipc	a0,0x13
    8000241e:	45650513          	addi	a0,a0,1110 # 80015870 <tickslock>
    80002422:	fb8fe0ef          	jal	80000bda <initlock>
}
    80002426:	60a2                	ld	ra,8(sp)
    80002428:	6402                	ld	s0,0(sp)
    8000242a:	0141                	addi	sp,sp,16
    8000242c:	8082                	ret

000000008000242e <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    8000242e:	1141                	addi	sp,sp,-16
    80002430:	e406                	sd	ra,8(sp)
    80002432:	e022                	sd	s0,0(sp)
    80002434:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002436:	00003797          	auipc	a5,0x3
    8000243a:	dda78793          	addi	a5,a5,-550 # 80005210 <kernelvec>
    8000243e:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80002442:	60a2                	ld	ra,8(sp)
    80002444:	6402                	ld	s0,0(sp)
    80002446:	0141                	addi	sp,sp,16
    80002448:	8082                	ret

000000008000244a <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    8000244a:	1141                	addi	sp,sp,-16
    8000244c:	e406                	sd	ra,8(sp)
    8000244e:	e022                	sd	s0,0(sp)
    80002450:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002452:	cd2ff0ef          	jal	80001924 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002456:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    8000245a:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000245c:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002460:	00004697          	auipc	a3,0x4
    80002464:	ba068693          	addi	a3,a3,-1120 # 80006000 <_trampoline>
    80002468:	00004717          	auipc	a4,0x4
    8000246c:	b9870713          	addi	a4,a4,-1128 # 80006000 <_trampoline>
    80002470:	8f15                	sub	a4,a4,a3
    80002472:	040007b7          	lui	a5,0x4000
    80002476:	17fd                	addi	a5,a5,-1 # 3ffffff <_entry-0x7c000001>
    80002478:	07b2                	slli	a5,a5,0xc
    8000247a:	973e                	add	a4,a4,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000247c:	10571073          	csrw	stvec,a4
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80002480:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80002482:	18002673          	csrr	a2,satp
    80002486:	e310                	sd	a2,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80002488:	6d30                	ld	a2,88(a0)
    8000248a:	6138                	ld	a4,64(a0)
    8000248c:	6585                	lui	a1,0x1
    8000248e:	972e                	add	a4,a4,a1
    80002490:	e618                	sd	a4,8(a2)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002492:	6d38                	ld	a4,88(a0)
    80002494:	00000617          	auipc	a2,0x0
    80002498:	10c60613          	addi	a2,a2,268 # 800025a0 <usertrap>
    8000249c:	eb10                	sd	a2,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    8000249e:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    800024a0:	8612                	mv	a2,tp
    800024a2:	f310                	sd	a2,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800024a4:	10002773          	csrr	a4,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    800024a8:	eff77713          	andi	a4,a4,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    800024ac:	02076713          	ori	a4,a4,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800024b0:	10071073          	csrw	sstatus,a4
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    800024b4:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    800024b6:	6f18                	ld	a4,24(a4)
    800024b8:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    800024bc:	6928                	ld	a0,80(a0)
    800024be:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    800024c0:	00004717          	auipc	a4,0x4
    800024c4:	bdc70713          	addi	a4,a4,-1060 # 8000609c <userret>
    800024c8:	8f15                	sub	a4,a4,a3
    800024ca:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    800024cc:	577d                	li	a4,-1
    800024ce:	177e                	slli	a4,a4,0x3f
    800024d0:	8d59                	or	a0,a0,a4
    800024d2:	9782                	jalr	a5
}
    800024d4:	60a2                	ld	ra,8(sp)
    800024d6:	6402                	ld	s0,0(sp)
    800024d8:	0141                	addi	sp,sp,16
    800024da:	8082                	ret

00000000800024dc <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800024dc:	1141                	addi	sp,sp,-16
    800024de:	e406                	sd	ra,8(sp)
    800024e0:	e022                	sd	s0,0(sp)
    800024e2:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    800024e4:	c0cff0ef          	jal	800018f0 <cpuid>
    800024e8:	cd11                	beqz	a0,80002504 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    800024ea:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    800024ee:	000f4737          	lui	a4,0xf4
    800024f2:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    800024f6:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    800024f8:	14d79073          	csrw	stimecmp,a5
}
    800024fc:	60a2                	ld	ra,8(sp)
    800024fe:	6402                	ld	s0,0(sp)
    80002500:	0141                	addi	sp,sp,16
    80002502:	8082                	ret
    acquire(&tickslock);
    80002504:	00013517          	auipc	a0,0x13
    80002508:	36c50513          	addi	a0,a0,876 # 80015870 <tickslock>
    8000250c:	f58fe0ef          	jal	80000c64 <acquire>
    ticks++;
    80002510:	00005717          	auipc	a4,0x5
    80002514:	40070713          	addi	a4,a4,1024 # 80007910 <ticks>
    80002518:	431c                	lw	a5,0(a4)
    8000251a:	2785                	addiw	a5,a5,1
    8000251c:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    8000251e:	853a                	mv	a0,a4
    80002520:	a0dff0ef          	jal	80001f2c <wakeup>
    release(&tickslock);
    80002524:	00013517          	auipc	a0,0x13
    80002528:	34c50513          	addi	a0,a0,844 # 80015870 <tickslock>
    8000252c:	fc8fe0ef          	jal	80000cf4 <release>
    80002530:	bf6d                	j	800024ea <clockintr+0xe>

0000000080002532 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80002532:	1101                	addi	sp,sp,-32
    80002534:	ec06                	sd	ra,24(sp)
    80002536:	e822                	sd	s0,16(sp)
    80002538:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000253a:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    8000253e:	57fd                	li	a5,-1
    80002540:	17fe                	slli	a5,a5,0x3f
    80002542:	07a5                	addi	a5,a5,9
    80002544:	00f70c63          	beq	a4,a5,8000255c <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80002548:	57fd                	li	a5,-1
    8000254a:	17fe                	slli	a5,a5,0x3f
    8000254c:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    8000254e:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80002550:	04f70463          	beq	a4,a5,80002598 <devintr+0x66>
  }
}
    80002554:	60e2                	ld	ra,24(sp)
    80002556:	6442                	ld	s0,16(sp)
    80002558:	6105                	addi	sp,sp,32
    8000255a:	8082                	ret
    8000255c:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    8000255e:	55f020ef          	jal	800052bc <plic_claim>
    80002562:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80002564:	47a9                	li	a5,10
    80002566:	02f50363          	beq	a0,a5,8000258c <devintr+0x5a>
    } else if(irq == VIRTIO0_IRQ){
    8000256a:	4785                	li	a5,1
    8000256c:	02f50363          	beq	a0,a5,80002592 <devintr+0x60>
    } else if(irq){
    80002570:	c919                	beqz	a0,80002586 <devintr+0x54>
      printf("unexpected interrupt irq=%d\n", irq);
    80002572:	85aa                	mv	a1,a0
    80002574:	00005517          	auipc	a0,0x5
    80002578:	d7c50513          	addi	a0,a0,-644 # 800072f0 <etext+0x2f0>
    8000257c:	f57fd0ef          	jal	800004d2 <printf>
      plic_complete(irq);
    80002580:	8526                	mv	a0,s1
    80002582:	55b020ef          	jal	800052dc <plic_complete>
    return 1;
    80002586:	4505                	li	a0,1
    80002588:	64a2                	ld	s1,8(sp)
    8000258a:	b7e9                	j	80002554 <devintr+0x22>
      uartintr();
    8000258c:	cc4fe0ef          	jal	80000a50 <uartintr>
    if(irq)
    80002590:	bfc5                	j	80002580 <devintr+0x4e>
      virtio_disk_intr();
    80002592:	1ae030ef          	jal	80005740 <virtio_disk_intr>
    if(irq)
    80002596:	b7ed                	j	80002580 <devintr+0x4e>
    clockintr();
    80002598:	f45ff0ef          	jal	800024dc <clockintr>
    return 2;
    8000259c:	4509                	li	a0,2
    8000259e:	bf5d                	j	80002554 <devintr+0x22>

00000000800025a0 <usertrap>:
{
    800025a0:	1101                	addi	sp,sp,-32
    800025a2:	ec06                	sd	ra,24(sp)
    800025a4:	e822                	sd	s0,16(sp)
    800025a6:	e426                	sd	s1,8(sp)
    800025a8:	e04a                	sd	s2,0(sp)
    800025aa:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800025ac:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    800025b0:	1007f793          	andi	a5,a5,256
    800025b4:	ef85                	bnez	a5,800025ec <usertrap+0x4c>
  asm volatile("csrw stvec, %0" : : "r" (x));
    800025b6:	00003797          	auipc	a5,0x3
    800025ba:	c5a78793          	addi	a5,a5,-934 # 80005210 <kernelvec>
    800025be:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    800025c2:	b62ff0ef          	jal	80001924 <myproc>
    800025c6:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    800025c8:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800025ca:	14102773          	csrr	a4,sepc
    800025ce:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    800025d0:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    800025d4:	47a1                	li	a5,8
    800025d6:	02f70163          	beq	a4,a5,800025f8 <usertrap+0x58>
  } else if((which_dev = devintr()) != 0){
    800025da:	f59ff0ef          	jal	80002532 <devintr>
    800025de:	892a                	mv	s2,a0
    800025e0:	c135                	beqz	a0,80002644 <usertrap+0xa4>
  if(killed(p))
    800025e2:	8526                	mv	a0,s1
    800025e4:	b39ff0ef          	jal	8000211c <killed>
    800025e8:	cd1d                	beqz	a0,80002626 <usertrap+0x86>
    800025ea:	a81d                	j	80002620 <usertrap+0x80>
    panic("usertrap: not from user mode");
    800025ec:	00005517          	auipc	a0,0x5
    800025f0:	d2450513          	addi	a0,a0,-732 # 80007310 <etext+0x310>
    800025f4:	9fcfe0ef          	jal	800007f0 <panic>
    if(killed(p))
    800025f8:	b25ff0ef          	jal	8000211c <killed>
    800025fc:	e121                	bnez	a0,8000263c <usertrap+0x9c>
    p->trapframe->epc += 4;
    800025fe:	6cb8                	ld	a4,88(s1)
    80002600:	6f1c                	ld	a5,24(a4)
    80002602:	0791                	addi	a5,a5,4
    80002604:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002606:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000260a:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000260e:	10079073          	csrw	sstatus,a5
    syscall();
    80002612:	23e000ef          	jal	80002850 <syscall>
  if(killed(p))
    80002616:	8526                	mv	a0,s1
    80002618:	b05ff0ef          	jal	8000211c <killed>
    8000261c:	c901                	beqz	a0,8000262c <usertrap+0x8c>
    8000261e:	4901                	li	s2,0
    exit(-1);
    80002620:	557d                	li	a0,-1
    80002622:	9cbff0ef          	jal	80001fec <exit>
  if(which_dev == 2)
    80002626:	4789                	li	a5,2
    80002628:	04f90563          	beq	s2,a5,80002672 <usertrap+0xd2>
  usertrapret();
    8000262c:	e1fff0ef          	jal	8000244a <usertrapret>
}
    80002630:	60e2                	ld	ra,24(sp)
    80002632:	6442                	ld	s0,16(sp)
    80002634:	64a2                	ld	s1,8(sp)
    80002636:	6902                	ld	s2,0(sp)
    80002638:	6105                	addi	sp,sp,32
    8000263a:	8082                	ret
      exit(-1);
    8000263c:	557d                	li	a0,-1
    8000263e:	9afff0ef          	jal	80001fec <exit>
    80002642:	bf75                	j	800025fe <usertrap+0x5e>
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002644:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80002648:	5890                	lw	a2,48(s1)
    8000264a:	00005517          	auipc	a0,0x5
    8000264e:	ce650513          	addi	a0,a0,-794 # 80007330 <etext+0x330>
    80002652:	e81fd0ef          	jal	800004d2 <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002656:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    8000265a:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    8000265e:	00005517          	auipc	a0,0x5
    80002662:	d0250513          	addi	a0,a0,-766 # 80007360 <etext+0x360>
    80002666:	e6dfd0ef          	jal	800004d2 <printf>
    setkilled(p);
    8000266a:	8526                	mv	a0,s1
    8000266c:	a8dff0ef          	jal	800020f8 <setkilled>
    80002670:	b75d                	j	80002616 <usertrap+0x76>
    yield();
    80002672:	843ff0ef          	jal	80001eb4 <yield>
    80002676:	bf5d                	j	8000262c <usertrap+0x8c>

0000000080002678 <kerneltrap>:
{
    80002678:	7179                	addi	sp,sp,-48
    8000267a:	f406                	sd	ra,40(sp)
    8000267c:	f022                	sd	s0,32(sp)
    8000267e:	ec26                	sd	s1,24(sp)
    80002680:	e84a                	sd	s2,16(sp)
    80002682:	e44e                	sd	s3,8(sp)
    80002684:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002686:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000268a:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000268e:	142027f3          	csrr	a5,scause
    80002692:	89be                	mv	s3,a5
  if((sstatus & SSTATUS_SPP) == 0)
    80002694:	1004f793          	andi	a5,s1,256
    80002698:	c795                	beqz	a5,800026c4 <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000269a:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000269e:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    800026a0:	eb85                	bnez	a5,800026d0 <kerneltrap+0x58>
  if((which_dev = devintr()) == 0){
    800026a2:	e91ff0ef          	jal	80002532 <devintr>
    800026a6:	c91d                	beqz	a0,800026dc <kerneltrap+0x64>
  if(which_dev == 2 && myproc() != 0)
    800026a8:	4789                	li	a5,2
    800026aa:	04f50a63          	beq	a0,a5,800026fe <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r" (x));
    800026ae:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800026b2:	10049073          	csrw	sstatus,s1
}
    800026b6:	70a2                	ld	ra,40(sp)
    800026b8:	7402                	ld	s0,32(sp)
    800026ba:	64e2                	ld	s1,24(sp)
    800026bc:	6942                	ld	s2,16(sp)
    800026be:	69a2                	ld	s3,8(sp)
    800026c0:	6145                	addi	sp,sp,48
    800026c2:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    800026c4:	00005517          	auipc	a0,0x5
    800026c8:	cc450513          	addi	a0,a0,-828 # 80007388 <etext+0x388>
    800026cc:	924fe0ef          	jal	800007f0 <panic>
    panic("kerneltrap: interrupts enabled");
    800026d0:	00005517          	auipc	a0,0x5
    800026d4:	ce050513          	addi	a0,a0,-800 # 800073b0 <etext+0x3b0>
    800026d8:	918fe0ef          	jal	800007f0 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800026dc:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    800026e0:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    800026e4:	85ce                	mv	a1,s3
    800026e6:	00005517          	auipc	a0,0x5
    800026ea:	cea50513          	addi	a0,a0,-790 # 800073d0 <etext+0x3d0>
    800026ee:	de5fd0ef          	jal	800004d2 <printf>
    panic("kerneltrap");
    800026f2:	00005517          	auipc	a0,0x5
    800026f6:	d0650513          	addi	a0,a0,-762 # 800073f8 <etext+0x3f8>
    800026fa:	8f6fe0ef          	jal	800007f0 <panic>
  if(which_dev == 2 && myproc() != 0)
    800026fe:	a26ff0ef          	jal	80001924 <myproc>
    80002702:	d555                	beqz	a0,800026ae <kerneltrap+0x36>
    yield();
    80002704:	fb0ff0ef          	jal	80001eb4 <yield>
    80002708:	b75d                	j	800026ae <kerneltrap+0x36>

000000008000270a <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    8000270a:	1101                	addi	sp,sp,-32
    8000270c:	ec06                	sd	ra,24(sp)
    8000270e:	e822                	sd	s0,16(sp)
    80002710:	e426                	sd	s1,8(sp)
    80002712:	1000                	addi	s0,sp,32
    80002714:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002716:	a0eff0ef          	jal	80001924 <myproc>
  switch (n) {
    8000271a:	4795                	li	a5,5
    8000271c:	0497e163          	bltu	a5,s1,8000275e <argraw+0x54>
    80002720:	048a                	slli	s1,s1,0x2
    80002722:	00005717          	auipc	a4,0x5
    80002726:	09670713          	addi	a4,a4,150 # 800077b8 <states.0+0x30>
    8000272a:	94ba                	add	s1,s1,a4
    8000272c:	409c                	lw	a5,0(s1)
    8000272e:	97ba                	add	a5,a5,a4
    80002730:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002732:	6d3c                	ld	a5,88(a0)
    80002734:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002736:	60e2                	ld	ra,24(sp)
    80002738:	6442                	ld	s0,16(sp)
    8000273a:	64a2                	ld	s1,8(sp)
    8000273c:	6105                	addi	sp,sp,32
    8000273e:	8082                	ret
    return p->trapframe->a1;
    80002740:	6d3c                	ld	a5,88(a0)
    80002742:	7fa8                	ld	a0,120(a5)
    80002744:	bfcd                	j	80002736 <argraw+0x2c>
    return p->trapframe->a2;
    80002746:	6d3c                	ld	a5,88(a0)
    80002748:	63c8                	ld	a0,128(a5)
    8000274a:	b7f5                	j	80002736 <argraw+0x2c>
    return p->trapframe->a3;
    8000274c:	6d3c                	ld	a5,88(a0)
    8000274e:	67c8                	ld	a0,136(a5)
    80002750:	b7dd                	j	80002736 <argraw+0x2c>
    return p->trapframe->a4;
    80002752:	6d3c                	ld	a5,88(a0)
    80002754:	6bc8                	ld	a0,144(a5)
    80002756:	b7c5                	j	80002736 <argraw+0x2c>
    return p->trapframe->a5;
    80002758:	6d3c                	ld	a5,88(a0)
    8000275a:	6fc8                	ld	a0,152(a5)
    8000275c:	bfe9                	j	80002736 <argraw+0x2c>
  panic("argraw");
    8000275e:	00005517          	auipc	a0,0x5
    80002762:	caa50513          	addi	a0,a0,-854 # 80007408 <etext+0x408>
    80002766:	88afe0ef          	jal	800007f0 <panic>

000000008000276a <fetchaddr>:
{
    8000276a:	1101                	addi	sp,sp,-32
    8000276c:	ec06                	sd	ra,24(sp)
    8000276e:	e822                	sd	s0,16(sp)
    80002770:	e426                	sd	s1,8(sp)
    80002772:	e04a                	sd	s2,0(sp)
    80002774:	1000                	addi	s0,sp,32
    80002776:	84aa                	mv	s1,a0
    80002778:	892e                	mv	s2,a1
  struct proc *p = myproc();
    8000277a:	9aaff0ef          	jal	80001924 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    8000277e:	653c                	ld	a5,72(a0)
    80002780:	02f4f663          	bgeu	s1,a5,800027ac <fetchaddr+0x42>
    80002784:	00848713          	addi	a4,s1,8
    80002788:	02e7e263          	bltu	a5,a4,800027ac <fetchaddr+0x42>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    8000278c:	46a1                	li	a3,8
    8000278e:	8626                	mv	a2,s1
    80002790:	85ca                	mv	a1,s2
    80002792:	6928                	ld	a0,80(a0)
    80002794:	ecffe0ef          	jal	80001662 <copyin>
    80002798:	00a03533          	snez	a0,a0
    8000279c:	40a0053b          	negw	a0,a0
}
    800027a0:	60e2                	ld	ra,24(sp)
    800027a2:	6442                	ld	s0,16(sp)
    800027a4:	64a2                	ld	s1,8(sp)
    800027a6:	6902                	ld	s2,0(sp)
    800027a8:	6105                	addi	sp,sp,32
    800027aa:	8082                	ret
    return -1;
    800027ac:	557d                	li	a0,-1
    800027ae:	bfcd                	j	800027a0 <fetchaddr+0x36>

00000000800027b0 <fetchstr>:
{
    800027b0:	7179                	addi	sp,sp,-48
    800027b2:	f406                	sd	ra,40(sp)
    800027b4:	f022                	sd	s0,32(sp)
    800027b6:	ec26                	sd	s1,24(sp)
    800027b8:	e84a                	sd	s2,16(sp)
    800027ba:	e44e                	sd	s3,8(sp)
    800027bc:	1800                	addi	s0,sp,48
    800027be:	89aa                	mv	s3,a0
    800027c0:	84ae                	mv	s1,a1
    800027c2:	8932                	mv	s2,a2
  struct proc *p = myproc();
    800027c4:	960ff0ef          	jal	80001924 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    800027c8:	86ca                	mv	a3,s2
    800027ca:	864e                	mv	a2,s3
    800027cc:	85a6                	mv	a1,s1
    800027ce:	6928                	ld	a0,80(a0)
    800027d0:	f19fe0ef          	jal	800016e8 <copyinstr>
    800027d4:	00054c63          	bltz	a0,800027ec <fetchstr+0x3c>
  return strlen(buf);
    800027d8:	8526                	mv	a0,s1
    800027da:	ed6fe0ef          	jal	80000eb0 <strlen>
}
    800027de:	70a2                	ld	ra,40(sp)
    800027e0:	7402                	ld	s0,32(sp)
    800027e2:	64e2                	ld	s1,24(sp)
    800027e4:	6942                	ld	s2,16(sp)
    800027e6:	69a2                	ld	s3,8(sp)
    800027e8:	6145                	addi	sp,sp,48
    800027ea:	8082                	ret
    return -1;
    800027ec:	557d                	li	a0,-1
    800027ee:	bfc5                	j	800027de <fetchstr+0x2e>

00000000800027f0 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    800027f0:	1101                	addi	sp,sp,-32
    800027f2:	ec06                	sd	ra,24(sp)
    800027f4:	e822                	sd	s0,16(sp)
    800027f6:	e426                	sd	s1,8(sp)
    800027f8:	1000                	addi	s0,sp,32
    800027fa:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800027fc:	f0fff0ef          	jal	8000270a <argraw>
    80002800:	c088                	sw	a0,0(s1)
}
    80002802:	60e2                	ld	ra,24(sp)
    80002804:	6442                	ld	s0,16(sp)
    80002806:	64a2                	ld	s1,8(sp)
    80002808:	6105                	addi	sp,sp,32
    8000280a:	8082                	ret

000000008000280c <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    8000280c:	1101                	addi	sp,sp,-32
    8000280e:	ec06                	sd	ra,24(sp)
    80002810:	e822                	sd	s0,16(sp)
    80002812:	e426                	sd	s1,8(sp)
    80002814:	1000                	addi	s0,sp,32
    80002816:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002818:	ef3ff0ef          	jal	8000270a <argraw>
    8000281c:	e088                	sd	a0,0(s1)
}
    8000281e:	60e2                	ld	ra,24(sp)
    80002820:	6442                	ld	s0,16(sp)
    80002822:	64a2                	ld	s1,8(sp)
    80002824:	6105                	addi	sp,sp,32
    80002826:	8082                	ret

0000000080002828 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002828:	1101                	addi	sp,sp,-32
    8000282a:	ec06                	sd	ra,24(sp)
    8000282c:	e822                	sd	s0,16(sp)
    8000282e:	e426                	sd	s1,8(sp)
    80002830:	e04a                	sd	s2,0(sp)
    80002832:	1000                	addi	s0,sp,32
    80002834:	892e                	mv	s2,a1
    80002836:	84b2                	mv	s1,a2
  *ip = argraw(n);
    80002838:	ed3ff0ef          	jal	8000270a <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    8000283c:	8626                	mv	a2,s1
    8000283e:	85ca                	mv	a1,s2
    80002840:	f71ff0ef          	jal	800027b0 <fetchstr>
}
    80002844:	60e2                	ld	ra,24(sp)
    80002846:	6442                	ld	s0,16(sp)
    80002848:	64a2                	ld	s1,8(sp)
    8000284a:	6902                	ld	s2,0(sp)
    8000284c:	6105                	addi	sp,sp,32
    8000284e:	8082                	ret

0000000080002850 <syscall>:
[SYS_getproccount] sys_getproccount,
};

void
syscall(void)
{
    80002850:	1101                	addi	sp,sp,-32
    80002852:	ec06                	sd	ra,24(sp)
    80002854:	e822                	sd	s0,16(sp)
    80002856:	e426                	sd	s1,8(sp)
    80002858:	e04a                	sd	s2,0(sp)
    8000285a:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    8000285c:	8c8ff0ef          	jal	80001924 <myproc>
    80002860:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002862:	05853903          	ld	s2,88(a0)
    80002866:	0a893783          	ld	a5,168(s2)
    8000286a:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    8000286e:	37fd                	addiw	a5,a5,-1
    80002870:	4755                	li	a4,21
    80002872:	00f76f63          	bltu	a4,a5,80002890 <syscall+0x40>
    80002876:	00369713          	slli	a4,a3,0x3
    8000287a:	00005797          	auipc	a5,0x5
    8000287e:	f5678793          	addi	a5,a5,-170 # 800077d0 <syscalls>
    80002882:	97ba                	add	a5,a5,a4
    80002884:	639c                	ld	a5,0(a5)
    80002886:	c789                	beqz	a5,80002890 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002888:	9782                	jalr	a5
    8000288a:	06a93823          	sd	a0,112(s2)
    8000288e:	a829                	j	800028a8 <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002890:	15848613          	addi	a2,s1,344
    80002894:	588c                	lw	a1,48(s1)
    80002896:	00005517          	auipc	a0,0x5
    8000289a:	b7a50513          	addi	a0,a0,-1158 # 80007410 <etext+0x410>
    8000289e:	c35fd0ef          	jal	800004d2 <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    800028a2:	6cbc                	ld	a5,88(s1)
    800028a4:	577d                	li	a4,-1
    800028a6:	fbb8                	sd	a4,112(a5)
  }
}
    800028a8:	60e2                	ld	ra,24(sp)
    800028aa:	6442                	ld	s0,16(sp)
    800028ac:	64a2                	ld	s1,8(sp)
    800028ae:	6902                	ld	s2,0(sp)
    800028b0:	6105                	addi	sp,sp,32
    800028b2:	8082                	ret

00000000800028b4 <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    800028b4:	1101                	addi	sp,sp,-32
    800028b6:	ec06                	sd	ra,24(sp)
    800028b8:	e822                	sd	s0,16(sp)
    800028ba:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    800028bc:	fec40593          	addi	a1,s0,-20
    800028c0:	4501                	li	a0,0
    800028c2:	f2fff0ef          	jal	800027f0 <argint>
  exit(n);
    800028c6:	fec42503          	lw	a0,-20(s0)
    800028ca:	f22ff0ef          	jal	80001fec <exit>
  return 0;  // not reached
}
    800028ce:	4501                	li	a0,0
    800028d0:	60e2                	ld	ra,24(sp)
    800028d2:	6442                	ld	s0,16(sp)
    800028d4:	6105                	addi	sp,sp,32
    800028d6:	8082                	ret

00000000800028d8 <sys_getpid>:

uint64
sys_getpid(void)
{
    800028d8:	1141                	addi	sp,sp,-16
    800028da:	e406                	sd	ra,8(sp)
    800028dc:	e022                	sd	s0,0(sp)
    800028de:	0800                	addi	s0,sp,16
  return myproc()->pid;
    800028e0:	844ff0ef          	jal	80001924 <myproc>
}
    800028e4:	5908                	lw	a0,48(a0)
    800028e6:	60a2                	ld	ra,8(sp)
    800028e8:	6402                	ld	s0,0(sp)
    800028ea:	0141                	addi	sp,sp,16
    800028ec:	8082                	ret

00000000800028ee <sys_fork>:

uint64
sys_fork(void)
{
    800028ee:	1141                	addi	sp,sp,-16
    800028f0:	e406                	sd	ra,8(sp)
    800028f2:	e022                	sd	s0,0(sp)
    800028f4:	0800                	addi	s0,sp,16
  return fork();
    800028f6:	b54ff0ef          	jal	80001c4a <fork>
}
    800028fa:	60a2                	ld	ra,8(sp)
    800028fc:	6402                	ld	s0,0(sp)
    800028fe:	0141                	addi	sp,sp,16
    80002900:	8082                	ret

0000000080002902 <sys_wait>:

uint64
sys_wait(void)
{
    80002902:	1101                	addi	sp,sp,-32
    80002904:	ec06                	sd	ra,24(sp)
    80002906:	e822                	sd	s0,16(sp)
    80002908:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    8000290a:	fe840593          	addi	a1,s0,-24
    8000290e:	4501                	li	a0,0
    80002910:	efdff0ef          	jal	8000280c <argaddr>
  return wait(p);
    80002914:	fe843503          	ld	a0,-24(s0)
    80002918:	82fff0ef          	jal	80002146 <wait>
}
    8000291c:	60e2                	ld	ra,24(sp)
    8000291e:	6442                	ld	s0,16(sp)
    80002920:	6105                	addi	sp,sp,32
    80002922:	8082                	ret

0000000080002924 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002924:	7179                	addi	sp,sp,-48
    80002926:	f406                	sd	ra,40(sp)
    80002928:	f022                	sd	s0,32(sp)
    8000292a:	ec26                	sd	s1,24(sp)
    8000292c:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    8000292e:	fdc40593          	addi	a1,s0,-36
    80002932:	4501                	li	a0,0
    80002934:	ebdff0ef          	jal	800027f0 <argint>
  addr = myproc()->sz;
    80002938:	fedfe0ef          	jal	80001924 <myproc>
    8000293c:	653c                	ld	a5,72(a0)
    8000293e:	84be                	mv	s1,a5
  if(growproc(n) < 0)
    80002940:	fdc42503          	lw	a0,-36(s0)
    80002944:	ab6ff0ef          	jal	80001bfa <growproc>
    80002948:	00054863          	bltz	a0,80002958 <sys_sbrk+0x34>
    return -1;
  return addr;
}
    8000294c:	8526                	mv	a0,s1
    8000294e:	70a2                	ld	ra,40(sp)
    80002950:	7402                	ld	s0,32(sp)
    80002952:	64e2                	ld	s1,24(sp)
    80002954:	6145                	addi	sp,sp,48
    80002956:	8082                	ret
    return -1;
    80002958:	57fd                	li	a5,-1
    8000295a:	84be                	mv	s1,a5
    8000295c:	bfc5                	j	8000294c <sys_sbrk+0x28>

000000008000295e <sys_sleep>:

uint64
sys_sleep(void)
{
    8000295e:	7139                	addi	sp,sp,-64
    80002960:	fc06                	sd	ra,56(sp)
    80002962:	f822                	sd	s0,48(sp)
    80002964:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002966:	fcc40593          	addi	a1,s0,-52
    8000296a:	4501                	li	a0,0
    8000296c:	e85ff0ef          	jal	800027f0 <argint>
  if(n < 0)
    80002970:	fcc42783          	lw	a5,-52(s0)
    80002974:	0607c863          	bltz	a5,800029e4 <sys_sleep+0x86>
    n = 0;
  acquire(&tickslock);
    80002978:	00013517          	auipc	a0,0x13
    8000297c:	ef850513          	addi	a0,a0,-264 # 80015870 <tickslock>
    80002980:	ae4fe0ef          	jal	80000c64 <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    80002984:	fcc42783          	lw	a5,-52(s0)
    80002988:	c3b9                	beqz	a5,800029ce <sys_sleep+0x70>
    8000298a:	f426                	sd	s1,40(sp)
    8000298c:	f04a                	sd	s2,32(sp)
    8000298e:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80002990:	00005997          	auipc	s3,0x5
    80002994:	f809a983          	lw	s3,-128(s3) # 80007910 <ticks>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002998:	00013917          	auipc	s2,0x13
    8000299c:	ed890913          	addi	s2,s2,-296 # 80015870 <tickslock>
    800029a0:	00005497          	auipc	s1,0x5
    800029a4:	f7048493          	addi	s1,s1,-144 # 80007910 <ticks>
    if(killed(myproc())){
    800029a8:	f7dfe0ef          	jal	80001924 <myproc>
    800029ac:	f70ff0ef          	jal	8000211c <killed>
    800029b0:	ed0d                	bnez	a0,800029ea <sys_sleep+0x8c>
    sleep(&ticks, &tickslock);
    800029b2:	85ca                	mv	a1,s2
    800029b4:	8526                	mv	a0,s1
    800029b6:	d2aff0ef          	jal	80001ee0 <sleep>
  while(ticks - ticks0 < n){
    800029ba:	409c                	lw	a5,0(s1)
    800029bc:	413787bb          	subw	a5,a5,s3
    800029c0:	fcc42703          	lw	a4,-52(s0)
    800029c4:	fee7e2e3          	bltu	a5,a4,800029a8 <sys_sleep+0x4a>
    800029c8:	74a2                	ld	s1,40(sp)
    800029ca:	7902                	ld	s2,32(sp)
    800029cc:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    800029ce:	00013517          	auipc	a0,0x13
    800029d2:	ea250513          	addi	a0,a0,-350 # 80015870 <tickslock>
    800029d6:	b1efe0ef          	jal	80000cf4 <release>
  return 0;
    800029da:	4501                	li	a0,0
}
    800029dc:	70e2                	ld	ra,56(sp)
    800029de:	7442                	ld	s0,48(sp)
    800029e0:	6121                	addi	sp,sp,64
    800029e2:	8082                	ret
    n = 0;
    800029e4:	fc042623          	sw	zero,-52(s0)
    800029e8:	bf41                	j	80002978 <sys_sleep+0x1a>
      release(&tickslock);
    800029ea:	00013517          	auipc	a0,0x13
    800029ee:	e8650513          	addi	a0,a0,-378 # 80015870 <tickslock>
    800029f2:	b02fe0ef          	jal	80000cf4 <release>
      return -1;
    800029f6:	557d                	li	a0,-1
    800029f8:	74a2                	ld	s1,40(sp)
    800029fa:	7902                	ld	s2,32(sp)
    800029fc:	69e2                	ld	s3,24(sp)
    800029fe:	bff9                	j	800029dc <sys_sleep+0x7e>

0000000080002a00 <sys_kill>:

uint64
sys_kill(void)
{
    80002a00:	1101                	addi	sp,sp,-32
    80002a02:	ec06                	sd	ra,24(sp)
    80002a04:	e822                	sd	s0,16(sp)
    80002a06:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002a08:	fec40593          	addi	a1,s0,-20
    80002a0c:	4501                	li	a0,0
    80002a0e:	de3ff0ef          	jal	800027f0 <argint>
  return kill(pid);
    80002a12:	fec42503          	lw	a0,-20(s0)
    80002a16:	e7cff0ef          	jal	80002092 <kill>
}
    80002a1a:	60e2                	ld	ra,24(sp)
    80002a1c:	6442                	ld	s0,16(sp)
    80002a1e:	6105                	addi	sp,sp,32
    80002a20:	8082                	ret

0000000080002a22 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002a22:	1101                	addi	sp,sp,-32
    80002a24:	ec06                	sd	ra,24(sp)
    80002a26:	e822                	sd	s0,16(sp)
    80002a28:	e426                	sd	s1,8(sp)
    80002a2a:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002a2c:	00013517          	auipc	a0,0x13
    80002a30:	e4450513          	addi	a0,a0,-444 # 80015870 <tickslock>
    80002a34:	a30fe0ef          	jal	80000c64 <acquire>
  xticks = ticks;
    80002a38:	00005797          	auipc	a5,0x5
    80002a3c:	ed87a783          	lw	a5,-296(a5) # 80007910 <ticks>
    80002a40:	84be                	mv	s1,a5
  release(&tickslock);
    80002a42:	00013517          	auipc	a0,0x13
    80002a46:	e2e50513          	addi	a0,a0,-466 # 80015870 <tickslock>
    80002a4a:	aaafe0ef          	jal	80000cf4 <release>
  return xticks;
}
    80002a4e:	02049513          	slli	a0,s1,0x20
    80002a52:	9101                	srli	a0,a0,0x20
    80002a54:	60e2                	ld	ra,24(sp)
    80002a56:	6442                	ld	s0,16(sp)
    80002a58:	64a2                	ld	s1,8(sp)
    80002a5a:	6105                	addi	sp,sp,32
    80002a5c:	8082                	ret

0000000080002a5e <sys_getproccount>:

uint64
sys_getproccount(void)
{
    80002a5e:	1141                	addi	sp,sp,-16
    80002a60:	e406                	sd	ra,8(sp)
    80002a62:	e022                	sd	s0,0(sp)
    80002a64:	0800                	addi	s0,sp,16
  return proccount();
    80002a66:	867ff0ef          	jal	800022cc <proccount>
}
    80002a6a:	60a2                	ld	ra,8(sp)
    80002a6c:	6402                	ld	s0,0(sp)
    80002a6e:	0141                	addi	sp,sp,16
    80002a70:	8082                	ret

0000000080002a72 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002a72:	7179                	addi	sp,sp,-48
    80002a74:	f406                	sd	ra,40(sp)
    80002a76:	f022                	sd	s0,32(sp)
    80002a78:	ec26                	sd	s1,24(sp)
    80002a7a:	e84a                	sd	s2,16(sp)
    80002a7c:	e44e                	sd	s3,8(sp)
    80002a7e:	e052                	sd	s4,0(sp)
    80002a80:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002a82:	00005597          	auipc	a1,0x5
    80002a86:	9ae58593          	addi	a1,a1,-1618 # 80007430 <etext+0x430>
    80002a8a:	00013517          	auipc	a0,0x13
    80002a8e:	dfe50513          	addi	a0,a0,-514 # 80015888 <bcache>
    80002a92:	948fe0ef          	jal	80000bda <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002a96:	0001b797          	auipc	a5,0x1b
    80002a9a:	df278793          	addi	a5,a5,-526 # 8001d888 <bcache+0x8000>
    80002a9e:	0001b717          	auipc	a4,0x1b
    80002aa2:	05270713          	addi	a4,a4,82 # 8001daf0 <bcache+0x8268>
    80002aa6:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002aaa:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002aae:	00013497          	auipc	s1,0x13
    80002ab2:	df248493          	addi	s1,s1,-526 # 800158a0 <bcache+0x18>
    b->next = bcache.head.next;
    80002ab6:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002ab8:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002aba:	00005a17          	auipc	s4,0x5
    80002abe:	97ea0a13          	addi	s4,s4,-1666 # 80007438 <etext+0x438>
    b->next = bcache.head.next;
    80002ac2:	2b893783          	ld	a5,696(s2)
    80002ac6:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002ac8:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002acc:	85d2                	mv	a1,s4
    80002ace:	01048513          	addi	a0,s1,16
    80002ad2:	25a010ef          	jal	80003d2c <initsleeplock>
    bcache.head.next->prev = b;
    80002ad6:	2b893783          	ld	a5,696(s2)
    80002ada:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002adc:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002ae0:	45848493          	addi	s1,s1,1112
    80002ae4:	fd349fe3          	bne	s1,s3,80002ac2 <binit+0x50>
  }
}
    80002ae8:	70a2                	ld	ra,40(sp)
    80002aea:	7402                	ld	s0,32(sp)
    80002aec:	64e2                	ld	s1,24(sp)
    80002aee:	6942                	ld	s2,16(sp)
    80002af0:	69a2                	ld	s3,8(sp)
    80002af2:	6a02                	ld	s4,0(sp)
    80002af4:	6145                	addi	sp,sp,48
    80002af6:	8082                	ret

0000000080002af8 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002af8:	7179                	addi	sp,sp,-48
    80002afa:	f406                	sd	ra,40(sp)
    80002afc:	f022                	sd	s0,32(sp)
    80002afe:	ec26                	sd	s1,24(sp)
    80002b00:	e84a                	sd	s2,16(sp)
    80002b02:	e44e                	sd	s3,8(sp)
    80002b04:	1800                	addi	s0,sp,48
    80002b06:	892a                	mv	s2,a0
    80002b08:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002b0a:	00013517          	auipc	a0,0x13
    80002b0e:	d7e50513          	addi	a0,a0,-642 # 80015888 <bcache>
    80002b12:	952fe0ef          	jal	80000c64 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002b16:	0001b497          	auipc	s1,0x1b
    80002b1a:	02a4b483          	ld	s1,42(s1) # 8001db40 <bcache+0x82b8>
    80002b1e:	0001b797          	auipc	a5,0x1b
    80002b22:	fd278793          	addi	a5,a5,-46 # 8001daf0 <bcache+0x8268>
    80002b26:	02f48b63          	beq	s1,a5,80002b5c <bread+0x64>
    80002b2a:	873e                	mv	a4,a5
    80002b2c:	a021                	j	80002b34 <bread+0x3c>
    80002b2e:	68a4                	ld	s1,80(s1)
    80002b30:	02e48663          	beq	s1,a4,80002b5c <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002b34:	449c                	lw	a5,8(s1)
    80002b36:	ff279ce3          	bne	a5,s2,80002b2e <bread+0x36>
    80002b3a:	44dc                	lw	a5,12(s1)
    80002b3c:	ff3799e3          	bne	a5,s3,80002b2e <bread+0x36>
      b->refcnt++;
    80002b40:	40bc                	lw	a5,64(s1)
    80002b42:	2785                	addiw	a5,a5,1
    80002b44:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002b46:	00013517          	auipc	a0,0x13
    80002b4a:	d4250513          	addi	a0,a0,-702 # 80015888 <bcache>
    80002b4e:	9a6fe0ef          	jal	80000cf4 <release>
      acquiresleep(&b->lock);
    80002b52:	01048513          	addi	a0,s1,16
    80002b56:	20c010ef          	jal	80003d62 <acquiresleep>
      return b;
    80002b5a:	a889                	j	80002bac <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002b5c:	0001b497          	auipc	s1,0x1b
    80002b60:	fdc4b483          	ld	s1,-36(s1) # 8001db38 <bcache+0x82b0>
    80002b64:	0001b797          	auipc	a5,0x1b
    80002b68:	f8c78793          	addi	a5,a5,-116 # 8001daf0 <bcache+0x8268>
    80002b6c:	00f48863          	beq	s1,a5,80002b7c <bread+0x84>
    80002b70:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002b72:	40bc                	lw	a5,64(s1)
    80002b74:	cb91                	beqz	a5,80002b88 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002b76:	64a4                	ld	s1,72(s1)
    80002b78:	fee49de3          	bne	s1,a4,80002b72 <bread+0x7a>
  panic("bget: no buffers");
    80002b7c:	00005517          	auipc	a0,0x5
    80002b80:	8c450513          	addi	a0,a0,-1852 # 80007440 <etext+0x440>
    80002b84:	c6dfd0ef          	jal	800007f0 <panic>
      b->dev = dev;
    80002b88:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002b8c:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002b90:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002b94:	4785                	li	a5,1
    80002b96:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002b98:	00013517          	auipc	a0,0x13
    80002b9c:	cf050513          	addi	a0,a0,-784 # 80015888 <bcache>
    80002ba0:	954fe0ef          	jal	80000cf4 <release>
      acquiresleep(&b->lock);
    80002ba4:	01048513          	addi	a0,s1,16
    80002ba8:	1ba010ef          	jal	80003d62 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002bac:	409c                	lw	a5,0(s1)
    80002bae:	cb89                	beqz	a5,80002bc0 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002bb0:	8526                	mv	a0,s1
    80002bb2:	70a2                	ld	ra,40(sp)
    80002bb4:	7402                	ld	s0,32(sp)
    80002bb6:	64e2                	ld	s1,24(sp)
    80002bb8:	6942                	ld	s2,16(sp)
    80002bba:	69a2                	ld	s3,8(sp)
    80002bbc:	6145                	addi	sp,sp,48
    80002bbe:	8082                	ret
    virtio_disk_rw(b, 0);
    80002bc0:	4581                	li	a1,0
    80002bc2:	8526                	mv	a0,s1
    80002bc4:	16f020ef          	jal	80005532 <virtio_disk_rw>
    b->valid = 1;
    80002bc8:	4785                	li	a5,1
    80002bca:	c09c                	sw	a5,0(s1)
  return b;
    80002bcc:	b7d5                	j	80002bb0 <bread+0xb8>

0000000080002bce <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80002bce:	1101                	addi	sp,sp,-32
    80002bd0:	ec06                	sd	ra,24(sp)
    80002bd2:	e822                	sd	s0,16(sp)
    80002bd4:	e426                	sd	s1,8(sp)
    80002bd6:	1000                	addi	s0,sp,32
    80002bd8:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002bda:	0541                	addi	a0,a0,16
    80002bdc:	204010ef          	jal	80003de0 <holdingsleep>
    80002be0:	c911                	beqz	a0,80002bf4 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002be2:	4585                	li	a1,1
    80002be4:	8526                	mv	a0,s1
    80002be6:	14d020ef          	jal	80005532 <virtio_disk_rw>
}
    80002bea:	60e2                	ld	ra,24(sp)
    80002bec:	6442                	ld	s0,16(sp)
    80002bee:	64a2                	ld	s1,8(sp)
    80002bf0:	6105                	addi	sp,sp,32
    80002bf2:	8082                	ret
    panic("bwrite");
    80002bf4:	00005517          	auipc	a0,0x5
    80002bf8:	86450513          	addi	a0,a0,-1948 # 80007458 <etext+0x458>
    80002bfc:	bf5fd0ef          	jal	800007f0 <panic>

0000000080002c00 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002c00:	1101                	addi	sp,sp,-32
    80002c02:	ec06                	sd	ra,24(sp)
    80002c04:	e822                	sd	s0,16(sp)
    80002c06:	e426                	sd	s1,8(sp)
    80002c08:	e04a                	sd	s2,0(sp)
    80002c0a:	1000                	addi	s0,sp,32
    80002c0c:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002c0e:	01050913          	addi	s2,a0,16
    80002c12:	854a                	mv	a0,s2
    80002c14:	1cc010ef          	jal	80003de0 <holdingsleep>
    80002c18:	c125                	beqz	a0,80002c78 <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    80002c1a:	854a                	mv	a0,s2
    80002c1c:	18c010ef          	jal	80003da8 <releasesleep>

  acquire(&bcache.lock);
    80002c20:	00013517          	auipc	a0,0x13
    80002c24:	c6850513          	addi	a0,a0,-920 # 80015888 <bcache>
    80002c28:	83cfe0ef          	jal	80000c64 <acquire>
  b->refcnt--;
    80002c2c:	40bc                	lw	a5,64(s1)
    80002c2e:	37fd                	addiw	a5,a5,-1
    80002c30:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002c32:	e79d                	bnez	a5,80002c60 <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002c34:	68b8                	ld	a4,80(s1)
    80002c36:	64bc                	ld	a5,72(s1)
    80002c38:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002c3a:	68b8                	ld	a4,80(s1)
    80002c3c:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002c3e:	0001b797          	auipc	a5,0x1b
    80002c42:	c4a78793          	addi	a5,a5,-950 # 8001d888 <bcache+0x8000>
    80002c46:	2b87b703          	ld	a4,696(a5)
    80002c4a:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002c4c:	0001b717          	auipc	a4,0x1b
    80002c50:	ea470713          	addi	a4,a4,-348 # 8001daf0 <bcache+0x8268>
    80002c54:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002c56:	2b87b703          	ld	a4,696(a5)
    80002c5a:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002c5c:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    80002c60:	00013517          	auipc	a0,0x13
    80002c64:	c2850513          	addi	a0,a0,-984 # 80015888 <bcache>
    80002c68:	88cfe0ef          	jal	80000cf4 <release>
}
    80002c6c:	60e2                	ld	ra,24(sp)
    80002c6e:	6442                	ld	s0,16(sp)
    80002c70:	64a2                	ld	s1,8(sp)
    80002c72:	6902                	ld	s2,0(sp)
    80002c74:	6105                	addi	sp,sp,32
    80002c76:	8082                	ret
    panic("brelse");
    80002c78:	00004517          	auipc	a0,0x4
    80002c7c:	7e850513          	addi	a0,a0,2024 # 80007460 <etext+0x460>
    80002c80:	b71fd0ef          	jal	800007f0 <panic>

0000000080002c84 <bpin>:

void
bpin(struct buf *b) {
    80002c84:	1101                	addi	sp,sp,-32
    80002c86:	ec06                	sd	ra,24(sp)
    80002c88:	e822                	sd	s0,16(sp)
    80002c8a:	e426                	sd	s1,8(sp)
    80002c8c:	1000                	addi	s0,sp,32
    80002c8e:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002c90:	00013517          	auipc	a0,0x13
    80002c94:	bf850513          	addi	a0,a0,-1032 # 80015888 <bcache>
    80002c98:	fcdfd0ef          	jal	80000c64 <acquire>
  b->refcnt++;
    80002c9c:	40bc                	lw	a5,64(s1)
    80002c9e:	2785                	addiw	a5,a5,1
    80002ca0:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002ca2:	00013517          	auipc	a0,0x13
    80002ca6:	be650513          	addi	a0,a0,-1050 # 80015888 <bcache>
    80002caa:	84afe0ef          	jal	80000cf4 <release>
}
    80002cae:	60e2                	ld	ra,24(sp)
    80002cb0:	6442                	ld	s0,16(sp)
    80002cb2:	64a2                	ld	s1,8(sp)
    80002cb4:	6105                	addi	sp,sp,32
    80002cb6:	8082                	ret

0000000080002cb8 <bunpin>:

void
bunpin(struct buf *b) {
    80002cb8:	1101                	addi	sp,sp,-32
    80002cba:	ec06                	sd	ra,24(sp)
    80002cbc:	e822                	sd	s0,16(sp)
    80002cbe:	e426                	sd	s1,8(sp)
    80002cc0:	1000                	addi	s0,sp,32
    80002cc2:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002cc4:	00013517          	auipc	a0,0x13
    80002cc8:	bc450513          	addi	a0,a0,-1084 # 80015888 <bcache>
    80002ccc:	f99fd0ef          	jal	80000c64 <acquire>
  b->refcnt--;
    80002cd0:	40bc                	lw	a5,64(s1)
    80002cd2:	37fd                	addiw	a5,a5,-1
    80002cd4:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002cd6:	00013517          	auipc	a0,0x13
    80002cda:	bb250513          	addi	a0,a0,-1102 # 80015888 <bcache>
    80002cde:	816fe0ef          	jal	80000cf4 <release>
}
    80002ce2:	60e2                	ld	ra,24(sp)
    80002ce4:	6442                	ld	s0,16(sp)
    80002ce6:	64a2                	ld	s1,8(sp)
    80002ce8:	6105                	addi	sp,sp,32
    80002cea:	8082                	ret

0000000080002cec <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002cec:	1101                	addi	sp,sp,-32
    80002cee:	ec06                	sd	ra,24(sp)
    80002cf0:	e822                	sd	s0,16(sp)
    80002cf2:	e426                	sd	s1,8(sp)
    80002cf4:	e04a                	sd	s2,0(sp)
    80002cf6:	1000                	addi	s0,sp,32
    80002cf8:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002cfa:	00d5d79b          	srliw	a5,a1,0xd
    80002cfe:	0001b597          	auipc	a1,0x1b
    80002d02:	2665a583          	lw	a1,614(a1) # 8001df64 <sb+0x1c>
    80002d06:	9dbd                	addw	a1,a1,a5
    80002d08:	df1ff0ef          	jal	80002af8 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002d0c:	0074f713          	andi	a4,s1,7
    80002d10:	4785                	li	a5,1
    80002d12:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    80002d16:	14ce                	slli	s1,s1,0x33
  if((bp->data[bi/8] & m) == 0)
    80002d18:	90d9                	srli	s1,s1,0x36
    80002d1a:	00950733          	add	a4,a0,s1
    80002d1e:	05874703          	lbu	a4,88(a4)
    80002d22:	00e7f6b3          	and	a3,a5,a4
    80002d26:	c29d                	beqz	a3,80002d4c <bfree+0x60>
    80002d28:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80002d2a:	94aa                	add	s1,s1,a0
    80002d2c:	fff7c793          	not	a5,a5
    80002d30:	8f7d                	and	a4,a4,a5
    80002d32:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002d36:	729000ef          	jal	80003c5e <log_write>
  brelse(bp);
    80002d3a:	854a                	mv	a0,s2
    80002d3c:	ec5ff0ef          	jal	80002c00 <brelse>
}
    80002d40:	60e2                	ld	ra,24(sp)
    80002d42:	6442                	ld	s0,16(sp)
    80002d44:	64a2                	ld	s1,8(sp)
    80002d46:	6902                	ld	s2,0(sp)
    80002d48:	6105                	addi	sp,sp,32
    80002d4a:	8082                	ret
    panic("freeing free block");
    80002d4c:	00004517          	auipc	a0,0x4
    80002d50:	71c50513          	addi	a0,a0,1820 # 80007468 <etext+0x468>
    80002d54:	a9dfd0ef          	jal	800007f0 <panic>

0000000080002d58 <balloc>:
{
    80002d58:	715d                	addi	sp,sp,-80
    80002d5a:	e486                	sd	ra,72(sp)
    80002d5c:	e0a2                	sd	s0,64(sp)
    80002d5e:	fc26                	sd	s1,56(sp)
    80002d60:	0880                	addi	s0,sp,80
  for(b = 0; b < sb.size; b += BPB){
    80002d62:	0001b797          	auipc	a5,0x1b
    80002d66:	1ea7a783          	lw	a5,490(a5) # 8001df4c <sb+0x4>
    80002d6a:	0e078263          	beqz	a5,80002e4e <balloc+0xf6>
    80002d6e:	f84a                	sd	s2,48(sp)
    80002d70:	f44e                	sd	s3,40(sp)
    80002d72:	f052                	sd	s4,32(sp)
    80002d74:	ec56                	sd	s5,24(sp)
    80002d76:	e85a                	sd	s6,16(sp)
    80002d78:	e45e                	sd	s7,8(sp)
    80002d7a:	e062                	sd	s8,0(sp)
    80002d7c:	8baa                	mv	s7,a0
    80002d7e:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002d80:	0001bb17          	auipc	s6,0x1b
    80002d84:	1c8b0b13          	addi	s6,s6,456 # 8001df48 <sb>
      m = 1 << (bi % 8);
    80002d88:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002d8a:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80002d8c:	6c09                	lui	s8,0x2
    80002d8e:	a09d                	j	80002df4 <balloc+0x9c>
        bp->data[bi/8] |= m;  // Mark block in use.
    80002d90:	97ca                	add	a5,a5,s2
    80002d92:	8e55                	or	a2,a2,a3
    80002d94:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80002d98:	854a                	mv	a0,s2
    80002d9a:	6c5000ef          	jal	80003c5e <log_write>
        brelse(bp);
    80002d9e:	854a                	mv	a0,s2
    80002da0:	e61ff0ef          	jal	80002c00 <brelse>
  bp = bread(dev, bno);
    80002da4:	85a6                	mv	a1,s1
    80002da6:	855e                	mv	a0,s7
    80002da8:	d51ff0ef          	jal	80002af8 <bread>
    80002dac:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002dae:	40000613          	li	a2,1024
    80002db2:	4581                	li	a1,0
    80002db4:	05850513          	addi	a0,a0,88
    80002db8:	f79fd0ef          	jal	80000d30 <memset>
  log_write(bp);
    80002dbc:	854a                	mv	a0,s2
    80002dbe:	6a1000ef          	jal	80003c5e <log_write>
  brelse(bp);
    80002dc2:	854a                	mv	a0,s2
    80002dc4:	e3dff0ef          	jal	80002c00 <brelse>
        return b + bi;
    80002dc8:	7942                	ld	s2,48(sp)
    80002dca:	79a2                	ld	s3,40(sp)
    80002dcc:	7a02                	ld	s4,32(sp)
    80002dce:	6ae2                	ld	s5,24(sp)
    80002dd0:	6b42                	ld	s6,16(sp)
    80002dd2:	6ba2                	ld	s7,8(sp)
    80002dd4:	6c02                	ld	s8,0(sp)
}
    80002dd6:	8526                	mv	a0,s1
    80002dd8:	60a6                	ld	ra,72(sp)
    80002dda:	6406                	ld	s0,64(sp)
    80002ddc:	74e2                	ld	s1,56(sp)
    80002dde:	6161                	addi	sp,sp,80
    80002de0:	8082                	ret
    brelse(bp);
    80002de2:	854a                	mv	a0,s2
    80002de4:	e1dff0ef          	jal	80002c00 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002de8:	015c0abb          	addw	s5,s8,s5
    80002dec:	004b2783          	lw	a5,4(s6)
    80002df0:	04faf863          	bgeu	s5,a5,80002e40 <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    80002df4:	40dad59b          	sraiw	a1,s5,0xd
    80002df8:	01cb2783          	lw	a5,28(s6)
    80002dfc:	9dbd                	addw	a1,a1,a5
    80002dfe:	855e                	mv	a0,s7
    80002e00:	cf9ff0ef          	jal	80002af8 <bread>
    80002e04:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002e06:	004b2503          	lw	a0,4(s6)
    80002e0a:	84d6                	mv	s1,s5
    80002e0c:	4701                	li	a4,0
    80002e0e:	fca4fae3          	bgeu	s1,a0,80002de2 <balloc+0x8a>
      m = 1 << (bi % 8);
    80002e12:	00777693          	andi	a3,a4,7
    80002e16:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80002e1a:	41f7579b          	sraiw	a5,a4,0x1f
    80002e1e:	01d7d79b          	srliw	a5,a5,0x1d
    80002e22:	9fb9                	addw	a5,a5,a4
    80002e24:	4037d79b          	sraiw	a5,a5,0x3
    80002e28:	00f90633          	add	a2,s2,a5
    80002e2c:	05864603          	lbu	a2,88(a2)
    80002e30:	00c6f5b3          	and	a1,a3,a2
    80002e34:	ddb1                	beqz	a1,80002d90 <balloc+0x38>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002e36:	2705                	addiw	a4,a4,1
    80002e38:	2485                	addiw	s1,s1,1
    80002e3a:	fd471ae3          	bne	a4,s4,80002e0e <balloc+0xb6>
    80002e3e:	b755                	j	80002de2 <balloc+0x8a>
    80002e40:	7942                	ld	s2,48(sp)
    80002e42:	79a2                	ld	s3,40(sp)
    80002e44:	7a02                	ld	s4,32(sp)
    80002e46:	6ae2                	ld	s5,24(sp)
    80002e48:	6b42                	ld	s6,16(sp)
    80002e4a:	6ba2                	ld	s7,8(sp)
    80002e4c:	6c02                	ld	s8,0(sp)
  printf("balloc: out of blocks\n");
    80002e4e:	00004517          	auipc	a0,0x4
    80002e52:	63250513          	addi	a0,a0,1586 # 80007480 <etext+0x480>
    80002e56:	e7cfd0ef          	jal	800004d2 <printf>
  return 0;
    80002e5a:	4481                	li	s1,0
    80002e5c:	bfad                	j	80002dd6 <balloc+0x7e>

0000000080002e5e <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80002e5e:	7179                	addi	sp,sp,-48
    80002e60:	f406                	sd	ra,40(sp)
    80002e62:	f022                	sd	s0,32(sp)
    80002e64:	ec26                	sd	s1,24(sp)
    80002e66:	e84a                	sd	s2,16(sp)
    80002e68:	e44e                	sd	s3,8(sp)
    80002e6a:	1800                	addi	s0,sp,48
    80002e6c:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    80002e6e:	47ad                	li	a5,11
    80002e70:	02b7e363          	bltu	a5,a1,80002e96 <bmap+0x38>
    if((addr = ip->addrs[bn]) == 0){
    80002e74:	02059793          	slli	a5,a1,0x20
    80002e78:	01e7d593          	srli	a1,a5,0x1e
    80002e7c:	00b509b3          	add	s3,a0,a1
    80002e80:	0509a483          	lw	s1,80(s3)
    80002e84:	e0b5                	bnez	s1,80002ee8 <bmap+0x8a>
      addr = balloc(ip->dev);
    80002e86:	4108                	lw	a0,0(a0)
    80002e88:	ed1ff0ef          	jal	80002d58 <balloc>
    80002e8c:	84aa                	mv	s1,a0
      if(addr == 0)
    80002e8e:	cd29                	beqz	a0,80002ee8 <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    80002e90:	04a9a823          	sw	a0,80(s3)
    80002e94:	a891                	j	80002ee8 <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80002e96:	ff45879b          	addiw	a5,a1,-12
    80002e9a:	873e                	mv	a4,a5
    80002e9c:	89be                	mv	s3,a5

  if(bn < NINDIRECT){
    80002e9e:	0ff00793          	li	a5,255
    80002ea2:	06e7e763          	bltu	a5,a4,80002f10 <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    80002ea6:	08052483          	lw	s1,128(a0)
    80002eaa:	e891                	bnez	s1,80002ebe <bmap+0x60>
      addr = balloc(ip->dev);
    80002eac:	4108                	lw	a0,0(a0)
    80002eae:	eabff0ef          	jal	80002d58 <balloc>
    80002eb2:	84aa                	mv	s1,a0
      if(addr == 0)
    80002eb4:	c915                	beqz	a0,80002ee8 <bmap+0x8a>
    80002eb6:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002eb8:	08a92023          	sw	a0,128(s2)
    80002ebc:	a011                	j	80002ec0 <bmap+0x62>
    80002ebe:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80002ec0:	85a6                	mv	a1,s1
    80002ec2:	00092503          	lw	a0,0(s2)
    80002ec6:	c33ff0ef          	jal	80002af8 <bread>
    80002eca:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80002ecc:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80002ed0:	02099713          	slli	a4,s3,0x20
    80002ed4:	01e75593          	srli	a1,a4,0x1e
    80002ed8:	97ae                	add	a5,a5,a1
    80002eda:	89be                	mv	s3,a5
    80002edc:	4384                	lw	s1,0(a5)
    80002ede:	cc89                	beqz	s1,80002ef8 <bmap+0x9a>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80002ee0:	8552                	mv	a0,s4
    80002ee2:	d1fff0ef          	jal	80002c00 <brelse>
    return addr;
    80002ee6:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80002ee8:	8526                	mv	a0,s1
    80002eea:	70a2                	ld	ra,40(sp)
    80002eec:	7402                	ld	s0,32(sp)
    80002eee:	64e2                	ld	s1,24(sp)
    80002ef0:	6942                	ld	s2,16(sp)
    80002ef2:	69a2                	ld	s3,8(sp)
    80002ef4:	6145                	addi	sp,sp,48
    80002ef6:	8082                	ret
      addr = balloc(ip->dev);
    80002ef8:	00092503          	lw	a0,0(s2)
    80002efc:	e5dff0ef          	jal	80002d58 <balloc>
    80002f00:	84aa                	mv	s1,a0
      if(addr){
    80002f02:	dd79                	beqz	a0,80002ee0 <bmap+0x82>
        a[bn] = addr;
    80002f04:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    80002f08:	8552                	mv	a0,s4
    80002f0a:	555000ef          	jal	80003c5e <log_write>
    80002f0e:	bfc9                	j	80002ee0 <bmap+0x82>
    80002f10:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    80002f12:	00004517          	auipc	a0,0x4
    80002f16:	58650513          	addi	a0,a0,1414 # 80007498 <etext+0x498>
    80002f1a:	8d7fd0ef          	jal	800007f0 <panic>

0000000080002f1e <iget>:
{
    80002f1e:	7179                	addi	sp,sp,-48
    80002f20:	f406                	sd	ra,40(sp)
    80002f22:	f022                	sd	s0,32(sp)
    80002f24:	ec26                	sd	s1,24(sp)
    80002f26:	e84a                	sd	s2,16(sp)
    80002f28:	e44e                	sd	s3,8(sp)
    80002f2a:	e052                	sd	s4,0(sp)
    80002f2c:	1800                	addi	s0,sp,48
    80002f2e:	89aa                	mv	s3,a0
    80002f30:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80002f32:	0001b517          	auipc	a0,0x1b
    80002f36:	03650513          	addi	a0,a0,54 # 8001df68 <itable>
    80002f3a:	d2bfd0ef          	jal	80000c64 <acquire>
  empty = 0;
    80002f3e:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80002f40:	0001b497          	auipc	s1,0x1b
    80002f44:	04048493          	addi	s1,s1,64 # 8001df80 <itable+0x18>
    80002f48:	0001d697          	auipc	a3,0x1d
    80002f4c:	ac868693          	addi	a3,a3,-1336 # 8001fa10 <log>
    80002f50:	a819                	j	80002f66 <iget+0x48>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80002f52:	0017b793          	seqz	a5,a5
    80002f56:	00193713          	seqz	a4,s2
    80002f5a:	8ff9                	and	a5,a5,a4
    80002f5c:	eb85                	bnez	a5,80002f8c <iget+0x6e>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80002f5e:	08848493          	addi	s1,s1,136
    80002f62:	02d48763          	beq	s1,a3,80002f90 <iget+0x72>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    80002f66:	449c                	lw	a5,8(s1)
    80002f68:	fef055e3          	blez	a5,80002f52 <iget+0x34>
    80002f6c:	4098                	lw	a4,0(s1)
    80002f6e:	ff3718e3          	bne	a4,s3,80002f5e <iget+0x40>
    80002f72:	40d8                	lw	a4,4(s1)
    80002f74:	ff4715e3          	bne	a4,s4,80002f5e <iget+0x40>
      ip->ref++;
    80002f78:	2785                	addiw	a5,a5,1
    80002f7a:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80002f7c:	0001b517          	auipc	a0,0x1b
    80002f80:	fec50513          	addi	a0,a0,-20 # 8001df68 <itable>
    80002f84:	d71fd0ef          	jal	80000cf4 <release>
      return ip;
    80002f88:	8926                	mv	s2,s1
    80002f8a:	a025                	j	80002fb2 <iget+0x94>
      empty = ip;
    80002f8c:	8926                	mv	s2,s1
    80002f8e:	bfc1                	j	80002f5e <iget+0x40>
  if(empty == 0)
    80002f90:	02090a63          	beqz	s2,80002fc4 <iget+0xa6>
  ip->dev = dev;
    80002f94:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    80002f98:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    80002f9c:	4785                	li	a5,1
    80002f9e:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    80002fa2:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    80002fa6:	0001b517          	auipc	a0,0x1b
    80002faa:	fc250513          	addi	a0,a0,-62 # 8001df68 <itable>
    80002fae:	d47fd0ef          	jal	80000cf4 <release>
}
    80002fb2:	854a                	mv	a0,s2
    80002fb4:	70a2                	ld	ra,40(sp)
    80002fb6:	7402                	ld	s0,32(sp)
    80002fb8:	64e2                	ld	s1,24(sp)
    80002fba:	6942                	ld	s2,16(sp)
    80002fbc:	69a2                	ld	s3,8(sp)
    80002fbe:	6a02                	ld	s4,0(sp)
    80002fc0:	6145                	addi	sp,sp,48
    80002fc2:	8082                	ret
    panic("iget: no inodes");
    80002fc4:	00004517          	auipc	a0,0x4
    80002fc8:	4ec50513          	addi	a0,a0,1260 # 800074b0 <etext+0x4b0>
    80002fcc:	825fd0ef          	jal	800007f0 <panic>

0000000080002fd0 <fsinit>:
fsinit(int dev) {
    80002fd0:	1101                	addi	sp,sp,-32
    80002fd2:	ec06                	sd	ra,24(sp)
    80002fd4:	e822                	sd	s0,16(sp)
    80002fd6:	e426                	sd	s1,8(sp)
    80002fd8:	e04a                	sd	s2,0(sp)
    80002fda:	1000                	addi	s0,sp,32
    80002fdc:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80002fde:	4585                	li	a1,1
    80002fe0:	b19ff0ef          	jal	80002af8 <bread>
    80002fe4:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80002fe6:	02000613          	li	a2,32
    80002fea:	05850593          	addi	a1,a0,88
    80002fee:	0001b517          	auipc	a0,0x1b
    80002ff2:	f5a50513          	addi	a0,a0,-166 # 8001df48 <sb>
    80002ff6:	d97fd0ef          	jal	80000d8c <memmove>
  brelse(bp);
    80002ffa:	8526                	mv	a0,s1
    80002ffc:	c05ff0ef          	jal	80002c00 <brelse>
  if(sb.magic != FSMAGIC)
    80003000:	0001b717          	auipc	a4,0x1b
    80003004:	f4872703          	lw	a4,-184(a4) # 8001df48 <sb>
    80003008:	102037b7          	lui	a5,0x10203
    8000300c:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80003010:	00f71f63          	bne	a4,a5,8000302e <fsinit+0x5e>
  initlog(dev, &sb);
    80003014:	0001b597          	auipc	a1,0x1b
    80003018:	f3458593          	addi	a1,a1,-204 # 8001df48 <sb>
    8000301c:	854a                	mv	a0,s2
    8000301e:	223000ef          	jal	80003a40 <initlog>
}
    80003022:	60e2                	ld	ra,24(sp)
    80003024:	6442                	ld	s0,16(sp)
    80003026:	64a2                	ld	s1,8(sp)
    80003028:	6902                	ld	s2,0(sp)
    8000302a:	6105                	addi	sp,sp,32
    8000302c:	8082                	ret
    panic("invalid file system");
    8000302e:	00004517          	auipc	a0,0x4
    80003032:	49250513          	addi	a0,a0,1170 # 800074c0 <etext+0x4c0>
    80003036:	fbafd0ef          	jal	800007f0 <panic>

000000008000303a <iinit>:
{
    8000303a:	7179                	addi	sp,sp,-48
    8000303c:	f406                	sd	ra,40(sp)
    8000303e:	f022                	sd	s0,32(sp)
    80003040:	ec26                	sd	s1,24(sp)
    80003042:	e84a                	sd	s2,16(sp)
    80003044:	e44e                	sd	s3,8(sp)
    80003046:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80003048:	00004597          	auipc	a1,0x4
    8000304c:	49058593          	addi	a1,a1,1168 # 800074d8 <etext+0x4d8>
    80003050:	0001b517          	auipc	a0,0x1b
    80003054:	f1850513          	addi	a0,a0,-232 # 8001df68 <itable>
    80003058:	b83fd0ef          	jal	80000bda <initlock>
  for(i = 0; i < NINODE; i++) {
    8000305c:	0001b497          	auipc	s1,0x1b
    80003060:	f3448493          	addi	s1,s1,-204 # 8001df90 <itable+0x28>
    80003064:	0001d997          	auipc	s3,0x1d
    80003068:	9bc98993          	addi	s3,s3,-1604 # 8001fa20 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    8000306c:	00004917          	auipc	s2,0x4
    80003070:	47490913          	addi	s2,s2,1140 # 800074e0 <etext+0x4e0>
    80003074:	85ca                	mv	a1,s2
    80003076:	8526                	mv	a0,s1
    80003078:	4b5000ef          	jal	80003d2c <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    8000307c:	08848493          	addi	s1,s1,136
    80003080:	ff349ae3          	bne	s1,s3,80003074 <iinit+0x3a>
}
    80003084:	70a2                	ld	ra,40(sp)
    80003086:	7402                	ld	s0,32(sp)
    80003088:	64e2                	ld	s1,24(sp)
    8000308a:	6942                	ld	s2,16(sp)
    8000308c:	69a2                	ld	s3,8(sp)
    8000308e:	6145                	addi	sp,sp,48
    80003090:	8082                	ret

0000000080003092 <ialloc>:
{
    80003092:	7139                	addi	sp,sp,-64
    80003094:	fc06                	sd	ra,56(sp)
    80003096:	f822                	sd	s0,48(sp)
    80003098:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    8000309a:	0001b717          	auipc	a4,0x1b
    8000309e:	eba72703          	lw	a4,-326(a4) # 8001df54 <sb+0xc>
    800030a2:	4785                	li	a5,1
    800030a4:	06e7f063          	bgeu	a5,a4,80003104 <ialloc+0x72>
    800030a8:	f426                	sd	s1,40(sp)
    800030aa:	f04a                	sd	s2,32(sp)
    800030ac:	ec4e                	sd	s3,24(sp)
    800030ae:	e852                	sd	s4,16(sp)
    800030b0:	e456                	sd	s5,8(sp)
    800030b2:	e05a                	sd	s6,0(sp)
    800030b4:	8aaa                	mv	s5,a0
    800030b6:	8b2e                	mv	s6,a1
    800030b8:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    800030ba:	0001ba17          	auipc	s4,0x1b
    800030be:	e8ea0a13          	addi	s4,s4,-370 # 8001df48 <sb>
    800030c2:	00495593          	srli	a1,s2,0x4
    800030c6:	018a2783          	lw	a5,24(s4)
    800030ca:	9dbd                	addw	a1,a1,a5
    800030cc:	8556                	mv	a0,s5
    800030ce:	a2bff0ef          	jal	80002af8 <bread>
    800030d2:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    800030d4:	05850993          	addi	s3,a0,88
    800030d8:	00f97793          	andi	a5,s2,15
    800030dc:	079a                	slli	a5,a5,0x6
    800030de:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    800030e0:	00099783          	lh	a5,0(s3)
    800030e4:	cb9d                	beqz	a5,8000311a <ialloc+0x88>
    brelse(bp);
    800030e6:	b1bff0ef          	jal	80002c00 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    800030ea:	0905                	addi	s2,s2,1
    800030ec:	00ca2703          	lw	a4,12(s4)
    800030f0:	0009079b          	sext.w	a5,s2
    800030f4:	fce7e7e3          	bltu	a5,a4,800030c2 <ialloc+0x30>
    800030f8:	74a2                	ld	s1,40(sp)
    800030fa:	7902                	ld	s2,32(sp)
    800030fc:	69e2                	ld	s3,24(sp)
    800030fe:	6a42                	ld	s4,16(sp)
    80003100:	6aa2                	ld	s5,8(sp)
    80003102:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    80003104:	00004517          	auipc	a0,0x4
    80003108:	3e450513          	addi	a0,a0,996 # 800074e8 <etext+0x4e8>
    8000310c:	bc6fd0ef          	jal	800004d2 <printf>
  return 0;
    80003110:	4501                	li	a0,0
}
    80003112:	70e2                	ld	ra,56(sp)
    80003114:	7442                	ld	s0,48(sp)
    80003116:	6121                	addi	sp,sp,64
    80003118:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    8000311a:	04000613          	li	a2,64
    8000311e:	4581                	li	a1,0
    80003120:	854e                	mv	a0,s3
    80003122:	c0ffd0ef          	jal	80000d30 <memset>
      dip->type = type;
    80003126:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    8000312a:	8526                	mv	a0,s1
    8000312c:	333000ef          	jal	80003c5e <log_write>
      brelse(bp);
    80003130:	8526                	mv	a0,s1
    80003132:	acfff0ef          	jal	80002c00 <brelse>
      return iget(dev, inum);
    80003136:	0009059b          	sext.w	a1,s2
    8000313a:	8556                	mv	a0,s5
    8000313c:	de3ff0ef          	jal	80002f1e <iget>
    80003140:	74a2                	ld	s1,40(sp)
    80003142:	7902                	ld	s2,32(sp)
    80003144:	69e2                	ld	s3,24(sp)
    80003146:	6a42                	ld	s4,16(sp)
    80003148:	6aa2                	ld	s5,8(sp)
    8000314a:	6b02                	ld	s6,0(sp)
    8000314c:	b7d9                	j	80003112 <ialloc+0x80>

000000008000314e <iupdate>:
{
    8000314e:	1101                	addi	sp,sp,-32
    80003150:	ec06                	sd	ra,24(sp)
    80003152:	e822                	sd	s0,16(sp)
    80003154:	e426                	sd	s1,8(sp)
    80003156:	e04a                	sd	s2,0(sp)
    80003158:	1000                	addi	s0,sp,32
    8000315a:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    8000315c:	415c                	lw	a5,4(a0)
    8000315e:	0047d79b          	srliw	a5,a5,0x4
    80003162:	0001b597          	auipc	a1,0x1b
    80003166:	dfe5a583          	lw	a1,-514(a1) # 8001df60 <sb+0x18>
    8000316a:	9dbd                	addw	a1,a1,a5
    8000316c:	4108                	lw	a0,0(a0)
    8000316e:	98bff0ef          	jal	80002af8 <bread>
    80003172:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    80003174:	05850793          	addi	a5,a0,88
    80003178:	40d8                	lw	a4,4(s1)
    8000317a:	8b3d                	andi	a4,a4,15
    8000317c:	071a                	slli	a4,a4,0x6
    8000317e:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80003180:	04449703          	lh	a4,68(s1)
    80003184:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    80003188:	04649703          	lh	a4,70(s1)
    8000318c:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80003190:	04849703          	lh	a4,72(s1)
    80003194:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    80003198:	04a49703          	lh	a4,74(s1)
    8000319c:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    800031a0:	44f8                	lw	a4,76(s1)
    800031a2:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    800031a4:	03400613          	li	a2,52
    800031a8:	05048593          	addi	a1,s1,80
    800031ac:	00c78513          	addi	a0,a5,12
    800031b0:	bddfd0ef          	jal	80000d8c <memmove>
  log_write(bp);
    800031b4:	854a                	mv	a0,s2
    800031b6:	2a9000ef          	jal	80003c5e <log_write>
  brelse(bp);
    800031ba:	854a                	mv	a0,s2
    800031bc:	a45ff0ef          	jal	80002c00 <brelse>
}
    800031c0:	60e2                	ld	ra,24(sp)
    800031c2:	6442                	ld	s0,16(sp)
    800031c4:	64a2                	ld	s1,8(sp)
    800031c6:	6902                	ld	s2,0(sp)
    800031c8:	6105                	addi	sp,sp,32
    800031ca:	8082                	ret

00000000800031cc <idup>:
{
    800031cc:	1101                	addi	sp,sp,-32
    800031ce:	ec06                	sd	ra,24(sp)
    800031d0:	e822                	sd	s0,16(sp)
    800031d2:	e426                	sd	s1,8(sp)
    800031d4:	1000                	addi	s0,sp,32
    800031d6:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800031d8:	0001b517          	auipc	a0,0x1b
    800031dc:	d9050513          	addi	a0,a0,-624 # 8001df68 <itable>
    800031e0:	a85fd0ef          	jal	80000c64 <acquire>
  ip->ref++;
    800031e4:	449c                	lw	a5,8(s1)
    800031e6:	2785                	addiw	a5,a5,1
    800031e8:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800031ea:	0001b517          	auipc	a0,0x1b
    800031ee:	d7e50513          	addi	a0,a0,-642 # 8001df68 <itable>
    800031f2:	b03fd0ef          	jal	80000cf4 <release>
}
    800031f6:	8526                	mv	a0,s1
    800031f8:	60e2                	ld	ra,24(sp)
    800031fa:	6442                	ld	s0,16(sp)
    800031fc:	64a2                	ld	s1,8(sp)
    800031fe:	6105                	addi	sp,sp,32
    80003200:	8082                	ret

0000000080003202 <ilock>:
{
    80003202:	1101                	addi	sp,sp,-32
    80003204:	ec06                	sd	ra,24(sp)
    80003206:	e822                	sd	s0,16(sp)
    80003208:	e426                	sd	s1,8(sp)
    8000320a:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    8000320c:	cd19                	beqz	a0,8000322a <ilock+0x28>
    8000320e:	84aa                	mv	s1,a0
    80003210:	451c                	lw	a5,8(a0)
    80003212:	00f05c63          	blez	a5,8000322a <ilock+0x28>
  acquiresleep(&ip->lock);
    80003216:	0541                	addi	a0,a0,16
    80003218:	34b000ef          	jal	80003d62 <acquiresleep>
  if(ip->valid == 0){
    8000321c:	40bc                	lw	a5,64(s1)
    8000321e:	cf89                	beqz	a5,80003238 <ilock+0x36>
}
    80003220:	60e2                	ld	ra,24(sp)
    80003222:	6442                	ld	s0,16(sp)
    80003224:	64a2                	ld	s1,8(sp)
    80003226:	6105                	addi	sp,sp,32
    80003228:	8082                	ret
    8000322a:	e04a                	sd	s2,0(sp)
    panic("ilock");
    8000322c:	00004517          	auipc	a0,0x4
    80003230:	2d450513          	addi	a0,a0,724 # 80007500 <etext+0x500>
    80003234:	dbcfd0ef          	jal	800007f0 <panic>
    80003238:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    8000323a:	40dc                	lw	a5,4(s1)
    8000323c:	0047d79b          	srliw	a5,a5,0x4
    80003240:	0001b597          	auipc	a1,0x1b
    80003244:	d205a583          	lw	a1,-736(a1) # 8001df60 <sb+0x18>
    80003248:	9dbd                	addw	a1,a1,a5
    8000324a:	4088                	lw	a0,0(s1)
    8000324c:	8adff0ef          	jal	80002af8 <bread>
    80003250:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    80003252:	05850593          	addi	a1,a0,88
    80003256:	40dc                	lw	a5,4(s1)
    80003258:	8bbd                	andi	a5,a5,15
    8000325a:	079a                	slli	a5,a5,0x6
    8000325c:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    8000325e:	00059783          	lh	a5,0(a1)
    80003262:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    80003266:	00259783          	lh	a5,2(a1)
    8000326a:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    8000326e:	00459783          	lh	a5,4(a1)
    80003272:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    80003276:	00659783          	lh	a5,6(a1)
    8000327a:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    8000327e:	459c                	lw	a5,8(a1)
    80003280:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80003282:	03400613          	li	a2,52
    80003286:	05b1                	addi	a1,a1,12
    80003288:	05048513          	addi	a0,s1,80
    8000328c:	b01fd0ef          	jal	80000d8c <memmove>
    brelse(bp);
    80003290:	854a                	mv	a0,s2
    80003292:	96fff0ef          	jal	80002c00 <brelse>
    ip->valid = 1;
    80003296:	4785                	li	a5,1
    80003298:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    8000329a:	04449783          	lh	a5,68(s1)
    8000329e:	c399                	beqz	a5,800032a4 <ilock+0xa2>
    800032a0:	6902                	ld	s2,0(sp)
    800032a2:	bfbd                	j	80003220 <ilock+0x1e>
      panic("ilock: no type");
    800032a4:	00004517          	auipc	a0,0x4
    800032a8:	26450513          	addi	a0,a0,612 # 80007508 <etext+0x508>
    800032ac:	d44fd0ef          	jal	800007f0 <panic>

00000000800032b0 <iunlock>:
{
    800032b0:	1101                	addi	sp,sp,-32
    800032b2:	ec06                	sd	ra,24(sp)
    800032b4:	e822                	sd	s0,16(sp)
    800032b6:	e426                	sd	s1,8(sp)
    800032b8:	e04a                	sd	s2,0(sp)
    800032ba:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    800032bc:	c505                	beqz	a0,800032e4 <iunlock+0x34>
    800032be:	84aa                	mv	s1,a0
    800032c0:	01050913          	addi	s2,a0,16
    800032c4:	854a                	mv	a0,s2
    800032c6:	31b000ef          	jal	80003de0 <holdingsleep>
    800032ca:	cd09                	beqz	a0,800032e4 <iunlock+0x34>
    800032cc:	449c                	lw	a5,8(s1)
    800032ce:	00f05b63          	blez	a5,800032e4 <iunlock+0x34>
  releasesleep(&ip->lock);
    800032d2:	854a                	mv	a0,s2
    800032d4:	2d5000ef          	jal	80003da8 <releasesleep>
}
    800032d8:	60e2                	ld	ra,24(sp)
    800032da:	6442                	ld	s0,16(sp)
    800032dc:	64a2                	ld	s1,8(sp)
    800032de:	6902                	ld	s2,0(sp)
    800032e0:	6105                	addi	sp,sp,32
    800032e2:	8082                	ret
    panic("iunlock");
    800032e4:	00004517          	auipc	a0,0x4
    800032e8:	23450513          	addi	a0,a0,564 # 80007518 <etext+0x518>
    800032ec:	d04fd0ef          	jal	800007f0 <panic>

00000000800032f0 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    800032f0:	7179                	addi	sp,sp,-48
    800032f2:	f406                	sd	ra,40(sp)
    800032f4:	f022                	sd	s0,32(sp)
    800032f6:	ec26                	sd	s1,24(sp)
    800032f8:	e84a                	sd	s2,16(sp)
    800032fa:	e44e                	sd	s3,8(sp)
    800032fc:	1800                	addi	s0,sp,48
    800032fe:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    80003300:	05050493          	addi	s1,a0,80
    80003304:	08050913          	addi	s2,a0,128
    80003308:	a021                	j	80003310 <itrunc+0x20>
    8000330a:	0491                	addi	s1,s1,4
    8000330c:	01248b63          	beq	s1,s2,80003322 <itrunc+0x32>
    if(ip->addrs[i]){
    80003310:	408c                	lw	a1,0(s1)
    80003312:	dde5                	beqz	a1,8000330a <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    80003314:	0009a503          	lw	a0,0(s3)
    80003318:	9d5ff0ef          	jal	80002cec <bfree>
      ip->addrs[i] = 0;
    8000331c:	0004a023          	sw	zero,0(s1)
    80003320:	b7ed                	j	8000330a <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    80003322:	0809a583          	lw	a1,128(s3)
    80003326:	ed89                	bnez	a1,80003340 <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    80003328:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    8000332c:	854e                	mv	a0,s3
    8000332e:	e21ff0ef          	jal	8000314e <iupdate>
}
    80003332:	70a2                	ld	ra,40(sp)
    80003334:	7402                	ld	s0,32(sp)
    80003336:	64e2                	ld	s1,24(sp)
    80003338:	6942                	ld	s2,16(sp)
    8000333a:	69a2                	ld	s3,8(sp)
    8000333c:	6145                	addi	sp,sp,48
    8000333e:	8082                	ret
    80003340:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80003342:	0009a503          	lw	a0,0(s3)
    80003346:	fb2ff0ef          	jal	80002af8 <bread>
    8000334a:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    8000334c:	05850493          	addi	s1,a0,88
    80003350:	45850913          	addi	s2,a0,1112
    80003354:	a021                	j	8000335c <itrunc+0x6c>
    80003356:	0491                	addi	s1,s1,4
    80003358:	01248963          	beq	s1,s2,8000336a <itrunc+0x7a>
      if(a[j])
    8000335c:	408c                	lw	a1,0(s1)
    8000335e:	dde5                	beqz	a1,80003356 <itrunc+0x66>
        bfree(ip->dev, a[j]);
    80003360:	0009a503          	lw	a0,0(s3)
    80003364:	989ff0ef          	jal	80002cec <bfree>
    80003368:	b7fd                	j	80003356 <itrunc+0x66>
    brelse(bp);
    8000336a:	8552                	mv	a0,s4
    8000336c:	895ff0ef          	jal	80002c00 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    80003370:	0809a583          	lw	a1,128(s3)
    80003374:	0009a503          	lw	a0,0(s3)
    80003378:	975ff0ef          	jal	80002cec <bfree>
    ip->addrs[NDIRECT] = 0;
    8000337c:	0809a023          	sw	zero,128(s3)
    80003380:	6a02                	ld	s4,0(sp)
    80003382:	b75d                	j	80003328 <itrunc+0x38>

0000000080003384 <iput>:
{
    80003384:	1101                	addi	sp,sp,-32
    80003386:	ec06                	sd	ra,24(sp)
    80003388:	e822                	sd	s0,16(sp)
    8000338a:	e426                	sd	s1,8(sp)
    8000338c:	1000                	addi	s0,sp,32
    8000338e:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003390:	0001b517          	auipc	a0,0x1b
    80003394:	bd850513          	addi	a0,a0,-1064 # 8001df68 <itable>
    80003398:	8cdfd0ef          	jal	80000c64 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    8000339c:	4498                	lw	a4,8(s1)
    8000339e:	4785                	li	a5,1
    800033a0:	02f70063          	beq	a4,a5,800033c0 <iput+0x3c>
  ip->ref--;
    800033a4:	449c                	lw	a5,8(s1)
    800033a6:	37fd                	addiw	a5,a5,-1
    800033a8:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800033aa:	0001b517          	auipc	a0,0x1b
    800033ae:	bbe50513          	addi	a0,a0,-1090 # 8001df68 <itable>
    800033b2:	943fd0ef          	jal	80000cf4 <release>
}
    800033b6:	60e2                	ld	ra,24(sp)
    800033b8:	6442                	ld	s0,16(sp)
    800033ba:	64a2                	ld	s1,8(sp)
    800033bc:	6105                	addi	sp,sp,32
    800033be:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800033c0:	40bc                	lw	a5,64(s1)
    800033c2:	d3ed                	beqz	a5,800033a4 <iput+0x20>
    800033c4:	04a49783          	lh	a5,74(s1)
    800033c8:	fff1                	bnez	a5,800033a4 <iput+0x20>
    800033ca:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    800033cc:	01048793          	addi	a5,s1,16
    800033d0:	893e                	mv	s2,a5
    800033d2:	853e                	mv	a0,a5
    800033d4:	18f000ef          	jal	80003d62 <acquiresleep>
    release(&itable.lock);
    800033d8:	0001b517          	auipc	a0,0x1b
    800033dc:	b9050513          	addi	a0,a0,-1136 # 8001df68 <itable>
    800033e0:	915fd0ef          	jal	80000cf4 <release>
    itrunc(ip);
    800033e4:	8526                	mv	a0,s1
    800033e6:	f0bff0ef          	jal	800032f0 <itrunc>
    ip->type = 0;
    800033ea:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    800033ee:	8526                	mv	a0,s1
    800033f0:	d5fff0ef          	jal	8000314e <iupdate>
    ip->valid = 0;
    800033f4:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    800033f8:	854a                	mv	a0,s2
    800033fa:	1af000ef          	jal	80003da8 <releasesleep>
    acquire(&itable.lock);
    800033fe:	0001b517          	auipc	a0,0x1b
    80003402:	b6a50513          	addi	a0,a0,-1174 # 8001df68 <itable>
    80003406:	85ffd0ef          	jal	80000c64 <acquire>
    8000340a:	6902                	ld	s2,0(sp)
    8000340c:	bf61                	j	800033a4 <iput+0x20>

000000008000340e <iunlockput>:
{
    8000340e:	1101                	addi	sp,sp,-32
    80003410:	ec06                	sd	ra,24(sp)
    80003412:	e822                	sd	s0,16(sp)
    80003414:	e426                	sd	s1,8(sp)
    80003416:	1000                	addi	s0,sp,32
    80003418:	84aa                	mv	s1,a0
  iunlock(ip);
    8000341a:	e97ff0ef          	jal	800032b0 <iunlock>
  iput(ip);
    8000341e:	8526                	mv	a0,s1
    80003420:	f65ff0ef          	jal	80003384 <iput>
}
    80003424:	60e2                	ld	ra,24(sp)
    80003426:	6442                	ld	s0,16(sp)
    80003428:	64a2                	ld	s1,8(sp)
    8000342a:	6105                	addi	sp,sp,32
    8000342c:	8082                	ret

000000008000342e <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    8000342e:	1141                	addi	sp,sp,-16
    80003430:	e406                	sd	ra,8(sp)
    80003432:	e022                	sd	s0,0(sp)
    80003434:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003436:	411c                	lw	a5,0(a0)
    80003438:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    8000343a:	415c                	lw	a5,4(a0)
    8000343c:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    8000343e:	04451783          	lh	a5,68(a0)
    80003442:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003446:	04a51783          	lh	a5,74(a0)
    8000344a:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    8000344e:	04c56783          	lwu	a5,76(a0)
    80003452:	e99c                	sd	a5,16(a1)
}
    80003454:	60a2                	ld	ra,8(sp)
    80003456:	6402                	ld	s0,0(sp)
    80003458:	0141                	addi	sp,sp,16
    8000345a:	8082                	ret

000000008000345c <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    8000345c:	457c                	lw	a5,76(a0)
    8000345e:	0ed7e663          	bltu	a5,a3,8000354a <readi+0xee>
{
    80003462:	7159                	addi	sp,sp,-112
    80003464:	f486                	sd	ra,104(sp)
    80003466:	f0a2                	sd	s0,96(sp)
    80003468:	eca6                	sd	s1,88(sp)
    8000346a:	e0d2                	sd	s4,64(sp)
    8000346c:	fc56                	sd	s5,56(sp)
    8000346e:	f85a                	sd	s6,48(sp)
    80003470:	f45e                	sd	s7,40(sp)
    80003472:	1880                	addi	s0,sp,112
    80003474:	8b2a                	mv	s6,a0
    80003476:	8bae                	mv	s7,a1
    80003478:	8a32                	mv	s4,a2
    8000347a:	84b6                	mv	s1,a3
    8000347c:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    8000347e:	9f35                	addw	a4,a4,a3
    return 0;
    80003480:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80003482:	0ad76b63          	bltu	a4,a3,80003538 <readi+0xdc>
    80003486:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    80003488:	00e7f463          	bgeu	a5,a4,80003490 <readi+0x34>
    n = ip->size - off;
    8000348c:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003490:	080a8b63          	beqz	s5,80003526 <readi+0xca>
    80003494:	e8ca                	sd	s2,80(sp)
    80003496:	f062                	sd	s8,32(sp)
    80003498:	ec66                	sd	s9,24(sp)
    8000349a:	e86a                	sd	s10,16(sp)
    8000349c:	e46e                	sd	s11,8(sp)
    8000349e:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    800034a0:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    800034a4:	5c7d                	li	s8,-1
    800034a6:	a80d                	j	800034d8 <readi+0x7c>
    800034a8:	020d1d93          	slli	s11,s10,0x20
    800034ac:	020ddd93          	srli	s11,s11,0x20
    800034b0:	05890613          	addi	a2,s2,88
    800034b4:	86ee                	mv	a3,s11
    800034b6:	963e                	add	a2,a2,a5
    800034b8:	85d2                	mv	a1,s4
    800034ba:	855e                	mv	a0,s7
    800034bc:	d7dfe0ef          	jal	80002238 <either_copyout>
    800034c0:	05850363          	beq	a0,s8,80003506 <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    800034c4:	854a                	mv	a0,s2
    800034c6:	f3aff0ef          	jal	80002c00 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800034ca:	013d09bb          	addw	s3,s10,s3
    800034ce:	009d04bb          	addw	s1,s10,s1
    800034d2:	9a6e                	add	s4,s4,s11
    800034d4:	0559f363          	bgeu	s3,s5,8000351a <readi+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    800034d8:	00a4d59b          	srliw	a1,s1,0xa
    800034dc:	855a                	mv	a0,s6
    800034de:	981ff0ef          	jal	80002e5e <bmap>
    800034e2:	85aa                	mv	a1,a0
    if(addr == 0)
    800034e4:	c139                	beqz	a0,8000352a <readi+0xce>
    bp = bread(ip->dev, addr);
    800034e6:	000b2503          	lw	a0,0(s6)
    800034ea:	e0eff0ef          	jal	80002af8 <bread>
    800034ee:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    800034f0:	3ff4f793          	andi	a5,s1,1023
    800034f4:	40fc873b          	subw	a4,s9,a5
    800034f8:	413a86bb          	subw	a3,s5,s3
    800034fc:	8d3a                	mv	s10,a4
    800034fe:	fae6f5e3          	bgeu	a3,a4,800034a8 <readi+0x4c>
    80003502:	8d36                	mv	s10,a3
    80003504:	b755                	j	800034a8 <readi+0x4c>
      brelse(bp);
    80003506:	854a                	mv	a0,s2
    80003508:	ef8ff0ef          	jal	80002c00 <brelse>
      tot = -1;
    8000350c:	59fd                	li	s3,-1
      break;
    8000350e:	6946                	ld	s2,80(sp)
    80003510:	7c02                	ld	s8,32(sp)
    80003512:	6ce2                	ld	s9,24(sp)
    80003514:	6d42                	ld	s10,16(sp)
    80003516:	6da2                	ld	s11,8(sp)
    80003518:	a831                	j	80003534 <readi+0xd8>
    8000351a:	6946                	ld	s2,80(sp)
    8000351c:	7c02                	ld	s8,32(sp)
    8000351e:	6ce2                	ld	s9,24(sp)
    80003520:	6d42                	ld	s10,16(sp)
    80003522:	6da2                	ld	s11,8(sp)
    80003524:	a801                	j	80003534 <readi+0xd8>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003526:	89d6                	mv	s3,s5
    80003528:	a031                	j	80003534 <readi+0xd8>
    8000352a:	6946                	ld	s2,80(sp)
    8000352c:	7c02                	ld	s8,32(sp)
    8000352e:	6ce2                	ld	s9,24(sp)
    80003530:	6d42                	ld	s10,16(sp)
    80003532:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80003534:	854e                	mv	a0,s3
    80003536:	69a6                	ld	s3,72(sp)
}
    80003538:	70a6                	ld	ra,104(sp)
    8000353a:	7406                	ld	s0,96(sp)
    8000353c:	64e6                	ld	s1,88(sp)
    8000353e:	6a06                	ld	s4,64(sp)
    80003540:	7ae2                	ld	s5,56(sp)
    80003542:	7b42                	ld	s6,48(sp)
    80003544:	7ba2                	ld	s7,40(sp)
    80003546:	6165                	addi	sp,sp,112
    80003548:	8082                	ret
    return 0;
    8000354a:	4501                	li	a0,0
}
    8000354c:	8082                	ret

000000008000354e <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    8000354e:	457c                	lw	a5,76(a0)
    80003550:	0ed7ee63          	bltu	a5,a3,8000364c <writei+0xfe>
{
    80003554:	7159                	addi	sp,sp,-112
    80003556:	f486                	sd	ra,104(sp)
    80003558:	f0a2                	sd	s0,96(sp)
    8000355a:	e8ca                	sd	s2,80(sp)
    8000355c:	e0d2                	sd	s4,64(sp)
    8000355e:	fc56                	sd	s5,56(sp)
    80003560:	f85a                	sd	s6,48(sp)
    80003562:	f45e                	sd	s7,40(sp)
    80003564:	1880                	addi	s0,sp,112
    80003566:	8aaa                	mv	s5,a0
    80003568:	8bae                	mv	s7,a1
    8000356a:	8a32                	mv	s4,a2
    8000356c:	8936                	mv	s2,a3
    8000356e:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80003570:	9f35                	addw	a4,a4,a3
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80003572:	000437b7          	lui	a5,0x43
    80003576:	00e7b7b3          	sltu	a5,a5,a4
  if(off > ip->size || off + n < off)
    8000357a:	00d73733          	sltu	a4,a4,a3
  if(off + n > MAXFILE*BSIZE)
    8000357e:	8fd9                	or	a5,a5,a4
    80003580:	ef91                	bnez	a5,8000359c <writei+0x4e>
    80003582:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003584:	0a0b0c63          	beqz	s6,8000363c <writei+0xee>
    80003588:	eca6                	sd	s1,88(sp)
    8000358a:	f062                	sd	s8,32(sp)
    8000358c:	ec66                	sd	s9,24(sp)
    8000358e:	e86a                	sd	s10,16(sp)
    80003590:	e46e                	sd	s11,8(sp)
    80003592:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003594:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003598:	5c7d                	li	s8,-1
    8000359a:	a835                	j	800035d6 <writei+0x88>
    return -1;
    8000359c:	557d                	li	a0,-1
    8000359e:	a071                	j	8000362a <writei+0xdc>
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    800035a0:	020d1d93          	slli	s11,s10,0x20
    800035a4:	020ddd93          	srli	s11,s11,0x20
    800035a8:	05848513          	addi	a0,s1,88
    800035ac:	86ee                	mv	a3,s11
    800035ae:	8652                	mv	a2,s4
    800035b0:	85de                	mv	a1,s7
    800035b2:	953e                	add	a0,a0,a5
    800035b4:	ccffe0ef          	jal	80002282 <either_copyin>
    800035b8:	05850663          	beq	a0,s8,80003604 <writei+0xb6>
      brelse(bp);
      break;
    }
    log_write(bp);
    800035bc:	8526                	mv	a0,s1
    800035be:	6a0000ef          	jal	80003c5e <log_write>
    brelse(bp);
    800035c2:	8526                	mv	a0,s1
    800035c4:	e3cff0ef          	jal	80002c00 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800035c8:	013d09bb          	addw	s3,s10,s3
    800035cc:	012d093b          	addw	s2,s10,s2
    800035d0:	9a6e                	add	s4,s4,s11
    800035d2:	0369fc63          	bgeu	s3,s6,8000360a <writei+0xbc>
    uint addr = bmap(ip, off/BSIZE);
    800035d6:	00a9559b          	srliw	a1,s2,0xa
    800035da:	8556                	mv	a0,s5
    800035dc:	883ff0ef          	jal	80002e5e <bmap>
    800035e0:	85aa                	mv	a1,a0
    if(addr == 0)
    800035e2:	c505                	beqz	a0,8000360a <writei+0xbc>
    bp = bread(ip->dev, addr);
    800035e4:	000aa503          	lw	a0,0(s5)
    800035e8:	d10ff0ef          	jal	80002af8 <bread>
    800035ec:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    800035ee:	3ff97793          	andi	a5,s2,1023
    800035f2:	40fc873b          	subw	a4,s9,a5
    800035f6:	413b06bb          	subw	a3,s6,s3
    800035fa:	8d3a                	mv	s10,a4
    800035fc:	fae6f2e3          	bgeu	a3,a4,800035a0 <writei+0x52>
    80003600:	8d36                	mv	s10,a3
    80003602:	bf79                	j	800035a0 <writei+0x52>
      brelse(bp);
    80003604:	8526                	mv	a0,s1
    80003606:	dfaff0ef          	jal	80002c00 <brelse>
  }

  if(off > ip->size)
    8000360a:	04caa783          	lw	a5,76(s5)
    8000360e:	0327f963          	bgeu	a5,s2,80003640 <writei+0xf2>
    ip->size = off;
    80003612:	052aa623          	sw	s2,76(s5)
    80003616:	64e6                	ld	s1,88(sp)
    80003618:	7c02                	ld	s8,32(sp)
    8000361a:	6ce2                	ld	s9,24(sp)
    8000361c:	6d42                	ld	s10,16(sp)
    8000361e:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003620:	8556                	mv	a0,s5
    80003622:	b2dff0ef          	jal	8000314e <iupdate>

  return tot;
    80003626:	854e                	mv	a0,s3
    80003628:	69a6                	ld	s3,72(sp)
}
    8000362a:	70a6                	ld	ra,104(sp)
    8000362c:	7406                	ld	s0,96(sp)
    8000362e:	6946                	ld	s2,80(sp)
    80003630:	6a06                	ld	s4,64(sp)
    80003632:	7ae2                	ld	s5,56(sp)
    80003634:	7b42                	ld	s6,48(sp)
    80003636:	7ba2                	ld	s7,40(sp)
    80003638:	6165                	addi	sp,sp,112
    8000363a:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    8000363c:	89da                	mv	s3,s6
    8000363e:	b7cd                	j	80003620 <writei+0xd2>
    80003640:	64e6                	ld	s1,88(sp)
    80003642:	7c02                	ld	s8,32(sp)
    80003644:	6ce2                	ld	s9,24(sp)
    80003646:	6d42                	ld	s10,16(sp)
    80003648:	6da2                	ld	s11,8(sp)
    8000364a:	bfd9                	j	80003620 <writei+0xd2>
    return -1;
    8000364c:	557d                	li	a0,-1
}
    8000364e:	8082                	ret

0000000080003650 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003650:	1141                	addi	sp,sp,-16
    80003652:	e406                	sd	ra,8(sp)
    80003654:	e022                	sd	s0,0(sp)
    80003656:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003658:	4639                	li	a2,14
    8000365a:	fa6fd0ef          	jal	80000e00 <strncmp>
}
    8000365e:	60a2                	ld	ra,8(sp)
    80003660:	6402                	ld	s0,0(sp)
    80003662:	0141                	addi	sp,sp,16
    80003664:	8082                	ret

0000000080003666 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003666:	711d                	addi	sp,sp,-96
    80003668:	ec86                	sd	ra,88(sp)
    8000366a:	e8a2                	sd	s0,80(sp)
    8000366c:	e4a6                	sd	s1,72(sp)
    8000366e:	e0ca                	sd	s2,64(sp)
    80003670:	fc4e                	sd	s3,56(sp)
    80003672:	f852                	sd	s4,48(sp)
    80003674:	f456                	sd	s5,40(sp)
    80003676:	f05a                	sd	s6,32(sp)
    80003678:	ec5e                	sd	s7,24(sp)
    8000367a:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    8000367c:	04451703          	lh	a4,68(a0)
    80003680:	4785                	li	a5,1
    80003682:	02f71963          	bne	a4,a5,800036b4 <dirlookup+0x4e>
    80003686:	892a                	mv	s2,a0
    80003688:	8aae                	mv	s5,a1
    8000368a:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    8000368c:	457c                	lw	a5,76(a0)
    8000368e:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003690:	fa040a13          	addi	s4,s0,-96
    80003694:	49c1                	li	s3,16
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    if(namecmp(name, de.name) == 0){
    80003696:	fa240b13          	addi	s6,s0,-94
  for(off = 0; off < dp->size; off += sizeof(de)){
    8000369a:	ef95                	bnez	a5,800036d6 <dirlookup+0x70>
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    8000369c:	4501                	li	a0,0
}
    8000369e:	60e6                	ld	ra,88(sp)
    800036a0:	6446                	ld	s0,80(sp)
    800036a2:	64a6                	ld	s1,72(sp)
    800036a4:	6906                	ld	s2,64(sp)
    800036a6:	79e2                	ld	s3,56(sp)
    800036a8:	7a42                	ld	s4,48(sp)
    800036aa:	7aa2                	ld	s5,40(sp)
    800036ac:	7b02                	ld	s6,32(sp)
    800036ae:	6be2                	ld	s7,24(sp)
    800036b0:	6125                	addi	sp,sp,96
    800036b2:	8082                	ret
    panic("dirlookup not DIR");
    800036b4:	00004517          	auipc	a0,0x4
    800036b8:	e6c50513          	addi	a0,a0,-404 # 80007520 <etext+0x520>
    800036bc:	934fd0ef          	jal	800007f0 <panic>
      panic("dirlookup read");
    800036c0:	00004517          	auipc	a0,0x4
    800036c4:	e7850513          	addi	a0,a0,-392 # 80007538 <etext+0x538>
    800036c8:	928fd0ef          	jal	800007f0 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    800036cc:	24c1                	addiw	s1,s1,16
    800036ce:	04c92783          	lw	a5,76(s2)
    800036d2:	fcf4f5e3          	bgeu	s1,a5,8000369c <dirlookup+0x36>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800036d6:	874e                	mv	a4,s3
    800036d8:	86a6                	mv	a3,s1
    800036da:	8652                	mv	a2,s4
    800036dc:	4581                	li	a1,0
    800036de:	854a                	mv	a0,s2
    800036e0:	d7dff0ef          	jal	8000345c <readi>
    800036e4:	fd351ee3          	bne	a0,s3,800036c0 <dirlookup+0x5a>
    if(de.inum == 0)
    800036e8:	fa045783          	lhu	a5,-96(s0)
    800036ec:	d3e5                	beqz	a5,800036cc <dirlookup+0x66>
    if(namecmp(name, de.name) == 0){
    800036ee:	85da                	mv	a1,s6
    800036f0:	8556                	mv	a0,s5
    800036f2:	f5fff0ef          	jal	80003650 <namecmp>
    800036f6:	f979                	bnez	a0,800036cc <dirlookup+0x66>
      if(poff)
    800036f8:	000b8463          	beqz	s7,80003700 <dirlookup+0x9a>
        *poff = off;
    800036fc:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    80003700:	fa045583          	lhu	a1,-96(s0)
    80003704:	00092503          	lw	a0,0(s2)
    80003708:	817ff0ef          	jal	80002f1e <iget>
    8000370c:	bf49                	j	8000369e <dirlookup+0x38>

000000008000370e <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    8000370e:	711d                	addi	sp,sp,-96
    80003710:	ec86                	sd	ra,88(sp)
    80003712:	e8a2                	sd	s0,80(sp)
    80003714:	e4a6                	sd	s1,72(sp)
    80003716:	e0ca                	sd	s2,64(sp)
    80003718:	fc4e                	sd	s3,56(sp)
    8000371a:	f852                	sd	s4,48(sp)
    8000371c:	f456                	sd	s5,40(sp)
    8000371e:	f05a                	sd	s6,32(sp)
    80003720:	ec5e                	sd	s7,24(sp)
    80003722:	e862                	sd	s8,16(sp)
    80003724:	e466                	sd	s9,8(sp)
    80003726:	e06a                	sd	s10,0(sp)
    80003728:	1080                	addi	s0,sp,96
    8000372a:	84aa                	mv	s1,a0
    8000372c:	8b2e                	mv	s6,a1
    8000372e:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003730:	00054703          	lbu	a4,0(a0)
    80003734:	02f00793          	li	a5,47
    80003738:	00f70f63          	beq	a4,a5,80003756 <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    8000373c:	9e8fe0ef          	jal	80001924 <myproc>
    80003740:	15053503          	ld	a0,336(a0)
    80003744:	a89ff0ef          	jal	800031cc <idup>
    80003748:	8a2a                	mv	s4,a0
  while(*path == '/')
    8000374a:	02f00993          	li	s3,47
  if(len >= DIRSIZ)
    8000374e:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    80003750:	4cb9                	li	s9,14

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80003752:	4b85                	li	s7,1
    80003754:	a879                	j	800037f2 <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    80003756:	4585                	li	a1,1
    80003758:	852e                	mv	a0,a1
    8000375a:	fc4ff0ef          	jal	80002f1e <iget>
    8000375e:	8a2a                	mv	s4,a0
    80003760:	b7ed                	j	8000374a <namex+0x3c>
      iunlockput(ip);
    80003762:	8552                	mv	a0,s4
    80003764:	cabff0ef          	jal	8000340e <iunlockput>
      return 0;
    80003768:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    8000376a:	8552                	mv	a0,s4
    8000376c:	60e6                	ld	ra,88(sp)
    8000376e:	6446                	ld	s0,80(sp)
    80003770:	64a6                	ld	s1,72(sp)
    80003772:	6906                	ld	s2,64(sp)
    80003774:	79e2                	ld	s3,56(sp)
    80003776:	7a42                	ld	s4,48(sp)
    80003778:	7aa2                	ld	s5,40(sp)
    8000377a:	7b02                	ld	s6,32(sp)
    8000377c:	6be2                	ld	s7,24(sp)
    8000377e:	6c42                	ld	s8,16(sp)
    80003780:	6ca2                	ld	s9,8(sp)
    80003782:	6d02                	ld	s10,0(sp)
    80003784:	6125                	addi	sp,sp,96
    80003786:	8082                	ret
      iunlock(ip);
    80003788:	8552                	mv	a0,s4
    8000378a:	b27ff0ef          	jal	800032b0 <iunlock>
      return ip;
    8000378e:	bff1                	j	8000376a <namex+0x5c>
      iunlockput(ip);
    80003790:	8552                	mv	a0,s4
    80003792:	c7dff0ef          	jal	8000340e <iunlockput>
      return 0;
    80003796:	8a4a                	mv	s4,s2
    80003798:	bfc9                	j	8000376a <namex+0x5c>
  while(*path != '/' && *path != 0)
    8000379a:	8926                	mv	s2,s1
  len = path - s;
    8000379c:	4d01                	li	s10,0
    8000379e:	4601                	li	a2,0
    memmove(name, s, len);
    800037a0:	2601                	sext.w	a2,a2
    800037a2:	85a6                	mv	a1,s1
    800037a4:	8556                	mv	a0,s5
    800037a6:	de6fd0ef          	jal	80000d8c <memmove>
    name[len] = 0;
    800037aa:	9d56                	add	s10,s10,s5
    800037ac:	000d0023          	sb	zero,0(s10)
    800037b0:	84ca                	mv	s1,s2
  while(*path == '/')
    800037b2:	0004c783          	lbu	a5,0(s1)
    800037b6:	01379763          	bne	a5,s3,800037c4 <namex+0xb6>
    path++;
    800037ba:	0485                	addi	s1,s1,1
  while(*path == '/')
    800037bc:	0004c783          	lbu	a5,0(s1)
    800037c0:	ff378de3          	beq	a5,s3,800037ba <namex+0xac>
    ilock(ip);
    800037c4:	8552                	mv	a0,s4
    800037c6:	a3dff0ef          	jal	80003202 <ilock>
    if(ip->type != T_DIR){
    800037ca:	044a1783          	lh	a5,68(s4)
    800037ce:	f9779ae3          	bne	a5,s7,80003762 <namex+0x54>
    if(nameiparent && *path == '\0'){
    800037d2:	000b0563          	beqz	s6,800037dc <namex+0xce>
    800037d6:	0004c783          	lbu	a5,0(s1)
    800037da:	d7dd                	beqz	a5,80003788 <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    800037dc:	4601                	li	a2,0
    800037de:	85d6                	mv	a1,s5
    800037e0:	8552                	mv	a0,s4
    800037e2:	e85ff0ef          	jal	80003666 <dirlookup>
    800037e6:	892a                	mv	s2,a0
    800037e8:	d545                	beqz	a0,80003790 <namex+0x82>
    iunlockput(ip);
    800037ea:	8552                	mv	a0,s4
    800037ec:	c23ff0ef          	jal	8000340e <iunlockput>
    ip = next;
    800037f0:	8a4a                	mv	s4,s2
  while(*path == '/')
    800037f2:	0004c783          	lbu	a5,0(s1)
    800037f6:	01379763          	bne	a5,s3,80003804 <namex+0xf6>
    path++;
    800037fa:	0485                	addi	s1,s1,1
  while(*path == '/')
    800037fc:	0004c783          	lbu	a5,0(s1)
    80003800:	ff378de3          	beq	a5,s3,800037fa <namex+0xec>
  if(*path == 0)
    80003804:	c7a1                	beqz	a5,8000384c <namex+0x13e>
  while(*path != '/' && *path != 0)
    80003806:	0004c703          	lbu	a4,0(s1)
    8000380a:	fd170793          	addi	a5,a4,-47
    8000380e:	00f037b3          	snez	a5,a5
    80003812:	00e03733          	snez	a4,a4
    80003816:	8ff9                	and	a5,a5,a4
    80003818:	d3c9                	beqz	a5,8000379a <namex+0x8c>
    8000381a:	8926                	mv	s2,s1
    path++;
    8000381c:	0905                	addi	s2,s2,1
  while(*path != '/' && *path != 0)
    8000381e:	00094703          	lbu	a4,0(s2)
    80003822:	fd170793          	addi	a5,a4,-47
    80003826:	00f037b3          	snez	a5,a5
    8000382a:	00e03733          	snez	a4,a4
    8000382e:	8ff9                	and	a5,a5,a4
    80003830:	f7f5                	bnez	a5,8000381c <namex+0x10e>
  len = path - s;
    80003832:	40990633          	sub	a2,s2,s1
    80003836:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    8000383a:	f7ac53e3          	bge	s8,s10,800037a0 <namex+0x92>
    memmove(name, s, DIRSIZ);
    8000383e:	8666                	mv	a2,s9
    80003840:	85a6                	mv	a1,s1
    80003842:	8556                	mv	a0,s5
    80003844:	d48fd0ef          	jal	80000d8c <memmove>
    80003848:	84ca                	mv	s1,s2
    8000384a:	b7a5                	j	800037b2 <namex+0xa4>
  if(nameiparent){
    8000384c:	f00b0fe3          	beqz	s6,8000376a <namex+0x5c>
    iput(ip);
    80003850:	8552                	mv	a0,s4
    80003852:	b33ff0ef          	jal	80003384 <iput>
    return 0;
    80003856:	bf09                	j	80003768 <namex+0x5a>

0000000080003858 <dirlink>:
{
    80003858:	715d                	addi	sp,sp,-80
    8000385a:	e486                	sd	ra,72(sp)
    8000385c:	e0a2                	sd	s0,64(sp)
    8000385e:	f84a                	sd	s2,48(sp)
    80003860:	ec56                	sd	s5,24(sp)
    80003862:	e85a                	sd	s6,16(sp)
    80003864:	0880                	addi	s0,sp,80
    80003866:	892a                	mv	s2,a0
    80003868:	8aae                	mv	s5,a1
    8000386a:	8b32                	mv	s6,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    8000386c:	4601                	li	a2,0
    8000386e:	df9ff0ef          	jal	80003666 <dirlookup>
    80003872:	ed1d                	bnez	a0,800038b0 <dirlink+0x58>
    80003874:	fc26                	sd	s1,56(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003876:	04c92483          	lw	s1,76(s2)
    8000387a:	c4b9                	beqz	s1,800038c8 <dirlink+0x70>
    8000387c:	f44e                	sd	s3,40(sp)
    8000387e:	f052                	sd	s4,32(sp)
    80003880:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003882:	fb040a13          	addi	s4,s0,-80
    80003886:	49c1                	li	s3,16
    80003888:	874e                	mv	a4,s3
    8000388a:	86a6                	mv	a3,s1
    8000388c:	8652                	mv	a2,s4
    8000388e:	4581                	li	a1,0
    80003890:	854a                	mv	a0,s2
    80003892:	bcbff0ef          	jal	8000345c <readi>
    80003896:	03351163          	bne	a0,s3,800038b8 <dirlink+0x60>
    if(de.inum == 0)
    8000389a:	fb045783          	lhu	a5,-80(s0)
    8000389e:	c39d                	beqz	a5,800038c4 <dirlink+0x6c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    800038a0:	24c1                	addiw	s1,s1,16
    800038a2:	04c92783          	lw	a5,76(s2)
    800038a6:	fef4e1e3          	bltu	s1,a5,80003888 <dirlink+0x30>
    800038aa:	79a2                	ld	s3,40(sp)
    800038ac:	7a02                	ld	s4,32(sp)
    800038ae:	a829                	j	800038c8 <dirlink+0x70>
    iput(ip);
    800038b0:	ad5ff0ef          	jal	80003384 <iput>
    return -1;
    800038b4:	557d                	li	a0,-1
    800038b6:	a83d                	j	800038f4 <dirlink+0x9c>
      panic("dirlink read");
    800038b8:	00004517          	auipc	a0,0x4
    800038bc:	c9050513          	addi	a0,a0,-880 # 80007548 <etext+0x548>
    800038c0:	f31fc0ef          	jal	800007f0 <panic>
    800038c4:	79a2                	ld	s3,40(sp)
    800038c6:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    800038c8:	4639                	li	a2,14
    800038ca:	85d6                	mv	a1,s5
    800038cc:	fb240513          	addi	a0,s0,-78
    800038d0:	d66fd0ef          	jal	80000e36 <strncpy>
  de.inum = inum;
    800038d4:	fb641823          	sh	s6,-80(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800038d8:	4741                	li	a4,16
    800038da:	86a6                	mv	a3,s1
    800038dc:	fb040613          	addi	a2,s0,-80
    800038e0:	4581                	li	a1,0
    800038e2:	854a                	mv	a0,s2
    800038e4:	c6bff0ef          	jal	8000354e <writei>
    800038e8:	1541                	addi	a0,a0,-16
    800038ea:	00a03533          	snez	a0,a0
    800038ee:	40a0053b          	negw	a0,a0
    800038f2:	74e2                	ld	s1,56(sp)
}
    800038f4:	60a6                	ld	ra,72(sp)
    800038f6:	6406                	ld	s0,64(sp)
    800038f8:	7942                	ld	s2,48(sp)
    800038fa:	6ae2                	ld	s5,24(sp)
    800038fc:	6b42                	ld	s6,16(sp)
    800038fe:	6161                	addi	sp,sp,80
    80003900:	8082                	ret

0000000080003902 <namei>:

struct inode*
namei(char *path)
{
    80003902:	1101                	addi	sp,sp,-32
    80003904:	ec06                	sd	ra,24(sp)
    80003906:	e822                	sd	s0,16(sp)
    80003908:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    8000390a:	fe040613          	addi	a2,s0,-32
    8000390e:	4581                	li	a1,0
    80003910:	dffff0ef          	jal	8000370e <namex>
}
    80003914:	60e2                	ld	ra,24(sp)
    80003916:	6442                	ld	s0,16(sp)
    80003918:	6105                	addi	sp,sp,32
    8000391a:	8082                	ret

000000008000391c <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    8000391c:	1141                	addi	sp,sp,-16
    8000391e:	e406                	sd	ra,8(sp)
    80003920:	e022                	sd	s0,0(sp)
    80003922:	0800                	addi	s0,sp,16
    80003924:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003926:	4585                	li	a1,1
    80003928:	de7ff0ef          	jal	8000370e <namex>
}
    8000392c:	60a2                	ld	ra,8(sp)
    8000392e:	6402                	ld	s0,0(sp)
    80003930:	0141                	addi	sp,sp,16
    80003932:	8082                	ret

0000000080003934 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003934:	1101                	addi	sp,sp,-32
    80003936:	ec06                	sd	ra,24(sp)
    80003938:	e822                	sd	s0,16(sp)
    8000393a:	e426                	sd	s1,8(sp)
    8000393c:	e04a                	sd	s2,0(sp)
    8000393e:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003940:	0001c917          	auipc	s2,0x1c
    80003944:	0d090913          	addi	s2,s2,208 # 8001fa10 <log>
    80003948:	01892583          	lw	a1,24(s2)
    8000394c:	02892503          	lw	a0,40(s2)
    80003950:	9a8ff0ef          	jal	80002af8 <bread>
    80003954:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003956:	02c92603          	lw	a2,44(s2)
    8000395a:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    8000395c:	00c05f63          	blez	a2,8000397a <write_head+0x46>
    80003960:	0001c717          	auipc	a4,0x1c
    80003964:	0e070713          	addi	a4,a4,224 # 8001fa40 <log+0x30>
    80003968:	87aa                	mv	a5,a0
    8000396a:	060a                	slli	a2,a2,0x2
    8000396c:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    8000396e:	4314                	lw	a3,0(a4)
    80003970:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003972:	0711                	addi	a4,a4,4
    80003974:	0791                	addi	a5,a5,4 # 43004 <_entry-0x7ffbcffc>
    80003976:	fec79ce3          	bne	a5,a2,8000396e <write_head+0x3a>
  }
  bwrite(buf);
    8000397a:	8526                	mv	a0,s1
    8000397c:	a52ff0ef          	jal	80002bce <bwrite>
  brelse(buf);
    80003980:	8526                	mv	a0,s1
    80003982:	a7eff0ef          	jal	80002c00 <brelse>
}
    80003986:	60e2                	ld	ra,24(sp)
    80003988:	6442                	ld	s0,16(sp)
    8000398a:	64a2                	ld	s1,8(sp)
    8000398c:	6902                	ld	s2,0(sp)
    8000398e:	6105                	addi	sp,sp,32
    80003990:	8082                	ret

0000000080003992 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003992:	0001c797          	auipc	a5,0x1c
    80003996:	0aa7a783          	lw	a5,170(a5) # 8001fa3c <log+0x2c>
    8000399a:	0af05263          	blez	a5,80003a3e <install_trans+0xac>
{
    8000399e:	715d                	addi	sp,sp,-80
    800039a0:	e486                	sd	ra,72(sp)
    800039a2:	e0a2                	sd	s0,64(sp)
    800039a4:	fc26                	sd	s1,56(sp)
    800039a6:	f84a                	sd	s2,48(sp)
    800039a8:	f44e                	sd	s3,40(sp)
    800039aa:	f052                	sd	s4,32(sp)
    800039ac:	ec56                	sd	s5,24(sp)
    800039ae:	e85a                	sd	s6,16(sp)
    800039b0:	e45e                	sd	s7,8(sp)
    800039b2:	0880                	addi	s0,sp,80
    800039b4:	8b2a                	mv	s6,a0
    800039b6:	0001ca97          	auipc	s5,0x1c
    800039ba:	08aa8a93          	addi	s5,s5,138 # 8001fa40 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    800039be:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    800039c0:	0001c997          	auipc	s3,0x1c
    800039c4:	05098993          	addi	s3,s3,80 # 8001fa10 <log>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    800039c8:	40000b93          	li	s7,1024
    800039cc:	a829                	j	800039e6 <install_trans+0x54>
    brelse(lbuf);
    800039ce:	854a                	mv	a0,s2
    800039d0:	a30ff0ef          	jal	80002c00 <brelse>
    brelse(dbuf);
    800039d4:	8526                	mv	a0,s1
    800039d6:	a2aff0ef          	jal	80002c00 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    800039da:	2a05                	addiw	s4,s4,1
    800039dc:	0a91                	addi	s5,s5,4
    800039de:	02c9a783          	lw	a5,44(s3)
    800039e2:	04fa5363          	bge	s4,a5,80003a28 <install_trans+0x96>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    800039e6:	0189a583          	lw	a1,24(s3)
    800039ea:	014585bb          	addw	a1,a1,s4
    800039ee:	2585                	addiw	a1,a1,1
    800039f0:	0289a503          	lw	a0,40(s3)
    800039f4:	904ff0ef          	jal	80002af8 <bread>
    800039f8:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    800039fa:	000aa583          	lw	a1,0(s5)
    800039fe:	0289a503          	lw	a0,40(s3)
    80003a02:	8f6ff0ef          	jal	80002af8 <bread>
    80003a06:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003a08:	865e                	mv	a2,s7
    80003a0a:	05890593          	addi	a1,s2,88
    80003a0e:	05850513          	addi	a0,a0,88
    80003a12:	b7afd0ef          	jal	80000d8c <memmove>
    bwrite(dbuf);  // write dst to disk
    80003a16:	8526                	mv	a0,s1
    80003a18:	9b6ff0ef          	jal	80002bce <bwrite>
    if(recovering == 0)
    80003a1c:	fa0b19e3          	bnez	s6,800039ce <install_trans+0x3c>
      bunpin(dbuf);
    80003a20:	8526                	mv	a0,s1
    80003a22:	a96ff0ef          	jal	80002cb8 <bunpin>
    80003a26:	b765                	j	800039ce <install_trans+0x3c>
}
    80003a28:	60a6                	ld	ra,72(sp)
    80003a2a:	6406                	ld	s0,64(sp)
    80003a2c:	74e2                	ld	s1,56(sp)
    80003a2e:	7942                	ld	s2,48(sp)
    80003a30:	79a2                	ld	s3,40(sp)
    80003a32:	7a02                	ld	s4,32(sp)
    80003a34:	6ae2                	ld	s5,24(sp)
    80003a36:	6b42                	ld	s6,16(sp)
    80003a38:	6ba2                	ld	s7,8(sp)
    80003a3a:	6161                	addi	sp,sp,80
    80003a3c:	8082                	ret
    80003a3e:	8082                	ret

0000000080003a40 <initlog>:
{
    80003a40:	7179                	addi	sp,sp,-48
    80003a42:	f406                	sd	ra,40(sp)
    80003a44:	f022                	sd	s0,32(sp)
    80003a46:	ec26                	sd	s1,24(sp)
    80003a48:	e84a                	sd	s2,16(sp)
    80003a4a:	e44e                	sd	s3,8(sp)
    80003a4c:	1800                	addi	s0,sp,48
    80003a4e:	892a                	mv	s2,a0
    80003a50:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003a52:	0001c497          	auipc	s1,0x1c
    80003a56:	fbe48493          	addi	s1,s1,-66 # 8001fa10 <log>
    80003a5a:	00004597          	auipc	a1,0x4
    80003a5e:	afe58593          	addi	a1,a1,-1282 # 80007558 <etext+0x558>
    80003a62:	8526                	mv	a0,s1
    80003a64:	976fd0ef          	jal	80000bda <initlock>
  log.start = sb->logstart;
    80003a68:	0149a583          	lw	a1,20(s3)
    80003a6c:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    80003a6e:	0109a783          	lw	a5,16(s3)
    80003a72:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    80003a74:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003a78:	854a                	mv	a0,s2
    80003a7a:	87eff0ef          	jal	80002af8 <bread>
  log.lh.n = lh->n;
    80003a7e:	4d30                	lw	a2,88(a0)
    80003a80:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    80003a82:	00c05f63          	blez	a2,80003aa0 <initlog+0x60>
    80003a86:	87aa                	mv	a5,a0
    80003a88:	0001c717          	auipc	a4,0x1c
    80003a8c:	fb870713          	addi	a4,a4,-72 # 8001fa40 <log+0x30>
    80003a90:	060a                	slli	a2,a2,0x2
    80003a92:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003a94:	4ff4                	lw	a3,92(a5)
    80003a96:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003a98:	0791                	addi	a5,a5,4
    80003a9a:	0711                	addi	a4,a4,4
    80003a9c:	fec79ce3          	bne	a5,a2,80003a94 <initlog+0x54>
  brelse(buf);
    80003aa0:	960ff0ef          	jal	80002c00 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003aa4:	4505                	li	a0,1
    80003aa6:	eedff0ef          	jal	80003992 <install_trans>
  log.lh.n = 0;
    80003aaa:	0001c797          	auipc	a5,0x1c
    80003aae:	f807a923          	sw	zero,-110(a5) # 8001fa3c <log+0x2c>
  write_head(); // clear the log
    80003ab2:	e83ff0ef          	jal	80003934 <write_head>
}
    80003ab6:	70a2                	ld	ra,40(sp)
    80003ab8:	7402                	ld	s0,32(sp)
    80003aba:	64e2                	ld	s1,24(sp)
    80003abc:	6942                	ld	s2,16(sp)
    80003abe:	69a2                	ld	s3,8(sp)
    80003ac0:	6145                	addi	sp,sp,48
    80003ac2:	8082                	ret

0000000080003ac4 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003ac4:	1101                	addi	sp,sp,-32
    80003ac6:	ec06                	sd	ra,24(sp)
    80003ac8:	e822                	sd	s0,16(sp)
    80003aca:	e426                	sd	s1,8(sp)
    80003acc:	e04a                	sd	s2,0(sp)
    80003ace:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003ad0:	0001c517          	auipc	a0,0x1c
    80003ad4:	f4050513          	addi	a0,a0,-192 # 8001fa10 <log>
    80003ad8:	98cfd0ef          	jal	80000c64 <acquire>
  while(1){
    if(log.committing){
    80003adc:	0001c497          	auipc	s1,0x1c
    80003ae0:	f3448493          	addi	s1,s1,-204 # 8001fa10 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003ae4:	4979                	li	s2,30
    80003ae6:	a029                	j	80003af0 <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003ae8:	85a6                	mv	a1,s1
    80003aea:	8526                	mv	a0,s1
    80003aec:	bf4fe0ef          	jal	80001ee0 <sleep>
    if(log.committing){
    80003af0:	50dc                	lw	a5,36(s1)
    80003af2:	fbfd                	bnez	a5,80003ae8 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003af4:	5098                	lw	a4,32(s1)
    80003af6:	2705                	addiw	a4,a4,1
    80003af8:	0027179b          	slliw	a5,a4,0x2
    80003afc:	9fb9                	addw	a5,a5,a4
    80003afe:	0017979b          	slliw	a5,a5,0x1
    80003b02:	54d4                	lw	a3,44(s1)
    80003b04:	9fb5                	addw	a5,a5,a3
    80003b06:	00f95763          	bge	s2,a5,80003b14 <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80003b0a:	85a6                	mv	a1,s1
    80003b0c:	8526                	mv	a0,s1
    80003b0e:	bd2fe0ef          	jal	80001ee0 <sleep>
    80003b12:	bff9                	j	80003af0 <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003b14:	0001c797          	auipc	a5,0x1c
    80003b18:	f0e7ae23          	sw	a4,-228(a5) # 8001fa30 <log+0x20>
      release(&log.lock);
    80003b1c:	0001c517          	auipc	a0,0x1c
    80003b20:	ef450513          	addi	a0,a0,-268 # 8001fa10 <log>
    80003b24:	9d0fd0ef          	jal	80000cf4 <release>
      break;
    }
  }
}
    80003b28:	60e2                	ld	ra,24(sp)
    80003b2a:	6442                	ld	s0,16(sp)
    80003b2c:	64a2                	ld	s1,8(sp)
    80003b2e:	6902                	ld	s2,0(sp)
    80003b30:	6105                	addi	sp,sp,32
    80003b32:	8082                	ret

0000000080003b34 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003b34:	7139                	addi	sp,sp,-64
    80003b36:	fc06                	sd	ra,56(sp)
    80003b38:	f822                	sd	s0,48(sp)
    80003b3a:	f426                	sd	s1,40(sp)
    80003b3c:	f04a                	sd	s2,32(sp)
    80003b3e:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003b40:	0001c497          	auipc	s1,0x1c
    80003b44:	ed048493          	addi	s1,s1,-304 # 8001fa10 <log>
    80003b48:	8526                	mv	a0,s1
    80003b4a:	91afd0ef          	jal	80000c64 <acquire>
  log.outstanding -= 1;
    80003b4e:	509c                	lw	a5,32(s1)
    80003b50:	37fd                	addiw	a5,a5,-1
    80003b52:	893e                	mv	s2,a5
    80003b54:	d09c                	sw	a5,32(s1)
  if(log.committing)
    80003b56:	50dc                	lw	a5,36(s1)
    80003b58:	ebb9                	bnez	a5,80003bae <end_op+0x7a>
    panic("log.committing");
  if(log.outstanding == 0){
    80003b5a:	06091363          	bnez	s2,80003bc0 <end_op+0x8c>
    do_commit = 1;
    log.committing = 1;
    80003b5e:	0001c497          	auipc	s1,0x1c
    80003b62:	eb248493          	addi	s1,s1,-334 # 8001fa10 <log>
    80003b66:	4785                	li	a5,1
    80003b68:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003b6a:	8526                	mv	a0,s1
    80003b6c:	988fd0ef          	jal	80000cf4 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003b70:	54dc                	lw	a5,44(s1)
    80003b72:	06f04463          	bgtz	a5,80003bda <end_op+0xa6>
    acquire(&log.lock);
    80003b76:	0001c517          	auipc	a0,0x1c
    80003b7a:	e9a50513          	addi	a0,a0,-358 # 8001fa10 <log>
    80003b7e:	8e6fd0ef          	jal	80000c64 <acquire>
    log.committing = 0;
    80003b82:	0001c797          	auipc	a5,0x1c
    80003b86:	ea07a923          	sw	zero,-334(a5) # 8001fa34 <log+0x24>
    wakeup(&log);
    80003b8a:	0001c517          	auipc	a0,0x1c
    80003b8e:	e8650513          	addi	a0,a0,-378 # 8001fa10 <log>
    80003b92:	b9afe0ef          	jal	80001f2c <wakeup>
    release(&log.lock);
    80003b96:	0001c517          	auipc	a0,0x1c
    80003b9a:	e7a50513          	addi	a0,a0,-390 # 8001fa10 <log>
    80003b9e:	956fd0ef          	jal	80000cf4 <release>
}
    80003ba2:	70e2                	ld	ra,56(sp)
    80003ba4:	7442                	ld	s0,48(sp)
    80003ba6:	74a2                	ld	s1,40(sp)
    80003ba8:	7902                	ld	s2,32(sp)
    80003baa:	6121                	addi	sp,sp,64
    80003bac:	8082                	ret
    80003bae:	ec4e                	sd	s3,24(sp)
    80003bb0:	e852                	sd	s4,16(sp)
    80003bb2:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003bb4:	00004517          	auipc	a0,0x4
    80003bb8:	9ac50513          	addi	a0,a0,-1620 # 80007560 <etext+0x560>
    80003bbc:	c35fc0ef          	jal	800007f0 <panic>
    wakeup(&log);
    80003bc0:	0001c517          	auipc	a0,0x1c
    80003bc4:	e5050513          	addi	a0,a0,-432 # 8001fa10 <log>
    80003bc8:	b64fe0ef          	jal	80001f2c <wakeup>
  release(&log.lock);
    80003bcc:	0001c517          	auipc	a0,0x1c
    80003bd0:	e4450513          	addi	a0,a0,-444 # 8001fa10 <log>
    80003bd4:	920fd0ef          	jal	80000cf4 <release>
  if(do_commit){
    80003bd8:	b7e9                	j	80003ba2 <end_op+0x6e>
    80003bda:	ec4e                	sd	s3,24(sp)
    80003bdc:	e852                	sd	s4,16(sp)
    80003bde:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003be0:	0001ca97          	auipc	s5,0x1c
    80003be4:	e60a8a93          	addi	s5,s5,-416 # 8001fa40 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003be8:	0001ca17          	auipc	s4,0x1c
    80003bec:	e28a0a13          	addi	s4,s4,-472 # 8001fa10 <log>
    80003bf0:	018a2583          	lw	a1,24(s4)
    80003bf4:	012585bb          	addw	a1,a1,s2
    80003bf8:	2585                	addiw	a1,a1,1
    80003bfa:	028a2503          	lw	a0,40(s4)
    80003bfe:	efbfe0ef          	jal	80002af8 <bread>
    80003c02:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003c04:	000aa583          	lw	a1,0(s5)
    80003c08:	028a2503          	lw	a0,40(s4)
    80003c0c:	eedfe0ef          	jal	80002af8 <bread>
    80003c10:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003c12:	40000613          	li	a2,1024
    80003c16:	05850593          	addi	a1,a0,88
    80003c1a:	05848513          	addi	a0,s1,88
    80003c1e:	96efd0ef          	jal	80000d8c <memmove>
    bwrite(to);  // write the log
    80003c22:	8526                	mv	a0,s1
    80003c24:	fabfe0ef          	jal	80002bce <bwrite>
    brelse(from);
    80003c28:	854e                	mv	a0,s3
    80003c2a:	fd7fe0ef          	jal	80002c00 <brelse>
    brelse(to);
    80003c2e:	8526                	mv	a0,s1
    80003c30:	fd1fe0ef          	jal	80002c00 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003c34:	2905                	addiw	s2,s2,1
    80003c36:	0a91                	addi	s5,s5,4
    80003c38:	02ca2783          	lw	a5,44(s4)
    80003c3c:	faf94ae3          	blt	s2,a5,80003bf0 <end_op+0xbc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80003c40:	cf5ff0ef          	jal	80003934 <write_head>
    install_trans(0); // Now install writes to home locations
    80003c44:	4501                	li	a0,0
    80003c46:	d4dff0ef          	jal	80003992 <install_trans>
    log.lh.n = 0;
    80003c4a:	0001c797          	auipc	a5,0x1c
    80003c4e:	de07a923          	sw	zero,-526(a5) # 8001fa3c <log+0x2c>
    write_head();    // Erase the transaction from the log
    80003c52:	ce3ff0ef          	jal	80003934 <write_head>
    80003c56:	69e2                	ld	s3,24(sp)
    80003c58:	6a42                	ld	s4,16(sp)
    80003c5a:	6aa2                	ld	s5,8(sp)
    80003c5c:	bf29                	j	80003b76 <end_op+0x42>

0000000080003c5e <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003c5e:	1101                	addi	sp,sp,-32
    80003c60:	ec06                	sd	ra,24(sp)
    80003c62:	e822                	sd	s0,16(sp)
    80003c64:	e426                	sd	s1,8(sp)
    80003c66:	1000                	addi	s0,sp,32
    80003c68:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003c6a:	0001c517          	auipc	a0,0x1c
    80003c6e:	da650513          	addi	a0,a0,-602 # 8001fa10 <log>
    80003c72:	ff3fc0ef          	jal	80000c64 <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    80003c76:	0001c617          	auipc	a2,0x1c
    80003c7a:	dc662603          	lw	a2,-570(a2) # 8001fa3c <log+0x2c>
    80003c7e:	47f5                	li	a5,29
    80003c80:	06c7c363          	blt	a5,a2,80003ce6 <log_write+0x88>
    80003c84:	0001c797          	auipc	a5,0x1c
    80003c88:	da87a783          	lw	a5,-600(a5) # 8001fa2c <log+0x1c>
    80003c8c:	37fd                	addiw	a5,a5,-1
    80003c8e:	04f65c63          	bge	a2,a5,80003ce6 <log_write+0x88>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003c92:	0001c797          	auipc	a5,0x1c
    80003c96:	d9e7a783          	lw	a5,-610(a5) # 8001fa30 <log+0x20>
    80003c9a:	04f05c63          	blez	a5,80003cf2 <log_write+0x94>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003c9e:	4781                	li	a5,0
    80003ca0:	04c05f63          	blez	a2,80003cfe <log_write+0xa0>
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003ca4:	44cc                	lw	a1,12(s1)
    80003ca6:	0001c717          	auipc	a4,0x1c
    80003caa:	d9a70713          	addi	a4,a4,-614 # 8001fa40 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80003cae:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003cb0:	4314                	lw	a3,0(a4)
    80003cb2:	04b68663          	beq	a3,a1,80003cfe <log_write+0xa0>
  for (i = 0; i < log.lh.n; i++) {
    80003cb6:	2785                	addiw	a5,a5,1
    80003cb8:	0711                	addi	a4,a4,4
    80003cba:	fef61be3          	bne	a2,a5,80003cb0 <log_write+0x52>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003cbe:	0621                	addi	a2,a2,8
    80003cc0:	060a                	slli	a2,a2,0x2
    80003cc2:	0001c797          	auipc	a5,0x1c
    80003cc6:	d4e78793          	addi	a5,a5,-690 # 8001fa10 <log>
    80003cca:	97b2                	add	a5,a5,a2
    80003ccc:	44d8                	lw	a4,12(s1)
    80003cce:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80003cd0:	8526                	mv	a0,s1
    80003cd2:	fb3fe0ef          	jal	80002c84 <bpin>
    log.lh.n++;
    80003cd6:	0001c717          	auipc	a4,0x1c
    80003cda:	d3a70713          	addi	a4,a4,-710 # 8001fa10 <log>
    80003cde:	575c                	lw	a5,44(a4)
    80003ce0:	2785                	addiw	a5,a5,1
    80003ce2:	d75c                	sw	a5,44(a4)
    80003ce4:	a80d                	j	80003d16 <log_write+0xb8>
    panic("too big a transaction");
    80003ce6:	00004517          	auipc	a0,0x4
    80003cea:	88a50513          	addi	a0,a0,-1910 # 80007570 <etext+0x570>
    80003cee:	b03fc0ef          	jal	800007f0 <panic>
    panic("log_write outside of trans");
    80003cf2:	00004517          	auipc	a0,0x4
    80003cf6:	89650513          	addi	a0,a0,-1898 # 80007588 <etext+0x588>
    80003cfa:	af7fc0ef          	jal	800007f0 <panic>
  log.lh.block[i] = b->blockno;
    80003cfe:	00878693          	addi	a3,a5,8
    80003d02:	068a                	slli	a3,a3,0x2
    80003d04:	0001c717          	auipc	a4,0x1c
    80003d08:	d0c70713          	addi	a4,a4,-756 # 8001fa10 <log>
    80003d0c:	9736                	add	a4,a4,a3
    80003d0e:	44d4                	lw	a3,12(s1)
    80003d10:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    80003d12:	faf60fe3          	beq	a2,a5,80003cd0 <log_write+0x72>
  }
  release(&log.lock);
    80003d16:	0001c517          	auipc	a0,0x1c
    80003d1a:	cfa50513          	addi	a0,a0,-774 # 8001fa10 <log>
    80003d1e:	fd7fc0ef          	jal	80000cf4 <release>
}
    80003d22:	60e2                	ld	ra,24(sp)
    80003d24:	6442                	ld	s0,16(sp)
    80003d26:	64a2                	ld	s1,8(sp)
    80003d28:	6105                	addi	sp,sp,32
    80003d2a:	8082                	ret

0000000080003d2c <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80003d2c:	1101                	addi	sp,sp,-32
    80003d2e:	ec06                	sd	ra,24(sp)
    80003d30:	e822                	sd	s0,16(sp)
    80003d32:	e426                	sd	s1,8(sp)
    80003d34:	e04a                	sd	s2,0(sp)
    80003d36:	1000                	addi	s0,sp,32
    80003d38:	84aa                	mv	s1,a0
    80003d3a:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80003d3c:	00004597          	auipc	a1,0x4
    80003d40:	86c58593          	addi	a1,a1,-1940 # 800075a8 <etext+0x5a8>
    80003d44:	0521                	addi	a0,a0,8
    80003d46:	e95fc0ef          	jal	80000bda <initlock>
  lk->name = name;
    80003d4a:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80003d4e:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003d52:	0204a423          	sw	zero,40(s1)
}
    80003d56:	60e2                	ld	ra,24(sp)
    80003d58:	6442                	ld	s0,16(sp)
    80003d5a:	64a2                	ld	s1,8(sp)
    80003d5c:	6902                	ld	s2,0(sp)
    80003d5e:	6105                	addi	sp,sp,32
    80003d60:	8082                	ret

0000000080003d62 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80003d62:	1101                	addi	sp,sp,-32
    80003d64:	ec06                	sd	ra,24(sp)
    80003d66:	e822                	sd	s0,16(sp)
    80003d68:	e426                	sd	s1,8(sp)
    80003d6a:	e04a                	sd	s2,0(sp)
    80003d6c:	1000                	addi	s0,sp,32
    80003d6e:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003d70:	00850913          	addi	s2,a0,8
    80003d74:	854a                	mv	a0,s2
    80003d76:	eeffc0ef          	jal	80000c64 <acquire>
  while (lk->locked) {
    80003d7a:	409c                	lw	a5,0(s1)
    80003d7c:	c799                	beqz	a5,80003d8a <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    80003d7e:	85ca                	mv	a1,s2
    80003d80:	8526                	mv	a0,s1
    80003d82:	95efe0ef          	jal	80001ee0 <sleep>
  while (lk->locked) {
    80003d86:	409c                	lw	a5,0(s1)
    80003d88:	fbfd                	bnez	a5,80003d7e <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80003d8a:	4785                	li	a5,1
    80003d8c:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80003d8e:	b97fd0ef          	jal	80001924 <myproc>
    80003d92:	591c                	lw	a5,48(a0)
    80003d94:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80003d96:	854a                	mv	a0,s2
    80003d98:	f5dfc0ef          	jal	80000cf4 <release>
}
    80003d9c:	60e2                	ld	ra,24(sp)
    80003d9e:	6442                	ld	s0,16(sp)
    80003da0:	64a2                	ld	s1,8(sp)
    80003da2:	6902                	ld	s2,0(sp)
    80003da4:	6105                	addi	sp,sp,32
    80003da6:	8082                	ret

0000000080003da8 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80003da8:	1101                	addi	sp,sp,-32
    80003daa:	ec06                	sd	ra,24(sp)
    80003dac:	e822                	sd	s0,16(sp)
    80003dae:	e426                	sd	s1,8(sp)
    80003db0:	e04a                	sd	s2,0(sp)
    80003db2:	1000                	addi	s0,sp,32
    80003db4:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003db6:	00850913          	addi	s2,a0,8
    80003dba:	854a                	mv	a0,s2
    80003dbc:	ea9fc0ef          	jal	80000c64 <acquire>
  lk->locked = 0;
    80003dc0:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003dc4:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80003dc8:	8526                	mv	a0,s1
    80003dca:	962fe0ef          	jal	80001f2c <wakeup>
  release(&lk->lk);
    80003dce:	854a                	mv	a0,s2
    80003dd0:	f25fc0ef          	jal	80000cf4 <release>
}
    80003dd4:	60e2                	ld	ra,24(sp)
    80003dd6:	6442                	ld	s0,16(sp)
    80003dd8:	64a2                	ld	s1,8(sp)
    80003dda:	6902                	ld	s2,0(sp)
    80003ddc:	6105                	addi	sp,sp,32
    80003dde:	8082                	ret

0000000080003de0 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80003de0:	7179                	addi	sp,sp,-48
    80003de2:	f406                	sd	ra,40(sp)
    80003de4:	f022                	sd	s0,32(sp)
    80003de6:	ec26                	sd	s1,24(sp)
    80003de8:	e84a                	sd	s2,16(sp)
    80003dea:	1800                	addi	s0,sp,48
    80003dec:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    80003dee:	00850913          	addi	s2,a0,8
    80003df2:	854a                	mv	a0,s2
    80003df4:	e71fc0ef          	jal	80000c64 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80003df8:	409c                	lw	a5,0(s1)
    80003dfa:	ef81                	bnez	a5,80003e12 <holdingsleep+0x32>
    80003dfc:	4481                	li	s1,0
  release(&lk->lk);
    80003dfe:	854a                	mv	a0,s2
    80003e00:	ef5fc0ef          	jal	80000cf4 <release>
  return r;
}
    80003e04:	8526                	mv	a0,s1
    80003e06:	70a2                	ld	ra,40(sp)
    80003e08:	7402                	ld	s0,32(sp)
    80003e0a:	64e2                	ld	s1,24(sp)
    80003e0c:	6942                	ld	s2,16(sp)
    80003e0e:	6145                	addi	sp,sp,48
    80003e10:	8082                	ret
    80003e12:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80003e14:	0284a983          	lw	s3,40(s1)
    80003e18:	b0dfd0ef          	jal	80001924 <myproc>
    80003e1c:	5904                	lw	s1,48(a0)
    80003e1e:	413484b3          	sub	s1,s1,s3
    80003e22:	0014b493          	seqz	s1,s1
    80003e26:	69a2                	ld	s3,8(sp)
    80003e28:	bfd9                	j	80003dfe <holdingsleep+0x1e>

0000000080003e2a <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80003e2a:	1141                	addi	sp,sp,-16
    80003e2c:	e406                	sd	ra,8(sp)
    80003e2e:	e022                	sd	s0,0(sp)
    80003e30:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80003e32:	00003597          	auipc	a1,0x3
    80003e36:	78658593          	addi	a1,a1,1926 # 800075b8 <etext+0x5b8>
    80003e3a:	0001c517          	auipc	a0,0x1c
    80003e3e:	d1e50513          	addi	a0,a0,-738 # 8001fb58 <ftable>
    80003e42:	d99fc0ef          	jal	80000bda <initlock>
}
    80003e46:	60a2                	ld	ra,8(sp)
    80003e48:	6402                	ld	s0,0(sp)
    80003e4a:	0141                	addi	sp,sp,16
    80003e4c:	8082                	ret

0000000080003e4e <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    80003e4e:	1101                	addi	sp,sp,-32
    80003e50:	ec06                	sd	ra,24(sp)
    80003e52:	e822                	sd	s0,16(sp)
    80003e54:	e426                	sd	s1,8(sp)
    80003e56:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80003e58:	0001c517          	auipc	a0,0x1c
    80003e5c:	d0050513          	addi	a0,a0,-768 # 8001fb58 <ftable>
    80003e60:	e05fc0ef          	jal	80000c64 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003e64:	0001c497          	auipc	s1,0x1c
    80003e68:	d0c48493          	addi	s1,s1,-756 # 8001fb70 <ftable+0x18>
    80003e6c:	0001d717          	auipc	a4,0x1d
    80003e70:	ca470713          	addi	a4,a4,-860 # 80020b10 <disk>
    if(f->ref == 0){
    80003e74:	40dc                	lw	a5,4(s1)
    80003e76:	cf89                	beqz	a5,80003e90 <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003e78:	02848493          	addi	s1,s1,40
    80003e7c:	fee49ce3          	bne	s1,a4,80003e74 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80003e80:	0001c517          	auipc	a0,0x1c
    80003e84:	cd850513          	addi	a0,a0,-808 # 8001fb58 <ftable>
    80003e88:	e6dfc0ef          	jal	80000cf4 <release>
  return 0;
    80003e8c:	4481                	li	s1,0
    80003e8e:	a809                	j	80003ea0 <filealloc+0x52>
      f->ref = 1;
    80003e90:	4785                	li	a5,1
    80003e92:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80003e94:	0001c517          	auipc	a0,0x1c
    80003e98:	cc450513          	addi	a0,a0,-828 # 8001fb58 <ftable>
    80003e9c:	e59fc0ef          	jal	80000cf4 <release>
}
    80003ea0:	8526                	mv	a0,s1
    80003ea2:	60e2                	ld	ra,24(sp)
    80003ea4:	6442                	ld	s0,16(sp)
    80003ea6:	64a2                	ld	s1,8(sp)
    80003ea8:	6105                	addi	sp,sp,32
    80003eaa:	8082                	ret

0000000080003eac <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80003eac:	1101                	addi	sp,sp,-32
    80003eae:	ec06                	sd	ra,24(sp)
    80003eb0:	e822                	sd	s0,16(sp)
    80003eb2:	e426                	sd	s1,8(sp)
    80003eb4:	1000                	addi	s0,sp,32
    80003eb6:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80003eb8:	0001c517          	auipc	a0,0x1c
    80003ebc:	ca050513          	addi	a0,a0,-864 # 8001fb58 <ftable>
    80003ec0:	da5fc0ef          	jal	80000c64 <acquire>
  if(f->ref < 1)
    80003ec4:	40dc                	lw	a5,4(s1)
    80003ec6:	02f05063          	blez	a5,80003ee6 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80003eca:	2785                	addiw	a5,a5,1
    80003ecc:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80003ece:	0001c517          	auipc	a0,0x1c
    80003ed2:	c8a50513          	addi	a0,a0,-886 # 8001fb58 <ftable>
    80003ed6:	e1ffc0ef          	jal	80000cf4 <release>
  return f;
}
    80003eda:	8526                	mv	a0,s1
    80003edc:	60e2                	ld	ra,24(sp)
    80003ede:	6442                	ld	s0,16(sp)
    80003ee0:	64a2                	ld	s1,8(sp)
    80003ee2:	6105                	addi	sp,sp,32
    80003ee4:	8082                	ret
    panic("filedup");
    80003ee6:	00003517          	auipc	a0,0x3
    80003eea:	6da50513          	addi	a0,a0,1754 # 800075c0 <etext+0x5c0>
    80003eee:	903fc0ef          	jal	800007f0 <panic>

0000000080003ef2 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80003ef2:	7139                	addi	sp,sp,-64
    80003ef4:	fc06                	sd	ra,56(sp)
    80003ef6:	f822                	sd	s0,48(sp)
    80003ef8:	f426                	sd	s1,40(sp)
    80003efa:	0080                	addi	s0,sp,64
    80003efc:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80003efe:	0001c517          	auipc	a0,0x1c
    80003f02:	c5a50513          	addi	a0,a0,-934 # 8001fb58 <ftable>
    80003f06:	d5ffc0ef          	jal	80000c64 <acquire>
  if(f->ref < 1)
    80003f0a:	40dc                	lw	a5,4(s1)
    80003f0c:	04f05a63          	blez	a5,80003f60 <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    80003f10:	37fd                	addiw	a5,a5,-1
    80003f12:	c0dc                	sw	a5,4(s1)
    80003f14:	06f04063          	bgtz	a5,80003f74 <fileclose+0x82>
    80003f18:	f04a                	sd	s2,32(sp)
    80003f1a:	ec4e                	sd	s3,24(sp)
    80003f1c:	e852                	sd	s4,16(sp)
    80003f1e:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    80003f20:	0004a903          	lw	s2,0(s1)
    80003f24:	0094c783          	lbu	a5,9(s1)
    80003f28:	89be                	mv	s3,a5
    80003f2a:	689c                	ld	a5,16(s1)
    80003f2c:	8a3e                	mv	s4,a5
    80003f2e:	6c9c                	ld	a5,24(s1)
    80003f30:	8abe                	mv	s5,a5
  f->ref = 0;
    80003f32:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80003f36:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80003f3a:	0001c517          	auipc	a0,0x1c
    80003f3e:	c1e50513          	addi	a0,a0,-994 # 8001fb58 <ftable>
    80003f42:	db3fc0ef          	jal	80000cf4 <release>

  if(ff.type == FD_PIPE){
    80003f46:	4785                	li	a5,1
    80003f48:	04f90163          	beq	s2,a5,80003f8a <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    80003f4c:	ffe9079b          	addiw	a5,s2,-2
    80003f50:	4705                	li	a4,1
    80003f52:	04f77563          	bgeu	a4,a5,80003f9c <fileclose+0xaa>
    80003f56:	7902                	ld	s2,32(sp)
    80003f58:	69e2                	ld	s3,24(sp)
    80003f5a:	6a42                	ld	s4,16(sp)
    80003f5c:	6aa2                	ld	s5,8(sp)
    80003f5e:	a00d                	j	80003f80 <fileclose+0x8e>
    80003f60:	f04a                	sd	s2,32(sp)
    80003f62:	ec4e                	sd	s3,24(sp)
    80003f64:	e852                	sd	s4,16(sp)
    80003f66:	e456                	sd	s5,8(sp)
    panic("fileclose");
    80003f68:	00003517          	auipc	a0,0x3
    80003f6c:	66050513          	addi	a0,a0,1632 # 800075c8 <etext+0x5c8>
    80003f70:	881fc0ef          	jal	800007f0 <panic>
    release(&ftable.lock);
    80003f74:	0001c517          	auipc	a0,0x1c
    80003f78:	be450513          	addi	a0,a0,-1052 # 8001fb58 <ftable>
    80003f7c:	d79fc0ef          	jal	80000cf4 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    80003f80:	70e2                	ld	ra,56(sp)
    80003f82:	7442                	ld	s0,48(sp)
    80003f84:	74a2                	ld	s1,40(sp)
    80003f86:	6121                	addi	sp,sp,64
    80003f88:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80003f8a:	85ce                	mv	a1,s3
    80003f8c:	8552                	mv	a0,s4
    80003f8e:	332000ef          	jal	800042c0 <pipeclose>
    80003f92:	7902                	ld	s2,32(sp)
    80003f94:	69e2                	ld	s3,24(sp)
    80003f96:	6a42                	ld	s4,16(sp)
    80003f98:	6aa2                	ld	s5,8(sp)
    80003f9a:	b7dd                	j	80003f80 <fileclose+0x8e>
    begin_op();
    80003f9c:	b29ff0ef          	jal	80003ac4 <begin_op>
    iput(ff.ip);
    80003fa0:	8556                	mv	a0,s5
    80003fa2:	be2ff0ef          	jal	80003384 <iput>
    end_op();
    80003fa6:	b8fff0ef          	jal	80003b34 <end_op>
    80003faa:	7902                	ld	s2,32(sp)
    80003fac:	69e2                	ld	s3,24(sp)
    80003fae:	6a42                	ld	s4,16(sp)
    80003fb0:	6aa2                	ld	s5,8(sp)
    80003fb2:	b7f9                	j	80003f80 <fileclose+0x8e>

0000000080003fb4 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80003fb4:	715d                	addi	sp,sp,-80
    80003fb6:	e486                	sd	ra,72(sp)
    80003fb8:	e0a2                	sd	s0,64(sp)
    80003fba:	fc26                	sd	s1,56(sp)
    80003fbc:	f052                	sd	s4,32(sp)
    80003fbe:	0880                	addi	s0,sp,80
    80003fc0:	84aa                	mv	s1,a0
    80003fc2:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    80003fc4:	961fd0ef          	jal	80001924 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80003fc8:	409c                	lw	a5,0(s1)
    80003fca:	37f9                	addiw	a5,a5,-2
    80003fcc:	4705                	li	a4,1
    80003fce:	04f76263          	bltu	a4,a5,80004012 <filestat+0x5e>
    80003fd2:	f84a                	sd	s2,48(sp)
    80003fd4:	f44e                	sd	s3,40(sp)
    80003fd6:	89aa                	mv	s3,a0
    ilock(f->ip);
    80003fd8:	6c88                	ld	a0,24(s1)
    80003fda:	a28ff0ef          	jal	80003202 <ilock>
    stati(f->ip, &st);
    80003fde:	fb840913          	addi	s2,s0,-72
    80003fe2:	85ca                	mv	a1,s2
    80003fe4:	6c88                	ld	a0,24(s1)
    80003fe6:	c48ff0ef          	jal	8000342e <stati>
    iunlock(f->ip);
    80003fea:	6c88                	ld	a0,24(s1)
    80003fec:	ac4ff0ef          	jal	800032b0 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    80003ff0:	46e1                	li	a3,24
    80003ff2:	864a                	mv	a2,s2
    80003ff4:	85d2                	mv	a1,s4
    80003ff6:	0509b503          	ld	a0,80(s3)
    80003ffa:	dbafd0ef          	jal	800015b4 <copyout>
    80003ffe:	41f5551b          	sraiw	a0,a0,0x1f
    80004002:	7942                	ld	s2,48(sp)
    80004004:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80004006:	60a6                	ld	ra,72(sp)
    80004008:	6406                	ld	s0,64(sp)
    8000400a:	74e2                	ld	s1,56(sp)
    8000400c:	7a02                	ld	s4,32(sp)
    8000400e:	6161                	addi	sp,sp,80
    80004010:	8082                	ret
  return -1;
    80004012:	557d                	li	a0,-1
    80004014:	bfcd                	j	80004006 <filestat+0x52>

0000000080004016 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80004016:	7179                	addi	sp,sp,-48
    80004018:	f406                	sd	ra,40(sp)
    8000401a:	f022                	sd	s0,32(sp)
    8000401c:	e84a                	sd	s2,16(sp)
    8000401e:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    80004020:	00854783          	lbu	a5,8(a0)
    80004024:	c3c5                	beqz	a5,800040c4 <fileread+0xae>
    80004026:	ec26                	sd	s1,24(sp)
    80004028:	e44e                	sd	s3,8(sp)
    8000402a:	84aa                	mv	s1,a0
    8000402c:	892e                	mv	s2,a1
    8000402e:	89b2                	mv	s3,a2
    return -1;

  if(f->type == FD_PIPE){
    80004030:	411c                	lw	a5,0(a0)
    80004032:	4705                	li	a4,1
    80004034:	04e78363          	beq	a5,a4,8000407a <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80004038:	470d                	li	a4,3
    8000403a:	04e78763          	beq	a5,a4,80004088 <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    8000403e:	4709                	li	a4,2
    80004040:	06e79a63          	bne	a5,a4,800040b4 <fileread+0x9e>
    ilock(f->ip);
    80004044:	6d08                	ld	a0,24(a0)
    80004046:	9bcff0ef          	jal	80003202 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    8000404a:	874e                	mv	a4,s3
    8000404c:	5094                	lw	a3,32(s1)
    8000404e:	864a                	mv	a2,s2
    80004050:	4585                	li	a1,1
    80004052:	6c88                	ld	a0,24(s1)
    80004054:	c08ff0ef          	jal	8000345c <readi>
    80004058:	892a                	mv	s2,a0
    8000405a:	00a05563          	blez	a0,80004064 <fileread+0x4e>
      f->off += r;
    8000405e:	509c                	lw	a5,32(s1)
    80004060:	9fa9                	addw	a5,a5,a0
    80004062:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    80004064:	6c88                	ld	a0,24(s1)
    80004066:	a4aff0ef          	jal	800032b0 <iunlock>
    8000406a:	64e2                	ld	s1,24(sp)
    8000406c:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    8000406e:	854a                	mv	a0,s2
    80004070:	70a2                	ld	ra,40(sp)
    80004072:	7402                	ld	s0,32(sp)
    80004074:	6942                	ld	s2,16(sp)
    80004076:	6145                	addi	sp,sp,48
    80004078:	8082                	ret
    r = piperead(f->pipe, addr, n);
    8000407a:	6908                	ld	a0,16(a0)
    8000407c:	39a000ef          	jal	80004416 <piperead>
    80004080:	892a                	mv	s2,a0
    80004082:	64e2                	ld	s1,24(sp)
    80004084:	69a2                	ld	s3,8(sp)
    80004086:	b7e5                	j	8000406e <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80004088:	02451783          	lh	a5,36(a0)
    8000408c:	03079693          	slli	a3,a5,0x30
    80004090:	92c1                	srli	a3,a3,0x30
    80004092:	4725                	li	a4,9
    80004094:	02d76663          	bltu	a4,a3,800040c0 <fileread+0xaa>
    80004098:	0792                	slli	a5,a5,0x4
    8000409a:	0001c717          	auipc	a4,0x1c
    8000409e:	a1e70713          	addi	a4,a4,-1506 # 8001fab8 <devsw>
    800040a2:	97ba                	add	a5,a5,a4
    800040a4:	639c                	ld	a5,0(a5)
    800040a6:	c395                	beqz	a5,800040ca <fileread+0xb4>
    r = devsw[f->major].read(1, addr, n);
    800040a8:	4505                	li	a0,1
    800040aa:	9782                	jalr	a5
    800040ac:	892a                	mv	s2,a0
    800040ae:	64e2                	ld	s1,24(sp)
    800040b0:	69a2                	ld	s3,8(sp)
    800040b2:	bf75                	j	8000406e <fileread+0x58>
    panic("fileread");
    800040b4:	00003517          	auipc	a0,0x3
    800040b8:	52450513          	addi	a0,a0,1316 # 800075d8 <etext+0x5d8>
    800040bc:	f34fc0ef          	jal	800007f0 <panic>
    800040c0:	64e2                	ld	s1,24(sp)
    800040c2:	69a2                	ld	s3,8(sp)
    return -1;
    800040c4:	57fd                	li	a5,-1
    800040c6:	893e                	mv	s2,a5
    800040c8:	b75d                	j	8000406e <fileread+0x58>
    800040ca:	64e2                	ld	s1,24(sp)
    800040cc:	69a2                	ld	s3,8(sp)
    800040ce:	bfdd                	j	800040c4 <fileread+0xae>

00000000800040d0 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    800040d0:	00954783          	lbu	a5,9(a0)
    800040d4:	12078463          	beqz	a5,800041fc <filewrite+0x12c>
{
    800040d8:	711d                	addi	sp,sp,-96
    800040da:	ec86                	sd	ra,88(sp)
    800040dc:	e8a2                	sd	s0,80(sp)
    800040de:	e0ca                	sd	s2,64(sp)
    800040e0:	f456                	sd	s5,40(sp)
    800040e2:	f05a                	sd	s6,32(sp)
    800040e4:	1080                	addi	s0,sp,96
    800040e6:	892a                	mv	s2,a0
    800040e8:	8b2e                	mv	s6,a1
    800040ea:	8ab2                	mv	s5,a2
    return -1;

  if(f->type == FD_PIPE){
    800040ec:	411c                	lw	a5,0(a0)
    800040ee:	4705                	li	a4,1
    800040f0:	02e78a63          	beq	a5,a4,80004124 <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800040f4:	470d                	li	a4,3
    800040f6:	02e78b63          	beq	a5,a4,8000412c <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800040fa:	4709                	li	a4,2
    800040fc:	0ce79f63          	bne	a5,a4,800041da <filewrite+0x10a>
    80004100:	f852                	sd	s4,48(sp)
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    80004102:	0ac05a63          	blez	a2,800041b6 <filewrite+0xe6>
    80004106:	e4a6                	sd	s1,72(sp)
    80004108:	fc4e                	sd	s3,56(sp)
    8000410a:	ec5e                	sd	s7,24(sp)
    8000410c:	e862                	sd	s8,16(sp)
    8000410e:	e466                	sd	s9,8(sp)
    int i = 0;
    80004110:	4a01                	li	s4,0
      int n1 = n - i;
      if(n1 > max)
    80004112:	6b85                	lui	s7,0x1
    80004114:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80004118:	6785                	lui	a5,0x1
    8000411a:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    8000411e:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004120:	4c05                	li	s8,1
    80004122:	a8ad                	j	8000419c <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    80004124:	6908                	ld	a0,16(a0)
    80004126:	1f8000ef          	jal	8000431e <pipewrite>
    8000412a:	a04d                	j	800041cc <filewrite+0xfc>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    8000412c:	02451783          	lh	a5,36(a0)
    80004130:	03079693          	slli	a3,a5,0x30
    80004134:	92c1                	srli	a3,a3,0x30
    80004136:	4725                	li	a4,9
    80004138:	0ad76d63          	bltu	a4,a3,800041f2 <filewrite+0x122>
    8000413c:	0792                	slli	a5,a5,0x4
    8000413e:	0001c717          	auipc	a4,0x1c
    80004142:	97a70713          	addi	a4,a4,-1670 # 8001fab8 <devsw>
    80004146:	97ba                	add	a5,a5,a4
    80004148:	679c                	ld	a5,8(a5)
    8000414a:	c7c5                	beqz	a5,800041f2 <filewrite+0x122>
    ret = devsw[f->major].write(1, addr, n);
    8000414c:	4505                	li	a0,1
    8000414e:	9782                	jalr	a5
    80004150:	a8b5                	j	800041cc <filewrite+0xfc>
      if(n1 > max)
    80004152:	2981                	sext.w	s3,s3
      begin_op();
    80004154:	971ff0ef          	jal	80003ac4 <begin_op>
      ilock(f->ip);
    80004158:	01893503          	ld	a0,24(s2)
    8000415c:	8a6ff0ef          	jal	80003202 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004160:	874e                	mv	a4,s3
    80004162:	02092683          	lw	a3,32(s2)
    80004166:	016a0633          	add	a2,s4,s6
    8000416a:	85e2                	mv	a1,s8
    8000416c:	01893503          	ld	a0,24(s2)
    80004170:	bdeff0ef          	jal	8000354e <writei>
    80004174:	84aa                	mv	s1,a0
    80004176:	00a05763          	blez	a0,80004184 <filewrite+0xb4>
        f->off += r;
    8000417a:	02092783          	lw	a5,32(s2)
    8000417e:	9fa9                	addw	a5,a5,a0
    80004180:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    80004184:	01893503          	ld	a0,24(s2)
    80004188:	928ff0ef          	jal	800032b0 <iunlock>
      end_op();
    8000418c:	9a9ff0ef          	jal	80003b34 <end_op>

      if(r != n1){
    80004190:	02999563          	bne	s3,s1,800041ba <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    80004194:	01448a3b          	addw	s4,s1,s4
    while(i < n){
    80004198:	015a5963          	bge	s4,s5,800041aa <filewrite+0xda>
      int n1 = n - i;
    8000419c:	414a87bb          	subw	a5,s5,s4
    800041a0:	89be                	mv	s3,a5
      if(n1 > max)
    800041a2:	fafbd8e3          	bge	s7,a5,80004152 <filewrite+0x82>
    800041a6:	89e6                	mv	s3,s9
    800041a8:	b76d                	j	80004152 <filewrite+0x82>
    800041aa:	64a6                	ld	s1,72(sp)
    800041ac:	79e2                	ld	s3,56(sp)
    800041ae:	6be2                	ld	s7,24(sp)
    800041b0:	6c42                	ld	s8,16(sp)
    800041b2:	6ca2                	ld	s9,8(sp)
    800041b4:	a801                	j	800041c4 <filewrite+0xf4>
    int i = 0;
    800041b6:	4a01                	li	s4,0
    800041b8:	a031                	j	800041c4 <filewrite+0xf4>
    800041ba:	64a6                	ld	s1,72(sp)
    800041bc:	79e2                	ld	s3,56(sp)
    800041be:	6be2                	ld	s7,24(sp)
    800041c0:	6c42                	ld	s8,16(sp)
    800041c2:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    800041c4:	034a9963          	bne	s5,s4,800041f6 <filewrite+0x126>
    800041c8:	8556                	mv	a0,s5
    800041ca:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    800041cc:	60e6                	ld	ra,88(sp)
    800041ce:	6446                	ld	s0,80(sp)
    800041d0:	6906                	ld	s2,64(sp)
    800041d2:	7aa2                	ld	s5,40(sp)
    800041d4:	7b02                	ld	s6,32(sp)
    800041d6:	6125                	addi	sp,sp,96
    800041d8:	8082                	ret
    800041da:	e4a6                	sd	s1,72(sp)
    800041dc:	fc4e                	sd	s3,56(sp)
    800041de:	f852                	sd	s4,48(sp)
    800041e0:	ec5e                	sd	s7,24(sp)
    800041e2:	e862                	sd	s8,16(sp)
    800041e4:	e466                	sd	s9,8(sp)
    panic("filewrite");
    800041e6:	00003517          	auipc	a0,0x3
    800041ea:	40250513          	addi	a0,a0,1026 # 800075e8 <etext+0x5e8>
    800041ee:	e02fc0ef          	jal	800007f0 <panic>
    return -1;
    800041f2:	557d                	li	a0,-1
    800041f4:	bfe1                	j	800041cc <filewrite+0xfc>
    ret = (i == n ? n : -1);
    800041f6:	557d                	li	a0,-1
    800041f8:	7a42                	ld	s4,48(sp)
    800041fa:	bfc9                	j	800041cc <filewrite+0xfc>
    return -1;
    800041fc:	557d                	li	a0,-1
}
    800041fe:	8082                	ret

0000000080004200 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    80004200:	7179                	addi	sp,sp,-48
    80004202:	f406                	sd	ra,40(sp)
    80004204:	f022                	sd	s0,32(sp)
    80004206:	ec26                	sd	s1,24(sp)
    80004208:	e052                	sd	s4,0(sp)
    8000420a:	1800                	addi	s0,sp,48
    8000420c:	84aa                	mv	s1,a0
    8000420e:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    80004210:	0005b023          	sd	zero,0(a1)
    80004214:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80004218:	c37ff0ef          	jal	80003e4e <filealloc>
    8000421c:	e088                	sd	a0,0(s1)
    8000421e:	c549                	beqz	a0,800042a8 <pipealloc+0xa8>
    80004220:	c2fff0ef          	jal	80003e4e <filealloc>
    80004224:	00aa3023          	sd	a0,0(s4)
    80004228:	cd25                	beqz	a0,800042a0 <pipealloc+0xa0>
    8000422a:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    8000422c:	955fc0ef          	jal	80000b80 <kalloc>
    80004230:	892a                	mv	s2,a0
    80004232:	c12d                	beqz	a0,80004294 <pipealloc+0x94>
    80004234:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    80004236:	4985                	li	s3,1
    80004238:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    8000423c:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    80004240:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    80004244:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004248:	00003597          	auipc	a1,0x3
    8000424c:	3b058593          	addi	a1,a1,944 # 800075f8 <etext+0x5f8>
    80004250:	98bfc0ef          	jal	80000bda <initlock>
  (*f0)->type = FD_PIPE;
    80004254:	609c                	ld	a5,0(s1)
    80004256:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    8000425a:	609c                	ld	a5,0(s1)
    8000425c:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004260:	609c                	ld	a5,0(s1)
    80004262:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80004266:	609c                	ld	a5,0(s1)
    80004268:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    8000426c:	000a3783          	ld	a5,0(s4)
    80004270:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80004274:	000a3783          	ld	a5,0(s4)
    80004278:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    8000427c:	000a3783          	ld	a5,0(s4)
    80004280:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80004284:	000a3783          	ld	a5,0(s4)
    80004288:	0127b823          	sd	s2,16(a5)
  return 0;
    8000428c:	4501                	li	a0,0
    8000428e:	6942                	ld	s2,16(sp)
    80004290:	69a2                	ld	s3,8(sp)
    80004292:	a00d                	j	800042b4 <pipealloc+0xb4>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80004294:	6088                	ld	a0,0(s1)
    80004296:	c119                	beqz	a0,8000429c <pipealloc+0x9c>
    80004298:	6942                	ld	s2,16(sp)
    8000429a:	a029                	j	800042a4 <pipealloc+0xa4>
    8000429c:	6942                	ld	s2,16(sp)
    8000429e:	a029                	j	800042a8 <pipealloc+0xa8>
    800042a0:	6088                	ld	a0,0(s1)
    800042a2:	c901                	beqz	a0,800042b2 <pipealloc+0xb2>
    fileclose(*f0);
    800042a4:	c4fff0ef          	jal	80003ef2 <fileclose>
  if(*f1)
    800042a8:	000a3503          	ld	a0,0(s4)
    800042ac:	c119                	beqz	a0,800042b2 <pipealloc+0xb2>
    fileclose(*f1);
    800042ae:	c45ff0ef          	jal	80003ef2 <fileclose>
  return -1;
    800042b2:	557d                	li	a0,-1
}
    800042b4:	70a2                	ld	ra,40(sp)
    800042b6:	7402                	ld	s0,32(sp)
    800042b8:	64e2                	ld	s1,24(sp)
    800042ba:	6a02                	ld	s4,0(sp)
    800042bc:	6145                	addi	sp,sp,48
    800042be:	8082                	ret

00000000800042c0 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    800042c0:	1101                	addi	sp,sp,-32
    800042c2:	ec06                	sd	ra,24(sp)
    800042c4:	e822                	sd	s0,16(sp)
    800042c6:	e426                	sd	s1,8(sp)
    800042c8:	e04a                	sd	s2,0(sp)
    800042ca:	1000                	addi	s0,sp,32
    800042cc:	84aa                	mv	s1,a0
    800042ce:	892e                	mv	s2,a1
  acquire(&pi->lock);
    800042d0:	995fc0ef          	jal	80000c64 <acquire>
  if(writable){
    800042d4:	02090763          	beqz	s2,80004302 <pipeclose+0x42>
    pi->writeopen = 0;
    800042d8:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    800042dc:	21848513          	addi	a0,s1,536
    800042e0:	c4dfd0ef          	jal	80001f2c <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    800042e4:	2204a783          	lw	a5,544(s1)
    800042e8:	e781                	bnez	a5,800042f0 <pipeclose+0x30>
    800042ea:	2244a783          	lw	a5,548(s1)
    800042ee:	c38d                	beqz	a5,80004310 <pipeclose+0x50>
    release(&pi->lock);
    kfree((char*)pi);
  } else
    release(&pi->lock);
    800042f0:	8526                	mv	a0,s1
    800042f2:	a03fc0ef          	jal	80000cf4 <release>
}
    800042f6:	60e2                	ld	ra,24(sp)
    800042f8:	6442                	ld	s0,16(sp)
    800042fa:	64a2                	ld	s1,8(sp)
    800042fc:	6902                	ld	s2,0(sp)
    800042fe:	6105                	addi	sp,sp,32
    80004300:	8082                	ret
    pi->readopen = 0;
    80004302:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80004306:	21c48513          	addi	a0,s1,540
    8000430a:	c23fd0ef          	jal	80001f2c <wakeup>
    8000430e:	bfd9                	j	800042e4 <pipeclose+0x24>
    release(&pi->lock);
    80004310:	8526                	mv	a0,s1
    80004312:	9e3fc0ef          	jal	80000cf4 <release>
    kfree((char*)pi);
    80004316:	8526                	mv	a0,s1
    80004318:	f80fc0ef          	jal	80000a98 <kfree>
    8000431c:	bfe9                	j	800042f6 <pipeclose+0x36>

000000008000431e <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    8000431e:	7159                	addi	sp,sp,-112
    80004320:	f486                	sd	ra,104(sp)
    80004322:	f0a2                	sd	s0,96(sp)
    80004324:	eca6                	sd	s1,88(sp)
    80004326:	e8ca                	sd	s2,80(sp)
    80004328:	e4ce                	sd	s3,72(sp)
    8000432a:	e0d2                	sd	s4,64(sp)
    8000432c:	fc56                	sd	s5,56(sp)
    8000432e:	1880                	addi	s0,sp,112
    80004330:	84aa                	mv	s1,a0
    80004332:	8aae                	mv	s5,a1
    80004334:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80004336:	deefd0ef          	jal	80001924 <myproc>
    8000433a:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    8000433c:	8526                	mv	a0,s1
    8000433e:	927fc0ef          	jal	80000c64 <acquire>
  while(i < n){
    80004342:	0d405263          	blez	s4,80004406 <pipewrite+0xe8>
    80004346:	f85a                	sd	s6,48(sp)
    80004348:	f45e                	sd	s7,40(sp)
    8000434a:	f062                	sd	s8,32(sp)
    8000434c:	ec66                	sd	s9,24(sp)
    8000434e:	e86a                	sd	s10,16(sp)
  int i = 0;
    80004350:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004352:	f9f40c13          	addi	s8,s0,-97
    80004356:	4b85                	li	s7,1
    80004358:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    8000435a:	21848d13          	addi	s10,s1,536
      sleep(&pi->nwrite, &pi->lock);
    8000435e:	21c48c93          	addi	s9,s1,540
    80004362:	a82d                	j	8000439c <pipewrite+0x7e>
      release(&pi->lock);
    80004364:	8526                	mv	a0,s1
    80004366:	98ffc0ef          	jal	80000cf4 <release>
      return -1;
    8000436a:	597d                	li	s2,-1
    8000436c:	7b42                	ld	s6,48(sp)
    8000436e:	7ba2                	ld	s7,40(sp)
    80004370:	7c02                	ld	s8,32(sp)
    80004372:	6ce2                	ld	s9,24(sp)
    80004374:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80004376:	854a                	mv	a0,s2
    80004378:	70a6                	ld	ra,104(sp)
    8000437a:	7406                	ld	s0,96(sp)
    8000437c:	64e6                	ld	s1,88(sp)
    8000437e:	6946                	ld	s2,80(sp)
    80004380:	69a6                	ld	s3,72(sp)
    80004382:	6a06                	ld	s4,64(sp)
    80004384:	7ae2                	ld	s5,56(sp)
    80004386:	6165                	addi	sp,sp,112
    80004388:	8082                	ret
      wakeup(&pi->nread);
    8000438a:	856a                	mv	a0,s10
    8000438c:	ba1fd0ef          	jal	80001f2c <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80004390:	85a6                	mv	a1,s1
    80004392:	8566                	mv	a0,s9
    80004394:	b4dfd0ef          	jal	80001ee0 <sleep>
  while(i < n){
    80004398:	05495a63          	bge	s2,s4,800043ec <pipewrite+0xce>
    if(pi->readopen == 0 || killed(pr)){
    8000439c:	2204a783          	lw	a5,544(s1)
    800043a0:	d3f1                	beqz	a5,80004364 <pipewrite+0x46>
    800043a2:	854e                	mv	a0,s3
    800043a4:	d79fd0ef          	jal	8000211c <killed>
    800043a8:	fd55                	bnez	a0,80004364 <pipewrite+0x46>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    800043aa:	2184a783          	lw	a5,536(s1)
    800043ae:	21c4a703          	lw	a4,540(s1)
    800043b2:	2007879b          	addiw	a5,a5,512
    800043b6:	fcf70ae3          	beq	a4,a5,8000438a <pipewrite+0x6c>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    800043ba:	86de                	mv	a3,s7
    800043bc:	01590633          	add	a2,s2,s5
    800043c0:	85e2                	mv	a1,s8
    800043c2:	0509b503          	ld	a0,80(s3)
    800043c6:	a9cfd0ef          	jal	80001662 <copyin>
    800043ca:	05650063          	beq	a0,s6,8000440a <pipewrite+0xec>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    800043ce:	21c4a783          	lw	a5,540(s1)
    800043d2:	0017871b          	addiw	a4,a5,1
    800043d6:	20e4ae23          	sw	a4,540(s1)
    800043da:	1ff7f793          	andi	a5,a5,511
    800043de:	97a6                	add	a5,a5,s1
    800043e0:	f9f44703          	lbu	a4,-97(s0)
    800043e4:	00e78c23          	sb	a4,24(a5)
      i++;
    800043e8:	2905                	addiw	s2,s2,1
    800043ea:	b77d                	j	80004398 <pipewrite+0x7a>
    800043ec:	7b42                	ld	s6,48(sp)
    800043ee:	7ba2                	ld	s7,40(sp)
    800043f0:	7c02                	ld	s8,32(sp)
    800043f2:	6ce2                	ld	s9,24(sp)
    800043f4:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    800043f6:	21848513          	addi	a0,s1,536
    800043fa:	b33fd0ef          	jal	80001f2c <wakeup>
  release(&pi->lock);
    800043fe:	8526                	mv	a0,s1
    80004400:	8f5fc0ef          	jal	80000cf4 <release>
  return i;
    80004404:	bf8d                	j	80004376 <pipewrite+0x58>
  int i = 0;
    80004406:	4901                	li	s2,0
    80004408:	b7fd                	j	800043f6 <pipewrite+0xd8>
    8000440a:	7b42                	ld	s6,48(sp)
    8000440c:	7ba2                	ld	s7,40(sp)
    8000440e:	7c02                	ld	s8,32(sp)
    80004410:	6ce2                	ld	s9,24(sp)
    80004412:	6d42                	ld	s10,16(sp)
    80004414:	b7cd                	j	800043f6 <pipewrite+0xd8>

0000000080004416 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004416:	711d                	addi	sp,sp,-96
    80004418:	ec86                	sd	ra,88(sp)
    8000441a:	e8a2                	sd	s0,80(sp)
    8000441c:	e4a6                	sd	s1,72(sp)
    8000441e:	e0ca                	sd	s2,64(sp)
    80004420:	fc4e                	sd	s3,56(sp)
    80004422:	f852                	sd	s4,48(sp)
    80004424:	f456                	sd	s5,40(sp)
    80004426:	1080                	addi	s0,sp,96
    80004428:	84aa                	mv	s1,a0
    8000442a:	892e                	mv	s2,a1
    8000442c:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    8000442e:	cf6fd0ef          	jal	80001924 <myproc>
    80004432:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80004434:	8526                	mv	a0,s1
    80004436:	82ffc0ef          	jal	80000c64 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    8000443a:	2184a703          	lw	a4,536(s1)
    8000443e:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004442:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004446:	02f71363          	bne	a4,a5,8000446c <piperead+0x56>
    8000444a:	2244a783          	lw	a5,548(s1)
    8000444e:	cf99                	beqz	a5,8000446c <piperead+0x56>
    if(killed(pr)){
    80004450:	8552                	mv	a0,s4
    80004452:	ccbfd0ef          	jal	8000211c <killed>
    80004456:	e53d                	bnez	a0,800044c4 <piperead+0xae>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004458:	85a6                	mv	a1,s1
    8000445a:	854e                	mv	a0,s3
    8000445c:	a85fd0ef          	jal	80001ee0 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004460:	2184a703          	lw	a4,536(s1)
    80004464:	21c4a783          	lw	a5,540(s1)
    80004468:	fef701e3          	beq	a4,a5,8000444a <piperead+0x34>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    8000446c:	07505163          	blez	s5,800044ce <piperead+0xb8>
    80004470:	f05a                	sd	s6,32(sp)
    80004472:	ec5e                	sd	s7,24(sp)
    80004474:	e862                	sd	s8,16(sp)
    80004476:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004478:	faf40c13          	addi	s8,s0,-81
    8000447c:	4b85                	li	s7,1
    8000447e:	5b7d                	li	s6,-1
    if(pi->nread == pi->nwrite)
    80004480:	2184a783          	lw	a5,536(s1)
    80004484:	21c4a703          	lw	a4,540(s1)
    80004488:	04f70563          	beq	a4,a5,800044d2 <piperead+0xbc>
    ch = pi->data[pi->nread++ % PIPESIZE];
    8000448c:	0017871b          	addiw	a4,a5,1
    80004490:	20e4ac23          	sw	a4,536(s1)
    80004494:	1ff7f793          	andi	a5,a5,511
    80004498:	97a6                	add	a5,a5,s1
    8000449a:	0187c783          	lbu	a5,24(a5)
    8000449e:	faf407a3          	sb	a5,-81(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    800044a2:	86de                	mv	a3,s7
    800044a4:	8662                	mv	a2,s8
    800044a6:	85ca                	mv	a1,s2
    800044a8:	050a3503          	ld	a0,80(s4)
    800044ac:	908fd0ef          	jal	800015b4 <copyout>
    800044b0:	05650563          	beq	a0,s6,800044fa <piperead+0xe4>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800044b4:	2985                	addiw	s3,s3,1
    800044b6:	0905                	addi	s2,s2,1
    800044b8:	fd3a94e3          	bne	s5,s3,80004480 <piperead+0x6a>
    800044bc:	7b02                	ld	s6,32(sp)
    800044be:	6be2                	ld	s7,24(sp)
    800044c0:	6c42                	ld	s8,16(sp)
    800044c2:	a819                	j	800044d8 <piperead+0xc2>
      release(&pi->lock);
    800044c4:	8526                	mv	a0,s1
    800044c6:	82ffc0ef          	jal	80000cf4 <release>
      return -1;
    800044ca:	59fd                	li	s3,-1
    800044cc:	a829                	j	800044e6 <piperead+0xd0>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800044ce:	4981                	li	s3,0
    800044d0:	a021                	j	800044d8 <piperead+0xc2>
    800044d2:	7b02                	ld	s6,32(sp)
    800044d4:	6be2                	ld	s7,24(sp)
    800044d6:	6c42                	ld	s8,16(sp)
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    800044d8:	21c48513          	addi	a0,s1,540
    800044dc:	a51fd0ef          	jal	80001f2c <wakeup>
  release(&pi->lock);
    800044e0:	8526                	mv	a0,s1
    800044e2:	813fc0ef          	jal	80000cf4 <release>
  return i;
}
    800044e6:	854e                	mv	a0,s3
    800044e8:	60e6                	ld	ra,88(sp)
    800044ea:	6446                	ld	s0,80(sp)
    800044ec:	64a6                	ld	s1,72(sp)
    800044ee:	6906                	ld	s2,64(sp)
    800044f0:	79e2                	ld	s3,56(sp)
    800044f2:	7a42                	ld	s4,48(sp)
    800044f4:	7aa2                	ld	s5,40(sp)
    800044f6:	6125                	addi	sp,sp,96
    800044f8:	8082                	ret
    800044fa:	7b02                	ld	s6,32(sp)
    800044fc:	6be2                	ld	s7,24(sp)
    800044fe:	6c42                	ld	s8,16(sp)
    80004500:	bfe1                	j	800044d8 <piperead+0xc2>

0000000080004502 <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    80004502:	1141                	addi	sp,sp,-16
    80004504:	e406                	sd	ra,8(sp)
    80004506:	e022                	sd	s0,0(sp)
    80004508:	0800                	addi	s0,sp,16
    8000450a:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    8000450c:	0035151b          	slliw	a0,a0,0x3
    80004510:	8921                	andi	a0,a0,8
      perm = PTE_X;
    if(flags & 0x2)
    80004512:	8b89                	andi	a5,a5,2
    80004514:	c399                	beqz	a5,8000451a <flags2perm+0x18>
      perm |= PTE_W;
    80004516:	00456513          	ori	a0,a0,4
    return perm;
}
    8000451a:	60a2                	ld	ra,8(sp)
    8000451c:	6402                	ld	s0,0(sp)
    8000451e:	0141                	addi	sp,sp,16
    80004520:	8082                	ret

0000000080004522 <exec>:

int
exec(char *path, char **argv)
{
    80004522:	df010113          	addi	sp,sp,-528
    80004526:	20113423          	sd	ra,520(sp)
    8000452a:	20813023          	sd	s0,512(sp)
    8000452e:	ffa6                	sd	s1,504(sp)
    80004530:	fbca                	sd	s2,496(sp)
    80004532:	0c00                	addi	s0,sp,528
    80004534:	892a                	mv	s2,a0
    80004536:	e0a43023          	sd	a0,-512(s0)
    8000453a:	deb43c23          	sd	a1,-520(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    8000453e:	be6fd0ef          	jal	80001924 <myproc>
    80004542:	84aa                	mv	s1,a0

  begin_op();
    80004544:	d80ff0ef          	jal	80003ac4 <begin_op>

  if((ip = namei(path)) == 0){
    80004548:	854a                	mv	a0,s2
    8000454a:	bb8ff0ef          	jal	80003902 <namei>
    8000454e:	c931                	beqz	a0,800045a2 <exec+0x80>
    80004550:	f3d2                	sd	s4,480(sp)
    80004552:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004554:	caffe0ef          	jal	80003202 <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004558:	04000713          	li	a4,64
    8000455c:	4681                	li	a3,0
    8000455e:	e5040613          	addi	a2,s0,-432
    80004562:	4581                	li	a1,0
    80004564:	8552                	mv	a0,s4
    80004566:	ef7fe0ef          	jal	8000345c <readi>
    8000456a:	04000793          	li	a5,64
    8000456e:	00f51a63          	bne	a0,a5,80004582 <exec+0x60>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    80004572:	e5042703          	lw	a4,-432(s0)
    80004576:	464c47b7          	lui	a5,0x464c4
    8000457a:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    8000457e:	02f70563          	beq	a4,a5,800045a8 <exec+0x86>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80004582:	8552                	mv	a0,s4
    80004584:	e8bfe0ef          	jal	8000340e <iunlockput>
    end_op();
    80004588:	dacff0ef          	jal	80003b34 <end_op>
    8000458c:	7a1e                	ld	s4,480(sp)
    return -1;
    8000458e:	557d                	li	a0,-1
  }
  return -1;
}
    80004590:	20813083          	ld	ra,520(sp)
    80004594:	20013403          	ld	s0,512(sp)
    80004598:	74fe                	ld	s1,504(sp)
    8000459a:	795e                	ld	s2,496(sp)
    8000459c:	21010113          	addi	sp,sp,528
    800045a0:	8082                	ret
    end_op();
    800045a2:	d92ff0ef          	jal	80003b34 <end_op>
    return -1;
    800045a6:	b7e5                	j	8000458e <exec+0x6c>
    800045a8:	ebda                	sd	s6,464(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    800045aa:	8526                	mv	a0,s1
    800045ac:	c22fd0ef          	jal	800019ce <proc_pagetable>
    800045b0:	8b2a                	mv	s6,a0
    800045b2:	26050063          	beqz	a0,80004812 <exec+0x2f0>
    800045b6:	f7ce                	sd	s3,488(sp)
    800045b8:	efd6                	sd	s5,472(sp)
    800045ba:	e7de                	sd	s7,456(sp)
    800045bc:	e3e2                	sd	s8,448(sp)
    800045be:	ff66                	sd	s9,440(sp)
    800045c0:	fb6a                	sd	s10,432(sp)
    800045c2:	f76e                	sd	s11,424(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    800045c4:	e8845783          	lhu	a5,-376(s0)
    800045c8:	cff9                	beqz	a5,800046a6 <exec+0x184>
    800045ca:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    800045ce:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    800045d0:	4d01                	li	s10,0
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    800045d2:	03800d93          	li	s11,56

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    800045d6:	6c85                	lui	s9,0x1
    800045d8:	6a85                	lui	s5,0x1
    800045da:	a085                	j	8000463a <exec+0x118>
      panic("loadseg: address should exist");
    800045dc:	00003517          	auipc	a0,0x3
    800045e0:	02450513          	addi	a0,a0,36 # 80007600 <etext+0x600>
    800045e4:	a0cfc0ef          	jal	800007f0 <panic>
    if(sz - i < PGSIZE)
    800045e8:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    800045ea:	874a                	mv	a4,s2
    800045ec:	009b86bb          	addw	a3,s7,s1
    800045f0:	4581                	li	a1,0
    800045f2:	8552                	mv	a0,s4
    800045f4:	e69fe0ef          	jal	8000345c <readi>
    800045f8:	22a91163          	bne	s2,a0,8000481a <exec+0x2f8>
  for(i = 0; i < sz; i += PGSIZE){
    800045fc:	009a84bb          	addw	s1,s5,s1
    80004600:	0334f263          	bgeu	s1,s3,80004624 <exec+0x102>
    pa = walkaddr(pagetable, va + i);
    80004604:	02049593          	slli	a1,s1,0x20
    80004608:	9181                	srli	a1,a1,0x20
    8000460a:	95e2                	add	a1,a1,s8
    8000460c:	855a                	mv	a0,s6
    8000460e:	a43fc0ef          	jal	80001050 <walkaddr>
    80004612:	862a                	mv	a2,a0
    if(pa == 0)
    80004614:	d561                	beqz	a0,800045dc <exec+0xba>
    if(sz - i < PGSIZE)
    80004616:	409987bb          	subw	a5,s3,s1
    8000461a:	893e                	mv	s2,a5
    8000461c:	fcfcf6e3          	bgeu	s9,a5,800045e8 <exec+0xc6>
    80004620:	8956                	mv	s2,s5
    80004622:	b7d9                	j	800045e8 <exec+0xc6>
    sz = sz1;
    80004624:	df043903          	ld	s2,-528(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004628:	2d05                	addiw	s10,s10,1
    8000462a:	e0843783          	ld	a5,-504(s0)
    8000462e:	0387869b          	addiw	a3,a5,56
    80004632:	e8845783          	lhu	a5,-376(s0)
    80004636:	06fd5963          	bge	s10,a5,800046a8 <exec+0x186>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    8000463a:	e0d43423          	sd	a3,-504(s0)
    8000463e:	876e                	mv	a4,s11
    80004640:	e1840613          	addi	a2,s0,-488
    80004644:	4581                	li	a1,0
    80004646:	8552                	mv	a0,s4
    80004648:	e15fe0ef          	jal	8000345c <readi>
    8000464c:	1db51563          	bne	a0,s11,80004816 <exec+0x2f4>
    if(ph.type != ELF_PROG_LOAD)
    80004650:	e1842783          	lw	a5,-488(s0)
    80004654:	4705                	li	a4,1
    80004656:	fce799e3          	bne	a5,a4,80004628 <exec+0x106>
    if(ph.memsz < ph.filesz)
    8000465a:	e4043483          	ld	s1,-448(s0)
    8000465e:	e3843783          	ld	a5,-456(s0)
    80004662:	1af4ea63          	bltu	s1,a5,80004816 <exec+0x2f4>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80004666:	e2843783          	ld	a5,-472(s0)
    8000466a:	94be                	add	s1,s1,a5
    8000466c:	1af4e563          	bltu	s1,a5,80004816 <exec+0x2f4>
    if(ph.vaddr % PGSIZE != 0)
    80004670:	17d2                	slli	a5,a5,0x34
    80004672:	1a079263          	bnez	a5,80004816 <exec+0x2f4>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004676:	e1c42503          	lw	a0,-484(s0)
    8000467a:	e89ff0ef          	jal	80004502 <flags2perm>
    8000467e:	86aa                	mv	a3,a0
    80004680:	8626                	mv	a2,s1
    80004682:	85ca                	mv	a1,s2
    80004684:	855a                	mv	a0,s6
    80004686:	d29fc0ef          	jal	800013ae <uvmalloc>
    8000468a:	dea43823          	sd	a0,-528(s0)
    8000468e:	18050463          	beqz	a0,80004816 <exec+0x2f4>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004692:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004696:	f80987e3          	beqz	s3,80004624 <exec+0x102>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    8000469a:	e2843c03          	ld	s8,-472(s0)
    8000469e:	e2042b83          	lw	s7,-480(s0)
  for(i = 0; i < sz; i += PGSIZE){
    800046a2:	4481                	li	s1,0
    800046a4:	b785                	j	80004604 <exec+0xe2>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    800046a6:	4901                	li	s2,0
  iunlockput(ip);
    800046a8:	8552                	mv	a0,s4
    800046aa:	d65fe0ef          	jal	8000340e <iunlockput>
  end_op();
    800046ae:	c86ff0ef          	jal	80003b34 <end_op>
  p = myproc();
    800046b2:	a72fd0ef          	jal	80001924 <myproc>
    800046b6:	89aa                	mv	s3,a0
  uint64 oldsz = p->sz;
    800046b8:	04853a83          	ld	s5,72(a0)
  sz = PGROUNDUP(sz);
    800046bc:	6485                	lui	s1,0x1
    800046be:	14fd                	addi	s1,s1,-1 # fff <_entry-0x7ffff001>
    800046c0:	94ca                	add	s1,s1,s2
    800046c2:	77fd                	lui	a5,0xfffff
    800046c4:	8cfd                	and	s1,s1,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    800046c6:	4691                	li	a3,4
    800046c8:	6609                	lui	a2,0x2
    800046ca:	9626                	add	a2,a2,s1
    800046cc:	85a6                	mv	a1,s1
    800046ce:	855a                	mv	a0,s6
    800046d0:	cdffc0ef          	jal	800013ae <uvmalloc>
    800046d4:	8a2a                	mv	s4,a0
    800046d6:	ed19                	bnez	a0,800046f4 <exec+0x1d2>
    proc_freepagetable(pagetable, sz);
    800046d8:	85a6                	mv	a1,s1
    800046da:	855a                	mv	a0,s6
    800046dc:	b74fd0ef          	jal	80001a50 <proc_freepagetable>
  if(ip){
    800046e0:	79be                	ld	s3,488(sp)
    800046e2:	7a1e                	ld	s4,480(sp)
    800046e4:	6afe                	ld	s5,472(sp)
    800046e6:	6b5e                	ld	s6,464(sp)
    800046e8:	6bbe                	ld	s7,456(sp)
    800046ea:	6c1e                	ld	s8,448(sp)
    800046ec:	7cfa                	ld	s9,440(sp)
    800046ee:	7d5a                	ld	s10,432(sp)
    800046f0:	7dba                	ld	s11,424(sp)
    800046f2:	bd71                	j	8000458e <exec+0x6c>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    800046f4:	75f9                	lui	a1,0xffffe
    800046f6:	95aa                	add	a1,a1,a0
    800046f8:	855a                	mv	a0,s6
    800046fa:	e91fc0ef          	jal	8000158a <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    800046fe:	7c7d                	lui	s8,0xfffff
    80004700:	9c52                	add	s8,s8,s4
  for(argc = 0; argv[argc]; argc++) {
    80004702:	df843783          	ld	a5,-520(s0)
    80004706:	6388                	ld	a0,0(a5)
  sp = sz;
    80004708:	8952                	mv	s2,s4
  for(argc = 0; argv[argc]; argc++) {
    8000470a:	4481                	li	s1,0
    ustack[argc] = sp;
    8000470c:	e9040c93          	addi	s9,s0,-368
    if(argc >= MAXARG)
    80004710:	02000d13          	li	s10,32
  for(argc = 0; argv[argc]; argc++) {
    80004714:	cd21                	beqz	a0,8000476c <exec+0x24a>
    sp -= strlen(argv[argc]) + 1;
    80004716:	f9afc0ef          	jal	80000eb0 <strlen>
    8000471a:	0015079b          	addiw	a5,a0,1
    8000471e:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004722:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80004726:	05896163          	bltu	s2,s8,80004768 <exec+0x246>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    8000472a:	df843d83          	ld	s11,-520(s0)
    8000472e:	000dbb83          	ld	s7,0(s11)
    80004732:	855e                	mv	a0,s7
    80004734:	f7cfc0ef          	jal	80000eb0 <strlen>
    80004738:	0015069b          	addiw	a3,a0,1
    8000473c:	865e                	mv	a2,s7
    8000473e:	85ca                	mv	a1,s2
    80004740:	855a                	mv	a0,s6
    80004742:	e73fc0ef          	jal	800015b4 <copyout>
    80004746:	02054163          	bltz	a0,80004768 <exec+0x246>
    ustack[argc] = sp;
    8000474a:	00349793          	slli	a5,s1,0x3
    8000474e:	97e6                	add	a5,a5,s9
    80004750:	0127b023          	sd	s2,0(a5) # fffffffffffff000 <end+0xffffffff7ffde3b0>
  for(argc = 0; argv[argc]; argc++) {
    80004754:	0485                	addi	s1,s1,1
    80004756:	008d8793          	addi	a5,s11,8
    8000475a:	def43c23          	sd	a5,-520(s0)
    8000475e:	008db503          	ld	a0,8(s11)
    80004762:	c509                	beqz	a0,8000476c <exec+0x24a>
    if(argc >= MAXARG)
    80004764:	fba499e3          	bne	s1,s10,80004716 <exec+0x1f4>
  sz = sz1;
    80004768:	84d2                	mv	s1,s4
    8000476a:	b7bd                	j	800046d8 <exec+0x1b6>
  ustack[argc] = 0;
    8000476c:	00349793          	slli	a5,s1,0x3
    80004770:	f9040713          	addi	a4,s0,-112
    80004774:	97ba                	add	a5,a5,a4
    80004776:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    8000477a:	00148693          	addi	a3,s1,1
    8000477e:	068e                	slli	a3,a3,0x3
    80004780:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004784:	ff097913          	andi	s2,s2,-16
  if(sp < stackbase)
    80004788:	ff8960e3          	bltu	s2,s8,80004768 <exec+0x246>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    8000478c:	e9040613          	addi	a2,s0,-368
    80004790:	85ca                	mv	a1,s2
    80004792:	855a                	mv	a0,s6
    80004794:	e21fc0ef          	jal	800015b4 <copyout>
    80004798:	fc0548e3          	bltz	a0,80004768 <exec+0x246>
  p->trapframe->a1 = sp;
    8000479c:	0589b783          	ld	a5,88(s3)
    800047a0:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    800047a4:	e0043783          	ld	a5,-512(s0)
    800047a8:	0007c703          	lbu	a4,0(a5)
    800047ac:	cf11                	beqz	a4,800047c8 <exec+0x2a6>
    800047ae:	0785                	addi	a5,a5,1
    if(*s == '/')
    800047b0:	02f00693          	li	a3,47
    800047b4:	a029                	j	800047be <exec+0x29c>
  for(last=s=path; *s; s++)
    800047b6:	0785                	addi	a5,a5,1
    800047b8:	fff7c703          	lbu	a4,-1(a5)
    800047bc:	c711                	beqz	a4,800047c8 <exec+0x2a6>
    if(*s == '/')
    800047be:	fed71ce3          	bne	a4,a3,800047b6 <exec+0x294>
      last = s+1;
    800047c2:	e0f43023          	sd	a5,-512(s0)
    800047c6:	bfc5                	j	800047b6 <exec+0x294>
  safestrcpy(p->name, last, sizeof(p->name));
    800047c8:	4641                	li	a2,16
    800047ca:	e0043583          	ld	a1,-512(s0)
    800047ce:	15898513          	addi	a0,s3,344
    800047d2:	ea8fc0ef          	jal	80000e7a <safestrcpy>
  oldpagetable = p->pagetable;
    800047d6:	0509b503          	ld	a0,80(s3)
  p->pagetable = pagetable;
    800047da:	0569b823          	sd	s6,80(s3)
  p->sz = sz;
    800047de:	0549b423          	sd	s4,72(s3)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    800047e2:	0589b783          	ld	a5,88(s3)
    800047e6:	e6843703          	ld	a4,-408(s0)
    800047ea:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    800047ec:	0589b783          	ld	a5,88(s3)
    800047f0:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    800047f4:	85d6                	mv	a1,s5
    800047f6:	a5afd0ef          	jal	80001a50 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    800047fa:	0004851b          	sext.w	a0,s1
    800047fe:	79be                	ld	s3,488(sp)
    80004800:	7a1e                	ld	s4,480(sp)
    80004802:	6afe                	ld	s5,472(sp)
    80004804:	6b5e                	ld	s6,464(sp)
    80004806:	6bbe                	ld	s7,456(sp)
    80004808:	6c1e                	ld	s8,448(sp)
    8000480a:	7cfa                	ld	s9,440(sp)
    8000480c:	7d5a                	ld	s10,432(sp)
    8000480e:	7dba                	ld	s11,424(sp)
    80004810:	b341                	j	80004590 <exec+0x6e>
    80004812:	6b5e                	ld	s6,464(sp)
    80004814:	b3bd                	j	80004582 <exec+0x60>
    return -1;
    80004816:	df243823          	sd	s2,-528(s0)
    proc_freepagetable(pagetable, sz);
    8000481a:	df043583          	ld	a1,-528(s0)
    8000481e:	855a                	mv	a0,s6
    80004820:	a30fd0ef          	jal	80001a50 <proc_freepagetable>
  if(ip){
    80004824:	79be                	ld	s3,488(sp)
    80004826:	6afe                	ld	s5,472(sp)
    80004828:	6b5e                	ld	s6,464(sp)
    8000482a:	6bbe                	ld	s7,456(sp)
    8000482c:	6c1e                	ld	s8,448(sp)
    8000482e:	7cfa                	ld	s9,440(sp)
    80004830:	7d5a                	ld	s10,432(sp)
    80004832:	7dba                	ld	s11,424(sp)
    80004834:	b3b9                	j	80004582 <exec+0x60>

0000000080004836 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004836:	7179                	addi	sp,sp,-48
    80004838:	f406                	sd	ra,40(sp)
    8000483a:	f022                	sd	s0,32(sp)
    8000483c:	ec26                	sd	s1,24(sp)
    8000483e:	e84a                	sd	s2,16(sp)
    80004840:	1800                	addi	s0,sp,48
    80004842:	892e                	mv	s2,a1
    80004844:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004846:	fdc40593          	addi	a1,s0,-36
    8000484a:	fa7fd0ef          	jal	800027f0 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    8000484e:	fdc42703          	lw	a4,-36(s0)
    80004852:	47bd                	li	a5,15
    80004854:	02e7e963          	bltu	a5,a4,80004886 <argfd+0x50>
    80004858:	8ccfd0ef          	jal	80001924 <myproc>
    8000485c:	fdc42703          	lw	a4,-36(s0)
    80004860:	01a70793          	addi	a5,a4,26
    80004864:	078e                	slli	a5,a5,0x3
    80004866:	953e                	add	a0,a0,a5
    80004868:	611c                	ld	a5,0(a0)
    8000486a:	cf91                	beqz	a5,80004886 <argfd+0x50>
    return -1;
  if(pfd)
    8000486c:	00090463          	beqz	s2,80004874 <argfd+0x3e>
    *pfd = fd;
    80004870:	00e92023          	sw	a4,0(s2)
  if(pf)
    80004874:	c091                	beqz	s1,80004878 <argfd+0x42>
    *pf = f;
    80004876:	e09c                	sd	a5,0(s1)
  return 0;
    80004878:	4501                	li	a0,0
}
    8000487a:	70a2                	ld	ra,40(sp)
    8000487c:	7402                	ld	s0,32(sp)
    8000487e:	64e2                	ld	s1,24(sp)
    80004880:	6942                	ld	s2,16(sp)
    80004882:	6145                	addi	sp,sp,48
    80004884:	8082                	ret
    return -1;
    80004886:	557d                	li	a0,-1
    80004888:	bfcd                	j	8000487a <argfd+0x44>

000000008000488a <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    8000488a:	1101                	addi	sp,sp,-32
    8000488c:	ec06                	sd	ra,24(sp)
    8000488e:	e822                	sd	s0,16(sp)
    80004890:	e426                	sd	s1,8(sp)
    80004892:	1000                	addi	s0,sp,32
    80004894:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004896:	88efd0ef          	jal	80001924 <myproc>
    8000489a:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    8000489c:	0d050793          	addi	a5,a0,208
    800048a0:	4501                	li	a0,0
    800048a2:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    800048a4:	6398                	ld	a4,0(a5)
    800048a6:	cb19                	beqz	a4,800048bc <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    800048a8:	2505                	addiw	a0,a0,1
    800048aa:	07a1                	addi	a5,a5,8
    800048ac:	fed51ce3          	bne	a0,a3,800048a4 <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    800048b0:	557d                	li	a0,-1
}
    800048b2:	60e2                	ld	ra,24(sp)
    800048b4:	6442                	ld	s0,16(sp)
    800048b6:	64a2                	ld	s1,8(sp)
    800048b8:	6105                	addi	sp,sp,32
    800048ba:	8082                	ret
      p->ofile[fd] = f;
    800048bc:	01a50793          	addi	a5,a0,26
    800048c0:	078e                	slli	a5,a5,0x3
    800048c2:	963e                	add	a2,a2,a5
    800048c4:	e204                	sd	s1,0(a2)
      return fd;
    800048c6:	b7f5                	j	800048b2 <fdalloc+0x28>

00000000800048c8 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    800048c8:	715d                	addi	sp,sp,-80
    800048ca:	e486                	sd	ra,72(sp)
    800048cc:	e0a2                	sd	s0,64(sp)
    800048ce:	fc26                	sd	s1,56(sp)
    800048d0:	f84a                	sd	s2,48(sp)
    800048d2:	f44e                	sd	s3,40(sp)
    800048d4:	f052                	sd	s4,32(sp)
    800048d6:	ec56                	sd	s5,24(sp)
    800048d8:	e85a                	sd	s6,16(sp)
    800048da:	0880                	addi	s0,sp,80
    800048dc:	892e                	mv	s2,a1
    800048de:	8a2e                	mv	s4,a1
    800048e0:	8ab2                	mv	s5,a2
    800048e2:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    800048e4:	fb040593          	addi	a1,s0,-80
    800048e8:	834ff0ef          	jal	8000391c <nameiparent>
    800048ec:	84aa                	mv	s1,a0
    return 0;
    800048ee:	89aa                	mv	s3,a0
  if((dp = nameiparent(path, name)) == 0)
    800048f0:	cd05                	beqz	a0,80004928 <create+0x60>

  ilock(dp);
    800048f2:	911fe0ef          	jal	80003202 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    800048f6:	4601                	li	a2,0
    800048f8:	fb040593          	addi	a1,s0,-80
    800048fc:	8526                	mv	a0,s1
    800048fe:	d69fe0ef          	jal	80003666 <dirlookup>
    80004902:	89aa                	mv	s3,a0
    80004904:	c131                	beqz	a0,80004948 <create+0x80>
    iunlockput(dp);
    80004906:	8526                	mv	a0,s1
    80004908:	b07fe0ef          	jal	8000340e <iunlockput>
    ilock(ip);
    8000490c:	854e                	mv	a0,s3
    8000490e:	8f5fe0ef          	jal	80003202 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004912:	4789                	li	a5,2
    80004914:	02f91563          	bne	s2,a5,8000493e <create+0x76>
    80004918:	0449d783          	lhu	a5,68(s3)
    8000491c:	37f9                	addiw	a5,a5,-2
    8000491e:	17c2                	slli	a5,a5,0x30
    80004920:	93c1                	srli	a5,a5,0x30
    80004922:	4705                	li	a4,1
    80004924:	00f76d63          	bltu	a4,a5,8000493e <create+0x76>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004928:	854e                	mv	a0,s3
    8000492a:	60a6                	ld	ra,72(sp)
    8000492c:	6406                	ld	s0,64(sp)
    8000492e:	74e2                	ld	s1,56(sp)
    80004930:	7942                	ld	s2,48(sp)
    80004932:	79a2                	ld	s3,40(sp)
    80004934:	7a02                	ld	s4,32(sp)
    80004936:	6ae2                	ld	s5,24(sp)
    80004938:	6b42                	ld	s6,16(sp)
    8000493a:	6161                	addi	sp,sp,80
    8000493c:	8082                	ret
    iunlockput(ip);
    8000493e:	854e                	mv	a0,s3
    80004940:	acffe0ef          	jal	8000340e <iunlockput>
    return 0;
    80004944:	4981                	li	s3,0
    80004946:	b7cd                	j	80004928 <create+0x60>
  if((ip = ialloc(dp->dev, type)) == 0){
    80004948:	85ca                	mv	a1,s2
    8000494a:	4088                	lw	a0,0(s1)
    8000494c:	f46fe0ef          	jal	80003092 <ialloc>
    80004950:	892a                	mv	s2,a0
    80004952:	cd15                	beqz	a0,8000498e <create+0xc6>
  ilock(ip);
    80004954:	8affe0ef          	jal	80003202 <ilock>
  ip->major = major;
    80004958:	05591323          	sh	s5,70(s2)
  ip->minor = minor;
    8000495c:	05691423          	sh	s6,72(s2)
  ip->nlink = 1;
    80004960:	4785                	li	a5,1
    80004962:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004966:	854a                	mv	a0,s2
    80004968:	fe6fe0ef          	jal	8000314e <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    8000496c:	4705                	li	a4,1
    8000496e:	02ea0463          	beq	s4,a4,80004996 <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80004972:	00492603          	lw	a2,4(s2)
    80004976:	fb040593          	addi	a1,s0,-80
    8000497a:	8526                	mv	a0,s1
    8000497c:	eddfe0ef          	jal	80003858 <dirlink>
    80004980:	06054263          	bltz	a0,800049e4 <create+0x11c>
  iunlockput(dp);
    80004984:	8526                	mv	a0,s1
    80004986:	a89fe0ef          	jal	8000340e <iunlockput>
    return 0;
    8000498a:	89ca                	mv	s3,s2
    8000498c:	bf71                	j	80004928 <create+0x60>
    iunlockput(dp);
    8000498e:	8526                	mv	a0,s1
    80004990:	a7ffe0ef          	jal	8000340e <iunlockput>
    return 0;
    80004994:	bfdd                	j	8000498a <create+0xc2>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004996:	00492603          	lw	a2,4(s2)
    8000499a:	00003597          	auipc	a1,0x3
    8000499e:	c8658593          	addi	a1,a1,-890 # 80007620 <etext+0x620>
    800049a2:	854a                	mv	a0,s2
    800049a4:	eb5fe0ef          	jal	80003858 <dirlink>
    800049a8:	02054e63          	bltz	a0,800049e4 <create+0x11c>
    800049ac:	40d0                	lw	a2,4(s1)
    800049ae:	00003597          	auipc	a1,0x3
    800049b2:	c7a58593          	addi	a1,a1,-902 # 80007628 <etext+0x628>
    800049b6:	854a                	mv	a0,s2
    800049b8:	ea1fe0ef          	jal	80003858 <dirlink>
    800049bc:	02054463          	bltz	a0,800049e4 <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    800049c0:	00492603          	lw	a2,4(s2)
    800049c4:	fb040593          	addi	a1,s0,-80
    800049c8:	8526                	mv	a0,s1
    800049ca:	e8ffe0ef          	jal	80003858 <dirlink>
    800049ce:	00054b63          	bltz	a0,800049e4 <create+0x11c>
    dp->nlink++;  // for ".."
    800049d2:	04a4d783          	lhu	a5,74(s1)
    800049d6:	2785                	addiw	a5,a5,1
    800049d8:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800049dc:	8526                	mv	a0,s1
    800049de:	f70fe0ef          	jal	8000314e <iupdate>
    800049e2:	b74d                	j	80004984 <create+0xbc>
  ip->nlink = 0;
    800049e4:	04091523          	sh	zero,74(s2)
  iupdate(ip);
    800049e8:	854a                	mv	a0,s2
    800049ea:	f64fe0ef          	jal	8000314e <iupdate>
  iunlockput(ip);
    800049ee:	854a                	mv	a0,s2
    800049f0:	a1ffe0ef          	jal	8000340e <iunlockput>
  iunlockput(dp);
    800049f4:	8526                	mv	a0,s1
    800049f6:	a19fe0ef          	jal	8000340e <iunlockput>
  return 0;
    800049fa:	b73d                	j	80004928 <create+0x60>

00000000800049fc <sys_dup>:
{
    800049fc:	7179                	addi	sp,sp,-48
    800049fe:	f406                	sd	ra,40(sp)
    80004a00:	f022                	sd	s0,32(sp)
    80004a02:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80004a04:	fd840613          	addi	a2,s0,-40
    80004a08:	4581                	li	a1,0
    80004a0a:	4501                	li	a0,0
    80004a0c:	e2bff0ef          	jal	80004836 <argfd>
    80004a10:	02054863          	bltz	a0,80004a40 <sys_dup+0x44>
    80004a14:	ec26                	sd	s1,24(sp)
    80004a16:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80004a18:	fd843483          	ld	s1,-40(s0)
    80004a1c:	8526                	mv	a0,s1
    80004a1e:	e6dff0ef          	jal	8000488a <fdalloc>
    80004a22:	892a                	mv	s2,a0
    80004a24:	00054c63          	bltz	a0,80004a3c <sys_dup+0x40>
  filedup(f);
    80004a28:	8526                	mv	a0,s1
    80004a2a:	c82ff0ef          	jal	80003eac <filedup>
  return fd;
    80004a2e:	854a                	mv	a0,s2
    80004a30:	64e2                	ld	s1,24(sp)
    80004a32:	6942                	ld	s2,16(sp)
}
    80004a34:	70a2                	ld	ra,40(sp)
    80004a36:	7402                	ld	s0,32(sp)
    80004a38:	6145                	addi	sp,sp,48
    80004a3a:	8082                	ret
    80004a3c:	64e2                	ld	s1,24(sp)
    80004a3e:	6942                	ld	s2,16(sp)
    return -1;
    80004a40:	557d                	li	a0,-1
    80004a42:	bfcd                	j	80004a34 <sys_dup+0x38>

0000000080004a44 <sys_read>:
{
    80004a44:	7179                	addi	sp,sp,-48
    80004a46:	f406                	sd	ra,40(sp)
    80004a48:	f022                	sd	s0,32(sp)
    80004a4a:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004a4c:	fd840593          	addi	a1,s0,-40
    80004a50:	4505                	li	a0,1
    80004a52:	dbbfd0ef          	jal	8000280c <argaddr>
  argint(2, &n);
    80004a56:	fe440593          	addi	a1,s0,-28
    80004a5a:	4509                	li	a0,2
    80004a5c:	d95fd0ef          	jal	800027f0 <argint>
  if(argfd(0, 0, &f) < 0)
    80004a60:	fe840613          	addi	a2,s0,-24
    80004a64:	4581                	li	a1,0
    80004a66:	4501                	li	a0,0
    80004a68:	dcfff0ef          	jal	80004836 <argfd>
    80004a6c:	87aa                	mv	a5,a0
    return -1;
    80004a6e:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004a70:	0007ca63          	bltz	a5,80004a84 <sys_read+0x40>
  return fileread(f, p, n);
    80004a74:	fe442603          	lw	a2,-28(s0)
    80004a78:	fd843583          	ld	a1,-40(s0)
    80004a7c:	fe843503          	ld	a0,-24(s0)
    80004a80:	d96ff0ef          	jal	80004016 <fileread>
}
    80004a84:	70a2                	ld	ra,40(sp)
    80004a86:	7402                	ld	s0,32(sp)
    80004a88:	6145                	addi	sp,sp,48
    80004a8a:	8082                	ret

0000000080004a8c <sys_write>:
{
    80004a8c:	7179                	addi	sp,sp,-48
    80004a8e:	f406                	sd	ra,40(sp)
    80004a90:	f022                	sd	s0,32(sp)
    80004a92:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004a94:	fd840593          	addi	a1,s0,-40
    80004a98:	4505                	li	a0,1
    80004a9a:	d73fd0ef          	jal	8000280c <argaddr>
  argint(2, &n);
    80004a9e:	fe440593          	addi	a1,s0,-28
    80004aa2:	4509                	li	a0,2
    80004aa4:	d4dfd0ef          	jal	800027f0 <argint>
  if(argfd(0, 0, &f) < 0)
    80004aa8:	fe840613          	addi	a2,s0,-24
    80004aac:	4581                	li	a1,0
    80004aae:	4501                	li	a0,0
    80004ab0:	d87ff0ef          	jal	80004836 <argfd>
    80004ab4:	87aa                	mv	a5,a0
    return -1;
    80004ab6:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004ab8:	0007ca63          	bltz	a5,80004acc <sys_write+0x40>
  return filewrite(f, p, n);
    80004abc:	fe442603          	lw	a2,-28(s0)
    80004ac0:	fd843583          	ld	a1,-40(s0)
    80004ac4:	fe843503          	ld	a0,-24(s0)
    80004ac8:	e08ff0ef          	jal	800040d0 <filewrite>
}
    80004acc:	70a2                	ld	ra,40(sp)
    80004ace:	7402                	ld	s0,32(sp)
    80004ad0:	6145                	addi	sp,sp,48
    80004ad2:	8082                	ret

0000000080004ad4 <sys_close>:
{
    80004ad4:	1101                	addi	sp,sp,-32
    80004ad6:	ec06                	sd	ra,24(sp)
    80004ad8:	e822                	sd	s0,16(sp)
    80004ada:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004adc:	fe040613          	addi	a2,s0,-32
    80004ae0:	fec40593          	addi	a1,s0,-20
    80004ae4:	4501                	li	a0,0
    80004ae6:	d51ff0ef          	jal	80004836 <argfd>
    return -1;
    80004aea:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004aec:	02054063          	bltz	a0,80004b0c <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    80004af0:	e35fc0ef          	jal	80001924 <myproc>
    80004af4:	fec42783          	lw	a5,-20(s0)
    80004af8:	07e9                	addi	a5,a5,26
    80004afa:	078e                	slli	a5,a5,0x3
    80004afc:	953e                	add	a0,a0,a5
    80004afe:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004b02:	fe043503          	ld	a0,-32(s0)
    80004b06:	becff0ef          	jal	80003ef2 <fileclose>
  return 0;
    80004b0a:	4781                	li	a5,0
}
    80004b0c:	853e                	mv	a0,a5
    80004b0e:	60e2                	ld	ra,24(sp)
    80004b10:	6442                	ld	s0,16(sp)
    80004b12:	6105                	addi	sp,sp,32
    80004b14:	8082                	ret

0000000080004b16 <sys_fstat>:
{
    80004b16:	1101                	addi	sp,sp,-32
    80004b18:	ec06                	sd	ra,24(sp)
    80004b1a:	e822                	sd	s0,16(sp)
    80004b1c:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004b1e:	fe040593          	addi	a1,s0,-32
    80004b22:	4505                	li	a0,1
    80004b24:	ce9fd0ef          	jal	8000280c <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004b28:	fe840613          	addi	a2,s0,-24
    80004b2c:	4581                	li	a1,0
    80004b2e:	4501                	li	a0,0
    80004b30:	d07ff0ef          	jal	80004836 <argfd>
    80004b34:	87aa                	mv	a5,a0
    return -1;
    80004b36:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004b38:	0007c863          	bltz	a5,80004b48 <sys_fstat+0x32>
  return filestat(f, st);
    80004b3c:	fe043583          	ld	a1,-32(s0)
    80004b40:	fe843503          	ld	a0,-24(s0)
    80004b44:	c70ff0ef          	jal	80003fb4 <filestat>
}
    80004b48:	60e2                	ld	ra,24(sp)
    80004b4a:	6442                	ld	s0,16(sp)
    80004b4c:	6105                	addi	sp,sp,32
    80004b4e:	8082                	ret

0000000080004b50 <sys_link>:
{
    80004b50:	7169                	addi	sp,sp,-304
    80004b52:	f606                	sd	ra,296(sp)
    80004b54:	f222                	sd	s0,288(sp)
    80004b56:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004b58:	08000613          	li	a2,128
    80004b5c:	ed040593          	addi	a1,s0,-304
    80004b60:	4501                	li	a0,0
    80004b62:	cc7fd0ef          	jal	80002828 <argstr>
    80004b66:	0c054a63          	bltz	a0,80004c3a <sys_link+0xea>
    80004b6a:	08000613          	li	a2,128
    80004b6e:	f5040593          	addi	a1,s0,-176
    80004b72:	4505                	li	a0,1
    80004b74:	cb5fd0ef          	jal	80002828 <argstr>
    80004b78:	0c054163          	bltz	a0,80004c3a <sys_link+0xea>
    80004b7c:	ee26                	sd	s1,280(sp)
  begin_op();
    80004b7e:	f47fe0ef          	jal	80003ac4 <begin_op>
  if((ip = namei(old)) == 0){
    80004b82:	ed040513          	addi	a0,s0,-304
    80004b86:	d7dfe0ef          	jal	80003902 <namei>
    80004b8a:	84aa                	mv	s1,a0
    80004b8c:	c53d                	beqz	a0,80004bfa <sys_link+0xaa>
  ilock(ip);
    80004b8e:	e74fe0ef          	jal	80003202 <ilock>
  if(ip->type == T_DIR){
    80004b92:	04449703          	lh	a4,68(s1)
    80004b96:	4785                	li	a5,1
    80004b98:	06f70563          	beq	a4,a5,80004c02 <sys_link+0xb2>
    80004b9c:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004b9e:	04a4d783          	lhu	a5,74(s1)
    80004ba2:	2785                	addiw	a5,a5,1
    80004ba4:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004ba8:	8526                	mv	a0,s1
    80004baa:	da4fe0ef          	jal	8000314e <iupdate>
  iunlock(ip);
    80004bae:	8526                	mv	a0,s1
    80004bb0:	f00fe0ef          	jal	800032b0 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80004bb4:	fd040593          	addi	a1,s0,-48
    80004bb8:	f5040513          	addi	a0,s0,-176
    80004bbc:	d61fe0ef          	jal	8000391c <nameiparent>
    80004bc0:	892a                	mv	s2,a0
    80004bc2:	c931                	beqz	a0,80004c16 <sys_link+0xc6>
  ilock(dp);
    80004bc4:	e3efe0ef          	jal	80003202 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80004bc8:	854a                	mv	a0,s2
    80004bca:	00092703          	lw	a4,0(s2)
    80004bce:	409c                	lw	a5,0(s1)
    80004bd0:	04f71063          	bne	a4,a5,80004c10 <sys_link+0xc0>
    80004bd4:	40d0                	lw	a2,4(s1)
    80004bd6:	fd040593          	addi	a1,s0,-48
    80004bda:	c7ffe0ef          	jal	80003858 <dirlink>
    80004bde:	02054963          	bltz	a0,80004c10 <sys_link+0xc0>
  iunlockput(dp);
    80004be2:	854a                	mv	a0,s2
    80004be4:	82bfe0ef          	jal	8000340e <iunlockput>
  iput(ip);
    80004be8:	8526                	mv	a0,s1
    80004bea:	f9afe0ef          	jal	80003384 <iput>
  end_op();
    80004bee:	f47fe0ef          	jal	80003b34 <end_op>
  return 0;
    80004bf2:	4501                	li	a0,0
    80004bf4:	64f2                	ld	s1,280(sp)
    80004bf6:	6952                	ld	s2,272(sp)
    80004bf8:	a091                	j	80004c3c <sys_link+0xec>
    end_op();
    80004bfa:	f3bfe0ef          	jal	80003b34 <end_op>
    return -1;
    80004bfe:	64f2                	ld	s1,280(sp)
    80004c00:	a82d                	j	80004c3a <sys_link+0xea>
    iunlockput(ip);
    80004c02:	8526                	mv	a0,s1
    80004c04:	80bfe0ef          	jal	8000340e <iunlockput>
    end_op();
    80004c08:	f2dfe0ef          	jal	80003b34 <end_op>
    return -1;
    80004c0c:	64f2                	ld	s1,280(sp)
    80004c0e:	a035                	j	80004c3a <sys_link+0xea>
    iunlockput(dp);
    80004c10:	854a                	mv	a0,s2
    80004c12:	ffcfe0ef          	jal	8000340e <iunlockput>
  ilock(ip);
    80004c16:	8526                	mv	a0,s1
    80004c18:	deafe0ef          	jal	80003202 <ilock>
  ip->nlink--;
    80004c1c:	04a4d783          	lhu	a5,74(s1)
    80004c20:	37fd                	addiw	a5,a5,-1
    80004c22:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004c26:	8526                	mv	a0,s1
    80004c28:	d26fe0ef          	jal	8000314e <iupdate>
  iunlockput(ip);
    80004c2c:	8526                	mv	a0,s1
    80004c2e:	fe0fe0ef          	jal	8000340e <iunlockput>
  end_op();
    80004c32:	f03fe0ef          	jal	80003b34 <end_op>
  return -1;
    80004c36:	64f2                	ld	s1,280(sp)
    80004c38:	6952                	ld	s2,272(sp)
    return -1;
    80004c3a:	557d                	li	a0,-1
}
    80004c3c:	70b2                	ld	ra,296(sp)
    80004c3e:	7412                	ld	s0,288(sp)
    80004c40:	6155                	addi	sp,sp,304
    80004c42:	8082                	ret

0000000080004c44 <sys_unlink>:
{
    80004c44:	7151                	addi	sp,sp,-240
    80004c46:	f586                	sd	ra,232(sp)
    80004c48:	f1a2                	sd	s0,224(sp)
    80004c4a:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004c4c:	08000613          	li	a2,128
    80004c50:	f3040593          	addi	a1,s0,-208
    80004c54:	4501                	li	a0,0
    80004c56:	bd3fd0ef          	jal	80002828 <argstr>
    80004c5a:	14054763          	bltz	a0,80004da8 <sys_unlink+0x164>
    80004c5e:	eda6                	sd	s1,216(sp)
  begin_op();
    80004c60:	e65fe0ef          	jal	80003ac4 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004c64:	fb040593          	addi	a1,s0,-80
    80004c68:	f3040513          	addi	a0,s0,-208
    80004c6c:	cb1fe0ef          	jal	8000391c <nameiparent>
    80004c70:	84aa                	mv	s1,a0
    80004c72:	c955                	beqz	a0,80004d26 <sys_unlink+0xe2>
  ilock(dp);
    80004c74:	d8efe0ef          	jal	80003202 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004c78:	00003597          	auipc	a1,0x3
    80004c7c:	9a858593          	addi	a1,a1,-1624 # 80007620 <etext+0x620>
    80004c80:	fb040513          	addi	a0,s0,-80
    80004c84:	9cdfe0ef          	jal	80003650 <namecmp>
    80004c88:	10050a63          	beqz	a0,80004d9c <sys_unlink+0x158>
    80004c8c:	00003597          	auipc	a1,0x3
    80004c90:	99c58593          	addi	a1,a1,-1636 # 80007628 <etext+0x628>
    80004c94:	fb040513          	addi	a0,s0,-80
    80004c98:	9b9fe0ef          	jal	80003650 <namecmp>
    80004c9c:	10050063          	beqz	a0,80004d9c <sys_unlink+0x158>
    80004ca0:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    80004ca2:	f2c40613          	addi	a2,s0,-212
    80004ca6:	fb040593          	addi	a1,s0,-80
    80004caa:	8526                	mv	a0,s1
    80004cac:	9bbfe0ef          	jal	80003666 <dirlookup>
    80004cb0:	892a                	mv	s2,a0
    80004cb2:	0e050463          	beqz	a0,80004d9a <sys_unlink+0x156>
    80004cb6:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    80004cb8:	d4afe0ef          	jal	80003202 <ilock>
  if(ip->nlink < 1)
    80004cbc:	04a91783          	lh	a5,74(s2)
    80004cc0:	06f05763          	blez	a5,80004d2e <sys_unlink+0xea>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80004cc4:	04491703          	lh	a4,68(s2)
    80004cc8:	4785                	li	a5,1
    80004cca:	06f70863          	beq	a4,a5,80004d3a <sys_unlink+0xf6>
  memset(&de, 0, sizeof(de));
    80004cce:	fc040993          	addi	s3,s0,-64
    80004cd2:	4641                	li	a2,16
    80004cd4:	4581                	li	a1,0
    80004cd6:	854e                	mv	a0,s3
    80004cd8:	858fc0ef          	jal	80000d30 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004cdc:	4741                	li	a4,16
    80004cde:	f2c42683          	lw	a3,-212(s0)
    80004ce2:	864e                	mv	a2,s3
    80004ce4:	4581                	li	a1,0
    80004ce6:	8526                	mv	a0,s1
    80004ce8:	867fe0ef          	jal	8000354e <writei>
    80004cec:	47c1                	li	a5,16
    80004cee:	08f51763          	bne	a0,a5,80004d7c <sys_unlink+0x138>
  if(ip->type == T_DIR){
    80004cf2:	04491703          	lh	a4,68(s2)
    80004cf6:	4785                	li	a5,1
    80004cf8:	08f70863          	beq	a4,a5,80004d88 <sys_unlink+0x144>
  iunlockput(dp);
    80004cfc:	8526                	mv	a0,s1
    80004cfe:	f10fe0ef          	jal	8000340e <iunlockput>
  ip->nlink--;
    80004d02:	04a95783          	lhu	a5,74(s2)
    80004d06:	37fd                	addiw	a5,a5,-1
    80004d08:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004d0c:	854a                	mv	a0,s2
    80004d0e:	c40fe0ef          	jal	8000314e <iupdate>
  iunlockput(ip);
    80004d12:	854a                	mv	a0,s2
    80004d14:	efafe0ef          	jal	8000340e <iunlockput>
  end_op();
    80004d18:	e1dfe0ef          	jal	80003b34 <end_op>
  return 0;
    80004d1c:	4501                	li	a0,0
    80004d1e:	64ee                	ld	s1,216(sp)
    80004d20:	694e                	ld	s2,208(sp)
    80004d22:	69ae                	ld	s3,200(sp)
    80004d24:	a059                	j	80004daa <sys_unlink+0x166>
    end_op();
    80004d26:	e0ffe0ef          	jal	80003b34 <end_op>
    return -1;
    80004d2a:	64ee                	ld	s1,216(sp)
    80004d2c:	a8b5                	j	80004da8 <sys_unlink+0x164>
    panic("unlink: nlink < 1");
    80004d2e:	00003517          	auipc	a0,0x3
    80004d32:	90250513          	addi	a0,a0,-1790 # 80007630 <etext+0x630>
    80004d36:	abbfb0ef          	jal	800007f0 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004d3a:	04c92703          	lw	a4,76(s2)
    80004d3e:	02000793          	li	a5,32
    80004d42:	f8e7f6e3          	bgeu	a5,a4,80004cce <sys_unlink+0x8a>
    80004d46:	89be                	mv	s3,a5
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004d48:	4741                	li	a4,16
    80004d4a:	86ce                	mv	a3,s3
    80004d4c:	f1840613          	addi	a2,s0,-232
    80004d50:	4581                	li	a1,0
    80004d52:	854a                	mv	a0,s2
    80004d54:	f08fe0ef          	jal	8000345c <readi>
    80004d58:	47c1                	li	a5,16
    80004d5a:	00f51b63          	bne	a0,a5,80004d70 <sys_unlink+0x12c>
    if(de.inum != 0)
    80004d5e:	f1845783          	lhu	a5,-232(s0)
    80004d62:	eba1                	bnez	a5,80004db2 <sys_unlink+0x16e>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004d64:	29c1                	addiw	s3,s3,16
    80004d66:	04c92783          	lw	a5,76(s2)
    80004d6a:	fcf9efe3          	bltu	s3,a5,80004d48 <sys_unlink+0x104>
    80004d6e:	b785                	j	80004cce <sys_unlink+0x8a>
      panic("isdirempty: readi");
    80004d70:	00003517          	auipc	a0,0x3
    80004d74:	8d850513          	addi	a0,a0,-1832 # 80007648 <etext+0x648>
    80004d78:	a79fb0ef          	jal	800007f0 <panic>
    panic("unlink: writei");
    80004d7c:	00003517          	auipc	a0,0x3
    80004d80:	8e450513          	addi	a0,a0,-1820 # 80007660 <etext+0x660>
    80004d84:	a6dfb0ef          	jal	800007f0 <panic>
    dp->nlink--;
    80004d88:	04a4d783          	lhu	a5,74(s1)
    80004d8c:	37fd                	addiw	a5,a5,-1
    80004d8e:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004d92:	8526                	mv	a0,s1
    80004d94:	bbafe0ef          	jal	8000314e <iupdate>
    80004d98:	b795                	j	80004cfc <sys_unlink+0xb8>
    80004d9a:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    80004d9c:	8526                	mv	a0,s1
    80004d9e:	e70fe0ef          	jal	8000340e <iunlockput>
  end_op();
    80004da2:	d93fe0ef          	jal	80003b34 <end_op>
  return -1;
    80004da6:	64ee                	ld	s1,216(sp)
    return -1;
    80004da8:	557d                	li	a0,-1
}
    80004daa:	70ae                	ld	ra,232(sp)
    80004dac:	740e                	ld	s0,224(sp)
    80004dae:	616d                	addi	sp,sp,240
    80004db0:	8082                	ret
    iunlockput(ip);
    80004db2:	854a                	mv	a0,s2
    80004db4:	e5afe0ef          	jal	8000340e <iunlockput>
    goto bad;
    80004db8:	694e                	ld	s2,208(sp)
    80004dba:	69ae                	ld	s3,200(sp)
    80004dbc:	b7c5                	j	80004d9c <sys_unlink+0x158>

0000000080004dbe <sys_open>:

uint64
sys_open(void)
{
    80004dbe:	7131                	addi	sp,sp,-192
    80004dc0:	fd06                	sd	ra,184(sp)
    80004dc2:	f922                	sd	s0,176(sp)
    80004dc4:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80004dc6:	f4c40593          	addi	a1,s0,-180
    80004dca:	4505                	li	a0,1
    80004dcc:	a25fd0ef          	jal	800027f0 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004dd0:	08000613          	li	a2,128
    80004dd4:	f5040593          	addi	a1,s0,-176
    80004dd8:	4501                	li	a0,0
    80004dda:	a4ffd0ef          	jal	80002828 <argstr>
    80004dde:	10054563          	bltz	a0,80004ee8 <sys_open+0x12a>
    80004de2:	f526                	sd	s1,168(sp)
    return -1;

  begin_op();
    80004de4:	ce1fe0ef          	jal	80003ac4 <begin_op>

  if(omode & O_CREATE){
    80004de8:	f4c42783          	lw	a5,-180(s0)
    80004dec:	2007f793          	andi	a5,a5,512
    80004df0:	cfd9                	beqz	a5,80004e8e <sys_open+0xd0>
    ip = create(path, T_FILE, 0, 0);
    80004df2:	4681                	li	a3,0
    80004df4:	4601                	li	a2,0
    80004df6:	4589                	li	a1,2
    80004df8:	f5040513          	addi	a0,s0,-176
    80004dfc:	acdff0ef          	jal	800048c8 <create>
    80004e00:	84aa                	mv	s1,a0
    if(ip == 0){
    80004e02:	c151                	beqz	a0,80004e86 <sys_open+0xc8>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    80004e04:	04449703          	lh	a4,68(s1)
    80004e08:	478d                	li	a5,3
    80004e0a:	00f71763          	bne	a4,a5,80004e18 <sys_open+0x5a>
    80004e0e:	0464d703          	lhu	a4,70(s1)
    80004e12:	47a5                	li	a5,9
    80004e14:	0ae7e863          	bltu	a5,a4,80004ec4 <sys_open+0x106>
    80004e18:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80004e1a:	834ff0ef          	jal	80003e4e <filealloc>
    80004e1e:	892a                	mv	s2,a0
    80004e20:	cd4d                	beqz	a0,80004eda <sys_open+0x11c>
    80004e22:	ed4e                	sd	s3,152(sp)
    80004e24:	a67ff0ef          	jal	8000488a <fdalloc>
    80004e28:	89aa                	mv	s3,a0
    80004e2a:	0a054463          	bltz	a0,80004ed2 <sys_open+0x114>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80004e2e:	04449703          	lh	a4,68(s1)
    80004e32:	478d                	li	a5,3
    80004e34:	0af70f63          	beq	a4,a5,80004ef2 <sys_open+0x134>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80004e38:	4789                	li	a5,2
    80004e3a:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    80004e3e:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    80004e42:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80004e46:	f4c42783          	lw	a5,-180(s0)
    80004e4a:	0017f713          	andi	a4,a5,1
    80004e4e:	00174713          	xori	a4,a4,1
    80004e52:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80004e56:	0037f713          	andi	a4,a5,3
    80004e5a:	00e03733          	snez	a4,a4
    80004e5e:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80004e62:	4007f793          	andi	a5,a5,1024
    80004e66:	c791                	beqz	a5,80004e72 <sys_open+0xb4>
    80004e68:	04449703          	lh	a4,68(s1)
    80004e6c:	4789                	li	a5,2
    80004e6e:	08f70963          	beq	a4,a5,80004f00 <sys_open+0x142>
    itrunc(ip);
  }

  iunlock(ip);
    80004e72:	8526                	mv	a0,s1
    80004e74:	c3cfe0ef          	jal	800032b0 <iunlock>
  end_op();
    80004e78:	cbdfe0ef          	jal	80003b34 <end_op>

  return fd;
    80004e7c:	854e                	mv	a0,s3
    80004e7e:	74aa                	ld	s1,168(sp)
    80004e80:	790a                	ld	s2,160(sp)
    80004e82:	69ea                	ld	s3,152(sp)
    80004e84:	a09d                	j	80004eea <sys_open+0x12c>
      end_op();
    80004e86:	caffe0ef          	jal	80003b34 <end_op>
      return -1;
    80004e8a:	74aa                	ld	s1,168(sp)
    80004e8c:	a8b1                	j	80004ee8 <sys_open+0x12a>
    if((ip = namei(path)) == 0){
    80004e8e:	f5040513          	addi	a0,s0,-176
    80004e92:	a71fe0ef          	jal	80003902 <namei>
    80004e96:	84aa                	mv	s1,a0
    80004e98:	c115                	beqz	a0,80004ebc <sys_open+0xfe>
    ilock(ip);
    80004e9a:	b68fe0ef          	jal	80003202 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    80004e9e:	04449703          	lh	a4,68(s1)
    80004ea2:	4785                	li	a5,1
    80004ea4:	f6f710e3          	bne	a4,a5,80004e04 <sys_open+0x46>
    80004ea8:	f4c42783          	lw	a5,-180(s0)
    80004eac:	d7b5                	beqz	a5,80004e18 <sys_open+0x5a>
      iunlockput(ip);
    80004eae:	8526                	mv	a0,s1
    80004eb0:	d5efe0ef          	jal	8000340e <iunlockput>
      end_op();
    80004eb4:	c81fe0ef          	jal	80003b34 <end_op>
      return -1;
    80004eb8:	74aa                	ld	s1,168(sp)
    80004eba:	a03d                	j	80004ee8 <sys_open+0x12a>
      end_op();
    80004ebc:	c79fe0ef          	jal	80003b34 <end_op>
      return -1;
    80004ec0:	74aa                	ld	s1,168(sp)
    80004ec2:	a01d                	j	80004ee8 <sys_open+0x12a>
    iunlockput(ip);
    80004ec4:	8526                	mv	a0,s1
    80004ec6:	d48fe0ef          	jal	8000340e <iunlockput>
    end_op();
    80004eca:	c6bfe0ef          	jal	80003b34 <end_op>
    return -1;
    80004ece:	74aa                	ld	s1,168(sp)
    80004ed0:	a821                	j	80004ee8 <sys_open+0x12a>
      fileclose(f);
    80004ed2:	854a                	mv	a0,s2
    80004ed4:	81eff0ef          	jal	80003ef2 <fileclose>
    80004ed8:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80004eda:	8526                	mv	a0,s1
    80004edc:	d32fe0ef          	jal	8000340e <iunlockput>
    end_op();
    80004ee0:	c55fe0ef          	jal	80003b34 <end_op>
    return -1;
    80004ee4:	74aa                	ld	s1,168(sp)
    80004ee6:	790a                	ld	s2,160(sp)
    return -1;
    80004ee8:	557d                	li	a0,-1
}
    80004eea:	70ea                	ld	ra,184(sp)
    80004eec:	744a                	ld	s0,176(sp)
    80004eee:	6129                	addi	sp,sp,192
    80004ef0:	8082                	ret
    f->type = FD_DEVICE;
    80004ef2:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    80004ef6:	04649783          	lh	a5,70(s1)
    80004efa:	02f91223          	sh	a5,36(s2)
    80004efe:	b791                	j	80004e42 <sys_open+0x84>
    itrunc(ip);
    80004f00:	8526                	mv	a0,s1
    80004f02:	beefe0ef          	jal	800032f0 <itrunc>
    80004f06:	b7b5                	j	80004e72 <sys_open+0xb4>

0000000080004f08 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80004f08:	7175                	addi	sp,sp,-144
    80004f0a:	e506                	sd	ra,136(sp)
    80004f0c:	e122                	sd	s0,128(sp)
    80004f0e:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80004f10:	bb5fe0ef          	jal	80003ac4 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    80004f14:	08000613          	li	a2,128
    80004f18:	f7040593          	addi	a1,s0,-144
    80004f1c:	4501                	li	a0,0
    80004f1e:	90bfd0ef          	jal	80002828 <argstr>
    80004f22:	02054363          	bltz	a0,80004f48 <sys_mkdir+0x40>
    80004f26:	4681                	li	a3,0
    80004f28:	4601                	li	a2,0
    80004f2a:	4585                	li	a1,1
    80004f2c:	f7040513          	addi	a0,s0,-144
    80004f30:	999ff0ef          	jal	800048c8 <create>
    80004f34:	c911                	beqz	a0,80004f48 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004f36:	cd8fe0ef          	jal	8000340e <iunlockput>
  end_op();
    80004f3a:	bfbfe0ef          	jal	80003b34 <end_op>
  return 0;
    80004f3e:	4501                	li	a0,0
}
    80004f40:	60aa                	ld	ra,136(sp)
    80004f42:	640a                	ld	s0,128(sp)
    80004f44:	6149                	addi	sp,sp,144
    80004f46:	8082                	ret
    end_op();
    80004f48:	bedfe0ef          	jal	80003b34 <end_op>
    return -1;
    80004f4c:	557d                	li	a0,-1
    80004f4e:	bfcd                	j	80004f40 <sys_mkdir+0x38>

0000000080004f50 <sys_mknod>:

uint64
sys_mknod(void)
{
    80004f50:	7135                	addi	sp,sp,-160
    80004f52:	ed06                	sd	ra,152(sp)
    80004f54:	e922                	sd	s0,144(sp)
    80004f56:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80004f58:	b6dfe0ef          	jal	80003ac4 <begin_op>
  argint(1, &major);
    80004f5c:	f6c40593          	addi	a1,s0,-148
    80004f60:	4505                	li	a0,1
    80004f62:	88ffd0ef          	jal	800027f0 <argint>
  argint(2, &minor);
    80004f66:	f6840593          	addi	a1,s0,-152
    80004f6a:	4509                	li	a0,2
    80004f6c:	885fd0ef          	jal	800027f0 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004f70:	08000613          	li	a2,128
    80004f74:	f7040593          	addi	a1,s0,-144
    80004f78:	4501                	li	a0,0
    80004f7a:	8affd0ef          	jal	80002828 <argstr>
    80004f7e:	02054563          	bltz	a0,80004fa8 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    80004f82:	f6841683          	lh	a3,-152(s0)
    80004f86:	f6c41603          	lh	a2,-148(s0)
    80004f8a:	458d                	li	a1,3
    80004f8c:	f7040513          	addi	a0,s0,-144
    80004f90:	939ff0ef          	jal	800048c8 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80004f94:	c911                	beqz	a0,80004fa8 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80004f96:	c78fe0ef          	jal	8000340e <iunlockput>
  end_op();
    80004f9a:	b9bfe0ef          	jal	80003b34 <end_op>
  return 0;
    80004f9e:	4501                	li	a0,0
}
    80004fa0:	60ea                	ld	ra,152(sp)
    80004fa2:	644a                	ld	s0,144(sp)
    80004fa4:	610d                	addi	sp,sp,160
    80004fa6:	8082                	ret
    end_op();
    80004fa8:	b8dfe0ef          	jal	80003b34 <end_op>
    return -1;
    80004fac:	557d                	li	a0,-1
    80004fae:	bfcd                	j	80004fa0 <sys_mknod+0x50>

0000000080004fb0 <sys_chdir>:

uint64
sys_chdir(void)
{
    80004fb0:	7135                	addi	sp,sp,-160
    80004fb2:	ed06                	sd	ra,152(sp)
    80004fb4:	e922                	sd	s0,144(sp)
    80004fb6:	e14a                	sd	s2,128(sp)
    80004fb8:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    80004fba:	96bfc0ef          	jal	80001924 <myproc>
    80004fbe:	892a                	mv	s2,a0
  
  begin_op();
    80004fc0:	b05fe0ef          	jal	80003ac4 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    80004fc4:	08000613          	li	a2,128
    80004fc8:	f6040593          	addi	a1,s0,-160
    80004fcc:	4501                	li	a0,0
    80004fce:	85bfd0ef          	jal	80002828 <argstr>
    80004fd2:	02054f63          	bltz	a0,80005010 <sys_chdir+0x60>
    80004fd6:	e526                	sd	s1,136(sp)
    80004fd8:	f6040513          	addi	a0,s0,-160
    80004fdc:	927fe0ef          	jal	80003902 <namei>
    80004fe0:	84aa                	mv	s1,a0
    80004fe2:	c515                	beqz	a0,8000500e <sys_chdir+0x5e>
    end_op();
    return -1;
  }
  ilock(ip);
    80004fe4:	a1efe0ef          	jal	80003202 <ilock>
  if(ip->type != T_DIR){
    80004fe8:	04449703          	lh	a4,68(s1)
    80004fec:	4785                	li	a5,1
    80004fee:	02f71963          	bne	a4,a5,80005020 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    80004ff2:	8526                	mv	a0,s1
    80004ff4:	abcfe0ef          	jal	800032b0 <iunlock>
  iput(p->cwd);
    80004ff8:	15093503          	ld	a0,336(s2)
    80004ffc:	b88fe0ef          	jal	80003384 <iput>
  end_op();
    80005000:	b35fe0ef          	jal	80003b34 <end_op>
  p->cwd = ip;
    80005004:	14993823          	sd	s1,336(s2)
  return 0;
    80005008:	4501                	li	a0,0
    8000500a:	64aa                	ld	s1,136(sp)
    8000500c:	a029                	j	80005016 <sys_chdir+0x66>
    8000500e:	64aa                	ld	s1,136(sp)
    end_op();
    80005010:	b25fe0ef          	jal	80003b34 <end_op>
    return -1;
    80005014:	557d                	li	a0,-1
}
    80005016:	60ea                	ld	ra,152(sp)
    80005018:	644a                	ld	s0,144(sp)
    8000501a:	690a                	ld	s2,128(sp)
    8000501c:	610d                	addi	sp,sp,160
    8000501e:	8082                	ret
    iunlockput(ip);
    80005020:	8526                	mv	a0,s1
    80005022:	becfe0ef          	jal	8000340e <iunlockput>
    end_op();
    80005026:	b0ffe0ef          	jal	80003b34 <end_op>
    return -1;
    8000502a:	64aa                	ld	s1,136(sp)
    8000502c:	b7e5                	j	80005014 <sys_chdir+0x64>

000000008000502e <sys_exec>:

uint64
sys_exec(void)
{
    8000502e:	7105                	addi	sp,sp,-480
    80005030:	ef86                	sd	ra,472(sp)
    80005032:	eba2                	sd	s0,464(sp)
    80005034:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80005036:	e2840593          	addi	a1,s0,-472
    8000503a:	4505                	li	a0,1
    8000503c:	fd0fd0ef          	jal	8000280c <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80005040:	08000613          	li	a2,128
    80005044:	f3040593          	addi	a1,s0,-208
    80005048:	4501                	li	a0,0
    8000504a:	fdefd0ef          	jal	80002828 <argstr>
    8000504e:	0c054e63          	bltz	a0,8000512a <sys_exec+0xfc>
    80005052:	e7a6                	sd	s1,456(sp)
    80005054:	e3ca                	sd	s2,448(sp)
    80005056:	ff4e                	sd	s3,440(sp)
    80005058:	fb52                	sd	s4,432(sp)
    8000505a:	f756                	sd	s5,424(sp)
    8000505c:	f35a                	sd	s6,416(sp)
    8000505e:	ef5e                	sd	s7,408(sp)
    return -1;
  }
  memset(argv, 0, sizeof(argv));
    80005060:	e3040a13          	addi	s4,s0,-464
    80005064:	10000613          	li	a2,256
    80005068:	4581                	li	a1,0
    8000506a:	8552                	mv	a0,s4
    8000506c:	cc5fb0ef          	jal	80000d30 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80005070:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    80005072:	89d2                	mv	s3,s4
    80005074:	4901                	li	s2,0
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80005076:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    8000507a:	6b05                	lui	s6,0x1
    if(i >= NELEM(argv)){
    8000507c:	02000b93          	li	s7,32
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80005080:	00391513          	slli	a0,s2,0x3
    80005084:	85d6                	mv	a1,s5
    80005086:	e2843783          	ld	a5,-472(s0)
    8000508a:	953e                	add	a0,a0,a5
    8000508c:	edefd0ef          	jal	8000276a <fetchaddr>
    80005090:	02054663          	bltz	a0,800050bc <sys_exec+0x8e>
    if(uarg == 0){
    80005094:	e2043783          	ld	a5,-480(s0)
    80005098:	c3b9                	beqz	a5,800050de <sys_exec+0xb0>
    argv[i] = kalloc();
    8000509a:	ae7fb0ef          	jal	80000b80 <kalloc>
    8000509e:	85aa                	mv	a1,a0
    800050a0:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    800050a4:	cd01                	beqz	a0,800050bc <sys_exec+0x8e>
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800050a6:	865a                	mv	a2,s6
    800050a8:	e2043503          	ld	a0,-480(s0)
    800050ac:	f04fd0ef          	jal	800027b0 <fetchstr>
    800050b0:	00054663          	bltz	a0,800050bc <sys_exec+0x8e>
    if(i >= NELEM(argv)){
    800050b4:	0905                	addi	s2,s2,1
    800050b6:	09a1                	addi	s3,s3,8
    800050b8:	fd7914e3          	bne	s2,s7,80005080 <sys_exec+0x52>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800050bc:	100a0a13          	addi	s4,s4,256
    800050c0:	6088                	ld	a0,0(s1)
    800050c2:	cd29                	beqz	a0,8000511c <sys_exec+0xee>
    kfree(argv[i]);
    800050c4:	9d5fb0ef          	jal	80000a98 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800050c8:	04a1                	addi	s1,s1,8
    800050ca:	ff449be3          	bne	s1,s4,800050c0 <sys_exec+0x92>
    800050ce:	64be                	ld	s1,456(sp)
    800050d0:	691e                	ld	s2,448(sp)
    800050d2:	79fa                	ld	s3,440(sp)
    800050d4:	7a5a                	ld	s4,432(sp)
    800050d6:	7aba                	ld	s5,424(sp)
    800050d8:	7b1a                	ld	s6,416(sp)
    800050da:	6bfa                	ld	s7,408(sp)
    800050dc:	a0b9                	j	8000512a <sys_exec+0xfc>
      argv[i] = 0;
    800050de:	0009079b          	sext.w	a5,s2
    800050e2:	e3040593          	addi	a1,s0,-464
    800050e6:	078e                	slli	a5,a5,0x3
    800050e8:	97ae                	add	a5,a5,a1
    800050ea:	0007b023          	sd	zero,0(a5)
  int ret = exec(path, argv);
    800050ee:	f3040513          	addi	a0,s0,-208
    800050f2:	c30ff0ef          	jal	80004522 <exec>
    800050f6:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800050f8:	100a0a13          	addi	s4,s4,256
    800050fc:	6088                	ld	a0,0(s1)
    800050fe:	c511                	beqz	a0,8000510a <sys_exec+0xdc>
    kfree(argv[i]);
    80005100:	999fb0ef          	jal	80000a98 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005104:	04a1                	addi	s1,s1,8
    80005106:	ff449be3          	bne	s1,s4,800050fc <sys_exec+0xce>
  return ret;
    8000510a:	854a                	mv	a0,s2
    8000510c:	64be                	ld	s1,456(sp)
    8000510e:	691e                	ld	s2,448(sp)
    80005110:	79fa                	ld	s3,440(sp)
    80005112:	7a5a                	ld	s4,432(sp)
    80005114:	7aba                	ld	s5,424(sp)
    80005116:	7b1a                	ld	s6,416(sp)
    80005118:	6bfa                	ld	s7,408(sp)
    8000511a:	a809                	j	8000512c <sys_exec+0xfe>
    8000511c:	64be                	ld	s1,456(sp)
    8000511e:	691e                	ld	s2,448(sp)
    80005120:	79fa                	ld	s3,440(sp)
    80005122:	7a5a                	ld	s4,432(sp)
    80005124:	7aba                	ld	s5,424(sp)
    80005126:	7b1a                	ld	s6,416(sp)
    80005128:	6bfa                	ld	s7,408(sp)
    return -1;
    8000512a:	557d                	li	a0,-1
  return -1;
}
    8000512c:	60fe                	ld	ra,472(sp)
    8000512e:	645e                	ld	s0,464(sp)
    80005130:	613d                	addi	sp,sp,480
    80005132:	8082                	ret

0000000080005134 <sys_pipe>:

uint64
sys_pipe(void)
{
    80005134:	7139                	addi	sp,sp,-64
    80005136:	fc06                	sd	ra,56(sp)
    80005138:	f822                	sd	s0,48(sp)
    8000513a:	f426                	sd	s1,40(sp)
    8000513c:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    8000513e:	fe6fc0ef          	jal	80001924 <myproc>
    80005142:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    80005144:	fd840593          	addi	a1,s0,-40
    80005148:	4501                	li	a0,0
    8000514a:	ec2fd0ef          	jal	8000280c <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    8000514e:	fc840593          	addi	a1,s0,-56
    80005152:	fd040513          	addi	a0,s0,-48
    80005156:	8aaff0ef          	jal	80004200 <pipealloc>
    8000515a:	0a054463          	bltz	a0,80005202 <sys_pipe+0xce>
    return -1;
  fd0 = -1;
    8000515e:	57fd                	li	a5,-1
    80005160:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    80005164:	fd043503          	ld	a0,-48(s0)
    80005168:	f22ff0ef          	jal	8000488a <fdalloc>
    8000516c:	fca42223          	sw	a0,-60(s0)
    80005170:	08054163          	bltz	a0,800051f2 <sys_pipe+0xbe>
    80005174:	fc843503          	ld	a0,-56(s0)
    80005178:	f12ff0ef          	jal	8000488a <fdalloc>
    8000517c:	fca42023          	sw	a0,-64(s0)
    80005180:	06054063          	bltz	a0,800051e0 <sys_pipe+0xac>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    80005184:	4691                	li	a3,4
    80005186:	fc440613          	addi	a2,s0,-60
    8000518a:	fd843583          	ld	a1,-40(s0)
    8000518e:	68a8                	ld	a0,80(s1)
    80005190:	c24fc0ef          	jal	800015b4 <copyout>
    80005194:	00054f63          	bltz	a0,800051b2 <sys_pipe+0x7e>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80005198:	4691                	li	a3,4
    8000519a:	fc040613          	addi	a2,s0,-64
    8000519e:	fd843583          	ld	a1,-40(s0)
    800051a2:	95b6                	add	a1,a1,a3
    800051a4:	68a8                	ld	a0,80(s1)
    800051a6:	c0efc0ef          	jal	800015b4 <copyout>
    800051aa:	87aa                	mv	a5,a0
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    800051ac:	4501                	li	a0,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800051ae:	0407db63          	bgez	a5,80005204 <sys_pipe+0xd0>
    p->ofile[fd0] = 0;
    800051b2:	fc442783          	lw	a5,-60(s0)
    800051b6:	07e9                	addi	a5,a5,26
    800051b8:	078e                	slli	a5,a5,0x3
    800051ba:	97a6                	add	a5,a5,s1
    800051bc:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    800051c0:	fc042783          	lw	a5,-64(s0)
    800051c4:	07e9                	addi	a5,a5,26
    800051c6:	078e                	slli	a5,a5,0x3
    800051c8:	97a6                	add	a5,a5,s1
    800051ca:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    800051ce:	fd043503          	ld	a0,-48(s0)
    800051d2:	d21fe0ef          	jal	80003ef2 <fileclose>
    fileclose(wf);
    800051d6:	fc843503          	ld	a0,-56(s0)
    800051da:	d19fe0ef          	jal	80003ef2 <fileclose>
    return -1;
    800051de:	a015                	j	80005202 <sys_pipe+0xce>
    if(fd0 >= 0)
    800051e0:	fc442783          	lw	a5,-60(s0)
    800051e4:	0007c763          	bltz	a5,800051f2 <sys_pipe+0xbe>
      p->ofile[fd0] = 0;
    800051e8:	07e9                	addi	a5,a5,26
    800051ea:	078e                	slli	a5,a5,0x3
    800051ec:	97a6                	add	a5,a5,s1
    800051ee:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    800051f2:	fd043503          	ld	a0,-48(s0)
    800051f6:	cfdfe0ef          	jal	80003ef2 <fileclose>
    fileclose(wf);
    800051fa:	fc843503          	ld	a0,-56(s0)
    800051fe:	cf5fe0ef          	jal	80003ef2 <fileclose>
    return -1;
    80005202:	557d                	li	a0,-1
}
    80005204:	70e2                	ld	ra,56(sp)
    80005206:	7442                	ld	s0,48(sp)
    80005208:	74a2                	ld	s1,40(sp)
    8000520a:	6121                	addi	sp,sp,64
    8000520c:	8082                	ret
	...

0000000080005210 <kernelvec>:
    80005210:	7111                	addi	sp,sp,-256
    80005212:	e006                	sd	ra,0(sp)
    80005214:	e40a                	sd	sp,8(sp)
    80005216:	e80e                	sd	gp,16(sp)
    80005218:	ec12                	sd	tp,24(sp)
    8000521a:	f016                	sd	t0,32(sp)
    8000521c:	f41a                	sd	t1,40(sp)
    8000521e:	f81e                	sd	t2,48(sp)
    80005220:	e4aa                	sd	a0,72(sp)
    80005222:	e8ae                	sd	a1,80(sp)
    80005224:	ecb2                	sd	a2,88(sp)
    80005226:	f0b6                	sd	a3,96(sp)
    80005228:	f4ba                	sd	a4,104(sp)
    8000522a:	f8be                	sd	a5,112(sp)
    8000522c:	fcc2                	sd	a6,120(sp)
    8000522e:	e146                	sd	a7,128(sp)
    80005230:	edf2                	sd	t3,216(sp)
    80005232:	f1f6                	sd	t4,224(sp)
    80005234:	f5fa                	sd	t5,232(sp)
    80005236:	f9fe                	sd	t6,240(sp)
    80005238:	c40fd0ef          	jal	80002678 <kerneltrap>
    8000523c:	6082                	ld	ra,0(sp)
    8000523e:	6122                	ld	sp,8(sp)
    80005240:	61c2                	ld	gp,16(sp)
    80005242:	7282                	ld	t0,32(sp)
    80005244:	7322                	ld	t1,40(sp)
    80005246:	73c2                	ld	t2,48(sp)
    80005248:	6526                	ld	a0,72(sp)
    8000524a:	65c6                	ld	a1,80(sp)
    8000524c:	6666                	ld	a2,88(sp)
    8000524e:	7686                	ld	a3,96(sp)
    80005250:	7726                	ld	a4,104(sp)
    80005252:	77c6                	ld	a5,112(sp)
    80005254:	7866                	ld	a6,120(sp)
    80005256:	688a                	ld	a7,128(sp)
    80005258:	6e6e                	ld	t3,216(sp)
    8000525a:	7e8e                	ld	t4,224(sp)
    8000525c:	7f2e                	ld	t5,232(sp)
    8000525e:	7fce                	ld	t6,240(sp)
    80005260:	6111                	addi	sp,sp,256
    80005262:	10200073          	sret
    80005266:	00000013          	nop
    8000526a:	00000013          	nop

000000008000526e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000526e:	1141                	addi	sp,sp,-16
    80005270:	e406                	sd	ra,8(sp)
    80005272:	e022                	sd	s0,0(sp)
    80005274:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80005276:	0c000737          	lui	a4,0xc000
    8000527a:	4785                	li	a5,1
    8000527c:	d71c                	sw	a5,40(a4)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000527e:	c35c                	sw	a5,4(a4)
}
    80005280:	60a2                	ld	ra,8(sp)
    80005282:	6402                	ld	s0,0(sp)
    80005284:	0141                	addi	sp,sp,16
    80005286:	8082                	ret

0000000080005288 <plicinithart>:

void
plicinithart(void)
{
    80005288:	1141                	addi	sp,sp,-16
    8000528a:	e406                	sd	ra,8(sp)
    8000528c:	e022                	sd	s0,0(sp)
    8000528e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005290:	e60fc0ef          	jal	800018f0 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005294:	0085171b          	slliw	a4,a0,0x8
    80005298:	0c0027b7          	lui	a5,0xc002
    8000529c:	97ba                	add	a5,a5,a4
    8000529e:	40200713          	li	a4,1026
    800052a2:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    800052a6:	00d5151b          	slliw	a0,a0,0xd
    800052aa:	0c2017b7          	lui	a5,0xc201
    800052ae:	97aa                	add	a5,a5,a0
    800052b0:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    800052b4:	60a2                	ld	ra,8(sp)
    800052b6:	6402                	ld	s0,0(sp)
    800052b8:	0141                	addi	sp,sp,16
    800052ba:	8082                	ret

00000000800052bc <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    800052bc:	1141                	addi	sp,sp,-16
    800052be:	e406                	sd	ra,8(sp)
    800052c0:	e022                	sd	s0,0(sp)
    800052c2:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800052c4:	e2cfc0ef          	jal	800018f0 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    800052c8:	00d5151b          	slliw	a0,a0,0xd
    800052cc:	0c2017b7          	lui	a5,0xc201
    800052d0:	97aa                	add	a5,a5,a0
  return irq;
}
    800052d2:	43c8                	lw	a0,4(a5)
    800052d4:	60a2                	ld	ra,8(sp)
    800052d6:	6402                	ld	s0,0(sp)
    800052d8:	0141                	addi	sp,sp,16
    800052da:	8082                	ret

00000000800052dc <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    800052dc:	1101                	addi	sp,sp,-32
    800052de:	ec06                	sd	ra,24(sp)
    800052e0:	e822                	sd	s0,16(sp)
    800052e2:	e426                	sd	s1,8(sp)
    800052e4:	1000                	addi	s0,sp,32
    800052e6:	84aa                	mv	s1,a0
  int hart = cpuid();
    800052e8:	e08fc0ef          	jal	800018f0 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    800052ec:	00d5179b          	slliw	a5,a0,0xd
    800052f0:	0c201737          	lui	a4,0xc201
    800052f4:	97ba                	add	a5,a5,a4
    800052f6:	c3c4                	sw	s1,4(a5)
}
    800052f8:	60e2                	ld	ra,24(sp)
    800052fa:	6442                	ld	s0,16(sp)
    800052fc:	64a2                	ld	s1,8(sp)
    800052fe:	6105                	addi	sp,sp,32
    80005300:	8082                	ret

0000000080005302 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005302:	1141                	addi	sp,sp,-16
    80005304:	e406                	sd	ra,8(sp)
    80005306:	e022                	sd	s0,0(sp)
    80005308:	0800                	addi	s0,sp,16
  if(i >= NUM)
    8000530a:	479d                	li	a5,7
    8000530c:	04a7ca63          	blt	a5,a0,80005360 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80005310:	0001c797          	auipc	a5,0x1c
    80005314:	80078793          	addi	a5,a5,-2048 # 80020b10 <disk>
    80005318:	97aa                	add	a5,a5,a0
    8000531a:	0187c783          	lbu	a5,24(a5)
    8000531e:	e7b9                	bnez	a5,8000536c <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005320:	00451693          	slli	a3,a0,0x4
    80005324:	0001b797          	auipc	a5,0x1b
    80005328:	7ec78793          	addi	a5,a5,2028 # 80020b10 <disk>
    8000532c:	6398                	ld	a4,0(a5)
    8000532e:	9736                	add	a4,a4,a3
    80005330:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    80005334:	6398                	ld	a4,0(a5)
    80005336:	9736                	add	a4,a4,a3
    80005338:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    8000533c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005340:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005344:	97aa                	add	a5,a5,a0
    80005346:	4705                	li	a4,1
    80005348:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    8000534c:	0001b517          	auipc	a0,0x1b
    80005350:	7dc50513          	addi	a0,a0,2012 # 80020b28 <disk+0x18>
    80005354:	bd9fc0ef          	jal	80001f2c <wakeup>
}
    80005358:	60a2                	ld	ra,8(sp)
    8000535a:	6402                	ld	s0,0(sp)
    8000535c:	0141                	addi	sp,sp,16
    8000535e:	8082                	ret
    panic("free_desc 1");
    80005360:	00002517          	auipc	a0,0x2
    80005364:	31050513          	addi	a0,a0,784 # 80007670 <etext+0x670>
    80005368:	c88fb0ef          	jal	800007f0 <panic>
    panic("free_desc 2");
    8000536c:	00002517          	auipc	a0,0x2
    80005370:	31450513          	addi	a0,a0,788 # 80007680 <etext+0x680>
    80005374:	c7cfb0ef          	jal	800007f0 <panic>

0000000080005378 <virtio_disk_init>:
{
    80005378:	1101                	addi	sp,sp,-32
    8000537a:	ec06                	sd	ra,24(sp)
    8000537c:	e822                	sd	s0,16(sp)
    8000537e:	e426                	sd	s1,8(sp)
    80005380:	e04a                	sd	s2,0(sp)
    80005382:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005384:	00002597          	auipc	a1,0x2
    80005388:	30c58593          	addi	a1,a1,780 # 80007690 <etext+0x690>
    8000538c:	0001c517          	auipc	a0,0x1c
    80005390:	8ac50513          	addi	a0,a0,-1876 # 80020c38 <disk+0x128>
    80005394:	847fb0ef          	jal	80000bda <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005398:	100017b7          	lui	a5,0x10001
    8000539c:	4398                	lw	a4,0(a5)
    8000539e:	747277b7          	lui	a5,0x74727
    800053a2:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    800053a6:	14f71263          	bne	a4,a5,800054ea <virtio_disk_init+0x172>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800053aa:	100017b7          	lui	a5,0x10001
    800053ae:	43d8                	lw	a4,4(a5)
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800053b0:	4789                	li	a5,2
    800053b2:	12f71c63          	bne	a4,a5,800054ea <virtio_disk_init+0x172>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800053b6:	100017b7          	lui	a5,0x10001
    800053ba:	4798                	lw	a4,8(a5)
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800053bc:	4789                	li	a5,2
    800053be:	12f71663          	bne	a4,a5,800054ea <virtio_disk_init+0x172>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    800053c2:	100017b7          	lui	a5,0x10001
    800053c6:	47d8                	lw	a4,12(a5)
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800053c8:	554d47b7          	lui	a5,0x554d4
    800053cc:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    800053d0:	10f71d63          	bne	a4,a5,800054ea <virtio_disk_init+0x172>
  *R(VIRTIO_MMIO_STATUS) = status;
    800053d4:	100017b7          	lui	a5,0x10001
    800053d8:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    800053dc:	4705                	li	a4,1
    800053de:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800053e0:	470d                	li	a4,3
    800053e2:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    800053e4:	10001737          	lui	a4,0x10001
    800053e8:	4b18                	lw	a4,16(a4)
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    800053ea:	c7ffe6b7          	lui	a3,0xc7ffe
    800053ee:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fddb0f>
    800053f2:	8f75                	and	a4,a4,a3
    800053f4:	100016b7          	lui	a3,0x10001
    800053f8:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    800053fa:	472d                	li	a4,11
    800053fc:	dbb8                	sw	a4,112(a5)
  status = *R(VIRTIO_MMIO_STATUS);
    800053fe:	0707a903          	lw	s2,112(a5)
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005402:	00897793          	andi	a5,s2,8
    80005406:	0e078863          	beqz	a5,800054f6 <virtio_disk_init+0x17e>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    8000540a:	100017b7          	lui	a5,0x10001
    8000540e:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80005412:	43fc                	lw	a5,68(a5)
    80005414:	0e079763          	bnez	a5,80005502 <virtio_disk_init+0x18a>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005418:	100017b7          	lui	a5,0x10001
    8000541c:	5bdc                	lw	a5,52(a5)
  if(max == 0)
    8000541e:	0e078863          	beqz	a5,8000550e <virtio_disk_init+0x196>
  if(max < NUM)
    80005422:	471d                	li	a4,7
    80005424:	0ef77b63          	bgeu	a4,a5,8000551a <virtio_disk_init+0x1a2>
  disk.desc = kalloc();
    80005428:	f58fb0ef          	jal	80000b80 <kalloc>
    8000542c:	0001b497          	auipc	s1,0x1b
    80005430:	6e448493          	addi	s1,s1,1764 # 80020b10 <disk>
    80005434:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80005436:	f4afb0ef          	jal	80000b80 <kalloc>
    8000543a:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    8000543c:	f44fb0ef          	jal	80000b80 <kalloc>
    80005440:	87aa                	mv	a5,a0
    80005442:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80005444:	6088                	ld	a0,0(s1)
    80005446:	0e050063          	beqz	a0,80005526 <virtio_disk_init+0x1ae>
    8000544a:	0001b717          	auipc	a4,0x1b
    8000544e:	6ce73703          	ld	a4,1742(a4) # 80020b18 <disk+0x8>
    80005452:	00173713          	seqz	a4,a4
    80005456:	0017b793          	seqz	a5,a5
    8000545a:	8fd9                	or	a5,a5,a4
    8000545c:	e7e9                	bnez	a5,80005526 <virtio_disk_init+0x1ae>
  memset(disk.desc, 0, PGSIZE);
    8000545e:	6605                	lui	a2,0x1
    80005460:	4581                	li	a1,0
    80005462:	8cffb0ef          	jal	80000d30 <memset>
  memset(disk.avail, 0, PGSIZE);
    80005466:	0001b497          	auipc	s1,0x1b
    8000546a:	6aa48493          	addi	s1,s1,1706 # 80020b10 <disk>
    8000546e:	6605                	lui	a2,0x1
    80005470:	4581                	li	a1,0
    80005472:	6488                	ld	a0,8(s1)
    80005474:	8bdfb0ef          	jal	80000d30 <memset>
  memset(disk.used, 0, PGSIZE);
    80005478:	6605                	lui	a2,0x1
    8000547a:	4581                	li	a1,0
    8000547c:	6888                	ld	a0,16(s1)
    8000547e:	8b3fb0ef          	jal	80000d30 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80005482:	100017b7          	lui	a5,0x10001
    80005486:	4721                	li	a4,8
    80005488:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    8000548a:	4098                	lw	a4,0(s1)
    8000548c:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80005490:	40d8                	lw	a4,4(s1)
    80005492:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005496:	649c                	ld	a5,8(s1)
    80005498:	10001737          	lui	a4,0x10001
    8000549c:	08f72823          	sw	a5,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    800054a0:	9781                	srai	a5,a5,0x20
    800054a2:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    800054a6:	689c                	ld	a5,16(s1)
    800054a8:	0af72023          	sw	a5,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    800054ac:	9781                	srai	a5,a5,0x20
    800054ae:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    800054b2:	4785                	li	a5,1
    800054b4:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    800054b6:	00f48c23          	sb	a5,24(s1)
    800054ba:	00f48ca3          	sb	a5,25(s1)
    800054be:	00f48d23          	sb	a5,26(s1)
    800054c2:	00f48da3          	sb	a5,27(s1)
    800054c6:	00f48e23          	sb	a5,28(s1)
    800054ca:	00f48ea3          	sb	a5,29(s1)
    800054ce:	00f48f23          	sb	a5,30(s1)
    800054d2:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    800054d6:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    800054da:	07272823          	sw	s2,112(a4)
}
    800054de:	60e2                	ld	ra,24(sp)
    800054e0:	6442                	ld	s0,16(sp)
    800054e2:	64a2                	ld	s1,8(sp)
    800054e4:	6902                	ld	s2,0(sp)
    800054e6:	6105                	addi	sp,sp,32
    800054e8:	8082                	ret
    panic("could not find virtio disk");
    800054ea:	00002517          	auipc	a0,0x2
    800054ee:	1b650513          	addi	a0,a0,438 # 800076a0 <etext+0x6a0>
    800054f2:	afefb0ef          	jal	800007f0 <panic>
    panic("virtio disk FEATURES_OK unset");
    800054f6:	00002517          	auipc	a0,0x2
    800054fa:	1ca50513          	addi	a0,a0,458 # 800076c0 <etext+0x6c0>
    800054fe:	af2fb0ef          	jal	800007f0 <panic>
    panic("virtio disk should not be ready");
    80005502:	00002517          	auipc	a0,0x2
    80005506:	1de50513          	addi	a0,a0,478 # 800076e0 <etext+0x6e0>
    8000550a:	ae6fb0ef          	jal	800007f0 <panic>
    panic("virtio disk has no queue 0");
    8000550e:	00002517          	auipc	a0,0x2
    80005512:	1f250513          	addi	a0,a0,498 # 80007700 <etext+0x700>
    80005516:	adafb0ef          	jal	800007f0 <panic>
    panic("virtio disk max queue too short");
    8000551a:	00002517          	auipc	a0,0x2
    8000551e:	20650513          	addi	a0,a0,518 # 80007720 <etext+0x720>
    80005522:	acefb0ef          	jal	800007f0 <panic>
    panic("virtio disk kalloc");
    80005526:	00002517          	auipc	a0,0x2
    8000552a:	21a50513          	addi	a0,a0,538 # 80007740 <etext+0x740>
    8000552e:	ac2fb0ef          	jal	800007f0 <panic>

0000000080005532 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80005532:	711d                	addi	sp,sp,-96
    80005534:	ec86                	sd	ra,88(sp)
    80005536:	e8a2                	sd	s0,80(sp)
    80005538:	e4a6                	sd	s1,72(sp)
    8000553a:	e0ca                	sd	s2,64(sp)
    8000553c:	fc4e                	sd	s3,56(sp)
    8000553e:	f852                	sd	s4,48(sp)
    80005540:	f456                	sd	s5,40(sp)
    80005542:	f05a                	sd	s6,32(sp)
    80005544:	ec5e                	sd	s7,24(sp)
    80005546:	e862                	sd	s8,16(sp)
    80005548:	1080                	addi	s0,sp,96
    8000554a:	89aa                	mv	s3,a0
    8000554c:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    8000554e:	00c52b83          	lw	s7,12(a0)
    80005552:	001b9b9b          	slliw	s7,s7,0x1
    80005556:	1b82                	slli	s7,s7,0x20
    80005558:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    8000555c:	0001b517          	auipc	a0,0x1b
    80005560:	6dc50513          	addi	a0,a0,1756 # 80020c38 <disk+0x128>
    80005564:	f00fb0ef          	jal	80000c64 <acquire>
  for(int i = 0; i < NUM; i++){
    80005568:	44a1                	li	s1,8
      disk.free[i] = 0;
    8000556a:	0001ba97          	auipc	s5,0x1b
    8000556e:	5a6a8a93          	addi	s5,s5,1446 # 80020b10 <disk>
  for(int i = 0; i < 3; i++){
    80005572:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    80005574:	5c7d                	li	s8,-1
    80005576:	a095                	j	800055da <virtio_disk_rw+0xa8>
      disk.free[i] = 0;
    80005578:	00fa8733          	add	a4,s5,a5
    8000557c:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80005580:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80005582:	0207c563          	bltz	a5,800055ac <virtio_disk_rw+0x7a>
  for(int i = 0; i < 3; i++){
    80005586:	2905                	addiw	s2,s2,1
    80005588:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    8000558a:	05490c63          	beq	s2,s4,800055e2 <virtio_disk_rw+0xb0>
    idx[i] = alloc_desc();
    8000558e:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80005590:	0001b717          	auipc	a4,0x1b
    80005594:	58070713          	addi	a4,a4,1408 # 80020b10 <disk>
    80005598:	4781                	li	a5,0
    if(disk.free[i]){
    8000559a:	01874683          	lbu	a3,24(a4)
    8000559e:	fee9                	bnez	a3,80005578 <virtio_disk_rw+0x46>
  for(int i = 0; i < NUM; i++){
    800055a0:	2785                	addiw	a5,a5,1
    800055a2:	0705                	addi	a4,a4,1
    800055a4:	fe979be3          	bne	a5,s1,8000559a <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    800055a8:	0185a023          	sw	s8,0(a1)
      for(int j = 0; j < i; j++)
    800055ac:	01205d63          	blez	s2,800055c6 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    800055b0:	fa042503          	lw	a0,-96(s0)
    800055b4:	d4fff0ef          	jal	80005302 <free_desc>
      for(int j = 0; j < i; j++)
    800055b8:	4785                	li	a5,1
    800055ba:	0127d663          	bge	a5,s2,800055c6 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    800055be:	fa442503          	lw	a0,-92(s0)
    800055c2:	d41ff0ef          	jal	80005302 <free_desc>
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    800055c6:	0001b597          	auipc	a1,0x1b
    800055ca:	67258593          	addi	a1,a1,1650 # 80020c38 <disk+0x128>
    800055ce:	0001b517          	auipc	a0,0x1b
    800055d2:	55a50513          	addi	a0,a0,1370 # 80020b28 <disk+0x18>
    800055d6:	90bfc0ef          	jal	80001ee0 <sleep>
  for(int i = 0; i < 3; i++){
    800055da:	fa040613          	addi	a2,s0,-96
    800055de:	4901                	li	s2,0
    800055e0:	b77d                	j	8000558e <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800055e2:	fa042503          	lw	a0,-96(s0)
    800055e6:	00451693          	slli	a3,a0,0x4

  if(write)
    800055ea:	0001b797          	auipc	a5,0x1b
    800055ee:	52678793          	addi	a5,a5,1318 # 80020b10 <disk>
    800055f2:	00451713          	slli	a4,a0,0x4
    800055f6:	0a070713          	addi	a4,a4,160
    800055fa:	973e                	add	a4,a4,a5
    800055fc:	01603633          	snez	a2,s6
    80005600:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005602:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005606:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    8000560a:	6398                	ld	a4,0(a5)
    8000560c:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    8000560e:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80005612:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80005614:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005616:	6390                	ld	a2,0(a5)
    80005618:	00d605b3          	add	a1,a2,a3
    8000561c:	4741                	li	a4,16
    8000561e:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005620:	4805                	li	a6,1
    80005622:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    80005626:	fa442703          	lw	a4,-92(s0)
    8000562a:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64) b->data;
    8000562e:	0712                	slli	a4,a4,0x4
    80005630:	963a                	add	a2,a2,a4
    80005632:	05898593          	addi	a1,s3,88
    80005636:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80005638:	0007b883          	ld	a7,0(a5)
    8000563c:	9746                	add	a4,a4,a7
    8000563e:	40000613          	li	a2,1024
    80005642:	c710                	sw	a2,8(a4)
  if(write)
    80005644:	001b3613          	seqz	a2,s6
    80005648:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    8000564c:	01066633          	or	a2,a2,a6
    80005650:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005654:	fa842583          	lw	a1,-88(s0)
    80005658:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    8000565c:	00250613          	addi	a2,a0,2
    80005660:	0612                	slli	a2,a2,0x4
    80005662:	963e                	add	a2,a2,a5
    80005664:	577d                	li	a4,-1
    80005666:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    8000566a:	0592                	slli	a1,a1,0x4
    8000566c:	98ae                	add	a7,a7,a1
    8000566e:	03068713          	addi	a4,a3,48
    80005672:	973e                	add	a4,a4,a5
    80005674:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005678:	6398                	ld	a4,0(a5)
    8000567a:	972e                	add	a4,a4,a1
    8000567c:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005680:	4689                	li	a3,2
    80005682:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005686:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    8000568a:	0109a223          	sw	a6,4(s3)
  disk.info[idx[0]].b = b;
    8000568e:	01363423          	sd	s3,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005692:	6794                	ld	a3,8(a5)
    80005694:	0026d703          	lhu	a4,2(a3)
    80005698:	8b1d                	andi	a4,a4,7
    8000569a:	0706                	slli	a4,a4,0x1
    8000569c:	96ba                	add	a3,a3,a4
    8000569e:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    800056a2:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    800056a6:	6798                	ld	a4,8(a5)
    800056a8:	00275783          	lhu	a5,2(a4)
    800056ac:	2785                	addiw	a5,a5,1
    800056ae:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    800056b2:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    800056b6:	100017b7          	lui	a5,0x10001
    800056ba:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    800056be:	0049a783          	lw	a5,4(s3)
    800056c2:	01079f63          	bne	a5,a6,800056e0 <virtio_disk_rw+0x1ae>
    sleep(b, &disk.vdisk_lock);
    800056c6:	0001b917          	auipc	s2,0x1b
    800056ca:	57290913          	addi	s2,s2,1394 # 80020c38 <disk+0x128>
  while(b->disk == 1) {
    800056ce:	84be                	mv	s1,a5
    sleep(b, &disk.vdisk_lock);
    800056d0:	85ca                	mv	a1,s2
    800056d2:	854e                	mv	a0,s3
    800056d4:	80dfc0ef          	jal	80001ee0 <sleep>
  while(b->disk == 1) {
    800056d8:	0049a783          	lw	a5,4(s3)
    800056dc:	fe978ae3          	beq	a5,s1,800056d0 <virtio_disk_rw+0x19e>
  }

  disk.info[idx[0]].b = 0;
    800056e0:	fa042903          	lw	s2,-96(s0)
    800056e4:	00290713          	addi	a4,s2,2
    800056e8:	0712                	slli	a4,a4,0x4
    800056ea:	0001b797          	auipc	a5,0x1b
    800056ee:	42678793          	addi	a5,a5,1062 # 80020b10 <disk>
    800056f2:	97ba                	add	a5,a5,a4
    800056f4:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    800056f8:	0001b997          	auipc	s3,0x1b
    800056fc:	41898993          	addi	s3,s3,1048 # 80020b10 <disk>
    80005700:	00491713          	slli	a4,s2,0x4
    80005704:	0009b783          	ld	a5,0(s3)
    80005708:	97ba                	add	a5,a5,a4
    8000570a:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    8000570e:	854a                	mv	a0,s2
    80005710:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005714:	befff0ef          	jal	80005302 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80005718:	8885                	andi	s1,s1,1
    8000571a:	f0fd                	bnez	s1,80005700 <virtio_disk_rw+0x1ce>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    8000571c:	0001b517          	auipc	a0,0x1b
    80005720:	51c50513          	addi	a0,a0,1308 # 80020c38 <disk+0x128>
    80005724:	dd0fb0ef          	jal	80000cf4 <release>
}
    80005728:	60e6                	ld	ra,88(sp)
    8000572a:	6446                	ld	s0,80(sp)
    8000572c:	64a6                	ld	s1,72(sp)
    8000572e:	6906                	ld	s2,64(sp)
    80005730:	79e2                	ld	s3,56(sp)
    80005732:	7a42                	ld	s4,48(sp)
    80005734:	7aa2                	ld	s5,40(sp)
    80005736:	7b02                	ld	s6,32(sp)
    80005738:	6be2                	ld	s7,24(sp)
    8000573a:	6c42                	ld	s8,16(sp)
    8000573c:	6125                	addi	sp,sp,96
    8000573e:	8082                	ret

0000000080005740 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005740:	1101                	addi	sp,sp,-32
    80005742:	ec06                	sd	ra,24(sp)
    80005744:	e822                	sd	s0,16(sp)
    80005746:	e426                	sd	s1,8(sp)
    80005748:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    8000574a:	0001b497          	auipc	s1,0x1b
    8000574e:	3c648493          	addi	s1,s1,966 # 80020b10 <disk>
    80005752:	0001b517          	auipc	a0,0x1b
    80005756:	4e650513          	addi	a0,a0,1254 # 80020c38 <disk+0x128>
    8000575a:	d0afb0ef          	jal	80000c64 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    8000575e:	100017b7          	lui	a5,0x10001
    80005762:	53bc                	lw	a5,96(a5)
    80005764:	8b8d                	andi	a5,a5,3
    80005766:	10001737          	lui	a4,0x10001
    8000576a:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    8000576c:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80005770:	689c                	ld	a5,16(s1)
    80005772:	0204d703          	lhu	a4,32(s1)
    80005776:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    8000577a:	04f70663          	beq	a4,a5,800057c6 <virtio_disk_intr+0x86>
    __sync_synchronize();
    8000577e:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005782:	6898                	ld	a4,16(s1)
    80005784:	0204d783          	lhu	a5,32(s1)
    80005788:	8b9d                	andi	a5,a5,7
    8000578a:	078e                	slli	a5,a5,0x3
    8000578c:	97ba                	add	a5,a5,a4
    8000578e:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80005790:	00278713          	addi	a4,a5,2
    80005794:	0712                	slli	a4,a4,0x4
    80005796:	9726                	add	a4,a4,s1
    80005798:	01074703          	lbu	a4,16(a4) # 10001010 <_entry-0x6fffeff0>
    8000579c:	e321                	bnez	a4,800057dc <virtio_disk_intr+0x9c>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    8000579e:	0789                	addi	a5,a5,2
    800057a0:	0792                	slli	a5,a5,0x4
    800057a2:	97a6                	add	a5,a5,s1
    800057a4:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    800057a6:	00052223          	sw	zero,4(a0)
    wakeup(b);
    800057aa:	f82fc0ef          	jal	80001f2c <wakeup>

    disk.used_idx += 1;
    800057ae:	0204d783          	lhu	a5,32(s1)
    800057b2:	2785                	addiw	a5,a5,1
    800057b4:	17c2                	slli	a5,a5,0x30
    800057b6:	93c1                	srli	a5,a5,0x30
    800057b8:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    800057bc:	6898                	ld	a4,16(s1)
    800057be:	00275703          	lhu	a4,2(a4)
    800057c2:	faf71ee3          	bne	a4,a5,8000577e <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    800057c6:	0001b517          	auipc	a0,0x1b
    800057ca:	47250513          	addi	a0,a0,1138 # 80020c38 <disk+0x128>
    800057ce:	d26fb0ef          	jal	80000cf4 <release>
}
    800057d2:	60e2                	ld	ra,24(sp)
    800057d4:	6442                	ld	s0,16(sp)
    800057d6:	64a2                	ld	s1,8(sp)
    800057d8:	6105                	addi	sp,sp,32
    800057da:	8082                	ret
      panic("virtio_disk_intr status");
    800057dc:	00002517          	auipc	a0,0x2
    800057e0:	f7c50513          	addi	a0,a0,-132 # 80007758 <etext+0x758>
    800057e4:	80cfb0ef          	jal	800007f0 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	8282                	jr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
