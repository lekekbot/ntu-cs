
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00008117          	auipc	sp,0x8
    80000004:	98010113          	addi	sp,sp,-1664 # 80007980 <stack0>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	04e000ef          	jal	80000064 <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e406                	sd	ra,8(sp)
    80000020:	e022                	sd	s0,0(sp)
    80000022:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000024:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000028:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002c:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80000030:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000034:	577d                	li	a4,-1
    80000036:	177e                	slli	a4,a4,0x3f
    80000038:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    8000003a:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003e:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000042:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000046:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    8000004a:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    8000004e:	000f4737          	lui	a4,0xf4
    80000052:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000056:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000058:	14d79073          	csrw	stimecmp,a5
}
    8000005c:	60a2                	ld	ra,8(sp)
    8000005e:	6402                	ld	s0,0(sp)
    80000060:	0141                	addi	sp,sp,16
    80000062:	8082                	ret

0000000080000064 <start>:
{
    80000064:	1141                	addi	sp,sp,-16
    80000066:	e406                	sd	ra,8(sp)
    80000068:	e022                	sd	s0,0(sp)
    8000006a:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    8000006c:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000070:	7779                	lui	a4,0xffffe
    80000072:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffdd6df>
    80000076:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000078:	6705                	lui	a4,0x1
    8000007a:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000007e:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80000080:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80000084:	00001797          	auipc	a5,0x1
    80000088:	e5878793          	addi	a5,a5,-424 # 80000edc <main>
    8000008c:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80000090:	4781                	li	a5,0
    80000092:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000096:	67c1                	lui	a5,0x10
    80000098:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000009a:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    8000009e:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    800000a2:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    800000a6:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r" (x));
    800000aa:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000ae:	57fd                	li	a5,-1
    800000b0:	83a9                	srli	a5,a5,0xa
    800000b2:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b6:	47bd                	li	a5,15
    800000b8:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000bc:	f61ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000c0:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c4:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c6:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c8:	30200073          	mret
}
    800000cc:	60a2                	ld	ra,8(sp)
    800000ce:	6402                	ld	s0,0(sp)
    800000d0:	0141                	addi	sp,sp,16
    800000d2:	8082                	ret

00000000800000d4 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d4:	711d                	addi	sp,sp,-96
    800000d6:	ec86                	sd	ra,88(sp)
    800000d8:	e8a2                	sd	s0,80(sp)
    800000da:	e0ca                	sd	s2,64(sp)
    800000dc:	1080                	addi	s0,sp,96
  int i;

  for(i = 0; i < n; i++){
    800000de:	04c05763          	blez	a2,8000012c <consolewrite+0x58>
    800000e2:	e4a6                	sd	s1,72(sp)
    800000e4:	fc4e                	sd	s3,56(sp)
    800000e6:	f852                	sd	s4,48(sp)
    800000e8:	f456                	sd	s5,40(sp)
    800000ea:	f05a                	sd	s6,32(sp)
    800000ec:	ec5e                	sd	s7,24(sp)
    800000ee:	8a2a                	mv	s4,a0
    800000f0:	84ae                	mv	s1,a1
    800000f2:	89b2                	mv	s3,a2
    800000f4:	4901                	li	s2,0
    char c;
    if(either_copyin(&c, user_src, src+i, 1) == -1)
    800000f6:	faf40b93          	addi	s7,s0,-81
    800000fa:	4b05                	li	s6,1
    800000fc:	5afd                	li	s5,-1
    800000fe:	86da                	mv	a3,s6
    80000100:	8626                	mv	a2,s1
    80000102:	85d2                	mv	a1,s4
    80000104:	855e                	mv	a0,s7
    80000106:	188020ef          	jal	8000228e <either_copyin>
    8000010a:	03550363          	beq	a0,s5,80000130 <consolewrite+0x5c>
      break;
    uartputc(c);
    8000010e:	faf44503          	lbu	a0,-81(s0)
    80000112:	06b000ef          	jal	8000097c <uartputc>
  for(i = 0; i < n; i++){
    80000116:	2905                	addiw	s2,s2,1
    80000118:	0485                	addi	s1,s1,1
    8000011a:	ff2992e3          	bne	s3,s2,800000fe <consolewrite+0x2a>
    8000011e:	64a6                	ld	s1,72(sp)
    80000120:	79e2                	ld	s3,56(sp)
    80000122:	7a42                	ld	s4,48(sp)
    80000124:	7aa2                	ld	s5,40(sp)
    80000126:	7b02                	ld	s6,32(sp)
    80000128:	6be2                	ld	s7,24(sp)
    8000012a:	a809                	j	8000013c <consolewrite+0x68>
    8000012c:	4901                	li	s2,0
    8000012e:	a039                	j	8000013c <consolewrite+0x68>
    80000130:	64a6                	ld	s1,72(sp)
    80000132:	79e2                	ld	s3,56(sp)
    80000134:	7a42                	ld	s4,48(sp)
    80000136:	7aa2                	ld	s5,40(sp)
    80000138:	7b02                	ld	s6,32(sp)
    8000013a:	6be2                	ld	s7,24(sp)
  }

  return i;
}
    8000013c:	854a                	mv	a0,s2
    8000013e:	60e6                	ld	ra,88(sp)
    80000140:	6446                	ld	s0,80(sp)
    80000142:	6906                	ld	s2,64(sp)
    80000144:	6125                	addi	sp,sp,96
    80000146:	8082                	ret

0000000080000148 <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000148:	711d                	addi	sp,sp,-96
    8000014a:	ec86                	sd	ra,88(sp)
    8000014c:	e8a2                	sd	s0,80(sp)
    8000014e:	e4a6                	sd	s1,72(sp)
    80000150:	e0ca                	sd	s2,64(sp)
    80000152:	fc4e                	sd	s3,56(sp)
    80000154:	f852                	sd	s4,48(sp)
    80000156:	f05a                	sd	s6,32(sp)
    80000158:	ec5e                	sd	s7,24(sp)
    8000015a:	1080                	addi	s0,sp,96
    8000015c:	8b2a                	mv	s6,a0
    8000015e:	8a2e                	mv	s4,a1
    80000160:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000162:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80000164:	00010517          	auipc	a0,0x10
    80000168:	81c50513          	addi	a0,a0,-2020 # 8000f980 <cons>
    8000016c:	2f9000ef          	jal	80000c64 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    80000170:	00010497          	auipc	s1,0x10
    80000174:	81048493          	addi	s1,s1,-2032 # 8000f980 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    80000178:	00010917          	auipc	s2,0x10
    8000017c:	8a090913          	addi	s2,s2,-1888 # 8000fa18 <cons+0x98>
  while(n > 0){
    80000180:	0b305b63          	blez	s3,80000236 <consoleread+0xee>
    while(cons.r == cons.w){
    80000184:	0984a783          	lw	a5,152(s1)
    80000188:	09c4a703          	lw	a4,156(s1)
    8000018c:	0af71063          	bne	a4,a5,8000022c <consoleread+0xe4>
      if(killed(myproc())){
    80000190:	7a0010ef          	jal	80001930 <myproc>
    80000194:	795010ef          	jal	80002128 <killed>
    80000198:	e12d                	bnez	a0,800001fa <consoleread+0xb2>
      sleep(&cons.r, &cons.lock);
    8000019a:	85a6                	mv	a1,s1
    8000019c:	854a                	mv	a0,s2
    8000019e:	54f010ef          	jal	80001eec <sleep>
    while(cons.r == cons.w){
    800001a2:	0984a783          	lw	a5,152(s1)
    800001a6:	09c4a703          	lw	a4,156(s1)
    800001aa:	fef703e3          	beq	a4,a5,80000190 <consoleread+0x48>
    800001ae:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001b0:	0000f717          	auipc	a4,0xf
    800001b4:	7d070713          	addi	a4,a4,2000 # 8000f980 <cons>
    800001b8:	0017869b          	addiw	a3,a5,1
    800001bc:	08d72c23          	sw	a3,152(a4)
    800001c0:	07f7f693          	andi	a3,a5,127
    800001c4:	9736                	add	a4,a4,a3
    800001c6:	01874703          	lbu	a4,24(a4)
    800001ca:	00070a9b          	sext.w	s5,a4

    if(c == C('D')){  // end-of-file
    800001ce:	4691                	li	a3,4
    800001d0:	04da8663          	beq	s5,a3,8000021c <consoleread+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    800001d4:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    800001d8:	4685                	li	a3,1
    800001da:	faf40613          	addi	a2,s0,-81
    800001de:	85d2                	mv	a1,s4
    800001e0:	855a                	mv	a0,s6
    800001e2:	062020ef          	jal	80002244 <either_copyout>
    800001e6:	57fd                	li	a5,-1
    800001e8:	04f50663          	beq	a0,a5,80000234 <consoleread+0xec>
      break;

    dst++;
    800001ec:	0a05                	addi	s4,s4,1
    --n;
    800001ee:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    800001f0:	47a9                	li	a5,10
    800001f2:	04fa8b63          	beq	s5,a5,80000248 <consoleread+0x100>
    800001f6:	7aa2                	ld	s5,40(sp)
    800001f8:	b761                	j	80000180 <consoleread+0x38>
        release(&cons.lock);
    800001fa:	0000f517          	auipc	a0,0xf
    800001fe:	78650513          	addi	a0,a0,1926 # 8000f980 <cons>
    80000202:	2f3000ef          	jal	80000cf4 <release>
        return -1;
    80000206:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000208:	60e6                	ld	ra,88(sp)
    8000020a:	6446                	ld	s0,80(sp)
    8000020c:	64a6                	ld	s1,72(sp)
    8000020e:	6906                	ld	s2,64(sp)
    80000210:	79e2                	ld	s3,56(sp)
    80000212:	7a42                	ld	s4,48(sp)
    80000214:	7b02                	ld	s6,32(sp)
    80000216:	6be2                	ld	s7,24(sp)
    80000218:	6125                	addi	sp,sp,96
    8000021a:	8082                	ret
      if(n < target){
    8000021c:	0179fa63          	bgeu	s3,s7,80000230 <consoleread+0xe8>
        cons.r--;
    80000220:	0000f717          	auipc	a4,0xf
    80000224:	7ef72c23          	sw	a5,2040(a4) # 8000fa18 <cons+0x98>
    80000228:	7aa2                	ld	s5,40(sp)
    8000022a:	a031                	j	80000236 <consoleread+0xee>
    8000022c:	f456                	sd	s5,40(sp)
    8000022e:	b749                	j	800001b0 <consoleread+0x68>
    80000230:	7aa2                	ld	s5,40(sp)
    80000232:	a011                	j	80000236 <consoleread+0xee>
    80000234:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80000236:	0000f517          	auipc	a0,0xf
    8000023a:	74a50513          	addi	a0,a0,1866 # 8000f980 <cons>
    8000023e:	2b7000ef          	jal	80000cf4 <release>
  return target - n;
    80000242:	413b853b          	subw	a0,s7,s3
    80000246:	b7c9                	j	80000208 <consoleread+0xc0>
    80000248:	7aa2                	ld	s5,40(sp)
    8000024a:	b7f5                	j	80000236 <consoleread+0xee>

000000008000024c <consputc>:
{
    8000024c:	1141                	addi	sp,sp,-16
    8000024e:	e406                	sd	ra,8(sp)
    80000250:	e022                	sd	s0,0(sp)
    80000252:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000254:	10000793          	li	a5,256
    80000258:	00f50863          	beq	a0,a5,80000268 <consputc+0x1c>
    uartputc_sync(c);
    8000025c:	652000ef          	jal	800008ae <uartputc_sync>
}
    80000260:	60a2                	ld	ra,8(sp)
    80000262:	6402                	ld	s0,0(sp)
    80000264:	0141                	addi	sp,sp,16
    80000266:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80000268:	4521                	li	a0,8
    8000026a:	644000ef          	jal	800008ae <uartputc_sync>
    8000026e:	02000513          	li	a0,32
    80000272:	63c000ef          	jal	800008ae <uartputc_sync>
    80000276:	4521                	li	a0,8
    80000278:	636000ef          	jal	800008ae <uartputc_sync>
    8000027c:	b7d5                	j	80000260 <consputc+0x14>

000000008000027e <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    8000027e:	1101                	addi	sp,sp,-32
    80000280:	ec06                	sd	ra,24(sp)
    80000282:	e822                	sd	s0,16(sp)
    80000284:	e426                	sd	s1,8(sp)
    80000286:	1000                	addi	s0,sp,32
    80000288:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    8000028a:	0000f517          	auipc	a0,0xf
    8000028e:	6f650513          	addi	a0,a0,1782 # 8000f980 <cons>
    80000292:	1d3000ef          	jal	80000c64 <acquire>

  switch(c){
    80000296:	47d5                	li	a5,21
    80000298:	0af48163          	beq	s1,a5,8000033a <consoleintr+0xbc>
    8000029c:	0297c563          	blt	a5,s1,800002c6 <consoleintr+0x48>
    800002a0:	47a1                	li	a5,8
    800002a2:	0ef48663          	beq	s1,a5,8000038e <consoleintr+0x110>
    800002a6:	47c1                	li	a5,16
    800002a8:	10f49763          	bne	s1,a5,800003b6 <consoleintr+0x138>
  case C('P'):  // Print process list.
    procdump();
    800002ac:	02c020ef          	jal	800022d8 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002b0:	0000f517          	auipc	a0,0xf
    800002b4:	6d050513          	addi	a0,a0,1744 # 8000f980 <cons>
    800002b8:	23d000ef          	jal	80000cf4 <release>
}
    800002bc:	60e2                	ld	ra,24(sp)
    800002be:	6442                	ld	s0,16(sp)
    800002c0:	64a2                	ld	s1,8(sp)
    800002c2:	6105                	addi	sp,sp,32
    800002c4:	8082                	ret
  switch(c){
    800002c6:	07f00793          	li	a5,127
    800002ca:	0cf48263          	beq	s1,a5,8000038e <consoleintr+0x110>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002ce:	0000f717          	auipc	a4,0xf
    800002d2:	6b270713          	addi	a4,a4,1714 # 8000f980 <cons>
    800002d6:	0a072783          	lw	a5,160(a4)
    800002da:	09872703          	lw	a4,152(a4)
    800002de:	9f99                	subw	a5,a5,a4
    800002e0:	07f00713          	li	a4,127
    800002e4:	fcf766e3          	bltu	a4,a5,800002b0 <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    800002e8:	47b5                	li	a5,13
    800002ea:	0cf48963          	beq	s1,a5,800003bc <consoleintr+0x13e>
      consputc(c);
    800002ee:	8526                	mv	a0,s1
    800002f0:	f5dff0ef          	jal	8000024c <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800002f4:	0000f717          	auipc	a4,0xf
    800002f8:	68c70713          	addi	a4,a4,1676 # 8000f980 <cons>
    800002fc:	0a072683          	lw	a3,160(a4)
    80000300:	0016879b          	addiw	a5,a3,1
    80000304:	863e                	mv	a2,a5
    80000306:	0af72023          	sw	a5,160(a4)
    8000030a:	07f6f693          	andi	a3,a3,127
    8000030e:	9736                	add	a4,a4,a3
    80000310:	00970c23          	sb	s1,24(a4)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80000314:	ff648713          	addi	a4,s1,-10
    80000318:	00173713          	seqz	a4,a4
    8000031c:	14f1                	addi	s1,s1,-4
    8000031e:	0014b493          	seqz	s1,s1
    80000322:	8f45                	or	a4,a4,s1
    80000324:	e361                	bnez	a4,800003e4 <consoleintr+0x166>
    80000326:	0000f717          	auipc	a4,0xf
    8000032a:	6f272703          	lw	a4,1778(a4) # 8000fa18 <cons+0x98>
    8000032e:	9f99                	subw	a5,a5,a4
    80000330:	08000713          	li	a4,128
    80000334:	f6e79ee3          	bne	a5,a4,800002b0 <consoleintr+0x32>
    80000338:	a075                	j	800003e4 <consoleintr+0x166>
    8000033a:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    8000033c:	0000f717          	auipc	a4,0xf
    80000340:	64470713          	addi	a4,a4,1604 # 8000f980 <cons>
    80000344:	0a072783          	lw	a5,160(a4)
    80000348:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    8000034c:	0000f497          	auipc	s1,0xf
    80000350:	63448493          	addi	s1,s1,1588 # 8000f980 <cons>
    while(cons.e != cons.w &&
    80000354:	4929                	li	s2,10
    80000356:	02f70863          	beq	a4,a5,80000386 <consoleintr+0x108>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    8000035a:	37fd                	addiw	a5,a5,-1
    8000035c:	07f7f713          	andi	a4,a5,127
    80000360:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    80000362:	01874703          	lbu	a4,24(a4)
    80000366:	03270263          	beq	a4,s2,8000038a <consoleintr+0x10c>
      cons.e--;
    8000036a:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    8000036e:	10000513          	li	a0,256
    80000372:	edbff0ef          	jal	8000024c <consputc>
    while(cons.e != cons.w &&
    80000376:	0a04a783          	lw	a5,160(s1)
    8000037a:	09c4a703          	lw	a4,156(s1)
    8000037e:	fcf71ee3          	bne	a4,a5,8000035a <consoleintr+0xdc>
    80000382:	6902                	ld	s2,0(sp)
    80000384:	b735                	j	800002b0 <consoleintr+0x32>
    80000386:	6902                	ld	s2,0(sp)
    80000388:	b725                	j	800002b0 <consoleintr+0x32>
    8000038a:	6902                	ld	s2,0(sp)
    8000038c:	b715                	j	800002b0 <consoleintr+0x32>
    if(cons.e != cons.w){
    8000038e:	0000f717          	auipc	a4,0xf
    80000392:	5f270713          	addi	a4,a4,1522 # 8000f980 <cons>
    80000396:	0a072783          	lw	a5,160(a4)
    8000039a:	09c72703          	lw	a4,156(a4)
    8000039e:	f0f709e3          	beq	a4,a5,800002b0 <consoleintr+0x32>
      cons.e--;
    800003a2:	37fd                	addiw	a5,a5,-1
    800003a4:	0000f717          	auipc	a4,0xf
    800003a8:	66f72e23          	sw	a5,1660(a4) # 8000fa20 <cons+0xa0>
      consputc(BACKSPACE);
    800003ac:	10000513          	li	a0,256
    800003b0:	e9dff0ef          	jal	8000024c <consputc>
    800003b4:	bdf5                	j	800002b0 <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800003b6:	ee048de3          	beqz	s1,800002b0 <consoleintr+0x32>
    800003ba:	bf11                	j	800002ce <consoleintr+0x50>
      consputc(c);
    800003bc:	4529                	li	a0,10
    800003be:	e8fff0ef          	jal	8000024c <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003c2:	0000f797          	auipc	a5,0xf
    800003c6:	5be78793          	addi	a5,a5,1470 # 8000f980 <cons>
    800003ca:	0a07a703          	lw	a4,160(a5)
    800003ce:	0017069b          	addiw	a3,a4,1
    800003d2:	8636                	mv	a2,a3
    800003d4:	0ad7a023          	sw	a3,160(a5)
    800003d8:	07f77713          	andi	a4,a4,127
    800003dc:	97ba                	add	a5,a5,a4
    800003de:	4729                	li	a4,10
    800003e0:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    800003e4:	0000f797          	auipc	a5,0xf
    800003e8:	62c7ac23          	sw	a2,1592(a5) # 8000fa1c <cons+0x9c>
        wakeup(&cons.r);
    800003ec:	0000f517          	auipc	a0,0xf
    800003f0:	62c50513          	addi	a0,a0,1580 # 8000fa18 <cons+0x98>
    800003f4:	345010ef          	jal	80001f38 <wakeup>
    800003f8:	bd65                	j	800002b0 <consoleintr+0x32>

00000000800003fa <consoleinit>:

void
consoleinit(void)
{
    800003fa:	1141                	addi	sp,sp,-16
    800003fc:	e406                	sd	ra,8(sp)
    800003fe:	e022                	sd	s0,0(sp)
    80000400:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000402:	00007597          	auipc	a1,0x7
    80000406:	bfe58593          	addi	a1,a1,-1026 # 80007000 <etext>
    8000040a:	0000f517          	auipc	a0,0xf
    8000040e:	57650513          	addi	a0,a0,1398 # 8000f980 <cons>
    80000412:	7c8000ef          	jal	80000bda <initlock>

  uartinit();
    80000416:	442000ef          	jal	80000858 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    8000041a:	0001f797          	auipc	a5,0x1f
    8000041e:	6fe78793          	addi	a5,a5,1790 # 8001fb18 <devsw>
    80000422:	00000717          	auipc	a4,0x0
    80000426:	d2670713          	addi	a4,a4,-730 # 80000148 <consoleread>
    8000042a:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    8000042c:	00000717          	auipc	a4,0x0
    80000430:	ca870713          	addi	a4,a4,-856 # 800000d4 <consolewrite>
    80000434:	ef98                	sd	a4,24(a5)
}
    80000436:	60a2                	ld	ra,8(sp)
    80000438:	6402                	ld	s0,0(sp)
    8000043a:	0141                	addi	sp,sp,16
    8000043c:	8082                	ret

000000008000043e <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    8000043e:	7139                	addi	sp,sp,-64
    80000440:	fc06                	sd	ra,56(sp)
    80000442:	f822                	sd	s0,48(sp)
    80000444:	f04a                	sd	s2,32(sp)
    80000446:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    80000448:	c219                	beqz	a2,8000044e <printint+0x10>
    8000044a:	08054063          	bltz	a0,800004ca <printint+0x8c>
    x = -xx;
  else
    x = xx;
    8000044e:	4301                	li	t1,0

  i = 0;
    80000450:	fc840913          	addi	s2,s0,-56
    x = xx;
    80000454:	86ca                	mv	a3,s2
  i = 0;
    80000456:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    80000458:	00007817          	auipc	a6,0x7
    8000045c:	33880813          	addi	a6,a6,824 # 80007790 <digits>
    80000460:	88ba                	mv	a7,a4
    80000462:	0017061b          	addiw	a2,a4,1
    80000466:	8732                	mv	a4,a2
    80000468:	02b577b3          	remu	a5,a0,a1
    8000046c:	97c2                	add	a5,a5,a6
    8000046e:	0007c783          	lbu	a5,0(a5)
    80000472:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    80000476:	87aa                	mv	a5,a0
    80000478:	02b55533          	divu	a0,a0,a1
    8000047c:	0685                	addi	a3,a3,1
    8000047e:	feb7f1e3          	bgeu	a5,a1,80000460 <printint+0x22>

  if(sign)
    80000482:	00030b63          	beqz	t1,80000498 <printint+0x5a>
    buf[i++] = '-';
    80000486:	fe040793          	addi	a5,s0,-32
    8000048a:	963e                	add	a2,a2,a5
    8000048c:	02d00793          	li	a5,45
    80000490:	fef60423          	sb	a5,-24(a2)
    80000494:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    80000498:	02e05463          	blez	a4,800004c0 <printint+0x82>
    8000049c:	f426                	sd	s1,40(sp)
    8000049e:	377d                	addiw	a4,a4,-1
    800004a0:	00e904b3          	add	s1,s2,a4
    800004a4:	197d                	addi	s2,s2,-1
    800004a6:	993a                	add	s2,s2,a4
    800004a8:	1702                	slli	a4,a4,0x20
    800004aa:	9301                	srli	a4,a4,0x20
    800004ac:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    800004b0:	0004c503          	lbu	a0,0(s1)
    800004b4:	d99ff0ef          	jal	8000024c <consputc>
  while(--i >= 0)
    800004b8:	14fd                	addi	s1,s1,-1
    800004ba:	ff249be3          	bne	s1,s2,800004b0 <printint+0x72>
    800004be:	74a2                	ld	s1,40(sp)
}
    800004c0:	70e2                	ld	ra,56(sp)
    800004c2:	7442                	ld	s0,48(sp)
    800004c4:	7902                	ld	s2,32(sp)
    800004c6:	6121                	addi	sp,sp,64
    800004c8:	8082                	ret
    x = -xx;
    800004ca:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800004ce:	4305                	li	t1,1
    x = -xx;
    800004d0:	b741                	j	80000450 <printint+0x12>

00000000800004d2 <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004d2:	7131                	addi	sp,sp,-192
    800004d4:	fc86                	sd	ra,120(sp)
    800004d6:	f8a2                	sd	s0,112(sp)
    800004d8:	f4a6                	sd	s1,104(sp)
    800004da:	ec6e                	sd	s11,24(sp)
    800004dc:	0100                	addi	s0,sp,128
    800004de:	84aa                	mv	s1,a0
    800004e0:	e40c                	sd	a1,8(s0)
    800004e2:	e810                	sd	a2,16(s0)
    800004e4:	ec14                	sd	a3,24(s0)
    800004e6:	f018                	sd	a4,32(s0)
    800004e8:	f41c                	sd	a5,40(s0)
    800004ea:	03043823          	sd	a6,48(s0)
    800004ee:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2, locking;
  char *s;

  locking = pr.locking;
    800004f2:	0000fd97          	auipc	s11,0xf
    800004f6:	54edad83          	lw	s11,1358(s11) # 8000fa40 <pr+0x18>
  if(locking)
    800004fa:	020d9d63          	bnez	s11,80000534 <printf+0x62>
    acquire(&pr.lock);

  va_start(ap, fmt);
    800004fe:	00840793          	addi	a5,s0,8
    80000502:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000506:	00054503          	lbu	a0,0(a0)
    8000050a:	20050c63          	beqz	a0,80000722 <printf+0x250>
    8000050e:	f0ca                	sd	s2,96(sp)
    80000510:	ecce                	sd	s3,88(sp)
    80000512:	e8d2                	sd	s4,80(sp)
    80000514:	e4d6                	sd	s5,72(sp)
    80000516:	e0da                	sd	s6,64(sp)
    80000518:	fc5e                	sd	s7,56(sp)
    8000051a:	f862                	sd	s8,48(sp)
    8000051c:	f06a                	sd	s10,32(sp)
    8000051e:	4a01                	li	s4,0
    if(cx != '%'){
    80000520:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    80000524:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    80000528:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 10, 0);
    8000052c:	4b29                	li	s6,10
    if(c0 == 'd'){
    8000052e:	06400b93          	li	s7,100
    80000532:	a80d                	j	80000564 <printf+0x92>
    acquire(&pr.lock);
    80000534:	0000f517          	auipc	a0,0xf
    80000538:	4f450513          	addi	a0,a0,1268 # 8000fa28 <pr>
    8000053c:	728000ef          	jal	80000c64 <acquire>
  va_start(ap, fmt);
    80000540:	00840793          	addi	a5,s0,8
    80000544:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000548:	0004c503          	lbu	a0,0(s1)
    8000054c:	f169                	bnez	a0,8000050e <printf+0x3c>
    8000054e:	aacd                	j	80000740 <printf+0x26e>
      consputc(cx);
    80000550:	cfdff0ef          	jal	8000024c <consputc>
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000554:	001a079b          	addiw	a5,s4,1
    80000558:	8a3e                	mv	s4,a5
    8000055a:	97a6                	add	a5,a5,s1
    8000055c:	0007c503          	lbu	a0,0(a5)
    80000560:	1a050763          	beqz	a0,8000070e <printf+0x23c>
    if(cx != '%'){
    80000564:	ff3516e3          	bne	a0,s3,80000550 <printf+0x7e>
    i++;
    80000568:	001a091b          	addiw	s2,s4,1
    c0 = fmt[i+0] & 0xff;
    8000056c:	012487b3          	add	a5,s1,s2
    80000570:	0007ca83          	lbu	s5,0(a5)
    if(c0) c1 = fmt[i+1] & 0xff;
    80000574:	1e0a8663          	beqz	s5,80000760 <printf+0x28e>
    80000578:	0017c703          	lbu	a4,1(a5)
    if(c1) c2 = fmt[i+2] & 0xff;
    8000057c:	1c070963          	beqz	a4,8000074e <printf+0x27c>
    if(c0 == 'd'){
    80000580:	037a8963          	beq	s5,s7,800005b2 <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80000584:	f94a8793          	addi	a5,s5,-108
    80000588:	0017b793          	seqz	a5,a5
    8000058c:	f9c70693          	addi	a3,a4,-100
    80000590:	0016b693          	seqz	a3,a3
    80000594:	8efd                	and	a3,a3,a5
    80000596:	ca9d                	beqz	a3,800005cc <printf+0xfa>
      printint(va_arg(ap, uint64), 10, 1);
    80000598:	f8843783          	ld	a5,-120(s0)
    8000059c:	00878713          	addi	a4,a5,8
    800005a0:	f8e43423          	sd	a4,-120(s0)
    800005a4:	4605                	li	a2,1
    800005a6:	85da                	mv	a1,s6
    800005a8:	6388                	ld	a0,0(a5)
    800005aa:	e95ff0ef          	jal	8000043e <printint>
      i += 1;
    800005ae:	2a09                	addiw	s4,s4,2
    800005b0:	b755                	j	80000554 <printf+0x82>
      printint(va_arg(ap, int), 10, 1);
    800005b2:	f8843783          	ld	a5,-120(s0)
    800005b6:	00878713          	addi	a4,a5,8
    800005ba:	f8e43423          	sd	a4,-120(s0)
    800005be:	4605                	li	a2,1
    800005c0:	85da                	mv	a1,s6
    800005c2:	4388                	lw	a0,0(a5)
    800005c4:	e7bff0ef          	jal	8000043e <printint>
    i++;
    800005c8:	8a4a                	mv	s4,s2
    800005ca:	b769                	j	80000554 <printf+0x82>
    if(c1) c2 = fmt[i+2] & 0xff;
    800005cc:	012486b3          	add	a3,s1,s2
    800005d0:	863a                	mv	a2,a4
    800005d2:	0026c703          	lbu	a4,2(a3)
    800005d6:	aa59                	j	8000076c <printf+0x29a>
      printint(va_arg(ap, uint64), 10, 1);
    800005d8:	f8843783          	ld	a5,-120(s0)
    800005dc:	00878713          	addi	a4,a5,8
    800005e0:	f8e43423          	sd	a4,-120(s0)
    800005e4:	4605                	li	a2,1
    800005e6:	45a9                	li	a1,10
    800005e8:	6388                	ld	a0,0(a5)
    800005ea:	e55ff0ef          	jal	8000043e <printint>
      i += 2;
    800005ee:	2a0d                	addiw	s4,s4,3
    800005f0:	b795                	j	80000554 <printf+0x82>
      printint(va_arg(ap, int), 10, 0);
    800005f2:	f8843783          	ld	a5,-120(s0)
    800005f6:	00878713          	addi	a4,a5,8
    800005fa:	f8e43423          	sd	a4,-120(s0)
    800005fe:	4601                	li	a2,0
    80000600:	85da                	mv	a1,s6
    80000602:	4388                	lw	a0,0(a5)
    80000604:	e3bff0ef          	jal	8000043e <printint>
    80000608:	b7c1                	j	800005c8 <printf+0xf6>
      printint(va_arg(ap, uint64), 10, 0);
    8000060a:	f8843783          	ld	a5,-120(s0)
    8000060e:	00878713          	addi	a4,a5,8
    80000612:	f8e43423          	sd	a4,-120(s0)
    80000616:	4601                	li	a2,0
    80000618:	85da                	mv	a1,s6
    8000061a:	6388                	ld	a0,0(a5)
    8000061c:	e23ff0ef          	jal	8000043e <printint>
      i += 1;
    80000620:	2a09                	addiw	s4,s4,2
    80000622:	bf0d                	j	80000554 <printf+0x82>
      printint(va_arg(ap, uint64), 10, 0);
    80000624:	f8843783          	ld	a5,-120(s0)
    80000628:	00878713          	addi	a4,a5,8
    8000062c:	f8e43423          	sd	a4,-120(s0)
    80000630:	4601                	li	a2,0
    80000632:	45a9                	li	a1,10
    80000634:	6388                	ld	a0,0(a5)
    80000636:	e09ff0ef          	jal	8000043e <printint>
      i += 2;
    8000063a:	2a0d                	addiw	s4,s4,3
    8000063c:	bf21                	j	80000554 <printf+0x82>
      printint(va_arg(ap, int), 16, 0);
    8000063e:	f8843783          	ld	a5,-120(s0)
    80000642:	00878713          	addi	a4,a5,8
    80000646:	f8e43423          	sd	a4,-120(s0)
    8000064a:	4601                	li	a2,0
    8000064c:	45c1                	li	a1,16
    8000064e:	4388                	lw	a0,0(a5)
    80000650:	defff0ef          	jal	8000043e <printint>
    80000654:	bf95                	j	800005c8 <printf+0xf6>
    } else if(c0 == 'l' && c1 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    80000656:	f8843783          	ld	a5,-120(s0)
    8000065a:	00878713          	addi	a4,a5,8
    8000065e:	f8e43423          	sd	a4,-120(s0)
    80000662:	4601                	li	a2,0
    80000664:	45c1                	li	a1,16
    80000666:	6388                	ld	a0,0(a5)
    80000668:	dd7ff0ef          	jal	8000043e <printint>
      i += 1;
    8000066c:	2a09                	addiw	s4,s4,2
    8000066e:	b5dd                	j	80000554 <printf+0x82>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
    80000670:	f8843783          	ld	a5,-120(s0)
    80000674:	00878713          	addi	a4,a5,8
    80000678:	f8e43423          	sd	a4,-120(s0)
    8000067c:	45c1                	li	a1,16
    8000067e:	6388                	ld	a0,0(a5)
    80000680:	dbfff0ef          	jal	8000043e <printint>
      i += 2;
    80000684:	2a0d                	addiw	s4,s4,3
    80000686:	b5f9                	j	80000554 <printf+0x82>
    80000688:	f466                	sd	s9,40(sp)
    } else if(c0 == 'p'){
      printptr(va_arg(ap, uint64));
    8000068a:	f8843783          	ld	a5,-120(s0)
    8000068e:	00878713          	addi	a4,a5,8
    80000692:	f8e43423          	sd	a4,-120(s0)
    80000696:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    8000069a:	03000513          	li	a0,48
    8000069e:	bafff0ef          	jal	8000024c <consputc>
  consputc('x');
    800006a2:	07800513          	li	a0,120
    800006a6:	ba7ff0ef          	jal	8000024c <consputc>
    800006aa:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006ac:	00007c97          	auipc	s9,0x7
    800006b0:	0e4c8c93          	addi	s9,s9,228 # 80007790 <digits>
    800006b4:	03cad793          	srli	a5,s5,0x3c
    800006b8:	97e6                	add	a5,a5,s9
    800006ba:	0007c503          	lbu	a0,0(a5)
    800006be:	b8fff0ef          	jal	8000024c <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006c2:	0a92                	slli	s5,s5,0x4
    800006c4:	3a7d                	addiw	s4,s4,-1
    800006c6:	fe0a17e3          	bnez	s4,800006b4 <printf+0x1e2>
    800006ca:	7ca2                	ld	s9,40(sp)
    800006cc:	bdf5                	j	800005c8 <printf+0xf6>
    } else if(c0 == 's'){
      if((s = va_arg(ap, char*)) == 0)
    800006ce:	f8843783          	ld	a5,-120(s0)
    800006d2:	00878713          	addi	a4,a5,8
    800006d6:	f8e43423          	sd	a4,-120(s0)
    800006da:	0007ba03          	ld	s4,0(a5)
    800006de:	000a0d63          	beqz	s4,800006f8 <printf+0x226>
        s = "(null)";
      for(; *s; s++)
    800006e2:	000a4503          	lbu	a0,0(s4)
    800006e6:	ee0501e3          	beqz	a0,800005c8 <printf+0xf6>
        consputc(*s);
    800006ea:	b63ff0ef          	jal	8000024c <consputc>
      for(; *s; s++)
    800006ee:	0a05                	addi	s4,s4,1
    800006f0:	000a4503          	lbu	a0,0(s4)
    800006f4:	f97d                	bnez	a0,800006ea <printf+0x218>
    800006f6:	bdc9                	j	800005c8 <printf+0xf6>
        s = "(null)";
    800006f8:	00007a17          	auipc	s4,0x7
    800006fc:	910a0a13          	addi	s4,s4,-1776 # 80007008 <etext+0x8>
      for(; *s; s++)
    80000700:	02800513          	li	a0,40
    80000704:	b7dd                	j	800006ea <printf+0x218>
    } else if(c0 == '%'){
      consputc('%');
    80000706:	8556                	mv	a0,s5
    80000708:	b45ff0ef          	jal	8000024c <consputc>
    8000070c:	bd75                	j	800005c8 <printf+0xf6>
    }
#endif
  }
  va_end(ap);

  if(locking)
    8000070e:	020d9163          	bnez	s11,80000730 <printf+0x25e>
    80000712:	7906                	ld	s2,96(sp)
    80000714:	69e6                	ld	s3,88(sp)
    80000716:	6a46                	ld	s4,80(sp)
    80000718:	6aa6                	ld	s5,72(sp)
    8000071a:	6b06                	ld	s6,64(sp)
    8000071c:	7be2                	ld	s7,56(sp)
    8000071e:	7c42                	ld	s8,48(sp)
    80000720:	7d02                	ld	s10,32(sp)
    release(&pr.lock);

  return 0;
}
    80000722:	4501                	li	a0,0
    80000724:	70e6                	ld	ra,120(sp)
    80000726:	7446                	ld	s0,112(sp)
    80000728:	74a6                	ld	s1,104(sp)
    8000072a:	6de2                	ld	s11,24(sp)
    8000072c:	6129                	addi	sp,sp,192
    8000072e:	8082                	ret
    80000730:	7906                	ld	s2,96(sp)
    80000732:	69e6                	ld	s3,88(sp)
    80000734:	6a46                	ld	s4,80(sp)
    80000736:	6aa6                	ld	s5,72(sp)
    80000738:	6b06                	ld	s6,64(sp)
    8000073a:	7be2                	ld	s7,56(sp)
    8000073c:	7c42                	ld	s8,48(sp)
    8000073e:	7d02                	ld	s10,32(sp)
    release(&pr.lock);
    80000740:	0000f517          	auipc	a0,0xf
    80000744:	2e850513          	addi	a0,a0,744 # 8000fa28 <pr>
    80000748:	5ac000ef          	jal	80000cf4 <release>
    8000074c:	bfd9                	j	80000722 <printf+0x250>
    if(c0 == 'd'){
    8000074e:	e77a82e3          	beq	s5,s7,800005b2 <printf+0xe0>
    } else if(c0 == 'l' && c1 == 'd'){
    80000752:	f94a8793          	addi	a5,s5,-108
    80000756:	0017b793          	seqz	a5,a5
    8000075a:	863a                	mv	a2,a4
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000075c:	4681                	li	a3,0
    8000075e:	a01d                	j	80000784 <printf+0x2b2>
    } else if(c0 == 'l' && c1 == 'd'){
    80000760:	f94a8793          	addi	a5,s5,-108
    80000764:	0017b793          	seqz	a5,a5
    c1 = c2 = 0;
    80000768:	8656                	mv	a2,s5
    8000076a:	8756                	mv	a4,s5
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    8000076c:	f9460693          	addi	a3,a2,-108
    80000770:	0016b693          	seqz	a3,a3
    80000774:	8efd                	and	a3,a3,a5
    80000776:	f9c70593          	addi	a1,a4,-100
    8000077a:	0015b593          	seqz	a1,a1
    8000077e:	8df5                	and	a1,a1,a3
    80000780:	e4059ce3          	bnez	a1,800005d8 <printf+0x106>
    } else if(c0 == 'u'){
    80000784:	e78a87e3          	beq	s5,s8,800005f2 <printf+0x120>
    } else if(c0 == 'l' && c1 == 'u'){
    80000788:	f8b60593          	addi	a1,a2,-117
    8000078c:	0015b593          	seqz	a1,a1
    80000790:	8dfd                	and	a1,a1,a5
    80000792:	e6059ce3          	bnez	a1,8000060a <printf+0x138>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    80000796:	f8b70593          	addi	a1,a4,-117
    8000079a:	0015b593          	seqz	a1,a1
    8000079e:	8df5                	and	a1,a1,a3
    800007a0:	e80592e3          	bnez	a1,80000624 <printf+0x152>
    } else if(c0 == 'x'){
    800007a4:	e9aa8de3          	beq	s5,s10,8000063e <printf+0x16c>
    } else if(c0 == 'l' && c1 == 'x'){
    800007a8:	f8860613          	addi	a2,a2,-120
    800007ac:	00163613          	seqz	a2,a2
    800007b0:	8e7d                	and	a2,a2,a5
    800007b2:	ea0612e3          	bnez	a2,80000656 <printf+0x184>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    800007b6:	f8870713          	addi	a4,a4,-120
    800007ba:	00173713          	seqz	a4,a4
    800007be:	8f75                	and	a4,a4,a3
    800007c0:	ea0718e3          	bnez	a4,80000670 <printf+0x19e>
    } else if(c0 == 'p'){
    800007c4:	07000793          	li	a5,112
    800007c8:	ecfa80e3          	beq	s5,a5,80000688 <printf+0x1b6>
    } else if(c0 == 's'){
    800007cc:	07300793          	li	a5,115
    800007d0:	eefa8fe3          	beq	s5,a5,800006ce <printf+0x1fc>
    } else if(c0 == '%'){
    800007d4:	02500793          	li	a5,37
    800007d8:	f2fa87e3          	beq	s5,a5,80000706 <printf+0x234>
    } else if(c0 == 0){
    800007dc:	f20a89e3          	beqz	s5,8000070e <printf+0x23c>
      consputc('%');
    800007e0:	02500513          	li	a0,37
    800007e4:	a69ff0ef          	jal	8000024c <consputc>
      consputc(c0);
    800007e8:	8556                	mv	a0,s5
    800007ea:	a63ff0ef          	jal	8000024c <consputc>
    800007ee:	bbe9                	j	800005c8 <printf+0xf6>

00000000800007f0 <panic>:

void
panic(char *s)
{
    800007f0:	1101                	addi	sp,sp,-32
    800007f2:	ec06                	sd	ra,24(sp)
    800007f4:	e822                	sd	s0,16(sp)
    800007f6:	e426                	sd	s1,8(sp)
    800007f8:	1000                	addi	s0,sp,32
    800007fa:	84aa                	mv	s1,a0
  pr.locking = 0;
    800007fc:	0000f797          	auipc	a5,0xf
    80000800:	2407a223          	sw	zero,580(a5) # 8000fa40 <pr+0x18>
  printf("panic: ");
    80000804:	00007517          	auipc	a0,0x7
    80000808:	81450513          	addi	a0,a0,-2028 # 80007018 <etext+0x18>
    8000080c:	cc7ff0ef          	jal	800004d2 <printf>
  printf("%s\n", s);
    80000810:	85a6                	mv	a1,s1
    80000812:	00007517          	auipc	a0,0x7
    80000816:	80e50513          	addi	a0,a0,-2034 # 80007020 <etext+0x20>
    8000081a:	cb9ff0ef          	jal	800004d2 <printf>
  panicked = 1; // freeze uart output from other CPUs
    8000081e:	4785                	li	a5,1
    80000820:	00007717          	auipc	a4,0x7
    80000824:	12f72023          	sw	a5,288(a4) # 80007940 <panicked>
  for(;;)
    80000828:	a001                	j	80000828 <panic+0x38>

000000008000082a <printfinit>:
    ;
}

void
printfinit(void)
{
    8000082a:	1141                	addi	sp,sp,-16
    8000082c:	e406                	sd	ra,8(sp)
    8000082e:	e022                	sd	s0,0(sp)
    80000830:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000832:	00006597          	auipc	a1,0x6
    80000836:	7f658593          	addi	a1,a1,2038 # 80007028 <etext+0x28>
    8000083a:	0000f517          	auipc	a0,0xf
    8000083e:	1ee50513          	addi	a0,a0,494 # 8000fa28 <pr>
    80000842:	398000ef          	jal	80000bda <initlock>
  pr.locking = 1;
    80000846:	4785                	li	a5,1
    80000848:	0000f717          	auipc	a4,0xf
    8000084c:	1ef72c23          	sw	a5,504(a4) # 8000fa40 <pr+0x18>
}
    80000850:	60a2                	ld	ra,8(sp)
    80000852:	6402                	ld	s0,0(sp)
    80000854:	0141                	addi	sp,sp,16
    80000856:	8082                	ret

0000000080000858 <uartinit>:

void uartstart();

void
uartinit(void)
{
    80000858:	1141                	addi	sp,sp,-16
    8000085a:	e406                	sd	ra,8(sp)
    8000085c:	e022                	sd	s0,0(sp)
    8000085e:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    80000860:	100007b7          	lui	a5,0x10000
    80000864:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000868:	10000737          	lui	a4,0x10000
    8000086c:	f8000693          	li	a3,-128
    80000870:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    80000874:	468d                	li	a3,3
    80000876:	10000637          	lui	a2,0x10000
    8000087a:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    8000087e:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    80000882:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    80000886:	8732                	mv	a4,a2
    80000888:	461d                	li	a2,7
    8000088a:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    8000088e:	00d780a3          	sb	a3,1(a5)

  initlock(&uart_tx_lock, "uart");
    80000892:	00006597          	auipc	a1,0x6
    80000896:	79e58593          	addi	a1,a1,1950 # 80007030 <etext+0x30>
    8000089a:	0000f517          	auipc	a0,0xf
    8000089e:	1ae50513          	addi	a0,a0,430 # 8000fa48 <uart_tx_lock>
    800008a2:	338000ef          	jal	80000bda <initlock>
}
    800008a6:	60a2                	ld	ra,8(sp)
    800008a8:	6402                	ld	s0,0(sp)
    800008aa:	0141                	addi	sp,sp,16
    800008ac:	8082                	ret

00000000800008ae <uartputc_sync>:
// use interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    800008ae:	1101                	addi	sp,sp,-32
    800008b0:	ec06                	sd	ra,24(sp)
    800008b2:	e822                	sd	s0,16(sp)
    800008b4:	e426                	sd	s1,8(sp)
    800008b6:	1000                	addi	s0,sp,32
    800008b8:	84aa                	mv	s1,a0
  push_off();
    800008ba:	366000ef          	jal	80000c20 <push_off>

  if(panicked){
    800008be:	00007797          	auipc	a5,0x7
    800008c2:	0827a783          	lw	a5,130(a5) # 80007940 <panicked>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800008c6:	10000737          	lui	a4,0x10000
    800008ca:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
  if(panicked){
    800008cc:	c391                	beqz	a5,800008d0 <uartputc_sync+0x22>
    for(;;)
    800008ce:	a001                	j	800008ce <uartputc_sync+0x20>
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    800008d0:	00074783          	lbu	a5,0(a4)
    800008d4:	0207f793          	andi	a5,a5,32
    800008d8:	dfe5                	beqz	a5,800008d0 <uartputc_sync+0x22>
    ;
  WriteReg(THR, c);
    800008da:	100007b7          	lui	a5,0x10000
    800008de:	00978023          	sb	s1,0(a5) # 10000000 <_entry-0x70000000>

  pop_off();
    800008e2:	3c2000ef          	jal	80000ca4 <pop_off>
}
    800008e6:	60e2                	ld	ra,24(sp)
    800008e8:	6442                	ld	s0,16(sp)
    800008ea:	64a2                	ld	s1,8(sp)
    800008ec:	6105                	addi	sp,sp,32
    800008ee:	8082                	ret

00000000800008f0 <uartstart>:
// called from both the top- and bottom-half.
void
uartstart()
{
  while(1){
    if(uart_tx_w == uart_tx_r){
    800008f0:	00007797          	auipc	a5,0x7
    800008f4:	0587b783          	ld	a5,88(a5) # 80007948 <uart_tx_r>
    800008f8:	00007717          	auipc	a4,0x7
    800008fc:	05873703          	ld	a4,88(a4) # 80007950 <uart_tx_w>
    80000900:	06f70d63          	beq	a4,a5,8000097a <uartstart+0x8a>
{
    80000904:	7139                	addi	sp,sp,-64
    80000906:	fc06                	sd	ra,56(sp)
    80000908:	f822                	sd	s0,48(sp)
    8000090a:	f426                	sd	s1,40(sp)
    8000090c:	f04a                	sd	s2,32(sp)
    8000090e:	ec4e                	sd	s3,24(sp)
    80000910:	e852                	sd	s4,16(sp)
    80000912:	e456                	sd	s5,8(sp)
    80000914:	e05a                	sd	s6,0(sp)
    80000916:	0080                	addi	s0,sp,64
      // transmit buffer is empty.
      return;
    }
    
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    80000918:	10000937          	lui	s2,0x10000
    8000091c:	0915                	addi	s2,s2,5 # 10000005 <_entry-0x6ffffffb>
      // so we cannot give it another byte.
      // it will interrupt when it's ready for a new byte.
      return;
    }
    
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    8000091e:	0000fa97          	auipc	s5,0xf
    80000922:	12aa8a93          	addi	s5,s5,298 # 8000fa48 <uart_tx_lock>
    uart_tx_r += 1;
    80000926:	00007497          	auipc	s1,0x7
    8000092a:	02248493          	addi	s1,s1,34 # 80007948 <uart_tx_r>
    
    // maybe uartputc() is waiting for space in the buffer.
    wakeup(&uart_tx_r);
    
    WriteReg(THR, c);
    8000092e:	10000a37          	lui	s4,0x10000
    if(uart_tx_w == uart_tx_r){
    80000932:	00007997          	auipc	s3,0x7
    80000936:	01e98993          	addi	s3,s3,30 # 80007950 <uart_tx_w>
    if((ReadReg(LSR) & LSR_TX_IDLE) == 0){
    8000093a:	00094703          	lbu	a4,0(s2)
    8000093e:	02077713          	andi	a4,a4,32
    80000942:	c315                	beqz	a4,80000966 <uartstart+0x76>
    int c = uart_tx_buf[uart_tx_r % UART_TX_BUF_SIZE];
    80000944:	01f7f713          	andi	a4,a5,31
    80000948:	9756                	add	a4,a4,s5
    8000094a:	01874b03          	lbu	s6,24(a4)
    uart_tx_r += 1;
    8000094e:	0785                	addi	a5,a5,1
    80000950:	e09c                	sd	a5,0(s1)
    wakeup(&uart_tx_r);
    80000952:	8526                	mv	a0,s1
    80000954:	5e4010ef          	jal	80001f38 <wakeup>
    WriteReg(THR, c);
    80000958:	016a0023          	sb	s6,0(s4) # 10000000 <_entry-0x70000000>
    if(uart_tx_w == uart_tx_r){
    8000095c:	609c                	ld	a5,0(s1)
    8000095e:	0009b703          	ld	a4,0(s3)
    80000962:	fcf71ce3          	bne	a4,a5,8000093a <uartstart+0x4a>
  }
}
    80000966:	70e2                	ld	ra,56(sp)
    80000968:	7442                	ld	s0,48(sp)
    8000096a:	74a2                	ld	s1,40(sp)
    8000096c:	7902                	ld	s2,32(sp)
    8000096e:	69e2                	ld	s3,24(sp)
    80000970:	6a42                	ld	s4,16(sp)
    80000972:	6aa2                	ld	s5,8(sp)
    80000974:	6b02                	ld	s6,0(sp)
    80000976:	6121                	addi	sp,sp,64
    80000978:	8082                	ret
    8000097a:	8082                	ret

000000008000097c <uartputc>:
{
    8000097c:	7179                	addi	sp,sp,-48
    8000097e:	f406                	sd	ra,40(sp)
    80000980:	f022                	sd	s0,32(sp)
    80000982:	ec26                	sd	s1,24(sp)
    80000984:	e84a                	sd	s2,16(sp)
    80000986:	e44e                	sd	s3,8(sp)
    80000988:	e052                	sd	s4,0(sp)
    8000098a:	1800                	addi	s0,sp,48
    8000098c:	8a2a                	mv	s4,a0
  acquire(&uart_tx_lock);
    8000098e:	0000f517          	auipc	a0,0xf
    80000992:	0ba50513          	addi	a0,a0,186 # 8000fa48 <uart_tx_lock>
    80000996:	2ce000ef          	jal	80000c64 <acquire>
  if(panicked){
    8000099a:	00007797          	auipc	a5,0x7
    8000099e:	fa67a783          	lw	a5,-90(a5) # 80007940 <panicked>
    800009a2:	e3d1                	bnez	a5,80000a26 <uartputc+0xaa>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800009a4:	00007717          	auipc	a4,0x7
    800009a8:	fac73703          	ld	a4,-84(a4) # 80007950 <uart_tx_w>
    800009ac:	00007797          	auipc	a5,0x7
    800009b0:	f9c7b783          	ld	a5,-100(a5) # 80007948 <uart_tx_r>
    800009b4:	02078793          	addi	a5,a5,32
    sleep(&uart_tx_r, &uart_tx_lock);
    800009b8:	0000f997          	auipc	s3,0xf
    800009bc:	09098993          	addi	s3,s3,144 # 8000fa48 <uart_tx_lock>
    800009c0:	00007497          	auipc	s1,0x7
    800009c4:	f8848493          	addi	s1,s1,-120 # 80007948 <uart_tx_r>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800009c8:	00007917          	auipc	s2,0x7
    800009cc:	f8890913          	addi	s2,s2,-120 # 80007950 <uart_tx_w>
    800009d0:	00e79d63          	bne	a5,a4,800009ea <uartputc+0x6e>
    sleep(&uart_tx_r, &uart_tx_lock);
    800009d4:	85ce                	mv	a1,s3
    800009d6:	8526                	mv	a0,s1
    800009d8:	514010ef          	jal	80001eec <sleep>
  while(uart_tx_w == uart_tx_r + UART_TX_BUF_SIZE){
    800009dc:	00093703          	ld	a4,0(s2)
    800009e0:	609c                	ld	a5,0(s1)
    800009e2:	02078793          	addi	a5,a5,32
    800009e6:	fee787e3          	beq	a5,a4,800009d4 <uartputc+0x58>
  uart_tx_buf[uart_tx_w % UART_TX_BUF_SIZE] = c;
    800009ea:	01f77693          	andi	a3,a4,31
    800009ee:	0000f797          	auipc	a5,0xf
    800009f2:	05a78793          	addi	a5,a5,90 # 8000fa48 <uart_tx_lock>
    800009f6:	97b6                	add	a5,a5,a3
    800009f8:	01478c23          	sb	s4,24(a5)
  uart_tx_w += 1;
    800009fc:	0705                	addi	a4,a4,1
    800009fe:	00007797          	auipc	a5,0x7
    80000a02:	f4e7b923          	sd	a4,-174(a5) # 80007950 <uart_tx_w>
  uartstart();
    80000a06:	eebff0ef          	jal	800008f0 <uartstart>
  release(&uart_tx_lock);
    80000a0a:	0000f517          	auipc	a0,0xf
    80000a0e:	03e50513          	addi	a0,a0,62 # 8000fa48 <uart_tx_lock>
    80000a12:	2e2000ef          	jal	80000cf4 <release>
}
    80000a16:	70a2                	ld	ra,40(sp)
    80000a18:	7402                	ld	s0,32(sp)
    80000a1a:	64e2                	ld	s1,24(sp)
    80000a1c:	6942                	ld	s2,16(sp)
    80000a1e:	69a2                	ld	s3,8(sp)
    80000a20:	6a02                	ld	s4,0(sp)
    80000a22:	6145                	addi	sp,sp,48
    80000a24:	8082                	ret
    for(;;)
    80000a26:	a001                	j	80000a26 <uartputc+0xaa>

0000000080000a28 <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    80000a28:	1141                	addi	sp,sp,-16
    80000a2a:	e406                	sd	ra,8(sp)
    80000a2c:	e022                	sd	s0,0(sp)
    80000a2e:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & 0x01){
    80000a30:	100007b7          	lui	a5,0x10000
    80000a34:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80000a38:	8b85                	andi	a5,a5,1
    80000a3a:	cb89                	beqz	a5,80000a4c <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    80000a3c:	100007b7          	lui	a5,0x10000
    80000a40:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    80000a44:	60a2                	ld	ra,8(sp)
    80000a46:	6402                	ld	s0,0(sp)
    80000a48:	0141                	addi	sp,sp,16
    80000a4a:	8082                	ret
    return -1;
    80000a4c:	557d                	li	a0,-1
    80000a4e:	bfdd                	j	80000a44 <uartgetc+0x1c>

0000000080000a50 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    80000a50:	1101                	addi	sp,sp,-32
    80000a52:	ec06                	sd	ra,24(sp)
    80000a54:	e822                	sd	s0,16(sp)
    80000a56:	e426                	sd	s1,8(sp)
    80000a58:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    80000a5a:	100007b7          	lui	a5,0x10000
    80000a5e:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>

  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80000a62:	54fd                	li	s1,-1
    int c = uartgetc();
    80000a64:	fc5ff0ef          	jal	80000a28 <uartgetc>
    if(c == -1)
    80000a68:	00950563          	beq	a0,s1,80000a72 <uartintr+0x22>
      break;
    consoleintr(c);
    80000a6c:	813ff0ef          	jal	8000027e <consoleintr>
  while(1){
    80000a70:	bfd5                	j	80000a64 <uartintr+0x14>
  }

  // send buffered characters.
  acquire(&uart_tx_lock);
    80000a72:	0000f517          	auipc	a0,0xf
    80000a76:	fd650513          	addi	a0,a0,-42 # 8000fa48 <uart_tx_lock>
    80000a7a:	1ea000ef          	jal	80000c64 <acquire>
  uartstart();
    80000a7e:	e73ff0ef          	jal	800008f0 <uartstart>
  release(&uart_tx_lock);
    80000a82:	0000f517          	auipc	a0,0xf
    80000a86:	fc650513          	addi	a0,a0,-58 # 8000fa48 <uart_tx_lock>
    80000a8a:	26a000ef          	jal	80000cf4 <release>
}
    80000a8e:	60e2                	ld	ra,24(sp)
    80000a90:	6442                	ld	s0,16(sp)
    80000a92:	64a2                	ld	s1,8(sp)
    80000a94:	6105                	addi	sp,sp,32
    80000a96:	8082                	ret

0000000080000a98 <kfree>:
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(void *pa)
{
    80000a98:	1101                	addi	sp,sp,-32
    80000a9a:	ec06                	sd	ra,24(sp)
    80000a9c:	e822                	sd	s0,16(sp)
    80000a9e:	e426                	sd	s1,8(sp)
    80000aa0:	e04a                	sd	s2,0(sp)
    80000aa2:	1000                	addi	s0,sp,32
  struct run *r;

  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000aa4:	00020797          	auipc	a5,0x20
    80000aa8:	67c78793          	addi	a5,a5,1660 # 80021120 <end>
    80000aac:	00f53733          	sltu	a4,a0,a5
    80000ab0:	47c5                	li	a5,17
    80000ab2:	07ee                	slli	a5,a5,0x1b
    80000ab4:	17fd                	addi	a5,a5,-1
    80000ab6:	00a7b7b3          	sltu	a5,a5,a0
    80000aba:	8fd9                	or	a5,a5,a4
    80000abc:	03451713          	slli	a4,a0,0x34
    80000ac0:	8fd9                	or	a5,a5,a4
    80000ac2:	eb9d                	bnez	a5,80000af8 <kfree+0x60>
    80000ac4:	84aa                	mv	s1,a0
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000ac6:	6605                	lui	a2,0x1
    80000ac8:	4585                	li	a1,1
    80000aca:	266000ef          	jal	80000d30 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000ace:	0000f917          	auipc	s2,0xf
    80000ad2:	fb290913          	addi	s2,s2,-78 # 8000fa80 <kmem>
    80000ad6:	854a                	mv	a0,s2
    80000ad8:	18c000ef          	jal	80000c64 <acquire>
  r->next = kmem.freelist;
    80000adc:	01893783          	ld	a5,24(s2)
    80000ae0:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000ae2:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000ae6:	854a                	mv	a0,s2
    80000ae8:	20c000ef          	jal	80000cf4 <release>
}
    80000aec:	60e2                	ld	ra,24(sp)
    80000aee:	6442                	ld	s0,16(sp)
    80000af0:	64a2                	ld	s1,8(sp)
    80000af2:	6902                	ld	s2,0(sp)
    80000af4:	6105                	addi	sp,sp,32
    80000af6:	8082                	ret
    panic("kfree");
    80000af8:	00006517          	auipc	a0,0x6
    80000afc:	54050513          	addi	a0,a0,1344 # 80007038 <etext+0x38>
    80000b00:	cf1ff0ef          	jal	800007f0 <panic>

0000000080000b04 <freerange>:
{
    80000b04:	7179                	addi	sp,sp,-48
    80000b06:	f406                	sd	ra,40(sp)
    80000b08:	f022                	sd	s0,32(sp)
    80000b0a:	ec26                	sd	s1,24(sp)
    80000b0c:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start);
    80000b0e:	6785                	lui	a5,0x1
    80000b10:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000b14:	00e504b3          	add	s1,a0,a4
    80000b18:	777d                	lui	a4,0xfffff
    80000b1a:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000b1c:	94be                	add	s1,s1,a5
    80000b1e:	0295e263          	bltu	a1,s1,80000b42 <freerange+0x3e>
    80000b22:	e84a                	sd	s2,16(sp)
    80000b24:	e44e                	sd	s3,8(sp)
    80000b26:	e052                	sd	s4,0(sp)
    80000b28:	892e                	mv	s2,a1
    kfree(p);
    80000b2a:	8a3a                	mv	s4,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000b2c:	89be                	mv	s3,a5
    kfree(p);
    80000b2e:	01448533          	add	a0,s1,s4
    80000b32:	f67ff0ef          	jal	80000a98 <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000b36:	94ce                	add	s1,s1,s3
    80000b38:	fe997be3          	bgeu	s2,s1,80000b2e <freerange+0x2a>
    80000b3c:	6942                	ld	s2,16(sp)
    80000b3e:	69a2                	ld	s3,8(sp)
    80000b40:	6a02                	ld	s4,0(sp)
}
    80000b42:	70a2                	ld	ra,40(sp)
    80000b44:	7402                	ld	s0,32(sp)
    80000b46:	64e2                	ld	s1,24(sp)
    80000b48:	6145                	addi	sp,sp,48
    80000b4a:	8082                	ret

0000000080000b4c <kinit>:
{
    80000b4c:	1141                	addi	sp,sp,-16
    80000b4e:	e406                	sd	ra,8(sp)
    80000b50:	e022                	sd	s0,0(sp)
    80000b52:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000b54:	00006597          	auipc	a1,0x6
    80000b58:	4ec58593          	addi	a1,a1,1260 # 80007040 <etext+0x40>
    80000b5c:	0000f517          	auipc	a0,0xf
    80000b60:	f2450513          	addi	a0,a0,-220 # 8000fa80 <kmem>
    80000b64:	076000ef          	jal	80000bda <initlock>
  freerange(end, (void*)PHYSTOP);
    80000b68:	45c5                	li	a1,17
    80000b6a:	05ee                	slli	a1,a1,0x1b
    80000b6c:	00020517          	auipc	a0,0x20
    80000b70:	5b450513          	addi	a0,a0,1460 # 80021120 <end>
    80000b74:	f91ff0ef          	jal	80000b04 <freerange>
}
    80000b78:	60a2                	ld	ra,8(sp)
    80000b7a:	6402                	ld	s0,0(sp)
    80000b7c:	0141                	addi	sp,sp,16
    80000b7e:	8082                	ret

0000000080000b80 <kalloc>:
// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void *
kalloc(void)
{
    80000b80:	1101                	addi	sp,sp,-32
    80000b82:	ec06                	sd	ra,24(sp)
    80000b84:	e822                	sd	s0,16(sp)
    80000b86:	e426                	sd	s1,8(sp)
    80000b88:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b8a:	0000f517          	auipc	a0,0xf
    80000b8e:	ef650513          	addi	a0,a0,-266 # 8000fa80 <kmem>
    80000b92:	0d2000ef          	jal	80000c64 <acquire>
  r = kmem.freelist;
    80000b96:	0000f497          	auipc	s1,0xf
    80000b9a:	f024b483          	ld	s1,-254(s1) # 8000fa98 <kmem+0x18>
  if(r)
    80000b9e:	c49d                	beqz	s1,80000bcc <kalloc+0x4c>
    kmem.freelist = r->next;
    80000ba0:	609c                	ld	a5,0(s1)
    80000ba2:	0000f717          	auipc	a4,0xf
    80000ba6:	eef73b23          	sd	a5,-266(a4) # 8000fa98 <kmem+0x18>
  release(&kmem.lock);
    80000baa:	0000f517          	auipc	a0,0xf
    80000bae:	ed650513          	addi	a0,a0,-298 # 8000fa80 <kmem>
    80000bb2:	142000ef          	jal	80000cf4 <release>

  if(r)
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000bb6:	6605                	lui	a2,0x1
    80000bb8:	4595                	li	a1,5
    80000bba:	8526                	mv	a0,s1
    80000bbc:	174000ef          	jal	80000d30 <memset>
  return (void*)r;
}
    80000bc0:	8526                	mv	a0,s1
    80000bc2:	60e2                	ld	ra,24(sp)
    80000bc4:	6442                	ld	s0,16(sp)
    80000bc6:	64a2                	ld	s1,8(sp)
    80000bc8:	6105                	addi	sp,sp,32
    80000bca:	8082                	ret
  release(&kmem.lock);
    80000bcc:	0000f517          	auipc	a0,0xf
    80000bd0:	eb450513          	addi	a0,a0,-332 # 8000fa80 <kmem>
    80000bd4:	120000ef          	jal	80000cf4 <release>
  if(r)
    80000bd8:	b7e5                	j	80000bc0 <kalloc+0x40>

0000000080000bda <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000bda:	1141                	addi	sp,sp,-16
    80000bdc:	e406                	sd	ra,8(sp)
    80000bde:	e022                	sd	s0,0(sp)
    80000be0:	0800                	addi	s0,sp,16
  lk->name = name;
    80000be2:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000be4:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000be8:	00053823          	sd	zero,16(a0)
}
    80000bec:	60a2                	ld	ra,8(sp)
    80000bee:	6402                	ld	s0,0(sp)
    80000bf0:	0141                	addi	sp,sp,16
    80000bf2:	8082                	ret

0000000080000bf4 <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000bf4:	411c                	lw	a5,0(a0)
    80000bf6:	e399                	bnez	a5,80000bfc <holding+0x8>
    80000bf8:	4501                	li	a0,0
  return r;
}
    80000bfa:	8082                	ret
{
    80000bfc:	1101                	addi	sp,sp,-32
    80000bfe:	ec06                	sd	ra,24(sp)
    80000c00:	e822                	sd	s0,16(sp)
    80000c02:	e426                	sd	s1,8(sp)
    80000c04:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000c06:	691c                	ld	a5,16(a0)
    80000c08:	84be                	mv	s1,a5
    80000c0a:	507000ef          	jal	80001910 <mycpu>
    80000c0e:	40a48533          	sub	a0,s1,a0
    80000c12:	00153513          	seqz	a0,a0
}
    80000c16:	60e2                	ld	ra,24(sp)
    80000c18:	6442                	ld	s0,16(sp)
    80000c1a:	64a2                	ld	s1,8(sp)
    80000c1c:	6105                	addi	sp,sp,32
    80000c1e:	8082                	ret

0000000080000c20 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000c20:	1101                	addi	sp,sp,-32
    80000c22:	ec06                	sd	ra,24(sp)
    80000c24:	e822                	sd	s0,16(sp)
    80000c26:	e426                	sd	s1,8(sp)
    80000c28:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c2a:	100027f3          	csrr	a5,sstatus
    80000c2e:	84be                	mv	s1,a5
  int old = intr_get();

  if(mycpu()->noff == 0){
    80000c30:	4e1000ef          	jal	80001910 <mycpu>
    80000c34:	5d3c                	lw	a5,120(a0)
    80000c36:	cb99                	beqz	a5,80000c4c <push_off+0x2c>
    intr_off();
    mycpu()->intena = old;
  }
  mycpu()->noff += 1;
    80000c38:	4d9000ef          	jal	80001910 <mycpu>
    80000c3c:	5d3c                	lw	a5,120(a0)
    80000c3e:	2785                	addiw	a5,a5,1
    80000c40:	dd3c                	sw	a5,120(a0)
}
    80000c42:	60e2                	ld	ra,24(sp)
    80000c44:	6442                	ld	s0,16(sp)
    80000c46:	64a2                	ld	s1,8(sp)
    80000c48:	6105                	addi	sp,sp,32
    80000c4a:	8082                	ret
    80000c4c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000c50:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c52:	10079073          	csrw	sstatus,a5
    mycpu()->intena = old;
    80000c56:	4bb000ef          	jal	80001910 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000c5a:	0014d793          	srli	a5,s1,0x1
    80000c5e:	8b85                	andi	a5,a5,1
    80000c60:	dd7c                	sw	a5,124(a0)
    80000c62:	bfd9                	j	80000c38 <push_off+0x18>

0000000080000c64 <acquire>:
{
    80000c64:	1101                	addi	sp,sp,-32
    80000c66:	ec06                	sd	ra,24(sp)
    80000c68:	e822                	sd	s0,16(sp)
    80000c6a:	e426                	sd	s1,8(sp)
    80000c6c:	1000                	addi	s0,sp,32
    80000c6e:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000c70:	fb1ff0ef          	jal	80000c20 <push_off>
  if(holding(lk))
    80000c74:	8526                	mv	a0,s1
    80000c76:	f7fff0ef          	jal	80000bf4 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c7a:	4705                	li	a4,1
  if(holding(lk))
    80000c7c:	ed11                	bnez	a0,80000c98 <acquire+0x34>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c7e:	0ce4a7af          	amoswap.w.aq	a5,a4,(s1)
    80000c82:	fff5                	bnez	a5,80000c7e <acquire+0x1a>
  __sync_synchronize();
    80000c84:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80000c88:	489000ef          	jal	80001910 <mycpu>
    80000c8c:	e888                	sd	a0,16(s1)
}
    80000c8e:	60e2                	ld	ra,24(sp)
    80000c90:	6442                	ld	s0,16(sp)
    80000c92:	64a2                	ld	s1,8(sp)
    80000c94:	6105                	addi	sp,sp,32
    80000c96:	8082                	ret
    panic("acquire");
    80000c98:	00006517          	auipc	a0,0x6
    80000c9c:	3b050513          	addi	a0,a0,944 # 80007048 <etext+0x48>
    80000ca0:	b51ff0ef          	jal	800007f0 <panic>

0000000080000ca4 <pop_off>:

void
pop_off(void)
{
    80000ca4:	1141                	addi	sp,sp,-16
    80000ca6:	e406                	sd	ra,8(sp)
    80000ca8:	e022                	sd	s0,0(sp)
    80000caa:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000cac:	465000ef          	jal	80001910 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000cb0:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000cb4:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000cb6:	e39d                	bnez	a5,80000cdc <pop_off+0x38>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000cb8:	5d3c                	lw	a5,120(a0)
    80000cba:	02f05763          	blez	a5,80000ce8 <pop_off+0x44>
    panic("pop_off");
  c->noff -= 1;
    80000cbe:	37fd                	addiw	a5,a5,-1
    80000cc0:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000cc2:	eb89                	bnez	a5,80000cd4 <pop_off+0x30>
    80000cc4:	5d7c                	lw	a5,124(a0)
    80000cc6:	c799                	beqz	a5,80000cd4 <pop_off+0x30>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000cc8:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000ccc:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000cd0:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000cd4:	60a2                	ld	ra,8(sp)
    80000cd6:	6402                	ld	s0,0(sp)
    80000cd8:	0141                	addi	sp,sp,16
    80000cda:	8082                	ret
    panic("pop_off - interruptible");
    80000cdc:	00006517          	auipc	a0,0x6
    80000ce0:	37450513          	addi	a0,a0,884 # 80007050 <etext+0x50>
    80000ce4:	b0dff0ef          	jal	800007f0 <panic>
    panic("pop_off");
    80000ce8:	00006517          	auipc	a0,0x6
    80000cec:	38050513          	addi	a0,a0,896 # 80007068 <etext+0x68>
    80000cf0:	b01ff0ef          	jal	800007f0 <panic>

0000000080000cf4 <release>:
{
    80000cf4:	1101                	addi	sp,sp,-32
    80000cf6:	ec06                	sd	ra,24(sp)
    80000cf8:	e822                	sd	s0,16(sp)
    80000cfa:	e426                	sd	s1,8(sp)
    80000cfc:	1000                	addi	s0,sp,32
    80000cfe:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000d00:	ef5ff0ef          	jal	80000bf4 <holding>
    80000d04:	c105                	beqz	a0,80000d24 <release+0x30>
  lk->cpu = 0;
    80000d06:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000d0a:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    80000d0e:	0310000f          	fence	rw,w
    80000d12:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000d16:	f8fff0ef          	jal	80000ca4 <pop_off>
}
    80000d1a:	60e2                	ld	ra,24(sp)
    80000d1c:	6442                	ld	s0,16(sp)
    80000d1e:	64a2                	ld	s1,8(sp)
    80000d20:	6105                	addi	sp,sp,32
    80000d22:	8082                	ret
    panic("release");
    80000d24:	00006517          	auipc	a0,0x6
    80000d28:	34c50513          	addi	a0,a0,844 # 80007070 <etext+0x70>
    80000d2c:	ac5ff0ef          	jal	800007f0 <panic>

0000000080000d30 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000d30:	1141                	addi	sp,sp,-16
    80000d32:	e406                	sd	ra,8(sp)
    80000d34:	e022                	sd	s0,0(sp)
    80000d36:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000d38:	ca19                	beqz	a2,80000d4e <memset+0x1e>
    80000d3a:	87aa                	mv	a5,a0
    80000d3c:	1602                	slli	a2,a2,0x20
    80000d3e:	9201                	srli	a2,a2,0x20
    80000d40:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000d44:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000d48:	0785                	addi	a5,a5,1
    80000d4a:	fee79de3          	bne	a5,a4,80000d44 <memset+0x14>
  }
  return dst;
}
    80000d4e:	60a2                	ld	ra,8(sp)
    80000d50:	6402                	ld	s0,0(sp)
    80000d52:	0141                	addi	sp,sp,16
    80000d54:	8082                	ret

0000000080000d56 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000d56:	1141                	addi	sp,sp,-16
    80000d58:	e406                	sd	ra,8(sp)
    80000d5a:	e022                	sd	s0,0(sp)
    80000d5c:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000d5e:	ce19                	beqz	a2,80000d7c <memcmp+0x26>
    80000d60:	1602                	slli	a2,a2,0x20
    80000d62:	9201                	srli	a2,a2,0x20
    80000d64:	00c506b3          	add	a3,a0,a2
    if(*s1 != *s2)
    80000d68:	00054783          	lbu	a5,0(a0)
    80000d6c:	0005c703          	lbu	a4,0(a1)
    80000d70:	00e79b63          	bne	a5,a4,80000d86 <memcmp+0x30>
      return *s1 - *s2;
    s1++, s2++;
    80000d74:	0505                	addi	a0,a0,1
    80000d76:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000d78:	fed518e3          	bne	a0,a3,80000d68 <memcmp+0x12>
  }

  return 0;
    80000d7c:	4501                	li	a0,0
}
    80000d7e:	60a2                	ld	ra,8(sp)
    80000d80:	6402                	ld	s0,0(sp)
    80000d82:	0141                	addi	sp,sp,16
    80000d84:	8082                	ret
      return *s1 - *s2;
    80000d86:	40e7853b          	subw	a0,a5,a4
    80000d8a:	bfd5                	j	80000d7e <memcmp+0x28>

0000000080000d8c <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000d8c:	1141                	addi	sp,sp,-16
    80000d8e:	e406                	sd	ra,8(sp)
    80000d90:	e022                	sd	s0,0(sp)
    80000d92:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d94:	c61d                	beqz	a2,80000dc2 <memmove+0x36>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d96:	00a5f963          	bgeu	a1,a0,80000da8 <memmove+0x1c>
    80000d9a:	02061693          	slli	a3,a2,0x20
    80000d9e:	9281                	srli	a3,a3,0x20
    80000da0:	00d58733          	add	a4,a1,a3
    80000da4:	02e56363          	bltu	a0,a4,80000dca <memmove+0x3e>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000da8:	1602                	slli	a2,a2,0x20
    80000daa:	9201                	srli	a2,a2,0x20
    80000dac:	00c587b3          	add	a5,a1,a2
{
    80000db0:	872a                	mv	a4,a0
      *d++ = *s++;
    80000db2:	0585                	addi	a1,a1,1
    80000db4:	0705                	addi	a4,a4,1
    80000db6:	fff5c683          	lbu	a3,-1(a1)
    80000dba:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000dbe:	fef59ae3          	bne	a1,a5,80000db2 <memmove+0x26>

  return dst;
}
    80000dc2:	60a2                	ld	ra,8(sp)
    80000dc4:	6402                	ld	s0,0(sp)
    80000dc6:	0141                	addi	sp,sp,16
    80000dc8:	8082                	ret
    d += n;
    80000dca:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000dcc:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000dd0:	1782                	slli	a5,a5,0x20
    80000dd2:	9381                	srli	a5,a5,0x20
    80000dd4:	fff7c793          	not	a5,a5
    80000dd8:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000dda:	177d                	addi	a4,a4,-1
    80000ddc:	16fd                	addi	a3,a3,-1
    80000dde:	00074603          	lbu	a2,0(a4)
    80000de2:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000de6:	fee79ae3          	bne	a5,a4,80000dda <memmove+0x4e>
    80000dea:	bfe1                	j	80000dc2 <memmove+0x36>

0000000080000dec <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000dec:	1141                	addi	sp,sp,-16
    80000dee:	e406                	sd	ra,8(sp)
    80000df0:	e022                	sd	s0,0(sp)
    80000df2:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000df4:	f99ff0ef          	jal	80000d8c <memmove>
}
    80000df8:	60a2                	ld	ra,8(sp)
    80000dfa:	6402                	ld	s0,0(sp)
    80000dfc:	0141                	addi	sp,sp,16
    80000dfe:	8082                	ret

0000000080000e00 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000e00:	1141                	addi	sp,sp,-16
    80000e02:	e406                	sd	ra,8(sp)
    80000e04:	e022                	sd	s0,0(sp)
    80000e06:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000e08:	ce01                	beqz	a2,80000e20 <strncmp+0x20>
    80000e0a:	00054783          	lbu	a5,0(a0)
    80000e0e:	cb99                	beqz	a5,80000e24 <strncmp+0x24>
    80000e10:	0005c703          	lbu	a4,0(a1)
    80000e14:	00f71863          	bne	a4,a5,80000e24 <strncmp+0x24>
    n--, p++, q++;
    80000e18:	367d                	addiw	a2,a2,-1
    80000e1a:	0505                	addi	a0,a0,1
    80000e1c:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000e1e:	f675                	bnez	a2,80000e0a <strncmp+0xa>
  if(n == 0)
    return 0;
    80000e20:	4501                	li	a0,0
    80000e22:	a031                	j	80000e2e <strncmp+0x2e>
  return (uchar)*p - (uchar)*q;
    80000e24:	00054503          	lbu	a0,0(a0)
    80000e28:	0005c783          	lbu	a5,0(a1)
    80000e2c:	9d1d                	subw	a0,a0,a5
}
    80000e2e:	60a2                	ld	ra,8(sp)
    80000e30:	6402                	ld	s0,0(sp)
    80000e32:	0141                	addi	sp,sp,16
    80000e34:	8082                	ret

0000000080000e36 <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000e36:	1141                	addi	sp,sp,-16
    80000e38:	e406                	sd	ra,8(sp)
    80000e3a:	e022                	sd	s0,0(sp)
    80000e3c:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000e3e:	87aa                	mv	a5,a0
    80000e40:	a011                	j	80000e44 <strncpy+0xe>
    80000e42:	8636                	mv	a2,a3
    80000e44:	02c05763          	blez	a2,80000e72 <strncpy+0x3c>
    80000e48:	fff6069b          	addiw	a3,a2,-1
    80000e4c:	0785                	addi	a5,a5,1
    80000e4e:	0005c703          	lbu	a4,0(a1)
    80000e52:	fee78fa3          	sb	a4,-1(a5)
    80000e56:	0585                	addi	a1,a1,1
    80000e58:	f76d                	bnez	a4,80000e42 <strncpy+0xc>
    ;
  while(n-- > 0)
    80000e5a:	873e                	mv	a4,a5
    80000e5c:	00d05b63          	blez	a3,80000e72 <strncpy+0x3c>
    80000e60:	9fb1                	addw	a5,a5,a2
    80000e62:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    80000e64:	0705                	addi	a4,a4,1
    80000e66:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    80000e6a:	40e786bb          	subw	a3,a5,a4
    80000e6e:	fed04be3          	bgtz	a3,80000e64 <strncpy+0x2e>
  return os;
}
    80000e72:	60a2                	ld	ra,8(sp)
    80000e74:	6402                	ld	s0,0(sp)
    80000e76:	0141                	addi	sp,sp,16
    80000e78:	8082                	ret

0000000080000e7a <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000e7a:	1141                	addi	sp,sp,-16
    80000e7c:	e406                	sd	ra,8(sp)
    80000e7e:	e022                	sd	s0,0(sp)
    80000e80:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000e82:	02c05363          	blez	a2,80000ea8 <safestrcpy+0x2e>
    80000e86:	fff6069b          	addiw	a3,a2,-1
    80000e8a:	1682                	slli	a3,a3,0x20
    80000e8c:	9281                	srli	a3,a3,0x20
    80000e8e:	96ae                	add	a3,a3,a1
    80000e90:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000e92:	00d58963          	beq	a1,a3,80000ea4 <safestrcpy+0x2a>
    80000e96:	0585                	addi	a1,a1,1
    80000e98:	0785                	addi	a5,a5,1
    80000e9a:	fff5c703          	lbu	a4,-1(a1)
    80000e9e:	fee78fa3          	sb	a4,-1(a5)
    80000ea2:	fb65                	bnez	a4,80000e92 <safestrcpy+0x18>
    ;
  *s = 0;
    80000ea4:	00078023          	sb	zero,0(a5)
  return os;
}
    80000ea8:	60a2                	ld	ra,8(sp)
    80000eaa:	6402                	ld	s0,0(sp)
    80000eac:	0141                	addi	sp,sp,16
    80000eae:	8082                	ret

0000000080000eb0 <strlen>:

int
strlen(const char *s)
{
    80000eb0:	1141                	addi	sp,sp,-16
    80000eb2:	e406                	sd	ra,8(sp)
    80000eb4:	e022                	sd	s0,0(sp)
    80000eb6:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000eb8:	00054783          	lbu	a5,0(a0)
    80000ebc:	cf91                	beqz	a5,80000ed8 <strlen+0x28>
    80000ebe:	00150793          	addi	a5,a0,1
    80000ec2:	86be                	mv	a3,a5
    80000ec4:	0785                	addi	a5,a5,1
    80000ec6:	fff7c703          	lbu	a4,-1(a5)
    80000eca:	ff65                	bnez	a4,80000ec2 <strlen+0x12>
    80000ecc:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000ed0:	60a2                	ld	ra,8(sp)
    80000ed2:	6402                	ld	s0,0(sp)
    80000ed4:	0141                	addi	sp,sp,16
    80000ed6:	8082                	ret
  for(n = 0; s[n]; n++)
    80000ed8:	4501                	li	a0,0
    80000eda:	bfdd                	j	80000ed0 <strlen+0x20>

0000000080000edc <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000edc:	1141                	addi	sp,sp,-16
    80000ede:	e406                	sd	ra,8(sp)
    80000ee0:	e022                	sd	s0,0(sp)
    80000ee2:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000ee4:	219000ef          	jal	800018fc <cpuid>
    ucnt_init(); ubuf_init(); // user counter & buffer
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000ee8:	00007717          	auipc	a4,0x7
    80000eec:	a7070713          	addi	a4,a4,-1424 # 80007958 <started>
  if(cpuid() == 0){
    80000ef0:	c515                	beqz	a0,80000f1c <main+0x40>
    while(started == 0)
    80000ef2:	431c                	lw	a5,0(a4)
    80000ef4:	dffd                	beqz	a5,80000ef2 <main+0x16>
      ;
    __sync_synchronize();
    80000ef6:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    80000efa:	203000ef          	jal	800018fc <cpuid>
    80000efe:	85aa                	mv	a1,a0
    80000f00:	00006517          	auipc	a0,0x6
    80000f04:	19850513          	addi	a0,a0,408 # 80007098 <etext+0x98>
    80000f08:	dcaff0ef          	jal	800004d2 <printf>
    kvminithart();    // turn on paging
    80000f0c:	08c000ef          	jal	80000f98 <kvminithart>
    trapinithart();   // install kernel trap vector
    80000f10:	4f6010ef          	jal	80002406 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000f14:	474040ef          	jal	80005388 <plicinithart>
  }

  scheduler();        
    80000f18:	647000ef          	jal	80001d5e <scheduler>
    consoleinit();
    80000f1c:	cdeff0ef          	jal	800003fa <consoleinit>
    printfinit();
    80000f20:	90bff0ef          	jal	8000082a <printfinit>
    printf("\n");
    80000f24:	00006517          	auipc	a0,0x6
    80000f28:	15450513          	addi	a0,a0,340 # 80007078 <etext+0x78>
    80000f2c:	da6ff0ef          	jal	800004d2 <printf>
    printf("xv6 kernel is booting\n");
    80000f30:	00006517          	auipc	a0,0x6
    80000f34:	15050513          	addi	a0,a0,336 # 80007080 <etext+0x80>
    80000f38:	d9aff0ef          	jal	800004d2 <printf>
    printf("\n");
    80000f3c:	00006517          	auipc	a0,0x6
    80000f40:	13c50513          	addi	a0,a0,316 # 80007078 <etext+0x78>
    80000f44:	d8eff0ef          	jal	800004d2 <printf>
    kinit();         // physical page allocator
    80000f48:	c05ff0ef          	jal	80000b4c <kinit>
    kvminit();       // create kernel page table
    80000f4c:	2cc000ef          	jal	80001218 <kvminit>
    kvminithart();   // turn on paging
    80000f50:	048000ef          	jal	80000f98 <kvminithart>
    procinit();      // process table
    80000f54:	0f1000ef          	jal	80001844 <procinit>
    trapinit();      // trap vectors
    80000f58:	48a010ef          	jal	800023e2 <trapinit>
    trapinithart();  // install kernel trap vector
    80000f5c:	4aa010ef          	jal	80002406 <trapinithart>
    plicinit();      // set up interrupt controller
    80000f60:	40e040ef          	jal	8000536e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000f64:	424040ef          	jal	80005388 <plicinithart>
    binit();         // buffer cache
    80000f68:	405010ef          	jal	80002b6c <binit>
    iinit();         // inode table
    80000f6c:	1c8020ef          	jal	80003134 <iinit>
    fileinit();      // file table
    80000f70:	7b5020ef          	jal	80003f24 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000f74:	504040ef          	jal	80005478 <virtio_disk_init>
    seminit();       // semaphore table
    80000f78:	285040ef          	jal	800059fc <seminit>
    ucnt_init(); ubuf_init(); // user counter & buffer
    80000f7c:	20b040ef          	jal	80005986 <ucnt_init>
    80000f80:	1e7040ef          	jal	80005966 <ubuf_init>
    userinit();      // first user process
    80000f84:	415000ef          	jal	80001b98 <userinit>
    __sync_synchronize();
    80000f88:	0330000f          	fence	rw,rw
    started = 1;
    80000f8c:	4785                	li	a5,1
    80000f8e:	00007717          	auipc	a4,0x7
    80000f92:	9cf72523          	sw	a5,-1590(a4) # 80007958 <started>
    80000f96:	b749                	j	80000f18 <main+0x3c>

0000000080000f98 <kvminithart>:

// Switch h/w page table register to the kernel's page table,
// and enable paging.
void
kvminithart()
{
    80000f98:	1141                	addi	sp,sp,-16
    80000f9a:	e406                	sd	ra,8(sp)
    80000f9c:	e022                	sd	s0,0(sp)
    80000f9e:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000fa0:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000fa4:	00007797          	auipc	a5,0x7
    80000fa8:	9bc7b783          	ld	a5,-1604(a5) # 80007960 <kernel_pagetable>
    80000fac:	83b1                	srli	a5,a5,0xc
    80000fae:	577d                	li	a4,-1
    80000fb0:	177e                	slli	a4,a4,0x3f
    80000fb2:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000fb4:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000fb8:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000fbc:	60a2                	ld	ra,8(sp)
    80000fbe:	6402                	ld	s0,0(sp)
    80000fc0:	0141                	addi	sp,sp,16
    80000fc2:	8082                	ret

0000000080000fc4 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000fc4:	7139                	addi	sp,sp,-64
    80000fc6:	fc06                	sd	ra,56(sp)
    80000fc8:	f822                	sd	s0,48(sp)
    80000fca:	f426                	sd	s1,40(sp)
    80000fcc:	f04a                	sd	s2,32(sp)
    80000fce:	ec4e                	sd	s3,24(sp)
    80000fd0:	e852                	sd	s4,16(sp)
    80000fd2:	e456                	sd	s5,8(sp)
    80000fd4:	e05a                	sd	s6,0(sp)
    80000fd6:	0080                	addi	s0,sp,64
    80000fd8:	84aa                	mv	s1,a0
    80000fda:	89ae                	mv	s3,a1
    80000fdc:	8b32                	mv	s6,a2
  if(va >= MAXVA)
    80000fde:	57fd                	li	a5,-1
    80000fe0:	83e9                	srli	a5,a5,0x1a
    80000fe2:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000fe4:	4ab1                	li	s5,12
  if(va >= MAXVA)
    80000fe6:	06b7e363          	bltu	a5,a1,8000104c <walk+0x88>
    pte_t *pte = &pagetable[PX(level, va)];
    80000fea:	0149d933          	srl	s2,s3,s4
    80000fee:	1ff97913          	andi	s2,s2,511
    80000ff2:	090e                	slli	s2,s2,0x3
    80000ff4:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000ff6:	00093483          	ld	s1,0(s2)
    80000ffa:	0014f793          	andi	a5,s1,1
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000ffe:	80a9                	srli	s1,s1,0xa
    80001000:	04b2                	slli	s1,s1,0xc
    if(*pte & PTE_V) {
    80001002:	e395                	bnez	a5,80001026 <walk+0x62>
    } else {
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80001004:	040b0a63          	beqz	s6,80001058 <walk+0x94>
    80001008:	b79ff0ef          	jal	80000b80 <kalloc>
    8000100c:	84aa                	mv	s1,a0
    8000100e:	c50d                	beqz	a0,80001038 <walk+0x74>
        return 0;
      memset(pagetable, 0, PGSIZE);
    80001010:	6605                	lui	a2,0x1
    80001012:	4581                	li	a1,0
    80001014:	d1dff0ef          	jal	80000d30 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    80001018:	00c4d793          	srli	a5,s1,0xc
    8000101c:	07aa                	slli	a5,a5,0xa
    8000101e:	0017e793          	ori	a5,a5,1
    80001022:	00f93023          	sd	a5,0(s2)
  for(int level = 2; level > 0; level--) {
    80001026:	3a5d                	addiw	s4,s4,-9
    80001028:	fd5a11e3          	bne	s4,s5,80000fea <walk+0x26>
    }
  }
  return &pagetable[PX(0, va)];
    8000102c:	00c9d513          	srli	a0,s3,0xc
    80001030:	1ff57513          	andi	a0,a0,511
    80001034:	050e                	slli	a0,a0,0x3
    80001036:	9526                	add	a0,a0,s1
}
    80001038:	70e2                	ld	ra,56(sp)
    8000103a:	7442                	ld	s0,48(sp)
    8000103c:	74a2                	ld	s1,40(sp)
    8000103e:	7902                	ld	s2,32(sp)
    80001040:	69e2                	ld	s3,24(sp)
    80001042:	6a42                	ld	s4,16(sp)
    80001044:	6aa2                	ld	s5,8(sp)
    80001046:	6b02                	ld	s6,0(sp)
    80001048:	6121                	addi	sp,sp,64
    8000104a:	8082                	ret
    panic("walk");
    8000104c:	00006517          	auipc	a0,0x6
    80001050:	06450513          	addi	a0,a0,100 # 800070b0 <etext+0xb0>
    80001054:	f9cff0ef          	jal	800007f0 <panic>
        return 0;
    80001058:	4501                	li	a0,0
    8000105a:	bff9                	j	80001038 <walk+0x74>

000000008000105c <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    8000105c:	57fd                	li	a5,-1
    8000105e:	83e9                	srli	a5,a5,0x1a
    80001060:	00b7f463          	bgeu	a5,a1,80001068 <walkaddr+0xc>
    return 0;
    80001064:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80001066:	8082                	ret
{
    80001068:	1141                	addi	sp,sp,-16
    8000106a:	e406                	sd	ra,8(sp)
    8000106c:	e022                	sd	s0,0(sp)
    8000106e:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80001070:	4601                	li	a2,0
    80001072:	f53ff0ef          	jal	80000fc4 <walk>
  if(pte == 0)
    80001076:	c519                	beqz	a0,80001084 <walkaddr+0x28>
  if((*pte & PTE_V) == 0)
    80001078:	6108                	ld	a0,0(a0)
  if((*pte & PTE_U) == 0)
    8000107a:	01157713          	andi	a4,a0,17
    8000107e:	47c5                	li	a5,17
    80001080:	00f70763          	beq	a4,a5,8000108e <walkaddr+0x32>
    return 0;
    80001084:	4501                	li	a0,0
}
    80001086:	60a2                	ld	ra,8(sp)
    80001088:	6402                	ld	s0,0(sp)
    8000108a:	0141                	addi	sp,sp,16
    8000108c:	8082                	ret
  pa = PTE2PA(*pte);
    8000108e:	8129                	srli	a0,a0,0xa
    80001090:	0532                	slli	a0,a0,0xc
  return pa;
    80001092:	bfd5                	j	80001086 <walkaddr+0x2a>

0000000080001094 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001094:	715d                	addi	sp,sp,-80
    80001096:	e486                	sd	ra,72(sp)
    80001098:	e0a2                	sd	s0,64(sp)
    8000109a:	fc26                	sd	s1,56(sp)
    8000109c:	f84a                	sd	s2,48(sp)
    8000109e:	f44e                	sd	s3,40(sp)
    800010a0:	f052                	sd	s4,32(sp)
    800010a2:	ec56                	sd	s5,24(sp)
    800010a4:	e85a                	sd	s6,16(sp)
    800010a6:	e45e                	sd	s7,8(sp)
    800010a8:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    800010aa:	03459793          	slli	a5,a1,0x34
    800010ae:	e7b1                	bnez	a5,800010fa <mappages+0x66>
    800010b0:	8a2a                	mv	s4,a0
    800010b2:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    800010b4:	03461793          	slli	a5,a2,0x34
    800010b8:	e7b9                	bnez	a5,80001106 <mappages+0x72>
    panic("mappages: size not aligned");

  if(size == 0)
    800010ba:	ce21                	beqz	a2,80001112 <mappages+0x7e>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    800010bc:	77fd                	lui	a5,0xfffff
    800010be:	963e                	add	a2,a2,a5
    800010c0:	00b60933          	add	s2,a2,a1
  a = va;
    800010c4:	84ae                	mv	s1,a1
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
    800010c6:	4b05                	li	s6,1
    800010c8:	40b689b3          	sub	s3,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    800010cc:	6b85                	lui	s7,0x1
    if((pte = walk(pagetable, a, 1)) == 0)
    800010ce:	865a                	mv	a2,s6
    800010d0:	85a6                	mv	a1,s1
    800010d2:	8552                	mv	a0,s4
    800010d4:	ef1ff0ef          	jal	80000fc4 <walk>
    800010d8:	c929                	beqz	a0,8000112a <mappages+0x96>
    if(*pte & PTE_V)
    800010da:	611c                	ld	a5,0(a0)
    800010dc:	8b85                	andi	a5,a5,1
    800010de:	e3a1                	bnez	a5,8000111e <mappages+0x8a>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800010e0:	013487b3          	add	a5,s1,s3
    800010e4:	83b1                	srli	a5,a5,0xc
    800010e6:	07aa                	slli	a5,a5,0xa
    800010e8:	0157e7b3          	or	a5,a5,s5
    800010ec:	0017e793          	ori	a5,a5,1
    800010f0:	e11c                	sd	a5,0(a0)
    if(a == last)
    800010f2:	05248863          	beq	s1,s2,80001142 <mappages+0xae>
    a += PGSIZE;
    800010f6:	94de                	add	s1,s1,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    800010f8:	bfd9                	j	800010ce <mappages+0x3a>
    panic("mappages: va not aligned");
    800010fa:	00006517          	auipc	a0,0x6
    800010fe:	fbe50513          	addi	a0,a0,-66 # 800070b8 <etext+0xb8>
    80001102:	eeeff0ef          	jal	800007f0 <panic>
    panic("mappages: size not aligned");
    80001106:	00006517          	auipc	a0,0x6
    8000110a:	fd250513          	addi	a0,a0,-46 # 800070d8 <etext+0xd8>
    8000110e:	ee2ff0ef          	jal	800007f0 <panic>
    panic("mappages: size");
    80001112:	00006517          	auipc	a0,0x6
    80001116:	fe650513          	addi	a0,a0,-26 # 800070f8 <etext+0xf8>
    8000111a:	ed6ff0ef          	jal	800007f0 <panic>
      panic("mappages: remap");
    8000111e:	00006517          	auipc	a0,0x6
    80001122:	fea50513          	addi	a0,a0,-22 # 80007108 <etext+0x108>
    80001126:	ecaff0ef          	jal	800007f0 <panic>
      return -1;
    8000112a:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    8000112c:	60a6                	ld	ra,72(sp)
    8000112e:	6406                	ld	s0,64(sp)
    80001130:	74e2                	ld	s1,56(sp)
    80001132:	7942                	ld	s2,48(sp)
    80001134:	79a2                	ld	s3,40(sp)
    80001136:	7a02                	ld	s4,32(sp)
    80001138:	6ae2                	ld	s5,24(sp)
    8000113a:	6b42                	ld	s6,16(sp)
    8000113c:	6ba2                	ld	s7,8(sp)
    8000113e:	6161                	addi	sp,sp,80
    80001140:	8082                	ret
  return 0;
    80001142:	4501                	li	a0,0
    80001144:	b7e5                	j	8000112c <mappages+0x98>

0000000080001146 <kvmmap>:
{
    80001146:	1141                	addi	sp,sp,-16
    80001148:	e406                	sd	ra,8(sp)
    8000114a:	e022                	sd	s0,0(sp)
    8000114c:	0800                	addi	s0,sp,16
    8000114e:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80001150:	86b2                	mv	a3,a2
    80001152:	863e                	mv	a2,a5
    80001154:	f41ff0ef          	jal	80001094 <mappages>
    80001158:	e509                	bnez	a0,80001162 <kvmmap+0x1c>
}
    8000115a:	60a2                	ld	ra,8(sp)
    8000115c:	6402                	ld	s0,0(sp)
    8000115e:	0141                	addi	sp,sp,16
    80001160:	8082                	ret
    panic("kvmmap");
    80001162:	00006517          	auipc	a0,0x6
    80001166:	fb650513          	addi	a0,a0,-74 # 80007118 <etext+0x118>
    8000116a:	e86ff0ef          	jal	800007f0 <panic>

000000008000116e <kvmmake>:
{
    8000116e:	1101                	addi	sp,sp,-32
    80001170:	ec06                	sd	ra,24(sp)
    80001172:	e822                	sd	s0,16(sp)
    80001174:	e426                	sd	s1,8(sp)
    80001176:	e04a                	sd	s2,0(sp)
    80001178:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    8000117a:	a07ff0ef          	jal	80000b80 <kalloc>
    8000117e:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80001180:	6605                	lui	a2,0x1
    80001182:	4581                	li	a1,0
    80001184:	badff0ef          	jal	80000d30 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80001188:	4719                	li	a4,6
    8000118a:	6685                	lui	a3,0x1
    8000118c:	10000637          	lui	a2,0x10000
    80001190:	85b2                	mv	a1,a2
    80001192:	8526                	mv	a0,s1
    80001194:	fb3ff0ef          	jal	80001146 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    80001198:	4719                	li	a4,6
    8000119a:	6685                	lui	a3,0x1
    8000119c:	10001637          	lui	a2,0x10001
    800011a0:	85b2                	mv	a1,a2
    800011a2:	8526                	mv	a0,s1
    800011a4:	fa3ff0ef          	jal	80001146 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    800011a8:	4719                	li	a4,6
    800011aa:	040006b7          	lui	a3,0x4000
    800011ae:	0c000637          	lui	a2,0xc000
    800011b2:	85b2                	mv	a1,a2
    800011b4:	8526                	mv	a0,s1
    800011b6:	f91ff0ef          	jal	80001146 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    800011ba:	00006917          	auipc	s2,0x6
    800011be:	e4690913          	addi	s2,s2,-442 # 80007000 <etext>
    800011c2:	4729                	li	a4,10
    800011c4:	800006b7          	lui	a3,0x80000
    800011c8:	96ca                	add	a3,a3,s2
    800011ca:	4605                	li	a2,1
    800011cc:	067e                	slli	a2,a2,0x1f
    800011ce:	85b2                	mv	a1,a2
    800011d0:	8526                	mv	a0,s1
    800011d2:	f75ff0ef          	jal	80001146 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    800011d6:	4719                	li	a4,6
    800011d8:	46c5                	li	a3,17
    800011da:	06ee                	slli	a3,a3,0x1b
    800011dc:	412686b3          	sub	a3,a3,s2
    800011e0:	864a                	mv	a2,s2
    800011e2:	85ca                	mv	a1,s2
    800011e4:	8526                	mv	a0,s1
    800011e6:	f61ff0ef          	jal	80001146 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800011ea:	4729                	li	a4,10
    800011ec:	6685                	lui	a3,0x1
    800011ee:	00005617          	auipc	a2,0x5
    800011f2:	e1260613          	addi	a2,a2,-494 # 80006000 <_trampoline>
    800011f6:	040005b7          	lui	a1,0x4000
    800011fa:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800011fc:	05b2                	slli	a1,a1,0xc
    800011fe:	8526                	mv	a0,s1
    80001200:	f47ff0ef          	jal	80001146 <kvmmap>
  proc_mapstacks(kpgtbl);
    80001204:	8526                	mv	a0,s1
    80001206:	5aa000ef          	jal	800017b0 <proc_mapstacks>
}
    8000120a:	8526                	mv	a0,s1
    8000120c:	60e2                	ld	ra,24(sp)
    8000120e:	6442                	ld	s0,16(sp)
    80001210:	64a2                	ld	s1,8(sp)
    80001212:	6902                	ld	s2,0(sp)
    80001214:	6105                	addi	sp,sp,32
    80001216:	8082                	ret

0000000080001218 <kvminit>:
{
    80001218:	1141                	addi	sp,sp,-16
    8000121a:	e406                	sd	ra,8(sp)
    8000121c:	e022                	sd	s0,0(sp)
    8000121e:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    80001220:	f4fff0ef          	jal	8000116e <kvmmake>
    80001224:	00006797          	auipc	a5,0x6
    80001228:	72a7be23          	sd	a0,1852(a5) # 80007960 <kernel_pagetable>
}
    8000122c:	60a2                	ld	ra,8(sp)
    8000122e:	6402                	ld	s0,0(sp)
    80001230:	0141                	addi	sp,sp,16
    80001232:	8082                	ret

0000000080001234 <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. The mappings must exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    80001234:	715d                	addi	sp,sp,-80
    80001236:	e486                	sd	ra,72(sp)
    80001238:	e0a2                	sd	s0,64(sp)
    8000123a:	0880                	addi	s0,sp,80
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    8000123c:	03459793          	slli	a5,a1,0x34
    80001240:	e39d                	bnez	a5,80001266 <uvmunmap+0x32>
    80001242:	f84a                	sd	s2,48(sp)
    80001244:	f44e                	sd	s3,40(sp)
    80001246:	f052                	sd	s4,32(sp)
    80001248:	ec56                	sd	s5,24(sp)
    8000124a:	e85a                	sd	s6,16(sp)
    8000124c:	e45e                	sd	s7,8(sp)
    8000124e:	8a2a                	mv	s4,a0
    80001250:	892e                	mv	s2,a1
    80001252:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001254:	0632                	slli	a2,a2,0xc
    80001256:	00b609b3          	add	s3,a2,a1
    if((pte = walk(pagetable, a, 0)) == 0)
      panic("uvmunmap: walk");
    if((*pte & PTE_V) == 0)
      panic("uvmunmap: not mapped");
    if(PTE_FLAGS(*pte) == PTE_V)
    8000125a:	4b85                	li	s7,1
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    8000125c:	6b05                	lui	s6,0x1
    8000125e:	0735ff63          	bgeu	a1,s3,800012dc <uvmunmap+0xa8>
    80001262:	fc26                	sd	s1,56(sp)
    80001264:	a0a9                	j	800012ae <uvmunmap+0x7a>
    80001266:	fc26                	sd	s1,56(sp)
    80001268:	f84a                	sd	s2,48(sp)
    8000126a:	f44e                	sd	s3,40(sp)
    8000126c:	f052                	sd	s4,32(sp)
    8000126e:	ec56                	sd	s5,24(sp)
    80001270:	e85a                	sd	s6,16(sp)
    80001272:	e45e                	sd	s7,8(sp)
    panic("uvmunmap: not aligned");
    80001274:	00006517          	auipc	a0,0x6
    80001278:	eac50513          	addi	a0,a0,-340 # 80007120 <etext+0x120>
    8000127c:	d74ff0ef          	jal	800007f0 <panic>
      panic("uvmunmap: walk");
    80001280:	00006517          	auipc	a0,0x6
    80001284:	eb850513          	addi	a0,a0,-328 # 80007138 <etext+0x138>
    80001288:	d68ff0ef          	jal	800007f0 <panic>
      panic("uvmunmap: not mapped");
    8000128c:	00006517          	auipc	a0,0x6
    80001290:	ebc50513          	addi	a0,a0,-324 # 80007148 <etext+0x148>
    80001294:	d5cff0ef          	jal	800007f0 <panic>
      panic("uvmunmap: not a leaf");
    80001298:	00006517          	auipc	a0,0x6
    8000129c:	ec850513          	addi	a0,a0,-312 # 80007160 <etext+0x160>
    800012a0:	d50ff0ef          	jal	800007f0 <panic>
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    800012a4:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800012a8:	995a                	add	s2,s2,s6
    800012aa:	03397863          	bgeu	s2,s3,800012da <uvmunmap+0xa6>
    if((pte = walk(pagetable, a, 0)) == 0)
    800012ae:	4601                	li	a2,0
    800012b0:	85ca                	mv	a1,s2
    800012b2:	8552                	mv	a0,s4
    800012b4:	d11ff0ef          	jal	80000fc4 <walk>
    800012b8:	84aa                	mv	s1,a0
    800012ba:	d179                	beqz	a0,80001280 <uvmunmap+0x4c>
    if((*pte & PTE_V) == 0)
    800012bc:	6108                	ld	a0,0(a0)
    800012be:	00157793          	andi	a5,a0,1
    800012c2:	d7e9                	beqz	a5,8000128c <uvmunmap+0x58>
    if(PTE_FLAGS(*pte) == PTE_V)
    800012c4:	3ff57793          	andi	a5,a0,1023
    800012c8:	fd7788e3          	beq	a5,s7,80001298 <uvmunmap+0x64>
    if(do_free){
    800012cc:	fc0a8ce3          	beqz	s5,800012a4 <uvmunmap+0x70>
      uint64 pa = PTE2PA(*pte);
    800012d0:	8129                	srli	a0,a0,0xa
      kfree((void*)pa);
    800012d2:	0532                	slli	a0,a0,0xc
    800012d4:	fc4ff0ef          	jal	80000a98 <kfree>
    800012d8:	b7f1                	j	800012a4 <uvmunmap+0x70>
    800012da:	74e2                	ld	s1,56(sp)
    800012dc:	7942                	ld	s2,48(sp)
    800012de:	79a2                	ld	s3,40(sp)
    800012e0:	7a02                	ld	s4,32(sp)
    800012e2:	6ae2                	ld	s5,24(sp)
    800012e4:	6b42                	ld	s6,16(sp)
    800012e6:	6ba2                	ld	s7,8(sp)
  }
}
    800012e8:	60a6                	ld	ra,72(sp)
    800012ea:	6406                	ld	s0,64(sp)
    800012ec:	6161                	addi	sp,sp,80
    800012ee:	8082                	ret

00000000800012f0 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    800012f0:	1101                	addi	sp,sp,-32
    800012f2:	ec06                	sd	ra,24(sp)
    800012f4:	e822                	sd	s0,16(sp)
    800012f6:	e426                	sd	s1,8(sp)
    800012f8:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    800012fa:	887ff0ef          	jal	80000b80 <kalloc>
    800012fe:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001300:	c509                	beqz	a0,8000130a <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    80001302:	6605                	lui	a2,0x1
    80001304:	4581                	li	a1,0
    80001306:	a2bff0ef          	jal	80000d30 <memset>
  return pagetable;
}
    8000130a:	8526                	mv	a0,s1
    8000130c:	60e2                	ld	ra,24(sp)
    8000130e:	6442                	ld	s0,16(sp)
    80001310:	64a2                	ld	s1,8(sp)
    80001312:	6105                	addi	sp,sp,32
    80001314:	8082                	ret

0000000080001316 <uvmfirst>:
// Load the user initcode into address 0 of pagetable,
// for the very first process.
// sz must be less than a page.
void
uvmfirst(pagetable_t pagetable, uchar *src, uint sz)
{
    80001316:	7179                	addi	sp,sp,-48
    80001318:	f406                	sd	ra,40(sp)
    8000131a:	f022                	sd	s0,32(sp)
    8000131c:	ec26                	sd	s1,24(sp)
    8000131e:	e84a                	sd	s2,16(sp)
    80001320:	e44e                	sd	s3,8(sp)
    80001322:	e052                	sd	s4,0(sp)
    80001324:	1800                	addi	s0,sp,48
  char *mem;

  if(sz >= PGSIZE)
    80001326:	6785                	lui	a5,0x1
    80001328:	04f67063          	bgeu	a2,a5,80001368 <uvmfirst+0x52>
    8000132c:	89aa                	mv	s3,a0
    8000132e:	8a2e                	mv	s4,a1
    80001330:	84b2                	mv	s1,a2
    panic("uvmfirst: more than a page");
  mem = kalloc();
    80001332:	84fff0ef          	jal	80000b80 <kalloc>
    80001336:	892a                	mv	s2,a0
  memset(mem, 0, PGSIZE);
    80001338:	6605                	lui	a2,0x1
    8000133a:	4581                	li	a1,0
    8000133c:	9f5ff0ef          	jal	80000d30 <memset>
  mappages(pagetable, 0, PGSIZE, (uint64)mem, PTE_W|PTE_R|PTE_X|PTE_U);
    80001340:	4779                	li	a4,30
    80001342:	86ca                	mv	a3,s2
    80001344:	6605                	lui	a2,0x1
    80001346:	4581                	li	a1,0
    80001348:	854e                	mv	a0,s3
    8000134a:	d4bff0ef          	jal	80001094 <mappages>
  memmove(mem, src, sz);
    8000134e:	8626                	mv	a2,s1
    80001350:	85d2                	mv	a1,s4
    80001352:	854a                	mv	a0,s2
    80001354:	a39ff0ef          	jal	80000d8c <memmove>
}
    80001358:	70a2                	ld	ra,40(sp)
    8000135a:	7402                	ld	s0,32(sp)
    8000135c:	64e2                	ld	s1,24(sp)
    8000135e:	6942                	ld	s2,16(sp)
    80001360:	69a2                	ld	s3,8(sp)
    80001362:	6a02                	ld	s4,0(sp)
    80001364:	6145                	addi	sp,sp,48
    80001366:	8082                	ret
    panic("uvmfirst: more than a page");
    80001368:	00006517          	auipc	a0,0x6
    8000136c:	e1050513          	addi	a0,a0,-496 # 80007178 <etext+0x178>
    80001370:	c80ff0ef          	jal	800007f0 <panic>

0000000080001374 <uvmdealloc>:
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
  if(newsz >= oldsz)
    80001374:	04b67163          	bgeu	a2,a1,800013b6 <uvmdealloc+0x42>
{
    80001378:	1101                	addi	sp,sp,-32
    8000137a:	ec06                	sd	ra,24(sp)
    8000137c:	e822                	sd	s0,16(sp)
    8000137e:	e426                	sd	s1,8(sp)
    80001380:	1000                	addi	s0,sp,32
    80001382:	84b2                	mv	s1,a2
    return oldsz;

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    80001384:	6785                	lui	a5,0x1
    80001386:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001388:	00f60733          	add	a4,a2,a5
    8000138c:	76fd                	lui	a3,0xfffff
    8000138e:	8f75                	and	a4,a4,a3
    80001390:	97ae                	add	a5,a5,a1
    80001392:	8ff5                	and	a5,a5,a3
    80001394:	00f76863          	bltu	a4,a5,800013a4 <uvmdealloc+0x30>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
    80001398:	8526                	mv	a0,s1
}
    8000139a:	60e2                	ld	ra,24(sp)
    8000139c:	6442                	ld	s0,16(sp)
    8000139e:	64a2                	ld	s1,8(sp)
    800013a0:	6105                	addi	sp,sp,32
    800013a2:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800013a4:	8f99                	sub	a5,a5,a4
    800013a6:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800013a8:	4685                	li	a3,1
    800013aa:	0007861b          	sext.w	a2,a5
    800013ae:	85ba                	mv	a1,a4
    800013b0:	e85ff0ef          	jal	80001234 <uvmunmap>
    800013b4:	b7d5                	j	80001398 <uvmdealloc+0x24>
    return oldsz;
    800013b6:	852e                	mv	a0,a1
}
    800013b8:	8082                	ret

00000000800013ba <uvmalloc>:
  if(newsz < oldsz)
    800013ba:	08b66e63          	bltu	a2,a1,80001456 <uvmalloc+0x9c>
{
    800013be:	715d                	addi	sp,sp,-80
    800013c0:	e486                	sd	ra,72(sp)
    800013c2:	e0a2                	sd	s0,64(sp)
    800013c4:	f052                	sd	s4,32(sp)
    800013c6:	ec56                	sd	s5,24(sp)
    800013c8:	e45e                	sd	s7,8(sp)
    800013ca:	0880                	addi	s0,sp,80
    800013cc:	8aaa                	mv	s5,a0
    800013ce:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    800013d0:	6785                	lui	a5,0x1
    800013d2:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800013d4:	95be                	add	a1,a1,a5
    800013d6:	77fd                	lui	a5,0xfffff
    800013d8:	8fed                	and	a5,a5,a1
    800013da:	8bbe                	mv	s7,a5
  for(a = oldsz; a < newsz; a += PGSIZE){
    800013dc:	04c7f163          	bgeu	a5,a2,8000141e <uvmalloc+0x64>
    800013e0:	fc26                	sd	s1,56(sp)
    800013e2:	f84a                	sd	s2,48(sp)
    800013e4:	f44e                	sd	s3,40(sp)
    800013e6:	e85a                	sd	s6,16(sp)
    800013e8:	893e                	mv	s2,a5
    memset(mem, 0, PGSIZE);
    800013ea:	6985                	lui	s3,0x1
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    800013ec:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    800013f0:	f90ff0ef          	jal	80000b80 <kalloc>
    800013f4:	84aa                	mv	s1,a0
    if(mem == 0){
    800013f6:	c515                	beqz	a0,80001422 <uvmalloc+0x68>
    memset(mem, 0, PGSIZE);
    800013f8:	864e                	mv	a2,s3
    800013fa:	4581                	li	a1,0
    800013fc:	935ff0ef          	jal	80000d30 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80001400:	875a                	mv	a4,s6
    80001402:	86a6                	mv	a3,s1
    80001404:	864e                	mv	a2,s3
    80001406:	85ca                	mv	a1,s2
    80001408:	8556                	mv	a0,s5
    8000140a:	c8bff0ef          	jal	80001094 <mappages>
    8000140e:	e91d                	bnez	a0,80001444 <uvmalloc+0x8a>
  for(a = oldsz; a < newsz; a += PGSIZE){
    80001410:	994e                	add	s2,s2,s3
    80001412:	fd496fe3          	bltu	s2,s4,800013f0 <uvmalloc+0x36>
    80001416:	74e2                	ld	s1,56(sp)
    80001418:	7942                	ld	s2,48(sp)
    8000141a:	79a2                	ld	s3,40(sp)
    8000141c:	6b42                	ld	s6,16(sp)
  return newsz;
    8000141e:	8552                	mv	a0,s4
    80001420:	a819                	j	80001436 <uvmalloc+0x7c>
      uvmdealloc(pagetable, a, oldsz);
    80001422:	865e                	mv	a2,s7
    80001424:	85ca                	mv	a1,s2
    80001426:	8556                	mv	a0,s5
    80001428:	f4dff0ef          	jal	80001374 <uvmdealloc>
      return 0;
    8000142c:	4501                	li	a0,0
    8000142e:	74e2                	ld	s1,56(sp)
    80001430:	7942                	ld	s2,48(sp)
    80001432:	79a2                	ld	s3,40(sp)
    80001434:	6b42                	ld	s6,16(sp)
}
    80001436:	60a6                	ld	ra,72(sp)
    80001438:	6406                	ld	s0,64(sp)
    8000143a:	7a02                	ld	s4,32(sp)
    8000143c:	6ae2                	ld	s5,24(sp)
    8000143e:	6ba2                	ld	s7,8(sp)
    80001440:	6161                	addi	sp,sp,80
    80001442:	8082                	ret
      kfree(mem);
    80001444:	8526                	mv	a0,s1
    80001446:	e52ff0ef          	jal	80000a98 <kfree>
      uvmdealloc(pagetable, a, oldsz);
    8000144a:	865e                	mv	a2,s7
    8000144c:	85ca                	mv	a1,s2
    8000144e:	8556                	mv	a0,s5
    80001450:	f25ff0ef          	jal	80001374 <uvmdealloc>
      return 0;
    80001454:	bfe1                	j	8000142c <uvmalloc+0x72>
    return oldsz;
    80001456:	852e                	mv	a0,a1
}
    80001458:	8082                	ret

000000008000145a <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    8000145a:	7179                	addi	sp,sp,-48
    8000145c:	f406                	sd	ra,40(sp)
    8000145e:	f022                	sd	s0,32(sp)
    80001460:	ec26                	sd	s1,24(sp)
    80001462:	e84a                	sd	s2,16(sp)
    80001464:	e44e                	sd	s3,8(sp)
    80001466:	1800                	addi	s0,sp,48
    80001468:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    8000146a:	84aa                	mv	s1,a0
    8000146c:	6905                	lui	s2,0x1
    8000146e:	992a                	add	s2,s2,a0
    80001470:	a811                	j	80001484 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      panic("freewalk: leaf");
    80001472:	00006517          	auipc	a0,0x6
    80001476:	d2650513          	addi	a0,a0,-730 # 80007198 <etext+0x198>
    8000147a:	b76ff0ef          	jal	800007f0 <panic>
  for(int i = 0; i < 512; i++){
    8000147e:	04a1                	addi	s1,s1,8
    80001480:	03248163          	beq	s1,s2,800014a2 <freewalk+0x48>
    pte_t pte = pagetable[i];
    80001484:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80001486:	0017f713          	andi	a4,a5,1
    8000148a:	db75                	beqz	a4,8000147e <freewalk+0x24>
    8000148c:	00e7f713          	andi	a4,a5,14
    80001490:	f36d                	bnez	a4,80001472 <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    80001492:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    80001494:	00c79513          	slli	a0,a5,0xc
    80001498:	fc3ff0ef          	jal	8000145a <freewalk>
      pagetable[i] = 0;
    8000149c:	0004b023          	sd	zero,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800014a0:	bff9                	j	8000147e <freewalk+0x24>
    }
  }
  kfree((void*)pagetable);
    800014a2:	854e                	mv	a0,s3
    800014a4:	df4ff0ef          	jal	80000a98 <kfree>
}
    800014a8:	70a2                	ld	ra,40(sp)
    800014aa:	7402                	ld	s0,32(sp)
    800014ac:	64e2                	ld	s1,24(sp)
    800014ae:	6942                	ld	s2,16(sp)
    800014b0:	69a2                	ld	s3,8(sp)
    800014b2:	6145                	addi	sp,sp,48
    800014b4:	8082                	ret

00000000800014b6 <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800014b6:	1101                	addi	sp,sp,-32
    800014b8:	ec06                	sd	ra,24(sp)
    800014ba:	e822                	sd	s0,16(sp)
    800014bc:	e426                	sd	s1,8(sp)
    800014be:	1000                	addi	s0,sp,32
    800014c0:	84aa                	mv	s1,a0
  if(sz > 0)
    800014c2:	e989                	bnez	a1,800014d4 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    800014c4:	8526                	mv	a0,s1
    800014c6:	f95ff0ef          	jal	8000145a <freewalk>
}
    800014ca:	60e2                	ld	ra,24(sp)
    800014cc:	6442                	ld	s0,16(sp)
    800014ce:	64a2                	ld	s1,8(sp)
    800014d0:	6105                	addi	sp,sp,32
    800014d2:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    800014d4:	6785                	lui	a5,0x1
    800014d6:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800014d8:	95be                	add	a1,a1,a5
    800014da:	4685                	li	a3,1
    800014dc:	00c5d613          	srli	a2,a1,0xc
    800014e0:	4581                	li	a1,0
    800014e2:	d53ff0ef          	jal	80001234 <uvmunmap>
    800014e6:	bff9                	j	800014c4 <uvmfree+0xe>

00000000800014e8 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    800014e8:	c64d                	beqz	a2,80001592 <uvmcopy+0xaa>
{
    800014ea:	715d                	addi	sp,sp,-80
    800014ec:	e486                	sd	ra,72(sp)
    800014ee:	e0a2                	sd	s0,64(sp)
    800014f0:	fc26                	sd	s1,56(sp)
    800014f2:	f84a                	sd	s2,48(sp)
    800014f4:	f44e                	sd	s3,40(sp)
    800014f6:	f052                	sd	s4,32(sp)
    800014f8:	ec56                	sd	s5,24(sp)
    800014fa:	e85a                	sd	s6,16(sp)
    800014fc:	e45e                	sd	s7,8(sp)
    800014fe:	0880                	addi	s0,sp,80
    80001500:	8b2a                	mv	s6,a0
    80001502:	8aae                	mv	s5,a1
    80001504:	8a32                	mv	s4,a2
  for(i = 0; i < sz; i += PGSIZE){
    80001506:	4901                	li	s2,0
      panic("uvmcopy: page not present");
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    80001508:	6985                	lui	s3,0x1
    if((pte = walk(old, i, 0)) == 0)
    8000150a:	4601                	li	a2,0
    8000150c:	85ca                	mv	a1,s2
    8000150e:	855a                	mv	a0,s6
    80001510:	ab5ff0ef          	jal	80000fc4 <walk>
    80001514:	cd0d                	beqz	a0,8000154e <uvmcopy+0x66>
    if((*pte & PTE_V) == 0)
    80001516:	00053b83          	ld	s7,0(a0)
    8000151a:	001bf793          	andi	a5,s7,1
    8000151e:	cf95                	beqz	a5,8000155a <uvmcopy+0x72>
    if((mem = kalloc()) == 0)
    80001520:	e60ff0ef          	jal	80000b80 <kalloc>
    80001524:	84aa                	mv	s1,a0
    80001526:	c139                	beqz	a0,8000156c <uvmcopy+0x84>
    pa = PTE2PA(*pte);
    80001528:	00abd593          	srli	a1,s7,0xa
    memmove(mem, (char*)pa, PGSIZE);
    8000152c:	864e                	mv	a2,s3
    8000152e:	05b2                	slli	a1,a1,0xc
    80001530:	85dff0ef          	jal	80000d8c <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    80001534:	3ffbf713          	andi	a4,s7,1023
    80001538:	86a6                	mv	a3,s1
    8000153a:	864e                	mv	a2,s3
    8000153c:	85ca                	mv	a1,s2
    8000153e:	8556                	mv	a0,s5
    80001540:	b55ff0ef          	jal	80001094 <mappages>
    80001544:	e10d                	bnez	a0,80001566 <uvmcopy+0x7e>
  for(i = 0; i < sz; i += PGSIZE){
    80001546:	994e                	add	s2,s2,s3
    80001548:	fd4961e3          	bltu	s2,s4,8000150a <uvmcopy+0x22>
    8000154c:	a805                	j	8000157c <uvmcopy+0x94>
      panic("uvmcopy: pte should exist");
    8000154e:	00006517          	auipc	a0,0x6
    80001552:	c5a50513          	addi	a0,a0,-934 # 800071a8 <etext+0x1a8>
    80001556:	a9aff0ef          	jal	800007f0 <panic>
      panic("uvmcopy: page not present");
    8000155a:	00006517          	auipc	a0,0x6
    8000155e:	c6e50513          	addi	a0,a0,-914 # 800071c8 <etext+0x1c8>
    80001562:	a8eff0ef          	jal	800007f0 <panic>
      kfree(mem);
    80001566:	8526                	mv	a0,s1
    80001568:	d30ff0ef          	jal	80000a98 <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    8000156c:	4685                	li	a3,1
    8000156e:	00c95613          	srli	a2,s2,0xc
    80001572:	4581                	li	a1,0
    80001574:	8556                	mv	a0,s5
    80001576:	cbfff0ef          	jal	80001234 <uvmunmap>
  return -1;
    8000157a:	557d                	li	a0,-1
}
    8000157c:	60a6                	ld	ra,72(sp)
    8000157e:	6406                	ld	s0,64(sp)
    80001580:	74e2                	ld	s1,56(sp)
    80001582:	7942                	ld	s2,48(sp)
    80001584:	79a2                	ld	s3,40(sp)
    80001586:	7a02                	ld	s4,32(sp)
    80001588:	6ae2                	ld	s5,24(sp)
    8000158a:	6b42                	ld	s6,16(sp)
    8000158c:	6ba2                	ld	s7,8(sp)
    8000158e:	6161                	addi	sp,sp,80
    80001590:	8082                	ret
  return 0;
    80001592:	4501                	li	a0,0
}
    80001594:	8082                	ret

0000000080001596 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    80001596:	1141                	addi	sp,sp,-16
    80001598:	e406                	sd	ra,8(sp)
    8000159a:	e022                	sd	s0,0(sp)
    8000159c:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    8000159e:	4601                	li	a2,0
    800015a0:	a25ff0ef          	jal	80000fc4 <walk>
  if(pte == 0)
    800015a4:	c901                	beqz	a0,800015b4 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800015a6:	611c                	ld	a5,0(a0)
    800015a8:	9bbd                	andi	a5,a5,-17
    800015aa:	e11c                	sd	a5,0(a0)
}
    800015ac:	60a2                	ld	ra,8(sp)
    800015ae:	6402                	ld	s0,0(sp)
    800015b0:	0141                	addi	sp,sp,16
    800015b2:	8082                	ret
    panic("uvmclear");
    800015b4:	00006517          	auipc	a0,0x6
    800015b8:	c3450513          	addi	a0,a0,-972 # 800071e8 <etext+0x1e8>
    800015bc:	a34ff0ef          	jal	800007f0 <panic>

00000000800015c0 <copyout>:
copyout(pagetable_t pagetable, uint64 dstva, char *src, uint64 len)
{
  uint64 n, va0, pa0;
  pte_t *pte;

  while(len > 0){
    800015c0:	c6cd                	beqz	a3,8000166a <copyout+0xaa>
{
    800015c2:	711d                	addi	sp,sp,-96
    800015c4:	ec86                	sd	ra,88(sp)
    800015c6:	e8a2                	sd	s0,80(sp)
    800015c8:	e4a6                	sd	s1,72(sp)
    800015ca:	e0ca                	sd	s2,64(sp)
    800015cc:	fc4e                	sd	s3,56(sp)
    800015ce:	f852                	sd	s4,48(sp)
    800015d0:	f456                	sd	s5,40(sp)
    800015d2:	f05a                	sd	s6,32(sp)
    800015d4:	ec5e                	sd	s7,24(sp)
    800015d6:	e862                	sd	s8,16(sp)
    800015d8:	e466                	sd	s9,8(sp)
    800015da:	1080                	addi	s0,sp,96
    800015dc:	8c2a                	mv	s8,a0
    800015de:	84ae                	mv	s1,a1
    800015e0:	8ab2                	mv	s5,a2
    800015e2:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(dstva);
    800015e4:	7cfd                	lui	s9,0xfffff
    if(va0 >= MAXVA)
    800015e6:	5bfd                	li	s7,-1
    800015e8:	01abdb93          	srli	s7,s7,0x1a
    pte = walk(pagetable, va0, 0);
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
       (*pte & PTE_W) == 0)
      return -1;
    pa0 = PTE2PA(*pte);
    n = PGSIZE - (dstva - va0);
    800015ec:	6b05                	lui	s6,0x1
    800015ee:	a089                	j	80001630 <copyout+0x70>
      return -1;
    800015f0:	557d                	li	a0,-1
    len -= n;
    src += n;
    dstva = va0 + PGSIZE;
  }
  return 0;
}
    800015f2:	60e6                	ld	ra,88(sp)
    800015f4:	6446                	ld	s0,80(sp)
    800015f6:	64a6                	ld	s1,72(sp)
    800015f8:	6906                	ld	s2,64(sp)
    800015fa:	79e2                	ld	s3,56(sp)
    800015fc:	7a42                	ld	s4,48(sp)
    800015fe:	7aa2                	ld	s5,40(sp)
    80001600:	7b02                	ld	s6,32(sp)
    80001602:	6be2                	ld	s7,24(sp)
    80001604:	6c42                	ld	s8,16(sp)
    80001606:	6ca2                	ld	s9,8(sp)
    80001608:	6125                	addi	sp,sp,96
    8000160a:	8082                	ret
    pa0 = PTE2PA(*pte);
    8000160c:	83a9                	srli	a5,a5,0xa
    8000160e:	07b2                	slli	a5,a5,0xc
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001610:	03449513          	slli	a0,s1,0x34
    80001614:	9151                	srli	a0,a0,0x34
    80001616:	0009061b          	sext.w	a2,s2
    8000161a:	85d6                	mv	a1,s5
    8000161c:	953e                	add	a0,a0,a5
    8000161e:	f6eff0ef          	jal	80000d8c <memmove>
    len -= n;
    80001622:	412a0a33          	sub	s4,s4,s2
    src += n;
    80001626:	9aca                	add	s5,s5,s2
    dstva = va0 + PGSIZE;
    80001628:	016984b3          	add	s1,s3,s6
  while(len > 0){
    8000162c:	020a0d63          	beqz	s4,80001666 <copyout+0xa6>
    va0 = PGROUNDDOWN(dstva);
    80001630:	0194f9b3          	and	s3,s1,s9
    if(va0 >= MAXVA)
    80001634:	fb3beee3          	bltu	s7,s3,800015f0 <copyout+0x30>
    pte = walk(pagetable, va0, 0);
    80001638:	4601                	li	a2,0
    8000163a:	85ce                	mv	a1,s3
    8000163c:	8562                	mv	a0,s8
    8000163e:	987ff0ef          	jal	80000fc4 <walk>
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80001642:	d55d                	beqz	a0,800015f0 <copyout+0x30>
    80001644:	611c                	ld	a5,0(a0)
    80001646:	0017f713          	andi	a4,a5,1
    8000164a:	d35d                	beqz	a4,800015f0 <copyout+0x30>
    8000164c:	0107f713          	andi	a4,a5,16
    80001650:	d345                	beqz	a4,800015f0 <copyout+0x30>
       (*pte & PTE_W) == 0)
    80001652:	0047f713          	andi	a4,a5,4
    if(pte == 0 || (*pte & PTE_V) == 0 || (*pte & PTE_U) == 0 ||
    80001656:	df49                	beqz	a4,800015f0 <copyout+0x30>
    n = PGSIZE - (dstva - va0);
    80001658:	40998933          	sub	s2,s3,s1
    8000165c:	995a                	add	s2,s2,s6
    if(n > len)
    8000165e:	fb2a77e3          	bgeu	s4,s2,8000160c <copyout+0x4c>
    80001662:	8952                	mv	s2,s4
    80001664:	b765                	j	8000160c <copyout+0x4c>
  return 0;
    80001666:	4501                	li	a0,0
    80001668:	b769                	j	800015f2 <copyout+0x32>
    8000166a:	4501                	li	a0,0
}
    8000166c:	8082                	ret

000000008000166e <copyin>:
int
copyin(pagetable_t pagetable, char *dst, uint64 srcva, uint64 len)
{
  uint64 n, va0, pa0;

  while(len > 0){
    8000166e:	c2c9                	beqz	a3,800016f0 <copyin+0x82>
{
    80001670:	715d                	addi	sp,sp,-80
    80001672:	e486                	sd	ra,72(sp)
    80001674:	e0a2                	sd	s0,64(sp)
    80001676:	fc26                	sd	s1,56(sp)
    80001678:	f84a                	sd	s2,48(sp)
    8000167a:	f44e                	sd	s3,40(sp)
    8000167c:	f052                	sd	s4,32(sp)
    8000167e:	ec56                	sd	s5,24(sp)
    80001680:	e85a                	sd	s6,16(sp)
    80001682:	e45e                	sd	s7,8(sp)
    80001684:	e062                	sd	s8,0(sp)
    80001686:	0880                	addi	s0,sp,80
    80001688:	8baa                	mv	s7,a0
    8000168a:	8aae                	mv	s5,a1
    8000168c:	84b2                	mv	s1,a2
    8000168e:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80001690:	7c7d                	lui	s8,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80001692:	6b05                	lui	s6,0x1
    80001694:	a00d                	j	800016b6 <copyin+0x48>
    if(n > len)
      n = len;
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80001696:	03449593          	slli	a1,s1,0x34
    8000169a:	91d1                	srli	a1,a1,0x34
    8000169c:	0009061b          	sext.w	a2,s2
    800016a0:	95aa                	add	a1,a1,a0
    800016a2:	8556                	mv	a0,s5
    800016a4:	ee8ff0ef          	jal	80000d8c <memmove>

    len -= n;
    800016a8:	412989b3          	sub	s3,s3,s2
    dst += n;
    800016ac:	9aca                	add	s5,s5,s2
    srcva = va0 + PGSIZE;
    800016ae:	016a04b3          	add	s1,s4,s6
  while(len > 0){
    800016b2:	02098063          	beqz	s3,800016d2 <copyin+0x64>
    va0 = PGROUNDDOWN(srcva);
    800016b6:	0184fa33          	and	s4,s1,s8
    pa0 = walkaddr(pagetable, va0);
    800016ba:	85d2                	mv	a1,s4
    800016bc:	855e                	mv	a0,s7
    800016be:	99fff0ef          	jal	8000105c <walkaddr>
    if(pa0 == 0)
    800016c2:	c50d                	beqz	a0,800016ec <copyin+0x7e>
    n = PGSIZE - (srcva - va0);
    800016c4:	409a0933          	sub	s2,s4,s1
    800016c8:	995a                	add	s2,s2,s6
    if(n > len)
    800016ca:	fd29f6e3          	bgeu	s3,s2,80001696 <copyin+0x28>
    800016ce:	894e                	mv	s2,s3
    800016d0:	b7d9                	j	80001696 <copyin+0x28>
  }
  return 0;
    800016d2:	4501                	li	a0,0
}
    800016d4:	60a6                	ld	ra,72(sp)
    800016d6:	6406                	ld	s0,64(sp)
    800016d8:	74e2                	ld	s1,56(sp)
    800016da:	7942                	ld	s2,48(sp)
    800016dc:	79a2                	ld	s3,40(sp)
    800016de:	7a02                	ld	s4,32(sp)
    800016e0:	6ae2                	ld	s5,24(sp)
    800016e2:	6b42                	ld	s6,16(sp)
    800016e4:	6ba2                	ld	s7,8(sp)
    800016e6:	6c02                	ld	s8,0(sp)
    800016e8:	6161                	addi	sp,sp,80
    800016ea:	8082                	ret
      return -1;
    800016ec:	557d                	li	a0,-1
    800016ee:	b7dd                	j	800016d4 <copyin+0x66>
  return 0;
    800016f0:	4501                	li	a0,0
}
    800016f2:	8082                	ret

00000000800016f4 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    800016f4:	cac5                	beqz	a3,800017a4 <copyinstr+0xb0>
{
    800016f6:	715d                	addi	sp,sp,-80
    800016f8:	e486                	sd	ra,72(sp)
    800016fa:	e0a2                	sd	s0,64(sp)
    800016fc:	fc26                	sd	s1,56(sp)
    800016fe:	f84a                	sd	s2,48(sp)
    80001700:	f44e                	sd	s3,40(sp)
    80001702:	f052                	sd	s4,32(sp)
    80001704:	ec56                	sd	s5,24(sp)
    80001706:	e85a                	sd	s6,16(sp)
    80001708:	e45e                	sd	s7,8(sp)
    8000170a:	0880                	addi	s0,sp,80
    8000170c:	8aaa                	mv	s5,a0
    8000170e:	84ae                	mv	s1,a1
    80001710:	8bb2                	mv	s7,a2
    80001712:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80001714:	7b7d                	lui	s6,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80001716:	6a05                	lui	s4,0x1
    80001718:	a82d                	j	80001752 <copyinstr+0x5e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    8000171a:	00078023          	sb	zero,0(a5)
        got_null = 1;
    8000171e:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80001720:	0017c793          	xori	a5,a5,1
    80001724:	40f0053b          	negw	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    80001728:	60a6                	ld	ra,72(sp)
    8000172a:	6406                	ld	s0,64(sp)
    8000172c:	74e2                	ld	s1,56(sp)
    8000172e:	7942                	ld	s2,48(sp)
    80001730:	79a2                	ld	s3,40(sp)
    80001732:	7a02                	ld	s4,32(sp)
    80001734:	6ae2                	ld	s5,24(sp)
    80001736:	6b42                	ld	s6,16(sp)
    80001738:	6ba2                	ld	s7,8(sp)
    8000173a:	6161                	addi	sp,sp,80
    8000173c:	8082                	ret
    8000173e:	fff98713          	addi	a4,s3,-1 # fff <_entry-0x7ffff001>
    80001742:	9726                	add	a4,a4,s1
      --max;
    80001744:	40b709b3          	sub	s3,a4,a1
    srcva = va0 + PGSIZE;
    80001748:	01490bb3          	add	s7,s2,s4
  while(got_null == 0 && max > 0){
    8000174c:	04e58463          	beq	a1,a4,80001794 <copyinstr+0xa0>
{
    80001750:	84be                	mv	s1,a5
    va0 = PGROUNDDOWN(srcva);
    80001752:	016bf933          	and	s2,s7,s6
    pa0 = walkaddr(pagetable, va0);
    80001756:	85ca                	mv	a1,s2
    80001758:	8556                	mv	a0,s5
    8000175a:	903ff0ef          	jal	8000105c <walkaddr>
    if(pa0 == 0)
    8000175e:	cd0d                	beqz	a0,80001798 <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    80001760:	41790633          	sub	a2,s2,s7
    80001764:	9652                	add	a2,a2,s4
    if(n > max)
    80001766:	00c9f363          	bgeu	s3,a2,8000176c <copyinstr+0x78>
    8000176a:	864e                	mv	a2,s3
    while(n > 0){
    8000176c:	ca05                	beqz	a2,8000179c <copyinstr+0xa8>
    char *p = (char *) (pa0 + (srcva - va0));
    8000176e:	034b9693          	slli	a3,s7,0x34
    80001772:	92d1                	srli	a3,a3,0x34
    80001774:	96aa                	add	a3,a3,a0
    80001776:	87a6                	mv	a5,s1
      if(*p == '\0'){
    80001778:	8e85                	sub	a3,a3,s1
    while(n > 0){
    8000177a:	9626                	add	a2,a2,s1
    8000177c:	85be                	mv	a1,a5
      if(*p == '\0'){
    8000177e:	00f68733          	add	a4,a3,a5
    80001782:	00074703          	lbu	a4,0(a4)
    80001786:	db51                	beqz	a4,8000171a <copyinstr+0x26>
        *dst = *p;
    80001788:	00e78023          	sb	a4,0(a5)
      dst++;
    8000178c:	0785                	addi	a5,a5,1
    while(n > 0){
    8000178e:	fec797e3          	bne	a5,a2,8000177c <copyinstr+0x88>
    80001792:	b775                	j	8000173e <copyinstr+0x4a>
    srcva = va0 + PGSIZE;
    80001794:	4781                	li	a5,0
    80001796:	b769                	j	80001720 <copyinstr+0x2c>
      return -1;
    80001798:	557d                	li	a0,-1
    8000179a:	b779                	j	80001728 <copyinstr+0x34>
    srcva = va0 + PGSIZE;
    8000179c:	6b85                	lui	s7,0x1
    8000179e:	9bca                	add	s7,s7,s2
    800017a0:	87a6                	mv	a5,s1
    800017a2:	b77d                	j	80001750 <copyinstr+0x5c>
    800017a4:	4781                	li	a5,0
  if(got_null){
    800017a6:	0017c793          	xori	a5,a5,1
    800017aa:	40f0053b          	negw	a0,a5
}
    800017ae:	8082                	ret

00000000800017b0 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    800017b0:	715d                	addi	sp,sp,-80
    800017b2:	e486                	sd	ra,72(sp)
    800017b4:	e0a2                	sd	s0,64(sp)
    800017b6:	fc26                	sd	s1,56(sp)
    800017b8:	f84a                	sd	s2,48(sp)
    800017ba:	f44e                	sd	s3,40(sp)
    800017bc:	f052                	sd	s4,32(sp)
    800017be:	ec56                	sd	s5,24(sp)
    800017c0:	e85a                	sd	s6,16(sp)
    800017c2:	e45e                	sd	s7,8(sp)
    800017c4:	0880                	addi	s0,sp,80
    800017c6:	8aaa                	mv	s5,a0
    800017c8:	4481                	li	s1,0
  
  for(p = proc; p < &proc[NPROC]; p++) {
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    800017ca:	000a57b7          	lui	a5,0xa5
    800017ce:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    800017d2:	07b2                	slli	a5,a5,0xc
    800017d4:	fa578793          	addi	a5,a5,-91
    800017d8:	4fa50937          	lui	s2,0x4fa50
    800017dc:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    800017e0:	1902                	slli	s2,s2,0x20
    800017e2:	993e                	add	s2,s2,a5
    800017e4:	040009b7          	lui	s3,0x4000
    800017e8:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800017ea:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800017ec:	4b99                	li	s7,6
    800017ee:	6b05                	lui	s6,0x1
  for(p = proc; p < &proc[NPROC]; p++) {
    800017f0:	6a19                	lui	s4,0x6
    800017f2:	a00a0a13          	addi	s4,s4,-1536 # 5a00 <_entry-0x7fffa600>
    char *pa = kalloc();
    800017f6:	b8aff0ef          	jal	80000b80 <kalloc>
    800017fa:	862a                	mv	a2,a0
    if(pa == 0)
    800017fc:	cd15                	beqz	a0,80001838 <proc_mapstacks+0x88>
    uint64 va = KSTACK((int) (p - proc));
    800017fe:	4034d593          	srai	a1,s1,0x3
    80001802:	032585b3          	mul	a1,a1,s2
    80001806:	05b6                	slli	a1,a1,0xd
    80001808:	6789                	lui	a5,0x2
    8000180a:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    8000180c:	875e                	mv	a4,s7
    8000180e:	86da                	mv	a3,s6
    80001810:	40b985b3          	sub	a1,s3,a1
    80001814:	8556                	mv	a0,s5
    80001816:	931ff0ef          	jal	80001146 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    8000181a:	16848493          	addi	s1,s1,360
    8000181e:	fd449ce3          	bne	s1,s4,800017f6 <proc_mapstacks+0x46>
  }
}
    80001822:	60a6                	ld	ra,72(sp)
    80001824:	6406                	ld	s0,64(sp)
    80001826:	74e2                	ld	s1,56(sp)
    80001828:	7942                	ld	s2,48(sp)
    8000182a:	79a2                	ld	s3,40(sp)
    8000182c:	7a02                	ld	s4,32(sp)
    8000182e:	6ae2                	ld	s5,24(sp)
    80001830:	6b42                	ld	s6,16(sp)
    80001832:	6ba2                	ld	s7,8(sp)
    80001834:	6161                	addi	sp,sp,80
    80001836:	8082                	ret
      panic("kalloc");
    80001838:	00006517          	auipc	a0,0x6
    8000183c:	9c050513          	addi	a0,a0,-1600 # 800071f8 <etext+0x1f8>
    80001840:	fb1fe0ef          	jal	800007f0 <panic>

0000000080001844 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80001844:	7139                	addi	sp,sp,-64
    80001846:	fc06                	sd	ra,56(sp)
    80001848:	f822                	sd	s0,48(sp)
    8000184a:	f426                	sd	s1,40(sp)
    8000184c:	f04a                	sd	s2,32(sp)
    8000184e:	ec4e                	sd	s3,24(sp)
    80001850:	e852                	sd	s4,16(sp)
    80001852:	e456                	sd	s5,8(sp)
    80001854:	e05a                	sd	s6,0(sp)
    80001856:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80001858:	00006597          	auipc	a1,0x6
    8000185c:	9a858593          	addi	a1,a1,-1624 # 80007200 <etext+0x200>
    80001860:	0000e517          	auipc	a0,0xe
    80001864:	24050513          	addi	a0,a0,576 # 8000faa0 <pid_lock>
    80001868:	b72ff0ef          	jal	80000bda <initlock>
  initlock(&wait_lock, "wait_lock");
    8000186c:	00006597          	auipc	a1,0x6
    80001870:	99c58593          	addi	a1,a1,-1636 # 80007208 <etext+0x208>
    80001874:	0000e517          	auipc	a0,0xe
    80001878:	24450513          	addi	a0,a0,580 # 8000fab8 <wait_lock>
    8000187c:	b5eff0ef          	jal	80000bda <initlock>
    80001880:	4901                	li	s2,0
  for(p = proc; p < &proc[NPROC]; p++) {
    80001882:	0000e497          	auipc	s1,0xe
    80001886:	64e48493          	addi	s1,s1,1614 # 8000fed0 <proc>
      initlock(&p->lock, "proc");
    8000188a:	00006a97          	auipc	s5,0x6
    8000188e:	98ea8a93          	addi	s5,s5,-1650 # 80007218 <etext+0x218>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80001892:	000a57b7          	lui	a5,0xa5
    80001896:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    8000189a:	07b2                	slli	a5,a5,0xc
    8000189c:	fa578793          	addi	a5,a5,-91
    800018a0:	4fa509b7          	lui	s3,0x4fa50
    800018a4:	a4f98993          	addi	s3,s3,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    800018a8:	1982                	slli	s3,s3,0x20
    800018aa:	99be                	add	s3,s3,a5
    800018ac:	04000a37          	lui	s4,0x4000
    800018b0:	1a7d                	addi	s4,s4,-1 # 3ffffff <_entry-0x7c000001>
    800018b2:	0a32                	slli	s4,s4,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    800018b4:	00014b17          	auipc	s6,0x14
    800018b8:	01cb0b13          	addi	s6,s6,28 # 800158d0 <tickslock>
      initlock(&p->lock, "proc");
    800018bc:	85d6                	mv	a1,s5
    800018be:	8526                	mv	a0,s1
    800018c0:	b1aff0ef          	jal	80000bda <initlock>
      p->state = UNUSED;
    800018c4:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    800018c8:	40395793          	srai	a5,s2,0x3
    800018cc:	033787b3          	mul	a5,a5,s3
    800018d0:	07b6                	slli	a5,a5,0xd
    800018d2:	6709                	lui	a4,0x2
    800018d4:	9fb9                	addw	a5,a5,a4
    800018d6:	40fa07b3          	sub	a5,s4,a5
    800018da:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    800018dc:	16848493          	addi	s1,s1,360
    800018e0:	16890913          	addi	s2,s2,360
    800018e4:	fd649ce3          	bne	s1,s6,800018bc <procinit+0x78>
  }
}
    800018e8:	70e2                	ld	ra,56(sp)
    800018ea:	7442                	ld	s0,48(sp)
    800018ec:	74a2                	ld	s1,40(sp)
    800018ee:	7902                	ld	s2,32(sp)
    800018f0:	69e2                	ld	s3,24(sp)
    800018f2:	6a42                	ld	s4,16(sp)
    800018f4:	6aa2                	ld	s5,8(sp)
    800018f6:	6b02                	ld	s6,0(sp)
    800018f8:	6121                	addi	sp,sp,64
    800018fa:	8082                	ret

00000000800018fc <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    800018fc:	1141                	addi	sp,sp,-16
    800018fe:	e406                	sd	ra,8(sp)
    80001900:	e022                	sd	s0,0(sp)
    80001902:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80001904:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80001906:	2501                	sext.w	a0,a0
    80001908:	60a2                	ld	ra,8(sp)
    8000190a:	6402                	ld	s0,0(sp)
    8000190c:	0141                	addi	sp,sp,16
    8000190e:	8082                	ret

0000000080001910 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80001910:	1141                	addi	sp,sp,-16
    80001912:	e406                	sd	ra,8(sp)
    80001914:	e022                	sd	s0,0(sp)
    80001916:	0800                	addi	s0,sp,16
    80001918:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    8000191a:	2781                	sext.w	a5,a5
    8000191c:	079e                	slli	a5,a5,0x7
  return c;
}
    8000191e:	0000e517          	auipc	a0,0xe
    80001922:	1b250513          	addi	a0,a0,434 # 8000fad0 <cpus>
    80001926:	953e                	add	a0,a0,a5
    80001928:	60a2                	ld	ra,8(sp)
    8000192a:	6402                	ld	s0,0(sp)
    8000192c:	0141                	addi	sp,sp,16
    8000192e:	8082                	ret

0000000080001930 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80001930:	1101                	addi	sp,sp,-32
    80001932:	ec06                	sd	ra,24(sp)
    80001934:	e822                	sd	s0,16(sp)
    80001936:	e426                	sd	s1,8(sp)
    80001938:	1000                	addi	s0,sp,32
  push_off();
    8000193a:	ae6ff0ef          	jal	80000c20 <push_off>
    8000193e:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001940:	2781                	sext.w	a5,a5
    80001942:	079e                	slli	a5,a5,0x7
    80001944:	0000e717          	auipc	a4,0xe
    80001948:	15c70713          	addi	a4,a4,348 # 8000faa0 <pid_lock>
    8000194c:	97ba                	add	a5,a5,a4
    8000194e:	7b9c                	ld	a5,48(a5)
    80001950:	84be                	mv	s1,a5
  pop_off();
    80001952:	b52ff0ef          	jal	80000ca4 <pop_off>
  return p;
}
    80001956:	8526                	mv	a0,s1
    80001958:	60e2                	ld	ra,24(sp)
    8000195a:	6442                	ld	s0,16(sp)
    8000195c:	64a2                	ld	s1,8(sp)
    8000195e:	6105                	addi	sp,sp,32
    80001960:	8082                	ret

0000000080001962 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001962:	1141                	addi	sp,sp,-16
    80001964:	e406                	sd	ra,8(sp)
    80001966:	e022                	sd	s0,0(sp)
    80001968:	0800                	addi	s0,sp,16
  static int first = 1;

  // Still holding p->lock from scheduler.
  release(&myproc()->lock);
    8000196a:	fc7ff0ef          	jal	80001930 <myproc>
    8000196e:	b86ff0ef          	jal	80000cf4 <release>

  if (first) {
    80001972:	00006797          	auipc	a5,0x6
    80001976:	f7e7a783          	lw	a5,-130(a5) # 800078f0 <first.1>
    8000197a:	e799                	bnez	a5,80001988 <forkret+0x26>
    first = 0;
    // ensure other cores see first=0.
    __sync_synchronize();
  }

  usertrapret();
    8000197c:	2a7000ef          	jal	80002422 <usertrapret>
}
    80001980:	60a2                	ld	ra,8(sp)
    80001982:	6402                	ld	s0,0(sp)
    80001984:	0141                	addi	sp,sp,16
    80001986:	8082                	ret
    fsinit(ROOTDEV);
    80001988:	4505                	li	a0,1
    8000198a:	740010ef          	jal	800030ca <fsinit>
    first = 0;
    8000198e:	00006797          	auipc	a5,0x6
    80001992:	f607a123          	sw	zero,-158(a5) # 800078f0 <first.1>
    __sync_synchronize();
    80001996:	0330000f          	fence	rw,rw
    8000199a:	b7cd                	j	8000197c <forkret+0x1a>

000000008000199c <allocpid>:
{
    8000199c:	1101                	addi	sp,sp,-32
    8000199e:	ec06                	sd	ra,24(sp)
    800019a0:	e822                	sd	s0,16(sp)
    800019a2:	e426                	sd	s1,8(sp)
    800019a4:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    800019a6:	0000e517          	auipc	a0,0xe
    800019aa:	0fa50513          	addi	a0,a0,250 # 8000faa0 <pid_lock>
    800019ae:	ab6ff0ef          	jal	80000c64 <acquire>
  pid = nextpid;
    800019b2:	00006797          	auipc	a5,0x6
    800019b6:	f4278793          	addi	a5,a5,-190 # 800078f4 <nextpid>
    800019ba:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    800019bc:	0014871b          	addiw	a4,s1,1
    800019c0:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    800019c2:	0000e517          	auipc	a0,0xe
    800019c6:	0de50513          	addi	a0,a0,222 # 8000faa0 <pid_lock>
    800019ca:	b2aff0ef          	jal	80000cf4 <release>
}
    800019ce:	8526                	mv	a0,s1
    800019d0:	60e2                	ld	ra,24(sp)
    800019d2:	6442                	ld	s0,16(sp)
    800019d4:	64a2                	ld	s1,8(sp)
    800019d6:	6105                	addi	sp,sp,32
    800019d8:	8082                	ret

00000000800019da <proc_pagetable>:
{
    800019da:	1101                	addi	sp,sp,-32
    800019dc:	ec06                	sd	ra,24(sp)
    800019de:	e822                	sd	s0,16(sp)
    800019e0:	e426                	sd	s1,8(sp)
    800019e2:	e04a                	sd	s2,0(sp)
    800019e4:	1000                	addi	s0,sp,32
    800019e6:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    800019e8:	909ff0ef          	jal	800012f0 <uvmcreate>
    800019ec:	84aa                	mv	s1,a0
  if(pagetable == 0)
    800019ee:	cd05                	beqz	a0,80001a26 <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    800019f0:	4729                	li	a4,10
    800019f2:	00004697          	auipc	a3,0x4
    800019f6:	60e68693          	addi	a3,a3,1550 # 80006000 <_trampoline>
    800019fa:	6605                	lui	a2,0x1
    800019fc:	040005b7          	lui	a1,0x4000
    80001a00:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a02:	05b2                	slli	a1,a1,0xc
    80001a04:	e90ff0ef          	jal	80001094 <mappages>
    80001a08:	02054663          	bltz	a0,80001a34 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001a0c:	4719                	li	a4,6
    80001a0e:	05893683          	ld	a3,88(s2)
    80001a12:	6605                	lui	a2,0x1
    80001a14:	020005b7          	lui	a1,0x2000
    80001a18:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a1a:	05b6                	slli	a1,a1,0xd
    80001a1c:	8526                	mv	a0,s1
    80001a1e:	e76ff0ef          	jal	80001094 <mappages>
    80001a22:	00054f63          	bltz	a0,80001a40 <proc_pagetable+0x66>
}
    80001a26:	8526                	mv	a0,s1
    80001a28:	60e2                	ld	ra,24(sp)
    80001a2a:	6442                	ld	s0,16(sp)
    80001a2c:	64a2                	ld	s1,8(sp)
    80001a2e:	6902                	ld	s2,0(sp)
    80001a30:	6105                	addi	sp,sp,32
    80001a32:	8082                	ret
    uvmfree(pagetable, 0);
    80001a34:	4581                	li	a1,0
    80001a36:	8526                	mv	a0,s1
    80001a38:	a7fff0ef          	jal	800014b6 <uvmfree>
    return 0;
    80001a3c:	4481                	li	s1,0
    80001a3e:	b7e5                	j	80001a26 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a40:	4681                	li	a3,0
    80001a42:	4605                	li	a2,1
    80001a44:	040005b7          	lui	a1,0x4000
    80001a48:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a4a:	05b2                	slli	a1,a1,0xc
    80001a4c:	8526                	mv	a0,s1
    80001a4e:	fe6ff0ef          	jal	80001234 <uvmunmap>
    uvmfree(pagetable, 0);
    80001a52:	4581                	li	a1,0
    80001a54:	8526                	mv	a0,s1
    80001a56:	a61ff0ef          	jal	800014b6 <uvmfree>
    return 0;
    80001a5a:	b7cd                	j	80001a3c <proc_pagetable+0x62>

0000000080001a5c <proc_freepagetable>:
{
    80001a5c:	1101                	addi	sp,sp,-32
    80001a5e:	ec06                	sd	ra,24(sp)
    80001a60:	e822                	sd	s0,16(sp)
    80001a62:	e426                	sd	s1,8(sp)
    80001a64:	e04a                	sd	s2,0(sp)
    80001a66:	1000                	addi	s0,sp,32
    80001a68:	84aa                	mv	s1,a0
    80001a6a:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001a6c:	4681                	li	a3,0
    80001a6e:	4605                	li	a2,1
    80001a70:	040005b7          	lui	a1,0x4000
    80001a74:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a76:	05b2                	slli	a1,a1,0xc
    80001a78:	fbcff0ef          	jal	80001234 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001a7c:	4681                	li	a3,0
    80001a7e:	4605                	li	a2,1
    80001a80:	020005b7          	lui	a1,0x2000
    80001a84:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001a86:	05b6                	slli	a1,a1,0xd
    80001a88:	8526                	mv	a0,s1
    80001a8a:	faaff0ef          	jal	80001234 <uvmunmap>
  uvmfree(pagetable, sz);
    80001a8e:	85ca                	mv	a1,s2
    80001a90:	8526                	mv	a0,s1
    80001a92:	a25ff0ef          	jal	800014b6 <uvmfree>
}
    80001a96:	60e2                	ld	ra,24(sp)
    80001a98:	6442                	ld	s0,16(sp)
    80001a9a:	64a2                	ld	s1,8(sp)
    80001a9c:	6902                	ld	s2,0(sp)
    80001a9e:	6105                	addi	sp,sp,32
    80001aa0:	8082                	ret

0000000080001aa2 <freeproc>:
{
    80001aa2:	1101                	addi	sp,sp,-32
    80001aa4:	ec06                	sd	ra,24(sp)
    80001aa6:	e822                	sd	s0,16(sp)
    80001aa8:	e426                	sd	s1,8(sp)
    80001aaa:	1000                	addi	s0,sp,32
    80001aac:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001aae:	6d28                	ld	a0,88(a0)
    80001ab0:	c119                	beqz	a0,80001ab6 <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001ab2:	fe7fe0ef          	jal	80000a98 <kfree>
  p->trapframe = 0;
    80001ab6:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001aba:	68a8                	ld	a0,80(s1)
    80001abc:	c501                	beqz	a0,80001ac4 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001abe:	64ac                	ld	a1,72(s1)
    80001ac0:	f9dff0ef          	jal	80001a5c <proc_freepagetable>
  p->pagetable = 0;
    80001ac4:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001ac8:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001acc:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001ad0:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001ad4:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001ad8:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001adc:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001ae0:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001ae4:	0004ac23          	sw	zero,24(s1)
}
    80001ae8:	60e2                	ld	ra,24(sp)
    80001aea:	6442                	ld	s0,16(sp)
    80001aec:	64a2                	ld	s1,8(sp)
    80001aee:	6105                	addi	sp,sp,32
    80001af0:	8082                	ret

0000000080001af2 <allocproc>:
{
    80001af2:	1101                	addi	sp,sp,-32
    80001af4:	ec06                	sd	ra,24(sp)
    80001af6:	e822                	sd	s0,16(sp)
    80001af8:	e426                	sd	s1,8(sp)
    80001afa:	e04a                	sd	s2,0(sp)
    80001afc:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001afe:	0000e497          	auipc	s1,0xe
    80001b02:	3d248493          	addi	s1,s1,978 # 8000fed0 <proc>
    80001b06:	00014917          	auipc	s2,0x14
    80001b0a:	dca90913          	addi	s2,s2,-566 # 800158d0 <tickslock>
    acquire(&p->lock);
    80001b0e:	8526                	mv	a0,s1
    80001b10:	954ff0ef          	jal	80000c64 <acquire>
    if(p->state == UNUSED) {
    80001b14:	4c9c                	lw	a5,24(s1)
    80001b16:	cb91                	beqz	a5,80001b2a <allocproc+0x38>
      release(&p->lock);
    80001b18:	8526                	mv	a0,s1
    80001b1a:	9daff0ef          	jal	80000cf4 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b1e:	16848493          	addi	s1,s1,360
    80001b22:	ff2496e3          	bne	s1,s2,80001b0e <allocproc+0x1c>
  return 0;
    80001b26:	4481                	li	s1,0
    80001b28:	a089                	j	80001b6a <allocproc+0x78>
  p->pid = allocpid();
    80001b2a:	e73ff0ef          	jal	8000199c <allocpid>
    80001b2e:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001b30:	4785                	li	a5,1
    80001b32:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001b34:	84cff0ef          	jal	80000b80 <kalloc>
    80001b38:	892a                	mv	s2,a0
    80001b3a:	eca8                	sd	a0,88(s1)
    80001b3c:	cd15                	beqz	a0,80001b78 <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    80001b3e:	8526                	mv	a0,s1
    80001b40:	e9bff0ef          	jal	800019da <proc_pagetable>
    80001b44:	892a                	mv	s2,a0
    80001b46:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001b48:	c121                	beqz	a0,80001b88 <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80001b4a:	07000613          	li	a2,112
    80001b4e:	4581                	li	a1,0
    80001b50:	06048513          	addi	a0,s1,96
    80001b54:	9dcff0ef          	jal	80000d30 <memset>
  p->context.ra = (uint64)forkret;
    80001b58:	00000797          	auipc	a5,0x0
    80001b5c:	e0a78793          	addi	a5,a5,-502 # 80001962 <forkret>
    80001b60:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001b62:	60bc                	ld	a5,64(s1)
    80001b64:	6705                	lui	a4,0x1
    80001b66:	97ba                	add	a5,a5,a4
    80001b68:	f4bc                	sd	a5,104(s1)
}
    80001b6a:	8526                	mv	a0,s1
    80001b6c:	60e2                	ld	ra,24(sp)
    80001b6e:	6442                	ld	s0,16(sp)
    80001b70:	64a2                	ld	s1,8(sp)
    80001b72:	6902                	ld	s2,0(sp)
    80001b74:	6105                	addi	sp,sp,32
    80001b76:	8082                	ret
    freeproc(p);
    80001b78:	8526                	mv	a0,s1
    80001b7a:	f29ff0ef          	jal	80001aa2 <freeproc>
    release(&p->lock);
    80001b7e:	8526                	mv	a0,s1
    80001b80:	974ff0ef          	jal	80000cf4 <release>
    return 0;
    80001b84:	84ca                	mv	s1,s2
    80001b86:	b7d5                	j	80001b6a <allocproc+0x78>
    freeproc(p);
    80001b88:	8526                	mv	a0,s1
    80001b8a:	f19ff0ef          	jal	80001aa2 <freeproc>
    release(&p->lock);
    80001b8e:	8526                	mv	a0,s1
    80001b90:	964ff0ef          	jal	80000cf4 <release>
    return 0;
    80001b94:	84ca                	mv	s1,s2
    80001b96:	bfd1                	j	80001b6a <allocproc+0x78>

0000000080001b98 <userinit>:
{
    80001b98:	1101                	addi	sp,sp,-32
    80001b9a:	ec06                	sd	ra,24(sp)
    80001b9c:	e822                	sd	s0,16(sp)
    80001b9e:	e426                	sd	s1,8(sp)
    80001ba0:	1000                	addi	s0,sp,32
  p = allocproc();
    80001ba2:	f51ff0ef          	jal	80001af2 <allocproc>
    80001ba6:	84aa                	mv	s1,a0
  initproc = p;
    80001ba8:	00006797          	auipc	a5,0x6
    80001bac:	dca7b023          	sd	a0,-576(a5) # 80007968 <initproc>
  uvmfirst(p->pagetable, initcode, sizeof(initcode));
    80001bb0:	03400613          	li	a2,52
    80001bb4:	00006597          	auipc	a1,0x6
    80001bb8:	d4c58593          	addi	a1,a1,-692 # 80007900 <initcode>
    80001bbc:	6928                	ld	a0,80(a0)
    80001bbe:	f58ff0ef          	jal	80001316 <uvmfirst>
  p->sz = PGSIZE;
    80001bc2:	6785                	lui	a5,0x1
    80001bc4:	e4bc                	sd	a5,72(s1)
  p->trapframe->epc = 0;      // user program counter
    80001bc6:	6cb8                	ld	a4,88(s1)
    80001bc8:	00073c23          	sd	zero,24(a4) # 1018 <_entry-0x7fffefe8>
  p->trapframe->sp = PGSIZE;  // user stack pointer
    80001bcc:	6cb8                	ld	a4,88(s1)
    80001bce:	fb1c                	sd	a5,48(a4)
  safestrcpy(p->name, "initcode", sizeof(p->name));
    80001bd0:	4641                	li	a2,16
    80001bd2:	00005597          	auipc	a1,0x5
    80001bd6:	64e58593          	addi	a1,a1,1614 # 80007220 <etext+0x220>
    80001bda:	15848513          	addi	a0,s1,344
    80001bde:	a9cff0ef          	jal	80000e7a <safestrcpy>
  p->cwd = namei("/");
    80001be2:	00005517          	auipc	a0,0x5
    80001be6:	64e50513          	addi	a0,a0,1614 # 80007230 <etext+0x230>
    80001bea:	613010ef          	jal	800039fc <namei>
    80001bee:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001bf2:	478d                	li	a5,3
    80001bf4:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001bf6:	8526                	mv	a0,s1
    80001bf8:	8fcff0ef          	jal	80000cf4 <release>
}
    80001bfc:	60e2                	ld	ra,24(sp)
    80001bfe:	6442                	ld	s0,16(sp)
    80001c00:	64a2                	ld	s1,8(sp)
    80001c02:	6105                	addi	sp,sp,32
    80001c04:	8082                	ret

0000000080001c06 <growproc>:
{
    80001c06:	1101                	addi	sp,sp,-32
    80001c08:	ec06                	sd	ra,24(sp)
    80001c0a:	e822                	sd	s0,16(sp)
    80001c0c:	e426                	sd	s1,8(sp)
    80001c0e:	e04a                	sd	s2,0(sp)
    80001c10:	1000                	addi	s0,sp,32
    80001c12:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001c14:	d1dff0ef          	jal	80001930 <myproc>
    80001c18:	84aa                	mv	s1,a0
  sz = p->sz;
    80001c1a:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001c1c:	01204c63          	bgtz	s2,80001c34 <growproc+0x2e>
  } else if(n < 0){
    80001c20:	02094463          	bltz	s2,80001c48 <growproc+0x42>
  p->sz = sz;
    80001c24:	e4ac                	sd	a1,72(s1)
  return 0;
    80001c26:	4501                	li	a0,0
}
    80001c28:	60e2                	ld	ra,24(sp)
    80001c2a:	6442                	ld	s0,16(sp)
    80001c2c:	64a2                	ld	s1,8(sp)
    80001c2e:	6902                	ld	s2,0(sp)
    80001c30:	6105                	addi	sp,sp,32
    80001c32:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001c34:	4691                	li	a3,4
    80001c36:	00b90633          	add	a2,s2,a1
    80001c3a:	6928                	ld	a0,80(a0)
    80001c3c:	f7eff0ef          	jal	800013ba <uvmalloc>
    80001c40:	85aa                	mv	a1,a0
    80001c42:	f16d                	bnez	a0,80001c24 <growproc+0x1e>
      return -1;
    80001c44:	557d                	li	a0,-1
    80001c46:	b7cd                	j	80001c28 <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001c48:	00b90633          	add	a2,s2,a1
    80001c4c:	6928                	ld	a0,80(a0)
    80001c4e:	f26ff0ef          	jal	80001374 <uvmdealloc>
    80001c52:	85aa                	mv	a1,a0
    80001c54:	bfc1                	j	80001c24 <growproc+0x1e>

0000000080001c56 <fork>:
{
    80001c56:	7139                	addi	sp,sp,-64
    80001c58:	fc06                	sd	ra,56(sp)
    80001c5a:	f822                	sd	s0,48(sp)
    80001c5c:	f426                	sd	s1,40(sp)
    80001c5e:	e456                	sd	s5,8(sp)
    80001c60:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001c62:	ccfff0ef          	jal	80001930 <myproc>
    80001c66:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001c68:	e8bff0ef          	jal	80001af2 <allocproc>
    80001c6c:	c92d                	beqz	a0,80001cde <fork+0x88>
    80001c6e:	e852                	sd	s4,16(sp)
    80001c70:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001c72:	048ab603          	ld	a2,72(s5)
    80001c76:	692c                	ld	a1,80(a0)
    80001c78:	050ab503          	ld	a0,80(s5)
    80001c7c:	86dff0ef          	jal	800014e8 <uvmcopy>
    80001c80:	04054863          	bltz	a0,80001cd0 <fork+0x7a>
    80001c84:	f04a                	sd	s2,32(sp)
    80001c86:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001c88:	048ab783          	ld	a5,72(s5)
    80001c8c:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001c90:	058ab683          	ld	a3,88(s5)
    80001c94:	87b6                	mv	a5,a3
    80001c96:	058a3703          	ld	a4,88(s4)
    80001c9a:	12068693          	addi	a3,a3,288
    80001c9e:	6388                	ld	a0,0(a5)
    80001ca0:	678c                	ld	a1,8(a5)
    80001ca2:	6b90                	ld	a2,16(a5)
    80001ca4:	e308                	sd	a0,0(a4)
    80001ca6:	e70c                	sd	a1,8(a4)
    80001ca8:	eb10                	sd	a2,16(a4)
    80001caa:	6f90                	ld	a2,24(a5)
    80001cac:	ef10                	sd	a2,24(a4)
    80001cae:	02078793          	addi	a5,a5,32 # 1020 <_entry-0x7fffefe0>
    80001cb2:	02070713          	addi	a4,a4,32
    80001cb6:	fed794e3          	bne	a5,a3,80001c9e <fork+0x48>
  np->trapframe->a0 = 0;
    80001cba:	058a3783          	ld	a5,88(s4)
    80001cbe:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001cc2:	0d0a8493          	addi	s1,s5,208
    80001cc6:	0d0a0913          	addi	s2,s4,208
    80001cca:	150a8993          	addi	s3,s5,336
    80001cce:	a831                	j	80001cea <fork+0x94>
    freeproc(np);
    80001cd0:	8552                	mv	a0,s4
    80001cd2:	dd1ff0ef          	jal	80001aa2 <freeproc>
    release(&np->lock);
    80001cd6:	8552                	mv	a0,s4
    80001cd8:	81cff0ef          	jal	80000cf4 <release>
    return -1;
    80001cdc:	6a42                	ld	s4,16(sp)
    return -1;
    80001cde:	54fd                	li	s1,-1
    80001ce0:	a885                	j	80001d50 <fork+0xfa>
  for(i = 0; i < NOFILE; i++)
    80001ce2:	04a1                	addi	s1,s1,8
    80001ce4:	0921                	addi	s2,s2,8
    80001ce6:	01348963          	beq	s1,s3,80001cf8 <fork+0xa2>
    if(p->ofile[i])
    80001cea:	6088                	ld	a0,0(s1)
    80001cec:	d97d                	beqz	a0,80001ce2 <fork+0x8c>
      np->ofile[i] = filedup(p->ofile[i]);
    80001cee:	2b8020ef          	jal	80003fa6 <filedup>
    80001cf2:	00a93023          	sd	a0,0(s2)
    80001cf6:	b7f5                	j	80001ce2 <fork+0x8c>
  np->cwd = idup(p->cwd);
    80001cf8:	150ab503          	ld	a0,336(s5)
    80001cfc:	5ca010ef          	jal	800032c6 <idup>
    80001d00:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001d04:	4641                	li	a2,16
    80001d06:	158a8593          	addi	a1,s5,344
    80001d0a:	158a0513          	addi	a0,s4,344
    80001d0e:	96cff0ef          	jal	80000e7a <safestrcpy>
  pid = np->pid;
    80001d12:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    80001d16:	8552                	mv	a0,s4
    80001d18:	fddfe0ef          	jal	80000cf4 <release>
  acquire(&wait_lock);
    80001d1c:	0000e517          	auipc	a0,0xe
    80001d20:	d9c50513          	addi	a0,a0,-612 # 8000fab8 <wait_lock>
    80001d24:	f41fe0ef          	jal	80000c64 <acquire>
  np->parent = p;
    80001d28:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001d2c:	0000e517          	auipc	a0,0xe
    80001d30:	d8c50513          	addi	a0,a0,-628 # 8000fab8 <wait_lock>
    80001d34:	fc1fe0ef          	jal	80000cf4 <release>
  acquire(&np->lock);
    80001d38:	8552                	mv	a0,s4
    80001d3a:	f2bfe0ef          	jal	80000c64 <acquire>
  np->state = RUNNABLE;
    80001d3e:	478d                	li	a5,3
    80001d40:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001d44:	8552                	mv	a0,s4
    80001d46:	faffe0ef          	jal	80000cf4 <release>
    80001d4a:	7902                	ld	s2,32(sp)
    80001d4c:	69e2                	ld	s3,24(sp)
    80001d4e:	6a42                	ld	s4,16(sp)
}
    80001d50:	8526                	mv	a0,s1
    80001d52:	70e2                	ld	ra,56(sp)
    80001d54:	7442                	ld	s0,48(sp)
    80001d56:	74a2                	ld	s1,40(sp)
    80001d58:	6aa2                	ld	s5,8(sp)
    80001d5a:	6121                	addi	sp,sp,64
    80001d5c:	8082                	ret

0000000080001d5e <scheduler>:
{
    80001d5e:	715d                	addi	sp,sp,-80
    80001d60:	e486                	sd	ra,72(sp)
    80001d62:	e0a2                	sd	s0,64(sp)
    80001d64:	fc26                	sd	s1,56(sp)
    80001d66:	f84a                	sd	s2,48(sp)
    80001d68:	f44e                	sd	s3,40(sp)
    80001d6a:	f052                	sd	s4,32(sp)
    80001d6c:	ec56                	sd	s5,24(sp)
    80001d6e:	e85a                	sd	s6,16(sp)
    80001d70:	e45e                	sd	s7,8(sp)
    80001d72:	e062                	sd	s8,0(sp)
    80001d74:	0880                	addi	s0,sp,80
    80001d76:	8792                	mv	a5,tp
  int id = r_tp();
    80001d78:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001d7a:	00779693          	slli	a3,a5,0x7
    80001d7e:	0000e717          	auipc	a4,0xe
    80001d82:	d2270713          	addi	a4,a4,-734 # 8000faa0 <pid_lock>
    80001d86:	9736                	add	a4,a4,a3
    80001d88:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001d8c:	0000eb17          	auipc	s6,0xe
    80001d90:	d4cb0b13          	addi	s6,s6,-692 # 8000fad8 <cpus+0x8>
    80001d94:	9b36                	add	s6,s6,a3
        p->state = RUNNING;
    80001d96:	4c11                	li	s8,4
        c->proc = p;
    80001d98:	8a3a                	mv	s4,a4
        found = 1;
    80001d9a:	4b85                	li	s7,1
    80001d9c:	a83d                	j	80001dda <scheduler+0x7c>
      release(&p->lock);
    80001d9e:	8526                	mv	a0,s1
    80001da0:	f55fe0ef          	jal	80000cf4 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001da4:	16848493          	addi	s1,s1,360
    80001da8:	03248563          	beq	s1,s2,80001dd2 <scheduler+0x74>
      acquire(&p->lock);
    80001dac:	8526                	mv	a0,s1
    80001dae:	eb7fe0ef          	jal	80000c64 <acquire>
      if(p->state == RUNNABLE) {
    80001db2:	4c9c                	lw	a5,24(s1)
    80001db4:	ff3795e3          	bne	a5,s3,80001d9e <scheduler+0x40>
        p->state = RUNNING;
    80001db8:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001dbc:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001dc0:	06048593          	addi	a1,s1,96
    80001dc4:	855a                	mv	a0,s6
    80001dc6:	5b2000ef          	jal	80002378 <swtch>
        c->proc = 0;
    80001dca:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001dce:	8ade                	mv	s5,s7
    80001dd0:	b7f9                	j	80001d9e <scheduler+0x40>
    if(found == 0) {
    80001dd2:	000a9463          	bnez	s5,80001dda <scheduler+0x7c>
      asm volatile("wfi");
    80001dd6:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001dda:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001dde:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001de2:	10079073          	csrw	sstatus,a5
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001de6:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001dea:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001dec:	10079073          	csrw	sstatus,a5
    int found = 0;
    80001df0:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001df2:	0000e497          	auipc	s1,0xe
    80001df6:	0de48493          	addi	s1,s1,222 # 8000fed0 <proc>
      if(p->state == RUNNABLE) {
    80001dfa:	498d                	li	s3,3
    for(p = proc; p < &proc[NPROC]; p++) {
    80001dfc:	00014917          	auipc	s2,0x14
    80001e00:	ad490913          	addi	s2,s2,-1324 # 800158d0 <tickslock>
    80001e04:	b765                	j	80001dac <scheduler+0x4e>

0000000080001e06 <sched>:
{
    80001e06:	7179                	addi	sp,sp,-48
    80001e08:	f406                	sd	ra,40(sp)
    80001e0a:	f022                	sd	s0,32(sp)
    80001e0c:	ec26                	sd	s1,24(sp)
    80001e0e:	e84a                	sd	s2,16(sp)
    80001e10:	e44e                	sd	s3,8(sp)
    80001e12:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001e14:	b1dff0ef          	jal	80001930 <myproc>
    80001e18:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001e1a:	ddbfe0ef          	jal	80000bf4 <holding>
    80001e1e:	c92d                	beqz	a0,80001e90 <sched+0x8a>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e20:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001e22:	2781                	sext.w	a5,a5
    80001e24:	079e                	slli	a5,a5,0x7
    80001e26:	0000e717          	auipc	a4,0xe
    80001e2a:	c7a70713          	addi	a4,a4,-902 # 8000faa0 <pid_lock>
    80001e2e:	97ba                	add	a5,a5,a4
    80001e30:	0a87a703          	lw	a4,168(a5)
    80001e34:	4785                	li	a5,1
    80001e36:	06f71363          	bne	a4,a5,80001e9c <sched+0x96>
  if(p->state == RUNNING)
    80001e3a:	4c98                	lw	a4,24(s1)
    80001e3c:	4791                	li	a5,4
    80001e3e:	06f70563          	beq	a4,a5,80001ea8 <sched+0xa2>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e42:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001e46:	8b89                	andi	a5,a5,2
  if(intr_get())
    80001e48:	e7b5                	bnez	a5,80001eb4 <sched+0xae>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e4a:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001e4c:	0000e917          	auipc	s2,0xe
    80001e50:	c5490913          	addi	s2,s2,-940 # 8000faa0 <pid_lock>
    80001e54:	2781                	sext.w	a5,a5
    80001e56:	079e                	slli	a5,a5,0x7
    80001e58:	97ca                	add	a5,a5,s2
    80001e5a:	0ac7a983          	lw	s3,172(a5)
    80001e5e:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001e60:	2781                	sext.w	a5,a5
    80001e62:	079e                	slli	a5,a5,0x7
    80001e64:	0000e597          	auipc	a1,0xe
    80001e68:	c7458593          	addi	a1,a1,-908 # 8000fad8 <cpus+0x8>
    80001e6c:	95be                	add	a1,a1,a5
    80001e6e:	06048513          	addi	a0,s1,96
    80001e72:	506000ef          	jal	80002378 <swtch>
    80001e76:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001e78:	2781                	sext.w	a5,a5
    80001e7a:	079e                	slli	a5,a5,0x7
    80001e7c:	993e                	add	s2,s2,a5
    80001e7e:	0b392623          	sw	s3,172(s2)
}
    80001e82:	70a2                	ld	ra,40(sp)
    80001e84:	7402                	ld	s0,32(sp)
    80001e86:	64e2                	ld	s1,24(sp)
    80001e88:	6942                	ld	s2,16(sp)
    80001e8a:	69a2                	ld	s3,8(sp)
    80001e8c:	6145                	addi	sp,sp,48
    80001e8e:	8082                	ret
    panic("sched p->lock");
    80001e90:	00005517          	auipc	a0,0x5
    80001e94:	3a850513          	addi	a0,a0,936 # 80007238 <etext+0x238>
    80001e98:	959fe0ef          	jal	800007f0 <panic>
    panic("sched locks");
    80001e9c:	00005517          	auipc	a0,0x5
    80001ea0:	3ac50513          	addi	a0,a0,940 # 80007248 <etext+0x248>
    80001ea4:	94dfe0ef          	jal	800007f0 <panic>
    panic("sched RUNNING");
    80001ea8:	00005517          	auipc	a0,0x5
    80001eac:	3b050513          	addi	a0,a0,944 # 80007258 <etext+0x258>
    80001eb0:	941fe0ef          	jal	800007f0 <panic>
    panic("sched interruptible");
    80001eb4:	00005517          	auipc	a0,0x5
    80001eb8:	3b450513          	addi	a0,a0,948 # 80007268 <etext+0x268>
    80001ebc:	935fe0ef          	jal	800007f0 <panic>

0000000080001ec0 <yield>:
{
    80001ec0:	1101                	addi	sp,sp,-32
    80001ec2:	ec06                	sd	ra,24(sp)
    80001ec4:	e822                	sd	s0,16(sp)
    80001ec6:	e426                	sd	s1,8(sp)
    80001ec8:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001eca:	a67ff0ef          	jal	80001930 <myproc>
    80001ece:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001ed0:	d95fe0ef          	jal	80000c64 <acquire>
  p->state = RUNNABLE;
    80001ed4:	478d                	li	a5,3
    80001ed6:	cc9c                	sw	a5,24(s1)
  sched();
    80001ed8:	f2fff0ef          	jal	80001e06 <sched>
  release(&p->lock);
    80001edc:	8526                	mv	a0,s1
    80001ede:	e17fe0ef          	jal	80000cf4 <release>
}
    80001ee2:	60e2                	ld	ra,24(sp)
    80001ee4:	6442                	ld	s0,16(sp)
    80001ee6:	64a2                	ld	s1,8(sp)
    80001ee8:	6105                	addi	sp,sp,32
    80001eea:	8082                	ret

0000000080001eec <sleep>:

// Sleep on wait channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001eec:	7179                	addi	sp,sp,-48
    80001eee:	f406                	sd	ra,40(sp)
    80001ef0:	f022                	sd	s0,32(sp)
    80001ef2:	ec26                	sd	s1,24(sp)
    80001ef4:	e84a                	sd	s2,16(sp)
    80001ef6:	e44e                	sd	s3,8(sp)
    80001ef8:	1800                	addi	s0,sp,48
    80001efa:	89aa                	mv	s3,a0
    80001efc:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001efe:	a33ff0ef          	jal	80001930 <myproc>
    80001f02:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80001f04:	d61fe0ef          	jal	80000c64 <acquire>
  release(lk);
    80001f08:	854a                	mv	a0,s2
    80001f0a:	debfe0ef          	jal	80000cf4 <release>

  // Go to sleep.
  p->chan = chan;
    80001f0e:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80001f12:	4789                	li	a5,2
    80001f14:	cc9c                	sw	a5,24(s1)

  sched();
    80001f16:	ef1ff0ef          	jal	80001e06 <sched>

  // Tidy up.
  p->chan = 0;
    80001f1a:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80001f1e:	8526                	mv	a0,s1
    80001f20:	dd5fe0ef          	jal	80000cf4 <release>
  acquire(lk);
    80001f24:	854a                	mv	a0,s2
    80001f26:	d3ffe0ef          	jal	80000c64 <acquire>
}
    80001f2a:	70a2                	ld	ra,40(sp)
    80001f2c:	7402                	ld	s0,32(sp)
    80001f2e:	64e2                	ld	s1,24(sp)
    80001f30:	6942                	ld	s2,16(sp)
    80001f32:	69a2                	ld	s3,8(sp)
    80001f34:	6145                	addi	sp,sp,48
    80001f36:	8082                	ret

0000000080001f38 <wakeup>:

// Wake up all processes sleeping on wait channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    80001f38:	7139                	addi	sp,sp,-64
    80001f3a:	fc06                	sd	ra,56(sp)
    80001f3c:	f822                	sd	s0,48(sp)
    80001f3e:	f426                	sd	s1,40(sp)
    80001f40:	f04a                	sd	s2,32(sp)
    80001f42:	ec4e                	sd	s3,24(sp)
    80001f44:	e852                	sd	s4,16(sp)
    80001f46:	e456                	sd	s5,8(sp)
    80001f48:	0080                	addi	s0,sp,64
    80001f4a:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80001f4c:	0000e497          	auipc	s1,0xe
    80001f50:	f8448493          	addi	s1,s1,-124 # 8000fed0 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80001f54:	4989                	li	s3,2
        p->state = RUNNABLE;
    80001f56:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    80001f58:	00014917          	auipc	s2,0x14
    80001f5c:	97890913          	addi	s2,s2,-1672 # 800158d0 <tickslock>
    80001f60:	a801                	j	80001f70 <wakeup+0x38>
      }
      release(&p->lock);
    80001f62:	8526                	mv	a0,s1
    80001f64:	d91fe0ef          	jal	80000cf4 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001f68:	16848493          	addi	s1,s1,360
    80001f6c:	03248263          	beq	s1,s2,80001f90 <wakeup+0x58>
    if(p != myproc()){
    80001f70:	9c1ff0ef          	jal	80001930 <myproc>
    80001f74:	fe950ae3          	beq	a0,s1,80001f68 <wakeup+0x30>
      acquire(&p->lock);
    80001f78:	8526                	mv	a0,s1
    80001f7a:	cebfe0ef          	jal	80000c64 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80001f7e:	4c9c                	lw	a5,24(s1)
    80001f80:	ff3791e3          	bne	a5,s3,80001f62 <wakeup+0x2a>
    80001f84:	709c                	ld	a5,32(s1)
    80001f86:	fd479ee3          	bne	a5,s4,80001f62 <wakeup+0x2a>
        p->state = RUNNABLE;
    80001f8a:	0154ac23          	sw	s5,24(s1)
    80001f8e:	bfd1                	j	80001f62 <wakeup+0x2a>
    }
  }
}
    80001f90:	70e2                	ld	ra,56(sp)
    80001f92:	7442                	ld	s0,48(sp)
    80001f94:	74a2                	ld	s1,40(sp)
    80001f96:	7902                	ld	s2,32(sp)
    80001f98:	69e2                	ld	s3,24(sp)
    80001f9a:	6a42                	ld	s4,16(sp)
    80001f9c:	6aa2                	ld	s5,8(sp)
    80001f9e:	6121                	addi	sp,sp,64
    80001fa0:	8082                	ret

0000000080001fa2 <reparent>:
{
    80001fa2:	7179                	addi	sp,sp,-48
    80001fa4:	f406                	sd	ra,40(sp)
    80001fa6:	f022                	sd	s0,32(sp)
    80001fa8:	ec26                	sd	s1,24(sp)
    80001faa:	e84a                	sd	s2,16(sp)
    80001fac:	e44e                	sd	s3,8(sp)
    80001fae:	e052                	sd	s4,0(sp)
    80001fb0:	1800                	addi	s0,sp,48
    80001fb2:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001fb4:	0000e497          	auipc	s1,0xe
    80001fb8:	f1c48493          	addi	s1,s1,-228 # 8000fed0 <proc>
      pp->parent = initproc;
    80001fbc:	00006a17          	auipc	s4,0x6
    80001fc0:	9aca0a13          	addi	s4,s4,-1620 # 80007968 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80001fc4:	00014997          	auipc	s3,0x14
    80001fc8:	90c98993          	addi	s3,s3,-1780 # 800158d0 <tickslock>
    80001fcc:	a029                	j	80001fd6 <reparent+0x34>
    80001fce:	16848493          	addi	s1,s1,360
    80001fd2:	01348b63          	beq	s1,s3,80001fe8 <reparent+0x46>
    if(pp->parent == p){
    80001fd6:	7c9c                	ld	a5,56(s1)
    80001fd8:	ff279be3          	bne	a5,s2,80001fce <reparent+0x2c>
      pp->parent = initproc;
    80001fdc:	000a3503          	ld	a0,0(s4)
    80001fe0:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80001fe2:	f57ff0ef          	jal	80001f38 <wakeup>
    80001fe6:	b7e5                	j	80001fce <reparent+0x2c>
}
    80001fe8:	70a2                	ld	ra,40(sp)
    80001fea:	7402                	ld	s0,32(sp)
    80001fec:	64e2                	ld	s1,24(sp)
    80001fee:	6942                	ld	s2,16(sp)
    80001ff0:	69a2                	ld	s3,8(sp)
    80001ff2:	6a02                	ld	s4,0(sp)
    80001ff4:	6145                	addi	sp,sp,48
    80001ff6:	8082                	ret

0000000080001ff8 <exit>:
{
    80001ff8:	7179                	addi	sp,sp,-48
    80001ffa:	f406                	sd	ra,40(sp)
    80001ffc:	f022                	sd	s0,32(sp)
    80001ffe:	ec26                	sd	s1,24(sp)
    80002000:	e84a                	sd	s2,16(sp)
    80002002:	e44e                	sd	s3,8(sp)
    80002004:	e052                	sd	s4,0(sp)
    80002006:	1800                	addi	s0,sp,48
    80002008:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    8000200a:	927ff0ef          	jal	80001930 <myproc>
    8000200e:	89aa                	mv	s3,a0
  if(p == initproc)
    80002010:	00006797          	auipc	a5,0x6
    80002014:	9587b783          	ld	a5,-1704(a5) # 80007968 <initproc>
    80002018:	0d050493          	addi	s1,a0,208
    8000201c:	15050913          	addi	s2,a0,336
    80002020:	00a79b63          	bne	a5,a0,80002036 <exit+0x3e>
    panic("init exiting");
    80002024:	00005517          	auipc	a0,0x5
    80002028:	25c50513          	addi	a0,a0,604 # 80007280 <etext+0x280>
    8000202c:	fc4fe0ef          	jal	800007f0 <panic>
  for(int fd = 0; fd < NOFILE; fd++){
    80002030:	04a1                	addi	s1,s1,8
    80002032:	01248963          	beq	s1,s2,80002044 <exit+0x4c>
    if(p->ofile[fd]){
    80002036:	6088                	ld	a0,0(s1)
    80002038:	dd65                	beqz	a0,80002030 <exit+0x38>
      fileclose(f);
    8000203a:	7b3010ef          	jal	80003fec <fileclose>
      p->ofile[fd] = 0;
    8000203e:	0004b023          	sd	zero,0(s1)
    80002042:	b7fd                	j	80002030 <exit+0x38>
  begin_op();
    80002044:	37b010ef          	jal	80003bbe <begin_op>
  iput(p->cwd);
    80002048:	1509b503          	ld	a0,336(s3)
    8000204c:	432010ef          	jal	8000347e <iput>
  end_op();
    80002050:	3df010ef          	jal	80003c2e <end_op>
  p->cwd = 0;
    80002054:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    80002058:	0000e517          	auipc	a0,0xe
    8000205c:	a6050513          	addi	a0,a0,-1440 # 8000fab8 <wait_lock>
    80002060:	c05fe0ef          	jal	80000c64 <acquire>
  reparent(p);
    80002064:	854e                	mv	a0,s3
    80002066:	f3dff0ef          	jal	80001fa2 <reparent>
  wakeup(p->parent);
    8000206a:	0389b503          	ld	a0,56(s3)
    8000206e:	ecbff0ef          	jal	80001f38 <wakeup>
  acquire(&p->lock);
    80002072:	854e                	mv	a0,s3
    80002074:	bf1fe0ef          	jal	80000c64 <acquire>
  p->xstate = status;
    80002078:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    8000207c:	4795                	li	a5,5
    8000207e:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    80002082:	0000e517          	auipc	a0,0xe
    80002086:	a3650513          	addi	a0,a0,-1482 # 8000fab8 <wait_lock>
    8000208a:	c6bfe0ef          	jal	80000cf4 <release>
  sched();
    8000208e:	d79ff0ef          	jal	80001e06 <sched>
  panic("zombie exit");
    80002092:	00005517          	auipc	a0,0x5
    80002096:	1fe50513          	addi	a0,a0,510 # 80007290 <etext+0x290>
    8000209a:	f56fe0ef          	jal	800007f0 <panic>

000000008000209e <kill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kill(int pid)
{
    8000209e:	7179                	addi	sp,sp,-48
    800020a0:	f406                	sd	ra,40(sp)
    800020a2:	f022                	sd	s0,32(sp)
    800020a4:	ec26                	sd	s1,24(sp)
    800020a6:	e84a                	sd	s2,16(sp)
    800020a8:	e44e                	sd	s3,8(sp)
    800020aa:	1800                	addi	s0,sp,48
    800020ac:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    800020ae:	0000e497          	auipc	s1,0xe
    800020b2:	e2248493          	addi	s1,s1,-478 # 8000fed0 <proc>
    800020b6:	00014997          	auipc	s3,0x14
    800020ba:	81a98993          	addi	s3,s3,-2022 # 800158d0 <tickslock>
    acquire(&p->lock);
    800020be:	8526                	mv	a0,s1
    800020c0:	ba5fe0ef          	jal	80000c64 <acquire>
    if(p->pid == pid){
    800020c4:	589c                	lw	a5,48(s1)
    800020c6:	01278b63          	beq	a5,s2,800020dc <kill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    800020ca:	8526                	mv	a0,s1
    800020cc:	c29fe0ef          	jal	80000cf4 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    800020d0:	16848493          	addi	s1,s1,360
    800020d4:	ff3495e3          	bne	s1,s3,800020be <kill+0x20>
  }
  return -1;
    800020d8:	557d                	li	a0,-1
    800020da:	a819                	j	800020f0 <kill+0x52>
      p->killed = 1;
    800020dc:	4785                	li	a5,1
    800020de:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    800020e0:	4c98                	lw	a4,24(s1)
    800020e2:	4789                	li	a5,2
    800020e4:	00f70d63          	beq	a4,a5,800020fe <kill+0x60>
      release(&p->lock);
    800020e8:	8526                	mv	a0,s1
    800020ea:	c0bfe0ef          	jal	80000cf4 <release>
      return 0;
    800020ee:	4501                	li	a0,0
}
    800020f0:	70a2                	ld	ra,40(sp)
    800020f2:	7402                	ld	s0,32(sp)
    800020f4:	64e2                	ld	s1,24(sp)
    800020f6:	6942                	ld	s2,16(sp)
    800020f8:	69a2                	ld	s3,8(sp)
    800020fa:	6145                	addi	sp,sp,48
    800020fc:	8082                	ret
        p->state = RUNNABLE;
    800020fe:	478d                	li	a5,3
    80002100:	cc9c                	sw	a5,24(s1)
    80002102:	b7dd                	j	800020e8 <kill+0x4a>

0000000080002104 <setkilled>:

void
setkilled(struct proc *p)
{
    80002104:	1101                	addi	sp,sp,-32
    80002106:	ec06                	sd	ra,24(sp)
    80002108:	e822                	sd	s0,16(sp)
    8000210a:	e426                	sd	s1,8(sp)
    8000210c:	1000                	addi	s0,sp,32
    8000210e:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002110:	b55fe0ef          	jal	80000c64 <acquire>
  p->killed = 1;
    80002114:	4785                	li	a5,1
    80002116:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    80002118:	8526                	mv	a0,s1
    8000211a:	bdbfe0ef          	jal	80000cf4 <release>
}
    8000211e:	60e2                	ld	ra,24(sp)
    80002120:	6442                	ld	s0,16(sp)
    80002122:	64a2                	ld	s1,8(sp)
    80002124:	6105                	addi	sp,sp,32
    80002126:	8082                	ret

0000000080002128 <killed>:

int
killed(struct proc *p)
{
    80002128:	1101                	addi	sp,sp,-32
    8000212a:	ec06                	sd	ra,24(sp)
    8000212c:	e822                	sd	s0,16(sp)
    8000212e:	e426                	sd	s1,8(sp)
    80002130:	e04a                	sd	s2,0(sp)
    80002132:	1000                	addi	s0,sp,32
    80002134:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    80002136:	b2ffe0ef          	jal	80000c64 <acquire>
  k = p->killed;
    8000213a:	549c                	lw	a5,40(s1)
    8000213c:	893e                	mv	s2,a5
  release(&p->lock);
    8000213e:	8526                	mv	a0,s1
    80002140:	bb5fe0ef          	jal	80000cf4 <release>
  return k;
}
    80002144:	854a                	mv	a0,s2
    80002146:	60e2                	ld	ra,24(sp)
    80002148:	6442                	ld	s0,16(sp)
    8000214a:	64a2                	ld	s1,8(sp)
    8000214c:	6902                	ld	s2,0(sp)
    8000214e:	6105                	addi	sp,sp,32
    80002150:	8082                	ret

0000000080002152 <wait>:
{
    80002152:	715d                	addi	sp,sp,-80
    80002154:	e486                	sd	ra,72(sp)
    80002156:	e0a2                	sd	s0,64(sp)
    80002158:	fc26                	sd	s1,56(sp)
    8000215a:	f84a                	sd	s2,48(sp)
    8000215c:	f44e                	sd	s3,40(sp)
    8000215e:	f052                	sd	s4,32(sp)
    80002160:	ec56                	sd	s5,24(sp)
    80002162:	e85a                	sd	s6,16(sp)
    80002164:	e45e                	sd	s7,8(sp)
    80002166:	0880                	addi	s0,sp,80
    80002168:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    8000216a:	fc6ff0ef          	jal	80001930 <myproc>
    8000216e:	892a                	mv	s2,a0
  acquire(&wait_lock);
    80002170:	0000e517          	auipc	a0,0xe
    80002174:	94850513          	addi	a0,a0,-1720 # 8000fab8 <wait_lock>
    80002178:	aedfe0ef          	jal	80000c64 <acquire>
        if(pp->state == ZOMBIE){
    8000217c:	4a15                	li	s4,5
        havekids = 1;
    8000217e:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002180:	00013997          	auipc	s3,0x13
    80002184:	75098993          	addi	s3,s3,1872 # 800158d0 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002188:	0000eb17          	auipc	s6,0xe
    8000218c:	930b0b13          	addi	s6,s6,-1744 # 8000fab8 <wait_lock>
    80002190:	a861                	j	80002228 <wait+0xd6>
          pid = pp->pid;
    80002192:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    80002196:	000b8c63          	beqz	s7,800021ae <wait+0x5c>
    8000219a:	4691                	li	a3,4
    8000219c:	02c48613          	addi	a2,s1,44
    800021a0:	85de                	mv	a1,s7
    800021a2:	05093503          	ld	a0,80(s2)
    800021a6:	c1aff0ef          	jal	800015c0 <copyout>
    800021aa:	02054a63          	bltz	a0,800021de <wait+0x8c>
          freeproc(pp);
    800021ae:	8526                	mv	a0,s1
    800021b0:	8f3ff0ef          	jal	80001aa2 <freeproc>
          release(&pp->lock);
    800021b4:	8526                	mv	a0,s1
    800021b6:	b3ffe0ef          	jal	80000cf4 <release>
          release(&wait_lock);
    800021ba:	0000e517          	auipc	a0,0xe
    800021be:	8fe50513          	addi	a0,a0,-1794 # 8000fab8 <wait_lock>
    800021c2:	b33fe0ef          	jal	80000cf4 <release>
}
    800021c6:	854e                	mv	a0,s3
    800021c8:	60a6                	ld	ra,72(sp)
    800021ca:	6406                	ld	s0,64(sp)
    800021cc:	74e2                	ld	s1,56(sp)
    800021ce:	7942                	ld	s2,48(sp)
    800021d0:	79a2                	ld	s3,40(sp)
    800021d2:	7a02                	ld	s4,32(sp)
    800021d4:	6ae2                	ld	s5,24(sp)
    800021d6:	6b42                	ld	s6,16(sp)
    800021d8:	6ba2                	ld	s7,8(sp)
    800021da:	6161                	addi	sp,sp,80
    800021dc:	8082                	ret
            release(&pp->lock);
    800021de:	8526                	mv	a0,s1
    800021e0:	b15fe0ef          	jal	80000cf4 <release>
            release(&wait_lock);
    800021e4:	0000e517          	auipc	a0,0xe
    800021e8:	8d450513          	addi	a0,a0,-1836 # 8000fab8 <wait_lock>
    800021ec:	b09fe0ef          	jal	80000cf4 <release>
            return -1;
    800021f0:	a881                	j	80002240 <wait+0xee>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800021f2:	16848493          	addi	s1,s1,360
    800021f6:	03348063          	beq	s1,s3,80002216 <wait+0xc4>
      if(pp->parent == p){
    800021fa:	7c9c                	ld	a5,56(s1)
    800021fc:	ff279be3          	bne	a5,s2,800021f2 <wait+0xa0>
        acquire(&pp->lock);
    80002200:	8526                	mv	a0,s1
    80002202:	a63fe0ef          	jal	80000c64 <acquire>
        if(pp->state == ZOMBIE){
    80002206:	4c9c                	lw	a5,24(s1)
    80002208:	f94785e3          	beq	a5,s4,80002192 <wait+0x40>
        release(&pp->lock);
    8000220c:	8526                	mv	a0,s1
    8000220e:	ae7fe0ef          	jal	80000cf4 <release>
        havekids = 1;
    80002212:	8756                	mv	a4,s5
    80002214:	bff9                	j	800021f2 <wait+0xa0>
    if(!havekids || killed(p)){
    80002216:	cf19                	beqz	a4,80002234 <wait+0xe2>
    80002218:	854a                	mv	a0,s2
    8000221a:	f0fff0ef          	jal	80002128 <killed>
    8000221e:	e919                	bnez	a0,80002234 <wait+0xe2>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002220:	85da                	mv	a1,s6
    80002222:	854a                	mv	a0,s2
    80002224:	cc9ff0ef          	jal	80001eec <sleep>
    havekids = 0;
    80002228:	4701                	li	a4,0
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000222a:	0000e497          	auipc	s1,0xe
    8000222e:	ca648493          	addi	s1,s1,-858 # 8000fed0 <proc>
    80002232:	b7e1                	j	800021fa <wait+0xa8>
      release(&wait_lock);
    80002234:	0000e517          	auipc	a0,0xe
    80002238:	88450513          	addi	a0,a0,-1916 # 8000fab8 <wait_lock>
    8000223c:	ab9fe0ef          	jal	80000cf4 <release>
            return -1;
    80002240:	59fd                	li	s3,-1
    80002242:	b751                	j	800021c6 <wait+0x74>

0000000080002244 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80002244:	7179                	addi	sp,sp,-48
    80002246:	f406                	sd	ra,40(sp)
    80002248:	f022                	sd	s0,32(sp)
    8000224a:	ec26                	sd	s1,24(sp)
    8000224c:	e84a                	sd	s2,16(sp)
    8000224e:	e44e                	sd	s3,8(sp)
    80002250:	e052                	sd	s4,0(sp)
    80002252:	1800                	addi	s0,sp,48
    80002254:	84aa                	mv	s1,a0
    80002256:	8a2e                	mv	s4,a1
    80002258:	89b2                	mv	s3,a2
    8000225a:	8936                	mv	s2,a3
  struct proc *p = myproc();
    8000225c:	ed4ff0ef          	jal	80001930 <myproc>
  if(user_dst){
    80002260:	cc99                	beqz	s1,8000227e <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    80002262:	86ca                	mv	a3,s2
    80002264:	864e                	mv	a2,s3
    80002266:	85d2                	mv	a1,s4
    80002268:	6928                	ld	a0,80(a0)
    8000226a:	b56ff0ef          	jal	800015c0 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    8000226e:	70a2                	ld	ra,40(sp)
    80002270:	7402                	ld	s0,32(sp)
    80002272:	64e2                	ld	s1,24(sp)
    80002274:	6942                	ld	s2,16(sp)
    80002276:	69a2                	ld	s3,8(sp)
    80002278:	6a02                	ld	s4,0(sp)
    8000227a:	6145                	addi	sp,sp,48
    8000227c:	8082                	ret
    memmove((char *)dst, src, len);
    8000227e:	0009061b          	sext.w	a2,s2
    80002282:	85ce                	mv	a1,s3
    80002284:	8552                	mv	a0,s4
    80002286:	b07fe0ef          	jal	80000d8c <memmove>
    return 0;
    8000228a:	8526                	mv	a0,s1
    8000228c:	b7cd                	j	8000226e <either_copyout+0x2a>

000000008000228e <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    8000228e:	7179                	addi	sp,sp,-48
    80002290:	f406                	sd	ra,40(sp)
    80002292:	f022                	sd	s0,32(sp)
    80002294:	ec26                	sd	s1,24(sp)
    80002296:	e84a                	sd	s2,16(sp)
    80002298:	e44e                	sd	s3,8(sp)
    8000229a:	e052                	sd	s4,0(sp)
    8000229c:	1800                	addi	s0,sp,48
    8000229e:	8a2a                	mv	s4,a0
    800022a0:	84ae                	mv	s1,a1
    800022a2:	89b2                	mv	s3,a2
    800022a4:	8936                	mv	s2,a3
  struct proc *p = myproc();
    800022a6:	e8aff0ef          	jal	80001930 <myproc>
  if(user_src){
    800022aa:	cc99                	beqz	s1,800022c8 <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    800022ac:	86ca                	mv	a3,s2
    800022ae:	864e                	mv	a2,s3
    800022b0:	85d2                	mv	a1,s4
    800022b2:	6928                	ld	a0,80(a0)
    800022b4:	bbaff0ef          	jal	8000166e <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    800022b8:	70a2                	ld	ra,40(sp)
    800022ba:	7402                	ld	s0,32(sp)
    800022bc:	64e2                	ld	s1,24(sp)
    800022be:	6942                	ld	s2,16(sp)
    800022c0:	69a2                	ld	s3,8(sp)
    800022c2:	6a02                	ld	s4,0(sp)
    800022c4:	6145                	addi	sp,sp,48
    800022c6:	8082                	ret
    memmove(dst, (char*)src, len);
    800022c8:	0009061b          	sext.w	a2,s2
    800022cc:	85ce                	mv	a1,s3
    800022ce:	8552                	mv	a0,s4
    800022d0:	abdfe0ef          	jal	80000d8c <memmove>
    return 0;
    800022d4:	8526                	mv	a0,s1
    800022d6:	b7cd                	j	800022b8 <either_copyin+0x2a>

00000000800022d8 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    800022d8:	715d                	addi	sp,sp,-80
    800022da:	e486                	sd	ra,72(sp)
    800022dc:	e0a2                	sd	s0,64(sp)
    800022de:	fc26                	sd	s1,56(sp)
    800022e0:	f84a                	sd	s2,48(sp)
    800022e2:	f44e                	sd	s3,40(sp)
    800022e4:	f052                	sd	s4,32(sp)
    800022e6:	ec56                	sd	s5,24(sp)
    800022e8:	e85a                	sd	s6,16(sp)
    800022ea:	e45e                	sd	s7,8(sp)
    800022ec:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    800022ee:	00005517          	auipc	a0,0x5
    800022f2:	d8a50513          	addi	a0,a0,-630 # 80007078 <etext+0x78>
    800022f6:	9dcfe0ef          	jal	800004d2 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800022fa:	0000e497          	auipc	s1,0xe
    800022fe:	d2e48493          	addi	s1,s1,-722 # 80010028 <proc+0x158>
    80002302:	00013917          	auipc	s2,0x13
    80002306:	72690913          	addi	s2,s2,1830 # 80015a28 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000230a:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    8000230c:	00005a97          	auipc	s5,0x5
    80002310:	f94a8a93          	addi	s5,s5,-108 # 800072a0 <etext+0x2a0>
    printf("%d %s %s", p->pid, state, p->name);
    80002314:	00005a17          	auipc	s4,0x5
    80002318:	f94a0a13          	addi	s4,s4,-108 # 800072a8 <etext+0x2a8>
    printf("\n");
    8000231c:	00005997          	auipc	s3,0x5
    80002320:	d5c98993          	addi	s3,s3,-676 # 80007078 <etext+0x78>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002324:	00005b97          	auipc	s7,0x5
    80002328:	484b8b93          	addi	s7,s7,1156 # 800077a8 <states.0>
    8000232c:	a829                	j	80002346 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    8000232e:	ed86a583          	lw	a1,-296(a3)
    80002332:	8552                	mv	a0,s4
    80002334:	99efe0ef          	jal	800004d2 <printf>
    printf("\n");
    80002338:	854e                	mv	a0,s3
    8000233a:	998fe0ef          	jal	800004d2 <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    8000233e:	16848493          	addi	s1,s1,360
    80002342:	03248063          	beq	s1,s2,80002362 <procdump+0x8a>
    if(p->state == UNUSED)
    80002346:	86a6                	mv	a3,s1
    80002348:	ec04a783          	lw	a5,-320(s1)
    8000234c:	dbed                	beqz	a5,8000233e <procdump+0x66>
      state = "???";
    8000234e:	8656                	mv	a2,s5
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002350:	fcfb6fe3          	bltu	s6,a5,8000232e <procdump+0x56>
    80002354:	02079713          	slli	a4,a5,0x20
    80002358:	01d75793          	srli	a5,a4,0x1d
    8000235c:	97de                	add	a5,a5,s7
    8000235e:	6390                	ld	a2,0(a5)
      state = states[p->state];
    80002360:	b7f9                	j	8000232e <procdump+0x56>
  }
}
    80002362:	60a6                	ld	ra,72(sp)
    80002364:	6406                	ld	s0,64(sp)
    80002366:	74e2                	ld	s1,56(sp)
    80002368:	7942                	ld	s2,48(sp)
    8000236a:	79a2                	ld	s3,40(sp)
    8000236c:	7a02                	ld	s4,32(sp)
    8000236e:	6ae2                	ld	s5,24(sp)
    80002370:	6b42                	ld	s6,16(sp)
    80002372:	6ba2                	ld	s7,8(sp)
    80002374:	6161                	addi	sp,sp,80
    80002376:	8082                	ret

0000000080002378 <swtch>:
    80002378:	00153023          	sd	ra,0(a0)
    8000237c:	00253423          	sd	sp,8(a0)
    80002380:	e900                	sd	s0,16(a0)
    80002382:	ed04                	sd	s1,24(a0)
    80002384:	03253023          	sd	s2,32(a0)
    80002388:	03353423          	sd	s3,40(a0)
    8000238c:	03453823          	sd	s4,48(a0)
    80002390:	03553c23          	sd	s5,56(a0)
    80002394:	05653023          	sd	s6,64(a0)
    80002398:	05753423          	sd	s7,72(a0)
    8000239c:	05853823          	sd	s8,80(a0)
    800023a0:	05953c23          	sd	s9,88(a0)
    800023a4:	07a53023          	sd	s10,96(a0)
    800023a8:	07b53423          	sd	s11,104(a0)
    800023ac:	0005b083          	ld	ra,0(a1)
    800023b0:	0085b103          	ld	sp,8(a1)
    800023b4:	6980                	ld	s0,16(a1)
    800023b6:	6d84                	ld	s1,24(a1)
    800023b8:	0205b903          	ld	s2,32(a1)
    800023bc:	0285b983          	ld	s3,40(a1)
    800023c0:	0305ba03          	ld	s4,48(a1)
    800023c4:	0385ba83          	ld	s5,56(a1)
    800023c8:	0405bb03          	ld	s6,64(a1)
    800023cc:	0485bb83          	ld	s7,72(a1)
    800023d0:	0505bc03          	ld	s8,80(a1)
    800023d4:	0585bc83          	ld	s9,88(a1)
    800023d8:	0605bd03          	ld	s10,96(a1)
    800023dc:	0685bd83          	ld	s11,104(a1)
    800023e0:	8082                	ret

00000000800023e2 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    800023e2:	1141                	addi	sp,sp,-16
    800023e4:	e406                	sd	ra,8(sp)
    800023e6:	e022                	sd	s0,0(sp)
    800023e8:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    800023ea:	00005597          	auipc	a1,0x5
    800023ee:	efe58593          	addi	a1,a1,-258 # 800072e8 <etext+0x2e8>
    800023f2:	00013517          	auipc	a0,0x13
    800023f6:	4de50513          	addi	a0,a0,1246 # 800158d0 <tickslock>
    800023fa:	fe0fe0ef          	jal	80000bda <initlock>
}
    800023fe:	60a2                	ld	ra,8(sp)
    80002400:	6402                	ld	s0,0(sp)
    80002402:	0141                	addi	sp,sp,16
    80002404:	8082                	ret

0000000080002406 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80002406:	1141                	addi	sp,sp,-16
    80002408:	e406                	sd	ra,8(sp)
    8000240a:	e022                	sd	s0,0(sp)
    8000240c:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000240e:	00003797          	auipc	a5,0x3
    80002412:	f0278793          	addi	a5,a5,-254 # 80005310 <kernelvec>
    80002416:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    8000241a:	60a2                	ld	ra,8(sp)
    8000241c:	6402                	ld	s0,0(sp)
    8000241e:	0141                	addi	sp,sp,16
    80002420:	8082                	ret

0000000080002422 <usertrapret>:
//
// return to user space
//
void
usertrapret(void)
{
    80002422:	1141                	addi	sp,sp,-16
    80002424:	e406                	sd	ra,8(sp)
    80002426:	e022                	sd	s0,0(sp)
    80002428:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    8000242a:	d06ff0ef          	jal	80001930 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000242e:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80002432:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002434:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(), so turn off interrupts until
  // we're back in user space, where usertrap() is correct.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002438:	00004697          	auipc	a3,0x4
    8000243c:	bc868693          	addi	a3,a3,-1080 # 80006000 <_trampoline>
    80002440:	00004717          	auipc	a4,0x4
    80002444:	bc070713          	addi	a4,a4,-1088 # 80006000 <_trampoline>
    80002448:	8f15                	sub	a4,a4,a3
    8000244a:	040007b7          	lui	a5,0x4000
    8000244e:	17fd                	addi	a5,a5,-1 # 3ffffff <_entry-0x7c000001>
    80002450:	07b2                	slli	a5,a5,0xc
    80002452:	973e                	add	a4,a4,a5
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002454:	10571073          	csrw	stvec,a4
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80002458:	6d38                	ld	a4,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    8000245a:	18002673          	csrr	a2,satp
    8000245e:	e310                	sd	a2,0(a4)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    80002460:	6d30                	ld	a2,88(a0)
    80002462:	6138                	ld	a4,64(a0)
    80002464:	6585                	lui	a1,0x1
    80002466:	972e                	add	a4,a4,a1
    80002468:	e618                	sd	a4,8(a2)
  p->trapframe->kernel_trap = (uint64)usertrap;
    8000246a:	6d38                	ld	a4,88(a0)
    8000246c:	00000617          	auipc	a2,0x0
    80002470:	10c60613          	addi	a2,a2,268 # 80002578 <usertrap>
    80002474:	eb10                	sd	a2,16(a4)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80002476:	6d38                	ld	a4,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80002478:	8612                	mv	a2,tp
    8000247a:	f310                	sd	a2,32(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000247c:	10002773          	csrr	a4,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80002480:	eff77713          	andi	a4,a4,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80002484:	02076713          	ori	a4,a4,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002488:	10071073          	csrw	sstatus,a4
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    8000248c:	6d38                	ld	a4,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    8000248e:	6f18                	ld	a4,24(a4)
    80002490:	14171073          	csrw	sepc,a4

  // tell trampoline.S the user page table to switch to.
  uint64 satp = MAKE_SATP(p->pagetable);
    80002494:	6928                	ld	a0,80(a0)
    80002496:	8131                	srli	a0,a0,0xc

  // jump to userret in trampoline.S at the top of memory, which 
  // switches to the user page table, restores user registers,
  // and switches to user mode with sret.
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80002498:	00004717          	auipc	a4,0x4
    8000249c:	c0470713          	addi	a4,a4,-1020 # 8000609c <userret>
    800024a0:	8f15                	sub	a4,a4,a3
    800024a2:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    800024a4:	577d                	li	a4,-1
    800024a6:	177e                	slli	a4,a4,0x3f
    800024a8:	8d59                	or	a0,a0,a4
    800024aa:	9782                	jalr	a5
}
    800024ac:	60a2                	ld	ra,8(sp)
    800024ae:	6402                	ld	s0,0(sp)
    800024b0:	0141                	addi	sp,sp,16
    800024b2:	8082                	ret

00000000800024b4 <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    800024b4:	1141                	addi	sp,sp,-16
    800024b6:	e406                	sd	ra,8(sp)
    800024b8:	e022                	sd	s0,0(sp)
    800024ba:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    800024bc:	c40ff0ef          	jal	800018fc <cpuid>
    800024c0:	cd11                	beqz	a0,800024dc <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    800024c2:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    800024c6:	000f4737          	lui	a4,0xf4
    800024ca:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    800024ce:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    800024d0:	14d79073          	csrw	stimecmp,a5
}
    800024d4:	60a2                	ld	ra,8(sp)
    800024d6:	6402                	ld	s0,0(sp)
    800024d8:	0141                	addi	sp,sp,16
    800024da:	8082                	ret
    acquire(&tickslock);
    800024dc:	00013517          	auipc	a0,0x13
    800024e0:	3f450513          	addi	a0,a0,1012 # 800158d0 <tickslock>
    800024e4:	f80fe0ef          	jal	80000c64 <acquire>
    ticks++;
    800024e8:	00005717          	auipc	a4,0x5
    800024ec:	48870713          	addi	a4,a4,1160 # 80007970 <ticks>
    800024f0:	431c                	lw	a5,0(a4)
    800024f2:	2785                	addiw	a5,a5,1
    800024f4:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    800024f6:	853a                	mv	a0,a4
    800024f8:	a41ff0ef          	jal	80001f38 <wakeup>
    release(&tickslock);
    800024fc:	00013517          	auipc	a0,0x13
    80002500:	3d450513          	addi	a0,a0,980 # 800158d0 <tickslock>
    80002504:	ff0fe0ef          	jal	80000cf4 <release>
    80002508:	bf6d                	j	800024c2 <clockintr+0xe>

000000008000250a <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    8000250a:	1101                	addi	sp,sp,-32
    8000250c:	ec06                	sd	ra,24(sp)
    8000250e:	e822                	sd	s0,16(sp)
    80002510:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002512:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    80002516:	57fd                	li	a5,-1
    80002518:	17fe                	slli	a5,a5,0x3f
    8000251a:	07a5                	addi	a5,a5,9
    8000251c:	00f70c63          	beq	a4,a5,80002534 <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80002520:	57fd                	li	a5,-1
    80002522:	17fe                	slli	a5,a5,0x3f
    80002524:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    80002526:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80002528:	04f70463          	beq	a4,a5,80002570 <devintr+0x66>
  }
}
    8000252c:	60e2                	ld	ra,24(sp)
    8000252e:	6442                	ld	s0,16(sp)
    80002530:	6105                	addi	sp,sp,32
    80002532:	8082                	ret
    80002534:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    80002536:	687020ef          	jal	800053bc <plic_claim>
    8000253a:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    8000253c:	47a9                	li	a5,10
    8000253e:	02f50363          	beq	a0,a5,80002564 <devintr+0x5a>
    } else if(irq == VIRTIO0_IRQ){
    80002542:	4785                	li	a5,1
    80002544:	02f50363          	beq	a0,a5,8000256a <devintr+0x60>
    } else if(irq){
    80002548:	c919                	beqz	a0,8000255e <devintr+0x54>
      printf("unexpected interrupt irq=%d\n", irq);
    8000254a:	85aa                	mv	a1,a0
    8000254c:	00005517          	auipc	a0,0x5
    80002550:	da450513          	addi	a0,a0,-604 # 800072f0 <etext+0x2f0>
    80002554:	f7ffd0ef          	jal	800004d2 <printf>
      plic_complete(irq);
    80002558:	8526                	mv	a0,s1
    8000255a:	683020ef          	jal	800053dc <plic_complete>
    return 1;
    8000255e:	4505                	li	a0,1
    80002560:	64a2                	ld	s1,8(sp)
    80002562:	b7e9                	j	8000252c <devintr+0x22>
      uartintr();
    80002564:	cecfe0ef          	jal	80000a50 <uartintr>
    if(irq)
    80002568:	bfc5                	j	80002558 <devintr+0x4e>
      virtio_disk_intr();
    8000256a:	2d6030ef          	jal	80005840 <virtio_disk_intr>
    if(irq)
    8000256e:	b7ed                	j	80002558 <devintr+0x4e>
    clockintr();
    80002570:	f45ff0ef          	jal	800024b4 <clockintr>
    return 2;
    80002574:	4509                	li	a0,2
    80002576:	bf5d                	j	8000252c <devintr+0x22>

0000000080002578 <usertrap>:
{
    80002578:	1101                	addi	sp,sp,-32
    8000257a:	ec06                	sd	ra,24(sp)
    8000257c:	e822                	sd	s0,16(sp)
    8000257e:	e426                	sd	s1,8(sp)
    80002580:	e04a                	sd	s2,0(sp)
    80002582:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002584:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    80002588:	1007f793          	andi	a5,a5,256
    8000258c:	ef85                	bnez	a5,800025c4 <usertrap+0x4c>
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000258e:	00003797          	auipc	a5,0x3
    80002592:	d8278793          	addi	a5,a5,-638 # 80005310 <kernelvec>
    80002596:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    8000259a:	b96ff0ef          	jal	80001930 <myproc>
    8000259e:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    800025a0:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800025a2:	14102773          	csrr	a4,sepc
    800025a6:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    800025a8:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    800025ac:	47a1                	li	a5,8
    800025ae:	02f70163          	beq	a4,a5,800025d0 <usertrap+0x58>
  } else if((which_dev = devintr()) != 0){
    800025b2:	f59ff0ef          	jal	8000250a <devintr>
    800025b6:	892a                	mv	s2,a0
    800025b8:	c135                	beqz	a0,8000261c <usertrap+0xa4>
  if(killed(p))
    800025ba:	8526                	mv	a0,s1
    800025bc:	b6dff0ef          	jal	80002128 <killed>
    800025c0:	cd1d                	beqz	a0,800025fe <usertrap+0x86>
    800025c2:	a81d                	j	800025f8 <usertrap+0x80>
    panic("usertrap: not from user mode");
    800025c4:	00005517          	auipc	a0,0x5
    800025c8:	d4c50513          	addi	a0,a0,-692 # 80007310 <etext+0x310>
    800025cc:	a24fe0ef          	jal	800007f0 <panic>
    if(killed(p))
    800025d0:	b59ff0ef          	jal	80002128 <killed>
    800025d4:	e121                	bnez	a0,80002614 <usertrap+0x9c>
    p->trapframe->epc += 4;
    800025d6:	6cb8                	ld	a4,88(s1)
    800025d8:	6f1c                	ld	a5,24(a4)
    800025da:	0791                	addi	a5,a5,4
    800025dc:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800025de:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    800025e2:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800025e6:	10079073          	csrw	sstatus,a5
    syscall();
    800025ea:	23e000ef          	jal	80002828 <syscall>
  if(killed(p))
    800025ee:	8526                	mv	a0,s1
    800025f0:	b39ff0ef          	jal	80002128 <killed>
    800025f4:	c901                	beqz	a0,80002604 <usertrap+0x8c>
    800025f6:	4901                	li	s2,0
    exit(-1);
    800025f8:	557d                	li	a0,-1
    800025fa:	9ffff0ef          	jal	80001ff8 <exit>
  if(which_dev == 2)
    800025fe:	4789                	li	a5,2
    80002600:	04f90563          	beq	s2,a5,8000264a <usertrap+0xd2>
  usertrapret();
    80002604:	e1fff0ef          	jal	80002422 <usertrapret>
}
    80002608:	60e2                	ld	ra,24(sp)
    8000260a:	6442                	ld	s0,16(sp)
    8000260c:	64a2                	ld	s1,8(sp)
    8000260e:	6902                	ld	s2,0(sp)
    80002610:	6105                	addi	sp,sp,32
    80002612:	8082                	ret
      exit(-1);
    80002614:	557d                	li	a0,-1
    80002616:	9e3ff0ef          	jal	80001ff8 <exit>
    8000261a:	bf75                	j	800025d6 <usertrap+0x5e>
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000261c:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80002620:	5890                	lw	a2,48(s1)
    80002622:	00005517          	auipc	a0,0x5
    80002626:	d0e50513          	addi	a0,a0,-754 # 80007330 <etext+0x330>
    8000262a:	ea9fd0ef          	jal	800004d2 <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    8000262e:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002632:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80002636:	00005517          	auipc	a0,0x5
    8000263a:	d2a50513          	addi	a0,a0,-726 # 80007360 <etext+0x360>
    8000263e:	e95fd0ef          	jal	800004d2 <printf>
    setkilled(p);
    80002642:	8526                	mv	a0,s1
    80002644:	ac1ff0ef          	jal	80002104 <setkilled>
    80002648:	b75d                	j	800025ee <usertrap+0x76>
    yield();
    8000264a:	877ff0ef          	jal	80001ec0 <yield>
    8000264e:	bf5d                	j	80002604 <usertrap+0x8c>

0000000080002650 <kerneltrap>:
{
    80002650:	7179                	addi	sp,sp,-48
    80002652:	f406                	sd	ra,40(sp)
    80002654:	f022                	sd	s0,32(sp)
    80002656:	ec26                	sd	s1,24(sp)
    80002658:	e84a                	sd	s2,16(sp)
    8000265a:	e44e                	sd	s3,8(sp)
    8000265c:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    8000265e:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002662:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002666:	142027f3          	csrr	a5,scause
    8000266a:	89be                	mv	s3,a5
  if((sstatus & SSTATUS_SPP) == 0)
    8000266c:	1004f793          	andi	a5,s1,256
    80002670:	c795                	beqz	a5,8000269c <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002672:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80002676:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    80002678:	eb85                	bnez	a5,800026a8 <kerneltrap+0x58>
  if((which_dev = devintr()) == 0){
    8000267a:	e91ff0ef          	jal	8000250a <devintr>
    8000267e:	c91d                	beqz	a0,800026b4 <kerneltrap+0x64>
  if(which_dev == 2 && myproc() != 0)
    80002680:	4789                	li	a5,2
    80002682:	04f50a63          	beq	a0,a5,800026d6 <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r" (x));
    80002686:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000268a:	10049073          	csrw	sstatus,s1
}
    8000268e:	70a2                	ld	ra,40(sp)
    80002690:	7402                	ld	s0,32(sp)
    80002692:	64e2                	ld	s1,24(sp)
    80002694:	6942                	ld	s2,16(sp)
    80002696:	69a2                	ld	s3,8(sp)
    80002698:	6145                	addi	sp,sp,48
    8000269a:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    8000269c:	00005517          	auipc	a0,0x5
    800026a0:	cec50513          	addi	a0,a0,-788 # 80007388 <etext+0x388>
    800026a4:	94cfe0ef          	jal	800007f0 <panic>
    panic("kerneltrap: interrupts enabled");
    800026a8:	00005517          	auipc	a0,0x5
    800026ac:	d0850513          	addi	a0,a0,-760 # 800073b0 <etext+0x3b0>
    800026b0:	940fe0ef          	jal	800007f0 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800026b4:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    800026b8:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    800026bc:	85ce                	mv	a1,s3
    800026be:	00005517          	auipc	a0,0x5
    800026c2:	d1250513          	addi	a0,a0,-750 # 800073d0 <etext+0x3d0>
    800026c6:	e0dfd0ef          	jal	800004d2 <printf>
    panic("kerneltrap");
    800026ca:	00005517          	auipc	a0,0x5
    800026ce:	d2e50513          	addi	a0,a0,-722 # 800073f8 <etext+0x3f8>
    800026d2:	91efe0ef          	jal	800007f0 <panic>
  if(which_dev == 2 && myproc() != 0)
    800026d6:	a5aff0ef          	jal	80001930 <myproc>
    800026da:	d555                	beqz	a0,80002686 <kerneltrap+0x36>
    yield();
    800026dc:	fe4ff0ef          	jal	80001ec0 <yield>
    800026e0:	b75d                	j	80002686 <kerneltrap+0x36>

00000000800026e2 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    800026e2:	1101                	addi	sp,sp,-32
    800026e4:	ec06                	sd	ra,24(sp)
    800026e6:	e822                	sd	s0,16(sp)
    800026e8:	e426                	sd	s1,8(sp)
    800026ea:	1000                	addi	s0,sp,32
    800026ec:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    800026ee:	a42ff0ef          	jal	80001930 <myproc>
  switch (n) {
    800026f2:	4795                	li	a5,5
    800026f4:	0497e163          	bltu	a5,s1,80002736 <argraw+0x54>
    800026f8:	048a                	slli	s1,s1,0x2
    800026fa:	00005717          	auipc	a4,0x5
    800026fe:	0de70713          	addi	a4,a4,222 # 800077d8 <states.0+0x30>
    80002702:	94ba                	add	s1,s1,a4
    80002704:	409c                	lw	a5,0(s1)
    80002706:	97ba                	add	a5,a5,a4
    80002708:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    8000270a:	6d3c                	ld	a5,88(a0)
    8000270c:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    8000270e:	60e2                	ld	ra,24(sp)
    80002710:	6442                	ld	s0,16(sp)
    80002712:	64a2                	ld	s1,8(sp)
    80002714:	6105                	addi	sp,sp,32
    80002716:	8082                	ret
    return p->trapframe->a1;
    80002718:	6d3c                	ld	a5,88(a0)
    8000271a:	7fa8                	ld	a0,120(a5)
    8000271c:	bfcd                	j	8000270e <argraw+0x2c>
    return p->trapframe->a2;
    8000271e:	6d3c                	ld	a5,88(a0)
    80002720:	63c8                	ld	a0,128(a5)
    80002722:	b7f5                	j	8000270e <argraw+0x2c>
    return p->trapframe->a3;
    80002724:	6d3c                	ld	a5,88(a0)
    80002726:	67c8                	ld	a0,136(a5)
    80002728:	b7dd                	j	8000270e <argraw+0x2c>
    return p->trapframe->a4;
    8000272a:	6d3c                	ld	a5,88(a0)
    8000272c:	6bc8                	ld	a0,144(a5)
    8000272e:	b7c5                	j	8000270e <argraw+0x2c>
    return p->trapframe->a5;
    80002730:	6d3c                	ld	a5,88(a0)
    80002732:	6fc8                	ld	a0,152(a5)
    80002734:	bfe9                	j	8000270e <argraw+0x2c>
  panic("argraw");
    80002736:	00005517          	auipc	a0,0x5
    8000273a:	cd250513          	addi	a0,a0,-814 # 80007408 <etext+0x408>
    8000273e:	8b2fe0ef          	jal	800007f0 <panic>

0000000080002742 <fetchaddr>:
{
    80002742:	1101                	addi	sp,sp,-32
    80002744:	ec06                	sd	ra,24(sp)
    80002746:	e822                	sd	s0,16(sp)
    80002748:	e426                	sd	s1,8(sp)
    8000274a:	e04a                	sd	s2,0(sp)
    8000274c:	1000                	addi	s0,sp,32
    8000274e:	84aa                	mv	s1,a0
    80002750:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002752:	9deff0ef          	jal	80001930 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002756:	653c                	ld	a5,72(a0)
    80002758:	02f4f663          	bgeu	s1,a5,80002784 <fetchaddr+0x42>
    8000275c:	00848713          	addi	a4,s1,8
    80002760:	02e7e263          	bltu	a5,a4,80002784 <fetchaddr+0x42>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80002764:	46a1                	li	a3,8
    80002766:	8626                	mv	a2,s1
    80002768:	85ca                	mv	a1,s2
    8000276a:	6928                	ld	a0,80(a0)
    8000276c:	f03fe0ef          	jal	8000166e <copyin>
    80002770:	00a03533          	snez	a0,a0
    80002774:	40a0053b          	negw	a0,a0
}
    80002778:	60e2                	ld	ra,24(sp)
    8000277a:	6442                	ld	s0,16(sp)
    8000277c:	64a2                	ld	s1,8(sp)
    8000277e:	6902                	ld	s2,0(sp)
    80002780:	6105                	addi	sp,sp,32
    80002782:	8082                	ret
    return -1;
    80002784:	557d                	li	a0,-1
    80002786:	bfcd                	j	80002778 <fetchaddr+0x36>

0000000080002788 <fetchstr>:
{
    80002788:	7179                	addi	sp,sp,-48
    8000278a:	f406                	sd	ra,40(sp)
    8000278c:	f022                	sd	s0,32(sp)
    8000278e:	ec26                	sd	s1,24(sp)
    80002790:	e84a                	sd	s2,16(sp)
    80002792:	e44e                	sd	s3,8(sp)
    80002794:	1800                	addi	s0,sp,48
    80002796:	89aa                	mv	s3,a0
    80002798:	84ae                	mv	s1,a1
    8000279a:	8932                	mv	s2,a2
  struct proc *p = myproc();
    8000279c:	994ff0ef          	jal	80001930 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    800027a0:	86ca                	mv	a3,s2
    800027a2:	864e                	mv	a2,s3
    800027a4:	85a6                	mv	a1,s1
    800027a6:	6928                	ld	a0,80(a0)
    800027a8:	f4dfe0ef          	jal	800016f4 <copyinstr>
    800027ac:	00054c63          	bltz	a0,800027c4 <fetchstr+0x3c>
  return strlen(buf);
    800027b0:	8526                	mv	a0,s1
    800027b2:	efefe0ef          	jal	80000eb0 <strlen>
}
    800027b6:	70a2                	ld	ra,40(sp)
    800027b8:	7402                	ld	s0,32(sp)
    800027ba:	64e2                	ld	s1,24(sp)
    800027bc:	6942                	ld	s2,16(sp)
    800027be:	69a2                	ld	s3,8(sp)
    800027c0:	6145                	addi	sp,sp,48
    800027c2:	8082                	ret
    return -1;
    800027c4:	557d                	li	a0,-1
    800027c6:	bfc5                	j	800027b6 <fetchstr+0x2e>

00000000800027c8 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    800027c8:	1101                	addi	sp,sp,-32
    800027ca:	ec06                	sd	ra,24(sp)
    800027cc:	e822                	sd	s0,16(sp)
    800027ce:	e426                	sd	s1,8(sp)
    800027d0:	1000                	addi	s0,sp,32
    800027d2:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800027d4:	f0fff0ef          	jal	800026e2 <argraw>
    800027d8:	c088                	sw	a0,0(s1)
}
    800027da:	60e2                	ld	ra,24(sp)
    800027dc:	6442                	ld	s0,16(sp)
    800027de:	64a2                	ld	s1,8(sp)
    800027e0:	6105                	addi	sp,sp,32
    800027e2:	8082                	ret

00000000800027e4 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    800027e4:	1101                	addi	sp,sp,-32
    800027e6:	ec06                	sd	ra,24(sp)
    800027e8:	e822                	sd	s0,16(sp)
    800027ea:	e426                	sd	s1,8(sp)
    800027ec:	1000                	addi	s0,sp,32
    800027ee:	84ae                	mv	s1,a1
  *ip = argraw(n);
    800027f0:	ef3ff0ef          	jal	800026e2 <argraw>
    800027f4:	e088                	sd	a0,0(s1)
}
    800027f6:	60e2                	ld	ra,24(sp)
    800027f8:	6442                	ld	s0,16(sp)
    800027fa:	64a2                	ld	s1,8(sp)
    800027fc:	6105                	addi	sp,sp,32
    800027fe:	8082                	ret

0000000080002800 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002800:	1101                	addi	sp,sp,-32
    80002802:	ec06                	sd	ra,24(sp)
    80002804:	e822                	sd	s0,16(sp)
    80002806:	e426                	sd	s1,8(sp)
    80002808:	e04a                	sd	s2,0(sp)
    8000280a:	1000                	addi	s0,sp,32
    8000280c:	892e                	mv	s2,a1
    8000280e:	84b2                	mv	s1,a2
  *ip = argraw(n);
    80002810:	ed3ff0ef          	jal	800026e2 <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    80002814:	8626                	mv	a2,s1
    80002816:	85ca                	mv	a1,s2
    80002818:	f71ff0ef          	jal	80002788 <fetchstr>
}
    8000281c:	60e2                	ld	ra,24(sp)
    8000281e:	6442                	ld	s0,16(sp)
    80002820:	64a2                	ld	s1,8(sp)
    80002822:	6902                	ld	s2,0(sp)
    80002824:	6105                	addi	sp,sp,32
    80002826:	8082                	ret

0000000080002828 <syscall>:
[SYS_sem_free] sys_sem_free,
};

void
syscall(void)
{
    80002828:	1101                	addi	sp,sp,-32
    8000282a:	ec06                	sd	ra,24(sp)
    8000282c:	e822                	sd	s0,16(sp)
    8000282e:	e426                	sd	s1,8(sp)
    80002830:	e04a                	sd	s2,0(sp)
    80002832:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002834:	8fcff0ef          	jal	80001930 <myproc>
    80002838:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    8000283a:	05853903          	ld	s2,88(a0)
    8000283e:	0a893783          	ld	a5,168(s2)
    80002842:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002846:	37fd                	addiw	a5,a5,-1
    80002848:	4775                	li	a4,29
    8000284a:	00f76f63          	bltu	a4,a5,80002868 <syscall+0x40>
    8000284e:	00369713          	slli	a4,a3,0x3
    80002852:	00005797          	auipc	a5,0x5
    80002856:	f9e78793          	addi	a5,a5,-98 # 800077f0 <syscalls>
    8000285a:	97ba                	add	a5,a5,a4
    8000285c:	639c                	ld	a5,0(a5)
    8000285e:	c789                	beqz	a5,80002868 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002860:	9782                	jalr	a5
    80002862:	06a93823          	sd	a0,112(s2)
    80002866:	a829                	j	80002880 <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002868:	15848613          	addi	a2,s1,344
    8000286c:	588c                	lw	a1,48(s1)
    8000286e:	00005517          	auipc	a0,0x5
    80002872:	ba250513          	addi	a0,a0,-1118 # 80007410 <etext+0x410>
    80002876:	c5dfd0ef          	jal	800004d2 <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    8000287a:	6cbc                	ld	a5,88(s1)
    8000287c:	577d                	li	a4,-1
    8000287e:	fbb8                	sd	a4,112(a5)
  }
}
    80002880:	60e2                	ld	ra,24(sp)
    80002882:	6442                	ld	s0,16(sp)
    80002884:	64a2                	ld	s1,8(sp)
    80002886:	6902                	ld	s2,0(sp)
    80002888:	6105                	addi	sp,sp,32
    8000288a:	8082                	ret

000000008000288c <sys_exit>:
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
    8000288c:	1101                	addi	sp,sp,-32
    8000288e:	ec06                	sd	ra,24(sp)
    80002890:	e822                	sd	s0,16(sp)
    80002892:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002894:	fec40593          	addi	a1,s0,-20
    80002898:	4501                	li	a0,0
    8000289a:	f2fff0ef          	jal	800027c8 <argint>
  exit(n);
    8000289e:	fec42503          	lw	a0,-20(s0)
    800028a2:	f56ff0ef          	jal	80001ff8 <exit>
  return 0;  // not reached
}
    800028a6:	4501                	li	a0,0
    800028a8:	60e2                	ld	ra,24(sp)
    800028aa:	6442                	ld	s0,16(sp)
    800028ac:	6105                	addi	sp,sp,32
    800028ae:	8082                	ret

00000000800028b0 <sys_getpid>:

uint64
sys_getpid(void)
{
    800028b0:	1141                	addi	sp,sp,-16
    800028b2:	e406                	sd	ra,8(sp)
    800028b4:	e022                	sd	s0,0(sp)
    800028b6:	0800                	addi	s0,sp,16
  return myproc()->pid;
    800028b8:	878ff0ef          	jal	80001930 <myproc>
}
    800028bc:	5908                	lw	a0,48(a0)
    800028be:	60a2                	ld	ra,8(sp)
    800028c0:	6402                	ld	s0,0(sp)
    800028c2:	0141                	addi	sp,sp,16
    800028c4:	8082                	ret

00000000800028c6 <sys_fork>:

uint64
sys_fork(void)
{
    800028c6:	1141                	addi	sp,sp,-16
    800028c8:	e406                	sd	ra,8(sp)
    800028ca:	e022                	sd	s0,0(sp)
    800028cc:	0800                	addi	s0,sp,16
  return fork();
    800028ce:	b88ff0ef          	jal	80001c56 <fork>
}
    800028d2:	60a2                	ld	ra,8(sp)
    800028d4:	6402                	ld	s0,0(sp)
    800028d6:	0141                	addi	sp,sp,16
    800028d8:	8082                	ret

00000000800028da <sys_wait>:

uint64
sys_wait(void)
{
    800028da:	1101                	addi	sp,sp,-32
    800028dc:	ec06                	sd	ra,24(sp)
    800028de:	e822                	sd	s0,16(sp)
    800028e0:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    800028e2:	fe840593          	addi	a1,s0,-24
    800028e6:	4501                	li	a0,0
    800028e8:	efdff0ef          	jal	800027e4 <argaddr>
  return wait(p);
    800028ec:	fe843503          	ld	a0,-24(s0)
    800028f0:	863ff0ef          	jal	80002152 <wait>
}
    800028f4:	60e2                	ld	ra,24(sp)
    800028f6:	6442                	ld	s0,16(sp)
    800028f8:	6105                	addi	sp,sp,32
    800028fa:	8082                	ret

00000000800028fc <sys_sbrk>:

uint64
sys_sbrk(void)
{
    800028fc:	7179                	addi	sp,sp,-48
    800028fe:	f406                	sd	ra,40(sp)
    80002900:	f022                	sd	s0,32(sp)
    80002902:	ec26                	sd	s1,24(sp)
    80002904:	1800                	addi	s0,sp,48
  uint64 addr;
  int n;

  argint(0, &n);
    80002906:	fdc40593          	addi	a1,s0,-36
    8000290a:	4501                	li	a0,0
    8000290c:	ebdff0ef          	jal	800027c8 <argint>
  addr = myproc()->sz;
    80002910:	820ff0ef          	jal	80001930 <myproc>
    80002914:	653c                	ld	a5,72(a0)
    80002916:	84be                	mv	s1,a5
  if(growproc(n) < 0)
    80002918:	fdc42503          	lw	a0,-36(s0)
    8000291c:	aeaff0ef          	jal	80001c06 <growproc>
    80002920:	00054863          	bltz	a0,80002930 <sys_sbrk+0x34>
    return -1;
  return addr;
}
    80002924:	8526                	mv	a0,s1
    80002926:	70a2                	ld	ra,40(sp)
    80002928:	7402                	ld	s0,32(sp)
    8000292a:	64e2                	ld	s1,24(sp)
    8000292c:	6145                	addi	sp,sp,48
    8000292e:	8082                	ret
    return -1;
    80002930:	57fd                	li	a5,-1
    80002932:	84be                	mv	s1,a5
    80002934:	bfc5                	j	80002924 <sys_sbrk+0x28>

0000000080002936 <sys_sleep>:

uint64
sys_sleep(void)
{
    80002936:	7139                	addi	sp,sp,-64
    80002938:	fc06                	sd	ra,56(sp)
    8000293a:	f822                	sd	s0,48(sp)
    8000293c:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    8000293e:	fcc40593          	addi	a1,s0,-52
    80002942:	4501                	li	a0,0
    80002944:	e85ff0ef          	jal	800027c8 <argint>
  if(n < 0)
    80002948:	fcc42783          	lw	a5,-52(s0)
    8000294c:	0607c863          	bltz	a5,800029bc <sys_sleep+0x86>
    n = 0;
  acquire(&tickslock);
    80002950:	00013517          	auipc	a0,0x13
    80002954:	f8050513          	addi	a0,a0,-128 # 800158d0 <tickslock>
    80002958:	b0cfe0ef          	jal	80000c64 <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    8000295c:	fcc42783          	lw	a5,-52(s0)
    80002960:	c3b9                	beqz	a5,800029a6 <sys_sleep+0x70>
    80002962:	f426                	sd	s1,40(sp)
    80002964:	f04a                	sd	s2,32(sp)
    80002966:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80002968:	00005997          	auipc	s3,0x5
    8000296c:	0089a983          	lw	s3,8(s3) # 80007970 <ticks>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002970:	00013917          	auipc	s2,0x13
    80002974:	f6090913          	addi	s2,s2,-160 # 800158d0 <tickslock>
    80002978:	00005497          	auipc	s1,0x5
    8000297c:	ff848493          	addi	s1,s1,-8 # 80007970 <ticks>
    if(killed(myproc())){
    80002980:	fb1fe0ef          	jal	80001930 <myproc>
    80002984:	fa4ff0ef          	jal	80002128 <killed>
    80002988:	ed0d                	bnez	a0,800029c2 <sys_sleep+0x8c>
    sleep(&ticks, &tickslock);
    8000298a:	85ca                	mv	a1,s2
    8000298c:	8526                	mv	a0,s1
    8000298e:	d5eff0ef          	jal	80001eec <sleep>
  while(ticks - ticks0 < n){
    80002992:	409c                	lw	a5,0(s1)
    80002994:	413787bb          	subw	a5,a5,s3
    80002998:	fcc42703          	lw	a4,-52(s0)
    8000299c:	fee7e2e3          	bltu	a5,a4,80002980 <sys_sleep+0x4a>
    800029a0:	74a2                	ld	s1,40(sp)
    800029a2:	7902                	ld	s2,32(sp)
    800029a4:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    800029a6:	00013517          	auipc	a0,0x13
    800029aa:	f2a50513          	addi	a0,a0,-214 # 800158d0 <tickslock>
    800029ae:	b46fe0ef          	jal	80000cf4 <release>
  return 0;
    800029b2:	4501                	li	a0,0
}
    800029b4:	70e2                	ld	ra,56(sp)
    800029b6:	7442                	ld	s0,48(sp)
    800029b8:	6121                	addi	sp,sp,64
    800029ba:	8082                	ret
    n = 0;
    800029bc:	fc042623          	sw	zero,-52(s0)
    800029c0:	bf41                	j	80002950 <sys_sleep+0x1a>
      release(&tickslock);
    800029c2:	00013517          	auipc	a0,0x13
    800029c6:	f0e50513          	addi	a0,a0,-242 # 800158d0 <tickslock>
    800029ca:	b2afe0ef          	jal	80000cf4 <release>
      return -1;
    800029ce:	557d                	li	a0,-1
    800029d0:	74a2                	ld	s1,40(sp)
    800029d2:	7902                	ld	s2,32(sp)
    800029d4:	69e2                	ld	s3,24(sp)
    800029d6:	bff9                	j	800029b4 <sys_sleep+0x7e>

00000000800029d8 <sys_kill>:

uint64
sys_kill(void)
{
    800029d8:	1101                	addi	sp,sp,-32
    800029da:	ec06                	sd	ra,24(sp)
    800029dc:	e822                	sd	s0,16(sp)
    800029de:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    800029e0:	fec40593          	addi	a1,s0,-20
    800029e4:	4501                	li	a0,0
    800029e6:	de3ff0ef          	jal	800027c8 <argint>
  return kill(pid);
    800029ea:	fec42503          	lw	a0,-20(s0)
    800029ee:	eb0ff0ef          	jal	8000209e <kill>
}
    800029f2:	60e2                	ld	ra,24(sp)
    800029f4:	6442                	ld	s0,16(sp)
    800029f6:	6105                	addi	sp,sp,32
    800029f8:	8082                	ret

00000000800029fa <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    800029fa:	1101                	addi	sp,sp,-32
    800029fc:	ec06                	sd	ra,24(sp)
    800029fe:	e822                	sd	s0,16(sp)
    80002a00:	e426                	sd	s1,8(sp)
    80002a02:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002a04:	00013517          	auipc	a0,0x13
    80002a08:	ecc50513          	addi	a0,a0,-308 # 800158d0 <tickslock>
    80002a0c:	a58fe0ef          	jal	80000c64 <acquire>
  xticks = ticks;
    80002a10:	00005797          	auipc	a5,0x5
    80002a14:	f607a783          	lw	a5,-160(a5) # 80007970 <ticks>
    80002a18:	84be                	mv	s1,a5
  release(&tickslock);
    80002a1a:	00013517          	auipc	a0,0x13
    80002a1e:	eb650513          	addi	a0,a0,-330 # 800158d0 <tickslock>
    80002a22:	ad2fe0ef          	jal	80000cf4 <release>
  return xticks;
}
    80002a26:	02049513          	slli	a0,s1,0x20
    80002a2a:	9101                	srli	a0,a0,0x20
    80002a2c:	60e2                	ld	ra,24(sp)
    80002a2e:	6442                	ld	s0,16(sp)
    80002a30:	64a2                	ld	s1,8(sp)
    80002a32:	6105                	addi	sp,sp,32
    80002a34:	8082                	ret

0000000080002a36 <sys_ucnt_set>:

// System call wrappers for shared user counter
uint64 sys_ucnt_set(void) {
    80002a36:	1101                	addi	sp,sp,-32
    80002a38:	ec06                	sd	ra,24(sp)
    80002a3a:	e822                	sd	s0,16(sp)
    80002a3c:	1000                	addi	s0,sp,32
  int idx, val;
  argint(0, &idx);
    80002a3e:	fec40593          	addi	a1,s0,-20
    80002a42:	4501                	li	a0,0
    80002a44:	d85ff0ef          	jal	800027c8 <argint>
  argint(1, &val);
    80002a48:	fe840593          	addi	a1,s0,-24
    80002a4c:	4505                	li	a0,1
    80002a4e:	d7bff0ef          	jal	800027c8 <argint>
  ucnt_set(idx, val);
    80002a52:	fe842583          	lw	a1,-24(s0)
    80002a56:	fec42503          	lw	a0,-20(s0)
    80002a5a:	757020ef          	jal	800059b0 <ucnt_set>
  return 0;
}
    80002a5e:	4501                	li	a0,0
    80002a60:	60e2                	ld	ra,24(sp)
    80002a62:	6442                	ld	s0,16(sp)
    80002a64:	6105                	addi	sp,sp,32
    80002a66:	8082                	ret

0000000080002a68 <sys_ucnt_get>:

uint64 sys_ucnt_get(void) {
    80002a68:	1101                	addi	sp,sp,-32
    80002a6a:	ec06                	sd	ra,24(sp)
    80002a6c:	e822                	sd	s0,16(sp)
    80002a6e:	1000                	addi	s0,sp,32
  int idx;
  argint(0, &idx);
    80002a70:	fec40593          	addi	a1,s0,-20
    80002a74:	4501                	li	a0,0
    80002a76:	d53ff0ef          	jal	800027c8 <argint>
  return ucnt_get(idx);
    80002a7a:	fec42503          	lw	a0,-20(s0)
    80002a7e:	757020ef          	jal	800059d4 <ucnt_get>
}
    80002a82:	60e2                	ld	ra,24(sp)
    80002a84:	6442                	ld	s0,16(sp)
    80002a86:	6105                	addi	sp,sp,32
    80002a88:	8082                	ret

0000000080002a8a <sys_ubuf_write>:

// System call wrappers for user buffer
uint64 sys_ubuf_write(void) {
    80002a8a:	1101                	addi	sp,sp,-32
    80002a8c:	ec06                	sd	ra,24(sp)
    80002a8e:	e822                	sd	s0,16(sp)
    80002a90:	1000                	addi	s0,sp,32
  int val;
  argint(0, &val);
    80002a92:	fec40593          	addi	a1,s0,-20
    80002a96:	4501                	li	a0,0
    80002a98:	d31ff0ef          	jal	800027c8 <argint>
  ubuf_write((char)val);
    80002a9c:	fec44503          	lbu	a0,-20(s0)
    80002aa0:	68b020ef          	jal	8000592a <ubuf_write>
  return 0;
}
    80002aa4:	4501                	li	a0,0
    80002aa6:	60e2                	ld	ra,24(sp)
    80002aa8:	6442                	ld	s0,16(sp)
    80002aaa:	6105                	addi	sp,sp,32
    80002aac:	8082                	ret

0000000080002aae <sys_ubuf_read>:

uint64 sys_ubuf_read(void) {
    80002aae:	1141                	addi	sp,sp,-16
    80002ab0:	e406                	sd	ra,8(sp)
    80002ab2:	e022                	sd	s0,0(sp)
    80002ab4:	0800                	addi	s0,sp,16
  return (uint64) ubuf_read();
    80002ab6:	633020ef          	jal	800058e8 <ubuf_read>
}
    80002aba:	60a2                	ld	ra,8(sp)
    80002abc:	6402                	ld	s0,0(sp)
    80002abe:	0141                	addi	sp,sp,16
    80002ac0:	8082                	ret

0000000080002ac2 <sys_sem_init>:

// Kernel-level semaphore syscall handlers
uint64 sys_sem_init(void) {
    80002ac2:	1101                	addi	sp,sp,-32
    80002ac4:	ec06                	sd	ra,24(sp)
    80002ac6:	e822                	sd	s0,16(sp)
    80002ac8:	1000                	addi	s0,sp,32
  int value;
  argint(0, &value);
    80002aca:	fec40593          	addi	a1,s0,-20
    80002ace:	4501                	li	a0,0
    80002ad0:	cf9ff0ef          	jal	800027c8 <argint>
  return sem_alloc(value);
    80002ad4:	fec42503          	lw	a0,-20(s0)
    80002ad8:	781020ef          	jal	80005a58 <sem_alloc>
}
    80002adc:	60e2                	ld	ra,24(sp)
    80002ade:	6442                	ld	s0,16(sp)
    80002ae0:	6105                	addi	sp,sp,32
    80002ae2:	8082                	ret

0000000080002ae4 <sys_sem_wait>:

uint64 sys_sem_wait(void) {
    80002ae4:	1101                	addi	sp,sp,-32
    80002ae6:	ec06                	sd	ra,24(sp)
    80002ae8:	e822                	sd	s0,16(sp)
    80002aea:	1000                	addi	s0,sp,32
  int semid;
  argint(0, &semid);
    80002aec:	fec40593          	addi	a1,s0,-20
    80002af0:	4501                	li	a0,0
    80002af2:	cd7ff0ef          	jal	800027c8 <argint>
  return sem_wait(semid);
    80002af6:	fec42503          	lw	a0,-20(s0)
    80002afa:	01e030ef          	jal	80005b18 <sem_wait>
}
    80002afe:	60e2                	ld	ra,24(sp)
    80002b00:	6442                	ld	s0,16(sp)
    80002b02:	6105                	addi	sp,sp,32
    80002b04:	8082                	ret

0000000080002b06 <sys_sem_signal>:

uint64 sys_sem_signal(void) {
    80002b06:	1101                	addi	sp,sp,-32
    80002b08:	ec06                	sd	ra,24(sp)
    80002b0a:	e822                	sd	s0,16(sp)
    80002b0c:	1000                	addi	s0,sp,32
  int semid;
  argint(0, &semid);
    80002b0e:	fec40593          	addi	a1,s0,-20
    80002b12:	4501                	li	a0,0
    80002b14:	cb5ff0ef          	jal	800027c8 <argint>
  return sem_signal(semid);
    80002b18:	fec42503          	lw	a0,-20(s0)
    80002b1c:	08c030ef          	jal	80005ba8 <sem_signal>
}
    80002b20:	60e2                	ld	ra,24(sp)
    80002b22:	6442                	ld	s0,16(sp)
    80002b24:	6105                	addi	sp,sp,32
    80002b26:	8082                	ret

0000000080002b28 <sys_sem_getvalue>:

uint64 sys_sem_getvalue(void) {
    80002b28:	1101                	addi	sp,sp,-32
    80002b2a:	ec06                	sd	ra,24(sp)
    80002b2c:	e822                	sd	s0,16(sp)
    80002b2e:	1000                	addi	s0,sp,32
  int semid;
  argint(0, &semid);
    80002b30:	fec40593          	addi	a1,s0,-20
    80002b34:	4501                	li	a0,0
    80002b36:	c93ff0ef          	jal	800027c8 <argint>
  return sem_getvalue(semid);
    80002b3a:	fec42503          	lw	a0,-20(s0)
    80002b3e:	0d0030ef          	jal	80005c0e <sem_getvalue>
}
    80002b42:	60e2                	ld	ra,24(sp)
    80002b44:	6442                	ld	s0,16(sp)
    80002b46:	6105                	addi	sp,sp,32
    80002b48:	8082                	ret

0000000080002b4a <sys_sem_free>:

uint64 sys_sem_free(void) {
    80002b4a:	1101                	addi	sp,sp,-32
    80002b4c:	ec06                	sd	ra,24(sp)
    80002b4e:	e822                	sd	s0,16(sp)
    80002b50:	1000                	addi	s0,sp,32
  int semid;
  argint(0, &semid);
    80002b52:	fec40593          	addi	a1,s0,-20
    80002b56:	4501                	li	a0,0
    80002b58:	c71ff0ef          	jal	800027c8 <argint>
  return sem_free(semid);
    80002b5c:	fec42503          	lw	a0,-20(s0)
    80002b60:	76f020ef          	jal	80005ace <sem_free>
}
    80002b64:	60e2                	ld	ra,24(sp)
    80002b66:	6442                	ld	s0,16(sp)
    80002b68:	6105                	addi	sp,sp,32
    80002b6a:	8082                	ret

0000000080002b6c <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002b6c:	7179                	addi	sp,sp,-48
    80002b6e:	f406                	sd	ra,40(sp)
    80002b70:	f022                	sd	s0,32(sp)
    80002b72:	ec26                	sd	s1,24(sp)
    80002b74:	e84a                	sd	s2,16(sp)
    80002b76:	e44e                	sd	s3,8(sp)
    80002b78:	e052                	sd	s4,0(sp)
    80002b7a:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002b7c:	00005597          	auipc	a1,0x5
    80002b80:	8b458593          	addi	a1,a1,-1868 # 80007430 <etext+0x430>
    80002b84:	00013517          	auipc	a0,0x13
    80002b88:	d6450513          	addi	a0,a0,-668 # 800158e8 <bcache>
    80002b8c:	84efe0ef          	jal	80000bda <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002b90:	0001b797          	auipc	a5,0x1b
    80002b94:	d5878793          	addi	a5,a5,-680 # 8001d8e8 <bcache+0x8000>
    80002b98:	0001b717          	auipc	a4,0x1b
    80002b9c:	fb870713          	addi	a4,a4,-72 # 8001db50 <bcache+0x8268>
    80002ba0:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002ba4:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002ba8:	00013497          	auipc	s1,0x13
    80002bac:	d5848493          	addi	s1,s1,-680 # 80015900 <bcache+0x18>
    b->next = bcache.head.next;
    80002bb0:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002bb2:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002bb4:	00005a17          	auipc	s4,0x5
    80002bb8:	884a0a13          	addi	s4,s4,-1916 # 80007438 <etext+0x438>
    b->next = bcache.head.next;
    80002bbc:	2b893783          	ld	a5,696(s2)
    80002bc0:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002bc2:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002bc6:	85d2                	mv	a1,s4
    80002bc8:	01048513          	addi	a0,s1,16
    80002bcc:	25a010ef          	jal	80003e26 <initsleeplock>
    bcache.head.next->prev = b;
    80002bd0:	2b893783          	ld	a5,696(s2)
    80002bd4:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002bd6:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002bda:	45848493          	addi	s1,s1,1112
    80002bde:	fd349fe3          	bne	s1,s3,80002bbc <binit+0x50>
  }
}
    80002be2:	70a2                	ld	ra,40(sp)
    80002be4:	7402                	ld	s0,32(sp)
    80002be6:	64e2                	ld	s1,24(sp)
    80002be8:	6942                	ld	s2,16(sp)
    80002bea:	69a2                	ld	s3,8(sp)
    80002bec:	6a02                	ld	s4,0(sp)
    80002bee:	6145                	addi	sp,sp,48
    80002bf0:	8082                	ret

0000000080002bf2 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002bf2:	7179                	addi	sp,sp,-48
    80002bf4:	f406                	sd	ra,40(sp)
    80002bf6:	f022                	sd	s0,32(sp)
    80002bf8:	ec26                	sd	s1,24(sp)
    80002bfa:	e84a                	sd	s2,16(sp)
    80002bfc:	e44e                	sd	s3,8(sp)
    80002bfe:	1800                	addi	s0,sp,48
    80002c00:	892a                	mv	s2,a0
    80002c02:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002c04:	00013517          	auipc	a0,0x13
    80002c08:	ce450513          	addi	a0,a0,-796 # 800158e8 <bcache>
    80002c0c:	858fe0ef          	jal	80000c64 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002c10:	0001b497          	auipc	s1,0x1b
    80002c14:	f904b483          	ld	s1,-112(s1) # 8001dba0 <bcache+0x82b8>
    80002c18:	0001b797          	auipc	a5,0x1b
    80002c1c:	f3878793          	addi	a5,a5,-200 # 8001db50 <bcache+0x8268>
    80002c20:	02f48b63          	beq	s1,a5,80002c56 <bread+0x64>
    80002c24:	873e                	mv	a4,a5
    80002c26:	a021                	j	80002c2e <bread+0x3c>
    80002c28:	68a4                	ld	s1,80(s1)
    80002c2a:	02e48663          	beq	s1,a4,80002c56 <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002c2e:	449c                	lw	a5,8(s1)
    80002c30:	ff279ce3          	bne	a5,s2,80002c28 <bread+0x36>
    80002c34:	44dc                	lw	a5,12(s1)
    80002c36:	ff3799e3          	bne	a5,s3,80002c28 <bread+0x36>
      b->refcnt++;
    80002c3a:	40bc                	lw	a5,64(s1)
    80002c3c:	2785                	addiw	a5,a5,1
    80002c3e:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002c40:	00013517          	auipc	a0,0x13
    80002c44:	ca850513          	addi	a0,a0,-856 # 800158e8 <bcache>
    80002c48:	8acfe0ef          	jal	80000cf4 <release>
      acquiresleep(&b->lock);
    80002c4c:	01048513          	addi	a0,s1,16
    80002c50:	20c010ef          	jal	80003e5c <acquiresleep>
      return b;
    80002c54:	a889                	j	80002ca6 <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002c56:	0001b497          	auipc	s1,0x1b
    80002c5a:	f424b483          	ld	s1,-190(s1) # 8001db98 <bcache+0x82b0>
    80002c5e:	0001b797          	auipc	a5,0x1b
    80002c62:	ef278793          	addi	a5,a5,-270 # 8001db50 <bcache+0x8268>
    80002c66:	00f48863          	beq	s1,a5,80002c76 <bread+0x84>
    80002c6a:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002c6c:	40bc                	lw	a5,64(s1)
    80002c6e:	cb91                	beqz	a5,80002c82 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002c70:	64a4                	ld	s1,72(s1)
    80002c72:	fee49de3          	bne	s1,a4,80002c6c <bread+0x7a>
  panic("bget: no buffers");
    80002c76:	00004517          	auipc	a0,0x4
    80002c7a:	7ca50513          	addi	a0,a0,1994 # 80007440 <etext+0x440>
    80002c7e:	b73fd0ef          	jal	800007f0 <panic>
      b->dev = dev;
    80002c82:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002c86:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002c8a:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002c8e:	4785                	li	a5,1
    80002c90:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002c92:	00013517          	auipc	a0,0x13
    80002c96:	c5650513          	addi	a0,a0,-938 # 800158e8 <bcache>
    80002c9a:	85afe0ef          	jal	80000cf4 <release>
      acquiresleep(&b->lock);
    80002c9e:	01048513          	addi	a0,s1,16
    80002ca2:	1ba010ef          	jal	80003e5c <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002ca6:	409c                	lw	a5,0(s1)
    80002ca8:	cb89                	beqz	a5,80002cba <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002caa:	8526                	mv	a0,s1
    80002cac:	70a2                	ld	ra,40(sp)
    80002cae:	7402                	ld	s0,32(sp)
    80002cb0:	64e2                	ld	s1,24(sp)
    80002cb2:	6942                	ld	s2,16(sp)
    80002cb4:	69a2                	ld	s3,8(sp)
    80002cb6:	6145                	addi	sp,sp,48
    80002cb8:	8082                	ret
    virtio_disk_rw(b, 0);
    80002cba:	4581                	li	a1,0
    80002cbc:	8526                	mv	a0,s1
    80002cbe:	175020ef          	jal	80005632 <virtio_disk_rw>
    b->valid = 1;
    80002cc2:	4785                	li	a5,1
    80002cc4:	c09c                	sw	a5,0(s1)
  return b;
    80002cc6:	b7d5                	j	80002caa <bread+0xb8>

0000000080002cc8 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80002cc8:	1101                	addi	sp,sp,-32
    80002cca:	ec06                	sd	ra,24(sp)
    80002ccc:	e822                	sd	s0,16(sp)
    80002cce:	e426                	sd	s1,8(sp)
    80002cd0:	1000                	addi	s0,sp,32
    80002cd2:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002cd4:	0541                	addi	a0,a0,16
    80002cd6:	204010ef          	jal	80003eda <holdingsleep>
    80002cda:	c911                	beqz	a0,80002cee <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002cdc:	4585                	li	a1,1
    80002cde:	8526                	mv	a0,s1
    80002ce0:	153020ef          	jal	80005632 <virtio_disk_rw>
}
    80002ce4:	60e2                	ld	ra,24(sp)
    80002ce6:	6442                	ld	s0,16(sp)
    80002ce8:	64a2                	ld	s1,8(sp)
    80002cea:	6105                	addi	sp,sp,32
    80002cec:	8082                	ret
    panic("bwrite");
    80002cee:	00004517          	auipc	a0,0x4
    80002cf2:	76a50513          	addi	a0,a0,1898 # 80007458 <etext+0x458>
    80002cf6:	afbfd0ef          	jal	800007f0 <panic>

0000000080002cfa <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002cfa:	1101                	addi	sp,sp,-32
    80002cfc:	ec06                	sd	ra,24(sp)
    80002cfe:	e822                	sd	s0,16(sp)
    80002d00:	e426                	sd	s1,8(sp)
    80002d02:	e04a                	sd	s2,0(sp)
    80002d04:	1000                	addi	s0,sp,32
    80002d06:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002d08:	01050913          	addi	s2,a0,16
    80002d0c:	854a                	mv	a0,s2
    80002d0e:	1cc010ef          	jal	80003eda <holdingsleep>
    80002d12:	c125                	beqz	a0,80002d72 <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    80002d14:	854a                	mv	a0,s2
    80002d16:	18c010ef          	jal	80003ea2 <releasesleep>

  acquire(&bcache.lock);
    80002d1a:	00013517          	auipc	a0,0x13
    80002d1e:	bce50513          	addi	a0,a0,-1074 # 800158e8 <bcache>
    80002d22:	f43fd0ef          	jal	80000c64 <acquire>
  b->refcnt--;
    80002d26:	40bc                	lw	a5,64(s1)
    80002d28:	37fd                	addiw	a5,a5,-1
    80002d2a:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002d2c:	e79d                	bnez	a5,80002d5a <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002d2e:	68b8                	ld	a4,80(s1)
    80002d30:	64bc                	ld	a5,72(s1)
    80002d32:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002d34:	68b8                	ld	a4,80(s1)
    80002d36:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002d38:	0001b797          	auipc	a5,0x1b
    80002d3c:	bb078793          	addi	a5,a5,-1104 # 8001d8e8 <bcache+0x8000>
    80002d40:	2b87b703          	ld	a4,696(a5)
    80002d44:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002d46:	0001b717          	auipc	a4,0x1b
    80002d4a:	e0a70713          	addi	a4,a4,-502 # 8001db50 <bcache+0x8268>
    80002d4e:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002d50:	2b87b703          	ld	a4,696(a5)
    80002d54:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002d56:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    80002d5a:	00013517          	auipc	a0,0x13
    80002d5e:	b8e50513          	addi	a0,a0,-1138 # 800158e8 <bcache>
    80002d62:	f93fd0ef          	jal	80000cf4 <release>
}
    80002d66:	60e2                	ld	ra,24(sp)
    80002d68:	6442                	ld	s0,16(sp)
    80002d6a:	64a2                	ld	s1,8(sp)
    80002d6c:	6902                	ld	s2,0(sp)
    80002d6e:	6105                	addi	sp,sp,32
    80002d70:	8082                	ret
    panic("brelse");
    80002d72:	00004517          	auipc	a0,0x4
    80002d76:	6ee50513          	addi	a0,a0,1774 # 80007460 <etext+0x460>
    80002d7a:	a77fd0ef          	jal	800007f0 <panic>

0000000080002d7e <bpin>:

void
bpin(struct buf *b) {
    80002d7e:	1101                	addi	sp,sp,-32
    80002d80:	ec06                	sd	ra,24(sp)
    80002d82:	e822                	sd	s0,16(sp)
    80002d84:	e426                	sd	s1,8(sp)
    80002d86:	1000                	addi	s0,sp,32
    80002d88:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002d8a:	00013517          	auipc	a0,0x13
    80002d8e:	b5e50513          	addi	a0,a0,-1186 # 800158e8 <bcache>
    80002d92:	ed3fd0ef          	jal	80000c64 <acquire>
  b->refcnt++;
    80002d96:	40bc                	lw	a5,64(s1)
    80002d98:	2785                	addiw	a5,a5,1
    80002d9a:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002d9c:	00013517          	auipc	a0,0x13
    80002da0:	b4c50513          	addi	a0,a0,-1204 # 800158e8 <bcache>
    80002da4:	f51fd0ef          	jal	80000cf4 <release>
}
    80002da8:	60e2                	ld	ra,24(sp)
    80002daa:	6442                	ld	s0,16(sp)
    80002dac:	64a2                	ld	s1,8(sp)
    80002dae:	6105                	addi	sp,sp,32
    80002db0:	8082                	ret

0000000080002db2 <bunpin>:

void
bunpin(struct buf *b) {
    80002db2:	1101                	addi	sp,sp,-32
    80002db4:	ec06                	sd	ra,24(sp)
    80002db6:	e822                	sd	s0,16(sp)
    80002db8:	e426                	sd	s1,8(sp)
    80002dba:	1000                	addi	s0,sp,32
    80002dbc:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002dbe:	00013517          	auipc	a0,0x13
    80002dc2:	b2a50513          	addi	a0,a0,-1238 # 800158e8 <bcache>
    80002dc6:	e9ffd0ef          	jal	80000c64 <acquire>
  b->refcnt--;
    80002dca:	40bc                	lw	a5,64(s1)
    80002dcc:	37fd                	addiw	a5,a5,-1
    80002dce:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002dd0:	00013517          	auipc	a0,0x13
    80002dd4:	b1850513          	addi	a0,a0,-1256 # 800158e8 <bcache>
    80002dd8:	f1dfd0ef          	jal	80000cf4 <release>
}
    80002ddc:	60e2                	ld	ra,24(sp)
    80002dde:	6442                	ld	s0,16(sp)
    80002de0:	64a2                	ld	s1,8(sp)
    80002de2:	6105                	addi	sp,sp,32
    80002de4:	8082                	ret

0000000080002de6 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002de6:	1101                	addi	sp,sp,-32
    80002de8:	ec06                	sd	ra,24(sp)
    80002dea:	e822                	sd	s0,16(sp)
    80002dec:	e426                	sd	s1,8(sp)
    80002dee:	e04a                	sd	s2,0(sp)
    80002df0:	1000                	addi	s0,sp,32
    80002df2:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002df4:	00d5d79b          	srliw	a5,a1,0xd
    80002df8:	0001b597          	auipc	a1,0x1b
    80002dfc:	1cc5a583          	lw	a1,460(a1) # 8001dfc4 <sb+0x1c>
    80002e00:	9dbd                	addw	a1,a1,a5
    80002e02:	df1ff0ef          	jal	80002bf2 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002e06:	0074f713          	andi	a4,s1,7
    80002e0a:	4785                	li	a5,1
    80002e0c:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    80002e10:	14ce                	slli	s1,s1,0x33
  if((bp->data[bi/8] & m) == 0)
    80002e12:	90d9                	srli	s1,s1,0x36
    80002e14:	00950733          	add	a4,a0,s1
    80002e18:	05874703          	lbu	a4,88(a4)
    80002e1c:	00e7f6b3          	and	a3,a5,a4
    80002e20:	c29d                	beqz	a3,80002e46 <bfree+0x60>
    80002e22:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80002e24:	94aa                	add	s1,s1,a0
    80002e26:	fff7c793          	not	a5,a5
    80002e2a:	8f7d                	and	a4,a4,a5
    80002e2c:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002e30:	729000ef          	jal	80003d58 <log_write>
  brelse(bp);
    80002e34:	854a                	mv	a0,s2
    80002e36:	ec5ff0ef          	jal	80002cfa <brelse>
}
    80002e3a:	60e2                	ld	ra,24(sp)
    80002e3c:	6442                	ld	s0,16(sp)
    80002e3e:	64a2                	ld	s1,8(sp)
    80002e40:	6902                	ld	s2,0(sp)
    80002e42:	6105                	addi	sp,sp,32
    80002e44:	8082                	ret
    panic("freeing free block");
    80002e46:	00004517          	auipc	a0,0x4
    80002e4a:	62250513          	addi	a0,a0,1570 # 80007468 <etext+0x468>
    80002e4e:	9a3fd0ef          	jal	800007f0 <panic>

0000000080002e52 <balloc>:
{
    80002e52:	715d                	addi	sp,sp,-80
    80002e54:	e486                	sd	ra,72(sp)
    80002e56:	e0a2                	sd	s0,64(sp)
    80002e58:	fc26                	sd	s1,56(sp)
    80002e5a:	0880                	addi	s0,sp,80
  for(b = 0; b < sb.size; b += BPB){
    80002e5c:	0001b797          	auipc	a5,0x1b
    80002e60:	1507a783          	lw	a5,336(a5) # 8001dfac <sb+0x4>
    80002e64:	0e078263          	beqz	a5,80002f48 <balloc+0xf6>
    80002e68:	f84a                	sd	s2,48(sp)
    80002e6a:	f44e                	sd	s3,40(sp)
    80002e6c:	f052                	sd	s4,32(sp)
    80002e6e:	ec56                	sd	s5,24(sp)
    80002e70:	e85a                	sd	s6,16(sp)
    80002e72:	e45e                	sd	s7,8(sp)
    80002e74:	e062                	sd	s8,0(sp)
    80002e76:	8baa                	mv	s7,a0
    80002e78:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002e7a:	0001bb17          	auipc	s6,0x1b
    80002e7e:	12eb0b13          	addi	s6,s6,302 # 8001dfa8 <sb>
      m = 1 << (bi % 8);
    80002e82:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002e84:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80002e86:	6c09                	lui	s8,0x2
    80002e88:	a09d                	j	80002eee <balloc+0x9c>
        bp->data[bi/8] |= m;  // Mark block in use.
    80002e8a:	97ca                	add	a5,a5,s2
    80002e8c:	8e55                	or	a2,a2,a3
    80002e8e:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80002e92:	854a                	mv	a0,s2
    80002e94:	6c5000ef          	jal	80003d58 <log_write>
        brelse(bp);
    80002e98:	854a                	mv	a0,s2
    80002e9a:	e61ff0ef          	jal	80002cfa <brelse>
  bp = bread(dev, bno);
    80002e9e:	85a6                	mv	a1,s1
    80002ea0:	855e                	mv	a0,s7
    80002ea2:	d51ff0ef          	jal	80002bf2 <bread>
    80002ea6:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002ea8:	40000613          	li	a2,1024
    80002eac:	4581                	li	a1,0
    80002eae:	05850513          	addi	a0,a0,88
    80002eb2:	e7ffd0ef          	jal	80000d30 <memset>
  log_write(bp);
    80002eb6:	854a                	mv	a0,s2
    80002eb8:	6a1000ef          	jal	80003d58 <log_write>
  brelse(bp);
    80002ebc:	854a                	mv	a0,s2
    80002ebe:	e3dff0ef          	jal	80002cfa <brelse>
        return b + bi;
    80002ec2:	7942                	ld	s2,48(sp)
    80002ec4:	79a2                	ld	s3,40(sp)
    80002ec6:	7a02                	ld	s4,32(sp)
    80002ec8:	6ae2                	ld	s5,24(sp)
    80002eca:	6b42                	ld	s6,16(sp)
    80002ecc:	6ba2                	ld	s7,8(sp)
    80002ece:	6c02                	ld	s8,0(sp)
}
    80002ed0:	8526                	mv	a0,s1
    80002ed2:	60a6                	ld	ra,72(sp)
    80002ed4:	6406                	ld	s0,64(sp)
    80002ed6:	74e2                	ld	s1,56(sp)
    80002ed8:	6161                	addi	sp,sp,80
    80002eda:	8082                	ret
    brelse(bp);
    80002edc:	854a                	mv	a0,s2
    80002ede:	e1dff0ef          	jal	80002cfa <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002ee2:	015c0abb          	addw	s5,s8,s5
    80002ee6:	004b2783          	lw	a5,4(s6)
    80002eea:	04faf863          	bgeu	s5,a5,80002f3a <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    80002eee:	40dad59b          	sraiw	a1,s5,0xd
    80002ef2:	01cb2783          	lw	a5,28(s6)
    80002ef6:	9dbd                	addw	a1,a1,a5
    80002ef8:	855e                	mv	a0,s7
    80002efa:	cf9ff0ef          	jal	80002bf2 <bread>
    80002efe:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002f00:	004b2503          	lw	a0,4(s6)
    80002f04:	84d6                	mv	s1,s5
    80002f06:	4701                	li	a4,0
    80002f08:	fca4fae3          	bgeu	s1,a0,80002edc <balloc+0x8a>
      m = 1 << (bi % 8);
    80002f0c:	00777693          	andi	a3,a4,7
    80002f10:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80002f14:	41f7579b          	sraiw	a5,a4,0x1f
    80002f18:	01d7d79b          	srliw	a5,a5,0x1d
    80002f1c:	9fb9                	addw	a5,a5,a4
    80002f1e:	4037d79b          	sraiw	a5,a5,0x3
    80002f22:	00f90633          	add	a2,s2,a5
    80002f26:	05864603          	lbu	a2,88(a2)
    80002f2a:	00c6f5b3          	and	a1,a3,a2
    80002f2e:	ddb1                	beqz	a1,80002e8a <balloc+0x38>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002f30:	2705                	addiw	a4,a4,1
    80002f32:	2485                	addiw	s1,s1,1
    80002f34:	fd471ae3          	bne	a4,s4,80002f08 <balloc+0xb6>
    80002f38:	b755                	j	80002edc <balloc+0x8a>
    80002f3a:	7942                	ld	s2,48(sp)
    80002f3c:	79a2                	ld	s3,40(sp)
    80002f3e:	7a02                	ld	s4,32(sp)
    80002f40:	6ae2                	ld	s5,24(sp)
    80002f42:	6b42                	ld	s6,16(sp)
    80002f44:	6ba2                	ld	s7,8(sp)
    80002f46:	6c02                	ld	s8,0(sp)
  printf("balloc: out of blocks\n");
    80002f48:	00004517          	auipc	a0,0x4
    80002f4c:	53850513          	addi	a0,a0,1336 # 80007480 <etext+0x480>
    80002f50:	d82fd0ef          	jal	800004d2 <printf>
  return 0;
    80002f54:	4481                	li	s1,0
    80002f56:	bfad                	j	80002ed0 <balloc+0x7e>

0000000080002f58 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80002f58:	7179                	addi	sp,sp,-48
    80002f5a:	f406                	sd	ra,40(sp)
    80002f5c:	f022                	sd	s0,32(sp)
    80002f5e:	ec26                	sd	s1,24(sp)
    80002f60:	e84a                	sd	s2,16(sp)
    80002f62:	e44e                	sd	s3,8(sp)
    80002f64:	1800                	addi	s0,sp,48
    80002f66:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    80002f68:	47ad                	li	a5,11
    80002f6a:	02b7e363          	bltu	a5,a1,80002f90 <bmap+0x38>
    if((addr = ip->addrs[bn]) == 0){
    80002f6e:	02059793          	slli	a5,a1,0x20
    80002f72:	01e7d593          	srli	a1,a5,0x1e
    80002f76:	00b509b3          	add	s3,a0,a1
    80002f7a:	0509a483          	lw	s1,80(s3)
    80002f7e:	e0b5                	bnez	s1,80002fe2 <bmap+0x8a>
      addr = balloc(ip->dev);
    80002f80:	4108                	lw	a0,0(a0)
    80002f82:	ed1ff0ef          	jal	80002e52 <balloc>
    80002f86:	84aa                	mv	s1,a0
      if(addr == 0)
    80002f88:	cd29                	beqz	a0,80002fe2 <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    80002f8a:	04a9a823          	sw	a0,80(s3)
    80002f8e:	a891                	j	80002fe2 <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80002f90:	ff45879b          	addiw	a5,a1,-12
    80002f94:	873e                	mv	a4,a5
    80002f96:	89be                	mv	s3,a5

  if(bn < NINDIRECT){
    80002f98:	0ff00793          	li	a5,255
    80002f9c:	06e7e763          	bltu	a5,a4,8000300a <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    80002fa0:	08052483          	lw	s1,128(a0)
    80002fa4:	e891                	bnez	s1,80002fb8 <bmap+0x60>
      addr = balloc(ip->dev);
    80002fa6:	4108                	lw	a0,0(a0)
    80002fa8:	eabff0ef          	jal	80002e52 <balloc>
    80002fac:	84aa                	mv	s1,a0
      if(addr == 0)
    80002fae:	c915                	beqz	a0,80002fe2 <bmap+0x8a>
    80002fb0:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002fb2:	08a92023          	sw	a0,128(s2)
    80002fb6:	a011                	j	80002fba <bmap+0x62>
    80002fb8:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80002fba:	85a6                	mv	a1,s1
    80002fbc:	00092503          	lw	a0,0(s2)
    80002fc0:	c33ff0ef          	jal	80002bf2 <bread>
    80002fc4:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80002fc6:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80002fca:	02099713          	slli	a4,s3,0x20
    80002fce:	01e75593          	srli	a1,a4,0x1e
    80002fd2:	97ae                	add	a5,a5,a1
    80002fd4:	89be                	mv	s3,a5
    80002fd6:	4384                	lw	s1,0(a5)
    80002fd8:	cc89                	beqz	s1,80002ff2 <bmap+0x9a>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80002fda:	8552                	mv	a0,s4
    80002fdc:	d1fff0ef          	jal	80002cfa <brelse>
    return addr;
    80002fe0:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80002fe2:	8526                	mv	a0,s1
    80002fe4:	70a2                	ld	ra,40(sp)
    80002fe6:	7402                	ld	s0,32(sp)
    80002fe8:	64e2                	ld	s1,24(sp)
    80002fea:	6942                	ld	s2,16(sp)
    80002fec:	69a2                	ld	s3,8(sp)
    80002fee:	6145                	addi	sp,sp,48
    80002ff0:	8082                	ret
      addr = balloc(ip->dev);
    80002ff2:	00092503          	lw	a0,0(s2)
    80002ff6:	e5dff0ef          	jal	80002e52 <balloc>
    80002ffa:	84aa                	mv	s1,a0
      if(addr){
    80002ffc:	dd79                	beqz	a0,80002fda <bmap+0x82>
        a[bn] = addr;
    80002ffe:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    80003002:	8552                	mv	a0,s4
    80003004:	555000ef          	jal	80003d58 <log_write>
    80003008:	bfc9                	j	80002fda <bmap+0x82>
    8000300a:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    8000300c:	00004517          	auipc	a0,0x4
    80003010:	48c50513          	addi	a0,a0,1164 # 80007498 <etext+0x498>
    80003014:	fdcfd0ef          	jal	800007f0 <panic>

0000000080003018 <iget>:
{
    80003018:	7179                	addi	sp,sp,-48
    8000301a:	f406                	sd	ra,40(sp)
    8000301c:	f022                	sd	s0,32(sp)
    8000301e:	ec26                	sd	s1,24(sp)
    80003020:	e84a                	sd	s2,16(sp)
    80003022:	e44e                	sd	s3,8(sp)
    80003024:	e052                	sd	s4,0(sp)
    80003026:	1800                	addi	s0,sp,48
    80003028:	89aa                	mv	s3,a0
    8000302a:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    8000302c:	0001b517          	auipc	a0,0x1b
    80003030:	f9c50513          	addi	a0,a0,-100 # 8001dfc8 <itable>
    80003034:	c31fd0ef          	jal	80000c64 <acquire>
  empty = 0;
    80003038:	4901                	li	s2,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    8000303a:	0001b497          	auipc	s1,0x1b
    8000303e:	fa648493          	addi	s1,s1,-90 # 8001dfe0 <itable+0x18>
    80003042:	0001d697          	auipc	a3,0x1d
    80003046:	a2e68693          	addi	a3,a3,-1490 # 8001fa70 <log>
    8000304a:	a819                	j	80003060 <iget+0x48>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    8000304c:	0017b793          	seqz	a5,a5
    80003050:	00193713          	seqz	a4,s2
    80003054:	8ff9                	and	a5,a5,a4
    80003056:	eb85                	bnez	a5,80003086 <iget+0x6e>
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80003058:	08848493          	addi	s1,s1,136
    8000305c:	02d48763          	beq	s1,a3,8000308a <iget+0x72>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    80003060:	449c                	lw	a5,8(s1)
    80003062:	fef055e3          	blez	a5,8000304c <iget+0x34>
    80003066:	4098                	lw	a4,0(s1)
    80003068:	ff3718e3          	bne	a4,s3,80003058 <iget+0x40>
    8000306c:	40d8                	lw	a4,4(s1)
    8000306e:	ff4715e3          	bne	a4,s4,80003058 <iget+0x40>
      ip->ref++;
    80003072:	2785                	addiw	a5,a5,1
    80003074:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80003076:	0001b517          	auipc	a0,0x1b
    8000307a:	f5250513          	addi	a0,a0,-174 # 8001dfc8 <itable>
    8000307e:	c77fd0ef          	jal	80000cf4 <release>
      return ip;
    80003082:	8926                	mv	s2,s1
    80003084:	a025                	j	800030ac <iget+0x94>
      empty = ip;
    80003086:	8926                	mv	s2,s1
    80003088:	bfc1                	j	80003058 <iget+0x40>
  if(empty == 0)
    8000308a:	02090a63          	beqz	s2,800030be <iget+0xa6>
  ip->dev = dev;
    8000308e:	01392023          	sw	s3,0(s2)
  ip->inum = inum;
    80003092:	01492223          	sw	s4,4(s2)
  ip->ref = 1;
    80003096:	4785                	li	a5,1
    80003098:	00f92423          	sw	a5,8(s2)
  ip->valid = 0;
    8000309c:	04092023          	sw	zero,64(s2)
  release(&itable.lock);
    800030a0:	0001b517          	auipc	a0,0x1b
    800030a4:	f2850513          	addi	a0,a0,-216 # 8001dfc8 <itable>
    800030a8:	c4dfd0ef          	jal	80000cf4 <release>
}
    800030ac:	854a                	mv	a0,s2
    800030ae:	70a2                	ld	ra,40(sp)
    800030b0:	7402                	ld	s0,32(sp)
    800030b2:	64e2                	ld	s1,24(sp)
    800030b4:	6942                	ld	s2,16(sp)
    800030b6:	69a2                	ld	s3,8(sp)
    800030b8:	6a02                	ld	s4,0(sp)
    800030ba:	6145                	addi	sp,sp,48
    800030bc:	8082                	ret
    panic("iget: no inodes");
    800030be:	00004517          	auipc	a0,0x4
    800030c2:	3f250513          	addi	a0,a0,1010 # 800074b0 <etext+0x4b0>
    800030c6:	f2afd0ef          	jal	800007f0 <panic>

00000000800030ca <fsinit>:
fsinit(int dev) {
    800030ca:	1101                	addi	sp,sp,-32
    800030cc:	ec06                	sd	ra,24(sp)
    800030ce:	e822                	sd	s0,16(sp)
    800030d0:	e426                	sd	s1,8(sp)
    800030d2:	e04a                	sd	s2,0(sp)
    800030d4:	1000                	addi	s0,sp,32
    800030d6:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    800030d8:	4585                	li	a1,1
    800030da:	b19ff0ef          	jal	80002bf2 <bread>
    800030de:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    800030e0:	02000613          	li	a2,32
    800030e4:	05850593          	addi	a1,a0,88
    800030e8:	0001b517          	auipc	a0,0x1b
    800030ec:	ec050513          	addi	a0,a0,-320 # 8001dfa8 <sb>
    800030f0:	c9dfd0ef          	jal	80000d8c <memmove>
  brelse(bp);
    800030f4:	8526                	mv	a0,s1
    800030f6:	c05ff0ef          	jal	80002cfa <brelse>
  if(sb.magic != FSMAGIC)
    800030fa:	0001b717          	auipc	a4,0x1b
    800030fe:	eae72703          	lw	a4,-338(a4) # 8001dfa8 <sb>
    80003102:	102037b7          	lui	a5,0x10203
    80003106:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    8000310a:	00f71f63          	bne	a4,a5,80003128 <fsinit+0x5e>
  initlog(dev, &sb);
    8000310e:	0001b597          	auipc	a1,0x1b
    80003112:	e9a58593          	addi	a1,a1,-358 # 8001dfa8 <sb>
    80003116:	854a                	mv	a0,s2
    80003118:	223000ef          	jal	80003b3a <initlog>
}
    8000311c:	60e2                	ld	ra,24(sp)
    8000311e:	6442                	ld	s0,16(sp)
    80003120:	64a2                	ld	s1,8(sp)
    80003122:	6902                	ld	s2,0(sp)
    80003124:	6105                	addi	sp,sp,32
    80003126:	8082                	ret
    panic("invalid file system");
    80003128:	00004517          	auipc	a0,0x4
    8000312c:	39850513          	addi	a0,a0,920 # 800074c0 <etext+0x4c0>
    80003130:	ec0fd0ef          	jal	800007f0 <panic>

0000000080003134 <iinit>:
{
    80003134:	7179                	addi	sp,sp,-48
    80003136:	f406                	sd	ra,40(sp)
    80003138:	f022                	sd	s0,32(sp)
    8000313a:	ec26                	sd	s1,24(sp)
    8000313c:	e84a                	sd	s2,16(sp)
    8000313e:	e44e                	sd	s3,8(sp)
    80003140:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80003142:	00004597          	auipc	a1,0x4
    80003146:	39658593          	addi	a1,a1,918 # 800074d8 <etext+0x4d8>
    8000314a:	0001b517          	auipc	a0,0x1b
    8000314e:	e7e50513          	addi	a0,a0,-386 # 8001dfc8 <itable>
    80003152:	a89fd0ef          	jal	80000bda <initlock>
  for(i = 0; i < NINODE; i++) {
    80003156:	0001b497          	auipc	s1,0x1b
    8000315a:	e9a48493          	addi	s1,s1,-358 # 8001dff0 <itable+0x28>
    8000315e:	0001d997          	auipc	s3,0x1d
    80003162:	92298993          	addi	s3,s3,-1758 # 8001fa80 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    80003166:	00004917          	auipc	s2,0x4
    8000316a:	37a90913          	addi	s2,s2,890 # 800074e0 <etext+0x4e0>
    8000316e:	85ca                	mv	a1,s2
    80003170:	8526                	mv	a0,s1
    80003172:	4b5000ef          	jal	80003e26 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    80003176:	08848493          	addi	s1,s1,136
    8000317a:	ff349ae3          	bne	s1,s3,8000316e <iinit+0x3a>
}
    8000317e:	70a2                	ld	ra,40(sp)
    80003180:	7402                	ld	s0,32(sp)
    80003182:	64e2                	ld	s1,24(sp)
    80003184:	6942                	ld	s2,16(sp)
    80003186:	69a2                	ld	s3,8(sp)
    80003188:	6145                	addi	sp,sp,48
    8000318a:	8082                	ret

000000008000318c <ialloc>:
{
    8000318c:	7139                	addi	sp,sp,-64
    8000318e:	fc06                	sd	ra,56(sp)
    80003190:	f822                	sd	s0,48(sp)
    80003192:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    80003194:	0001b717          	auipc	a4,0x1b
    80003198:	e2072703          	lw	a4,-480(a4) # 8001dfb4 <sb+0xc>
    8000319c:	4785                	li	a5,1
    8000319e:	06e7f063          	bgeu	a5,a4,800031fe <ialloc+0x72>
    800031a2:	f426                	sd	s1,40(sp)
    800031a4:	f04a                	sd	s2,32(sp)
    800031a6:	ec4e                	sd	s3,24(sp)
    800031a8:	e852                	sd	s4,16(sp)
    800031aa:	e456                	sd	s5,8(sp)
    800031ac:	e05a                	sd	s6,0(sp)
    800031ae:	8aaa                	mv	s5,a0
    800031b0:	8b2e                	mv	s6,a1
    800031b2:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    800031b4:	0001ba17          	auipc	s4,0x1b
    800031b8:	df4a0a13          	addi	s4,s4,-524 # 8001dfa8 <sb>
    800031bc:	00495593          	srli	a1,s2,0x4
    800031c0:	018a2783          	lw	a5,24(s4)
    800031c4:	9dbd                	addw	a1,a1,a5
    800031c6:	8556                	mv	a0,s5
    800031c8:	a2bff0ef          	jal	80002bf2 <bread>
    800031cc:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    800031ce:	05850993          	addi	s3,a0,88
    800031d2:	00f97793          	andi	a5,s2,15
    800031d6:	079a                	slli	a5,a5,0x6
    800031d8:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    800031da:	00099783          	lh	a5,0(s3)
    800031de:	cb9d                	beqz	a5,80003214 <ialloc+0x88>
    brelse(bp);
    800031e0:	b1bff0ef          	jal	80002cfa <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    800031e4:	0905                	addi	s2,s2,1
    800031e6:	00ca2703          	lw	a4,12(s4)
    800031ea:	0009079b          	sext.w	a5,s2
    800031ee:	fce7e7e3          	bltu	a5,a4,800031bc <ialloc+0x30>
    800031f2:	74a2                	ld	s1,40(sp)
    800031f4:	7902                	ld	s2,32(sp)
    800031f6:	69e2                	ld	s3,24(sp)
    800031f8:	6a42                	ld	s4,16(sp)
    800031fa:	6aa2                	ld	s5,8(sp)
    800031fc:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    800031fe:	00004517          	auipc	a0,0x4
    80003202:	2ea50513          	addi	a0,a0,746 # 800074e8 <etext+0x4e8>
    80003206:	accfd0ef          	jal	800004d2 <printf>
  return 0;
    8000320a:	4501                	li	a0,0
}
    8000320c:	70e2                	ld	ra,56(sp)
    8000320e:	7442                	ld	s0,48(sp)
    80003210:	6121                	addi	sp,sp,64
    80003212:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003214:	04000613          	li	a2,64
    80003218:	4581                	li	a1,0
    8000321a:	854e                	mv	a0,s3
    8000321c:	b15fd0ef          	jal	80000d30 <memset>
      dip->type = type;
    80003220:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80003224:	8526                	mv	a0,s1
    80003226:	333000ef          	jal	80003d58 <log_write>
      brelse(bp);
    8000322a:	8526                	mv	a0,s1
    8000322c:	acfff0ef          	jal	80002cfa <brelse>
      return iget(dev, inum);
    80003230:	0009059b          	sext.w	a1,s2
    80003234:	8556                	mv	a0,s5
    80003236:	de3ff0ef          	jal	80003018 <iget>
    8000323a:	74a2                	ld	s1,40(sp)
    8000323c:	7902                	ld	s2,32(sp)
    8000323e:	69e2                	ld	s3,24(sp)
    80003240:	6a42                	ld	s4,16(sp)
    80003242:	6aa2                	ld	s5,8(sp)
    80003244:	6b02                	ld	s6,0(sp)
    80003246:	b7d9                	j	8000320c <ialloc+0x80>

0000000080003248 <iupdate>:
{
    80003248:	1101                	addi	sp,sp,-32
    8000324a:	ec06                	sd	ra,24(sp)
    8000324c:	e822                	sd	s0,16(sp)
    8000324e:	e426                	sd	s1,8(sp)
    80003250:	e04a                	sd	s2,0(sp)
    80003252:	1000                	addi	s0,sp,32
    80003254:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003256:	415c                	lw	a5,4(a0)
    80003258:	0047d79b          	srliw	a5,a5,0x4
    8000325c:	0001b597          	auipc	a1,0x1b
    80003260:	d645a583          	lw	a1,-668(a1) # 8001dfc0 <sb+0x18>
    80003264:	9dbd                	addw	a1,a1,a5
    80003266:	4108                	lw	a0,0(a0)
    80003268:	98bff0ef          	jal	80002bf2 <bread>
    8000326c:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000326e:	05850793          	addi	a5,a0,88
    80003272:	40d8                	lw	a4,4(s1)
    80003274:	8b3d                	andi	a4,a4,15
    80003276:	071a                	slli	a4,a4,0x6
    80003278:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    8000327a:	04449703          	lh	a4,68(s1)
    8000327e:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    80003282:	04649703          	lh	a4,70(s1)
    80003286:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    8000328a:	04849703          	lh	a4,72(s1)
    8000328e:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    80003292:	04a49703          	lh	a4,74(s1)
    80003296:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    8000329a:	44f8                	lw	a4,76(s1)
    8000329c:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    8000329e:	03400613          	li	a2,52
    800032a2:	05048593          	addi	a1,s1,80
    800032a6:	00c78513          	addi	a0,a5,12
    800032aa:	ae3fd0ef          	jal	80000d8c <memmove>
  log_write(bp);
    800032ae:	854a                	mv	a0,s2
    800032b0:	2a9000ef          	jal	80003d58 <log_write>
  brelse(bp);
    800032b4:	854a                	mv	a0,s2
    800032b6:	a45ff0ef          	jal	80002cfa <brelse>
}
    800032ba:	60e2                	ld	ra,24(sp)
    800032bc:	6442                	ld	s0,16(sp)
    800032be:	64a2                	ld	s1,8(sp)
    800032c0:	6902                	ld	s2,0(sp)
    800032c2:	6105                	addi	sp,sp,32
    800032c4:	8082                	ret

00000000800032c6 <idup>:
{
    800032c6:	1101                	addi	sp,sp,-32
    800032c8:	ec06                	sd	ra,24(sp)
    800032ca:	e822                	sd	s0,16(sp)
    800032cc:	e426                	sd	s1,8(sp)
    800032ce:	1000                	addi	s0,sp,32
    800032d0:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800032d2:	0001b517          	auipc	a0,0x1b
    800032d6:	cf650513          	addi	a0,a0,-778 # 8001dfc8 <itable>
    800032da:	98bfd0ef          	jal	80000c64 <acquire>
  ip->ref++;
    800032de:	449c                	lw	a5,8(s1)
    800032e0:	2785                	addiw	a5,a5,1
    800032e2:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800032e4:	0001b517          	auipc	a0,0x1b
    800032e8:	ce450513          	addi	a0,a0,-796 # 8001dfc8 <itable>
    800032ec:	a09fd0ef          	jal	80000cf4 <release>
}
    800032f0:	8526                	mv	a0,s1
    800032f2:	60e2                	ld	ra,24(sp)
    800032f4:	6442                	ld	s0,16(sp)
    800032f6:	64a2                	ld	s1,8(sp)
    800032f8:	6105                	addi	sp,sp,32
    800032fa:	8082                	ret

00000000800032fc <ilock>:
{
    800032fc:	1101                	addi	sp,sp,-32
    800032fe:	ec06                	sd	ra,24(sp)
    80003300:	e822                	sd	s0,16(sp)
    80003302:	e426                	sd	s1,8(sp)
    80003304:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    80003306:	cd19                	beqz	a0,80003324 <ilock+0x28>
    80003308:	84aa                	mv	s1,a0
    8000330a:	451c                	lw	a5,8(a0)
    8000330c:	00f05c63          	blez	a5,80003324 <ilock+0x28>
  acquiresleep(&ip->lock);
    80003310:	0541                	addi	a0,a0,16
    80003312:	34b000ef          	jal	80003e5c <acquiresleep>
  if(ip->valid == 0){
    80003316:	40bc                	lw	a5,64(s1)
    80003318:	cf89                	beqz	a5,80003332 <ilock+0x36>
}
    8000331a:	60e2                	ld	ra,24(sp)
    8000331c:	6442                	ld	s0,16(sp)
    8000331e:	64a2                	ld	s1,8(sp)
    80003320:	6105                	addi	sp,sp,32
    80003322:	8082                	ret
    80003324:	e04a                	sd	s2,0(sp)
    panic("ilock");
    80003326:	00004517          	auipc	a0,0x4
    8000332a:	1da50513          	addi	a0,a0,474 # 80007500 <etext+0x500>
    8000332e:	cc2fd0ef          	jal	800007f0 <panic>
    80003332:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003334:	40dc                	lw	a5,4(s1)
    80003336:	0047d79b          	srliw	a5,a5,0x4
    8000333a:	0001b597          	auipc	a1,0x1b
    8000333e:	c865a583          	lw	a1,-890(a1) # 8001dfc0 <sb+0x18>
    80003342:	9dbd                	addw	a1,a1,a5
    80003344:	4088                	lw	a0,0(s1)
    80003346:	8adff0ef          	jal	80002bf2 <bread>
    8000334a:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000334c:	05850593          	addi	a1,a0,88
    80003350:	40dc                	lw	a5,4(s1)
    80003352:	8bbd                	andi	a5,a5,15
    80003354:	079a                	slli	a5,a5,0x6
    80003356:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80003358:	00059783          	lh	a5,0(a1)
    8000335c:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    80003360:	00259783          	lh	a5,2(a1)
    80003364:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80003368:	00459783          	lh	a5,4(a1)
    8000336c:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    80003370:	00659783          	lh	a5,6(a1)
    80003374:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80003378:	459c                	lw	a5,8(a1)
    8000337a:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    8000337c:	03400613          	li	a2,52
    80003380:	05b1                	addi	a1,a1,12
    80003382:	05048513          	addi	a0,s1,80
    80003386:	a07fd0ef          	jal	80000d8c <memmove>
    brelse(bp);
    8000338a:	854a                	mv	a0,s2
    8000338c:	96fff0ef          	jal	80002cfa <brelse>
    ip->valid = 1;
    80003390:	4785                	li	a5,1
    80003392:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    80003394:	04449783          	lh	a5,68(s1)
    80003398:	c399                	beqz	a5,8000339e <ilock+0xa2>
    8000339a:	6902                	ld	s2,0(sp)
    8000339c:	bfbd                	j	8000331a <ilock+0x1e>
      panic("ilock: no type");
    8000339e:	00004517          	auipc	a0,0x4
    800033a2:	16a50513          	addi	a0,a0,362 # 80007508 <etext+0x508>
    800033a6:	c4afd0ef          	jal	800007f0 <panic>

00000000800033aa <iunlock>:
{
    800033aa:	1101                	addi	sp,sp,-32
    800033ac:	ec06                	sd	ra,24(sp)
    800033ae:	e822                	sd	s0,16(sp)
    800033b0:	e426                	sd	s1,8(sp)
    800033b2:	e04a                	sd	s2,0(sp)
    800033b4:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    800033b6:	c505                	beqz	a0,800033de <iunlock+0x34>
    800033b8:	84aa                	mv	s1,a0
    800033ba:	01050913          	addi	s2,a0,16
    800033be:	854a                	mv	a0,s2
    800033c0:	31b000ef          	jal	80003eda <holdingsleep>
    800033c4:	cd09                	beqz	a0,800033de <iunlock+0x34>
    800033c6:	449c                	lw	a5,8(s1)
    800033c8:	00f05b63          	blez	a5,800033de <iunlock+0x34>
  releasesleep(&ip->lock);
    800033cc:	854a                	mv	a0,s2
    800033ce:	2d5000ef          	jal	80003ea2 <releasesleep>
}
    800033d2:	60e2                	ld	ra,24(sp)
    800033d4:	6442                	ld	s0,16(sp)
    800033d6:	64a2                	ld	s1,8(sp)
    800033d8:	6902                	ld	s2,0(sp)
    800033da:	6105                	addi	sp,sp,32
    800033dc:	8082                	ret
    panic("iunlock");
    800033de:	00004517          	auipc	a0,0x4
    800033e2:	13a50513          	addi	a0,a0,314 # 80007518 <etext+0x518>
    800033e6:	c0afd0ef          	jal	800007f0 <panic>

00000000800033ea <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    800033ea:	7179                	addi	sp,sp,-48
    800033ec:	f406                	sd	ra,40(sp)
    800033ee:	f022                	sd	s0,32(sp)
    800033f0:	ec26                	sd	s1,24(sp)
    800033f2:	e84a                	sd	s2,16(sp)
    800033f4:	e44e                	sd	s3,8(sp)
    800033f6:	1800                	addi	s0,sp,48
    800033f8:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    800033fa:	05050493          	addi	s1,a0,80
    800033fe:	08050913          	addi	s2,a0,128
    80003402:	a021                	j	8000340a <itrunc+0x20>
    80003404:	0491                	addi	s1,s1,4
    80003406:	01248b63          	beq	s1,s2,8000341c <itrunc+0x32>
    if(ip->addrs[i]){
    8000340a:	408c                	lw	a1,0(s1)
    8000340c:	dde5                	beqz	a1,80003404 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    8000340e:	0009a503          	lw	a0,0(s3)
    80003412:	9d5ff0ef          	jal	80002de6 <bfree>
      ip->addrs[i] = 0;
    80003416:	0004a023          	sw	zero,0(s1)
    8000341a:	b7ed                	j	80003404 <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    8000341c:	0809a583          	lw	a1,128(s3)
    80003420:	ed89                	bnez	a1,8000343a <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    80003422:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003426:	854e                	mv	a0,s3
    80003428:	e21ff0ef          	jal	80003248 <iupdate>
}
    8000342c:	70a2                	ld	ra,40(sp)
    8000342e:	7402                	ld	s0,32(sp)
    80003430:	64e2                	ld	s1,24(sp)
    80003432:	6942                	ld	s2,16(sp)
    80003434:	69a2                	ld	s3,8(sp)
    80003436:	6145                	addi	sp,sp,48
    80003438:	8082                	ret
    8000343a:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    8000343c:	0009a503          	lw	a0,0(s3)
    80003440:	fb2ff0ef          	jal	80002bf2 <bread>
    80003444:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80003446:	05850493          	addi	s1,a0,88
    8000344a:	45850913          	addi	s2,a0,1112
    8000344e:	a021                	j	80003456 <itrunc+0x6c>
    80003450:	0491                	addi	s1,s1,4
    80003452:	01248963          	beq	s1,s2,80003464 <itrunc+0x7a>
      if(a[j])
    80003456:	408c                	lw	a1,0(s1)
    80003458:	dde5                	beqz	a1,80003450 <itrunc+0x66>
        bfree(ip->dev, a[j]);
    8000345a:	0009a503          	lw	a0,0(s3)
    8000345e:	989ff0ef          	jal	80002de6 <bfree>
    80003462:	b7fd                	j	80003450 <itrunc+0x66>
    brelse(bp);
    80003464:	8552                	mv	a0,s4
    80003466:	895ff0ef          	jal	80002cfa <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    8000346a:	0809a583          	lw	a1,128(s3)
    8000346e:	0009a503          	lw	a0,0(s3)
    80003472:	975ff0ef          	jal	80002de6 <bfree>
    ip->addrs[NDIRECT] = 0;
    80003476:	0809a023          	sw	zero,128(s3)
    8000347a:	6a02                	ld	s4,0(sp)
    8000347c:	b75d                	j	80003422 <itrunc+0x38>

000000008000347e <iput>:
{
    8000347e:	1101                	addi	sp,sp,-32
    80003480:	ec06                	sd	ra,24(sp)
    80003482:	e822                	sd	s0,16(sp)
    80003484:	e426                	sd	s1,8(sp)
    80003486:	1000                	addi	s0,sp,32
    80003488:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    8000348a:	0001b517          	auipc	a0,0x1b
    8000348e:	b3e50513          	addi	a0,a0,-1218 # 8001dfc8 <itable>
    80003492:	fd2fd0ef          	jal	80000c64 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003496:	4498                	lw	a4,8(s1)
    80003498:	4785                	li	a5,1
    8000349a:	02f70063          	beq	a4,a5,800034ba <iput+0x3c>
  ip->ref--;
    8000349e:	449c                	lw	a5,8(s1)
    800034a0:	37fd                	addiw	a5,a5,-1
    800034a2:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800034a4:	0001b517          	auipc	a0,0x1b
    800034a8:	b2450513          	addi	a0,a0,-1244 # 8001dfc8 <itable>
    800034ac:	849fd0ef          	jal	80000cf4 <release>
}
    800034b0:	60e2                	ld	ra,24(sp)
    800034b2:	6442                	ld	s0,16(sp)
    800034b4:	64a2                	ld	s1,8(sp)
    800034b6:	6105                	addi	sp,sp,32
    800034b8:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800034ba:	40bc                	lw	a5,64(s1)
    800034bc:	d3ed                	beqz	a5,8000349e <iput+0x20>
    800034be:	04a49783          	lh	a5,74(s1)
    800034c2:	fff1                	bnez	a5,8000349e <iput+0x20>
    800034c4:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    800034c6:	01048793          	addi	a5,s1,16
    800034ca:	893e                	mv	s2,a5
    800034cc:	853e                	mv	a0,a5
    800034ce:	18f000ef          	jal	80003e5c <acquiresleep>
    release(&itable.lock);
    800034d2:	0001b517          	auipc	a0,0x1b
    800034d6:	af650513          	addi	a0,a0,-1290 # 8001dfc8 <itable>
    800034da:	81bfd0ef          	jal	80000cf4 <release>
    itrunc(ip);
    800034de:	8526                	mv	a0,s1
    800034e0:	f0bff0ef          	jal	800033ea <itrunc>
    ip->type = 0;
    800034e4:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    800034e8:	8526                	mv	a0,s1
    800034ea:	d5fff0ef          	jal	80003248 <iupdate>
    ip->valid = 0;
    800034ee:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    800034f2:	854a                	mv	a0,s2
    800034f4:	1af000ef          	jal	80003ea2 <releasesleep>
    acquire(&itable.lock);
    800034f8:	0001b517          	auipc	a0,0x1b
    800034fc:	ad050513          	addi	a0,a0,-1328 # 8001dfc8 <itable>
    80003500:	f64fd0ef          	jal	80000c64 <acquire>
    80003504:	6902                	ld	s2,0(sp)
    80003506:	bf61                	j	8000349e <iput+0x20>

0000000080003508 <iunlockput>:
{
    80003508:	1101                	addi	sp,sp,-32
    8000350a:	ec06                	sd	ra,24(sp)
    8000350c:	e822                	sd	s0,16(sp)
    8000350e:	e426                	sd	s1,8(sp)
    80003510:	1000                	addi	s0,sp,32
    80003512:	84aa                	mv	s1,a0
  iunlock(ip);
    80003514:	e97ff0ef          	jal	800033aa <iunlock>
  iput(ip);
    80003518:	8526                	mv	a0,s1
    8000351a:	f65ff0ef          	jal	8000347e <iput>
}
    8000351e:	60e2                	ld	ra,24(sp)
    80003520:	6442                	ld	s0,16(sp)
    80003522:	64a2                	ld	s1,8(sp)
    80003524:	6105                	addi	sp,sp,32
    80003526:	8082                	ret

0000000080003528 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80003528:	1141                	addi	sp,sp,-16
    8000352a:	e406                	sd	ra,8(sp)
    8000352c:	e022                	sd	s0,0(sp)
    8000352e:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003530:	411c                	lw	a5,0(a0)
    80003532:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80003534:	415c                	lw	a5,4(a0)
    80003536:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80003538:	04451783          	lh	a5,68(a0)
    8000353c:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003540:	04a51783          	lh	a5,74(a0)
    80003544:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003548:	04c56783          	lwu	a5,76(a0)
    8000354c:	e99c                	sd	a5,16(a1)
}
    8000354e:	60a2                	ld	ra,8(sp)
    80003550:	6402                	ld	s0,0(sp)
    80003552:	0141                	addi	sp,sp,16
    80003554:	8082                	ret

0000000080003556 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003556:	457c                	lw	a5,76(a0)
    80003558:	0ed7e663          	bltu	a5,a3,80003644 <readi+0xee>
{
    8000355c:	7159                	addi	sp,sp,-112
    8000355e:	f486                	sd	ra,104(sp)
    80003560:	f0a2                	sd	s0,96(sp)
    80003562:	eca6                	sd	s1,88(sp)
    80003564:	e0d2                	sd	s4,64(sp)
    80003566:	fc56                	sd	s5,56(sp)
    80003568:	f85a                	sd	s6,48(sp)
    8000356a:	f45e                	sd	s7,40(sp)
    8000356c:	1880                	addi	s0,sp,112
    8000356e:	8b2a                	mv	s6,a0
    80003570:	8bae                	mv	s7,a1
    80003572:	8a32                	mv	s4,a2
    80003574:	84b6                	mv	s1,a3
    80003576:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80003578:	9f35                	addw	a4,a4,a3
    return 0;
    8000357a:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    8000357c:	0ad76b63          	bltu	a4,a3,80003632 <readi+0xdc>
    80003580:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    80003582:	00e7f463          	bgeu	a5,a4,8000358a <readi+0x34>
    n = ip->size - off;
    80003586:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    8000358a:	080a8b63          	beqz	s5,80003620 <readi+0xca>
    8000358e:	e8ca                	sd	s2,80(sp)
    80003590:	f062                	sd	s8,32(sp)
    80003592:	ec66                	sd	s9,24(sp)
    80003594:	e86a                	sd	s10,16(sp)
    80003596:	e46e                	sd	s11,8(sp)
    80003598:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    8000359a:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    8000359e:	5c7d                	li	s8,-1
    800035a0:	a80d                	j	800035d2 <readi+0x7c>
    800035a2:	020d1d93          	slli	s11,s10,0x20
    800035a6:	020ddd93          	srli	s11,s11,0x20
    800035aa:	05890613          	addi	a2,s2,88
    800035ae:	86ee                	mv	a3,s11
    800035b0:	963e                	add	a2,a2,a5
    800035b2:	85d2                	mv	a1,s4
    800035b4:	855e                	mv	a0,s7
    800035b6:	c8ffe0ef          	jal	80002244 <either_copyout>
    800035ba:	05850363          	beq	a0,s8,80003600 <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    800035be:	854a                	mv	a0,s2
    800035c0:	f3aff0ef          	jal	80002cfa <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800035c4:	013d09bb          	addw	s3,s10,s3
    800035c8:	009d04bb          	addw	s1,s10,s1
    800035cc:	9a6e                	add	s4,s4,s11
    800035ce:	0559f363          	bgeu	s3,s5,80003614 <readi+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    800035d2:	00a4d59b          	srliw	a1,s1,0xa
    800035d6:	855a                	mv	a0,s6
    800035d8:	981ff0ef          	jal	80002f58 <bmap>
    800035dc:	85aa                	mv	a1,a0
    if(addr == 0)
    800035de:	c139                	beqz	a0,80003624 <readi+0xce>
    bp = bread(ip->dev, addr);
    800035e0:	000b2503          	lw	a0,0(s6)
    800035e4:	e0eff0ef          	jal	80002bf2 <bread>
    800035e8:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    800035ea:	3ff4f793          	andi	a5,s1,1023
    800035ee:	40fc873b          	subw	a4,s9,a5
    800035f2:	413a86bb          	subw	a3,s5,s3
    800035f6:	8d3a                	mv	s10,a4
    800035f8:	fae6f5e3          	bgeu	a3,a4,800035a2 <readi+0x4c>
    800035fc:	8d36                	mv	s10,a3
    800035fe:	b755                	j	800035a2 <readi+0x4c>
      brelse(bp);
    80003600:	854a                	mv	a0,s2
    80003602:	ef8ff0ef          	jal	80002cfa <brelse>
      tot = -1;
    80003606:	59fd                	li	s3,-1
      break;
    80003608:	6946                	ld	s2,80(sp)
    8000360a:	7c02                	ld	s8,32(sp)
    8000360c:	6ce2                	ld	s9,24(sp)
    8000360e:	6d42                	ld	s10,16(sp)
    80003610:	6da2                	ld	s11,8(sp)
    80003612:	a831                	j	8000362e <readi+0xd8>
    80003614:	6946                	ld	s2,80(sp)
    80003616:	7c02                	ld	s8,32(sp)
    80003618:	6ce2                	ld	s9,24(sp)
    8000361a:	6d42                	ld	s10,16(sp)
    8000361c:	6da2                	ld	s11,8(sp)
    8000361e:	a801                	j	8000362e <readi+0xd8>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003620:	89d6                	mv	s3,s5
    80003622:	a031                	j	8000362e <readi+0xd8>
    80003624:	6946                	ld	s2,80(sp)
    80003626:	7c02                	ld	s8,32(sp)
    80003628:	6ce2                	ld	s9,24(sp)
    8000362a:	6d42                	ld	s10,16(sp)
    8000362c:	6da2                	ld	s11,8(sp)
  }
  return tot;
    8000362e:	854e                	mv	a0,s3
    80003630:	69a6                	ld	s3,72(sp)
}
    80003632:	70a6                	ld	ra,104(sp)
    80003634:	7406                	ld	s0,96(sp)
    80003636:	64e6                	ld	s1,88(sp)
    80003638:	6a06                	ld	s4,64(sp)
    8000363a:	7ae2                	ld	s5,56(sp)
    8000363c:	7b42                	ld	s6,48(sp)
    8000363e:	7ba2                	ld	s7,40(sp)
    80003640:	6165                	addi	sp,sp,112
    80003642:	8082                	ret
    return 0;
    80003644:	4501                	li	a0,0
}
    80003646:	8082                	ret

0000000080003648 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003648:	457c                	lw	a5,76(a0)
    8000364a:	0ed7ee63          	bltu	a5,a3,80003746 <writei+0xfe>
{
    8000364e:	7159                	addi	sp,sp,-112
    80003650:	f486                	sd	ra,104(sp)
    80003652:	f0a2                	sd	s0,96(sp)
    80003654:	e8ca                	sd	s2,80(sp)
    80003656:	e0d2                	sd	s4,64(sp)
    80003658:	fc56                	sd	s5,56(sp)
    8000365a:	f85a                	sd	s6,48(sp)
    8000365c:	f45e                	sd	s7,40(sp)
    8000365e:	1880                	addi	s0,sp,112
    80003660:	8aaa                	mv	s5,a0
    80003662:	8bae                	mv	s7,a1
    80003664:	8a32                	mv	s4,a2
    80003666:	8936                	mv	s2,a3
    80003668:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    8000366a:	9f35                	addw	a4,a4,a3
    return -1;
  if(off + n > MAXFILE*BSIZE)
    8000366c:	000437b7          	lui	a5,0x43
    80003670:	00e7b7b3          	sltu	a5,a5,a4
  if(off > ip->size || off + n < off)
    80003674:	00d73733          	sltu	a4,a4,a3
  if(off + n > MAXFILE*BSIZE)
    80003678:	8fd9                	or	a5,a5,a4
    8000367a:	ef91                	bnez	a5,80003696 <writei+0x4e>
    8000367c:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    8000367e:	0a0b0c63          	beqz	s6,80003736 <writei+0xee>
    80003682:	eca6                	sd	s1,88(sp)
    80003684:	f062                	sd	s8,32(sp)
    80003686:	ec66                	sd	s9,24(sp)
    80003688:	e86a                	sd	s10,16(sp)
    8000368a:	e46e                	sd	s11,8(sp)
    8000368c:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    8000368e:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003692:	5c7d                	li	s8,-1
    80003694:	a835                	j	800036d0 <writei+0x88>
    return -1;
    80003696:	557d                	li	a0,-1
    80003698:	a071                	j	80003724 <writei+0xdc>
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    8000369a:	020d1d93          	slli	s11,s10,0x20
    8000369e:	020ddd93          	srli	s11,s11,0x20
    800036a2:	05848513          	addi	a0,s1,88
    800036a6:	86ee                	mv	a3,s11
    800036a8:	8652                	mv	a2,s4
    800036aa:	85de                	mv	a1,s7
    800036ac:	953e                	add	a0,a0,a5
    800036ae:	be1fe0ef          	jal	8000228e <either_copyin>
    800036b2:	05850663          	beq	a0,s8,800036fe <writei+0xb6>
      brelse(bp);
      break;
    }
    log_write(bp);
    800036b6:	8526                	mv	a0,s1
    800036b8:	6a0000ef          	jal	80003d58 <log_write>
    brelse(bp);
    800036bc:	8526                	mv	a0,s1
    800036be:	e3cff0ef          	jal	80002cfa <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800036c2:	013d09bb          	addw	s3,s10,s3
    800036c6:	012d093b          	addw	s2,s10,s2
    800036ca:	9a6e                	add	s4,s4,s11
    800036cc:	0369fc63          	bgeu	s3,s6,80003704 <writei+0xbc>
    uint addr = bmap(ip, off/BSIZE);
    800036d0:	00a9559b          	srliw	a1,s2,0xa
    800036d4:	8556                	mv	a0,s5
    800036d6:	883ff0ef          	jal	80002f58 <bmap>
    800036da:	85aa                	mv	a1,a0
    if(addr == 0)
    800036dc:	c505                	beqz	a0,80003704 <writei+0xbc>
    bp = bread(ip->dev, addr);
    800036de:	000aa503          	lw	a0,0(s5)
    800036e2:	d10ff0ef          	jal	80002bf2 <bread>
    800036e6:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    800036e8:	3ff97793          	andi	a5,s2,1023
    800036ec:	40fc873b          	subw	a4,s9,a5
    800036f0:	413b06bb          	subw	a3,s6,s3
    800036f4:	8d3a                	mv	s10,a4
    800036f6:	fae6f2e3          	bgeu	a3,a4,8000369a <writei+0x52>
    800036fa:	8d36                	mv	s10,a3
    800036fc:	bf79                	j	8000369a <writei+0x52>
      brelse(bp);
    800036fe:	8526                	mv	a0,s1
    80003700:	dfaff0ef          	jal	80002cfa <brelse>
  }

  if(off > ip->size)
    80003704:	04caa783          	lw	a5,76(s5)
    80003708:	0327f963          	bgeu	a5,s2,8000373a <writei+0xf2>
    ip->size = off;
    8000370c:	052aa623          	sw	s2,76(s5)
    80003710:	64e6                	ld	s1,88(sp)
    80003712:	7c02                	ld	s8,32(sp)
    80003714:	6ce2                	ld	s9,24(sp)
    80003716:	6d42                	ld	s10,16(sp)
    80003718:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    8000371a:	8556                	mv	a0,s5
    8000371c:	b2dff0ef          	jal	80003248 <iupdate>

  return tot;
    80003720:	854e                	mv	a0,s3
    80003722:	69a6                	ld	s3,72(sp)
}
    80003724:	70a6                	ld	ra,104(sp)
    80003726:	7406                	ld	s0,96(sp)
    80003728:	6946                	ld	s2,80(sp)
    8000372a:	6a06                	ld	s4,64(sp)
    8000372c:	7ae2                	ld	s5,56(sp)
    8000372e:	7b42                	ld	s6,48(sp)
    80003730:	7ba2                	ld	s7,40(sp)
    80003732:	6165                	addi	sp,sp,112
    80003734:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003736:	89da                	mv	s3,s6
    80003738:	b7cd                	j	8000371a <writei+0xd2>
    8000373a:	64e6                	ld	s1,88(sp)
    8000373c:	7c02                	ld	s8,32(sp)
    8000373e:	6ce2                	ld	s9,24(sp)
    80003740:	6d42                	ld	s10,16(sp)
    80003742:	6da2                	ld	s11,8(sp)
    80003744:	bfd9                	j	8000371a <writei+0xd2>
    return -1;
    80003746:	557d                	li	a0,-1
}
    80003748:	8082                	ret

000000008000374a <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    8000374a:	1141                	addi	sp,sp,-16
    8000374c:	e406                	sd	ra,8(sp)
    8000374e:	e022                	sd	s0,0(sp)
    80003750:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003752:	4639                	li	a2,14
    80003754:	eacfd0ef          	jal	80000e00 <strncmp>
}
    80003758:	60a2                	ld	ra,8(sp)
    8000375a:	6402                	ld	s0,0(sp)
    8000375c:	0141                	addi	sp,sp,16
    8000375e:	8082                	ret

0000000080003760 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003760:	711d                	addi	sp,sp,-96
    80003762:	ec86                	sd	ra,88(sp)
    80003764:	e8a2                	sd	s0,80(sp)
    80003766:	e4a6                	sd	s1,72(sp)
    80003768:	e0ca                	sd	s2,64(sp)
    8000376a:	fc4e                	sd	s3,56(sp)
    8000376c:	f852                	sd	s4,48(sp)
    8000376e:	f456                	sd	s5,40(sp)
    80003770:	f05a                	sd	s6,32(sp)
    80003772:	ec5e                	sd	s7,24(sp)
    80003774:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003776:	04451703          	lh	a4,68(a0)
    8000377a:	4785                	li	a5,1
    8000377c:	02f71963          	bne	a4,a5,800037ae <dirlookup+0x4e>
    80003780:	892a                	mv	s2,a0
    80003782:	8aae                	mv	s5,a1
    80003784:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003786:	457c                	lw	a5,76(a0)
    80003788:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000378a:	fa040a13          	addi	s4,s0,-96
    8000378e:	49c1                	li	s3,16
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    if(namecmp(name, de.name) == 0){
    80003790:	fa240b13          	addi	s6,s0,-94
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003794:	ef95                	bnez	a5,800037d0 <dirlookup+0x70>
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003796:	4501                	li	a0,0
}
    80003798:	60e6                	ld	ra,88(sp)
    8000379a:	6446                	ld	s0,80(sp)
    8000379c:	64a6                	ld	s1,72(sp)
    8000379e:	6906                	ld	s2,64(sp)
    800037a0:	79e2                	ld	s3,56(sp)
    800037a2:	7a42                	ld	s4,48(sp)
    800037a4:	7aa2                	ld	s5,40(sp)
    800037a6:	7b02                	ld	s6,32(sp)
    800037a8:	6be2                	ld	s7,24(sp)
    800037aa:	6125                	addi	sp,sp,96
    800037ac:	8082                	ret
    panic("dirlookup not DIR");
    800037ae:	00004517          	auipc	a0,0x4
    800037b2:	d7250513          	addi	a0,a0,-654 # 80007520 <etext+0x520>
    800037b6:	83afd0ef          	jal	800007f0 <panic>
      panic("dirlookup read");
    800037ba:	00004517          	auipc	a0,0x4
    800037be:	d7e50513          	addi	a0,a0,-642 # 80007538 <etext+0x538>
    800037c2:	82efd0ef          	jal	800007f0 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    800037c6:	24c1                	addiw	s1,s1,16
    800037c8:	04c92783          	lw	a5,76(s2)
    800037cc:	fcf4f5e3          	bgeu	s1,a5,80003796 <dirlookup+0x36>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800037d0:	874e                	mv	a4,s3
    800037d2:	86a6                	mv	a3,s1
    800037d4:	8652                	mv	a2,s4
    800037d6:	4581                	li	a1,0
    800037d8:	854a                	mv	a0,s2
    800037da:	d7dff0ef          	jal	80003556 <readi>
    800037de:	fd351ee3          	bne	a0,s3,800037ba <dirlookup+0x5a>
    if(de.inum == 0)
    800037e2:	fa045783          	lhu	a5,-96(s0)
    800037e6:	d3e5                	beqz	a5,800037c6 <dirlookup+0x66>
    if(namecmp(name, de.name) == 0){
    800037e8:	85da                	mv	a1,s6
    800037ea:	8556                	mv	a0,s5
    800037ec:	f5fff0ef          	jal	8000374a <namecmp>
    800037f0:	f979                	bnez	a0,800037c6 <dirlookup+0x66>
      if(poff)
    800037f2:	000b8463          	beqz	s7,800037fa <dirlookup+0x9a>
        *poff = off;
    800037f6:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    800037fa:	fa045583          	lhu	a1,-96(s0)
    800037fe:	00092503          	lw	a0,0(s2)
    80003802:	817ff0ef          	jal	80003018 <iget>
    80003806:	bf49                	j	80003798 <dirlookup+0x38>

0000000080003808 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003808:	711d                	addi	sp,sp,-96
    8000380a:	ec86                	sd	ra,88(sp)
    8000380c:	e8a2                	sd	s0,80(sp)
    8000380e:	e4a6                	sd	s1,72(sp)
    80003810:	e0ca                	sd	s2,64(sp)
    80003812:	fc4e                	sd	s3,56(sp)
    80003814:	f852                	sd	s4,48(sp)
    80003816:	f456                	sd	s5,40(sp)
    80003818:	f05a                	sd	s6,32(sp)
    8000381a:	ec5e                	sd	s7,24(sp)
    8000381c:	e862                	sd	s8,16(sp)
    8000381e:	e466                	sd	s9,8(sp)
    80003820:	e06a                	sd	s10,0(sp)
    80003822:	1080                	addi	s0,sp,96
    80003824:	84aa                	mv	s1,a0
    80003826:	8b2e                	mv	s6,a1
    80003828:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    8000382a:	00054703          	lbu	a4,0(a0)
    8000382e:	02f00793          	li	a5,47
    80003832:	00f70f63          	beq	a4,a5,80003850 <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003836:	8fafe0ef          	jal	80001930 <myproc>
    8000383a:	15053503          	ld	a0,336(a0)
    8000383e:	a89ff0ef          	jal	800032c6 <idup>
    80003842:	8a2a                	mv	s4,a0
  while(*path == '/')
    80003844:	02f00993          	li	s3,47
  if(len >= DIRSIZ)
    80003848:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    8000384a:	4cb9                	li	s9,14

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    8000384c:	4b85                	li	s7,1
    8000384e:	a879                	j	800038ec <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    80003850:	4585                	li	a1,1
    80003852:	852e                	mv	a0,a1
    80003854:	fc4ff0ef          	jal	80003018 <iget>
    80003858:	8a2a                	mv	s4,a0
    8000385a:	b7ed                	j	80003844 <namex+0x3c>
      iunlockput(ip);
    8000385c:	8552                	mv	a0,s4
    8000385e:	cabff0ef          	jal	80003508 <iunlockput>
      return 0;
    80003862:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003864:	8552                	mv	a0,s4
    80003866:	60e6                	ld	ra,88(sp)
    80003868:	6446                	ld	s0,80(sp)
    8000386a:	64a6                	ld	s1,72(sp)
    8000386c:	6906                	ld	s2,64(sp)
    8000386e:	79e2                	ld	s3,56(sp)
    80003870:	7a42                	ld	s4,48(sp)
    80003872:	7aa2                	ld	s5,40(sp)
    80003874:	7b02                	ld	s6,32(sp)
    80003876:	6be2                	ld	s7,24(sp)
    80003878:	6c42                	ld	s8,16(sp)
    8000387a:	6ca2                	ld	s9,8(sp)
    8000387c:	6d02                	ld	s10,0(sp)
    8000387e:	6125                	addi	sp,sp,96
    80003880:	8082                	ret
      iunlock(ip);
    80003882:	8552                	mv	a0,s4
    80003884:	b27ff0ef          	jal	800033aa <iunlock>
      return ip;
    80003888:	bff1                	j	80003864 <namex+0x5c>
      iunlockput(ip);
    8000388a:	8552                	mv	a0,s4
    8000388c:	c7dff0ef          	jal	80003508 <iunlockput>
      return 0;
    80003890:	8a4a                	mv	s4,s2
    80003892:	bfc9                	j	80003864 <namex+0x5c>
  while(*path != '/' && *path != 0)
    80003894:	8926                	mv	s2,s1
  len = path - s;
    80003896:	4d01                	li	s10,0
    80003898:	4601                	li	a2,0
    memmove(name, s, len);
    8000389a:	2601                	sext.w	a2,a2
    8000389c:	85a6                	mv	a1,s1
    8000389e:	8556                	mv	a0,s5
    800038a0:	cecfd0ef          	jal	80000d8c <memmove>
    name[len] = 0;
    800038a4:	9d56                	add	s10,s10,s5
    800038a6:	000d0023          	sb	zero,0(s10)
    800038aa:	84ca                	mv	s1,s2
  while(*path == '/')
    800038ac:	0004c783          	lbu	a5,0(s1)
    800038b0:	01379763          	bne	a5,s3,800038be <namex+0xb6>
    path++;
    800038b4:	0485                	addi	s1,s1,1
  while(*path == '/')
    800038b6:	0004c783          	lbu	a5,0(s1)
    800038ba:	ff378de3          	beq	a5,s3,800038b4 <namex+0xac>
    ilock(ip);
    800038be:	8552                	mv	a0,s4
    800038c0:	a3dff0ef          	jal	800032fc <ilock>
    if(ip->type != T_DIR){
    800038c4:	044a1783          	lh	a5,68(s4)
    800038c8:	f9779ae3          	bne	a5,s7,8000385c <namex+0x54>
    if(nameiparent && *path == '\0'){
    800038cc:	000b0563          	beqz	s6,800038d6 <namex+0xce>
    800038d0:	0004c783          	lbu	a5,0(s1)
    800038d4:	d7dd                	beqz	a5,80003882 <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    800038d6:	4601                	li	a2,0
    800038d8:	85d6                	mv	a1,s5
    800038da:	8552                	mv	a0,s4
    800038dc:	e85ff0ef          	jal	80003760 <dirlookup>
    800038e0:	892a                	mv	s2,a0
    800038e2:	d545                	beqz	a0,8000388a <namex+0x82>
    iunlockput(ip);
    800038e4:	8552                	mv	a0,s4
    800038e6:	c23ff0ef          	jal	80003508 <iunlockput>
    ip = next;
    800038ea:	8a4a                	mv	s4,s2
  while(*path == '/')
    800038ec:	0004c783          	lbu	a5,0(s1)
    800038f0:	01379763          	bne	a5,s3,800038fe <namex+0xf6>
    path++;
    800038f4:	0485                	addi	s1,s1,1
  while(*path == '/')
    800038f6:	0004c783          	lbu	a5,0(s1)
    800038fa:	ff378de3          	beq	a5,s3,800038f4 <namex+0xec>
  if(*path == 0)
    800038fe:	c7a1                	beqz	a5,80003946 <namex+0x13e>
  while(*path != '/' && *path != 0)
    80003900:	0004c703          	lbu	a4,0(s1)
    80003904:	fd170793          	addi	a5,a4,-47
    80003908:	00f037b3          	snez	a5,a5
    8000390c:	00e03733          	snez	a4,a4
    80003910:	8ff9                	and	a5,a5,a4
    80003912:	d3c9                	beqz	a5,80003894 <namex+0x8c>
    80003914:	8926                	mv	s2,s1
    path++;
    80003916:	0905                	addi	s2,s2,1
  while(*path != '/' && *path != 0)
    80003918:	00094703          	lbu	a4,0(s2)
    8000391c:	fd170793          	addi	a5,a4,-47
    80003920:	00f037b3          	snez	a5,a5
    80003924:	00e03733          	snez	a4,a4
    80003928:	8ff9                	and	a5,a5,a4
    8000392a:	f7f5                	bnez	a5,80003916 <namex+0x10e>
  len = path - s;
    8000392c:	40990633          	sub	a2,s2,s1
    80003930:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    80003934:	f7ac53e3          	bge	s8,s10,8000389a <namex+0x92>
    memmove(name, s, DIRSIZ);
    80003938:	8666                	mv	a2,s9
    8000393a:	85a6                	mv	a1,s1
    8000393c:	8556                	mv	a0,s5
    8000393e:	c4efd0ef          	jal	80000d8c <memmove>
    80003942:	84ca                	mv	s1,s2
    80003944:	b7a5                	j	800038ac <namex+0xa4>
  if(nameiparent){
    80003946:	f00b0fe3          	beqz	s6,80003864 <namex+0x5c>
    iput(ip);
    8000394a:	8552                	mv	a0,s4
    8000394c:	b33ff0ef          	jal	8000347e <iput>
    return 0;
    80003950:	bf09                	j	80003862 <namex+0x5a>

0000000080003952 <dirlink>:
{
    80003952:	715d                	addi	sp,sp,-80
    80003954:	e486                	sd	ra,72(sp)
    80003956:	e0a2                	sd	s0,64(sp)
    80003958:	f84a                	sd	s2,48(sp)
    8000395a:	ec56                	sd	s5,24(sp)
    8000395c:	e85a                	sd	s6,16(sp)
    8000395e:	0880                	addi	s0,sp,80
    80003960:	892a                	mv	s2,a0
    80003962:	8aae                	mv	s5,a1
    80003964:	8b32                	mv	s6,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003966:	4601                	li	a2,0
    80003968:	df9ff0ef          	jal	80003760 <dirlookup>
    8000396c:	ed1d                	bnez	a0,800039aa <dirlink+0x58>
    8000396e:	fc26                	sd	s1,56(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003970:	04c92483          	lw	s1,76(s2)
    80003974:	c4b9                	beqz	s1,800039c2 <dirlink+0x70>
    80003976:	f44e                	sd	s3,40(sp)
    80003978:	f052                	sd	s4,32(sp)
    8000397a:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    8000397c:	fb040a13          	addi	s4,s0,-80
    80003980:	49c1                	li	s3,16
    80003982:	874e                	mv	a4,s3
    80003984:	86a6                	mv	a3,s1
    80003986:	8652                	mv	a2,s4
    80003988:	4581                	li	a1,0
    8000398a:	854a                	mv	a0,s2
    8000398c:	bcbff0ef          	jal	80003556 <readi>
    80003990:	03351163          	bne	a0,s3,800039b2 <dirlink+0x60>
    if(de.inum == 0)
    80003994:	fb045783          	lhu	a5,-80(s0)
    80003998:	c39d                	beqz	a5,800039be <dirlink+0x6c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    8000399a:	24c1                	addiw	s1,s1,16
    8000399c:	04c92783          	lw	a5,76(s2)
    800039a0:	fef4e1e3          	bltu	s1,a5,80003982 <dirlink+0x30>
    800039a4:	79a2                	ld	s3,40(sp)
    800039a6:	7a02                	ld	s4,32(sp)
    800039a8:	a829                	j	800039c2 <dirlink+0x70>
    iput(ip);
    800039aa:	ad5ff0ef          	jal	8000347e <iput>
    return -1;
    800039ae:	557d                	li	a0,-1
    800039b0:	a83d                	j	800039ee <dirlink+0x9c>
      panic("dirlink read");
    800039b2:	00004517          	auipc	a0,0x4
    800039b6:	b9650513          	addi	a0,a0,-1130 # 80007548 <etext+0x548>
    800039ba:	e37fc0ef          	jal	800007f0 <panic>
    800039be:	79a2                	ld	s3,40(sp)
    800039c0:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    800039c2:	4639                	li	a2,14
    800039c4:	85d6                	mv	a1,s5
    800039c6:	fb240513          	addi	a0,s0,-78
    800039ca:	c6cfd0ef          	jal	80000e36 <strncpy>
  de.inum = inum;
    800039ce:	fb641823          	sh	s6,-80(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800039d2:	4741                	li	a4,16
    800039d4:	86a6                	mv	a3,s1
    800039d6:	fb040613          	addi	a2,s0,-80
    800039da:	4581                	li	a1,0
    800039dc:	854a                	mv	a0,s2
    800039de:	c6bff0ef          	jal	80003648 <writei>
    800039e2:	1541                	addi	a0,a0,-16
    800039e4:	00a03533          	snez	a0,a0
    800039e8:	40a0053b          	negw	a0,a0
    800039ec:	74e2                	ld	s1,56(sp)
}
    800039ee:	60a6                	ld	ra,72(sp)
    800039f0:	6406                	ld	s0,64(sp)
    800039f2:	7942                	ld	s2,48(sp)
    800039f4:	6ae2                	ld	s5,24(sp)
    800039f6:	6b42                	ld	s6,16(sp)
    800039f8:	6161                	addi	sp,sp,80
    800039fa:	8082                	ret

00000000800039fc <namei>:

struct inode*
namei(char *path)
{
    800039fc:	1101                	addi	sp,sp,-32
    800039fe:	ec06                	sd	ra,24(sp)
    80003a00:	e822                	sd	s0,16(sp)
    80003a02:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003a04:	fe040613          	addi	a2,s0,-32
    80003a08:	4581                	li	a1,0
    80003a0a:	dffff0ef          	jal	80003808 <namex>
}
    80003a0e:	60e2                	ld	ra,24(sp)
    80003a10:	6442                	ld	s0,16(sp)
    80003a12:	6105                	addi	sp,sp,32
    80003a14:	8082                	ret

0000000080003a16 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003a16:	1141                	addi	sp,sp,-16
    80003a18:	e406                	sd	ra,8(sp)
    80003a1a:	e022                	sd	s0,0(sp)
    80003a1c:	0800                	addi	s0,sp,16
    80003a1e:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003a20:	4585                	li	a1,1
    80003a22:	de7ff0ef          	jal	80003808 <namex>
}
    80003a26:	60a2                	ld	ra,8(sp)
    80003a28:	6402                	ld	s0,0(sp)
    80003a2a:	0141                	addi	sp,sp,16
    80003a2c:	8082                	ret

0000000080003a2e <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003a2e:	1101                	addi	sp,sp,-32
    80003a30:	ec06                	sd	ra,24(sp)
    80003a32:	e822                	sd	s0,16(sp)
    80003a34:	e426                	sd	s1,8(sp)
    80003a36:	e04a                	sd	s2,0(sp)
    80003a38:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003a3a:	0001c917          	auipc	s2,0x1c
    80003a3e:	03690913          	addi	s2,s2,54 # 8001fa70 <log>
    80003a42:	01892583          	lw	a1,24(s2)
    80003a46:	02892503          	lw	a0,40(s2)
    80003a4a:	9a8ff0ef          	jal	80002bf2 <bread>
    80003a4e:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003a50:	02c92603          	lw	a2,44(s2)
    80003a54:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003a56:	00c05f63          	blez	a2,80003a74 <write_head+0x46>
    80003a5a:	0001c717          	auipc	a4,0x1c
    80003a5e:	04670713          	addi	a4,a4,70 # 8001faa0 <log+0x30>
    80003a62:	87aa                	mv	a5,a0
    80003a64:	060a                	slli	a2,a2,0x2
    80003a66:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003a68:	4314                	lw	a3,0(a4)
    80003a6a:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003a6c:	0711                	addi	a4,a4,4
    80003a6e:	0791                	addi	a5,a5,4 # 43004 <_entry-0x7ffbcffc>
    80003a70:	fec79ce3          	bne	a5,a2,80003a68 <write_head+0x3a>
  }
  bwrite(buf);
    80003a74:	8526                	mv	a0,s1
    80003a76:	a52ff0ef          	jal	80002cc8 <bwrite>
  brelse(buf);
    80003a7a:	8526                	mv	a0,s1
    80003a7c:	a7eff0ef          	jal	80002cfa <brelse>
}
    80003a80:	60e2                	ld	ra,24(sp)
    80003a82:	6442                	ld	s0,16(sp)
    80003a84:	64a2                	ld	s1,8(sp)
    80003a86:	6902                	ld	s2,0(sp)
    80003a88:	6105                	addi	sp,sp,32
    80003a8a:	8082                	ret

0000000080003a8c <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003a8c:	0001c797          	auipc	a5,0x1c
    80003a90:	0107a783          	lw	a5,16(a5) # 8001fa9c <log+0x2c>
    80003a94:	0af05263          	blez	a5,80003b38 <install_trans+0xac>
{
    80003a98:	715d                	addi	sp,sp,-80
    80003a9a:	e486                	sd	ra,72(sp)
    80003a9c:	e0a2                	sd	s0,64(sp)
    80003a9e:	fc26                	sd	s1,56(sp)
    80003aa0:	f84a                	sd	s2,48(sp)
    80003aa2:	f44e                	sd	s3,40(sp)
    80003aa4:	f052                	sd	s4,32(sp)
    80003aa6:	ec56                	sd	s5,24(sp)
    80003aa8:	e85a                	sd	s6,16(sp)
    80003aaa:	e45e                	sd	s7,8(sp)
    80003aac:	0880                	addi	s0,sp,80
    80003aae:	8b2a                	mv	s6,a0
    80003ab0:	0001ca97          	auipc	s5,0x1c
    80003ab4:	ff0a8a93          	addi	s5,s5,-16 # 8001faa0 <log+0x30>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003ab8:	4a01                	li	s4,0
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003aba:	0001c997          	auipc	s3,0x1c
    80003abe:	fb698993          	addi	s3,s3,-74 # 8001fa70 <log>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003ac2:	40000b93          	li	s7,1024
    80003ac6:	a829                	j	80003ae0 <install_trans+0x54>
    brelse(lbuf);
    80003ac8:	854a                	mv	a0,s2
    80003aca:	a30ff0ef          	jal	80002cfa <brelse>
    brelse(dbuf);
    80003ace:	8526                	mv	a0,s1
    80003ad0:	a2aff0ef          	jal	80002cfa <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003ad4:	2a05                	addiw	s4,s4,1
    80003ad6:	0a91                	addi	s5,s5,4
    80003ad8:	02c9a783          	lw	a5,44(s3)
    80003adc:	04fa5363          	bge	s4,a5,80003b22 <install_trans+0x96>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003ae0:	0189a583          	lw	a1,24(s3)
    80003ae4:	014585bb          	addw	a1,a1,s4
    80003ae8:	2585                	addiw	a1,a1,1
    80003aea:	0289a503          	lw	a0,40(s3)
    80003aee:	904ff0ef          	jal	80002bf2 <bread>
    80003af2:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80003af4:	000aa583          	lw	a1,0(s5)
    80003af8:	0289a503          	lw	a0,40(s3)
    80003afc:	8f6ff0ef          	jal	80002bf2 <bread>
    80003b00:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003b02:	865e                	mv	a2,s7
    80003b04:	05890593          	addi	a1,s2,88
    80003b08:	05850513          	addi	a0,a0,88
    80003b0c:	a80fd0ef          	jal	80000d8c <memmove>
    bwrite(dbuf);  // write dst to disk
    80003b10:	8526                	mv	a0,s1
    80003b12:	9b6ff0ef          	jal	80002cc8 <bwrite>
    if(recovering == 0)
    80003b16:	fa0b19e3          	bnez	s6,80003ac8 <install_trans+0x3c>
      bunpin(dbuf);
    80003b1a:	8526                	mv	a0,s1
    80003b1c:	a96ff0ef          	jal	80002db2 <bunpin>
    80003b20:	b765                	j	80003ac8 <install_trans+0x3c>
}
    80003b22:	60a6                	ld	ra,72(sp)
    80003b24:	6406                	ld	s0,64(sp)
    80003b26:	74e2                	ld	s1,56(sp)
    80003b28:	7942                	ld	s2,48(sp)
    80003b2a:	79a2                	ld	s3,40(sp)
    80003b2c:	7a02                	ld	s4,32(sp)
    80003b2e:	6ae2                	ld	s5,24(sp)
    80003b30:	6b42                	ld	s6,16(sp)
    80003b32:	6ba2                	ld	s7,8(sp)
    80003b34:	6161                	addi	sp,sp,80
    80003b36:	8082                	ret
    80003b38:	8082                	ret

0000000080003b3a <initlog>:
{
    80003b3a:	7179                	addi	sp,sp,-48
    80003b3c:	f406                	sd	ra,40(sp)
    80003b3e:	f022                	sd	s0,32(sp)
    80003b40:	ec26                	sd	s1,24(sp)
    80003b42:	e84a                	sd	s2,16(sp)
    80003b44:	e44e                	sd	s3,8(sp)
    80003b46:	1800                	addi	s0,sp,48
    80003b48:	892a                	mv	s2,a0
    80003b4a:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003b4c:	0001c497          	auipc	s1,0x1c
    80003b50:	f2448493          	addi	s1,s1,-220 # 8001fa70 <log>
    80003b54:	00004597          	auipc	a1,0x4
    80003b58:	a0458593          	addi	a1,a1,-1532 # 80007558 <etext+0x558>
    80003b5c:	8526                	mv	a0,s1
    80003b5e:	87cfd0ef          	jal	80000bda <initlock>
  log.start = sb->logstart;
    80003b62:	0149a583          	lw	a1,20(s3)
    80003b66:	cc8c                	sw	a1,24(s1)
  log.size = sb->nlog;
    80003b68:	0109a783          	lw	a5,16(s3)
    80003b6c:	ccdc                	sw	a5,28(s1)
  log.dev = dev;
    80003b6e:	0324a423          	sw	s2,40(s1)
  struct buf *buf = bread(log.dev, log.start);
    80003b72:	854a                	mv	a0,s2
    80003b74:	87eff0ef          	jal	80002bf2 <bread>
  log.lh.n = lh->n;
    80003b78:	4d30                	lw	a2,88(a0)
    80003b7a:	d4d0                	sw	a2,44(s1)
  for (i = 0; i < log.lh.n; i++) {
    80003b7c:	00c05f63          	blez	a2,80003b9a <initlog+0x60>
    80003b80:	87aa                	mv	a5,a0
    80003b82:	0001c717          	auipc	a4,0x1c
    80003b86:	f1e70713          	addi	a4,a4,-226 # 8001faa0 <log+0x30>
    80003b8a:	060a                	slli	a2,a2,0x2
    80003b8c:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003b8e:	4ff4                	lw	a3,92(a5)
    80003b90:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003b92:	0791                	addi	a5,a5,4
    80003b94:	0711                	addi	a4,a4,4
    80003b96:	fec79ce3          	bne	a5,a2,80003b8e <initlog+0x54>
  brelse(buf);
    80003b9a:	960ff0ef          	jal	80002cfa <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003b9e:	4505                	li	a0,1
    80003ba0:	eedff0ef          	jal	80003a8c <install_trans>
  log.lh.n = 0;
    80003ba4:	0001c797          	auipc	a5,0x1c
    80003ba8:	ee07ac23          	sw	zero,-264(a5) # 8001fa9c <log+0x2c>
  write_head(); // clear the log
    80003bac:	e83ff0ef          	jal	80003a2e <write_head>
}
    80003bb0:	70a2                	ld	ra,40(sp)
    80003bb2:	7402                	ld	s0,32(sp)
    80003bb4:	64e2                	ld	s1,24(sp)
    80003bb6:	6942                	ld	s2,16(sp)
    80003bb8:	69a2                	ld	s3,8(sp)
    80003bba:	6145                	addi	sp,sp,48
    80003bbc:	8082                	ret

0000000080003bbe <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003bbe:	1101                	addi	sp,sp,-32
    80003bc0:	ec06                	sd	ra,24(sp)
    80003bc2:	e822                	sd	s0,16(sp)
    80003bc4:	e426                	sd	s1,8(sp)
    80003bc6:	e04a                	sd	s2,0(sp)
    80003bc8:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003bca:	0001c517          	auipc	a0,0x1c
    80003bce:	ea650513          	addi	a0,a0,-346 # 8001fa70 <log>
    80003bd2:	892fd0ef          	jal	80000c64 <acquire>
  while(1){
    if(log.committing){
    80003bd6:	0001c497          	auipc	s1,0x1c
    80003bda:	e9a48493          	addi	s1,s1,-358 # 8001fa70 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003bde:	4979                	li	s2,30
    80003be0:	a029                	j	80003bea <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003be2:	85a6                	mv	a1,s1
    80003be4:	8526                	mv	a0,s1
    80003be6:	b06fe0ef          	jal	80001eec <sleep>
    if(log.committing){
    80003bea:	50dc                	lw	a5,36(s1)
    80003bec:	fbfd                	bnez	a5,80003be2 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGSIZE){
    80003bee:	5098                	lw	a4,32(s1)
    80003bf0:	2705                	addiw	a4,a4,1
    80003bf2:	0027179b          	slliw	a5,a4,0x2
    80003bf6:	9fb9                	addw	a5,a5,a4
    80003bf8:	0017979b          	slliw	a5,a5,0x1
    80003bfc:	54d4                	lw	a3,44(s1)
    80003bfe:	9fb5                	addw	a5,a5,a3
    80003c00:	00f95763          	bge	s2,a5,80003c0e <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80003c04:	85a6                	mv	a1,s1
    80003c06:	8526                	mv	a0,s1
    80003c08:	ae4fe0ef          	jal	80001eec <sleep>
    80003c0c:	bff9                	j	80003bea <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003c0e:	0001c797          	auipc	a5,0x1c
    80003c12:	e8e7a123          	sw	a4,-382(a5) # 8001fa90 <log+0x20>
      release(&log.lock);
    80003c16:	0001c517          	auipc	a0,0x1c
    80003c1a:	e5a50513          	addi	a0,a0,-422 # 8001fa70 <log>
    80003c1e:	8d6fd0ef          	jal	80000cf4 <release>
      break;
    }
  }
}
    80003c22:	60e2                	ld	ra,24(sp)
    80003c24:	6442                	ld	s0,16(sp)
    80003c26:	64a2                	ld	s1,8(sp)
    80003c28:	6902                	ld	s2,0(sp)
    80003c2a:	6105                	addi	sp,sp,32
    80003c2c:	8082                	ret

0000000080003c2e <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003c2e:	7139                	addi	sp,sp,-64
    80003c30:	fc06                	sd	ra,56(sp)
    80003c32:	f822                	sd	s0,48(sp)
    80003c34:	f426                	sd	s1,40(sp)
    80003c36:	f04a                	sd	s2,32(sp)
    80003c38:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003c3a:	0001c497          	auipc	s1,0x1c
    80003c3e:	e3648493          	addi	s1,s1,-458 # 8001fa70 <log>
    80003c42:	8526                	mv	a0,s1
    80003c44:	820fd0ef          	jal	80000c64 <acquire>
  log.outstanding -= 1;
    80003c48:	509c                	lw	a5,32(s1)
    80003c4a:	37fd                	addiw	a5,a5,-1
    80003c4c:	893e                	mv	s2,a5
    80003c4e:	d09c                	sw	a5,32(s1)
  if(log.committing)
    80003c50:	50dc                	lw	a5,36(s1)
    80003c52:	ebb9                	bnez	a5,80003ca8 <end_op+0x7a>
    panic("log.committing");
  if(log.outstanding == 0){
    80003c54:	06091363          	bnez	s2,80003cba <end_op+0x8c>
    do_commit = 1;
    log.committing = 1;
    80003c58:	0001c497          	auipc	s1,0x1c
    80003c5c:	e1848493          	addi	s1,s1,-488 # 8001fa70 <log>
    80003c60:	4785                	li	a5,1
    80003c62:	d0dc                	sw	a5,36(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003c64:	8526                	mv	a0,s1
    80003c66:	88efd0ef          	jal	80000cf4 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003c6a:	54dc                	lw	a5,44(s1)
    80003c6c:	06f04463          	bgtz	a5,80003cd4 <end_op+0xa6>
    acquire(&log.lock);
    80003c70:	0001c517          	auipc	a0,0x1c
    80003c74:	e0050513          	addi	a0,a0,-512 # 8001fa70 <log>
    80003c78:	fedfc0ef          	jal	80000c64 <acquire>
    log.committing = 0;
    80003c7c:	0001c797          	auipc	a5,0x1c
    80003c80:	e007ac23          	sw	zero,-488(a5) # 8001fa94 <log+0x24>
    wakeup(&log);
    80003c84:	0001c517          	auipc	a0,0x1c
    80003c88:	dec50513          	addi	a0,a0,-532 # 8001fa70 <log>
    80003c8c:	aacfe0ef          	jal	80001f38 <wakeup>
    release(&log.lock);
    80003c90:	0001c517          	auipc	a0,0x1c
    80003c94:	de050513          	addi	a0,a0,-544 # 8001fa70 <log>
    80003c98:	85cfd0ef          	jal	80000cf4 <release>
}
    80003c9c:	70e2                	ld	ra,56(sp)
    80003c9e:	7442                	ld	s0,48(sp)
    80003ca0:	74a2                	ld	s1,40(sp)
    80003ca2:	7902                	ld	s2,32(sp)
    80003ca4:	6121                	addi	sp,sp,64
    80003ca6:	8082                	ret
    80003ca8:	ec4e                	sd	s3,24(sp)
    80003caa:	e852                	sd	s4,16(sp)
    80003cac:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003cae:	00004517          	auipc	a0,0x4
    80003cb2:	8b250513          	addi	a0,a0,-1870 # 80007560 <etext+0x560>
    80003cb6:	b3bfc0ef          	jal	800007f0 <panic>
    wakeup(&log);
    80003cba:	0001c517          	auipc	a0,0x1c
    80003cbe:	db650513          	addi	a0,a0,-586 # 8001fa70 <log>
    80003cc2:	a76fe0ef          	jal	80001f38 <wakeup>
  release(&log.lock);
    80003cc6:	0001c517          	auipc	a0,0x1c
    80003cca:	daa50513          	addi	a0,a0,-598 # 8001fa70 <log>
    80003cce:	826fd0ef          	jal	80000cf4 <release>
  if(do_commit){
    80003cd2:	b7e9                	j	80003c9c <end_op+0x6e>
    80003cd4:	ec4e                	sd	s3,24(sp)
    80003cd6:	e852                	sd	s4,16(sp)
    80003cd8:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003cda:	0001ca97          	auipc	s5,0x1c
    80003cde:	dc6a8a93          	addi	s5,s5,-570 # 8001faa0 <log+0x30>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003ce2:	0001ca17          	auipc	s4,0x1c
    80003ce6:	d8ea0a13          	addi	s4,s4,-626 # 8001fa70 <log>
    80003cea:	018a2583          	lw	a1,24(s4)
    80003cee:	012585bb          	addw	a1,a1,s2
    80003cf2:	2585                	addiw	a1,a1,1
    80003cf4:	028a2503          	lw	a0,40(s4)
    80003cf8:	efbfe0ef          	jal	80002bf2 <bread>
    80003cfc:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003cfe:	000aa583          	lw	a1,0(s5)
    80003d02:	028a2503          	lw	a0,40(s4)
    80003d06:	eedfe0ef          	jal	80002bf2 <bread>
    80003d0a:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003d0c:	40000613          	li	a2,1024
    80003d10:	05850593          	addi	a1,a0,88
    80003d14:	05848513          	addi	a0,s1,88
    80003d18:	874fd0ef          	jal	80000d8c <memmove>
    bwrite(to);  // write the log
    80003d1c:	8526                	mv	a0,s1
    80003d1e:	fabfe0ef          	jal	80002cc8 <bwrite>
    brelse(from);
    80003d22:	854e                	mv	a0,s3
    80003d24:	fd7fe0ef          	jal	80002cfa <brelse>
    brelse(to);
    80003d28:	8526                	mv	a0,s1
    80003d2a:	fd1fe0ef          	jal	80002cfa <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003d2e:	2905                	addiw	s2,s2,1
    80003d30:	0a91                	addi	s5,s5,4
    80003d32:	02ca2783          	lw	a5,44(s4)
    80003d36:	faf94ae3          	blt	s2,a5,80003cea <end_op+0xbc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80003d3a:	cf5ff0ef          	jal	80003a2e <write_head>
    install_trans(0); // Now install writes to home locations
    80003d3e:	4501                	li	a0,0
    80003d40:	d4dff0ef          	jal	80003a8c <install_trans>
    log.lh.n = 0;
    80003d44:	0001c797          	auipc	a5,0x1c
    80003d48:	d407ac23          	sw	zero,-680(a5) # 8001fa9c <log+0x2c>
    write_head();    // Erase the transaction from the log
    80003d4c:	ce3ff0ef          	jal	80003a2e <write_head>
    80003d50:	69e2                	ld	s3,24(sp)
    80003d52:	6a42                	ld	s4,16(sp)
    80003d54:	6aa2                	ld	s5,8(sp)
    80003d56:	bf29                	j	80003c70 <end_op+0x42>

0000000080003d58 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003d58:	1101                	addi	sp,sp,-32
    80003d5a:	ec06                	sd	ra,24(sp)
    80003d5c:	e822                	sd	s0,16(sp)
    80003d5e:	e426                	sd	s1,8(sp)
    80003d60:	1000                	addi	s0,sp,32
    80003d62:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003d64:	0001c517          	auipc	a0,0x1c
    80003d68:	d0c50513          	addi	a0,a0,-756 # 8001fa70 <log>
    80003d6c:	ef9fc0ef          	jal	80000c64 <acquire>
  if (log.lh.n >= LOGSIZE || log.lh.n >= log.size - 1)
    80003d70:	0001c617          	auipc	a2,0x1c
    80003d74:	d2c62603          	lw	a2,-724(a2) # 8001fa9c <log+0x2c>
    80003d78:	47f5                	li	a5,29
    80003d7a:	06c7c363          	blt	a5,a2,80003de0 <log_write+0x88>
    80003d7e:	0001c797          	auipc	a5,0x1c
    80003d82:	d0e7a783          	lw	a5,-754(a5) # 8001fa8c <log+0x1c>
    80003d86:	37fd                	addiw	a5,a5,-1
    80003d88:	04f65c63          	bge	a2,a5,80003de0 <log_write+0x88>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003d8c:	0001c797          	auipc	a5,0x1c
    80003d90:	d047a783          	lw	a5,-764(a5) # 8001fa90 <log+0x20>
    80003d94:	04f05c63          	blez	a5,80003dec <log_write+0x94>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003d98:	4781                	li	a5,0
    80003d9a:	04c05f63          	blez	a2,80003df8 <log_write+0xa0>
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003d9e:	44cc                	lw	a1,12(s1)
    80003da0:	0001c717          	auipc	a4,0x1c
    80003da4:	d0070713          	addi	a4,a4,-768 # 8001faa0 <log+0x30>
  for (i = 0; i < log.lh.n; i++) {
    80003da8:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003daa:	4314                	lw	a3,0(a4)
    80003dac:	04b68663          	beq	a3,a1,80003df8 <log_write+0xa0>
  for (i = 0; i < log.lh.n; i++) {
    80003db0:	2785                	addiw	a5,a5,1
    80003db2:	0711                	addi	a4,a4,4
    80003db4:	fef61be3          	bne	a2,a5,80003daa <log_write+0x52>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003db8:	0621                	addi	a2,a2,8
    80003dba:	060a                	slli	a2,a2,0x2
    80003dbc:	0001c797          	auipc	a5,0x1c
    80003dc0:	cb478793          	addi	a5,a5,-844 # 8001fa70 <log>
    80003dc4:	97b2                	add	a5,a5,a2
    80003dc6:	44d8                	lw	a4,12(s1)
    80003dc8:	cb98                	sw	a4,16(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80003dca:	8526                	mv	a0,s1
    80003dcc:	fb3fe0ef          	jal	80002d7e <bpin>
    log.lh.n++;
    80003dd0:	0001c717          	auipc	a4,0x1c
    80003dd4:	ca070713          	addi	a4,a4,-864 # 8001fa70 <log>
    80003dd8:	575c                	lw	a5,44(a4)
    80003dda:	2785                	addiw	a5,a5,1
    80003ddc:	d75c                	sw	a5,44(a4)
    80003dde:	a80d                	j	80003e10 <log_write+0xb8>
    panic("too big a transaction");
    80003de0:	00003517          	auipc	a0,0x3
    80003de4:	79050513          	addi	a0,a0,1936 # 80007570 <etext+0x570>
    80003de8:	a09fc0ef          	jal	800007f0 <panic>
    panic("log_write outside of trans");
    80003dec:	00003517          	auipc	a0,0x3
    80003df0:	79c50513          	addi	a0,a0,1948 # 80007588 <etext+0x588>
    80003df4:	9fdfc0ef          	jal	800007f0 <panic>
  log.lh.block[i] = b->blockno;
    80003df8:	00878693          	addi	a3,a5,8
    80003dfc:	068a                	slli	a3,a3,0x2
    80003dfe:	0001c717          	auipc	a4,0x1c
    80003e02:	c7270713          	addi	a4,a4,-910 # 8001fa70 <log>
    80003e06:	9736                	add	a4,a4,a3
    80003e08:	44d4                	lw	a3,12(s1)
    80003e0a:	cb14                	sw	a3,16(a4)
  if (i == log.lh.n) {  // Add new block to log?
    80003e0c:	faf60fe3          	beq	a2,a5,80003dca <log_write+0x72>
  }
  release(&log.lock);
    80003e10:	0001c517          	auipc	a0,0x1c
    80003e14:	c6050513          	addi	a0,a0,-928 # 8001fa70 <log>
    80003e18:	eddfc0ef          	jal	80000cf4 <release>
}
    80003e1c:	60e2                	ld	ra,24(sp)
    80003e1e:	6442                	ld	s0,16(sp)
    80003e20:	64a2                	ld	s1,8(sp)
    80003e22:	6105                	addi	sp,sp,32
    80003e24:	8082                	ret

0000000080003e26 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80003e26:	1101                	addi	sp,sp,-32
    80003e28:	ec06                	sd	ra,24(sp)
    80003e2a:	e822                	sd	s0,16(sp)
    80003e2c:	e426                	sd	s1,8(sp)
    80003e2e:	e04a                	sd	s2,0(sp)
    80003e30:	1000                	addi	s0,sp,32
    80003e32:	84aa                	mv	s1,a0
    80003e34:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80003e36:	00003597          	auipc	a1,0x3
    80003e3a:	77258593          	addi	a1,a1,1906 # 800075a8 <etext+0x5a8>
    80003e3e:	0521                	addi	a0,a0,8
    80003e40:	d9bfc0ef          	jal	80000bda <initlock>
  lk->name = name;
    80003e44:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80003e48:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003e4c:	0204a423          	sw	zero,40(s1)
}
    80003e50:	60e2                	ld	ra,24(sp)
    80003e52:	6442                	ld	s0,16(sp)
    80003e54:	64a2                	ld	s1,8(sp)
    80003e56:	6902                	ld	s2,0(sp)
    80003e58:	6105                	addi	sp,sp,32
    80003e5a:	8082                	ret

0000000080003e5c <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80003e5c:	1101                	addi	sp,sp,-32
    80003e5e:	ec06                	sd	ra,24(sp)
    80003e60:	e822                	sd	s0,16(sp)
    80003e62:	e426                	sd	s1,8(sp)
    80003e64:	e04a                	sd	s2,0(sp)
    80003e66:	1000                	addi	s0,sp,32
    80003e68:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003e6a:	00850913          	addi	s2,a0,8
    80003e6e:	854a                	mv	a0,s2
    80003e70:	df5fc0ef          	jal	80000c64 <acquire>
  while (lk->locked) {
    80003e74:	409c                	lw	a5,0(s1)
    80003e76:	c799                	beqz	a5,80003e84 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    80003e78:	85ca                	mv	a1,s2
    80003e7a:	8526                	mv	a0,s1
    80003e7c:	870fe0ef          	jal	80001eec <sleep>
  while (lk->locked) {
    80003e80:	409c                	lw	a5,0(s1)
    80003e82:	fbfd                	bnez	a5,80003e78 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80003e84:	4785                	li	a5,1
    80003e86:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80003e88:	aa9fd0ef          	jal	80001930 <myproc>
    80003e8c:	591c                	lw	a5,48(a0)
    80003e8e:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80003e90:	854a                	mv	a0,s2
    80003e92:	e63fc0ef          	jal	80000cf4 <release>
}
    80003e96:	60e2                	ld	ra,24(sp)
    80003e98:	6442                	ld	s0,16(sp)
    80003e9a:	64a2                	ld	s1,8(sp)
    80003e9c:	6902                	ld	s2,0(sp)
    80003e9e:	6105                	addi	sp,sp,32
    80003ea0:	8082                	ret

0000000080003ea2 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80003ea2:	1101                	addi	sp,sp,-32
    80003ea4:	ec06                	sd	ra,24(sp)
    80003ea6:	e822                	sd	s0,16(sp)
    80003ea8:	e426                	sd	s1,8(sp)
    80003eaa:	e04a                	sd	s2,0(sp)
    80003eac:	1000                	addi	s0,sp,32
    80003eae:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003eb0:	00850913          	addi	s2,a0,8
    80003eb4:	854a                	mv	a0,s2
    80003eb6:	daffc0ef          	jal	80000c64 <acquire>
  lk->locked = 0;
    80003eba:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003ebe:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80003ec2:	8526                	mv	a0,s1
    80003ec4:	874fe0ef          	jal	80001f38 <wakeup>
  release(&lk->lk);
    80003ec8:	854a                	mv	a0,s2
    80003eca:	e2bfc0ef          	jal	80000cf4 <release>
}
    80003ece:	60e2                	ld	ra,24(sp)
    80003ed0:	6442                	ld	s0,16(sp)
    80003ed2:	64a2                	ld	s1,8(sp)
    80003ed4:	6902                	ld	s2,0(sp)
    80003ed6:	6105                	addi	sp,sp,32
    80003ed8:	8082                	ret

0000000080003eda <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80003eda:	7179                	addi	sp,sp,-48
    80003edc:	f406                	sd	ra,40(sp)
    80003ede:	f022                	sd	s0,32(sp)
    80003ee0:	ec26                	sd	s1,24(sp)
    80003ee2:	e84a                	sd	s2,16(sp)
    80003ee4:	1800                	addi	s0,sp,48
    80003ee6:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    80003ee8:	00850913          	addi	s2,a0,8
    80003eec:	854a                	mv	a0,s2
    80003eee:	d77fc0ef          	jal	80000c64 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80003ef2:	409c                	lw	a5,0(s1)
    80003ef4:	ef81                	bnez	a5,80003f0c <holdingsleep+0x32>
    80003ef6:	4481                	li	s1,0
  release(&lk->lk);
    80003ef8:	854a                	mv	a0,s2
    80003efa:	dfbfc0ef          	jal	80000cf4 <release>
  return r;
}
    80003efe:	8526                	mv	a0,s1
    80003f00:	70a2                	ld	ra,40(sp)
    80003f02:	7402                	ld	s0,32(sp)
    80003f04:	64e2                	ld	s1,24(sp)
    80003f06:	6942                	ld	s2,16(sp)
    80003f08:	6145                	addi	sp,sp,48
    80003f0a:	8082                	ret
    80003f0c:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80003f0e:	0284a983          	lw	s3,40(s1)
    80003f12:	a1ffd0ef          	jal	80001930 <myproc>
    80003f16:	5904                	lw	s1,48(a0)
    80003f18:	413484b3          	sub	s1,s1,s3
    80003f1c:	0014b493          	seqz	s1,s1
    80003f20:	69a2                	ld	s3,8(sp)
    80003f22:	bfd9                	j	80003ef8 <holdingsleep+0x1e>

0000000080003f24 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80003f24:	1141                	addi	sp,sp,-16
    80003f26:	e406                	sd	ra,8(sp)
    80003f28:	e022                	sd	s0,0(sp)
    80003f2a:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80003f2c:	00003597          	auipc	a1,0x3
    80003f30:	68c58593          	addi	a1,a1,1676 # 800075b8 <etext+0x5b8>
    80003f34:	0001c517          	auipc	a0,0x1c
    80003f38:	c8450513          	addi	a0,a0,-892 # 8001fbb8 <ftable>
    80003f3c:	c9ffc0ef          	jal	80000bda <initlock>
}
    80003f40:	60a2                	ld	ra,8(sp)
    80003f42:	6402                	ld	s0,0(sp)
    80003f44:	0141                	addi	sp,sp,16
    80003f46:	8082                	ret

0000000080003f48 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    80003f48:	1101                	addi	sp,sp,-32
    80003f4a:	ec06                	sd	ra,24(sp)
    80003f4c:	e822                	sd	s0,16(sp)
    80003f4e:	e426                	sd	s1,8(sp)
    80003f50:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80003f52:	0001c517          	auipc	a0,0x1c
    80003f56:	c6650513          	addi	a0,a0,-922 # 8001fbb8 <ftable>
    80003f5a:	d0bfc0ef          	jal	80000c64 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003f5e:	0001c497          	auipc	s1,0x1c
    80003f62:	c7248493          	addi	s1,s1,-910 # 8001fbd0 <ftable+0x18>
    80003f66:	0001d717          	auipc	a4,0x1d
    80003f6a:	c0a70713          	addi	a4,a4,-1014 # 80020b70 <disk>
    if(f->ref == 0){
    80003f6e:	40dc                	lw	a5,4(s1)
    80003f70:	cf89                	beqz	a5,80003f8a <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003f72:	02848493          	addi	s1,s1,40
    80003f76:	fee49ce3          	bne	s1,a4,80003f6e <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80003f7a:	0001c517          	auipc	a0,0x1c
    80003f7e:	c3e50513          	addi	a0,a0,-962 # 8001fbb8 <ftable>
    80003f82:	d73fc0ef          	jal	80000cf4 <release>
  return 0;
    80003f86:	4481                	li	s1,0
    80003f88:	a809                	j	80003f9a <filealloc+0x52>
      f->ref = 1;
    80003f8a:	4785                	li	a5,1
    80003f8c:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80003f8e:	0001c517          	auipc	a0,0x1c
    80003f92:	c2a50513          	addi	a0,a0,-982 # 8001fbb8 <ftable>
    80003f96:	d5ffc0ef          	jal	80000cf4 <release>
}
    80003f9a:	8526                	mv	a0,s1
    80003f9c:	60e2                	ld	ra,24(sp)
    80003f9e:	6442                	ld	s0,16(sp)
    80003fa0:	64a2                	ld	s1,8(sp)
    80003fa2:	6105                	addi	sp,sp,32
    80003fa4:	8082                	ret

0000000080003fa6 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80003fa6:	1101                	addi	sp,sp,-32
    80003fa8:	ec06                	sd	ra,24(sp)
    80003faa:	e822                	sd	s0,16(sp)
    80003fac:	e426                	sd	s1,8(sp)
    80003fae:	1000                	addi	s0,sp,32
    80003fb0:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80003fb2:	0001c517          	auipc	a0,0x1c
    80003fb6:	c0650513          	addi	a0,a0,-1018 # 8001fbb8 <ftable>
    80003fba:	cabfc0ef          	jal	80000c64 <acquire>
  if(f->ref < 1)
    80003fbe:	40dc                	lw	a5,4(s1)
    80003fc0:	02f05063          	blez	a5,80003fe0 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80003fc4:	2785                	addiw	a5,a5,1
    80003fc6:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80003fc8:	0001c517          	auipc	a0,0x1c
    80003fcc:	bf050513          	addi	a0,a0,-1040 # 8001fbb8 <ftable>
    80003fd0:	d25fc0ef          	jal	80000cf4 <release>
  return f;
}
    80003fd4:	8526                	mv	a0,s1
    80003fd6:	60e2                	ld	ra,24(sp)
    80003fd8:	6442                	ld	s0,16(sp)
    80003fda:	64a2                	ld	s1,8(sp)
    80003fdc:	6105                	addi	sp,sp,32
    80003fde:	8082                	ret
    panic("filedup");
    80003fe0:	00003517          	auipc	a0,0x3
    80003fe4:	5e050513          	addi	a0,a0,1504 # 800075c0 <etext+0x5c0>
    80003fe8:	809fc0ef          	jal	800007f0 <panic>

0000000080003fec <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80003fec:	7139                	addi	sp,sp,-64
    80003fee:	fc06                	sd	ra,56(sp)
    80003ff0:	f822                	sd	s0,48(sp)
    80003ff2:	f426                	sd	s1,40(sp)
    80003ff4:	0080                	addi	s0,sp,64
    80003ff6:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    80003ff8:	0001c517          	auipc	a0,0x1c
    80003ffc:	bc050513          	addi	a0,a0,-1088 # 8001fbb8 <ftable>
    80004000:	c65fc0ef          	jal	80000c64 <acquire>
  if(f->ref < 1)
    80004004:	40dc                	lw	a5,4(s1)
    80004006:	04f05a63          	blez	a5,8000405a <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    8000400a:	37fd                	addiw	a5,a5,-1
    8000400c:	c0dc                	sw	a5,4(s1)
    8000400e:	06f04063          	bgtz	a5,8000406e <fileclose+0x82>
    80004012:	f04a                	sd	s2,32(sp)
    80004014:	ec4e                	sd	s3,24(sp)
    80004016:	e852                	sd	s4,16(sp)
    80004018:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    8000401a:	0004a903          	lw	s2,0(s1)
    8000401e:	0094c783          	lbu	a5,9(s1)
    80004022:	89be                	mv	s3,a5
    80004024:	689c                	ld	a5,16(s1)
    80004026:	8a3e                	mv	s4,a5
    80004028:	6c9c                	ld	a5,24(s1)
    8000402a:	8abe                	mv	s5,a5
  f->ref = 0;
    8000402c:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    80004030:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    80004034:	0001c517          	auipc	a0,0x1c
    80004038:	b8450513          	addi	a0,a0,-1148 # 8001fbb8 <ftable>
    8000403c:	cb9fc0ef          	jal	80000cf4 <release>

  if(ff.type == FD_PIPE){
    80004040:	4785                	li	a5,1
    80004042:	04f90163          	beq	s2,a5,80004084 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    80004046:	ffe9079b          	addiw	a5,s2,-2
    8000404a:	4705                	li	a4,1
    8000404c:	04f77563          	bgeu	a4,a5,80004096 <fileclose+0xaa>
    80004050:	7902                	ld	s2,32(sp)
    80004052:	69e2                	ld	s3,24(sp)
    80004054:	6a42                	ld	s4,16(sp)
    80004056:	6aa2                	ld	s5,8(sp)
    80004058:	a00d                	j	8000407a <fileclose+0x8e>
    8000405a:	f04a                	sd	s2,32(sp)
    8000405c:	ec4e                	sd	s3,24(sp)
    8000405e:	e852                	sd	s4,16(sp)
    80004060:	e456                	sd	s5,8(sp)
    panic("fileclose");
    80004062:	00003517          	auipc	a0,0x3
    80004066:	56650513          	addi	a0,a0,1382 # 800075c8 <etext+0x5c8>
    8000406a:	f86fc0ef          	jal	800007f0 <panic>
    release(&ftable.lock);
    8000406e:	0001c517          	auipc	a0,0x1c
    80004072:	b4a50513          	addi	a0,a0,-1206 # 8001fbb8 <ftable>
    80004076:	c7ffc0ef          	jal	80000cf4 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    8000407a:	70e2                	ld	ra,56(sp)
    8000407c:	7442                	ld	s0,48(sp)
    8000407e:	74a2                	ld	s1,40(sp)
    80004080:	6121                	addi	sp,sp,64
    80004082:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80004084:	85ce                	mv	a1,s3
    80004086:	8552                	mv	a0,s4
    80004088:	332000ef          	jal	800043ba <pipeclose>
    8000408c:	7902                	ld	s2,32(sp)
    8000408e:	69e2                	ld	s3,24(sp)
    80004090:	6a42                	ld	s4,16(sp)
    80004092:	6aa2                	ld	s5,8(sp)
    80004094:	b7dd                	j	8000407a <fileclose+0x8e>
    begin_op();
    80004096:	b29ff0ef          	jal	80003bbe <begin_op>
    iput(ff.ip);
    8000409a:	8556                	mv	a0,s5
    8000409c:	be2ff0ef          	jal	8000347e <iput>
    end_op();
    800040a0:	b8fff0ef          	jal	80003c2e <end_op>
    800040a4:	7902                	ld	s2,32(sp)
    800040a6:	69e2                	ld	s3,24(sp)
    800040a8:	6a42                	ld	s4,16(sp)
    800040aa:	6aa2                	ld	s5,8(sp)
    800040ac:	b7f9                	j	8000407a <fileclose+0x8e>

00000000800040ae <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    800040ae:	715d                	addi	sp,sp,-80
    800040b0:	e486                	sd	ra,72(sp)
    800040b2:	e0a2                	sd	s0,64(sp)
    800040b4:	fc26                	sd	s1,56(sp)
    800040b6:	f052                	sd	s4,32(sp)
    800040b8:	0880                	addi	s0,sp,80
    800040ba:	84aa                	mv	s1,a0
    800040bc:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    800040be:	873fd0ef          	jal	80001930 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    800040c2:	409c                	lw	a5,0(s1)
    800040c4:	37f9                	addiw	a5,a5,-2
    800040c6:	4705                	li	a4,1
    800040c8:	04f76263          	bltu	a4,a5,8000410c <filestat+0x5e>
    800040cc:	f84a                	sd	s2,48(sp)
    800040ce:	f44e                	sd	s3,40(sp)
    800040d0:	89aa                	mv	s3,a0
    ilock(f->ip);
    800040d2:	6c88                	ld	a0,24(s1)
    800040d4:	a28ff0ef          	jal	800032fc <ilock>
    stati(f->ip, &st);
    800040d8:	fb840913          	addi	s2,s0,-72
    800040dc:	85ca                	mv	a1,s2
    800040de:	6c88                	ld	a0,24(s1)
    800040e0:	c48ff0ef          	jal	80003528 <stati>
    iunlock(f->ip);
    800040e4:	6c88                	ld	a0,24(s1)
    800040e6:	ac4ff0ef          	jal	800033aa <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    800040ea:	46e1                	li	a3,24
    800040ec:	864a                	mv	a2,s2
    800040ee:	85d2                	mv	a1,s4
    800040f0:	0509b503          	ld	a0,80(s3)
    800040f4:	cccfd0ef          	jal	800015c0 <copyout>
    800040f8:	41f5551b          	sraiw	a0,a0,0x1f
    800040fc:	7942                	ld	s2,48(sp)
    800040fe:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80004100:	60a6                	ld	ra,72(sp)
    80004102:	6406                	ld	s0,64(sp)
    80004104:	74e2                	ld	s1,56(sp)
    80004106:	7a02                	ld	s4,32(sp)
    80004108:	6161                	addi	sp,sp,80
    8000410a:	8082                	ret
  return -1;
    8000410c:	557d                	li	a0,-1
    8000410e:	bfcd                	j	80004100 <filestat+0x52>

0000000080004110 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    80004110:	7179                	addi	sp,sp,-48
    80004112:	f406                	sd	ra,40(sp)
    80004114:	f022                	sd	s0,32(sp)
    80004116:	e84a                	sd	s2,16(sp)
    80004118:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    8000411a:	00854783          	lbu	a5,8(a0)
    8000411e:	c3c5                	beqz	a5,800041be <fileread+0xae>
    80004120:	ec26                	sd	s1,24(sp)
    80004122:	e44e                	sd	s3,8(sp)
    80004124:	84aa                	mv	s1,a0
    80004126:	892e                	mv	s2,a1
    80004128:	89b2                	mv	s3,a2
    return -1;

  if(f->type == FD_PIPE){
    8000412a:	411c                	lw	a5,0(a0)
    8000412c:	4705                	li	a4,1
    8000412e:	04e78363          	beq	a5,a4,80004174 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    80004132:	470d                	li	a4,3
    80004134:	04e78763          	beq	a5,a4,80004182 <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    80004138:	4709                	li	a4,2
    8000413a:	06e79a63          	bne	a5,a4,800041ae <fileread+0x9e>
    ilock(f->ip);
    8000413e:	6d08                	ld	a0,24(a0)
    80004140:	9bcff0ef          	jal	800032fc <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    80004144:	874e                	mv	a4,s3
    80004146:	5094                	lw	a3,32(s1)
    80004148:	864a                	mv	a2,s2
    8000414a:	4585                	li	a1,1
    8000414c:	6c88                	ld	a0,24(s1)
    8000414e:	c08ff0ef          	jal	80003556 <readi>
    80004152:	892a                	mv	s2,a0
    80004154:	00a05563          	blez	a0,8000415e <fileread+0x4e>
      f->off += r;
    80004158:	509c                	lw	a5,32(s1)
    8000415a:	9fa9                	addw	a5,a5,a0
    8000415c:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    8000415e:	6c88                	ld	a0,24(s1)
    80004160:	a4aff0ef          	jal	800033aa <iunlock>
    80004164:	64e2                	ld	s1,24(sp)
    80004166:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    80004168:	854a                	mv	a0,s2
    8000416a:	70a2                	ld	ra,40(sp)
    8000416c:	7402                	ld	s0,32(sp)
    8000416e:	6942                	ld	s2,16(sp)
    80004170:	6145                	addi	sp,sp,48
    80004172:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80004174:	6908                	ld	a0,16(a0)
    80004176:	39a000ef          	jal	80004510 <piperead>
    8000417a:	892a                	mv	s2,a0
    8000417c:	64e2                	ld	s1,24(sp)
    8000417e:	69a2                	ld	s3,8(sp)
    80004180:	b7e5                	j	80004168 <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80004182:	02451783          	lh	a5,36(a0)
    80004186:	03079693          	slli	a3,a5,0x30
    8000418a:	92c1                	srli	a3,a3,0x30
    8000418c:	4725                	li	a4,9
    8000418e:	02d76663          	bltu	a4,a3,800041ba <fileread+0xaa>
    80004192:	0792                	slli	a5,a5,0x4
    80004194:	0001c717          	auipc	a4,0x1c
    80004198:	98470713          	addi	a4,a4,-1660 # 8001fb18 <devsw>
    8000419c:	97ba                	add	a5,a5,a4
    8000419e:	639c                	ld	a5,0(a5)
    800041a0:	c395                	beqz	a5,800041c4 <fileread+0xb4>
    r = devsw[f->major].read(1, addr, n);
    800041a2:	4505                	li	a0,1
    800041a4:	9782                	jalr	a5
    800041a6:	892a                	mv	s2,a0
    800041a8:	64e2                	ld	s1,24(sp)
    800041aa:	69a2                	ld	s3,8(sp)
    800041ac:	bf75                	j	80004168 <fileread+0x58>
    panic("fileread");
    800041ae:	00003517          	auipc	a0,0x3
    800041b2:	42a50513          	addi	a0,a0,1066 # 800075d8 <etext+0x5d8>
    800041b6:	e3afc0ef          	jal	800007f0 <panic>
    800041ba:	64e2                	ld	s1,24(sp)
    800041bc:	69a2                	ld	s3,8(sp)
    return -1;
    800041be:	57fd                	li	a5,-1
    800041c0:	893e                	mv	s2,a5
    800041c2:	b75d                	j	80004168 <fileread+0x58>
    800041c4:	64e2                	ld	s1,24(sp)
    800041c6:	69a2                	ld	s3,8(sp)
    800041c8:	bfdd                	j	800041be <fileread+0xae>

00000000800041ca <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    800041ca:	00954783          	lbu	a5,9(a0)
    800041ce:	12078463          	beqz	a5,800042f6 <filewrite+0x12c>
{
    800041d2:	711d                	addi	sp,sp,-96
    800041d4:	ec86                	sd	ra,88(sp)
    800041d6:	e8a2                	sd	s0,80(sp)
    800041d8:	e0ca                	sd	s2,64(sp)
    800041da:	f456                	sd	s5,40(sp)
    800041dc:	f05a                	sd	s6,32(sp)
    800041de:	1080                	addi	s0,sp,96
    800041e0:	892a                	mv	s2,a0
    800041e2:	8b2e                	mv	s6,a1
    800041e4:	8ab2                	mv	s5,a2
    return -1;

  if(f->type == FD_PIPE){
    800041e6:	411c                	lw	a5,0(a0)
    800041e8:	4705                	li	a4,1
    800041ea:	02e78a63          	beq	a5,a4,8000421e <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800041ee:	470d                	li	a4,3
    800041f0:	02e78b63          	beq	a5,a4,80004226 <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800041f4:	4709                	li	a4,2
    800041f6:	0ce79f63          	bne	a5,a4,800042d4 <filewrite+0x10a>
    800041fa:	f852                	sd	s4,48(sp)
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800041fc:	0ac05a63          	blez	a2,800042b0 <filewrite+0xe6>
    80004200:	e4a6                	sd	s1,72(sp)
    80004202:	fc4e                	sd	s3,56(sp)
    80004204:	ec5e                	sd	s7,24(sp)
    80004206:	e862                	sd	s8,16(sp)
    80004208:	e466                	sd	s9,8(sp)
    int i = 0;
    8000420a:	4a01                	li	s4,0
      int n1 = n - i;
      if(n1 > max)
    8000420c:	6b85                	lui	s7,0x1
    8000420e:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    80004212:	6785                	lui	a5,0x1
    80004214:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    80004218:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    8000421a:	4c05                	li	s8,1
    8000421c:	a8ad                	j	80004296 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    8000421e:	6908                	ld	a0,16(a0)
    80004220:	1f8000ef          	jal	80004418 <pipewrite>
    80004224:	a04d                	j	800042c6 <filewrite+0xfc>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    80004226:	02451783          	lh	a5,36(a0)
    8000422a:	03079693          	slli	a3,a5,0x30
    8000422e:	92c1                	srli	a3,a3,0x30
    80004230:	4725                	li	a4,9
    80004232:	0ad76d63          	bltu	a4,a3,800042ec <filewrite+0x122>
    80004236:	0792                	slli	a5,a5,0x4
    80004238:	0001c717          	auipc	a4,0x1c
    8000423c:	8e070713          	addi	a4,a4,-1824 # 8001fb18 <devsw>
    80004240:	97ba                	add	a5,a5,a4
    80004242:	679c                	ld	a5,8(a5)
    80004244:	c7c5                	beqz	a5,800042ec <filewrite+0x122>
    ret = devsw[f->major].write(1, addr, n);
    80004246:	4505                	li	a0,1
    80004248:	9782                	jalr	a5
    8000424a:	a8b5                	j	800042c6 <filewrite+0xfc>
      if(n1 > max)
    8000424c:	2981                	sext.w	s3,s3
      begin_op();
    8000424e:	971ff0ef          	jal	80003bbe <begin_op>
      ilock(f->ip);
    80004252:	01893503          	ld	a0,24(s2)
    80004256:	8a6ff0ef          	jal	800032fc <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    8000425a:	874e                	mv	a4,s3
    8000425c:	02092683          	lw	a3,32(s2)
    80004260:	016a0633          	add	a2,s4,s6
    80004264:	85e2                	mv	a1,s8
    80004266:	01893503          	ld	a0,24(s2)
    8000426a:	bdeff0ef          	jal	80003648 <writei>
    8000426e:	84aa                	mv	s1,a0
    80004270:	00a05763          	blez	a0,8000427e <filewrite+0xb4>
        f->off += r;
    80004274:	02092783          	lw	a5,32(s2)
    80004278:	9fa9                	addw	a5,a5,a0
    8000427a:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    8000427e:	01893503          	ld	a0,24(s2)
    80004282:	928ff0ef          	jal	800033aa <iunlock>
      end_op();
    80004286:	9a9ff0ef          	jal	80003c2e <end_op>

      if(r != n1){
    8000428a:	02999563          	bne	s3,s1,800042b4 <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    8000428e:	01448a3b          	addw	s4,s1,s4
    while(i < n){
    80004292:	015a5963          	bge	s4,s5,800042a4 <filewrite+0xda>
      int n1 = n - i;
    80004296:	414a87bb          	subw	a5,s5,s4
    8000429a:	89be                	mv	s3,a5
      if(n1 > max)
    8000429c:	fafbd8e3          	bge	s7,a5,8000424c <filewrite+0x82>
    800042a0:	89e6                	mv	s3,s9
    800042a2:	b76d                	j	8000424c <filewrite+0x82>
    800042a4:	64a6                	ld	s1,72(sp)
    800042a6:	79e2                	ld	s3,56(sp)
    800042a8:	6be2                	ld	s7,24(sp)
    800042aa:	6c42                	ld	s8,16(sp)
    800042ac:	6ca2                	ld	s9,8(sp)
    800042ae:	a801                	j	800042be <filewrite+0xf4>
    int i = 0;
    800042b0:	4a01                	li	s4,0
    800042b2:	a031                	j	800042be <filewrite+0xf4>
    800042b4:	64a6                	ld	s1,72(sp)
    800042b6:	79e2                	ld	s3,56(sp)
    800042b8:	6be2                	ld	s7,24(sp)
    800042ba:	6c42                	ld	s8,16(sp)
    800042bc:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    800042be:	034a9963          	bne	s5,s4,800042f0 <filewrite+0x126>
    800042c2:	8556                	mv	a0,s5
    800042c4:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    800042c6:	60e6                	ld	ra,88(sp)
    800042c8:	6446                	ld	s0,80(sp)
    800042ca:	6906                	ld	s2,64(sp)
    800042cc:	7aa2                	ld	s5,40(sp)
    800042ce:	7b02                	ld	s6,32(sp)
    800042d0:	6125                	addi	sp,sp,96
    800042d2:	8082                	ret
    800042d4:	e4a6                	sd	s1,72(sp)
    800042d6:	fc4e                	sd	s3,56(sp)
    800042d8:	f852                	sd	s4,48(sp)
    800042da:	ec5e                	sd	s7,24(sp)
    800042dc:	e862                	sd	s8,16(sp)
    800042de:	e466                	sd	s9,8(sp)
    panic("filewrite");
    800042e0:	00003517          	auipc	a0,0x3
    800042e4:	30850513          	addi	a0,a0,776 # 800075e8 <etext+0x5e8>
    800042e8:	d08fc0ef          	jal	800007f0 <panic>
    return -1;
    800042ec:	557d                	li	a0,-1
    800042ee:	bfe1                	j	800042c6 <filewrite+0xfc>
    ret = (i == n ? n : -1);
    800042f0:	557d                	li	a0,-1
    800042f2:	7a42                	ld	s4,48(sp)
    800042f4:	bfc9                	j	800042c6 <filewrite+0xfc>
    return -1;
    800042f6:	557d                	li	a0,-1
}
    800042f8:	8082                	ret

00000000800042fa <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800042fa:	7179                	addi	sp,sp,-48
    800042fc:	f406                	sd	ra,40(sp)
    800042fe:	f022                	sd	s0,32(sp)
    80004300:	ec26                	sd	s1,24(sp)
    80004302:	e052                	sd	s4,0(sp)
    80004304:	1800                	addi	s0,sp,48
    80004306:	84aa                	mv	s1,a0
    80004308:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    8000430a:	0005b023          	sd	zero,0(a1)
    8000430e:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    80004312:	c37ff0ef          	jal	80003f48 <filealloc>
    80004316:	e088                	sd	a0,0(s1)
    80004318:	c549                	beqz	a0,800043a2 <pipealloc+0xa8>
    8000431a:	c2fff0ef          	jal	80003f48 <filealloc>
    8000431e:	00aa3023          	sd	a0,0(s4)
    80004322:	cd25                	beqz	a0,8000439a <pipealloc+0xa0>
    80004324:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    80004326:	85bfc0ef          	jal	80000b80 <kalloc>
    8000432a:	892a                	mv	s2,a0
    8000432c:	c12d                	beqz	a0,8000438e <pipealloc+0x94>
    8000432e:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    80004330:	4985                	li	s3,1
    80004332:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    80004336:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    8000433a:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    8000433e:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    80004342:	00003597          	auipc	a1,0x3
    80004346:	2b658593          	addi	a1,a1,694 # 800075f8 <etext+0x5f8>
    8000434a:	891fc0ef          	jal	80000bda <initlock>
  (*f0)->type = FD_PIPE;
    8000434e:	609c                	ld	a5,0(s1)
    80004350:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    80004354:	609c                	ld	a5,0(s1)
    80004356:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    8000435a:	609c                	ld	a5,0(s1)
    8000435c:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80004360:	609c                	ld	a5,0(s1)
    80004362:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004366:	000a3783          	ld	a5,0(s4)
    8000436a:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    8000436e:	000a3783          	ld	a5,0(s4)
    80004372:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004376:	000a3783          	ld	a5,0(s4)
    8000437a:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    8000437e:	000a3783          	ld	a5,0(s4)
    80004382:	0127b823          	sd	s2,16(a5)
  return 0;
    80004386:	4501                	li	a0,0
    80004388:	6942                	ld	s2,16(sp)
    8000438a:	69a2                	ld	s3,8(sp)
    8000438c:	a00d                	j	800043ae <pipealloc+0xb4>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    8000438e:	6088                	ld	a0,0(s1)
    80004390:	c119                	beqz	a0,80004396 <pipealloc+0x9c>
    80004392:	6942                	ld	s2,16(sp)
    80004394:	a029                	j	8000439e <pipealloc+0xa4>
    80004396:	6942                	ld	s2,16(sp)
    80004398:	a029                	j	800043a2 <pipealloc+0xa8>
    8000439a:	6088                	ld	a0,0(s1)
    8000439c:	c901                	beqz	a0,800043ac <pipealloc+0xb2>
    fileclose(*f0);
    8000439e:	c4fff0ef          	jal	80003fec <fileclose>
  if(*f1)
    800043a2:	000a3503          	ld	a0,0(s4)
    800043a6:	c119                	beqz	a0,800043ac <pipealloc+0xb2>
    fileclose(*f1);
    800043a8:	c45ff0ef          	jal	80003fec <fileclose>
  return -1;
    800043ac:	557d                	li	a0,-1
}
    800043ae:	70a2                	ld	ra,40(sp)
    800043b0:	7402                	ld	s0,32(sp)
    800043b2:	64e2                	ld	s1,24(sp)
    800043b4:	6a02                	ld	s4,0(sp)
    800043b6:	6145                	addi	sp,sp,48
    800043b8:	8082                	ret

00000000800043ba <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    800043ba:	1101                	addi	sp,sp,-32
    800043bc:	ec06                	sd	ra,24(sp)
    800043be:	e822                	sd	s0,16(sp)
    800043c0:	e426                	sd	s1,8(sp)
    800043c2:	e04a                	sd	s2,0(sp)
    800043c4:	1000                	addi	s0,sp,32
    800043c6:	84aa                	mv	s1,a0
    800043c8:	892e                	mv	s2,a1
  acquire(&pi->lock);
    800043ca:	89bfc0ef          	jal	80000c64 <acquire>
  if(writable){
    800043ce:	02090763          	beqz	s2,800043fc <pipeclose+0x42>
    pi->writeopen = 0;
    800043d2:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    800043d6:	21848513          	addi	a0,s1,536
    800043da:	b5ffd0ef          	jal	80001f38 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    800043de:	2204a783          	lw	a5,544(s1)
    800043e2:	e781                	bnez	a5,800043ea <pipeclose+0x30>
    800043e4:	2244a783          	lw	a5,548(s1)
    800043e8:	c38d                	beqz	a5,8000440a <pipeclose+0x50>
    release(&pi->lock);
    kfree((char*)pi);
  } else
    release(&pi->lock);
    800043ea:	8526                	mv	a0,s1
    800043ec:	909fc0ef          	jal	80000cf4 <release>
}
    800043f0:	60e2                	ld	ra,24(sp)
    800043f2:	6442                	ld	s0,16(sp)
    800043f4:	64a2                	ld	s1,8(sp)
    800043f6:	6902                	ld	s2,0(sp)
    800043f8:	6105                	addi	sp,sp,32
    800043fa:	8082                	ret
    pi->readopen = 0;
    800043fc:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    80004400:	21c48513          	addi	a0,s1,540
    80004404:	b35fd0ef          	jal	80001f38 <wakeup>
    80004408:	bfd9                	j	800043de <pipeclose+0x24>
    release(&pi->lock);
    8000440a:	8526                	mv	a0,s1
    8000440c:	8e9fc0ef          	jal	80000cf4 <release>
    kfree((char*)pi);
    80004410:	8526                	mv	a0,s1
    80004412:	e86fc0ef          	jal	80000a98 <kfree>
    80004416:	bfe9                	j	800043f0 <pipeclose+0x36>

0000000080004418 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    80004418:	7159                	addi	sp,sp,-112
    8000441a:	f486                	sd	ra,104(sp)
    8000441c:	f0a2                	sd	s0,96(sp)
    8000441e:	eca6                	sd	s1,88(sp)
    80004420:	e8ca                	sd	s2,80(sp)
    80004422:	e4ce                	sd	s3,72(sp)
    80004424:	e0d2                	sd	s4,64(sp)
    80004426:	fc56                	sd	s5,56(sp)
    80004428:	1880                	addi	s0,sp,112
    8000442a:	84aa                	mv	s1,a0
    8000442c:	8aae                	mv	s5,a1
    8000442e:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    80004430:	d00fd0ef          	jal	80001930 <myproc>
    80004434:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    80004436:	8526                	mv	a0,s1
    80004438:	82dfc0ef          	jal	80000c64 <acquire>
  while(i < n){
    8000443c:	0d405263          	blez	s4,80004500 <pipewrite+0xe8>
    80004440:	f85a                	sd	s6,48(sp)
    80004442:	f45e                	sd	s7,40(sp)
    80004444:	f062                	sd	s8,32(sp)
    80004446:	ec66                	sd	s9,24(sp)
    80004448:	e86a                	sd	s10,16(sp)
  int i = 0;
    8000444a:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    8000444c:	f9f40c13          	addi	s8,s0,-97
    80004450:	4b85                	li	s7,1
    80004452:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80004454:	21848d13          	addi	s10,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80004458:	21c48c93          	addi	s9,s1,540
    8000445c:	a82d                	j	80004496 <pipewrite+0x7e>
      release(&pi->lock);
    8000445e:	8526                	mv	a0,s1
    80004460:	895fc0ef          	jal	80000cf4 <release>
      return -1;
    80004464:	597d                	li	s2,-1
    80004466:	7b42                	ld	s6,48(sp)
    80004468:	7ba2                	ld	s7,40(sp)
    8000446a:	7c02                	ld	s8,32(sp)
    8000446c:	6ce2                	ld	s9,24(sp)
    8000446e:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80004470:	854a                	mv	a0,s2
    80004472:	70a6                	ld	ra,104(sp)
    80004474:	7406                	ld	s0,96(sp)
    80004476:	64e6                	ld	s1,88(sp)
    80004478:	6946                	ld	s2,80(sp)
    8000447a:	69a6                	ld	s3,72(sp)
    8000447c:	6a06                	ld	s4,64(sp)
    8000447e:	7ae2                	ld	s5,56(sp)
    80004480:	6165                	addi	sp,sp,112
    80004482:	8082                	ret
      wakeup(&pi->nread);
    80004484:	856a                	mv	a0,s10
    80004486:	ab3fd0ef          	jal	80001f38 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    8000448a:	85a6                	mv	a1,s1
    8000448c:	8566                	mv	a0,s9
    8000448e:	a5ffd0ef          	jal	80001eec <sleep>
  while(i < n){
    80004492:	05495a63          	bge	s2,s4,800044e6 <pipewrite+0xce>
    if(pi->readopen == 0 || killed(pr)){
    80004496:	2204a783          	lw	a5,544(s1)
    8000449a:	d3f1                	beqz	a5,8000445e <pipewrite+0x46>
    8000449c:	854e                	mv	a0,s3
    8000449e:	c8bfd0ef          	jal	80002128 <killed>
    800044a2:	fd55                	bnez	a0,8000445e <pipewrite+0x46>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    800044a4:	2184a783          	lw	a5,536(s1)
    800044a8:	21c4a703          	lw	a4,540(s1)
    800044ac:	2007879b          	addiw	a5,a5,512
    800044b0:	fcf70ae3          	beq	a4,a5,80004484 <pipewrite+0x6c>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    800044b4:	86de                	mv	a3,s7
    800044b6:	01590633          	add	a2,s2,s5
    800044ba:	85e2                	mv	a1,s8
    800044bc:	0509b503          	ld	a0,80(s3)
    800044c0:	9aefd0ef          	jal	8000166e <copyin>
    800044c4:	05650063          	beq	a0,s6,80004504 <pipewrite+0xec>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    800044c8:	21c4a783          	lw	a5,540(s1)
    800044cc:	0017871b          	addiw	a4,a5,1
    800044d0:	20e4ae23          	sw	a4,540(s1)
    800044d4:	1ff7f793          	andi	a5,a5,511
    800044d8:	97a6                	add	a5,a5,s1
    800044da:	f9f44703          	lbu	a4,-97(s0)
    800044de:	00e78c23          	sb	a4,24(a5)
      i++;
    800044e2:	2905                	addiw	s2,s2,1
    800044e4:	b77d                	j	80004492 <pipewrite+0x7a>
    800044e6:	7b42                	ld	s6,48(sp)
    800044e8:	7ba2                	ld	s7,40(sp)
    800044ea:	7c02                	ld	s8,32(sp)
    800044ec:	6ce2                	ld	s9,24(sp)
    800044ee:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    800044f0:	21848513          	addi	a0,s1,536
    800044f4:	a45fd0ef          	jal	80001f38 <wakeup>
  release(&pi->lock);
    800044f8:	8526                	mv	a0,s1
    800044fa:	ffafc0ef          	jal	80000cf4 <release>
  return i;
    800044fe:	bf8d                	j	80004470 <pipewrite+0x58>
  int i = 0;
    80004500:	4901                	li	s2,0
    80004502:	b7fd                	j	800044f0 <pipewrite+0xd8>
    80004504:	7b42                	ld	s6,48(sp)
    80004506:	7ba2                	ld	s7,40(sp)
    80004508:	7c02                	ld	s8,32(sp)
    8000450a:	6ce2                	ld	s9,24(sp)
    8000450c:	6d42                	ld	s10,16(sp)
    8000450e:	b7cd                	j	800044f0 <pipewrite+0xd8>

0000000080004510 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004510:	711d                	addi	sp,sp,-96
    80004512:	ec86                	sd	ra,88(sp)
    80004514:	e8a2                	sd	s0,80(sp)
    80004516:	e4a6                	sd	s1,72(sp)
    80004518:	e0ca                	sd	s2,64(sp)
    8000451a:	fc4e                	sd	s3,56(sp)
    8000451c:	f852                	sd	s4,48(sp)
    8000451e:	f456                	sd	s5,40(sp)
    80004520:	1080                	addi	s0,sp,96
    80004522:	84aa                	mv	s1,a0
    80004524:	892e                	mv	s2,a1
    80004526:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80004528:	c08fd0ef          	jal	80001930 <myproc>
    8000452c:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    8000452e:	8526                	mv	a0,s1
    80004530:	f34fc0ef          	jal	80000c64 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004534:	2184a703          	lw	a4,536(s1)
    80004538:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    8000453c:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004540:	02f71363          	bne	a4,a5,80004566 <piperead+0x56>
    80004544:	2244a783          	lw	a5,548(s1)
    80004548:	cf99                	beqz	a5,80004566 <piperead+0x56>
    if(killed(pr)){
    8000454a:	8552                	mv	a0,s4
    8000454c:	bddfd0ef          	jal	80002128 <killed>
    80004550:	e53d                	bnez	a0,800045be <piperead+0xae>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004552:	85a6                	mv	a1,s1
    80004554:	854e                	mv	a0,s3
    80004556:	997fd0ef          	jal	80001eec <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    8000455a:	2184a703          	lw	a4,536(s1)
    8000455e:	21c4a783          	lw	a5,540(s1)
    80004562:	fef701e3          	beq	a4,a5,80004544 <piperead+0x34>
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004566:	07505163          	blez	s5,800045c8 <piperead+0xb8>
    8000456a:	f05a                	sd	s6,32(sp)
    8000456c:	ec5e                	sd	s7,24(sp)
    8000456e:	e862                	sd	s8,16(sp)
    80004570:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004572:	faf40c13          	addi	s8,s0,-81
    80004576:	4b85                	li	s7,1
    80004578:	5b7d                	li	s6,-1
    if(pi->nread == pi->nwrite)
    8000457a:	2184a783          	lw	a5,536(s1)
    8000457e:	21c4a703          	lw	a4,540(s1)
    80004582:	04f70563          	beq	a4,a5,800045cc <piperead+0xbc>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80004586:	0017871b          	addiw	a4,a5,1
    8000458a:	20e4ac23          	sw	a4,536(s1)
    8000458e:	1ff7f793          	andi	a5,a5,511
    80004592:	97a6                	add	a5,a5,s1
    80004594:	0187c783          	lbu	a5,24(a5)
    80004598:	faf407a3          	sb	a5,-81(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    8000459c:	86de                	mv	a3,s7
    8000459e:	8662                	mv	a2,s8
    800045a0:	85ca                	mv	a1,s2
    800045a2:	050a3503          	ld	a0,80(s4)
    800045a6:	81afd0ef          	jal	800015c0 <copyout>
    800045aa:	05650563          	beq	a0,s6,800045f4 <piperead+0xe4>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800045ae:	2985                	addiw	s3,s3,1
    800045b0:	0905                	addi	s2,s2,1
    800045b2:	fd3a94e3          	bne	s5,s3,8000457a <piperead+0x6a>
    800045b6:	7b02                	ld	s6,32(sp)
    800045b8:	6be2                	ld	s7,24(sp)
    800045ba:	6c42                	ld	s8,16(sp)
    800045bc:	a819                	j	800045d2 <piperead+0xc2>
      release(&pi->lock);
    800045be:	8526                	mv	a0,s1
    800045c0:	f34fc0ef          	jal	80000cf4 <release>
      return -1;
    800045c4:	59fd                	li	s3,-1
    800045c6:	a829                	j	800045e0 <piperead+0xd0>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    800045c8:	4981                	li	s3,0
    800045ca:	a021                	j	800045d2 <piperead+0xc2>
    800045cc:	7b02                	ld	s6,32(sp)
    800045ce:	6be2                	ld	s7,24(sp)
    800045d0:	6c42                	ld	s8,16(sp)
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    800045d2:	21c48513          	addi	a0,s1,540
    800045d6:	963fd0ef          	jal	80001f38 <wakeup>
  release(&pi->lock);
    800045da:	8526                	mv	a0,s1
    800045dc:	f18fc0ef          	jal	80000cf4 <release>
  return i;
}
    800045e0:	854e                	mv	a0,s3
    800045e2:	60e6                	ld	ra,88(sp)
    800045e4:	6446                	ld	s0,80(sp)
    800045e6:	64a6                	ld	s1,72(sp)
    800045e8:	6906                	ld	s2,64(sp)
    800045ea:	79e2                	ld	s3,56(sp)
    800045ec:	7a42                	ld	s4,48(sp)
    800045ee:	7aa2                	ld	s5,40(sp)
    800045f0:	6125                	addi	sp,sp,96
    800045f2:	8082                	ret
    800045f4:	7b02                	ld	s6,32(sp)
    800045f6:	6be2                	ld	s7,24(sp)
    800045f8:	6c42                	ld	s8,16(sp)
    800045fa:	bfe1                	j	800045d2 <piperead+0xc2>

00000000800045fc <flags2perm>:
#include "elf.h"

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

int flags2perm(int flags)
{
    800045fc:	1141                	addi	sp,sp,-16
    800045fe:	e406                	sd	ra,8(sp)
    80004600:	e022                	sd	s0,0(sp)
    80004602:	0800                	addi	s0,sp,16
    80004604:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80004606:	0035151b          	slliw	a0,a0,0x3
    8000460a:	8921                	andi	a0,a0,8
      perm = PTE_X;
    if(flags & 0x2)
    8000460c:	8b89                	andi	a5,a5,2
    8000460e:	c399                	beqz	a5,80004614 <flags2perm+0x18>
      perm |= PTE_W;
    80004610:	00456513          	ori	a0,a0,4
    return perm;
}
    80004614:	60a2                	ld	ra,8(sp)
    80004616:	6402                	ld	s0,0(sp)
    80004618:	0141                	addi	sp,sp,16
    8000461a:	8082                	ret

000000008000461c <exec>:

int
exec(char *path, char **argv)
{
    8000461c:	df010113          	addi	sp,sp,-528
    80004620:	20113423          	sd	ra,520(sp)
    80004624:	20813023          	sd	s0,512(sp)
    80004628:	ffa6                	sd	s1,504(sp)
    8000462a:	fbca                	sd	s2,496(sp)
    8000462c:	0c00                	addi	s0,sp,528
    8000462e:	892a                	mv	s2,a0
    80004630:	e0a43023          	sd	a0,-512(s0)
    80004634:	deb43c23          	sd	a1,-520(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004638:	af8fd0ef          	jal	80001930 <myproc>
    8000463c:	84aa                	mv	s1,a0

  begin_op();
    8000463e:	d80ff0ef          	jal	80003bbe <begin_op>

  if((ip = namei(path)) == 0){
    80004642:	854a                	mv	a0,s2
    80004644:	bb8ff0ef          	jal	800039fc <namei>
    80004648:	c931                	beqz	a0,8000469c <exec+0x80>
    8000464a:	f3d2                	sd	s4,480(sp)
    8000464c:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    8000464e:	caffe0ef          	jal	800032fc <ilock>

  // Check ELF header
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004652:	04000713          	li	a4,64
    80004656:	4681                	li	a3,0
    80004658:	e5040613          	addi	a2,s0,-432
    8000465c:	4581                	li	a1,0
    8000465e:	8552                	mv	a0,s4
    80004660:	ef7fe0ef          	jal	80003556 <readi>
    80004664:	04000793          	li	a5,64
    80004668:	00f51a63          	bne	a0,a5,8000467c <exec+0x60>
    goto bad;

  if(elf.magic != ELF_MAGIC)
    8000466c:	e5042703          	lw	a4,-432(s0)
    80004670:	464c47b7          	lui	a5,0x464c4
    80004674:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004678:	02f70563          	beq	a4,a5,800046a2 <exec+0x86>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    8000467c:	8552                	mv	a0,s4
    8000467e:	e8bfe0ef          	jal	80003508 <iunlockput>
    end_op();
    80004682:	dacff0ef          	jal	80003c2e <end_op>
    80004686:	7a1e                	ld	s4,480(sp)
    return -1;
    80004688:	557d                	li	a0,-1
  }
  return -1;
}
    8000468a:	20813083          	ld	ra,520(sp)
    8000468e:	20013403          	ld	s0,512(sp)
    80004692:	74fe                	ld	s1,504(sp)
    80004694:	795e                	ld	s2,496(sp)
    80004696:	21010113          	addi	sp,sp,528
    8000469a:	8082                	ret
    end_op();
    8000469c:	d92ff0ef          	jal	80003c2e <end_op>
    return -1;
    800046a0:	b7e5                	j	80004688 <exec+0x6c>
    800046a2:	ebda                	sd	s6,464(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    800046a4:	8526                	mv	a0,s1
    800046a6:	b34fd0ef          	jal	800019da <proc_pagetable>
    800046aa:	8b2a                	mv	s6,a0
    800046ac:	26050063          	beqz	a0,8000490c <exec+0x2f0>
    800046b0:	f7ce                	sd	s3,488(sp)
    800046b2:	efd6                	sd	s5,472(sp)
    800046b4:	e7de                	sd	s7,456(sp)
    800046b6:	e3e2                	sd	s8,448(sp)
    800046b8:	ff66                	sd	s9,440(sp)
    800046ba:	fb6a                	sd	s10,432(sp)
    800046bc:	f76e                	sd	s11,424(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    800046be:	e8845783          	lhu	a5,-376(s0)
    800046c2:	cff9                	beqz	a5,800047a0 <exec+0x184>
    800046c4:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    800046c8:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    800046ca:	4d01                	li	s10,0
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    800046cc:	03800d93          	li	s11,56

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    800046d0:	6c85                	lui	s9,0x1
    800046d2:	6a85                	lui	s5,0x1
    800046d4:	a085                	j	80004734 <exec+0x118>
      panic("loadseg: address should exist");
    800046d6:	00003517          	auipc	a0,0x3
    800046da:	f2a50513          	addi	a0,a0,-214 # 80007600 <etext+0x600>
    800046de:	912fc0ef          	jal	800007f0 <panic>
    if(sz - i < PGSIZE)
    800046e2:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    800046e4:	874a                	mv	a4,s2
    800046e6:	009b86bb          	addw	a3,s7,s1
    800046ea:	4581                	li	a1,0
    800046ec:	8552                	mv	a0,s4
    800046ee:	e69fe0ef          	jal	80003556 <readi>
    800046f2:	22a91163          	bne	s2,a0,80004914 <exec+0x2f8>
  for(i = 0; i < sz; i += PGSIZE){
    800046f6:	009a84bb          	addw	s1,s5,s1
    800046fa:	0334f263          	bgeu	s1,s3,8000471e <exec+0x102>
    pa = walkaddr(pagetable, va + i);
    800046fe:	02049593          	slli	a1,s1,0x20
    80004702:	9181                	srli	a1,a1,0x20
    80004704:	95e2                	add	a1,a1,s8
    80004706:	855a                	mv	a0,s6
    80004708:	955fc0ef          	jal	8000105c <walkaddr>
    8000470c:	862a                	mv	a2,a0
    if(pa == 0)
    8000470e:	d561                	beqz	a0,800046d6 <exec+0xba>
    if(sz - i < PGSIZE)
    80004710:	409987bb          	subw	a5,s3,s1
    80004714:	893e                	mv	s2,a5
    80004716:	fcfcf6e3          	bgeu	s9,a5,800046e2 <exec+0xc6>
    8000471a:	8956                	mv	s2,s5
    8000471c:	b7d9                	j	800046e2 <exec+0xc6>
    sz = sz1;
    8000471e:	df043903          	ld	s2,-528(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004722:	2d05                	addiw	s10,s10,1
    80004724:	e0843783          	ld	a5,-504(s0)
    80004728:	0387869b          	addiw	a3,a5,56
    8000472c:	e8845783          	lhu	a5,-376(s0)
    80004730:	06fd5963          	bge	s10,a5,800047a2 <exec+0x186>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004734:	e0d43423          	sd	a3,-504(s0)
    80004738:	876e                	mv	a4,s11
    8000473a:	e1840613          	addi	a2,s0,-488
    8000473e:	4581                	li	a1,0
    80004740:	8552                	mv	a0,s4
    80004742:	e15fe0ef          	jal	80003556 <readi>
    80004746:	1db51563          	bne	a0,s11,80004910 <exec+0x2f4>
    if(ph.type != ELF_PROG_LOAD)
    8000474a:	e1842783          	lw	a5,-488(s0)
    8000474e:	4705                	li	a4,1
    80004750:	fce799e3          	bne	a5,a4,80004722 <exec+0x106>
    if(ph.memsz < ph.filesz)
    80004754:	e4043483          	ld	s1,-448(s0)
    80004758:	e3843783          	ld	a5,-456(s0)
    8000475c:	1af4ea63          	bltu	s1,a5,80004910 <exec+0x2f4>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80004760:	e2843783          	ld	a5,-472(s0)
    80004764:	94be                	add	s1,s1,a5
    80004766:	1af4e563          	bltu	s1,a5,80004910 <exec+0x2f4>
    if(ph.vaddr % PGSIZE != 0)
    8000476a:	17d2                	slli	a5,a5,0x34
    8000476c:	1a079263          	bnez	a5,80004910 <exec+0x2f4>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004770:	e1c42503          	lw	a0,-484(s0)
    80004774:	e89ff0ef          	jal	800045fc <flags2perm>
    80004778:	86aa                	mv	a3,a0
    8000477a:	8626                	mv	a2,s1
    8000477c:	85ca                	mv	a1,s2
    8000477e:	855a                	mv	a0,s6
    80004780:	c3bfc0ef          	jal	800013ba <uvmalloc>
    80004784:	dea43823          	sd	a0,-528(s0)
    80004788:	18050463          	beqz	a0,80004910 <exec+0x2f4>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    8000478c:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004790:	f80987e3          	beqz	s3,8000471e <exec+0x102>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004794:	e2843c03          	ld	s8,-472(s0)
    80004798:	e2042b83          	lw	s7,-480(s0)
  for(i = 0; i < sz; i += PGSIZE){
    8000479c:	4481                	li	s1,0
    8000479e:	b785                	j	800046fe <exec+0xe2>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    800047a0:	4901                	li	s2,0
  iunlockput(ip);
    800047a2:	8552                	mv	a0,s4
    800047a4:	d65fe0ef          	jal	80003508 <iunlockput>
  end_op();
    800047a8:	c86ff0ef          	jal	80003c2e <end_op>
  p = myproc();
    800047ac:	984fd0ef          	jal	80001930 <myproc>
    800047b0:	89aa                	mv	s3,a0
  uint64 oldsz = p->sz;
    800047b2:	04853a83          	ld	s5,72(a0)
  sz = PGROUNDUP(sz);
    800047b6:	6485                	lui	s1,0x1
    800047b8:	14fd                	addi	s1,s1,-1 # fff <_entry-0x7ffff001>
    800047ba:	94ca                	add	s1,s1,s2
    800047bc:	77fd                	lui	a5,0xfffff
    800047be:	8cfd                	and	s1,s1,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    800047c0:	4691                	li	a3,4
    800047c2:	6609                	lui	a2,0x2
    800047c4:	9626                	add	a2,a2,s1
    800047c6:	85a6                	mv	a1,s1
    800047c8:	855a                	mv	a0,s6
    800047ca:	bf1fc0ef          	jal	800013ba <uvmalloc>
    800047ce:	8a2a                	mv	s4,a0
    800047d0:	ed19                	bnez	a0,800047ee <exec+0x1d2>
    proc_freepagetable(pagetable, sz);
    800047d2:	85a6                	mv	a1,s1
    800047d4:	855a                	mv	a0,s6
    800047d6:	a86fd0ef          	jal	80001a5c <proc_freepagetable>
  if(ip){
    800047da:	79be                	ld	s3,488(sp)
    800047dc:	7a1e                	ld	s4,480(sp)
    800047de:	6afe                	ld	s5,472(sp)
    800047e0:	6b5e                	ld	s6,464(sp)
    800047e2:	6bbe                	ld	s7,456(sp)
    800047e4:	6c1e                	ld	s8,448(sp)
    800047e6:	7cfa                	ld	s9,440(sp)
    800047e8:	7d5a                	ld	s10,432(sp)
    800047ea:	7dba                	ld	s11,424(sp)
    800047ec:	bd71                	j	80004688 <exec+0x6c>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    800047ee:	75f9                	lui	a1,0xffffe
    800047f0:	95aa                	add	a1,a1,a0
    800047f2:	855a                	mv	a0,s6
    800047f4:	da3fc0ef          	jal	80001596 <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    800047f8:	7c7d                	lui	s8,0xfffff
    800047fa:	9c52                	add	s8,s8,s4
  for(argc = 0; argv[argc]; argc++) {
    800047fc:	df843783          	ld	a5,-520(s0)
    80004800:	6388                	ld	a0,0(a5)
  sp = sz;
    80004802:	8952                	mv	s2,s4
  for(argc = 0; argv[argc]; argc++) {
    80004804:	4481                	li	s1,0
    ustack[argc] = sp;
    80004806:	e9040c93          	addi	s9,s0,-368
    if(argc >= MAXARG)
    8000480a:	02000d13          	li	s10,32
  for(argc = 0; argv[argc]; argc++) {
    8000480e:	cd21                	beqz	a0,80004866 <exec+0x24a>
    sp -= strlen(argv[argc]) + 1;
    80004810:	ea0fc0ef          	jal	80000eb0 <strlen>
    80004814:	0015079b          	addiw	a5,a0,1
    80004818:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    8000481c:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80004820:	05896163          	bltu	s2,s8,80004862 <exec+0x246>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004824:	df843d83          	ld	s11,-520(s0)
    80004828:	000dbb83          	ld	s7,0(s11)
    8000482c:	855e                	mv	a0,s7
    8000482e:	e82fc0ef          	jal	80000eb0 <strlen>
    80004832:	0015069b          	addiw	a3,a0,1
    80004836:	865e                	mv	a2,s7
    80004838:	85ca                	mv	a1,s2
    8000483a:	855a                	mv	a0,s6
    8000483c:	d85fc0ef          	jal	800015c0 <copyout>
    80004840:	02054163          	bltz	a0,80004862 <exec+0x246>
    ustack[argc] = sp;
    80004844:	00349793          	slli	a5,s1,0x3
    80004848:	97e6                	add	a5,a5,s9
    8000484a:	0127b023          	sd	s2,0(a5) # fffffffffffff000 <end+0xffffffff7ffddee0>
  for(argc = 0; argv[argc]; argc++) {
    8000484e:	0485                	addi	s1,s1,1
    80004850:	008d8793          	addi	a5,s11,8
    80004854:	def43c23          	sd	a5,-520(s0)
    80004858:	008db503          	ld	a0,8(s11)
    8000485c:	c509                	beqz	a0,80004866 <exec+0x24a>
    if(argc >= MAXARG)
    8000485e:	fba499e3          	bne	s1,s10,80004810 <exec+0x1f4>
  sz = sz1;
    80004862:	84d2                	mv	s1,s4
    80004864:	b7bd                	j	800047d2 <exec+0x1b6>
  ustack[argc] = 0;
    80004866:	00349793          	slli	a5,s1,0x3
    8000486a:	f9040713          	addi	a4,s0,-112
    8000486e:	97ba                	add	a5,a5,a4
    80004870:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80004874:	00148693          	addi	a3,s1,1
    80004878:	068e                	slli	a3,a3,0x3
    8000487a:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    8000487e:	ff097913          	andi	s2,s2,-16
  if(sp < stackbase)
    80004882:	ff8960e3          	bltu	s2,s8,80004862 <exec+0x246>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004886:	e9040613          	addi	a2,s0,-368
    8000488a:	85ca                	mv	a1,s2
    8000488c:	855a                	mv	a0,s6
    8000488e:	d33fc0ef          	jal	800015c0 <copyout>
    80004892:	fc0548e3          	bltz	a0,80004862 <exec+0x246>
  p->trapframe->a1 = sp;
    80004896:	0589b783          	ld	a5,88(s3)
    8000489a:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    8000489e:	e0043783          	ld	a5,-512(s0)
    800048a2:	0007c703          	lbu	a4,0(a5)
    800048a6:	cf11                	beqz	a4,800048c2 <exec+0x2a6>
    800048a8:	0785                	addi	a5,a5,1
    if(*s == '/')
    800048aa:	02f00693          	li	a3,47
    800048ae:	a029                	j	800048b8 <exec+0x29c>
  for(last=s=path; *s; s++)
    800048b0:	0785                	addi	a5,a5,1
    800048b2:	fff7c703          	lbu	a4,-1(a5)
    800048b6:	c711                	beqz	a4,800048c2 <exec+0x2a6>
    if(*s == '/')
    800048b8:	fed71ce3          	bne	a4,a3,800048b0 <exec+0x294>
      last = s+1;
    800048bc:	e0f43023          	sd	a5,-512(s0)
    800048c0:	bfc5                	j	800048b0 <exec+0x294>
  safestrcpy(p->name, last, sizeof(p->name));
    800048c2:	4641                	li	a2,16
    800048c4:	e0043583          	ld	a1,-512(s0)
    800048c8:	15898513          	addi	a0,s3,344
    800048cc:	daefc0ef          	jal	80000e7a <safestrcpy>
  oldpagetable = p->pagetable;
    800048d0:	0509b503          	ld	a0,80(s3)
  p->pagetable = pagetable;
    800048d4:	0569b823          	sd	s6,80(s3)
  p->sz = sz;
    800048d8:	0549b423          	sd	s4,72(s3)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    800048dc:	0589b783          	ld	a5,88(s3)
    800048e0:	e6843703          	ld	a4,-408(s0)
    800048e4:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    800048e6:	0589b783          	ld	a5,88(s3)
    800048ea:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    800048ee:	85d6                	mv	a1,s5
    800048f0:	96cfd0ef          	jal	80001a5c <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    800048f4:	0004851b          	sext.w	a0,s1
    800048f8:	79be                	ld	s3,488(sp)
    800048fa:	7a1e                	ld	s4,480(sp)
    800048fc:	6afe                	ld	s5,472(sp)
    800048fe:	6b5e                	ld	s6,464(sp)
    80004900:	6bbe                	ld	s7,456(sp)
    80004902:	6c1e                	ld	s8,448(sp)
    80004904:	7cfa                	ld	s9,440(sp)
    80004906:	7d5a                	ld	s10,432(sp)
    80004908:	7dba                	ld	s11,424(sp)
    8000490a:	b341                	j	8000468a <exec+0x6e>
    8000490c:	6b5e                	ld	s6,464(sp)
    8000490e:	b3bd                	j	8000467c <exec+0x60>
    return -1;
    80004910:	df243823          	sd	s2,-528(s0)
    proc_freepagetable(pagetable, sz);
    80004914:	df043583          	ld	a1,-528(s0)
    80004918:	855a                	mv	a0,s6
    8000491a:	942fd0ef          	jal	80001a5c <proc_freepagetable>
  if(ip){
    8000491e:	79be                	ld	s3,488(sp)
    80004920:	6afe                	ld	s5,472(sp)
    80004922:	6b5e                	ld	s6,464(sp)
    80004924:	6bbe                	ld	s7,456(sp)
    80004926:	6c1e                	ld	s8,448(sp)
    80004928:	7cfa                	ld	s9,440(sp)
    8000492a:	7d5a                	ld	s10,432(sp)
    8000492c:	7dba                	ld	s11,424(sp)
    8000492e:	b3b9                	j	8000467c <exec+0x60>

0000000080004930 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004930:	7179                	addi	sp,sp,-48
    80004932:	f406                	sd	ra,40(sp)
    80004934:	f022                	sd	s0,32(sp)
    80004936:	ec26                	sd	s1,24(sp)
    80004938:	e84a                	sd	s2,16(sp)
    8000493a:	1800                	addi	s0,sp,48
    8000493c:	892e                	mv	s2,a1
    8000493e:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004940:	fdc40593          	addi	a1,s0,-36
    80004944:	e85fd0ef          	jal	800027c8 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80004948:	fdc42703          	lw	a4,-36(s0)
    8000494c:	47bd                	li	a5,15
    8000494e:	02e7e963          	bltu	a5,a4,80004980 <argfd+0x50>
    80004952:	fdffc0ef          	jal	80001930 <myproc>
    80004956:	fdc42703          	lw	a4,-36(s0)
    8000495a:	01a70793          	addi	a5,a4,26
    8000495e:	078e                	slli	a5,a5,0x3
    80004960:	953e                	add	a0,a0,a5
    80004962:	611c                	ld	a5,0(a0)
    80004964:	cf91                	beqz	a5,80004980 <argfd+0x50>
    return -1;
  if(pfd)
    80004966:	00090463          	beqz	s2,8000496e <argfd+0x3e>
    *pfd = fd;
    8000496a:	00e92023          	sw	a4,0(s2)
  if(pf)
    8000496e:	c091                	beqz	s1,80004972 <argfd+0x42>
    *pf = f;
    80004970:	e09c                	sd	a5,0(s1)
  return 0;
    80004972:	4501                	li	a0,0
}
    80004974:	70a2                	ld	ra,40(sp)
    80004976:	7402                	ld	s0,32(sp)
    80004978:	64e2                	ld	s1,24(sp)
    8000497a:	6942                	ld	s2,16(sp)
    8000497c:	6145                	addi	sp,sp,48
    8000497e:	8082                	ret
    return -1;
    80004980:	557d                	li	a0,-1
    80004982:	bfcd                	j	80004974 <argfd+0x44>

0000000080004984 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004984:	1101                	addi	sp,sp,-32
    80004986:	ec06                	sd	ra,24(sp)
    80004988:	e822                	sd	s0,16(sp)
    8000498a:	e426                	sd	s1,8(sp)
    8000498c:	1000                	addi	s0,sp,32
    8000498e:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004990:	fa1fc0ef          	jal	80001930 <myproc>
    80004994:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80004996:	0d050793          	addi	a5,a0,208
    8000499a:	4501                	li	a0,0
    8000499c:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    8000499e:	6398                	ld	a4,0(a5)
    800049a0:	cb19                	beqz	a4,800049b6 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    800049a2:	2505                	addiw	a0,a0,1
    800049a4:	07a1                	addi	a5,a5,8
    800049a6:	fed51ce3          	bne	a0,a3,8000499e <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    800049aa:	557d                	li	a0,-1
}
    800049ac:	60e2                	ld	ra,24(sp)
    800049ae:	6442                	ld	s0,16(sp)
    800049b0:	64a2                	ld	s1,8(sp)
    800049b2:	6105                	addi	sp,sp,32
    800049b4:	8082                	ret
      p->ofile[fd] = f;
    800049b6:	01a50793          	addi	a5,a0,26
    800049ba:	078e                	slli	a5,a5,0x3
    800049bc:	963e                	add	a2,a2,a5
    800049be:	e204                	sd	s1,0(a2)
      return fd;
    800049c0:	b7f5                	j	800049ac <fdalloc+0x28>

00000000800049c2 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    800049c2:	715d                	addi	sp,sp,-80
    800049c4:	e486                	sd	ra,72(sp)
    800049c6:	e0a2                	sd	s0,64(sp)
    800049c8:	fc26                	sd	s1,56(sp)
    800049ca:	f84a                	sd	s2,48(sp)
    800049cc:	f44e                	sd	s3,40(sp)
    800049ce:	f052                	sd	s4,32(sp)
    800049d0:	ec56                	sd	s5,24(sp)
    800049d2:	e85a                	sd	s6,16(sp)
    800049d4:	0880                	addi	s0,sp,80
    800049d6:	892e                	mv	s2,a1
    800049d8:	8a2e                	mv	s4,a1
    800049da:	8ab2                	mv	s5,a2
    800049dc:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    800049de:	fb040593          	addi	a1,s0,-80
    800049e2:	834ff0ef          	jal	80003a16 <nameiparent>
    800049e6:	84aa                	mv	s1,a0
    return 0;
    800049e8:	89aa                	mv	s3,a0
  if((dp = nameiparent(path, name)) == 0)
    800049ea:	cd05                	beqz	a0,80004a22 <create+0x60>

  ilock(dp);
    800049ec:	911fe0ef          	jal	800032fc <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    800049f0:	4601                	li	a2,0
    800049f2:	fb040593          	addi	a1,s0,-80
    800049f6:	8526                	mv	a0,s1
    800049f8:	d69fe0ef          	jal	80003760 <dirlookup>
    800049fc:	89aa                	mv	s3,a0
    800049fe:	c131                	beqz	a0,80004a42 <create+0x80>
    iunlockput(dp);
    80004a00:	8526                	mv	a0,s1
    80004a02:	b07fe0ef          	jal	80003508 <iunlockput>
    ilock(ip);
    80004a06:	854e                	mv	a0,s3
    80004a08:	8f5fe0ef          	jal	800032fc <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004a0c:	4789                	li	a5,2
    80004a0e:	02f91563          	bne	s2,a5,80004a38 <create+0x76>
    80004a12:	0449d783          	lhu	a5,68(s3)
    80004a16:	37f9                	addiw	a5,a5,-2
    80004a18:	17c2                	slli	a5,a5,0x30
    80004a1a:	93c1                	srli	a5,a5,0x30
    80004a1c:	4705                	li	a4,1
    80004a1e:	00f76d63          	bltu	a4,a5,80004a38 <create+0x76>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004a22:	854e                	mv	a0,s3
    80004a24:	60a6                	ld	ra,72(sp)
    80004a26:	6406                	ld	s0,64(sp)
    80004a28:	74e2                	ld	s1,56(sp)
    80004a2a:	7942                	ld	s2,48(sp)
    80004a2c:	79a2                	ld	s3,40(sp)
    80004a2e:	7a02                	ld	s4,32(sp)
    80004a30:	6ae2                	ld	s5,24(sp)
    80004a32:	6b42                	ld	s6,16(sp)
    80004a34:	6161                	addi	sp,sp,80
    80004a36:	8082                	ret
    iunlockput(ip);
    80004a38:	854e                	mv	a0,s3
    80004a3a:	acffe0ef          	jal	80003508 <iunlockput>
    return 0;
    80004a3e:	4981                	li	s3,0
    80004a40:	b7cd                	j	80004a22 <create+0x60>
  if((ip = ialloc(dp->dev, type)) == 0){
    80004a42:	85ca                	mv	a1,s2
    80004a44:	4088                	lw	a0,0(s1)
    80004a46:	f46fe0ef          	jal	8000318c <ialloc>
    80004a4a:	892a                	mv	s2,a0
    80004a4c:	cd15                	beqz	a0,80004a88 <create+0xc6>
  ilock(ip);
    80004a4e:	8affe0ef          	jal	800032fc <ilock>
  ip->major = major;
    80004a52:	05591323          	sh	s5,70(s2)
  ip->minor = minor;
    80004a56:	05691423          	sh	s6,72(s2)
  ip->nlink = 1;
    80004a5a:	4785                	li	a5,1
    80004a5c:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004a60:	854a                	mv	a0,s2
    80004a62:	fe6fe0ef          	jal	80003248 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80004a66:	4705                	li	a4,1
    80004a68:	02ea0463          	beq	s4,a4,80004a90 <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80004a6c:	00492603          	lw	a2,4(s2)
    80004a70:	fb040593          	addi	a1,s0,-80
    80004a74:	8526                	mv	a0,s1
    80004a76:	eddfe0ef          	jal	80003952 <dirlink>
    80004a7a:	06054263          	bltz	a0,80004ade <create+0x11c>
  iunlockput(dp);
    80004a7e:	8526                	mv	a0,s1
    80004a80:	a89fe0ef          	jal	80003508 <iunlockput>
    return 0;
    80004a84:	89ca                	mv	s3,s2
    80004a86:	bf71                	j	80004a22 <create+0x60>
    iunlockput(dp);
    80004a88:	8526                	mv	a0,s1
    80004a8a:	a7ffe0ef          	jal	80003508 <iunlockput>
    return 0;
    80004a8e:	bfdd                	j	80004a84 <create+0xc2>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004a90:	00492603          	lw	a2,4(s2)
    80004a94:	00003597          	auipc	a1,0x3
    80004a98:	b8c58593          	addi	a1,a1,-1140 # 80007620 <etext+0x620>
    80004a9c:	854a                	mv	a0,s2
    80004a9e:	eb5fe0ef          	jal	80003952 <dirlink>
    80004aa2:	02054e63          	bltz	a0,80004ade <create+0x11c>
    80004aa6:	40d0                	lw	a2,4(s1)
    80004aa8:	00003597          	auipc	a1,0x3
    80004aac:	b8058593          	addi	a1,a1,-1152 # 80007628 <etext+0x628>
    80004ab0:	854a                	mv	a0,s2
    80004ab2:	ea1fe0ef          	jal	80003952 <dirlink>
    80004ab6:	02054463          	bltz	a0,80004ade <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    80004aba:	00492603          	lw	a2,4(s2)
    80004abe:	fb040593          	addi	a1,s0,-80
    80004ac2:	8526                	mv	a0,s1
    80004ac4:	e8ffe0ef          	jal	80003952 <dirlink>
    80004ac8:	00054b63          	bltz	a0,80004ade <create+0x11c>
    dp->nlink++;  // for ".."
    80004acc:	04a4d783          	lhu	a5,74(s1)
    80004ad0:	2785                	addiw	a5,a5,1
    80004ad2:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004ad6:	8526                	mv	a0,s1
    80004ad8:	f70fe0ef          	jal	80003248 <iupdate>
    80004adc:	b74d                	j	80004a7e <create+0xbc>
  ip->nlink = 0;
    80004ade:	04091523          	sh	zero,74(s2)
  iupdate(ip);
    80004ae2:	854a                	mv	a0,s2
    80004ae4:	f64fe0ef          	jal	80003248 <iupdate>
  iunlockput(ip);
    80004ae8:	854a                	mv	a0,s2
    80004aea:	a1ffe0ef          	jal	80003508 <iunlockput>
  iunlockput(dp);
    80004aee:	8526                	mv	a0,s1
    80004af0:	a19fe0ef          	jal	80003508 <iunlockput>
  return 0;
    80004af4:	b73d                	j	80004a22 <create+0x60>

0000000080004af6 <sys_dup>:
{
    80004af6:	7179                	addi	sp,sp,-48
    80004af8:	f406                	sd	ra,40(sp)
    80004afa:	f022                	sd	s0,32(sp)
    80004afc:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80004afe:	fd840613          	addi	a2,s0,-40
    80004b02:	4581                	li	a1,0
    80004b04:	4501                	li	a0,0
    80004b06:	e2bff0ef          	jal	80004930 <argfd>
    80004b0a:	02054863          	bltz	a0,80004b3a <sys_dup+0x44>
    80004b0e:	ec26                	sd	s1,24(sp)
    80004b10:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80004b12:	fd843483          	ld	s1,-40(s0)
    80004b16:	8526                	mv	a0,s1
    80004b18:	e6dff0ef          	jal	80004984 <fdalloc>
    80004b1c:	892a                	mv	s2,a0
    80004b1e:	00054c63          	bltz	a0,80004b36 <sys_dup+0x40>
  filedup(f);
    80004b22:	8526                	mv	a0,s1
    80004b24:	c82ff0ef          	jal	80003fa6 <filedup>
  return fd;
    80004b28:	854a                	mv	a0,s2
    80004b2a:	64e2                	ld	s1,24(sp)
    80004b2c:	6942                	ld	s2,16(sp)
}
    80004b2e:	70a2                	ld	ra,40(sp)
    80004b30:	7402                	ld	s0,32(sp)
    80004b32:	6145                	addi	sp,sp,48
    80004b34:	8082                	ret
    80004b36:	64e2                	ld	s1,24(sp)
    80004b38:	6942                	ld	s2,16(sp)
    return -1;
    80004b3a:	557d                	li	a0,-1
    80004b3c:	bfcd                	j	80004b2e <sys_dup+0x38>

0000000080004b3e <sys_read>:
{
    80004b3e:	7179                	addi	sp,sp,-48
    80004b40:	f406                	sd	ra,40(sp)
    80004b42:	f022                	sd	s0,32(sp)
    80004b44:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004b46:	fd840593          	addi	a1,s0,-40
    80004b4a:	4505                	li	a0,1
    80004b4c:	c99fd0ef          	jal	800027e4 <argaddr>
  argint(2, &n);
    80004b50:	fe440593          	addi	a1,s0,-28
    80004b54:	4509                	li	a0,2
    80004b56:	c73fd0ef          	jal	800027c8 <argint>
  if(argfd(0, 0, &f) < 0)
    80004b5a:	fe840613          	addi	a2,s0,-24
    80004b5e:	4581                	li	a1,0
    80004b60:	4501                	li	a0,0
    80004b62:	dcfff0ef          	jal	80004930 <argfd>
    80004b66:	87aa                	mv	a5,a0
    return -1;
    80004b68:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004b6a:	0007ca63          	bltz	a5,80004b7e <sys_read+0x40>
  return fileread(f, p, n);
    80004b6e:	fe442603          	lw	a2,-28(s0)
    80004b72:	fd843583          	ld	a1,-40(s0)
    80004b76:	fe843503          	ld	a0,-24(s0)
    80004b7a:	d96ff0ef          	jal	80004110 <fileread>
}
    80004b7e:	70a2                	ld	ra,40(sp)
    80004b80:	7402                	ld	s0,32(sp)
    80004b82:	6145                	addi	sp,sp,48
    80004b84:	8082                	ret

0000000080004b86 <sys_write>:
{
    80004b86:	7179                	addi	sp,sp,-48
    80004b88:	f406                	sd	ra,40(sp)
    80004b8a:	f022                	sd	s0,32(sp)
    80004b8c:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004b8e:	fd840593          	addi	a1,s0,-40
    80004b92:	4505                	li	a0,1
    80004b94:	c51fd0ef          	jal	800027e4 <argaddr>
  argint(2, &n);
    80004b98:	fe440593          	addi	a1,s0,-28
    80004b9c:	4509                	li	a0,2
    80004b9e:	c2bfd0ef          	jal	800027c8 <argint>
  if(argfd(0, 0, &f) < 0)
    80004ba2:	fe840613          	addi	a2,s0,-24
    80004ba6:	4581                	li	a1,0
    80004ba8:	4501                	li	a0,0
    80004baa:	d87ff0ef          	jal	80004930 <argfd>
    80004bae:	87aa                	mv	a5,a0
    return -1;
    80004bb0:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004bb2:	0007ca63          	bltz	a5,80004bc6 <sys_write+0x40>
  return filewrite(f, p, n);
    80004bb6:	fe442603          	lw	a2,-28(s0)
    80004bba:	fd843583          	ld	a1,-40(s0)
    80004bbe:	fe843503          	ld	a0,-24(s0)
    80004bc2:	e08ff0ef          	jal	800041ca <filewrite>
}
    80004bc6:	70a2                	ld	ra,40(sp)
    80004bc8:	7402                	ld	s0,32(sp)
    80004bca:	6145                	addi	sp,sp,48
    80004bcc:	8082                	ret

0000000080004bce <sys_close>:
{
    80004bce:	1101                	addi	sp,sp,-32
    80004bd0:	ec06                	sd	ra,24(sp)
    80004bd2:	e822                	sd	s0,16(sp)
    80004bd4:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004bd6:	fe040613          	addi	a2,s0,-32
    80004bda:	fec40593          	addi	a1,s0,-20
    80004bde:	4501                	li	a0,0
    80004be0:	d51ff0ef          	jal	80004930 <argfd>
    return -1;
    80004be4:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004be6:	02054063          	bltz	a0,80004c06 <sys_close+0x38>
  myproc()->ofile[fd] = 0;
    80004bea:	d47fc0ef          	jal	80001930 <myproc>
    80004bee:	fec42783          	lw	a5,-20(s0)
    80004bf2:	07e9                	addi	a5,a5,26
    80004bf4:	078e                	slli	a5,a5,0x3
    80004bf6:	953e                	add	a0,a0,a5
    80004bf8:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004bfc:	fe043503          	ld	a0,-32(s0)
    80004c00:	becff0ef          	jal	80003fec <fileclose>
  return 0;
    80004c04:	4781                	li	a5,0
}
    80004c06:	853e                	mv	a0,a5
    80004c08:	60e2                	ld	ra,24(sp)
    80004c0a:	6442                	ld	s0,16(sp)
    80004c0c:	6105                	addi	sp,sp,32
    80004c0e:	8082                	ret

0000000080004c10 <sys_fstat>:
{
    80004c10:	1101                	addi	sp,sp,-32
    80004c12:	ec06                	sd	ra,24(sp)
    80004c14:	e822                	sd	s0,16(sp)
    80004c16:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004c18:	fe040593          	addi	a1,s0,-32
    80004c1c:	4505                	li	a0,1
    80004c1e:	bc7fd0ef          	jal	800027e4 <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004c22:	fe840613          	addi	a2,s0,-24
    80004c26:	4581                	li	a1,0
    80004c28:	4501                	li	a0,0
    80004c2a:	d07ff0ef          	jal	80004930 <argfd>
    80004c2e:	87aa                	mv	a5,a0
    return -1;
    80004c30:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004c32:	0007c863          	bltz	a5,80004c42 <sys_fstat+0x32>
  return filestat(f, st);
    80004c36:	fe043583          	ld	a1,-32(s0)
    80004c3a:	fe843503          	ld	a0,-24(s0)
    80004c3e:	c70ff0ef          	jal	800040ae <filestat>
}
    80004c42:	60e2                	ld	ra,24(sp)
    80004c44:	6442                	ld	s0,16(sp)
    80004c46:	6105                	addi	sp,sp,32
    80004c48:	8082                	ret

0000000080004c4a <sys_link>:
{
    80004c4a:	7169                	addi	sp,sp,-304
    80004c4c:	f606                	sd	ra,296(sp)
    80004c4e:	f222                	sd	s0,288(sp)
    80004c50:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004c52:	08000613          	li	a2,128
    80004c56:	ed040593          	addi	a1,s0,-304
    80004c5a:	4501                	li	a0,0
    80004c5c:	ba5fd0ef          	jal	80002800 <argstr>
    80004c60:	0c054a63          	bltz	a0,80004d34 <sys_link+0xea>
    80004c64:	08000613          	li	a2,128
    80004c68:	f5040593          	addi	a1,s0,-176
    80004c6c:	4505                	li	a0,1
    80004c6e:	b93fd0ef          	jal	80002800 <argstr>
    80004c72:	0c054163          	bltz	a0,80004d34 <sys_link+0xea>
    80004c76:	ee26                	sd	s1,280(sp)
  begin_op();
    80004c78:	f47fe0ef          	jal	80003bbe <begin_op>
  if((ip = namei(old)) == 0){
    80004c7c:	ed040513          	addi	a0,s0,-304
    80004c80:	d7dfe0ef          	jal	800039fc <namei>
    80004c84:	84aa                	mv	s1,a0
    80004c86:	c53d                	beqz	a0,80004cf4 <sys_link+0xaa>
  ilock(ip);
    80004c88:	e74fe0ef          	jal	800032fc <ilock>
  if(ip->type == T_DIR){
    80004c8c:	04449703          	lh	a4,68(s1)
    80004c90:	4785                	li	a5,1
    80004c92:	06f70563          	beq	a4,a5,80004cfc <sys_link+0xb2>
    80004c96:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004c98:	04a4d783          	lhu	a5,74(s1)
    80004c9c:	2785                	addiw	a5,a5,1
    80004c9e:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004ca2:	8526                	mv	a0,s1
    80004ca4:	da4fe0ef          	jal	80003248 <iupdate>
  iunlock(ip);
    80004ca8:	8526                	mv	a0,s1
    80004caa:	f00fe0ef          	jal	800033aa <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80004cae:	fd040593          	addi	a1,s0,-48
    80004cb2:	f5040513          	addi	a0,s0,-176
    80004cb6:	d61fe0ef          	jal	80003a16 <nameiparent>
    80004cba:	892a                	mv	s2,a0
    80004cbc:	c931                	beqz	a0,80004d10 <sys_link+0xc6>
  ilock(dp);
    80004cbe:	e3efe0ef          	jal	800032fc <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80004cc2:	854a                	mv	a0,s2
    80004cc4:	00092703          	lw	a4,0(s2)
    80004cc8:	409c                	lw	a5,0(s1)
    80004cca:	04f71063          	bne	a4,a5,80004d0a <sys_link+0xc0>
    80004cce:	40d0                	lw	a2,4(s1)
    80004cd0:	fd040593          	addi	a1,s0,-48
    80004cd4:	c7ffe0ef          	jal	80003952 <dirlink>
    80004cd8:	02054963          	bltz	a0,80004d0a <sys_link+0xc0>
  iunlockput(dp);
    80004cdc:	854a                	mv	a0,s2
    80004cde:	82bfe0ef          	jal	80003508 <iunlockput>
  iput(ip);
    80004ce2:	8526                	mv	a0,s1
    80004ce4:	f9afe0ef          	jal	8000347e <iput>
  end_op();
    80004ce8:	f47fe0ef          	jal	80003c2e <end_op>
  return 0;
    80004cec:	4501                	li	a0,0
    80004cee:	64f2                	ld	s1,280(sp)
    80004cf0:	6952                	ld	s2,272(sp)
    80004cf2:	a091                	j	80004d36 <sys_link+0xec>
    end_op();
    80004cf4:	f3bfe0ef          	jal	80003c2e <end_op>
    return -1;
    80004cf8:	64f2                	ld	s1,280(sp)
    80004cfa:	a82d                	j	80004d34 <sys_link+0xea>
    iunlockput(ip);
    80004cfc:	8526                	mv	a0,s1
    80004cfe:	80bfe0ef          	jal	80003508 <iunlockput>
    end_op();
    80004d02:	f2dfe0ef          	jal	80003c2e <end_op>
    return -1;
    80004d06:	64f2                	ld	s1,280(sp)
    80004d08:	a035                	j	80004d34 <sys_link+0xea>
    iunlockput(dp);
    80004d0a:	854a                	mv	a0,s2
    80004d0c:	ffcfe0ef          	jal	80003508 <iunlockput>
  ilock(ip);
    80004d10:	8526                	mv	a0,s1
    80004d12:	deafe0ef          	jal	800032fc <ilock>
  ip->nlink--;
    80004d16:	04a4d783          	lhu	a5,74(s1)
    80004d1a:	37fd                	addiw	a5,a5,-1
    80004d1c:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004d20:	8526                	mv	a0,s1
    80004d22:	d26fe0ef          	jal	80003248 <iupdate>
  iunlockput(ip);
    80004d26:	8526                	mv	a0,s1
    80004d28:	fe0fe0ef          	jal	80003508 <iunlockput>
  end_op();
    80004d2c:	f03fe0ef          	jal	80003c2e <end_op>
  return -1;
    80004d30:	64f2                	ld	s1,280(sp)
    80004d32:	6952                	ld	s2,272(sp)
    return -1;
    80004d34:	557d                	li	a0,-1
}
    80004d36:	70b2                	ld	ra,296(sp)
    80004d38:	7412                	ld	s0,288(sp)
    80004d3a:	6155                	addi	sp,sp,304
    80004d3c:	8082                	ret

0000000080004d3e <sys_unlink>:
{
    80004d3e:	7151                	addi	sp,sp,-240
    80004d40:	f586                	sd	ra,232(sp)
    80004d42:	f1a2                	sd	s0,224(sp)
    80004d44:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004d46:	08000613          	li	a2,128
    80004d4a:	f3040593          	addi	a1,s0,-208
    80004d4e:	4501                	li	a0,0
    80004d50:	ab1fd0ef          	jal	80002800 <argstr>
    80004d54:	14054763          	bltz	a0,80004ea2 <sys_unlink+0x164>
    80004d58:	eda6                	sd	s1,216(sp)
  begin_op();
    80004d5a:	e65fe0ef          	jal	80003bbe <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004d5e:	fb040593          	addi	a1,s0,-80
    80004d62:	f3040513          	addi	a0,s0,-208
    80004d66:	cb1fe0ef          	jal	80003a16 <nameiparent>
    80004d6a:	84aa                	mv	s1,a0
    80004d6c:	c955                	beqz	a0,80004e20 <sys_unlink+0xe2>
  ilock(dp);
    80004d6e:	d8efe0ef          	jal	800032fc <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004d72:	00003597          	auipc	a1,0x3
    80004d76:	8ae58593          	addi	a1,a1,-1874 # 80007620 <etext+0x620>
    80004d7a:	fb040513          	addi	a0,s0,-80
    80004d7e:	9cdfe0ef          	jal	8000374a <namecmp>
    80004d82:	10050a63          	beqz	a0,80004e96 <sys_unlink+0x158>
    80004d86:	00003597          	auipc	a1,0x3
    80004d8a:	8a258593          	addi	a1,a1,-1886 # 80007628 <etext+0x628>
    80004d8e:	fb040513          	addi	a0,s0,-80
    80004d92:	9b9fe0ef          	jal	8000374a <namecmp>
    80004d96:	10050063          	beqz	a0,80004e96 <sys_unlink+0x158>
    80004d9a:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    80004d9c:	f2c40613          	addi	a2,s0,-212
    80004da0:	fb040593          	addi	a1,s0,-80
    80004da4:	8526                	mv	a0,s1
    80004da6:	9bbfe0ef          	jal	80003760 <dirlookup>
    80004daa:	892a                	mv	s2,a0
    80004dac:	0e050463          	beqz	a0,80004e94 <sys_unlink+0x156>
    80004db0:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    80004db2:	d4afe0ef          	jal	800032fc <ilock>
  if(ip->nlink < 1)
    80004db6:	04a91783          	lh	a5,74(s2)
    80004dba:	06f05763          	blez	a5,80004e28 <sys_unlink+0xea>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80004dbe:	04491703          	lh	a4,68(s2)
    80004dc2:	4785                	li	a5,1
    80004dc4:	06f70863          	beq	a4,a5,80004e34 <sys_unlink+0xf6>
  memset(&de, 0, sizeof(de));
    80004dc8:	fc040993          	addi	s3,s0,-64
    80004dcc:	4641                	li	a2,16
    80004dce:	4581                	li	a1,0
    80004dd0:	854e                	mv	a0,s3
    80004dd2:	f5ffb0ef          	jal	80000d30 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004dd6:	4741                	li	a4,16
    80004dd8:	f2c42683          	lw	a3,-212(s0)
    80004ddc:	864e                	mv	a2,s3
    80004dde:	4581                	li	a1,0
    80004de0:	8526                	mv	a0,s1
    80004de2:	867fe0ef          	jal	80003648 <writei>
    80004de6:	47c1                	li	a5,16
    80004de8:	08f51763          	bne	a0,a5,80004e76 <sys_unlink+0x138>
  if(ip->type == T_DIR){
    80004dec:	04491703          	lh	a4,68(s2)
    80004df0:	4785                	li	a5,1
    80004df2:	08f70863          	beq	a4,a5,80004e82 <sys_unlink+0x144>
  iunlockput(dp);
    80004df6:	8526                	mv	a0,s1
    80004df8:	f10fe0ef          	jal	80003508 <iunlockput>
  ip->nlink--;
    80004dfc:	04a95783          	lhu	a5,74(s2)
    80004e00:	37fd                	addiw	a5,a5,-1
    80004e02:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004e06:	854a                	mv	a0,s2
    80004e08:	c40fe0ef          	jal	80003248 <iupdate>
  iunlockput(ip);
    80004e0c:	854a                	mv	a0,s2
    80004e0e:	efafe0ef          	jal	80003508 <iunlockput>
  end_op();
    80004e12:	e1dfe0ef          	jal	80003c2e <end_op>
  return 0;
    80004e16:	4501                	li	a0,0
    80004e18:	64ee                	ld	s1,216(sp)
    80004e1a:	694e                	ld	s2,208(sp)
    80004e1c:	69ae                	ld	s3,200(sp)
    80004e1e:	a059                	j	80004ea4 <sys_unlink+0x166>
    end_op();
    80004e20:	e0ffe0ef          	jal	80003c2e <end_op>
    return -1;
    80004e24:	64ee                	ld	s1,216(sp)
    80004e26:	a8b5                	j	80004ea2 <sys_unlink+0x164>
    panic("unlink: nlink < 1");
    80004e28:	00003517          	auipc	a0,0x3
    80004e2c:	80850513          	addi	a0,a0,-2040 # 80007630 <etext+0x630>
    80004e30:	9c1fb0ef          	jal	800007f0 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004e34:	04c92703          	lw	a4,76(s2)
    80004e38:	02000793          	li	a5,32
    80004e3c:	f8e7f6e3          	bgeu	a5,a4,80004dc8 <sys_unlink+0x8a>
    80004e40:	89be                	mv	s3,a5
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004e42:	4741                	li	a4,16
    80004e44:	86ce                	mv	a3,s3
    80004e46:	f1840613          	addi	a2,s0,-232
    80004e4a:	4581                	li	a1,0
    80004e4c:	854a                	mv	a0,s2
    80004e4e:	f08fe0ef          	jal	80003556 <readi>
    80004e52:	47c1                	li	a5,16
    80004e54:	00f51b63          	bne	a0,a5,80004e6a <sys_unlink+0x12c>
    if(de.inum != 0)
    80004e58:	f1845783          	lhu	a5,-232(s0)
    80004e5c:	eba1                	bnez	a5,80004eac <sys_unlink+0x16e>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004e5e:	29c1                	addiw	s3,s3,16
    80004e60:	04c92783          	lw	a5,76(s2)
    80004e64:	fcf9efe3          	bltu	s3,a5,80004e42 <sys_unlink+0x104>
    80004e68:	b785                	j	80004dc8 <sys_unlink+0x8a>
      panic("isdirempty: readi");
    80004e6a:	00002517          	auipc	a0,0x2
    80004e6e:	7de50513          	addi	a0,a0,2014 # 80007648 <etext+0x648>
    80004e72:	97ffb0ef          	jal	800007f0 <panic>
    panic("unlink: writei");
    80004e76:	00002517          	auipc	a0,0x2
    80004e7a:	7ea50513          	addi	a0,a0,2026 # 80007660 <etext+0x660>
    80004e7e:	973fb0ef          	jal	800007f0 <panic>
    dp->nlink--;
    80004e82:	04a4d783          	lhu	a5,74(s1)
    80004e86:	37fd                	addiw	a5,a5,-1
    80004e88:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004e8c:	8526                	mv	a0,s1
    80004e8e:	bbafe0ef          	jal	80003248 <iupdate>
    80004e92:	b795                	j	80004df6 <sys_unlink+0xb8>
    80004e94:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    80004e96:	8526                	mv	a0,s1
    80004e98:	e70fe0ef          	jal	80003508 <iunlockput>
  end_op();
    80004e9c:	d93fe0ef          	jal	80003c2e <end_op>
  return -1;
    80004ea0:	64ee                	ld	s1,216(sp)
    return -1;
    80004ea2:	557d                	li	a0,-1
}
    80004ea4:	70ae                	ld	ra,232(sp)
    80004ea6:	740e                	ld	s0,224(sp)
    80004ea8:	616d                	addi	sp,sp,240
    80004eaa:	8082                	ret
    iunlockput(ip);
    80004eac:	854a                	mv	a0,s2
    80004eae:	e5afe0ef          	jal	80003508 <iunlockput>
    goto bad;
    80004eb2:	694e                	ld	s2,208(sp)
    80004eb4:	69ae                	ld	s3,200(sp)
    80004eb6:	b7c5                	j	80004e96 <sys_unlink+0x158>

0000000080004eb8 <sys_open>:

uint64
sys_open(void)
{
    80004eb8:	7131                	addi	sp,sp,-192
    80004eba:	fd06                	sd	ra,184(sp)
    80004ebc:	f922                	sd	s0,176(sp)
    80004ebe:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80004ec0:	f4c40593          	addi	a1,s0,-180
    80004ec4:	4505                	li	a0,1
    80004ec6:	903fd0ef          	jal	800027c8 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004eca:	08000613          	li	a2,128
    80004ece:	f5040593          	addi	a1,s0,-176
    80004ed2:	4501                	li	a0,0
    80004ed4:	92dfd0ef          	jal	80002800 <argstr>
    80004ed8:	10054563          	bltz	a0,80004fe2 <sys_open+0x12a>
    80004edc:	f526                	sd	s1,168(sp)
    return -1;

  begin_op();
    80004ede:	ce1fe0ef          	jal	80003bbe <begin_op>

  if(omode & O_CREATE){
    80004ee2:	f4c42783          	lw	a5,-180(s0)
    80004ee6:	2007f793          	andi	a5,a5,512
    80004eea:	cfd9                	beqz	a5,80004f88 <sys_open+0xd0>
    ip = create(path, T_FILE, 0, 0);
    80004eec:	4681                	li	a3,0
    80004eee:	4601                	li	a2,0
    80004ef0:	4589                	li	a1,2
    80004ef2:	f5040513          	addi	a0,s0,-176
    80004ef6:	acdff0ef          	jal	800049c2 <create>
    80004efa:	84aa                	mv	s1,a0
    if(ip == 0){
    80004efc:	c151                	beqz	a0,80004f80 <sys_open+0xc8>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    80004efe:	04449703          	lh	a4,68(s1)
    80004f02:	478d                	li	a5,3
    80004f04:	00f71763          	bne	a4,a5,80004f12 <sys_open+0x5a>
    80004f08:	0464d703          	lhu	a4,70(s1)
    80004f0c:	47a5                	li	a5,9
    80004f0e:	0ae7e863          	bltu	a5,a4,80004fbe <sys_open+0x106>
    80004f12:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80004f14:	834ff0ef          	jal	80003f48 <filealloc>
    80004f18:	892a                	mv	s2,a0
    80004f1a:	cd4d                	beqz	a0,80004fd4 <sys_open+0x11c>
    80004f1c:	ed4e                	sd	s3,152(sp)
    80004f1e:	a67ff0ef          	jal	80004984 <fdalloc>
    80004f22:	89aa                	mv	s3,a0
    80004f24:	0a054463          	bltz	a0,80004fcc <sys_open+0x114>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80004f28:	04449703          	lh	a4,68(s1)
    80004f2c:	478d                	li	a5,3
    80004f2e:	0af70f63          	beq	a4,a5,80004fec <sys_open+0x134>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80004f32:	4789                	li	a5,2
    80004f34:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    80004f38:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    80004f3c:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    80004f40:	f4c42783          	lw	a5,-180(s0)
    80004f44:	0017f713          	andi	a4,a5,1
    80004f48:	00174713          	xori	a4,a4,1
    80004f4c:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    80004f50:	0037f713          	andi	a4,a5,3
    80004f54:	00e03733          	snez	a4,a4
    80004f58:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80004f5c:	4007f793          	andi	a5,a5,1024
    80004f60:	c791                	beqz	a5,80004f6c <sys_open+0xb4>
    80004f62:	04449703          	lh	a4,68(s1)
    80004f66:	4789                	li	a5,2
    80004f68:	08f70963          	beq	a4,a5,80004ffa <sys_open+0x142>
    itrunc(ip);
  }

  iunlock(ip);
    80004f6c:	8526                	mv	a0,s1
    80004f6e:	c3cfe0ef          	jal	800033aa <iunlock>
  end_op();
    80004f72:	cbdfe0ef          	jal	80003c2e <end_op>

  return fd;
    80004f76:	854e                	mv	a0,s3
    80004f78:	74aa                	ld	s1,168(sp)
    80004f7a:	790a                	ld	s2,160(sp)
    80004f7c:	69ea                	ld	s3,152(sp)
    80004f7e:	a09d                	j	80004fe4 <sys_open+0x12c>
      end_op();
    80004f80:	caffe0ef          	jal	80003c2e <end_op>
      return -1;
    80004f84:	74aa                	ld	s1,168(sp)
    80004f86:	a8b1                	j	80004fe2 <sys_open+0x12a>
    if((ip = namei(path)) == 0){
    80004f88:	f5040513          	addi	a0,s0,-176
    80004f8c:	a71fe0ef          	jal	800039fc <namei>
    80004f90:	84aa                	mv	s1,a0
    80004f92:	c115                	beqz	a0,80004fb6 <sys_open+0xfe>
    ilock(ip);
    80004f94:	b68fe0ef          	jal	800032fc <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    80004f98:	04449703          	lh	a4,68(s1)
    80004f9c:	4785                	li	a5,1
    80004f9e:	f6f710e3          	bne	a4,a5,80004efe <sys_open+0x46>
    80004fa2:	f4c42783          	lw	a5,-180(s0)
    80004fa6:	d7b5                	beqz	a5,80004f12 <sys_open+0x5a>
      iunlockput(ip);
    80004fa8:	8526                	mv	a0,s1
    80004faa:	d5efe0ef          	jal	80003508 <iunlockput>
      end_op();
    80004fae:	c81fe0ef          	jal	80003c2e <end_op>
      return -1;
    80004fb2:	74aa                	ld	s1,168(sp)
    80004fb4:	a03d                	j	80004fe2 <sys_open+0x12a>
      end_op();
    80004fb6:	c79fe0ef          	jal	80003c2e <end_op>
      return -1;
    80004fba:	74aa                	ld	s1,168(sp)
    80004fbc:	a01d                	j	80004fe2 <sys_open+0x12a>
    iunlockput(ip);
    80004fbe:	8526                	mv	a0,s1
    80004fc0:	d48fe0ef          	jal	80003508 <iunlockput>
    end_op();
    80004fc4:	c6bfe0ef          	jal	80003c2e <end_op>
    return -1;
    80004fc8:	74aa                	ld	s1,168(sp)
    80004fca:	a821                	j	80004fe2 <sys_open+0x12a>
      fileclose(f);
    80004fcc:	854a                	mv	a0,s2
    80004fce:	81eff0ef          	jal	80003fec <fileclose>
    80004fd2:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80004fd4:	8526                	mv	a0,s1
    80004fd6:	d32fe0ef          	jal	80003508 <iunlockput>
    end_op();
    80004fda:	c55fe0ef          	jal	80003c2e <end_op>
    return -1;
    80004fde:	74aa                	ld	s1,168(sp)
    80004fe0:	790a                	ld	s2,160(sp)
    return -1;
    80004fe2:	557d                	li	a0,-1
}
    80004fe4:	70ea                	ld	ra,184(sp)
    80004fe6:	744a                	ld	s0,176(sp)
    80004fe8:	6129                	addi	sp,sp,192
    80004fea:	8082                	ret
    f->type = FD_DEVICE;
    80004fec:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    80004ff0:	04649783          	lh	a5,70(s1)
    80004ff4:	02f91223          	sh	a5,36(s2)
    80004ff8:	b791                	j	80004f3c <sys_open+0x84>
    itrunc(ip);
    80004ffa:	8526                	mv	a0,s1
    80004ffc:	beefe0ef          	jal	800033ea <itrunc>
    80005000:	b7b5                	j	80004f6c <sys_open+0xb4>

0000000080005002 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80005002:	7175                	addi	sp,sp,-144
    80005004:	e506                	sd	ra,136(sp)
    80005006:	e122                	sd	s0,128(sp)
    80005008:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    8000500a:	bb5fe0ef          	jal	80003bbe <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    8000500e:	08000613          	li	a2,128
    80005012:	f7040593          	addi	a1,s0,-144
    80005016:	4501                	li	a0,0
    80005018:	fe8fd0ef          	jal	80002800 <argstr>
    8000501c:	02054363          	bltz	a0,80005042 <sys_mkdir+0x40>
    80005020:	4681                	li	a3,0
    80005022:	4601                	li	a2,0
    80005024:	4585                	li	a1,1
    80005026:	f7040513          	addi	a0,s0,-144
    8000502a:	999ff0ef          	jal	800049c2 <create>
    8000502e:	c911                	beqz	a0,80005042 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005030:	cd8fe0ef          	jal	80003508 <iunlockput>
  end_op();
    80005034:	bfbfe0ef          	jal	80003c2e <end_op>
  return 0;
    80005038:	4501                	li	a0,0
}
    8000503a:	60aa                	ld	ra,136(sp)
    8000503c:	640a                	ld	s0,128(sp)
    8000503e:	6149                	addi	sp,sp,144
    80005040:	8082                	ret
    end_op();
    80005042:	bedfe0ef          	jal	80003c2e <end_op>
    return -1;
    80005046:	557d                	li	a0,-1
    80005048:	bfcd                	j	8000503a <sys_mkdir+0x38>

000000008000504a <sys_mknod>:

uint64
sys_mknod(void)
{
    8000504a:	7135                	addi	sp,sp,-160
    8000504c:	ed06                	sd	ra,152(sp)
    8000504e:	e922                	sd	s0,144(sp)
    80005050:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80005052:	b6dfe0ef          	jal	80003bbe <begin_op>
  argint(1, &major);
    80005056:	f6c40593          	addi	a1,s0,-148
    8000505a:	4505                	li	a0,1
    8000505c:	f6cfd0ef          	jal	800027c8 <argint>
  argint(2, &minor);
    80005060:	f6840593          	addi	a1,s0,-152
    80005064:	4509                	li	a0,2
    80005066:	f62fd0ef          	jal	800027c8 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    8000506a:	08000613          	li	a2,128
    8000506e:	f7040593          	addi	a1,s0,-144
    80005072:	4501                	li	a0,0
    80005074:	f8cfd0ef          	jal	80002800 <argstr>
    80005078:	02054563          	bltz	a0,800050a2 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    8000507c:	f6841683          	lh	a3,-152(s0)
    80005080:	f6c41603          	lh	a2,-148(s0)
    80005084:	458d                	li	a1,3
    80005086:	f7040513          	addi	a0,s0,-144
    8000508a:	939ff0ef          	jal	800049c2 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    8000508e:	c911                	beqz	a0,800050a2 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005090:	c78fe0ef          	jal	80003508 <iunlockput>
  end_op();
    80005094:	b9bfe0ef          	jal	80003c2e <end_op>
  return 0;
    80005098:	4501                	li	a0,0
}
    8000509a:	60ea                	ld	ra,152(sp)
    8000509c:	644a                	ld	s0,144(sp)
    8000509e:	610d                	addi	sp,sp,160
    800050a0:	8082                	ret
    end_op();
    800050a2:	b8dfe0ef          	jal	80003c2e <end_op>
    return -1;
    800050a6:	557d                	li	a0,-1
    800050a8:	bfcd                	j	8000509a <sys_mknod+0x50>

00000000800050aa <sys_chdir>:

uint64
sys_chdir(void)
{
    800050aa:	7135                	addi	sp,sp,-160
    800050ac:	ed06                	sd	ra,152(sp)
    800050ae:	e922                	sd	s0,144(sp)
    800050b0:	e14a                	sd	s2,128(sp)
    800050b2:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    800050b4:	87dfc0ef          	jal	80001930 <myproc>
    800050b8:	892a                	mv	s2,a0
  
  begin_op();
    800050ba:	b05fe0ef          	jal	80003bbe <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    800050be:	08000613          	li	a2,128
    800050c2:	f6040593          	addi	a1,s0,-160
    800050c6:	4501                	li	a0,0
    800050c8:	f38fd0ef          	jal	80002800 <argstr>
    800050cc:	02054f63          	bltz	a0,8000510a <sys_chdir+0x60>
    800050d0:	e526                	sd	s1,136(sp)
    800050d2:	f6040513          	addi	a0,s0,-160
    800050d6:	927fe0ef          	jal	800039fc <namei>
    800050da:	84aa                	mv	s1,a0
    800050dc:	c515                	beqz	a0,80005108 <sys_chdir+0x5e>
    end_op();
    return -1;
  }
  ilock(ip);
    800050de:	a1efe0ef          	jal	800032fc <ilock>
  if(ip->type != T_DIR){
    800050e2:	04449703          	lh	a4,68(s1)
    800050e6:	4785                	li	a5,1
    800050e8:	02f71963          	bne	a4,a5,8000511a <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    800050ec:	8526                	mv	a0,s1
    800050ee:	abcfe0ef          	jal	800033aa <iunlock>
  iput(p->cwd);
    800050f2:	15093503          	ld	a0,336(s2)
    800050f6:	b88fe0ef          	jal	8000347e <iput>
  end_op();
    800050fa:	b35fe0ef          	jal	80003c2e <end_op>
  p->cwd = ip;
    800050fe:	14993823          	sd	s1,336(s2)
  return 0;
    80005102:	4501                	li	a0,0
    80005104:	64aa                	ld	s1,136(sp)
    80005106:	a029                	j	80005110 <sys_chdir+0x66>
    80005108:	64aa                	ld	s1,136(sp)
    end_op();
    8000510a:	b25fe0ef          	jal	80003c2e <end_op>
    return -1;
    8000510e:	557d                	li	a0,-1
}
    80005110:	60ea                	ld	ra,152(sp)
    80005112:	644a                	ld	s0,144(sp)
    80005114:	690a                	ld	s2,128(sp)
    80005116:	610d                	addi	sp,sp,160
    80005118:	8082                	ret
    iunlockput(ip);
    8000511a:	8526                	mv	a0,s1
    8000511c:	becfe0ef          	jal	80003508 <iunlockput>
    end_op();
    80005120:	b0ffe0ef          	jal	80003c2e <end_op>
    return -1;
    80005124:	64aa                	ld	s1,136(sp)
    80005126:	b7e5                	j	8000510e <sys_chdir+0x64>

0000000080005128 <sys_exec>:

uint64
sys_exec(void)
{
    80005128:	7105                	addi	sp,sp,-480
    8000512a:	ef86                	sd	ra,472(sp)
    8000512c:	eba2                	sd	s0,464(sp)
    8000512e:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80005130:	e2840593          	addi	a1,s0,-472
    80005134:	4505                	li	a0,1
    80005136:	eaefd0ef          	jal	800027e4 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    8000513a:	08000613          	li	a2,128
    8000513e:	f3040593          	addi	a1,s0,-208
    80005142:	4501                	li	a0,0
    80005144:	ebcfd0ef          	jal	80002800 <argstr>
    80005148:	0c054e63          	bltz	a0,80005224 <sys_exec+0xfc>
    8000514c:	e7a6                	sd	s1,456(sp)
    8000514e:	e3ca                	sd	s2,448(sp)
    80005150:	ff4e                	sd	s3,440(sp)
    80005152:	fb52                	sd	s4,432(sp)
    80005154:	f756                	sd	s5,424(sp)
    80005156:	f35a                	sd	s6,416(sp)
    80005158:	ef5e                	sd	s7,408(sp)
    return -1;
  }
  memset(argv, 0, sizeof(argv));
    8000515a:	e3040a13          	addi	s4,s0,-464
    8000515e:	10000613          	li	a2,256
    80005162:	4581                	li	a1,0
    80005164:	8552                	mv	a0,s4
    80005166:	bcbfb0ef          	jal	80000d30 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    8000516a:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    8000516c:	89d2                	mv	s3,s4
    8000516e:	4901                	li	s2,0
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    80005170:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    80005174:	6b05                	lui	s6,0x1
    if(i >= NELEM(argv)){
    80005176:	02000b93          	li	s7,32
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    8000517a:	00391513          	slli	a0,s2,0x3
    8000517e:	85d6                	mv	a1,s5
    80005180:	e2843783          	ld	a5,-472(s0)
    80005184:	953e                	add	a0,a0,a5
    80005186:	dbcfd0ef          	jal	80002742 <fetchaddr>
    8000518a:	02054663          	bltz	a0,800051b6 <sys_exec+0x8e>
    if(uarg == 0){
    8000518e:	e2043783          	ld	a5,-480(s0)
    80005192:	c3b9                	beqz	a5,800051d8 <sys_exec+0xb0>
    argv[i] = kalloc();
    80005194:	9edfb0ef          	jal	80000b80 <kalloc>
    80005198:	85aa                	mv	a1,a0
    8000519a:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    8000519e:	cd01                	beqz	a0,800051b6 <sys_exec+0x8e>
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800051a0:	865a                	mv	a2,s6
    800051a2:	e2043503          	ld	a0,-480(s0)
    800051a6:	de2fd0ef          	jal	80002788 <fetchstr>
    800051aa:	00054663          	bltz	a0,800051b6 <sys_exec+0x8e>
    if(i >= NELEM(argv)){
    800051ae:	0905                	addi	s2,s2,1
    800051b0:	09a1                	addi	s3,s3,8
    800051b2:	fd7914e3          	bne	s2,s7,8000517a <sys_exec+0x52>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800051b6:	100a0a13          	addi	s4,s4,256
    800051ba:	6088                	ld	a0,0(s1)
    800051bc:	cd29                	beqz	a0,80005216 <sys_exec+0xee>
    kfree(argv[i]);
    800051be:	8dbfb0ef          	jal	80000a98 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800051c2:	04a1                	addi	s1,s1,8
    800051c4:	ff449be3          	bne	s1,s4,800051ba <sys_exec+0x92>
    800051c8:	64be                	ld	s1,456(sp)
    800051ca:	691e                	ld	s2,448(sp)
    800051cc:	79fa                	ld	s3,440(sp)
    800051ce:	7a5a                	ld	s4,432(sp)
    800051d0:	7aba                	ld	s5,424(sp)
    800051d2:	7b1a                	ld	s6,416(sp)
    800051d4:	6bfa                	ld	s7,408(sp)
    800051d6:	a0b9                	j	80005224 <sys_exec+0xfc>
      argv[i] = 0;
    800051d8:	0009079b          	sext.w	a5,s2
    800051dc:	e3040593          	addi	a1,s0,-464
    800051e0:	078e                	slli	a5,a5,0x3
    800051e2:	97ae                	add	a5,a5,a1
    800051e4:	0007b023          	sd	zero,0(a5)
  int ret = exec(path, argv);
    800051e8:	f3040513          	addi	a0,s0,-208
    800051ec:	c30ff0ef          	jal	8000461c <exec>
    800051f0:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800051f2:	100a0a13          	addi	s4,s4,256
    800051f6:	6088                	ld	a0,0(s1)
    800051f8:	c511                	beqz	a0,80005204 <sys_exec+0xdc>
    kfree(argv[i]);
    800051fa:	89ffb0ef          	jal	80000a98 <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800051fe:	04a1                	addi	s1,s1,8
    80005200:	ff449be3          	bne	s1,s4,800051f6 <sys_exec+0xce>
  return ret;
    80005204:	854a                	mv	a0,s2
    80005206:	64be                	ld	s1,456(sp)
    80005208:	691e                	ld	s2,448(sp)
    8000520a:	79fa                	ld	s3,440(sp)
    8000520c:	7a5a                	ld	s4,432(sp)
    8000520e:	7aba                	ld	s5,424(sp)
    80005210:	7b1a                	ld	s6,416(sp)
    80005212:	6bfa                	ld	s7,408(sp)
    80005214:	a809                	j	80005226 <sys_exec+0xfe>
    80005216:	64be                	ld	s1,456(sp)
    80005218:	691e                	ld	s2,448(sp)
    8000521a:	79fa                	ld	s3,440(sp)
    8000521c:	7a5a                	ld	s4,432(sp)
    8000521e:	7aba                	ld	s5,424(sp)
    80005220:	7b1a                	ld	s6,416(sp)
    80005222:	6bfa                	ld	s7,408(sp)
    return -1;
    80005224:	557d                	li	a0,-1
  return -1;
}
    80005226:	60fe                	ld	ra,472(sp)
    80005228:	645e                	ld	s0,464(sp)
    8000522a:	613d                	addi	sp,sp,480
    8000522c:	8082                	ret

000000008000522e <sys_pipe>:

uint64
sys_pipe(void)
{
    8000522e:	7139                	addi	sp,sp,-64
    80005230:	fc06                	sd	ra,56(sp)
    80005232:	f822                	sd	s0,48(sp)
    80005234:	f426                	sd	s1,40(sp)
    80005236:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80005238:	ef8fc0ef          	jal	80001930 <myproc>
    8000523c:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    8000523e:	fd840593          	addi	a1,s0,-40
    80005242:	4501                	li	a0,0
    80005244:	da0fd0ef          	jal	800027e4 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80005248:	fc840593          	addi	a1,s0,-56
    8000524c:	fd040513          	addi	a0,s0,-48
    80005250:	8aaff0ef          	jal	800042fa <pipealloc>
    80005254:	0a054463          	bltz	a0,800052fc <sys_pipe+0xce>
    return -1;
  fd0 = -1;
    80005258:	57fd                	li	a5,-1
    8000525a:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    8000525e:	fd043503          	ld	a0,-48(s0)
    80005262:	f22ff0ef          	jal	80004984 <fdalloc>
    80005266:	fca42223          	sw	a0,-60(s0)
    8000526a:	08054163          	bltz	a0,800052ec <sys_pipe+0xbe>
    8000526e:	fc843503          	ld	a0,-56(s0)
    80005272:	f12ff0ef          	jal	80004984 <fdalloc>
    80005276:	fca42023          	sw	a0,-64(s0)
    8000527a:	06054063          	bltz	a0,800052da <sys_pipe+0xac>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    8000527e:	4691                	li	a3,4
    80005280:	fc440613          	addi	a2,s0,-60
    80005284:	fd843583          	ld	a1,-40(s0)
    80005288:	68a8                	ld	a0,80(s1)
    8000528a:	b36fc0ef          	jal	800015c0 <copyout>
    8000528e:	00054f63          	bltz	a0,800052ac <sys_pipe+0x7e>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    80005292:	4691                	li	a3,4
    80005294:	fc040613          	addi	a2,s0,-64
    80005298:	fd843583          	ld	a1,-40(s0)
    8000529c:	95b6                	add	a1,a1,a3
    8000529e:	68a8                	ld	a0,80(s1)
    800052a0:	b20fc0ef          	jal	800015c0 <copyout>
    800052a4:	87aa                	mv	a5,a0
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    800052a6:	4501                	li	a0,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800052a8:	0407db63          	bgez	a5,800052fe <sys_pipe+0xd0>
    p->ofile[fd0] = 0;
    800052ac:	fc442783          	lw	a5,-60(s0)
    800052b0:	07e9                	addi	a5,a5,26
    800052b2:	078e                	slli	a5,a5,0x3
    800052b4:	97a6                	add	a5,a5,s1
    800052b6:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    800052ba:	fc042783          	lw	a5,-64(s0)
    800052be:	07e9                	addi	a5,a5,26
    800052c0:	078e                	slli	a5,a5,0x3
    800052c2:	97a6                	add	a5,a5,s1
    800052c4:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    800052c8:	fd043503          	ld	a0,-48(s0)
    800052cc:	d21fe0ef          	jal	80003fec <fileclose>
    fileclose(wf);
    800052d0:	fc843503          	ld	a0,-56(s0)
    800052d4:	d19fe0ef          	jal	80003fec <fileclose>
    return -1;
    800052d8:	a015                	j	800052fc <sys_pipe+0xce>
    if(fd0 >= 0)
    800052da:	fc442783          	lw	a5,-60(s0)
    800052de:	0007c763          	bltz	a5,800052ec <sys_pipe+0xbe>
      p->ofile[fd0] = 0;
    800052e2:	07e9                	addi	a5,a5,26
    800052e4:	078e                	slli	a5,a5,0x3
    800052e6:	97a6                	add	a5,a5,s1
    800052e8:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    800052ec:	fd043503          	ld	a0,-48(s0)
    800052f0:	cfdfe0ef          	jal	80003fec <fileclose>
    fileclose(wf);
    800052f4:	fc843503          	ld	a0,-56(s0)
    800052f8:	cf5fe0ef          	jal	80003fec <fileclose>
    return -1;
    800052fc:	557d                	li	a0,-1
}
    800052fe:	70e2                	ld	ra,56(sp)
    80005300:	7442                	ld	s0,48(sp)
    80005302:	74a2                	ld	s1,40(sp)
    80005304:	6121                	addi	sp,sp,64
    80005306:	8082                	ret
	...

0000000080005310 <kernelvec>:
    80005310:	7111                	addi	sp,sp,-256
    80005312:	e006                	sd	ra,0(sp)
    80005314:	e40a                	sd	sp,8(sp)
    80005316:	e80e                	sd	gp,16(sp)
    80005318:	ec12                	sd	tp,24(sp)
    8000531a:	f016                	sd	t0,32(sp)
    8000531c:	f41a                	sd	t1,40(sp)
    8000531e:	f81e                	sd	t2,48(sp)
    80005320:	e4aa                	sd	a0,72(sp)
    80005322:	e8ae                	sd	a1,80(sp)
    80005324:	ecb2                	sd	a2,88(sp)
    80005326:	f0b6                	sd	a3,96(sp)
    80005328:	f4ba                	sd	a4,104(sp)
    8000532a:	f8be                	sd	a5,112(sp)
    8000532c:	fcc2                	sd	a6,120(sp)
    8000532e:	e146                	sd	a7,128(sp)
    80005330:	edf2                	sd	t3,216(sp)
    80005332:	f1f6                	sd	t4,224(sp)
    80005334:	f5fa                	sd	t5,232(sp)
    80005336:	f9fe                	sd	t6,240(sp)
    80005338:	b18fd0ef          	jal	80002650 <kerneltrap>
    8000533c:	6082                	ld	ra,0(sp)
    8000533e:	6122                	ld	sp,8(sp)
    80005340:	61c2                	ld	gp,16(sp)
    80005342:	7282                	ld	t0,32(sp)
    80005344:	7322                	ld	t1,40(sp)
    80005346:	73c2                	ld	t2,48(sp)
    80005348:	6526                	ld	a0,72(sp)
    8000534a:	65c6                	ld	a1,80(sp)
    8000534c:	6666                	ld	a2,88(sp)
    8000534e:	7686                	ld	a3,96(sp)
    80005350:	7726                	ld	a4,104(sp)
    80005352:	77c6                	ld	a5,112(sp)
    80005354:	7866                	ld	a6,120(sp)
    80005356:	688a                	ld	a7,128(sp)
    80005358:	6e6e                	ld	t3,216(sp)
    8000535a:	7e8e                	ld	t4,224(sp)
    8000535c:	7f2e                	ld	t5,232(sp)
    8000535e:	7fce                	ld	t6,240(sp)
    80005360:	6111                	addi	sp,sp,256
    80005362:	10200073          	sret
    80005366:	00000013          	nop
    8000536a:	00000013          	nop

000000008000536e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000536e:	1141                	addi	sp,sp,-16
    80005370:	e406                	sd	ra,8(sp)
    80005372:	e022                	sd	s0,0(sp)
    80005374:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    80005376:	0c000737          	lui	a4,0xc000
    8000537a:	4785                	li	a5,1
    8000537c:	d71c                	sw	a5,40(a4)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    8000537e:	c35c                	sw	a5,4(a4)
}
    80005380:	60a2                	ld	ra,8(sp)
    80005382:	6402                	ld	s0,0(sp)
    80005384:	0141                	addi	sp,sp,16
    80005386:	8082                	ret

0000000080005388 <plicinithart>:

void
plicinithart(void)
{
    80005388:	1141                	addi	sp,sp,-16
    8000538a:	e406                	sd	ra,8(sp)
    8000538c:	e022                	sd	s0,0(sp)
    8000538e:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005390:	d6cfc0ef          	jal	800018fc <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    80005394:	0085171b          	slliw	a4,a0,0x8
    80005398:	0c0027b7          	lui	a5,0xc002
    8000539c:	97ba                	add	a5,a5,a4
    8000539e:	40200713          	li	a4,1026
    800053a2:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    800053a6:	00d5151b          	slliw	a0,a0,0xd
    800053aa:	0c2017b7          	lui	a5,0xc201
    800053ae:	97aa                	add	a5,a5,a0
    800053b0:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    800053b4:	60a2                	ld	ra,8(sp)
    800053b6:	6402                	ld	s0,0(sp)
    800053b8:	0141                	addi	sp,sp,16
    800053ba:	8082                	ret

00000000800053bc <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    800053bc:	1141                	addi	sp,sp,-16
    800053be:	e406                	sd	ra,8(sp)
    800053c0:	e022                	sd	s0,0(sp)
    800053c2:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800053c4:	d38fc0ef          	jal	800018fc <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    800053c8:	00d5151b          	slliw	a0,a0,0xd
    800053cc:	0c2017b7          	lui	a5,0xc201
    800053d0:	97aa                	add	a5,a5,a0
  return irq;
}
    800053d2:	43c8                	lw	a0,4(a5)
    800053d4:	60a2                	ld	ra,8(sp)
    800053d6:	6402                	ld	s0,0(sp)
    800053d8:	0141                	addi	sp,sp,16
    800053da:	8082                	ret

00000000800053dc <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    800053dc:	1101                	addi	sp,sp,-32
    800053de:	ec06                	sd	ra,24(sp)
    800053e0:	e822                	sd	s0,16(sp)
    800053e2:	e426                	sd	s1,8(sp)
    800053e4:	1000                	addi	s0,sp,32
    800053e6:	84aa                	mv	s1,a0
  int hart = cpuid();
    800053e8:	d14fc0ef          	jal	800018fc <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    800053ec:	00d5179b          	slliw	a5,a0,0xd
    800053f0:	0c201737          	lui	a4,0xc201
    800053f4:	97ba                	add	a5,a5,a4
    800053f6:	c3c4                	sw	s1,4(a5)
}
    800053f8:	60e2                	ld	ra,24(sp)
    800053fa:	6442                	ld	s0,16(sp)
    800053fc:	64a2                	ld	s1,8(sp)
    800053fe:	6105                	addi	sp,sp,32
    80005400:	8082                	ret

0000000080005402 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005402:	1141                	addi	sp,sp,-16
    80005404:	e406                	sd	ra,8(sp)
    80005406:	e022                	sd	s0,0(sp)
    80005408:	0800                	addi	s0,sp,16
  if(i >= NUM)
    8000540a:	479d                	li	a5,7
    8000540c:	04a7ca63          	blt	a5,a0,80005460 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80005410:	0001b797          	auipc	a5,0x1b
    80005414:	76078793          	addi	a5,a5,1888 # 80020b70 <disk>
    80005418:	97aa                	add	a5,a5,a0
    8000541a:	0187c783          	lbu	a5,24(a5)
    8000541e:	e7b9                	bnez	a5,8000546c <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005420:	00451693          	slli	a3,a0,0x4
    80005424:	0001b797          	auipc	a5,0x1b
    80005428:	74c78793          	addi	a5,a5,1868 # 80020b70 <disk>
    8000542c:	6398                	ld	a4,0(a5)
    8000542e:	9736                	add	a4,a4,a3
    80005430:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    80005434:	6398                	ld	a4,0(a5)
    80005436:	9736                	add	a4,a4,a3
    80005438:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    8000543c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005440:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005444:	97aa                	add	a5,a5,a0
    80005446:	4705                	li	a4,1
    80005448:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    8000544c:	0001b517          	auipc	a0,0x1b
    80005450:	73c50513          	addi	a0,a0,1852 # 80020b88 <disk+0x18>
    80005454:	ae5fc0ef          	jal	80001f38 <wakeup>
}
    80005458:	60a2                	ld	ra,8(sp)
    8000545a:	6402                	ld	s0,0(sp)
    8000545c:	0141                	addi	sp,sp,16
    8000545e:	8082                	ret
    panic("free_desc 1");
    80005460:	00002517          	auipc	a0,0x2
    80005464:	21050513          	addi	a0,a0,528 # 80007670 <etext+0x670>
    80005468:	b88fb0ef          	jal	800007f0 <panic>
    panic("free_desc 2");
    8000546c:	00002517          	auipc	a0,0x2
    80005470:	21450513          	addi	a0,a0,532 # 80007680 <etext+0x680>
    80005474:	b7cfb0ef          	jal	800007f0 <panic>

0000000080005478 <virtio_disk_init>:
{
    80005478:	1101                	addi	sp,sp,-32
    8000547a:	ec06                	sd	ra,24(sp)
    8000547c:	e822                	sd	s0,16(sp)
    8000547e:	e426                	sd	s1,8(sp)
    80005480:	e04a                	sd	s2,0(sp)
    80005482:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005484:	00002597          	auipc	a1,0x2
    80005488:	20c58593          	addi	a1,a1,524 # 80007690 <etext+0x690>
    8000548c:	0001c517          	auipc	a0,0x1c
    80005490:	80c50513          	addi	a0,a0,-2036 # 80020c98 <disk+0x128>
    80005494:	f46fb0ef          	jal	80000bda <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005498:	100017b7          	lui	a5,0x10001
    8000549c:	4398                	lw	a4,0(a5)
    8000549e:	747277b7          	lui	a5,0x74727
    800054a2:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    800054a6:	14f71263          	bne	a4,a5,800055ea <virtio_disk_init+0x172>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800054aa:	100017b7          	lui	a5,0x10001
    800054ae:	43d8                	lw	a4,4(a5)
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800054b0:	4789                	li	a5,2
    800054b2:	12f71c63          	bne	a4,a5,800055ea <virtio_disk_init+0x172>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800054b6:	100017b7          	lui	a5,0x10001
    800054ba:	4798                	lw	a4,8(a5)
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800054bc:	4789                	li	a5,2
    800054be:	12f71663          	bne	a4,a5,800055ea <virtio_disk_init+0x172>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    800054c2:	100017b7          	lui	a5,0x10001
    800054c6:	47d8                	lw	a4,12(a5)
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800054c8:	554d47b7          	lui	a5,0x554d4
    800054cc:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    800054d0:	10f71d63          	bne	a4,a5,800055ea <virtio_disk_init+0x172>
  *R(VIRTIO_MMIO_STATUS) = status;
    800054d4:	100017b7          	lui	a5,0x10001
    800054d8:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    800054dc:	4705                	li	a4,1
    800054de:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    800054e0:	470d                	li	a4,3
    800054e2:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    800054e4:	10001737          	lui	a4,0x10001
    800054e8:	4b18                	lw	a4,16(a4)
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    800054ea:	c7ffe6b7          	lui	a3,0xc7ffe
    800054ee:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fdd63f>
    800054f2:	8f75                	and	a4,a4,a3
    800054f4:	100016b7          	lui	a3,0x10001
    800054f8:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    800054fa:	472d                	li	a4,11
    800054fc:	dbb8                	sw	a4,112(a5)
  status = *R(VIRTIO_MMIO_STATUS);
    800054fe:	0707a903          	lw	s2,112(a5)
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005502:	00897793          	andi	a5,s2,8
    80005506:	0e078863          	beqz	a5,800055f6 <virtio_disk_init+0x17e>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    8000550a:	100017b7          	lui	a5,0x10001
    8000550e:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80005512:	43fc                	lw	a5,68(a5)
    80005514:	0e079763          	bnez	a5,80005602 <virtio_disk_init+0x18a>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005518:	100017b7          	lui	a5,0x10001
    8000551c:	5bdc                	lw	a5,52(a5)
  if(max == 0)
    8000551e:	0e078863          	beqz	a5,8000560e <virtio_disk_init+0x196>
  if(max < NUM)
    80005522:	471d                	li	a4,7
    80005524:	0ef77b63          	bgeu	a4,a5,8000561a <virtio_disk_init+0x1a2>
  disk.desc = kalloc();
    80005528:	e58fb0ef          	jal	80000b80 <kalloc>
    8000552c:	0001b497          	auipc	s1,0x1b
    80005530:	64448493          	addi	s1,s1,1604 # 80020b70 <disk>
    80005534:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80005536:	e4afb0ef          	jal	80000b80 <kalloc>
    8000553a:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    8000553c:	e44fb0ef          	jal	80000b80 <kalloc>
    80005540:	87aa                	mv	a5,a0
    80005542:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80005544:	6088                	ld	a0,0(s1)
    80005546:	0e050063          	beqz	a0,80005626 <virtio_disk_init+0x1ae>
    8000554a:	0001b717          	auipc	a4,0x1b
    8000554e:	62e73703          	ld	a4,1582(a4) # 80020b78 <disk+0x8>
    80005552:	00173713          	seqz	a4,a4
    80005556:	0017b793          	seqz	a5,a5
    8000555a:	8fd9                	or	a5,a5,a4
    8000555c:	e7e9                	bnez	a5,80005626 <virtio_disk_init+0x1ae>
  memset(disk.desc, 0, PGSIZE);
    8000555e:	6605                	lui	a2,0x1
    80005560:	4581                	li	a1,0
    80005562:	fcefb0ef          	jal	80000d30 <memset>
  memset(disk.avail, 0, PGSIZE);
    80005566:	0001b497          	auipc	s1,0x1b
    8000556a:	60a48493          	addi	s1,s1,1546 # 80020b70 <disk>
    8000556e:	6605                	lui	a2,0x1
    80005570:	4581                	li	a1,0
    80005572:	6488                	ld	a0,8(s1)
    80005574:	fbcfb0ef          	jal	80000d30 <memset>
  memset(disk.used, 0, PGSIZE);
    80005578:	6605                	lui	a2,0x1
    8000557a:	4581                	li	a1,0
    8000557c:	6888                	ld	a0,16(s1)
    8000557e:	fb2fb0ef          	jal	80000d30 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80005582:	100017b7          	lui	a5,0x10001
    80005586:	4721                	li	a4,8
    80005588:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    8000558a:	4098                	lw	a4,0(s1)
    8000558c:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80005590:	40d8                	lw	a4,4(s1)
    80005592:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    80005596:	649c                	ld	a5,8(s1)
    80005598:	10001737          	lui	a4,0x10001
    8000559c:	08f72823          	sw	a5,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    800055a0:	9781                	srai	a5,a5,0x20
    800055a2:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    800055a6:	689c                	ld	a5,16(s1)
    800055a8:	0af72023          	sw	a5,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    800055ac:	9781                	srai	a5,a5,0x20
    800055ae:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    800055b2:	4785                	li	a5,1
    800055b4:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    800055b6:	00f48c23          	sb	a5,24(s1)
    800055ba:	00f48ca3          	sb	a5,25(s1)
    800055be:	00f48d23          	sb	a5,26(s1)
    800055c2:	00f48da3          	sb	a5,27(s1)
    800055c6:	00f48e23          	sb	a5,28(s1)
    800055ca:	00f48ea3          	sb	a5,29(s1)
    800055ce:	00f48f23          	sb	a5,30(s1)
    800055d2:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    800055d6:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    800055da:	07272823          	sw	s2,112(a4)
}
    800055de:	60e2                	ld	ra,24(sp)
    800055e0:	6442                	ld	s0,16(sp)
    800055e2:	64a2                	ld	s1,8(sp)
    800055e4:	6902                	ld	s2,0(sp)
    800055e6:	6105                	addi	sp,sp,32
    800055e8:	8082                	ret
    panic("could not find virtio disk");
    800055ea:	00002517          	auipc	a0,0x2
    800055ee:	0b650513          	addi	a0,a0,182 # 800076a0 <etext+0x6a0>
    800055f2:	9fefb0ef          	jal	800007f0 <panic>
    panic("virtio disk FEATURES_OK unset");
    800055f6:	00002517          	auipc	a0,0x2
    800055fa:	0ca50513          	addi	a0,a0,202 # 800076c0 <etext+0x6c0>
    800055fe:	9f2fb0ef          	jal	800007f0 <panic>
    panic("virtio disk should not be ready");
    80005602:	00002517          	auipc	a0,0x2
    80005606:	0de50513          	addi	a0,a0,222 # 800076e0 <etext+0x6e0>
    8000560a:	9e6fb0ef          	jal	800007f0 <panic>
    panic("virtio disk has no queue 0");
    8000560e:	00002517          	auipc	a0,0x2
    80005612:	0f250513          	addi	a0,a0,242 # 80007700 <etext+0x700>
    80005616:	9dafb0ef          	jal	800007f0 <panic>
    panic("virtio disk max queue too short");
    8000561a:	00002517          	auipc	a0,0x2
    8000561e:	10650513          	addi	a0,a0,262 # 80007720 <etext+0x720>
    80005622:	9cefb0ef          	jal	800007f0 <panic>
    panic("virtio disk kalloc");
    80005626:	00002517          	auipc	a0,0x2
    8000562a:	11a50513          	addi	a0,a0,282 # 80007740 <etext+0x740>
    8000562e:	9c2fb0ef          	jal	800007f0 <panic>

0000000080005632 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80005632:	711d                	addi	sp,sp,-96
    80005634:	ec86                	sd	ra,88(sp)
    80005636:	e8a2                	sd	s0,80(sp)
    80005638:	e4a6                	sd	s1,72(sp)
    8000563a:	e0ca                	sd	s2,64(sp)
    8000563c:	fc4e                	sd	s3,56(sp)
    8000563e:	f852                	sd	s4,48(sp)
    80005640:	f456                	sd	s5,40(sp)
    80005642:	f05a                	sd	s6,32(sp)
    80005644:	ec5e                	sd	s7,24(sp)
    80005646:	e862                	sd	s8,16(sp)
    80005648:	1080                	addi	s0,sp,96
    8000564a:	89aa                	mv	s3,a0
    8000564c:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    8000564e:	00c52b83          	lw	s7,12(a0)
    80005652:	001b9b9b          	slliw	s7,s7,0x1
    80005656:	1b82                	slli	s7,s7,0x20
    80005658:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    8000565c:	0001b517          	auipc	a0,0x1b
    80005660:	63c50513          	addi	a0,a0,1596 # 80020c98 <disk+0x128>
    80005664:	e00fb0ef          	jal	80000c64 <acquire>
  for(int i = 0; i < NUM; i++){
    80005668:	44a1                	li	s1,8
      disk.free[i] = 0;
    8000566a:	0001ba97          	auipc	s5,0x1b
    8000566e:	506a8a93          	addi	s5,s5,1286 # 80020b70 <disk>
  for(int i = 0; i < 3; i++){
    80005672:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    80005674:	5c7d                	li	s8,-1
    80005676:	a095                	j	800056da <virtio_disk_rw+0xa8>
      disk.free[i] = 0;
    80005678:	00fa8733          	add	a4,s5,a5
    8000567c:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    80005680:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    80005682:	0207c563          	bltz	a5,800056ac <virtio_disk_rw+0x7a>
  for(int i = 0; i < 3; i++){
    80005686:	2905                	addiw	s2,s2,1
    80005688:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    8000568a:	05490c63          	beq	s2,s4,800056e2 <virtio_disk_rw+0xb0>
    idx[i] = alloc_desc();
    8000568e:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    80005690:	0001b717          	auipc	a4,0x1b
    80005694:	4e070713          	addi	a4,a4,1248 # 80020b70 <disk>
    80005698:	4781                	li	a5,0
    if(disk.free[i]){
    8000569a:	01874683          	lbu	a3,24(a4)
    8000569e:	fee9                	bnez	a3,80005678 <virtio_disk_rw+0x46>
  for(int i = 0; i < NUM; i++){
    800056a0:	2785                	addiw	a5,a5,1
    800056a2:	0705                	addi	a4,a4,1
    800056a4:	fe979be3          	bne	a5,s1,8000569a <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    800056a8:	0185a023          	sw	s8,0(a1)
      for(int j = 0; j < i; j++)
    800056ac:	01205d63          	blez	s2,800056c6 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    800056b0:	fa042503          	lw	a0,-96(s0)
    800056b4:	d4fff0ef          	jal	80005402 <free_desc>
      for(int j = 0; j < i; j++)
    800056b8:	4785                	li	a5,1
    800056ba:	0127d663          	bge	a5,s2,800056c6 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    800056be:	fa442503          	lw	a0,-92(s0)
    800056c2:	d41ff0ef          	jal	80005402 <free_desc>
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    800056c6:	0001b597          	auipc	a1,0x1b
    800056ca:	5d258593          	addi	a1,a1,1490 # 80020c98 <disk+0x128>
    800056ce:	0001b517          	auipc	a0,0x1b
    800056d2:	4ba50513          	addi	a0,a0,1210 # 80020b88 <disk+0x18>
    800056d6:	817fc0ef          	jal	80001eec <sleep>
  for(int i = 0; i < 3; i++){
    800056da:	fa040613          	addi	a2,s0,-96
    800056de:	4901                	li	s2,0
    800056e0:	b77d                	j	8000568e <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800056e2:	fa042503          	lw	a0,-96(s0)
    800056e6:	00451693          	slli	a3,a0,0x4

  if(write)
    800056ea:	0001b797          	auipc	a5,0x1b
    800056ee:	48678793          	addi	a5,a5,1158 # 80020b70 <disk>
    800056f2:	00451713          	slli	a4,a0,0x4
    800056f6:	0a070713          	addi	a4,a4,160
    800056fa:	973e                	add	a4,a4,a5
    800056fc:	01603633          	snez	a2,s6
    80005700:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005702:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005706:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    8000570a:	6398                	ld	a4,0(a5)
    8000570c:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    8000570e:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80005712:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80005714:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005716:	6390                	ld	a2,0(a5)
    80005718:	00d605b3          	add	a1,a2,a3
    8000571c:	4741                	li	a4,16
    8000571e:	c598                	sw	a4,8(a1)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005720:	4805                	li	a6,1
    80005722:	01059623          	sh	a6,12(a1)
  disk.desc[idx[0]].next = idx[1];
    80005726:	fa442703          	lw	a4,-92(s0)
    8000572a:	00e59723          	sh	a4,14(a1)

  disk.desc[idx[1]].addr = (uint64) b->data;
    8000572e:	0712                	slli	a4,a4,0x4
    80005730:	963a                	add	a2,a2,a4
    80005732:	05898593          	addi	a1,s3,88
    80005736:	e20c                	sd	a1,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80005738:	0007b883          	ld	a7,0(a5)
    8000573c:	9746                	add	a4,a4,a7
    8000573e:	40000613          	li	a2,1024
    80005742:	c710                	sw	a2,8(a4)
  if(write)
    80005744:	001b3613          	seqz	a2,s6
    80005748:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    8000574c:	01066633          	or	a2,a2,a6
    80005750:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005754:	fa842583          	lw	a1,-88(s0)
    80005758:	00b71723          	sh	a1,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    8000575c:	00250613          	addi	a2,a0,2
    80005760:	0612                	slli	a2,a2,0x4
    80005762:	963e                	add	a2,a2,a5
    80005764:	577d                	li	a4,-1
    80005766:	00e60823          	sb	a4,16(a2)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    8000576a:	0592                	slli	a1,a1,0x4
    8000576c:	98ae                	add	a7,a7,a1
    8000576e:	03068713          	addi	a4,a3,48
    80005772:	973e                	add	a4,a4,a5
    80005774:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80005778:	6398                	ld	a4,0(a5)
    8000577a:	972e                	add	a4,a4,a1
    8000577c:	01072423          	sw	a6,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    80005780:	4689                	li	a3,2
    80005782:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80005786:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    8000578a:	0109a223          	sw	a6,4(s3)
  disk.info[idx[0]].b = b;
    8000578e:	01363423          	sd	s3,8(a2)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80005792:	6794                	ld	a3,8(a5)
    80005794:	0026d703          	lhu	a4,2(a3)
    80005798:	8b1d                	andi	a4,a4,7
    8000579a:	0706                	slli	a4,a4,0x1
    8000579c:	96ba                	add	a3,a3,a4
    8000579e:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    800057a2:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    800057a6:	6798                	ld	a4,8(a5)
    800057a8:	00275783          	lhu	a5,2(a4)
    800057ac:	2785                	addiw	a5,a5,1
    800057ae:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    800057b2:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    800057b6:	100017b7          	lui	a5,0x10001
    800057ba:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    800057be:	0049a783          	lw	a5,4(s3)
    800057c2:	01079f63          	bne	a5,a6,800057e0 <virtio_disk_rw+0x1ae>
    sleep(b, &disk.vdisk_lock);
    800057c6:	0001b917          	auipc	s2,0x1b
    800057ca:	4d290913          	addi	s2,s2,1234 # 80020c98 <disk+0x128>
  while(b->disk == 1) {
    800057ce:	84be                	mv	s1,a5
    sleep(b, &disk.vdisk_lock);
    800057d0:	85ca                	mv	a1,s2
    800057d2:	854e                	mv	a0,s3
    800057d4:	f18fc0ef          	jal	80001eec <sleep>
  while(b->disk == 1) {
    800057d8:	0049a783          	lw	a5,4(s3)
    800057dc:	fe978ae3          	beq	a5,s1,800057d0 <virtio_disk_rw+0x19e>
  }

  disk.info[idx[0]].b = 0;
    800057e0:	fa042903          	lw	s2,-96(s0)
    800057e4:	00290713          	addi	a4,s2,2
    800057e8:	0712                	slli	a4,a4,0x4
    800057ea:	0001b797          	auipc	a5,0x1b
    800057ee:	38678793          	addi	a5,a5,902 # 80020b70 <disk>
    800057f2:	97ba                	add	a5,a5,a4
    800057f4:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    800057f8:	0001b997          	auipc	s3,0x1b
    800057fc:	37898993          	addi	s3,s3,888 # 80020b70 <disk>
    80005800:	00491713          	slli	a4,s2,0x4
    80005804:	0009b783          	ld	a5,0(s3)
    80005808:	97ba                	add	a5,a5,a4
    8000580a:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    8000580e:	854a                	mv	a0,s2
    80005810:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005814:	befff0ef          	jal	80005402 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    80005818:	8885                	andi	s1,s1,1
    8000581a:	f0fd                	bnez	s1,80005800 <virtio_disk_rw+0x1ce>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    8000581c:	0001b517          	auipc	a0,0x1b
    80005820:	47c50513          	addi	a0,a0,1148 # 80020c98 <disk+0x128>
    80005824:	cd0fb0ef          	jal	80000cf4 <release>
}
    80005828:	60e6                	ld	ra,88(sp)
    8000582a:	6446                	ld	s0,80(sp)
    8000582c:	64a6                	ld	s1,72(sp)
    8000582e:	6906                	ld	s2,64(sp)
    80005830:	79e2                	ld	s3,56(sp)
    80005832:	7a42                	ld	s4,48(sp)
    80005834:	7aa2                	ld	s5,40(sp)
    80005836:	7b02                	ld	s6,32(sp)
    80005838:	6be2                	ld	s7,24(sp)
    8000583a:	6c42                	ld	s8,16(sp)
    8000583c:	6125                	addi	sp,sp,96
    8000583e:	8082                	ret

0000000080005840 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005840:	1101                	addi	sp,sp,-32
    80005842:	ec06                	sd	ra,24(sp)
    80005844:	e822                	sd	s0,16(sp)
    80005846:	e426                	sd	s1,8(sp)
    80005848:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    8000584a:	0001b497          	auipc	s1,0x1b
    8000584e:	32648493          	addi	s1,s1,806 # 80020b70 <disk>
    80005852:	0001b517          	auipc	a0,0x1b
    80005856:	44650513          	addi	a0,a0,1094 # 80020c98 <disk+0x128>
    8000585a:	c0afb0ef          	jal	80000c64 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    8000585e:	100017b7          	lui	a5,0x10001
    80005862:	53bc                	lw	a5,96(a5)
    80005864:	8b8d                	andi	a5,a5,3
    80005866:	10001737          	lui	a4,0x10001
    8000586a:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    8000586c:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80005870:	689c                	ld	a5,16(s1)
    80005872:	0204d703          	lhu	a4,32(s1)
    80005876:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    8000587a:	04f70663          	beq	a4,a5,800058c6 <virtio_disk_intr+0x86>
    __sync_synchronize();
    8000587e:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80005882:	6898                	ld	a4,16(s1)
    80005884:	0204d783          	lhu	a5,32(s1)
    80005888:	8b9d                	andi	a5,a5,7
    8000588a:	078e                	slli	a5,a5,0x3
    8000588c:	97ba                	add	a5,a5,a4
    8000588e:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80005890:	00278713          	addi	a4,a5,2
    80005894:	0712                	slli	a4,a4,0x4
    80005896:	9726                	add	a4,a4,s1
    80005898:	01074703          	lbu	a4,16(a4) # 10001010 <_entry-0x6fffeff0>
    8000589c:	e321                	bnez	a4,800058dc <virtio_disk_intr+0x9c>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    8000589e:	0789                	addi	a5,a5,2
    800058a0:	0792                	slli	a5,a5,0x4
    800058a2:	97a6                	add	a5,a5,s1
    800058a4:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    800058a6:	00052223          	sw	zero,4(a0)
    wakeup(b);
    800058aa:	e8efc0ef          	jal	80001f38 <wakeup>

    disk.used_idx += 1;
    800058ae:	0204d783          	lhu	a5,32(s1)
    800058b2:	2785                	addiw	a5,a5,1
    800058b4:	17c2                	slli	a5,a5,0x30
    800058b6:	93c1                	srli	a5,a5,0x30
    800058b8:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    800058bc:	6898                	ld	a4,16(s1)
    800058be:	00275703          	lhu	a4,2(a4)
    800058c2:	faf71ee3          	bne	a4,a5,8000587e <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    800058c6:	0001b517          	auipc	a0,0x1b
    800058ca:	3d250513          	addi	a0,a0,978 # 80020c98 <disk+0x128>
    800058ce:	c26fb0ef          	jal	80000cf4 <release>
}
    800058d2:	60e2                	ld	ra,24(sp)
    800058d4:	6442                	ld	s0,16(sp)
    800058d6:	64a2                	ld	s1,8(sp)
    800058d8:	6105                	addi	sp,sp,32
    800058da:	8082                	ret
      panic("virtio_disk_intr status");
    800058dc:	00002517          	auipc	a0,0x2
    800058e0:	e7c50513          	addi	a0,a0,-388 # 80007758 <etext+0x758>
    800058e4:	f0dfa0ef          	jal	800007f0 <panic>

00000000800058e8 <ubuf_read>:
    int head;  
    int tail;
};
struct ubuf ubuf;

char ubuf_read(void) {
    800058e8:	1101                	addi	sp,sp,-32
    800058ea:	ec06                	sd	ra,24(sp)
    800058ec:	e822                	sd	s0,16(sp)
    800058ee:	e426                	sd	s1,8(sp)
    800058f0:	e04a                	sd	s2,0(sp)
    800058f2:	1000                	addi	s0,sp,32
    char data = ubuf.data[ubuf.head];
    800058f4:	0001b497          	auipc	s1,0x1b
    800058f8:	3bc48493          	addi	s1,s1,956 # 80020cb0 <ubuf>
    800058fc:	489c                	lw	a5,16(s1)
    800058fe:	97a6                	add	a5,a5,s1
    80005900:	0007c903          	lbu	s2,0(a5)
    yield();
    80005904:	dbcfc0ef          	jal	80001ec0 <yield>
    ubuf.head = (ubuf.head + 1) % UBUF_SIZE;
    80005908:	489c                	lw	a5,16(s1)
    8000590a:	2785                	addiw	a5,a5,1
    8000590c:	41f7d71b          	sraiw	a4,a5,0x1f
    80005910:	01c7571b          	srliw	a4,a4,0x1c
    80005914:	9fb9                	addw	a5,a5,a4
    80005916:	8bbd                	andi	a5,a5,15
    80005918:	9f99                	subw	a5,a5,a4
    8000591a:	c89c                	sw	a5,16(s1)
    return data;
}
    8000591c:	854a                	mv	a0,s2
    8000591e:	60e2                	ld	ra,24(sp)
    80005920:	6442                	ld	s0,16(sp)
    80005922:	64a2                	ld	s1,8(sp)
    80005924:	6902                	ld	s2,0(sp)
    80005926:	6105                	addi	sp,sp,32
    80005928:	8082                	ret

000000008000592a <ubuf_write>:

void ubuf_write(char val) {
    8000592a:	1101                	addi	sp,sp,-32
    8000592c:	ec06                	sd	ra,24(sp)
    8000592e:	e822                	sd	s0,16(sp)
    80005930:	e426                	sd	s1,8(sp)
    80005932:	1000                	addi	s0,sp,32
    ubuf.data[ubuf.tail] = val;
    80005934:	0001b497          	auipc	s1,0x1b
    80005938:	37c48493          	addi	s1,s1,892 # 80020cb0 <ubuf>
    8000593c:	48dc                	lw	a5,20(s1)
    8000593e:	97a6                	add	a5,a5,s1
    80005940:	00a78023          	sb	a0,0(a5)
    yield();
    80005944:	d7cfc0ef          	jal	80001ec0 <yield>
    ubuf.tail = (ubuf.tail + 1) % UBUF_SIZE;
    80005948:	48dc                	lw	a5,20(s1)
    8000594a:	2785                	addiw	a5,a5,1
    8000594c:	41f7d71b          	sraiw	a4,a5,0x1f
    80005950:	01c7571b          	srliw	a4,a4,0x1c
    80005954:	9fb9                	addw	a5,a5,a4
    80005956:	8bbd                	andi	a5,a5,15
    80005958:	9f99                	subw	a5,a5,a4
    8000595a:	c8dc                	sw	a5,20(s1)
}
    8000595c:	60e2                	ld	ra,24(sp)
    8000595e:	6442                	ld	s0,16(sp)
    80005960:	64a2                	ld	s1,8(sp)
    80005962:	6105                	addi	sp,sp,32
    80005964:	8082                	ret

0000000080005966 <ubuf_init>:

void ubuf_init() {
    80005966:	1141                	addi	sp,sp,-16
    80005968:	e406                	sd	ra,8(sp)
    8000596a:	e022                	sd	s0,0(sp)
    8000596c:	0800                	addi	s0,sp,16
    ubuf.head = 0;
    8000596e:	0001b797          	auipc	a5,0x1b
    80005972:	34278793          	addi	a5,a5,834 # 80020cb0 <ubuf>
    80005976:	0007a823          	sw	zero,16(a5)
    ubuf.tail = 0;
    8000597a:	0007aa23          	sw	zero,20(a5)
    8000597e:	60a2                	ld	ra,8(sp)
    80005980:	6402                	ld	s0,0(sp)
    80005982:	0141                	addi	sp,sp,16
    80005984:	8082                	ret

0000000080005986 <ucnt_init>:
#include "defs.h"

#define UCNT_MAX 16 // Maximum number of counters
int ucnt[UCNT_MAX];

void ucnt_init() {
    80005986:	1141                	addi	sp,sp,-16
    80005988:	e406                	sd	ra,8(sp)
    8000598a:	e022                	sd	s0,0(sp)
    8000598c:	0800                	addi	s0,sp,16
    for (int i = 0; i < UCNT_MAX; i++) {
    8000598e:	0001b797          	auipc	a5,0x1b
    80005992:	33a78793          	addi	a5,a5,826 # 80020cc8 <ucnt>
    80005996:	0001b717          	auipc	a4,0x1b
    8000599a:	37270713          	addi	a4,a4,882 # 80020d08 <sem_table_lock>
        ucnt[i] = 0;
    8000599e:	0007a023          	sw	zero,0(a5)
    for (int i = 0; i < UCNT_MAX; i++) {
    800059a2:	0791                	addi	a5,a5,4
    800059a4:	fee79de3          	bne	a5,a4,8000599e <ucnt_init+0x18>
    }
}
    800059a8:	60a2                	ld	ra,8(sp)
    800059aa:	6402                	ld	s0,0(sp)
    800059ac:	0141                	addi	sp,sp,16
    800059ae:	8082                	ret

00000000800059b0 <ucnt_set>:

void ucnt_set(int idx, int val) {
    800059b0:	1141                	addi	sp,sp,-16
    800059b2:	e406                	sd	ra,8(sp)
    800059b4:	e022                	sd	s0,0(sp)
    800059b6:	0800                	addi	s0,sp,16
    if (idx < 0 || idx >= UCNT_MAX)
    800059b8:	47bd                	li	a5,15
    800059ba:	00a7e963          	bltu	a5,a0,800059cc <ucnt_set+0x1c>
        return;
    ucnt[idx] = val;
    800059be:	050a                	slli	a0,a0,0x2
    800059c0:	0001b797          	auipc	a5,0x1b
    800059c4:	30878793          	addi	a5,a5,776 # 80020cc8 <ucnt>
    800059c8:	97aa                	add	a5,a5,a0
    800059ca:	c38c                	sw	a1,0(a5)
}
    800059cc:	60a2                	ld	ra,8(sp)
    800059ce:	6402                	ld	s0,0(sp)
    800059d0:	0141                	addi	sp,sp,16
    800059d2:	8082                	ret

00000000800059d4 <ucnt_get>:

int ucnt_get(int idx) {
    800059d4:	1141                	addi	sp,sp,-16
    800059d6:	e406                	sd	ra,8(sp)
    800059d8:	e022                	sd	s0,0(sp)
    800059da:	0800                	addi	s0,sp,16
    if (idx < 0 || idx >= UCNT_MAX)
    800059dc:	47bd                	li	a5,15
    800059de:	00a7ed63          	bltu	a5,a0,800059f8 <ucnt_get+0x24>
        return 0;
    int val = ucnt[idx];
    800059e2:	050a                	slli	a0,a0,0x2
    800059e4:	0001b797          	auipc	a5,0x1b
    800059e8:	2e478793          	addi	a5,a5,740 # 80020cc8 <ucnt>
    800059ec:	97aa                	add	a5,a5,a0
    800059ee:	4388                	lw	a0,0(a5)
    return val;
}
    800059f0:	60a2                	ld	ra,8(sp)
    800059f2:	6402                	ld	s0,0(sp)
    800059f4:	0141                	addi	sp,sp,16
    800059f6:	8082                	ret
        return 0;
    800059f8:	4501                	li	a0,0
    800059fa:	bfdd                	j	800059f0 <ucnt_get+0x1c>

00000000800059fc <seminit>:
struct semaphore semaphores[MAX_SEMAPHORES];
struct spinlock sem_table_lock;

void
seminit(void)
{
    800059fc:	7179                	addi	sp,sp,-48
    800059fe:	f406                	sd	ra,40(sp)
    80005a00:	f022                	sd	s0,32(sp)
    80005a02:	ec26                	sd	s1,24(sp)
    80005a04:	e84a                	sd	s2,16(sp)
    80005a06:	e44e                	sd	s3,8(sp)
    80005a08:	1800                	addi	s0,sp,48
  initlock(&sem_table_lock, "sem_table");
    80005a0a:	00002597          	auipc	a1,0x2
    80005a0e:	d6658593          	addi	a1,a1,-666 # 80007770 <etext+0x770>
    80005a12:	0001b517          	auipc	a0,0x1b
    80005a16:	2f650513          	addi	a0,a0,758 # 80020d08 <sem_table_lock>
    80005a1a:	9c0fb0ef          	jal	80000bda <initlock>
  for(int i = 0; i < MAX_SEMAPHORES; i++) {
    80005a1e:	0001b497          	auipc	s1,0x1b
    80005a22:	30248493          	addi	s1,s1,770 # 80020d20 <semaphores>
    80005a26:	0001b997          	auipc	s3,0x1b
    80005a2a:	6fa98993          	addi	s3,s3,1786 # 80021120 <end>
    semaphores[i].in_use = 0;
    initlock(&semaphores[i].lock, "semaphore");
    80005a2e:	00002917          	auipc	s2,0x2
    80005a32:	d5290913          	addi	s2,s2,-686 # 80007780 <etext+0x780>
    semaphores[i].in_use = 0;
    80005a36:	0004ae23          	sw	zero,28(s1)
    initlock(&semaphores[i].lock, "semaphore");
    80005a3a:	85ca                	mv	a1,s2
    80005a3c:	8526                	mv	a0,s1
    80005a3e:	99cfb0ef          	jal	80000bda <initlock>
  for(int i = 0; i < MAX_SEMAPHORES; i++) {
    80005a42:	02048493          	addi	s1,s1,32
    80005a46:	ff3498e3          	bne	s1,s3,80005a36 <seminit+0x3a>
  }
}
    80005a4a:	70a2                	ld	ra,40(sp)
    80005a4c:	7402                	ld	s0,32(sp)
    80005a4e:	64e2                	ld	s1,24(sp)
    80005a50:	6942                	ld	s2,16(sp)
    80005a52:	69a2                	ld	s3,8(sp)
    80005a54:	6145                	addi	sp,sp,48
    80005a56:	8082                	ret

0000000080005a58 <sem_alloc>:

int
sem_alloc(int value)
{
    80005a58:	1101                	addi	sp,sp,-32
    80005a5a:	ec06                	sd	ra,24(sp)
    80005a5c:	e822                	sd	s0,16(sp)
    80005a5e:	e426                	sd	s1,8(sp)
    80005a60:	e04a                	sd	s2,0(sp)
    80005a62:	1000                	addi	s0,sp,32
    80005a64:	892a                	mv	s2,a0
  acquire(&sem_table_lock);
    80005a66:	0001b517          	auipc	a0,0x1b
    80005a6a:	2a250513          	addi	a0,a0,674 # 80020d08 <sem_table_lock>
    80005a6e:	9f6fb0ef          	jal	80000c64 <acquire>
  for(int i = 0; i < MAX_SEMAPHORES; i++) {
    80005a72:	0001b797          	auipc	a5,0x1b
    80005a76:	2ca78793          	addi	a5,a5,714 # 80020d3c <semaphores+0x1c>
    80005a7a:	4481                	li	s1,0
    80005a7c:	02000693          	li	a3,32
    if(!semaphores[i].in_use) {
    80005a80:	4398                	lw	a4,0(a5)
    80005a82:	cf11                	beqz	a4,80005a9e <sem_alloc+0x46>
  for(int i = 0; i < MAX_SEMAPHORES; i++) {
    80005a84:	2485                	addiw	s1,s1,1
    80005a86:	02078793          	addi	a5,a5,32
    80005a8a:	fed49be3          	bne	s1,a3,80005a80 <sem_alloc+0x28>
      semaphores[i].value = value;
      release(&sem_table_lock);
      return i;
    }
  }
  release(&sem_table_lock);
    80005a8e:	0001b517          	auipc	a0,0x1b
    80005a92:	27a50513          	addi	a0,a0,634 # 80020d08 <sem_table_lock>
    80005a96:	a5efb0ef          	jal	80000cf4 <release>
  return -1;  // No free semaphores
    80005a9a:	54fd                	li	s1,-1
    80005a9c:	a015                	j	80005ac0 <sem_alloc+0x68>
      semaphores[i].in_use = 1;
    80005a9e:	00549713          	slli	a4,s1,0x5
    80005aa2:	0001b797          	auipc	a5,0x1b
    80005aa6:	26678793          	addi	a5,a5,614 # 80020d08 <sem_table_lock>
    80005aaa:	97ba                	add	a5,a5,a4
    80005aac:	4705                	li	a4,1
    80005aae:	dbd8                	sw	a4,52(a5)
      semaphores[i].value = value;
    80005ab0:	0327a823          	sw	s2,48(a5)
      release(&sem_table_lock);
    80005ab4:	0001b517          	auipc	a0,0x1b
    80005ab8:	25450513          	addi	a0,a0,596 # 80020d08 <sem_table_lock>
    80005abc:	a38fb0ef          	jal	80000cf4 <release>
}
    80005ac0:	8526                	mv	a0,s1
    80005ac2:	60e2                	ld	ra,24(sp)
    80005ac4:	6442                	ld	s0,16(sp)
    80005ac6:	64a2                	ld	s1,8(sp)
    80005ac8:	6902                	ld	s2,0(sp)
    80005aca:	6105                	addi	sp,sp,32
    80005acc:	8082                	ret

0000000080005ace <sem_free>:

int
sem_free(int semid)
{
  if(semid < 0 || semid >= MAX_SEMAPHORES)
    80005ace:	47fd                	li	a5,31
    80005ad0:	04a7e263          	bltu	a5,a0,80005b14 <sem_free+0x46>
{
    80005ad4:	1101                	addi	sp,sp,-32
    80005ad6:	ec06                	sd	ra,24(sp)
    80005ad8:	e822                	sd	s0,16(sp)
    80005ada:	e426                	sd	s1,8(sp)
    80005adc:	1000                	addi	s0,sp,32
    80005ade:	84aa                	mv	s1,a0
    return -1;
  
  acquire(&sem_table_lock);
    80005ae0:	0001b517          	auipc	a0,0x1b
    80005ae4:	22850513          	addi	a0,a0,552 # 80020d08 <sem_table_lock>
    80005ae8:	97cfb0ef          	jal	80000c64 <acquire>
  semaphores[semid].in_use = 0;
    80005aec:	0496                	slli	s1,s1,0x5
    80005aee:	0001b797          	auipc	a5,0x1b
    80005af2:	21a78793          	addi	a5,a5,538 # 80020d08 <sem_table_lock>
    80005af6:	97a6                	add	a5,a5,s1
    80005af8:	0207aa23          	sw	zero,52(a5)
  release(&sem_table_lock);
    80005afc:	0001b517          	auipc	a0,0x1b
    80005b00:	20c50513          	addi	a0,a0,524 # 80020d08 <sem_table_lock>
    80005b04:	9f0fb0ef          	jal	80000cf4 <release>

  return 0;
    80005b08:	4501                	li	a0,0
}
    80005b0a:	60e2                	ld	ra,24(sp)
    80005b0c:	6442                	ld	s0,16(sp)
    80005b0e:	64a2                	ld	s1,8(sp)
    80005b10:	6105                	addi	sp,sp,32
    80005b12:	8082                	ret
    return -1;
    80005b14:	557d                	li	a0,-1
}
    80005b16:	8082                	ret

0000000080005b18 <sem_wait>:

int
sem_wait(int semid)
{
  if(semid < 0 || semid >= MAX_SEMAPHORES || !semaphores[semid].in_use)
    80005b18:	47fd                	li	a5,31
    80005b1a:	08a7e563          	bltu	a5,a0,80005ba4 <sem_wait+0x8c>
{
    80005b1e:	7179                	addi	sp,sp,-48
    80005b20:	f406                	sd	ra,40(sp)
    80005b22:	f022                	sd	s0,32(sp)
    80005b24:	e44e                	sd	s3,8(sp)
    80005b26:	1800                	addi	s0,sp,48
    80005b28:	89aa                	mv	s3,a0
  if(semid < 0 || semid >= MAX_SEMAPHORES || !semaphores[semid].in_use)
    80005b2a:	00551713          	slli	a4,a0,0x5
    80005b2e:	0001b797          	auipc	a5,0x1b
    80005b32:	1da78793          	addi	a5,a5,474 # 80020d08 <sem_table_lock>
    80005b36:	97ba                	add	a5,a5,a4
    80005b38:	5bdc                	lw	a5,52(a5)
    return -1;
    80005b3a:	557d                	li	a0,-1
  if(semid < 0 || semid >= MAX_SEMAPHORES || !semaphores[semid].in_use)
    80005b3c:	cfb9                	beqz	a5,80005b9a <sem_wait+0x82>
    80005b3e:	ec26                	sd	s1,24(sp)
    80005b40:	e84a                	sd	s2,16(sp)
 
  struct semaphore *sem = &semaphores[semid];
    80005b42:	00599913          	slli	s2,s3,0x5
    80005b46:	0001b497          	auipc	s1,0x1b
    80005b4a:	1da48493          	addi	s1,s1,474 # 80020d20 <semaphores>
    80005b4e:	94ca                	add	s1,s1,s2

  acquire(&sem->lock);
    80005b50:	8526                	mv	a0,s1
    80005b52:	912fb0ef          	jal	80000c64 <acquire>
  while(sem->value == 0)
    80005b56:	0001b797          	auipc	a5,0x1b
    80005b5a:	1b278793          	addi	a5,a5,434 # 80020d08 <sem_table_lock>
    80005b5e:	97ca                	add	a5,a5,s2
    80005b60:	5b9c                	lw	a5,48(a5)
    80005b62:	ef91                	bnez	a5,80005b7e <sem_wait+0x66>
    80005b64:	87ca                	mv	a5,s2
    80005b66:	0001b917          	auipc	s2,0x1b
    80005b6a:	1a290913          	addi	s2,s2,418 # 80020d08 <sem_table_lock>
    80005b6e:	993e                	add	s2,s2,a5
    sleep(sem, &sem->lock);
    80005b70:	85a6                	mv	a1,s1
    80005b72:	8526                	mv	a0,s1
    80005b74:	b78fc0ef          	jal	80001eec <sleep>
  while(sem->value == 0)
    80005b78:	03092783          	lw	a5,48(s2)
    80005b7c:	dbf5                	beqz	a5,80005b70 <sem_wait+0x58>
  sem->value--;
    80005b7e:	0996                	slli	s3,s3,0x5
    80005b80:	0001b717          	auipc	a4,0x1b
    80005b84:	18870713          	addi	a4,a4,392 # 80020d08 <sem_table_lock>
    80005b88:	974e                	add	a4,a4,s3
    80005b8a:	37fd                	addiw	a5,a5,-1
    80005b8c:	db1c                	sw	a5,48(a4)
  release(&sem->lock);
    80005b8e:	8526                	mv	a0,s1
    80005b90:	964fb0ef          	jal	80000cf4 <release>

  return 0;
    80005b94:	4501                	li	a0,0
    80005b96:	64e2                	ld	s1,24(sp)
    80005b98:	6942                	ld	s2,16(sp)
}
    80005b9a:	70a2                	ld	ra,40(sp)
    80005b9c:	7402                	ld	s0,32(sp)
    80005b9e:	69a2                	ld	s3,8(sp)
    80005ba0:	6145                	addi	sp,sp,48
    80005ba2:	8082                	ret
    return -1;
    80005ba4:	557d                	li	a0,-1
}
    80005ba6:	8082                	ret

0000000080005ba8 <sem_signal>:

int
sem_signal(int semid)
{
  if(semid < 0 || semid >= MAX_SEMAPHORES || !semaphores[semid].in_use)
    80005ba8:	47fd                	li	a5,31
    80005baa:	06a7e063          	bltu	a5,a0,80005c0a <sem_signal+0x62>
    80005bae:	00551713          	slli	a4,a0,0x5
    80005bb2:	0001b797          	auipc	a5,0x1b
    80005bb6:	15678793          	addi	a5,a5,342 # 80020d08 <sem_table_lock>
    80005bba:	97ba                	add	a5,a5,a4
    80005bbc:	5bdc                	lw	a5,52(a5)
    80005bbe:	c7b1                	beqz	a5,80005c0a <sem_signal+0x62>
{
    80005bc0:	1101                	addi	sp,sp,-32
    80005bc2:	ec06                	sd	ra,24(sp)
    80005bc4:	e822                	sd	s0,16(sp)
    80005bc6:	e426                	sd	s1,8(sp)
    80005bc8:	e04a                	sd	s2,0(sp)
    80005bca:	1000                	addi	s0,sp,32
    return -1;

  struct semaphore *sem = &semaphores[semid];
    80005bcc:	00551493          	slli	s1,a0,0x5
    80005bd0:	0001b917          	auipc	s2,0x1b
    80005bd4:	15090913          	addi	s2,s2,336 # 80020d20 <semaphores>
    80005bd8:	9926                	add	s2,s2,s1

  acquire(&sem->lock);
    80005bda:	854a                	mv	a0,s2
    80005bdc:	888fb0ef          	jal	80000c64 <acquire>
  sem->value++;
    80005be0:	0001b797          	auipc	a5,0x1b
    80005be4:	12878793          	addi	a5,a5,296 # 80020d08 <sem_table_lock>
    80005be8:	97a6                	add	a5,a5,s1
    80005bea:	5b98                	lw	a4,48(a5)
    80005bec:	2705                	addiw	a4,a4,1
    80005bee:	db98                	sw	a4,48(a5)
  wakeup(sem);
    80005bf0:	854a                	mv	a0,s2
    80005bf2:	b46fc0ef          	jal	80001f38 <wakeup>
  release(&sem->lock);
    80005bf6:	854a                	mv	a0,s2
    80005bf8:	8fcfb0ef          	jal	80000cf4 <release>

  return 0;
    80005bfc:	4501                	li	a0,0
}
    80005bfe:	60e2                	ld	ra,24(sp)
    80005c00:	6442                	ld	s0,16(sp)
    80005c02:	64a2                	ld	s1,8(sp)
    80005c04:	6902                	ld	s2,0(sp)
    80005c06:	6105                	addi	sp,sp,32
    80005c08:	8082                	ret
    return -1;
    80005c0a:	557d                	li	a0,-1
}
    80005c0c:	8082                	ret

0000000080005c0e <sem_getvalue>:

int
sem_getvalue(int semid)
{
    80005c0e:	1101                	addi	sp,sp,-32
    80005c10:	ec06                	sd	ra,24(sp)
    80005c12:	e822                	sd	s0,16(sp)
    80005c14:	e426                	sd	s1,8(sp)
    80005c16:	1000                	addi	s0,sp,32
  if(semid < 0 || semid >= MAX_SEMAPHORES || !semaphores[semid].in_use)
    80005c18:	47fd                	li	a5,31
    80005c1a:	04a7e663          	bltu	a5,a0,80005c66 <sem_getvalue+0x58>
    80005c1e:	00551713          	slli	a4,a0,0x5
    80005c22:	0001b797          	auipc	a5,0x1b
    80005c26:	0e678793          	addi	a5,a5,230 # 80020d08 <sem_table_lock>
    80005c2a:	97ba                	add	a5,a5,a4
    80005c2c:	5bdc                	lw	a5,52(a5)
    80005c2e:	cf85                	beqz	a5,80005c66 <sem_getvalue+0x58>
    80005c30:	e04a                	sd	s2,0(sp)
    return -1;
  struct semaphore *sem = &semaphores[semid];

  acquire(&sem->lock);
    80005c32:	00551493          	slli	s1,a0,0x5
    80005c36:	0001b917          	auipc	s2,0x1b
    80005c3a:	0ea90913          	addi	s2,s2,234 # 80020d20 <semaphores>
    80005c3e:	9926                	add	s2,s2,s1
    80005c40:	854a                	mv	a0,s2
    80005c42:	822fb0ef          	jal	80000c64 <acquire>
  int value = sem->value;
    80005c46:	0001b797          	auipc	a5,0x1b
    80005c4a:	0c278793          	addi	a5,a5,194 # 80020d08 <sem_table_lock>
    80005c4e:	97a6                	add	a5,a5,s1
    80005c50:	5b84                	lw	s1,48(a5)
  release(&sem->lock);
    80005c52:	854a                	mv	a0,s2
    80005c54:	8a0fb0ef          	jal	80000cf4 <release>
    80005c58:	6902                	ld	s2,0(sp)

  return value;
}
    80005c5a:	8526                	mv	a0,s1
    80005c5c:	60e2                	ld	ra,24(sp)
    80005c5e:	6442                	ld	s0,16(sp)
    80005c60:	64a2                	ld	s1,8(sp)
    80005c62:	6105                	addi	sp,sp,32
    80005c64:	8082                	ret
    return -1;
    80005c66:	54fd                	li	s1,-1
    80005c68:	bfcd                	j	80005c5a <sem_getvalue+0x4c>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	8282                	jr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
