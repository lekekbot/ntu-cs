kernel/ubuf.o: kernel/ubuf.c kernel/types.h kernel/defs.h kernel/riscv.h
