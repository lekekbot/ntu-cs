kernel/ucnt.o: kernel/ucnt.c kernel/types.h kernel/defs.h kernel/riscv.h
