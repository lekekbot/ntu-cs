user/race_test.o: user/race_test.c user/user.h kernel/types.h
