
user/_race_test:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <sem_basic>:
    } while (0)


int N = 1000;

void sem_basic() {
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	e426                	sd	s1,8(sp)
   8:	1000                	addi	s0,sp,32
    printf("[sem_basic] Initializing semaphore to 1...\n");
   a:	00001517          	auipc	a0,0x1
   e:	da650513          	addi	a0,a0,-602 # db0 <malloc+0xf8>
  12:	3eb000ef          	jal	bfc <printf>
    int semid = sem_init(1);
  16:	4505                	li	a0,1
  18:	01b000ef          	jal	832 <sem_init>
  1c:	84aa                	mv	s1,a0
    T_ASSERT(sem_getvalue(semid) == 1);
  1e:	02d000ef          	jal	84a <sem_getvalue>
  22:	4785                	li	a5,1
  24:	04f51c63          	bne	a0,a5,7c <sem_basic+0x7c>

    printf("[sem_basic] Waiting (should decrement to 0)...\n");
  28:	00001517          	auipc	a0,0x1
  2c:	e1050513          	addi	a0,a0,-496 # e38 <malloc+0x180>
  30:	3cd000ef          	jal	bfc <printf>
    sem_wait(semid);
  34:	8526                	mv	a0,s1
  36:	005000ef          	jal	83a <sem_wait>
    T_ASSERT(sem_getvalue(semid) == 0);
  3a:	8526                	mv	a0,s1
  3c:	00f000ef          	jal	84a <sem_getvalue>
  40:	e125                	bnez	a0,a0 <sem_basic+0xa0>

    printf("[sem_basic] Posting (should increment to 1)...\n");
  42:	00001517          	auipc	a0,0x1
  46:	e4650513          	addi	a0,a0,-442 # e88 <malloc+0x1d0>
  4a:	3b3000ef          	jal	bfc <printf>
    sem_signal(semid);
  4e:	8526                	mv	a0,s1
  50:	7f2000ef          	jal	842 <sem_signal>
    T_ASSERT(sem_getvalue(semid) == 1);
  54:	8526                	mv	a0,s1
  56:	7f4000ef          	jal	84a <sem_getvalue>
  5a:	4785                	li	a5,1
  5c:	06f51463          	bne	a0,a5,c4 <sem_basic+0xc4>

    sem_free(semid);
  60:	8526                	mv	a0,s1
  62:	7f0000ef          	jal	852 <sem_free>
    printf("[sem_basic] PASS: Basic semaphore operations work.\n");
  66:	00001517          	auipc	a0,0x1
  6a:	e5250513          	addi	a0,a0,-430 # eb8 <malloc+0x200>
  6e:	38f000ef          	jal	bfc <printf>
}
  72:	60e2                	ld	ra,24(sp)
  74:	6442                	ld	s0,16(sp)
  76:	64a2                	ld	s1,8(sp)
  78:	6105                	addi	sp,sp,32
  7a:	8082                	ret
    T_ASSERT(sem_getvalue(semid) == 1);
  7c:	00001697          	auipc	a3,0x1
  80:	d6468693          	addi	a3,a3,-668 # de0 <malloc+0x128>
  84:	4645                	li	a2,17
  86:	00001597          	auipc	a1,0x1
  8a:	d7a58593          	addi	a1,a1,-646 # e00 <malloc+0x148>
  8e:	00001517          	auipc	a0,0x1
  92:	d8a50513          	addi	a0,a0,-630 # e18 <malloc+0x160>
  96:	367000ef          	jal	bfc <printf>
  9a:	4505                	li	a0,1
  9c:	6d6000ef          	jal	772 <exit>
    T_ASSERT(sem_getvalue(semid) == 0);
  a0:	00001697          	auipc	a3,0x1
  a4:	dc868693          	addi	a3,a3,-568 # e68 <malloc+0x1b0>
  a8:	4655                	li	a2,21
  aa:	00001597          	auipc	a1,0x1
  ae:	d5658593          	addi	a1,a1,-682 # e00 <malloc+0x148>
  b2:	00001517          	auipc	a0,0x1
  b6:	d6650513          	addi	a0,a0,-666 # e18 <malloc+0x160>
  ba:	343000ef          	jal	bfc <printf>
  be:	4505                	li	a0,1
  c0:	6b2000ef          	jal	772 <exit>
    T_ASSERT(sem_getvalue(semid) == 1);
  c4:	00001697          	auipc	a3,0x1
  c8:	d1c68693          	addi	a3,a3,-740 # de0 <malloc+0x128>
  cc:	4665                	li	a2,25
  ce:	00001597          	auipc	a1,0x1
  d2:	d3258593          	addi	a1,a1,-718 # e00 <malloc+0x148>
  d6:	00001517          	auipc	a0,0x1
  da:	d4250513          	addi	a0,a0,-702 # e18 <malloc+0x160>
  de:	31f000ef          	jal	bfc <printf>
  e2:	4505                	li	a0,1
  e4:	68e000ef          	jal	772 <exit>

00000000000000e8 <do_work>:

void do_work(int pid, int semid) {
    for (int i = 0; i < N; i++) {
  e8:	00002797          	auipc	a5,0x2
  ec:	f187a783          	lw	a5,-232(a5) # 2000 <N>
  f0:	04f05963          	blez	a5,142 <do_work+0x5a>
void do_work(int pid, int semid) {
  f4:	7179                	addi	sp,sp,-48
  f6:	f406                	sd	ra,40(sp)
  f8:	f022                	sd	s0,32(sp)
  fa:	ec26                	sd	s1,24(sp)
  fc:	e84a                	sd	s2,16(sp)
  fe:	e44e                	sd	s3,8(sp)
 100:	1800                	addi	s0,sp,48
 102:	892e                	mv	s2,a1
    for (int i = 0; i < N; i++) {
 104:	4481                	li	s1,0
 106:	00002997          	auipc	s3,0x2
 10a:	efa98993          	addi	s3,s3,-262 # 2000 <N>
        sem_wait(semid);
 10e:	854a                	mv	a0,s2
 110:	72a000ef          	jal	83a <sem_wait>
        int val = ucnt_get(0);
 114:	4501                	li	a0,0
 116:	704000ef          	jal	81a <ucnt_get>
        ucnt_set(0, val + 1);
 11a:	0015059b          	addiw	a1,a0,1
 11e:	4501                	li	a0,0
 120:	6f2000ef          	jal	812 <ucnt_set>
        sem_signal(semid);
 124:	854a                	mv	a0,s2
 126:	71c000ef          	jal	842 <sem_signal>
    for (int i = 0; i < N; i++) {
 12a:	2485                	addiw	s1,s1,1
 12c:	0009a783          	lw	a5,0(s3)
 130:	fcf4cfe3          	blt	s1,a5,10e <do_work+0x26>
    }
}
 134:	70a2                	ld	ra,40(sp)
 136:	7402                	ld	s0,32(sp)
 138:	64e2                	ld	s1,24(sp)
 13a:	6942                	ld	s2,16(sp)
 13c:	69a2                	ld	s3,8(sp)
 13e:	6145                	addi	sp,sp,48
 140:	8082                	ret
 142:	8082                	ret

0000000000000144 <race_test>:

void race_test() {
 144:	7179                	addi	sp,sp,-48
 146:	f406                	sd	ra,40(sp)
 148:	f022                	sd	s0,32(sp)
 14a:	ec26                	sd	s1,24(sp)
 14c:	e84a                	sd	s2,16(sp)
 14e:	e44e                	sd	s3,8(sp)
 150:	1800                	addi	s0,sp,48
    ucnt_set(0, 0);
 152:	4581                	li	a1,0
 154:	4501                	li	a0,0
 156:	6bc000ef          	jal	812 <ucnt_set>
    int semid = sem_init(1); // binary semaphore: mutual exclusion
 15a:	4505                	li	a0,1
 15c:	6d6000ef          	jal	832 <sem_init>
    T_ASSERT(semid >= 0);
 160:	06054963          	bltz	a0,1d2 <race_test+0x8e>
 164:	84aa                	mv	s1,a0

    int pid = fork();
 166:	604000ef          	jal	76a <fork>
    T_ASSERT(pid >= 0);
 16a:	08054763          	bltz	a0,1f8 <race_test+0xb4>
    if (pid == 0) { // child
 16e:	c945                	beqz	a0,21e <race_test+0xda>
        do_work(pid, semid);
        exit(0);
    } else { // parent
        do_work(getpid(), semid);
 170:	682000ef          	jal	7f2 <getpid>
 174:	85a6                	mv	a1,s1
 176:	f73ff0ef          	jal	e8 <do_work>
        wait(0);
 17a:	4501                	li	a0,0
 17c:	5fe000ef          	jal	77a <wait>
        int final = ucnt_get(0);
 180:	4501                	li	a0,0
 182:	698000ef          	jal	81a <ucnt_get>
 186:	89aa                	mv	s3,a0
        printf("[race_test] final counter=%d (expected %d)\n", final, 2*N);
 188:	00002917          	auipc	s2,0x2
 18c:	e7890913          	addi	s2,s2,-392 # 2000 <N>
 190:	00092603          	lw	a2,0(s2)
 194:	0016161b          	slliw	a2,a2,0x1
 198:	85aa                	mv	a1,a0
 19a:	00001517          	auipc	a0,0x1
 19e:	d7650513          	addi	a0,a0,-650 # f10 <malloc+0x258>
 1a2:	25b000ef          	jal	bfc <printf>
        T_ASSERT(final == 2*N);
 1a6:	00092783          	lw	a5,0(s2)
 1aa:	0017979b          	slliw	a5,a5,0x1
 1ae:	07379e63          	bne	a5,s3,22a <race_test+0xe6>
        printf("[race_test] PASS: consistent counter\n");
 1b2:	00001517          	auipc	a0,0x1
 1b6:	d9e50513          	addi	a0,a0,-610 # f50 <malloc+0x298>
 1ba:	243000ef          	jal	bfc <printf>
    }

    sem_free(semid);
 1be:	8526                	mv	a0,s1
 1c0:	692000ef          	jal	852 <sem_free>
}    
 1c4:	70a2                	ld	ra,40(sp)
 1c6:	7402                	ld	s0,32(sp)
 1c8:	64e2                	ld	s1,24(sp)
 1ca:	6942                	ld	s2,16(sp)
 1cc:	69a2                	ld	s3,8(sp)
 1ce:	6145                	addi	sp,sp,48
 1d0:	8082                	ret
    T_ASSERT(semid >= 0);
 1d2:	00001697          	auipc	a3,0x1
 1d6:	d1e68693          	addi	a3,a3,-738 # ef0 <malloc+0x238>
 1da:	02b00613          	li	a2,43
 1de:	00001597          	auipc	a1,0x1
 1e2:	c2258593          	addi	a1,a1,-990 # e00 <malloc+0x148>
 1e6:	00001517          	auipc	a0,0x1
 1ea:	c3250513          	addi	a0,a0,-974 # e18 <malloc+0x160>
 1ee:	20f000ef          	jal	bfc <printf>
 1f2:	4505                	li	a0,1
 1f4:	57e000ef          	jal	772 <exit>
    T_ASSERT(pid >= 0);
 1f8:	00001697          	auipc	a3,0x1
 1fc:	d0868693          	addi	a3,a3,-760 # f00 <malloc+0x248>
 200:	02e00613          	li	a2,46
 204:	00001597          	auipc	a1,0x1
 208:	bfc58593          	addi	a1,a1,-1028 # e00 <malloc+0x148>
 20c:	00001517          	auipc	a0,0x1
 210:	c0c50513          	addi	a0,a0,-1012 # e18 <malloc+0x160>
 214:	1e9000ef          	jal	bfc <printf>
 218:	4505                	li	a0,1
 21a:	558000ef          	jal	772 <exit>
        do_work(pid, semid);
 21e:	85a6                	mv	a1,s1
 220:	ec9ff0ef          	jal	e8 <do_work>
        exit(0);
 224:	4501                	li	a0,0
 226:	54c000ef          	jal	772 <exit>
        T_ASSERT(final == 2*N);
 22a:	00001697          	auipc	a3,0x1
 22e:	d1668693          	addi	a3,a3,-746 # f40 <malloc+0x288>
 232:	03700613          	li	a2,55
 236:	00001597          	auipc	a1,0x1
 23a:	bca58593          	addi	a1,a1,-1078 # e00 <malloc+0x148>
 23e:	00001517          	auipc	a0,0x1
 242:	bda50513          	addi	a0,a0,-1062 # e18 <malloc+0x160>
 246:	1b7000ef          	jal	bfc <printf>
 24a:	4505                	li	a0,1
 24c:	526000ef          	jal	772 <exit>

0000000000000250 <consumer>:
    int empty;   // counts free slots, initialised to UBUF_SLOTS
    int filled;  // counts filled slots, initialised to 0
    int mutex;   // binary semaphore protecting the buffer indices, initialised to 1
};

void consumer(struct buf_sem b, int loops, int valid[]) {
 250:	715d                	addi	sp,sp,-80
 252:	e486                	sd	ra,72(sp)
 254:	e0a2                	sd	s0,64(sp)
 256:	0880                	addi	s0,sp,80
 258:	faa43823          	sd	a0,-80(s0)
 25c:	fab43c23          	sd	a1,-72(s0)
    char tmp;
    for(int i = 0; i < loops; i++) {
 260:	04c05963          	blez	a2,2b2 <consumer+0x62>
 264:	fc26                	sd	s1,56(sp)
 266:	f84a                	sd	s2,48(sp)
 268:	f44e                	sd	s3,40(sp)
 26a:	f052                	sd	s4,32(sp)
 26c:	ec56                	sd	s5,24(sp)
 26e:	8a32                	mv	s4,a2
 270:	8ab6                	mv	s5,a3
 272:	fb842983          	lw	s3,-72(s0)
 276:	4901                	li	s2,0
        sem_wait(b.filled);   // wait until a slot holds data
 278:	fb442503          	lw	a0,-76(s0)
 27c:	5be000ef          	jal	83a <sem_wait>
        sem_wait(b.mutex);    // enter the critical section
 280:	854e                	mv	a0,s3
 282:	5b8000ef          	jal	83a <sem_wait>
        tmp = ubuf_read();
 286:	5a4000ef          	jal	82a <ubuf_read>
 28a:	84aa                	mv	s1,a0
        sem_signal(b.mutex);  // leave the critical section
 28c:	854e                	mv	a0,s3
 28e:	5b4000ef          	jal	842 <sem_signal>
        sem_signal(b.empty);  // one more slot is free
 292:	fb042503          	lw	a0,-80(s0)
 296:	5ac000ef          	jal	842 <sem_signal>
        T_ASSERT(valid[(unsigned char)tmp]);
 29a:	048a                	slli	s1,s1,0x2
 29c:	94d6                	add	s1,s1,s5
 29e:	409c                	lw	a5,0(s1)
 2a0:	cf89                	beqz	a5,2ba <consumer+0x6a>
    for(int i = 0; i < loops; i++) {
 2a2:	2905                	addiw	s2,s2,1
 2a4:	fd2a1ae3          	bne	s4,s2,278 <consumer+0x28>
 2a8:	74e2                	ld	s1,56(sp)
 2aa:	7942                	ld	s2,48(sp)
 2ac:	79a2                	ld	s3,40(sp)
 2ae:	7a02                	ld	s4,32(sp)
 2b0:	6ae2                	ld	s5,24(sp)
    }
}
 2b2:	60a6                	ld	ra,72(sp)
 2b4:	6406                	ld	s0,64(sp)
 2b6:	6161                	addi	sp,sp,80
 2b8:	8082                	ret
        T_ASSERT(valid[(unsigned char)tmp]);
 2ba:	00001697          	auipc	a3,0x1
 2be:	cbe68693          	addi	a3,a3,-834 # f78 <malloc+0x2c0>
 2c2:	04e00613          	li	a2,78
 2c6:	00001597          	auipc	a1,0x1
 2ca:	b3a58593          	addi	a1,a1,-1222 # e00 <malloc+0x148>
 2ce:	00001517          	auipc	a0,0x1
 2d2:	b4a50513          	addi	a0,a0,-1206 # e18 <malloc+0x160>
 2d6:	127000ef          	jal	bfc <printf>
 2da:	4505                	li	a0,1
 2dc:	496000ef          	jal	772 <exit>

00000000000002e0 <producer>:

void producer(const char* msg, struct buf_sem b) {
 2e0:	7179                	addi	sp,sp,-48
 2e2:	f406                	sd	ra,40(sp)
 2e4:	f022                	sd	s0,32(sp)
 2e6:	1800                	addi	s0,sp,48
 2e8:	fcb43823          	sd	a1,-48(s0)
 2ec:	fcc43c23          	sd	a2,-40(s0)
    for (const char* p = msg; *p != '\0'; p++) {
 2f0:	00054783          	lbu	a5,0(a0)
 2f4:	cf95                	beqz	a5,330 <producer+0x50>
 2f6:	ec26                	sd	s1,24(sp)
 2f8:	e84a                	sd	s2,16(sp)
 2fa:	84aa                	mv	s1,a0
 2fc:	fd842903          	lw	s2,-40(s0)
        sem_wait(b.empty);    // wait until a slot is free
 300:	fd042503          	lw	a0,-48(s0)
 304:	536000ef          	jal	83a <sem_wait>
        sem_wait(b.mutex);    // enter the critical section
 308:	854a                	mv	a0,s2
 30a:	530000ef          	jal	83a <sem_wait>
        ubuf_write(*p);
 30e:	0004c503          	lbu	a0,0(s1)
 312:	510000ef          	jal	822 <ubuf_write>
        sem_signal(b.mutex);  // leave the critical section
 316:	854a                	mv	a0,s2
 318:	52a000ef          	jal	842 <sem_signal>
        sem_signal(b.filled); // one more slot holds data
 31c:	fd442503          	lw	a0,-44(s0)
 320:	522000ef          	jal	842 <sem_signal>
    for (const char* p = msg; *p != '\0'; p++) {
 324:	0485                	addi	s1,s1,1
 326:	0004c783          	lbu	a5,0(s1)
 32a:	fbf9                	bnez	a5,300 <producer+0x20>
 32c:	64e2                	ld	s1,24(sp)
 32e:	6942                	ld	s2,16(sp)
    }
}
 330:	70a2                	ld	ra,40(sp)
 332:	7402                	ld	s0,32(sp)
 334:	6145                	addi	sp,sp,48
 336:	8082                	ret

0000000000000338 <producer_consumer>:

void producer_consumer() {
 338:	b8010113          	addi	sp,sp,-1152
 33c:	46113c23          	sd	ra,1144(sp)
 340:	46813823          	sd	s0,1136(sp)
 344:	46913423          	sd	s1,1128(sp)
 348:	47213023          	sd	s2,1120(sp)
 34c:	45313c23          	sd	s3,1112(sp)
 350:	48010413          	addi	s0,sp,1152
    #define MSG_SIZE 48
    const char msg[MSG_SIZE + 1] = "cafefacefacefacefacefacefacefacefacecafecafecafe";
 354:	00001797          	auipc	a5,0x1
 358:	ca478793          	addi	a5,a5,-860 # ff8 <malloc+0x340>
 35c:	6384                	ld	s1,0(a5)
 35e:	678c                	ld	a1,8(a5)
 360:	6b90                	ld	a2,16(a5)
 362:	6f94                	ld	a3,24(a5)
 364:	7398                	ld	a4,32(a5)
 366:	f8943c23          	sd	s1,-104(s0)
 36a:	fab43023          	sd	a1,-96(s0)
 36e:	fac43423          	sd	a2,-88(s0)
 372:	fad43823          	sd	a3,-80(s0)
 376:	fae43c23          	sd	a4,-72(s0)
 37a:	7798                	ld	a4,40(a5)
 37c:	fce43023          	sd	a4,-64(s0)
 380:	0307c783          	lbu	a5,48(a5)
 384:	fcf40423          	sb	a5,-56(s0)
    const int NUM_PROD = 2;
    int valid[256] = {0};
 388:	40000613          	li	a2,1024
 38c:	4581                	li	a1,0
 38e:	b9840513          	addi	a0,s0,-1128
 392:	1e2000ef          	jal	574 <memset>
    for (const char* p = msg; *p != '\0'; p++) {
 396:	0ff4f793          	zext.b	a5,s1
 39a:	cf89                	beqz	a5,3b4 <producer_consumer+0x7c>
 39c:	f9840713          	addi	a4,s0,-104
        unsigned char uc = (unsigned char)*p;
        valid[uc] = 1;
 3a0:	b9840613          	addi	a2,s0,-1128
 3a4:	4685                	li	a3,1
 3a6:	078a                	slli	a5,a5,0x2
 3a8:	97b2                	add	a5,a5,a2
 3aa:	c394                	sw	a3,0(a5)
    for (const char* p = msg; *p != '\0'; p++) {
 3ac:	0705                	addi	a4,a4,1
 3ae:	00074783          	lbu	a5,0(a4)
 3b2:	fbf5                	bnez	a5,3a6 <producer_consumer+0x6e>
    }

    struct buf_sem b;
    b.empty = sem_init(UBUF_SLOTS); // buffer starts empty
 3b4:	4541                	li	a0,16
 3b6:	47c000ef          	jal	832 <sem_init>
 3ba:	84aa                	mv	s1,a0
    b.filled = sem_init(0);         // nothing to consume yet
 3bc:	4501                	li	a0,0
 3be:	474000ef          	jal	832 <sem_init>
 3c2:	892a                	mv	s2,a0
    b.mutex = sem_init(1);          // unlocked
 3c4:	4505                	li	a0,1
 3c6:	46c000ef          	jal	832 <sem_init>
 3ca:	89aa                	mv	s3,a0
    T_ASSERT(b.empty >= 0 && b.filled >= 0 && b.mutex >= 0);
 3cc:	0124e7b3          	or	a5,s1,s2
 3d0:	8fc9                	or	a5,a5,a0
 3d2:	02079713          	slli	a4,a5,0x20
 3d6:	06074e63          	bltz	a4,452 <producer_consumer+0x11a>

    for (int i = 0; i < NUM_PROD; i++) {
        int pid = fork();
 3da:	390000ef          	jal	76a <fork>
        T_ASSERT(pid >= 0);
 3de:	08054d63          	bltz	a0,478 <producer_consumer+0x140>
        if (pid == 0) { // child
 3e2:	cd55                	beqz	a0,49e <producer_consumer+0x166>
        int pid = fork();
 3e4:	386000ef          	jal	76a <fork>
        T_ASSERT(pid >= 0);
 3e8:	08054863          	bltz	a0,478 <producer_consumer+0x140>
        if (pid == 0) { // child
 3ec:	c94d                	beqz	a0,49e <producer_consumer+0x166>
            producer(msg, b);
            exit(0);
        }
    }

    consumer(b, MSG_SIZE * NUM_PROD, valid);
 3ee:	b8942423          	sw	s1,-1144(s0)
 3f2:	b9242623          	sw	s2,-1140(s0)
 3f6:	b9342823          	sw	s3,-1136(s0)
 3fa:	b9840693          	addi	a3,s0,-1128
 3fe:	06000613          	li	a2,96
 402:	b8843503          	ld	a0,-1144(s0)
 406:	b9043583          	ld	a1,-1136(s0)
 40a:	e47ff0ef          	jal	250 <consumer>
    for (int i = 0; i < NUM_PROD; i++) {
        wait(0);
 40e:	4501                	li	a0,0
 410:	36a000ef          	jal	77a <wait>
 414:	4501                	li	a0,0
 416:	364000ef          	jal	77a <wait>
    }
    printf("[producer_consumer] PASS: message delivered\n");
 41a:	00001517          	auipc	a0,0x1
 41e:	bae50513          	addi	a0,a0,-1106 # fc8 <malloc+0x310>
 422:	7da000ef          	jal	bfc <printf>
    sem_free(b.mutex);
 426:	854e                	mv	a0,s3
 428:	42a000ef          	jal	852 <sem_free>
    sem_free(b.filled);
 42c:	854a                	mv	a0,s2
 42e:	424000ef          	jal	852 <sem_free>
    sem_free(b.empty);
 432:	8526                	mv	a0,s1
 434:	41e000ef          	jal	852 <sem_free>
}
 438:	47813083          	ld	ra,1144(sp)
 43c:	47013403          	ld	s0,1136(sp)
 440:	46813483          	ld	s1,1128(sp)
 444:	46013903          	ld	s2,1120(sp)
 448:	45813983          	ld	s3,1112(sp)
 44c:	48010113          	addi	sp,sp,1152
 450:	8082                	ret
    T_ASSERT(b.empty >= 0 && b.filled >= 0 && b.mutex >= 0);
 452:	00001697          	auipc	a3,0x1
 456:	b4668693          	addi	a3,a3,-1210 # f98 <malloc+0x2e0>
 45a:	06a00613          	li	a2,106
 45e:	00001597          	auipc	a1,0x1
 462:	9a258593          	addi	a1,a1,-1630 # e00 <malloc+0x148>
 466:	00001517          	auipc	a0,0x1
 46a:	9b250513          	addi	a0,a0,-1614 # e18 <malloc+0x160>
 46e:	78e000ef          	jal	bfc <printf>
 472:	4505                	li	a0,1
 474:	2fe000ef          	jal	772 <exit>
        T_ASSERT(pid >= 0);
 478:	00001697          	auipc	a3,0x1
 47c:	a8868693          	addi	a3,a3,-1400 # f00 <malloc+0x248>
 480:	06e00613          	li	a2,110
 484:	00001597          	auipc	a1,0x1
 488:	97c58593          	addi	a1,a1,-1668 # e00 <malloc+0x148>
 48c:	00001517          	auipc	a0,0x1
 490:	98c50513          	addi	a0,a0,-1652 # e18 <malloc+0x160>
 494:	768000ef          	jal	bfc <printf>
 498:	4505                	li	a0,1
 49a:	2d8000ef          	jal	772 <exit>
            producer(msg, b);
 49e:	b8942423          	sw	s1,-1144(s0)
 4a2:	b9242623          	sw	s2,-1140(s0)
 4a6:	b9342823          	sw	s3,-1136(s0)
 4aa:	b8843583          	ld	a1,-1144(s0)
 4ae:	b9043603          	ld	a2,-1136(s0)
 4b2:	f9840513          	addi	a0,s0,-104
 4b6:	e2bff0ef          	jal	2e0 <producer>
            exit(0);
 4ba:	4501                	li	a0,0
 4bc:	2b6000ef          	jal	772 <exit>

00000000000004c0 <main>:



int main() {
 4c0:	1141                	addi	sp,sp,-16
 4c2:	e406                	sd	ra,8(sp)
 4c4:	e022                	sd	s0,0(sp)
 4c6:	0800                	addi	s0,sp,16
    sem_basic();
 4c8:	b39ff0ef          	jal	0 <sem_basic>
    
    race_test();
 4cc:	c79ff0ef          	jal	144 <race_test>

    producer_consumer();
 4d0:	e69ff0ef          	jal	338 <producer_consumer>

    printf("ALL TESTS PASSED\n");
 4d4:	00001517          	auipc	a0,0x1
 4d8:	b5c50513          	addi	a0,a0,-1188 # 1030 <malloc+0x378>
 4dc:	720000ef          	jal	bfc <printf>

    exit(0);
 4e0:	4501                	li	a0,0
 4e2:	290000ef          	jal	772 <exit>

00000000000004e6 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 4e6:	1141                	addi	sp,sp,-16
 4e8:	e406                	sd	ra,8(sp)
 4ea:	e022                	sd	s0,0(sp)
 4ec:	0800                	addi	s0,sp,16
  extern int main();
  main();
 4ee:	fd3ff0ef          	jal	4c0 <main>
  exit(0);
 4f2:	4501                	li	a0,0
 4f4:	27e000ef          	jal	772 <exit>

00000000000004f8 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 4f8:	1141                	addi	sp,sp,-16
 4fa:	e406                	sd	ra,8(sp)
 4fc:	e022                	sd	s0,0(sp)
 4fe:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 500:	87aa                	mv	a5,a0
 502:	0585                	addi	a1,a1,1
 504:	0785                	addi	a5,a5,1
 506:	fff5c703          	lbu	a4,-1(a1)
 50a:	fee78fa3          	sb	a4,-1(a5)
 50e:	fb75                	bnez	a4,502 <strcpy+0xa>
    ;
  return os;
}
 510:	60a2                	ld	ra,8(sp)
 512:	6402                	ld	s0,0(sp)
 514:	0141                	addi	sp,sp,16
 516:	8082                	ret

0000000000000518 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 518:	1141                	addi	sp,sp,-16
 51a:	e406                	sd	ra,8(sp)
 51c:	e022                	sd	s0,0(sp)
 51e:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 520:	00054783          	lbu	a5,0(a0)
 524:	cb91                	beqz	a5,538 <strcmp+0x20>
 526:	0005c703          	lbu	a4,0(a1)
 52a:	00f71763          	bne	a4,a5,538 <strcmp+0x20>
    p++, q++;
 52e:	0505                	addi	a0,a0,1
 530:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 532:	00054783          	lbu	a5,0(a0)
 536:	fbe5                	bnez	a5,526 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 538:	0005c503          	lbu	a0,0(a1)
}
 53c:	40a7853b          	subw	a0,a5,a0
 540:	60a2                	ld	ra,8(sp)
 542:	6402                	ld	s0,0(sp)
 544:	0141                	addi	sp,sp,16
 546:	8082                	ret

0000000000000548 <strlen>:

uint
strlen(const char *s)
{
 548:	1141                	addi	sp,sp,-16
 54a:	e406                	sd	ra,8(sp)
 54c:	e022                	sd	s0,0(sp)
 54e:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 550:	00054783          	lbu	a5,0(a0)
 554:	cf91                	beqz	a5,570 <strlen+0x28>
 556:	00150793          	addi	a5,a0,1
 55a:	86be                	mv	a3,a5
 55c:	0785                	addi	a5,a5,1
 55e:	fff7c703          	lbu	a4,-1(a5)
 562:	ff65                	bnez	a4,55a <strlen+0x12>
 564:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 568:	60a2                	ld	ra,8(sp)
 56a:	6402                	ld	s0,0(sp)
 56c:	0141                	addi	sp,sp,16
 56e:	8082                	ret
  for(n = 0; s[n]; n++)
 570:	4501                	li	a0,0
 572:	bfdd                	j	568 <strlen+0x20>

0000000000000574 <memset>:

void*
memset(void *dst, int c, uint n)
{
 574:	1141                	addi	sp,sp,-16
 576:	e406                	sd	ra,8(sp)
 578:	e022                	sd	s0,0(sp)
 57a:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 57c:	ca19                	beqz	a2,592 <memset+0x1e>
 57e:	87aa                	mv	a5,a0
 580:	1602                	slli	a2,a2,0x20
 582:	9201                	srli	a2,a2,0x20
 584:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 588:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 58c:	0785                	addi	a5,a5,1
 58e:	fee79de3          	bne	a5,a4,588 <memset+0x14>
  }
  return dst;
}
 592:	60a2                	ld	ra,8(sp)
 594:	6402                	ld	s0,0(sp)
 596:	0141                	addi	sp,sp,16
 598:	8082                	ret

000000000000059a <strchr>:

char*
strchr(const char *s, char c)
{
 59a:	1141                	addi	sp,sp,-16
 59c:	e406                	sd	ra,8(sp)
 59e:	e022                	sd	s0,0(sp)
 5a0:	0800                	addi	s0,sp,16
  for(; *s; s++)
 5a2:	00054783          	lbu	a5,0(a0)
 5a6:	c799                	beqz	a5,5b4 <strchr+0x1a>
    if(*s == c)
 5a8:	00f58763          	beq	a1,a5,5b6 <strchr+0x1c>
  for(; *s; s++)
 5ac:	0505                	addi	a0,a0,1
 5ae:	00054783          	lbu	a5,0(a0)
 5b2:	fbfd                	bnez	a5,5a8 <strchr+0xe>
      return (char*)s;
  return 0;
 5b4:	4501                	li	a0,0
}
 5b6:	60a2                	ld	ra,8(sp)
 5b8:	6402                	ld	s0,0(sp)
 5ba:	0141                	addi	sp,sp,16
 5bc:	8082                	ret

00000000000005be <gets>:

char*
gets(char *buf, int max)
{
 5be:	711d                	addi	sp,sp,-96
 5c0:	ec86                	sd	ra,88(sp)
 5c2:	e8a2                	sd	s0,80(sp)
 5c4:	e4a6                	sd	s1,72(sp)
 5c6:	e0ca                	sd	s2,64(sp)
 5c8:	fc4e                	sd	s3,56(sp)
 5ca:	f852                	sd	s4,48(sp)
 5cc:	f456                	sd	s5,40(sp)
 5ce:	f05a                	sd	s6,32(sp)
 5d0:	ec5e                	sd	s7,24(sp)
 5d2:	e862                	sd	s8,16(sp)
 5d4:	1080                	addi	s0,sp,96
 5d6:	8baa                	mv	s7,a0
 5d8:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 5da:	892a                	mv	s2,a0
 5dc:	4481                	li	s1,0
    cc = read(0, &c, 1);
 5de:	faf40b13          	addi	s6,s0,-81
 5e2:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 5e4:	8c26                	mv	s8,s1
 5e6:	0014899b          	addiw	s3,s1,1
 5ea:	84ce                	mv	s1,s3
 5ec:	0349d863          	bge	s3,s4,61c <gets+0x5e>
    cc = read(0, &c, 1);
 5f0:	8656                	mv	a2,s5
 5f2:	85da                	mv	a1,s6
 5f4:	4501                	li	a0,0
 5f6:	194000ef          	jal	78a <read>
    if(cc < 1)
 5fa:	02a05163          	blez	a0,61c <gets+0x5e>
      break;
    buf[i++] = c;
 5fe:	faf44783          	lbu	a5,-81(s0)
 602:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 606:	0905                	addi	s2,s2,1
 608:	ff678713          	addi	a4,a5,-10
 60c:	00173713          	seqz	a4,a4
 610:	17cd                	addi	a5,a5,-13
 612:	0017b793          	seqz	a5,a5
 616:	8fd9                	or	a5,a5,a4
 618:	d7f1                	beqz	a5,5e4 <gets+0x26>
    buf[i++] = c;
 61a:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 61c:	9c5e                	add	s8,s8,s7
 61e:	000c0023          	sb	zero,0(s8)
  return buf;
}
 622:	855e                	mv	a0,s7
 624:	60e6                	ld	ra,88(sp)
 626:	6446                	ld	s0,80(sp)
 628:	64a6                	ld	s1,72(sp)
 62a:	6906                	ld	s2,64(sp)
 62c:	79e2                	ld	s3,56(sp)
 62e:	7a42                	ld	s4,48(sp)
 630:	7aa2                	ld	s5,40(sp)
 632:	7b02                	ld	s6,32(sp)
 634:	6be2                	ld	s7,24(sp)
 636:	6c42                	ld	s8,16(sp)
 638:	6125                	addi	sp,sp,96
 63a:	8082                	ret

000000000000063c <stat>:

int
stat(const char *n, struct stat *st)
{
 63c:	1101                	addi	sp,sp,-32
 63e:	ec06                	sd	ra,24(sp)
 640:	e822                	sd	s0,16(sp)
 642:	e04a                	sd	s2,0(sp)
 644:	1000                	addi	s0,sp,32
 646:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 648:	4581                	li	a1,0
 64a:	168000ef          	jal	7b2 <open>
  if(fd < 0)
 64e:	02054263          	bltz	a0,672 <stat+0x36>
 652:	e426                	sd	s1,8(sp)
 654:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 656:	85ca                	mv	a1,s2
 658:	172000ef          	jal	7ca <fstat>
 65c:	892a                	mv	s2,a0
  close(fd);
 65e:	8526                	mv	a0,s1
 660:	13a000ef          	jal	79a <close>
  return r;
 664:	64a2                	ld	s1,8(sp)
}
 666:	854a                	mv	a0,s2
 668:	60e2                	ld	ra,24(sp)
 66a:	6442                	ld	s0,16(sp)
 66c:	6902                	ld	s2,0(sp)
 66e:	6105                	addi	sp,sp,32
 670:	8082                	ret
    return -1;
 672:	57fd                	li	a5,-1
 674:	893e                	mv	s2,a5
 676:	bfc5                	j	666 <stat+0x2a>

0000000000000678 <atoi>:

int
atoi(const char *s)
{
 678:	1141                	addi	sp,sp,-16
 67a:	e406                	sd	ra,8(sp)
 67c:	e022                	sd	s0,0(sp)
 67e:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 680:	00054683          	lbu	a3,0(a0)
 684:	fd06879b          	addiw	a5,a3,-48
 688:	0ff7f793          	zext.b	a5,a5
 68c:	4625                	li	a2,9
 68e:	02f66963          	bltu	a2,a5,6c0 <atoi+0x48>
 692:	872a                	mv	a4,a0
  n = 0;
 694:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 696:	0705                	addi	a4,a4,1
 698:	0025179b          	slliw	a5,a0,0x2
 69c:	9fa9                	addw	a5,a5,a0
 69e:	0017979b          	slliw	a5,a5,0x1
 6a2:	9fb5                	addw	a5,a5,a3
 6a4:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 6a8:	00074683          	lbu	a3,0(a4)
 6ac:	fd06879b          	addiw	a5,a3,-48
 6b0:	0ff7f793          	zext.b	a5,a5
 6b4:	fef671e3          	bgeu	a2,a5,696 <atoi+0x1e>
  return n;
}
 6b8:	60a2                	ld	ra,8(sp)
 6ba:	6402                	ld	s0,0(sp)
 6bc:	0141                	addi	sp,sp,16
 6be:	8082                	ret
  n = 0;
 6c0:	4501                	li	a0,0
 6c2:	bfdd                	j	6b8 <atoi+0x40>

00000000000006c4 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 6c4:	1141                	addi	sp,sp,-16
 6c6:	e406                	sd	ra,8(sp)
 6c8:	e022                	sd	s0,0(sp)
 6ca:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 6cc:	02b57563          	bgeu	a0,a1,6f6 <memmove+0x32>
    while(n-- > 0)
 6d0:	00c05f63          	blez	a2,6ee <memmove+0x2a>
 6d4:	1602                	slli	a2,a2,0x20
 6d6:	9201                	srli	a2,a2,0x20
 6d8:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 6dc:	872a                	mv	a4,a0
      *dst++ = *src++;
 6de:	0585                	addi	a1,a1,1
 6e0:	0705                	addi	a4,a4,1
 6e2:	fff5c683          	lbu	a3,-1(a1)
 6e6:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 6ea:	fee79ae3          	bne	a5,a4,6de <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 6ee:	60a2                	ld	ra,8(sp)
 6f0:	6402                	ld	s0,0(sp)
 6f2:	0141                	addi	sp,sp,16
 6f4:	8082                	ret
    while(n-- > 0)
 6f6:	fec05ce3          	blez	a2,6ee <memmove+0x2a>
    dst += n;
 6fa:	00c50733          	add	a4,a0,a2
    src += n;
 6fe:	95b2                	add	a1,a1,a2
 700:	fff6079b          	addiw	a5,a2,-1
 704:	1782                	slli	a5,a5,0x20
 706:	9381                	srli	a5,a5,0x20
 708:	fff7c793          	not	a5,a5
 70c:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 70e:	15fd                	addi	a1,a1,-1
 710:	177d                	addi	a4,a4,-1
 712:	0005c683          	lbu	a3,0(a1)
 716:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 71a:	fef71ae3          	bne	a4,a5,70e <memmove+0x4a>
 71e:	bfc1                	j	6ee <memmove+0x2a>

0000000000000720 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 720:	1141                	addi	sp,sp,-16
 722:	e406                	sd	ra,8(sp)
 724:	e022                	sd	s0,0(sp)
 726:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 728:	ce19                	beqz	a2,746 <memcmp+0x26>
 72a:	1602                	slli	a2,a2,0x20
 72c:	9201                	srli	a2,a2,0x20
 72e:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 732:	00054783          	lbu	a5,0(a0)
 736:	0005c703          	lbu	a4,0(a1)
 73a:	00e79b63          	bne	a5,a4,750 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
 73e:	0505                	addi	a0,a0,1
    p2++;
 740:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 742:	fed518e3          	bne	a0,a3,732 <memcmp+0x12>
  }
  return 0;
 746:	4501                	li	a0,0
}
 748:	60a2                	ld	ra,8(sp)
 74a:	6402                	ld	s0,0(sp)
 74c:	0141                	addi	sp,sp,16
 74e:	8082                	ret
      return *p1 - *p2;
 750:	40e7853b          	subw	a0,a5,a4
 754:	bfd5                	j	748 <memcmp+0x28>

0000000000000756 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 756:	1141                	addi	sp,sp,-16
 758:	e406                	sd	ra,8(sp)
 75a:	e022                	sd	s0,0(sp)
 75c:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 75e:	f67ff0ef          	jal	6c4 <memmove>
}
 762:	60a2                	ld	ra,8(sp)
 764:	6402                	ld	s0,0(sp)
 766:	0141                	addi	sp,sp,16
 768:	8082                	ret

000000000000076a <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 76a:	4885                	li	a7,1
 ecall
 76c:	00000073          	ecall
 ret
 770:	8082                	ret

0000000000000772 <exit>:
.global exit
exit:
 li a7, SYS_exit
 772:	4889                	li	a7,2
 ecall
 774:	00000073          	ecall
 ret
 778:	8082                	ret

000000000000077a <wait>:
.global wait
wait:
 li a7, SYS_wait
 77a:	488d                	li	a7,3
 ecall
 77c:	00000073          	ecall
 ret
 780:	8082                	ret

0000000000000782 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 782:	4891                	li	a7,4
 ecall
 784:	00000073          	ecall
 ret
 788:	8082                	ret

000000000000078a <read>:
.global read
read:
 li a7, SYS_read
 78a:	4895                	li	a7,5
 ecall
 78c:	00000073          	ecall
 ret
 790:	8082                	ret

0000000000000792 <write>:
.global write
write:
 li a7, SYS_write
 792:	48c1                	li	a7,16
 ecall
 794:	00000073          	ecall
 ret
 798:	8082                	ret

000000000000079a <close>:
.global close
close:
 li a7, SYS_close
 79a:	48d5                	li	a7,21
 ecall
 79c:	00000073          	ecall
 ret
 7a0:	8082                	ret

00000000000007a2 <kill>:
.global kill
kill:
 li a7, SYS_kill
 7a2:	4899                	li	a7,6
 ecall
 7a4:	00000073          	ecall
 ret
 7a8:	8082                	ret

00000000000007aa <exec>:
.global exec
exec:
 li a7, SYS_exec
 7aa:	489d                	li	a7,7
 ecall
 7ac:	00000073          	ecall
 ret
 7b0:	8082                	ret

00000000000007b2 <open>:
.global open
open:
 li a7, SYS_open
 7b2:	48bd                	li	a7,15
 ecall
 7b4:	00000073          	ecall
 ret
 7b8:	8082                	ret

00000000000007ba <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 7ba:	48c5                	li	a7,17
 ecall
 7bc:	00000073          	ecall
 ret
 7c0:	8082                	ret

00000000000007c2 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 7c2:	48c9                	li	a7,18
 ecall
 7c4:	00000073          	ecall
 ret
 7c8:	8082                	ret

00000000000007ca <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 7ca:	48a1                	li	a7,8
 ecall
 7cc:	00000073          	ecall
 ret
 7d0:	8082                	ret

00000000000007d2 <link>:
.global link
link:
 li a7, SYS_link
 7d2:	48cd                	li	a7,19
 ecall
 7d4:	00000073          	ecall
 ret
 7d8:	8082                	ret

00000000000007da <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 7da:	48d1                	li	a7,20
 ecall
 7dc:	00000073          	ecall
 ret
 7e0:	8082                	ret

00000000000007e2 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 7e2:	48a5                	li	a7,9
 ecall
 7e4:	00000073          	ecall
 ret
 7e8:	8082                	ret

00000000000007ea <dup>:
.global dup
dup:
 li a7, SYS_dup
 7ea:	48a9                	li	a7,10
 ecall
 7ec:	00000073          	ecall
 ret
 7f0:	8082                	ret

00000000000007f2 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 7f2:	48ad                	li	a7,11
 ecall
 7f4:	00000073          	ecall
 ret
 7f8:	8082                	ret

00000000000007fa <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
 7fa:	48b1                	li	a7,12
 ecall
 7fc:	00000073          	ecall
 ret
 800:	8082                	ret

0000000000000802 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
 802:	48b5                	li	a7,13
 ecall
 804:	00000073          	ecall
 ret
 808:	8082                	ret

000000000000080a <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 80a:	48b9                	li	a7,14
 ecall
 80c:	00000073          	ecall
 ret
 810:	8082                	ret

0000000000000812 <ucnt_set>:
.global ucnt_set
ucnt_set:
 li a7, SYS_ucnt_set
 812:	48d9                	li	a7,22
 ecall
 814:	00000073          	ecall
 ret
 818:	8082                	ret

000000000000081a <ucnt_get>:
.global ucnt_get
ucnt_get:
 li a7, SYS_ucnt_get
 81a:	48dd                	li	a7,23
 ecall
 81c:	00000073          	ecall
 ret
 820:	8082                	ret

0000000000000822 <ubuf_write>:
.global ubuf_write
ubuf_write:
 li a7, SYS_ubuf_write
 822:	48e1                	li	a7,24
 ecall
 824:	00000073          	ecall
 ret
 828:	8082                	ret

000000000000082a <ubuf_read>:
.global ubuf_read
ubuf_read:
 li a7, SYS_ubuf_read
 82a:	48e5                	li	a7,25
 ecall
 82c:	00000073          	ecall
 ret
 830:	8082                	ret

0000000000000832 <sem_init>:
.global sem_init
sem_init:
 li a7, SYS_sem_init
 832:	48e9                	li	a7,26
 ecall
 834:	00000073          	ecall
 ret
 838:	8082                	ret

000000000000083a <sem_wait>:
.global sem_wait
sem_wait:
 li a7, SYS_sem_wait
 83a:	48ed                	li	a7,27
 ecall
 83c:	00000073          	ecall
 ret
 840:	8082                	ret

0000000000000842 <sem_signal>:
.global sem_signal
sem_signal:
 li a7, SYS_sem_signal
 842:	48f1                	li	a7,28
 ecall
 844:	00000073          	ecall
 ret
 848:	8082                	ret

000000000000084a <sem_getvalue>:
.global sem_getvalue
sem_getvalue:
 li a7, SYS_sem_getvalue
 84a:	48f5                	li	a7,29
 ecall
 84c:	00000073          	ecall
 ret
 850:	8082                	ret

0000000000000852 <sem_free>:
.global sem_free
sem_free:
 li a7, SYS_sem_free
 852:	48f9                	li	a7,30
 ecall
 854:	00000073          	ecall
 ret
 858:	8082                	ret

000000000000085a <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 85a:	1101                	addi	sp,sp,-32
 85c:	ec06                	sd	ra,24(sp)
 85e:	e822                	sd	s0,16(sp)
 860:	1000                	addi	s0,sp,32
 862:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 866:	4605                	li	a2,1
 868:	fef40593          	addi	a1,s0,-17
 86c:	f27ff0ef          	jal	792 <write>
}
 870:	60e2                	ld	ra,24(sp)
 872:	6442                	ld	s0,16(sp)
 874:	6105                	addi	sp,sp,32
 876:	8082                	ret

0000000000000878 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 878:	715d                	addi	sp,sp,-80
 87a:	e486                	sd	ra,72(sp)
 87c:	e0a2                	sd	s0,64(sp)
 87e:	f84a                	sd	s2,48(sp)
 880:	f44e                	sd	s3,40(sp)
 882:	0880                	addi	s0,sp,80
 884:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 886:	00d036b3          	snez	a3,a3
 88a:	03f5d793          	srli	a5,a1,0x3f
 88e:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
 890:	0005871b          	sext.w	a4,a1
  neg = 0;
 894:	4301                	li	t1,0
  if(sgn && xx < 0){
 896:	c681                	beqz	a3,89e <printint+0x26>
    x = -xx;
 898:	40b0073b          	negw	a4,a1
    neg = 1;
 89c:	4305                	li	t1,1
  }

  i = 0;
 89e:	fb840993          	addi	s3,s0,-72
  neg = 0;
 8a2:	85ce                	mv	a1,s3
  i = 0;
 8a4:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
 8a6:	00000817          	auipc	a6,0x0
 8aa:	7aa80813          	addi	a6,a6,1962 # 1050 <digits>
 8ae:	88b6                	mv	a7,a3
 8b0:	0016851b          	addiw	a0,a3,1
 8b4:	86aa                	mv	a3,a0
 8b6:	02c777bb          	remuw	a5,a4,a2
 8ba:	1782                	slli	a5,a5,0x20
 8bc:	9381                	srli	a5,a5,0x20
 8be:	97c2                	add	a5,a5,a6
 8c0:	0007c783          	lbu	a5,0(a5)
 8c4:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
 8c8:	87ba                	mv	a5,a4
 8ca:	02c7573b          	divuw	a4,a4,a2
 8ce:	0585                	addi	a1,a1,1
 8d0:	fcc7ffe3          	bgeu	a5,a2,8ae <printint+0x36>
  if(neg)
 8d4:	00030b63          	beqz	t1,8ea <printint+0x72>
    buf[i++] = '-';
 8d8:	fd040793          	addi	a5,s0,-48
 8dc:	953e                	add	a0,a0,a5
 8de:	02d00793          	li	a5,45
 8e2:	fef50423          	sb	a5,-24(a0)
 8e6:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
 8ea:	02d05563          	blez	a3,914 <printint+0x9c>
 8ee:	fc26                	sd	s1,56(sp)
 8f0:	36fd                	addiw	a3,a3,-1
 8f2:	00d984b3          	add	s1,s3,a3
 8f6:	19fd                	addi	s3,s3,-1
 8f8:	99b6                	add	s3,s3,a3
 8fa:	1682                	slli	a3,a3,0x20
 8fc:	9281                	srli	a3,a3,0x20
 8fe:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
 902:	0004c583          	lbu	a1,0(s1)
 906:	854a                	mv	a0,s2
 908:	f53ff0ef          	jal	85a <putc>
  while(--i >= 0)
 90c:	14fd                	addi	s1,s1,-1
 90e:	ff349ae3          	bne	s1,s3,902 <printint+0x8a>
 912:	74e2                	ld	s1,56(sp)
}
 914:	60a6                	ld	ra,72(sp)
 916:	6406                	ld	s0,64(sp)
 918:	7942                	ld	s2,48(sp)
 91a:	79a2                	ld	s3,40(sp)
 91c:	6161                	addi	sp,sp,80
 91e:	8082                	ret

0000000000000920 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 920:	711d                	addi	sp,sp,-96
 922:	ec86                	sd	ra,88(sp)
 924:	e8a2                	sd	s0,80(sp)
 926:	e4a6                	sd	s1,72(sp)
 928:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 92a:	0005c483          	lbu	s1,0(a1)
 92e:	28048263          	beqz	s1,bb2 <vprintf+0x292>
 932:	e0ca                	sd	s2,64(sp)
 934:	fc4e                	sd	s3,56(sp)
 936:	f852                	sd	s4,48(sp)
 938:	f456                	sd	s5,40(sp)
 93a:	f05a                	sd	s6,32(sp)
 93c:	ec5e                	sd	s7,24(sp)
 93e:	e862                	sd	s8,16(sp)
 940:	8b2a                	mv	s6,a0
 942:	8a2e                	mv	s4,a1
 944:	8bb2                	mv	s7,a2
  state = 0;
 946:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 948:	4901                	li	s2,0
 94a:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 94c:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 950:	06400c13          	li	s8,100
 954:	a00d                	j	976 <vprintf+0x56>
        putc(fd, c0);
 956:	85a6                	mv	a1,s1
 958:	855a                	mv	a0,s6
 95a:	f01ff0ef          	jal	85a <putc>
 95e:	a019                	j	964 <vprintf+0x44>
    } else if(state == '%'){
 960:	03598363          	beq	s3,s5,986 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 964:	0019079b          	addiw	a5,s2,1
 968:	893e                	mv	s2,a5
 96a:	873e                	mv	a4,a5
 96c:	97d2                	add	a5,a5,s4
 96e:	0007c483          	lbu	s1,0(a5)
 972:	22048963          	beqz	s1,ba4 <vprintf+0x284>
    c0 = fmt[i] & 0xff;
 976:	0004879b          	sext.w	a5,s1
    if(state == 0){
 97a:	fe0993e3          	bnez	s3,960 <vprintf+0x40>
      if(c0 == '%'){
 97e:	fd579ce3          	bne	a5,s5,956 <vprintf+0x36>
        state = '%';
 982:	89be                	mv	s3,a5
 984:	b7c5                	j	964 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 986:	00ea06b3          	add	a3,s4,a4
 98a:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 98e:	22060763          	beqz	a2,bbc <vprintf+0x29c>
      if(c0 == 'd'){
 992:	0b878363          	beq	a5,s8,a38 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 996:	f9478693          	addi	a3,a5,-108
 99a:	0016b693          	seqz	a3,a3
 99e:	f9c60593          	addi	a1,a2,-100
 9a2:	0015b593          	seqz	a1,a1
 9a6:	8df5                	and	a1,a1,a3
 9a8:	e5c5                	bnez	a1,a50 <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
 9aa:	9752                	add	a4,a4,s4
 9ac:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 9b0:	f9460713          	addi	a4,a2,-108
 9b4:	00173713          	seqz	a4,a4
 9b8:	8f75                	and	a4,a4,a3
 9ba:	f9c50593          	addi	a1,a0,-100
 9be:	0015b593          	seqz	a1,a1
 9c2:	8df9                	and	a1,a1,a4
 9c4:	e1dd                	bnez	a1,a6a <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
 9c6:	07500593          	li	a1,117
 9ca:	0ab78d63          	beq	a5,a1,a84 <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
 9ce:	f8b60593          	addi	a1,a2,-117
 9d2:	0015b593          	seqz	a1,a1
 9d6:	8df5                	and	a1,a1,a3
 9d8:	e1f1                	bnez	a1,a9c <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 9da:	f8b50593          	addi	a1,a0,-117
 9de:	0015b593          	seqz	a1,a1
 9e2:	8df9                	and	a1,a1,a4
 9e4:	e9e9                	bnez	a1,ab6 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
 9e6:	07800593          	li	a1,120
 9ea:	0eb78363          	beq	a5,a1,ad0 <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
 9ee:	f8860613          	addi	a2,a2,-120
 9f2:	00163613          	seqz	a2,a2
 9f6:	8ef1                	and	a3,a3,a2
 9f8:	0e069863          	bnez	a3,ae8 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 9fc:	f8850513          	addi	a0,a0,-120
 a00:	00153513          	seqz	a0,a0
 a04:	8f69                	and	a4,a4,a0
 a06:	0e071e63          	bnez	a4,b02 <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
 a0a:	07000713          	li	a4,112
 a0e:	10e78663          	beq	a5,a4,b1a <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
 a12:	07300713          	li	a4,115
 a16:	14e78663          	beq	a5,a4,b62 <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
 a1a:	02500713          	li	a4,37
 a1e:	16e78e63          	beq	a5,a4,b9a <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 a22:	02500593          	li	a1,37
 a26:	855a                	mv	a0,s6
 a28:	e33ff0ef          	jal	85a <putc>
        putc(fd, c0);
 a2c:	85a6                	mv	a1,s1
 a2e:	855a                	mv	a0,s6
 a30:	e2bff0ef          	jal	85a <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
 a34:	4981                	li	s3,0
 a36:	b73d                	j	964 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 a38:	008b8493          	addi	s1,s7,8
 a3c:	4685                	li	a3,1
 a3e:	4629                	li	a2,10
 a40:	000ba583          	lw	a1,0(s7)
 a44:	855a                	mv	a0,s6
 a46:	e33ff0ef          	jal	878 <printint>
 a4a:	8ba6                	mv	s7,s1
      state = 0;
 a4c:	4981                	li	s3,0
 a4e:	bf19                	j	964 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 a50:	008b8493          	addi	s1,s7,8
 a54:	4685                	li	a3,1
 a56:	4629                	li	a2,10
 a58:	000bb583          	ld	a1,0(s7)
 a5c:	855a                	mv	a0,s6
 a5e:	e1bff0ef          	jal	878 <printint>
        i += 1;
 a62:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 a64:	8ba6                	mv	s7,s1
      state = 0;
 a66:	4981                	li	s3,0
 a68:	bdf5                	j	964 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
 a6a:	008b8493          	addi	s1,s7,8
 a6e:	4685                	li	a3,1
 a70:	4629                	li	a2,10
 a72:	000bb583          	ld	a1,0(s7)
 a76:	855a                	mv	a0,s6
 a78:	e01ff0ef          	jal	878 <printint>
        i += 2;
 a7c:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 a7e:	8ba6                	mv	s7,s1
      state = 0;
 a80:	4981                	li	s3,0
        i += 2;
 a82:	b5cd                	j	964 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
 a84:	008b8493          	addi	s1,s7,8
 a88:	4681                	li	a3,0
 a8a:	4629                	li	a2,10
 a8c:	000ba583          	lw	a1,0(s7)
 a90:	855a                	mv	a0,s6
 a92:	de7ff0ef          	jal	878 <printint>
 a96:	8ba6                	mv	s7,s1
      state = 0;
 a98:	4981                	li	s3,0
 a9a:	b5e9                	j	964 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 a9c:	008b8493          	addi	s1,s7,8
 aa0:	4681                	li	a3,0
 aa2:	4629                	li	a2,10
 aa4:	000bb583          	ld	a1,0(s7)
 aa8:	855a                	mv	a0,s6
 aaa:	dcfff0ef          	jal	878 <printint>
        i += 1;
 aae:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 ab0:	8ba6                	mv	s7,s1
      state = 0;
 ab2:	4981                	li	s3,0
 ab4:	bd45                	j	964 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 ab6:	008b8493          	addi	s1,s7,8
 aba:	4681                	li	a3,0
 abc:	4629                	li	a2,10
 abe:	000bb583          	ld	a1,0(s7)
 ac2:	855a                	mv	a0,s6
 ac4:	db5ff0ef          	jal	878 <printint>
        i += 2;
 ac8:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 aca:	8ba6                	mv	s7,s1
      state = 0;
 acc:	4981                	li	s3,0
        i += 2;
 ace:	bd59                	j	964 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
 ad0:	008b8493          	addi	s1,s7,8
 ad4:	4681                	li	a3,0
 ad6:	4641                	li	a2,16
 ad8:	000ba583          	lw	a1,0(s7)
 adc:	855a                	mv	a0,s6
 ade:	d9bff0ef          	jal	878 <printint>
 ae2:	8ba6                	mv	s7,s1
      state = 0;
 ae4:	4981                	li	s3,0
 ae6:	bdbd                	j	964 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 ae8:	008b8493          	addi	s1,s7,8
 aec:	4681                	li	a3,0
 aee:	4641                	li	a2,16
 af0:	000bb583          	ld	a1,0(s7)
 af4:	855a                	mv	a0,s6
 af6:	d83ff0ef          	jal	878 <printint>
        i += 1;
 afa:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 afc:	8ba6                	mv	s7,s1
      state = 0;
 afe:	4981                	li	s3,0
 b00:	b595                	j	964 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 b02:	008b8493          	addi	s1,s7,8
 b06:	4641                	li	a2,16
 b08:	000bb583          	ld	a1,0(s7)
 b0c:	855a                	mv	a0,s6
 b0e:	d6bff0ef          	jal	878 <printint>
        i += 2;
 b12:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 b14:	8ba6                	mv	s7,s1
      state = 0;
 b16:	4981                	li	s3,0
        i += 2;
 b18:	b5b1                	j	964 <vprintf+0x44>
 b1a:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 b1c:	008b8793          	addi	a5,s7,8
 b20:	8cbe                	mv	s9,a5
 b22:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 b26:	03000593          	li	a1,48
 b2a:	855a                	mv	a0,s6
 b2c:	d2fff0ef          	jal	85a <putc>
  putc(fd, 'x');
 b30:	07800593          	li	a1,120
 b34:	855a                	mv	a0,s6
 b36:	d25ff0ef          	jal	85a <putc>
 b3a:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 b3c:	00000b97          	auipc	s7,0x0
 b40:	514b8b93          	addi	s7,s7,1300 # 1050 <digits>
 b44:	03c9d793          	srli	a5,s3,0x3c
 b48:	97de                	add	a5,a5,s7
 b4a:	0007c583          	lbu	a1,0(a5)
 b4e:	855a                	mv	a0,s6
 b50:	d0bff0ef          	jal	85a <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 b54:	0992                	slli	s3,s3,0x4
 b56:	34fd                	addiw	s1,s1,-1
 b58:	f4f5                	bnez	s1,b44 <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
 b5a:	8be6                	mv	s7,s9
      state = 0;
 b5c:	4981                	li	s3,0
 b5e:	6ca2                	ld	s9,8(sp)
 b60:	b511                	j	964 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 b62:	008b8993          	addi	s3,s7,8
 b66:	000bb483          	ld	s1,0(s7)
 b6a:	cc91                	beqz	s1,b86 <vprintf+0x266>
        for(; *s; s++)
 b6c:	0004c583          	lbu	a1,0(s1)
 b70:	c195                	beqz	a1,b94 <vprintf+0x274>
          putc(fd, *s);
 b72:	855a                	mv	a0,s6
 b74:	ce7ff0ef          	jal	85a <putc>
        for(; *s; s++)
 b78:	0485                	addi	s1,s1,1
 b7a:	0004c583          	lbu	a1,0(s1)
 b7e:	f9f5                	bnez	a1,b72 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 b80:	8bce                	mv	s7,s3
      state = 0;
 b82:	4981                	li	s3,0
 b84:	b3c5                	j	964 <vprintf+0x44>
          s = "(null)";
 b86:	00000497          	auipc	s1,0x0
 b8a:	4c248493          	addi	s1,s1,1218 # 1048 <malloc+0x390>
        for(; *s; s++)
 b8e:	02800593          	li	a1,40
 b92:	b7c5                	j	b72 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
 b94:	8bce                	mv	s7,s3
      state = 0;
 b96:	4981                	li	s3,0
 b98:	b3f1                	j	964 <vprintf+0x44>
        putc(fd, '%');
 b9a:	85be                	mv	a1,a5
 b9c:	855a                	mv	a0,s6
 b9e:	cbdff0ef          	jal	85a <putc>
 ba2:	bd49                	j	a34 <vprintf+0x114>
 ba4:	6906                	ld	s2,64(sp)
 ba6:	79e2                	ld	s3,56(sp)
 ba8:	7a42                	ld	s4,48(sp)
 baa:	7aa2                	ld	s5,40(sp)
 bac:	7b02                	ld	s6,32(sp)
 bae:	6be2                	ld	s7,24(sp)
 bb0:	6c42                	ld	s8,16(sp)
    }
  }
}
 bb2:	60e6                	ld	ra,88(sp)
 bb4:	6446                	ld	s0,80(sp)
 bb6:	64a6                	ld	s1,72(sp)
 bb8:	6125                	addi	sp,sp,96
 bba:	8082                	ret
      if(c0 == 'd'){
 bbc:	06400713          	li	a4,100
 bc0:	e6e78ce3          	beq	a5,a4,a38 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
 bc4:	f9478693          	addi	a3,a5,-108
 bc8:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 bcc:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 bce:	4701                	li	a4,0
 bd0:	bbdd                	j	9c6 <vprintf+0xa6>

0000000000000bd2 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 bd2:	715d                	addi	sp,sp,-80
 bd4:	ec06                	sd	ra,24(sp)
 bd6:	e822                	sd	s0,16(sp)
 bd8:	1000                	addi	s0,sp,32
 bda:	e010                	sd	a2,0(s0)
 bdc:	e414                	sd	a3,8(s0)
 bde:	e818                	sd	a4,16(s0)
 be0:	ec1c                	sd	a5,24(s0)
 be2:	03043023          	sd	a6,32(s0)
 be6:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 bea:	8622                	mv	a2,s0
 bec:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 bf0:	d31ff0ef          	jal	920 <vprintf>
}
 bf4:	60e2                	ld	ra,24(sp)
 bf6:	6442                	ld	s0,16(sp)
 bf8:	6161                	addi	sp,sp,80
 bfa:	8082                	ret

0000000000000bfc <printf>:

void
printf(const char *fmt, ...)
{
 bfc:	711d                	addi	sp,sp,-96
 bfe:	ec06                	sd	ra,24(sp)
 c00:	e822                	sd	s0,16(sp)
 c02:	1000                	addi	s0,sp,32
 c04:	e40c                	sd	a1,8(s0)
 c06:	e810                	sd	a2,16(s0)
 c08:	ec14                	sd	a3,24(s0)
 c0a:	f018                	sd	a4,32(s0)
 c0c:	f41c                	sd	a5,40(s0)
 c0e:	03043823          	sd	a6,48(s0)
 c12:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 c16:	00840613          	addi	a2,s0,8
 c1a:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 c1e:	85aa                	mv	a1,a0
 c20:	4505                	li	a0,1
 c22:	cffff0ef          	jal	920 <vprintf>
}
 c26:	60e2                	ld	ra,24(sp)
 c28:	6442                	ld	s0,16(sp)
 c2a:	6125                	addi	sp,sp,96
 c2c:	8082                	ret

0000000000000c2e <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 c2e:	1141                	addi	sp,sp,-16
 c30:	e406                	sd	ra,8(sp)
 c32:	e022                	sd	s0,0(sp)
 c34:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 c36:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 c3a:	00001797          	auipc	a5,0x1
 c3e:	3d67b783          	ld	a5,982(a5) # 2010 <freep>
 c42:	a095                	j	ca6 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
 c44:	ff852583          	lw	a1,-8(a0)
 c48:	6390                	ld	a2,0(a5)
 c4a:	02059813          	slli	a6,a1,0x20
 c4e:	01c85693          	srli	a3,a6,0x1c
 c52:	96ba                	add	a3,a3,a4
 c54:	02d60563          	beq	a2,a3,c7e <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 c58:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 c5c:	4790                	lw	a2,8(a5)
 c5e:	02061593          	slli	a1,a2,0x20
 c62:	01c5d693          	srli	a3,a1,0x1c
 c66:	96be                	add	a3,a3,a5
 c68:	02d70263          	beq	a4,a3,c8c <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 c6c:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 c6e:	00001717          	auipc	a4,0x1
 c72:	3af73123          	sd	a5,930(a4) # 2010 <freep>
}
 c76:	60a2                	ld	ra,8(sp)
 c78:	6402                	ld	s0,0(sp)
 c7a:	0141                	addi	sp,sp,16
 c7c:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 c7e:	4614                	lw	a3,8(a2)
 c80:	9ead                	addw	a3,a3,a1
 c82:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 c86:	6394                	ld	a3,0(a5)
 c88:	6290                	ld	a2,0(a3)
 c8a:	b7f9                	j	c58 <free+0x2a>
    p->s.size += bp->s.size;
 c8c:	ff852703          	lw	a4,-8(a0)
 c90:	9f31                	addw	a4,a4,a2
 c92:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 c94:	ff053703          	ld	a4,-16(a0)
 c98:	bfd1                	j	c6c <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 c9a:	6394                	ld	a3,0(a5)
 c9c:	00d7e463          	bltu	a5,a3,ca4 <free+0x76>
 ca0:	fad762e3          	bltu	a4,a3,c44 <free+0x16>
 ca4:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 ca6:	fee7fae3          	bgeu	a5,a4,c9a <free+0x6c>
 caa:	6394                	ld	a3,0(a5)
 cac:	f8d76ce3          	bltu	a4,a3,c44 <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 cb0:	f8d7fae3          	bgeu	a5,a3,c44 <free+0x16>
 cb4:	87b6                	mv	a5,a3
 cb6:	bfc5                	j	ca6 <free+0x78>

0000000000000cb8 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 cb8:	7139                	addi	sp,sp,-64
 cba:	fc06                	sd	ra,56(sp)
 cbc:	f822                	sd	s0,48(sp)
 cbe:	f04a                	sd	s2,32(sp)
 cc0:	ec4e                	sd	s3,24(sp)
 cc2:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 cc4:	02051993          	slli	s3,a0,0x20
 cc8:	0209d993          	srli	s3,s3,0x20
 ccc:	09bd                	addi	s3,s3,15
 cce:	0049d993          	srli	s3,s3,0x4
 cd2:	2985                	addiw	s3,s3,1
 cd4:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 cd6:	00001517          	auipc	a0,0x1
 cda:	33a53503          	ld	a0,826(a0) # 2010 <freep>
 cde:	c905                	beqz	a0,d0e <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 ce0:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 ce2:	4798                	lw	a4,8(a5)
 ce4:	09377663          	bgeu	a4,s3,d70 <malloc+0xb8>
 ce8:	f426                	sd	s1,40(sp)
 cea:	e852                	sd	s4,16(sp)
 cec:	e456                	sd	s5,8(sp)
 cee:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 cf0:	8a4e                	mv	s4,s3
 cf2:	6705                	lui	a4,0x1
 cf4:	00e9f363          	bgeu	s3,a4,cfa <malloc+0x42>
 cf8:	6a05                	lui	s4,0x1
 cfa:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 cfe:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 d02:	00001497          	auipc	s1,0x1
 d06:	30e48493          	addi	s1,s1,782 # 2010 <freep>
  if(p == (char*)-1)
 d0a:	5afd                	li	s5,-1
 d0c:	a83d                	j	d4a <malloc+0x92>
 d0e:	f426                	sd	s1,40(sp)
 d10:	e852                	sd	s4,16(sp)
 d12:	e456                	sd	s5,8(sp)
 d14:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 d16:	00001797          	auipc	a5,0x1
 d1a:	30a78793          	addi	a5,a5,778 # 2020 <base>
 d1e:	00001717          	auipc	a4,0x1
 d22:	2ef73923          	sd	a5,754(a4) # 2010 <freep>
 d26:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 d28:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 d2c:	b7d1                	j	cf0 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 d2e:	6398                	ld	a4,0(a5)
 d30:	e118                	sd	a4,0(a0)
 d32:	a899                	j	d88 <malloc+0xd0>
  hp->s.size = nu;
 d34:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 d38:	0541                	addi	a0,a0,16
 d3a:	ef5ff0ef          	jal	c2e <free>
  return freep;
 d3e:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 d40:	c125                	beqz	a0,da0 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 d42:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 d44:	4798                	lw	a4,8(a5)
 d46:	03277163          	bgeu	a4,s2,d68 <malloc+0xb0>
    if(p == freep)
 d4a:	6098                	ld	a4,0(s1)
 d4c:	853e                	mv	a0,a5
 d4e:	fef71ae3          	bne	a4,a5,d42 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 d52:	8552                	mv	a0,s4
 d54:	aa7ff0ef          	jal	7fa <sbrk>
  if(p == (char*)-1)
 d58:	fd551ee3          	bne	a0,s5,d34 <malloc+0x7c>
        return 0;
 d5c:	4501                	li	a0,0
 d5e:	74a2                	ld	s1,40(sp)
 d60:	6a42                	ld	s4,16(sp)
 d62:	6aa2                	ld	s5,8(sp)
 d64:	6b02                	ld	s6,0(sp)
 d66:	a03d                	j	d94 <malloc+0xdc>
 d68:	74a2                	ld	s1,40(sp)
 d6a:	6a42                	ld	s4,16(sp)
 d6c:	6aa2                	ld	s5,8(sp)
 d6e:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 d70:	fae90fe3          	beq	s2,a4,d2e <malloc+0x76>
        p->s.size -= nunits;
 d74:	4137073b          	subw	a4,a4,s3
 d78:	c798                	sw	a4,8(a5)
        p += p->s.size;
 d7a:	02071693          	slli	a3,a4,0x20
 d7e:	01c6d713          	srli	a4,a3,0x1c
 d82:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 d84:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 d88:	00001717          	auipc	a4,0x1
 d8c:	28a73423          	sd	a0,648(a4) # 2010 <freep>
      return (void*)(p + 1);
 d90:	01078513          	addi	a0,a5,16
  }
}
 d94:	70e2                	ld	ra,56(sp)
 d96:	7442                	ld	s0,48(sp)
 d98:	7902                	ld	s2,32(sp)
 d9a:	69e2                	ld	s3,24(sp)
 d9c:	6121                	addi	sp,sp,64
 d9e:	8082                	ret
 da0:	74a2                	ld	s1,40(sp)
 da2:	6a42                	ld	s4,16(sp)
 da4:	6aa2                	ld	s5,8(sp)
 da6:	6b02                	ld	s6,0(sp)
 da8:	b7f5                	j	d94 <malloc+0xdc>
