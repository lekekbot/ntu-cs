
user/_grind:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <do_rand>:
#include "kernel/riscv.h"

// from FreeBSD.
int
do_rand(unsigned long *ctx)
{
       0:	1141                	addi	sp,sp,-16
       2:	e406                	sd	ra,8(sp)
       4:	e022                	sd	s0,0(sp)
       6:	0800                	addi	s0,sp,16
 * October 1988, p. 1195.
 */
    long hi, lo, x;

    /* Transform to [1, 0x7ffffffe] range. */
    x = (*ctx % 0x7ffffffe) + 1;
       8:	611c                	ld	a5,0(a0)
       a:	0017d693          	srli	a3,a5,0x1
       e:	c0000737          	lui	a4,0xc0000
      12:	0705                	addi	a4,a4,1 # ffffffffc0000001 <base+0xffffffffbfffdbf9>
      14:	1706                	slli	a4,a4,0x21
      16:	0725                	addi	a4,a4,9
      18:	02e6b733          	mulhu	a4,a3,a4
      1c:	8375                	srli	a4,a4,0x1d
      1e:	01e71693          	slli	a3,a4,0x1e
      22:	40e68733          	sub	a4,a3,a4
      26:	0706                	slli	a4,a4,0x1
      28:	8f99                	sub	a5,a5,a4
      2a:	0785                	addi	a5,a5,1
    hi = x / 127773;
    lo = x % 127773;
      2c:	1fe406b7          	lui	a3,0x1fe40
      30:	b7968693          	addi	a3,a3,-1159 # 1fe3fb79 <base+0x1fe3d771>
      34:	41a70737          	lui	a4,0x41a70
      38:	5af70713          	addi	a4,a4,1455 # 41a705af <base+0x41a6e1a7>
      3c:	1702                	slli	a4,a4,0x20
      3e:	9736                	add	a4,a4,a3
      40:	02e79733          	mulh	a4,a5,a4
      44:	873d                	srai	a4,a4,0xf
      46:	43f7d693          	srai	a3,a5,0x3f
      4a:	8f15                	sub	a4,a4,a3
      4c:	66fd                	lui	a3,0x1f
      4e:	31d68693          	addi	a3,a3,797 # 1f31d <base+0x1cf15>
      52:	02d706b3          	mul	a3,a4,a3
      56:	8f95                	sub	a5,a5,a3
    x = 16807 * lo - 2836 * hi;
      58:	6691                	lui	a3,0x4
      5a:	1a768693          	addi	a3,a3,423 # 41a7 <base+0x1d9f>
      5e:	02d787b3          	mul	a5,a5,a3
      62:	76fd                	lui	a3,0xfffff
      64:	4ec68693          	addi	a3,a3,1260 # fffffffffffff4ec <base+0xffffffffffffd0e4>
      68:	02d70733          	mul	a4,a4,a3
      6c:	97ba                	add	a5,a5,a4
    if (x < 0)
      6e:	0007ca63          	bltz	a5,82 <do_rand+0x82>
        x += 0x7fffffff;
    /* Transform to [0, 0x7ffffffd] range. */
    x--;
      72:	17fd                	addi	a5,a5,-1
    *ctx = x;
      74:	e11c                	sd	a5,0(a0)
    return (x);
}
      76:	0007851b          	sext.w	a0,a5
      7a:	60a2                	ld	ra,8(sp)
      7c:	6402                	ld	s0,0(sp)
      7e:	0141                	addi	sp,sp,16
      80:	8082                	ret
        x += 0x7fffffff;
      82:	80000737          	lui	a4,0x80000
      86:	fff74713          	not	a4,a4
      8a:	97ba                	add	a5,a5,a4
      8c:	b7dd                	j	72 <do_rand+0x72>

000000000000008e <rand>:

unsigned long rand_next = 1;

int
rand(void)
{
      8e:	1141                	addi	sp,sp,-16
      90:	e406                	sd	ra,8(sp)
      92:	e022                	sd	s0,0(sp)
      94:	0800                	addi	s0,sp,16
    return (do_rand(&rand_next));
      96:	00002517          	auipc	a0,0x2
      9a:	f6a50513          	addi	a0,a0,-150 # 2000 <rand_next>
      9e:	f63ff0ef          	jal	0 <do_rand>
}
      a2:	60a2                	ld	ra,8(sp)
      a4:	6402                	ld	s0,0(sp)
      a6:	0141                	addi	sp,sp,16
      a8:	8082                	ret

00000000000000aa <go>:

void
go(int which_child)
{
      aa:	7171                	addi	sp,sp,-176
      ac:	f506                	sd	ra,168(sp)
      ae:	f122                	sd	s0,160(sp)
      b0:	ed26                	sd	s1,152(sp)
      b2:	1900                	addi	s0,sp,176
      b4:	84aa                	mv	s1,a0
  int fd = -1;
  static char buf[999];
  char *break0 = sbrk(0);
      b6:	4501                	li	a0,0
      b8:	3e3000ef          	jal	c9a <sbrk>
      bc:	f4a43c23          	sd	a0,-168(s0)
  uint64 iters = 0;

  mkdir("grindir");
      c0:	00001517          	auipc	a0,0x1
      c4:	19050513          	addi	a0,a0,400 # 1250 <malloc+0xf8>
      c8:	3b3000ef          	jal	c7a <mkdir>
  if(chdir("grindir") != 0){
      cc:	00001517          	auipc	a0,0x1
      d0:	18450513          	addi	a0,a0,388 # 1250 <malloc+0xf8>
      d4:	3af000ef          	jal	c82 <chdir>
      d8:	c505                	beqz	a0,100 <go+0x56>
      da:	e94a                	sd	s2,144(sp)
      dc:	e54e                	sd	s3,136(sp)
      de:	e152                	sd	s4,128(sp)
      e0:	fcd6                	sd	s5,120(sp)
      e2:	f8da                	sd	s6,112(sp)
      e4:	f4de                	sd	s7,104(sp)
      e6:	f0e2                	sd	s8,96(sp)
      e8:	ece6                	sd	s9,88(sp)
      ea:	e8ea                	sd	s10,80(sp)
      ec:	e4ee                	sd	s11,72(sp)
    printf("grind: chdir grindir failed\n");
      ee:	00001517          	auipc	a0,0x1
      f2:	16a50513          	addi	a0,a0,362 # 1258 <malloc+0x100>
      f6:	7a7000ef          	jal	109c <printf>
    exit(1);
      fa:	4505                	li	a0,1
      fc:	317000ef          	jal	c12 <exit>
     100:	e94a                	sd	s2,144(sp)
     102:	e54e                	sd	s3,136(sp)
     104:	e152                	sd	s4,128(sp)
     106:	fcd6                	sd	s5,120(sp)
     108:	f8da                	sd	s6,112(sp)
     10a:	f4de                	sd	s7,104(sp)
     10c:	f0e2                	sd	s8,96(sp)
     10e:	ece6                	sd	s9,88(sp)
     110:	e8ea                	sd	s10,80(sp)
     112:	e4ee                	sd	s11,72(sp)
  }
  chdir("/");
     114:	00001517          	auipc	a0,0x1
     118:	16c50513          	addi	a0,a0,364 # 1280 <malloc+0x128>
     11c:	367000ef          	jal	c82 <chdir>
     120:	00001c17          	auipc	s8,0x1
     124:	170c0c13          	addi	s8,s8,368 # 1290 <malloc+0x138>
     128:	c489                	beqz	s1,132 <go+0x88>
     12a:	00001c17          	auipc	s8,0x1
     12e:	15ec0c13          	addi	s8,s8,350 # 1288 <malloc+0x130>
  uint64 iters = 0;
     132:	4481                	li	s1,0
  int fd = -1;
     134:	5cfd                	li	s9,-1
  
  while(1){
    iters++;
    if((iters % 500) == 0)
     136:	106259b7          	lui	s3,0x10625
     13a:	dd398993          	addi	s3,s3,-557 # 10624dd3 <base+0x106229cb>
     13e:	09be                	slli	s3,s3,0xf
     140:	8d598993          	addi	s3,s3,-1835
     144:	09ca                	slli	s3,s3,0x12
     146:	80098993          	addi	s3,s3,-2048
     14a:	fcf98993          	addi	s3,s3,-49
     14e:	1f400b93          	li	s7,500
      write(1, which_child?"B":"A", 1);
     152:	4a05                	li	s4,1
    int what = rand() % 23;
     154:	b2164ab7          	lui	s5,0xb2164
     158:	2c9a8a93          	addi	s5,s5,713 # ffffffffb21642c9 <base+0xffffffffb2161ec1>
     15c:	4b59                	li	s6,22
     15e:	00001917          	auipc	s2,0x1
     162:	40290913          	addi	s2,s2,1026 # 1560 <malloc+0x408>
      close(fd1);
      unlink("c");
    } else if(what == 22){
      // echo hi | cat
      int aa[2], bb[2];
      if(pipe(aa) < 0){
     166:	f6840d93          	addi	s11,s0,-152
     16a:	a819                	j	180 <go+0xd6>
      close(open("grindir/../a", O_CREATE|O_RDWR));
     16c:	20200593          	li	a1,514
     170:	00001517          	auipc	a0,0x1
     174:	12850513          	addi	a0,a0,296 # 1298 <malloc+0x140>
     178:	2db000ef          	jal	c52 <open>
     17c:	2bf000ef          	jal	c3a <close>
    iters++;
     180:	0485                	addi	s1,s1,1
    if((iters % 500) == 0)
     182:	0024d793          	srli	a5,s1,0x2
     186:	0337b7b3          	mulhu	a5,a5,s3
     18a:	8391                	srli	a5,a5,0x4
     18c:	037787b3          	mul	a5,a5,s7
     190:	00f49763          	bne	s1,a5,19e <go+0xf4>
      write(1, which_child?"B":"A", 1);
     194:	8652                	mv	a2,s4
     196:	85e2                	mv	a1,s8
     198:	8552                	mv	a0,s4
     19a:	299000ef          	jal	c32 <write>
    int what = rand() % 23;
     19e:	ef1ff0ef          	jal	8e <rand>
     1a2:	035507b3          	mul	a5,a0,s5
     1a6:	9381                	srli	a5,a5,0x20
     1a8:	9fa9                	addw	a5,a5,a0
     1aa:	4047d79b          	sraiw	a5,a5,0x4
     1ae:	41f5571b          	sraiw	a4,a0,0x1f
     1b2:	9f99                	subw	a5,a5,a4
     1b4:	0017971b          	slliw	a4,a5,0x1
     1b8:	9f3d                	addw	a4,a4,a5
     1ba:	0037171b          	slliw	a4,a4,0x3
     1be:	40f707bb          	subw	a5,a4,a5
     1c2:	9d1d                	subw	a0,a0,a5
     1c4:	faab6ee3          	bltu	s6,a0,180 <go+0xd6>
     1c8:	02051793          	slli	a5,a0,0x20
     1cc:	01e7d513          	srli	a0,a5,0x1e
     1d0:	954a                	add	a0,a0,s2
     1d2:	411c                	lw	a5,0(a0)
     1d4:	97ca                	add	a5,a5,s2
     1d6:	8782                	jr	a5
      close(open("grindir/../grindir/../b", O_CREATE|O_RDWR));
     1d8:	20200593          	li	a1,514
     1dc:	00001517          	auipc	a0,0x1
     1e0:	0cc50513          	addi	a0,a0,204 # 12a8 <malloc+0x150>
     1e4:	26f000ef          	jal	c52 <open>
     1e8:	253000ef          	jal	c3a <close>
     1ec:	bf51                	j	180 <go+0xd6>
      unlink("grindir/../a");
     1ee:	00001517          	auipc	a0,0x1
     1f2:	0aa50513          	addi	a0,a0,170 # 1298 <malloc+0x140>
     1f6:	26d000ef          	jal	c62 <unlink>
     1fa:	b759                	j	180 <go+0xd6>
      if(chdir("grindir") != 0){
     1fc:	00001517          	auipc	a0,0x1
     200:	05450513          	addi	a0,a0,84 # 1250 <malloc+0xf8>
     204:	27f000ef          	jal	c82 <chdir>
     208:	ed11                	bnez	a0,224 <go+0x17a>
      unlink("../b");
     20a:	00001517          	auipc	a0,0x1
     20e:	0b650513          	addi	a0,a0,182 # 12c0 <malloc+0x168>
     212:	251000ef          	jal	c62 <unlink>
      chdir("/");
     216:	00001517          	auipc	a0,0x1
     21a:	06a50513          	addi	a0,a0,106 # 1280 <malloc+0x128>
     21e:	265000ef          	jal	c82 <chdir>
     222:	bfb9                	j	180 <go+0xd6>
        printf("grind: chdir grindir failed\n");
     224:	00001517          	auipc	a0,0x1
     228:	03450513          	addi	a0,a0,52 # 1258 <malloc+0x100>
     22c:	671000ef          	jal	109c <printf>
        exit(1);
     230:	4505                	li	a0,1
     232:	1e1000ef          	jal	c12 <exit>
      close(fd);
     236:	8566                	mv	a0,s9
     238:	203000ef          	jal	c3a <close>
      fd = open("/grindir/../a", O_CREATE|O_RDWR);
     23c:	20200593          	li	a1,514
     240:	00001517          	auipc	a0,0x1
     244:	08850513          	addi	a0,a0,136 # 12c8 <malloc+0x170>
     248:	20b000ef          	jal	c52 <open>
     24c:	8caa                	mv	s9,a0
     24e:	bf0d                	j	180 <go+0xd6>
      close(fd);
     250:	8566                	mv	a0,s9
     252:	1e9000ef          	jal	c3a <close>
      fd = open("/./grindir/./../b", O_CREATE|O_RDWR);
     256:	20200593          	li	a1,514
     25a:	00001517          	auipc	a0,0x1
     25e:	07e50513          	addi	a0,a0,126 # 12d8 <malloc+0x180>
     262:	1f1000ef          	jal	c52 <open>
     266:	8caa                	mv	s9,a0
     268:	bf21                	j	180 <go+0xd6>
      write(fd, buf, sizeof(buf));
     26a:	3e700613          	li	a2,999
     26e:	00002597          	auipc	a1,0x2
     272:	db258593          	addi	a1,a1,-590 # 2020 <buf.0>
     276:	8566                	mv	a0,s9
     278:	1bb000ef          	jal	c32 <write>
     27c:	b711                	j	180 <go+0xd6>
      read(fd, buf, sizeof(buf));
     27e:	3e700613          	li	a2,999
     282:	00002597          	auipc	a1,0x2
     286:	d9e58593          	addi	a1,a1,-610 # 2020 <buf.0>
     28a:	8566                	mv	a0,s9
     28c:	19f000ef          	jal	c2a <read>
     290:	bdc5                	j	180 <go+0xd6>
      mkdir("grindir/../a");
     292:	00001517          	auipc	a0,0x1
     296:	00650513          	addi	a0,a0,6 # 1298 <malloc+0x140>
     29a:	1e1000ef          	jal	c7a <mkdir>
      close(open("a/../a/./a", O_CREATE|O_RDWR));
     29e:	20200593          	li	a1,514
     2a2:	00001517          	auipc	a0,0x1
     2a6:	04e50513          	addi	a0,a0,78 # 12f0 <malloc+0x198>
     2aa:	1a9000ef          	jal	c52 <open>
     2ae:	18d000ef          	jal	c3a <close>
      unlink("a/a");
     2b2:	00001517          	auipc	a0,0x1
     2b6:	04e50513          	addi	a0,a0,78 # 1300 <malloc+0x1a8>
     2ba:	1a9000ef          	jal	c62 <unlink>
     2be:	b5c9                	j	180 <go+0xd6>
      mkdir("/../b");
     2c0:	00001517          	auipc	a0,0x1
     2c4:	04850513          	addi	a0,a0,72 # 1308 <malloc+0x1b0>
     2c8:	1b3000ef          	jal	c7a <mkdir>
      close(open("grindir/../b/b", O_CREATE|O_RDWR));
     2cc:	20200593          	li	a1,514
     2d0:	00001517          	auipc	a0,0x1
     2d4:	04050513          	addi	a0,a0,64 # 1310 <malloc+0x1b8>
     2d8:	17b000ef          	jal	c52 <open>
     2dc:	15f000ef          	jal	c3a <close>
      unlink("b/b");
     2e0:	00001517          	auipc	a0,0x1
     2e4:	04050513          	addi	a0,a0,64 # 1320 <malloc+0x1c8>
     2e8:	17b000ef          	jal	c62 <unlink>
     2ec:	bd51                	j	180 <go+0xd6>
      unlink("b");
     2ee:	00001517          	auipc	a0,0x1
     2f2:	03a50513          	addi	a0,a0,58 # 1328 <malloc+0x1d0>
     2f6:	16d000ef          	jal	c62 <unlink>
      link("../grindir/./../a", "../b");
     2fa:	00001597          	auipc	a1,0x1
     2fe:	fc658593          	addi	a1,a1,-58 # 12c0 <malloc+0x168>
     302:	00001517          	auipc	a0,0x1
     306:	02e50513          	addi	a0,a0,46 # 1330 <malloc+0x1d8>
     30a:	169000ef          	jal	c72 <link>
     30e:	bd8d                	j	180 <go+0xd6>
      unlink("../grindir/../a");
     310:	00001517          	auipc	a0,0x1
     314:	03850513          	addi	a0,a0,56 # 1348 <malloc+0x1f0>
     318:	14b000ef          	jal	c62 <unlink>
      link(".././b", "/grindir/../a");
     31c:	00001597          	auipc	a1,0x1
     320:	fac58593          	addi	a1,a1,-84 # 12c8 <malloc+0x170>
     324:	00001517          	auipc	a0,0x1
     328:	03450513          	addi	a0,a0,52 # 1358 <malloc+0x200>
     32c:	147000ef          	jal	c72 <link>
     330:	bd81                	j	180 <go+0xd6>
      int pid = fork();
     332:	0d9000ef          	jal	c0a <fork>
      if(pid == 0){
     336:	c519                	beqz	a0,344 <go+0x29a>
      } else if(pid < 0){
     338:	00054863          	bltz	a0,348 <go+0x29e>
      wait(0);
     33c:	4501                	li	a0,0
     33e:	0dd000ef          	jal	c1a <wait>
     342:	bd3d                	j	180 <go+0xd6>
        exit(0);
     344:	0cf000ef          	jal	c12 <exit>
        printf("grind: fork failed\n");
     348:	00001517          	auipc	a0,0x1
     34c:	01850513          	addi	a0,a0,24 # 1360 <malloc+0x208>
     350:	54d000ef          	jal	109c <printf>
        exit(1);
     354:	4505                	li	a0,1
     356:	0bd000ef          	jal	c12 <exit>
      int pid = fork();
     35a:	0b1000ef          	jal	c0a <fork>
      if(pid == 0){
     35e:	c519                	beqz	a0,36c <go+0x2c2>
      } else if(pid < 0){
     360:	00054d63          	bltz	a0,37a <go+0x2d0>
      wait(0);
     364:	4501                	li	a0,0
     366:	0b5000ef          	jal	c1a <wait>
     36a:	bd19                	j	180 <go+0xd6>
        fork();
     36c:	09f000ef          	jal	c0a <fork>
        fork();
     370:	09b000ef          	jal	c0a <fork>
        exit(0);
     374:	4501                	li	a0,0
     376:	09d000ef          	jal	c12 <exit>
        printf("grind: fork failed\n");
     37a:	00001517          	auipc	a0,0x1
     37e:	fe650513          	addi	a0,a0,-26 # 1360 <malloc+0x208>
     382:	51b000ef          	jal	109c <printf>
        exit(1);
     386:	4505                	li	a0,1
     388:	08b000ef          	jal	c12 <exit>
      sbrk(6011);
     38c:	6505                	lui	a0,0x1
     38e:	77b50513          	addi	a0,a0,1915 # 177b <digits+0x1bb>
     392:	109000ef          	jal	c9a <sbrk>
     396:	b3ed                	j	180 <go+0xd6>
      if(sbrk(0) > break0)
     398:	4501                	li	a0,0
     39a:	101000ef          	jal	c9a <sbrk>
     39e:	f5843783          	ld	a5,-168(s0)
     3a2:	dca7ffe3          	bgeu	a5,a0,180 <go+0xd6>
        sbrk(-(sbrk(0) - break0));
     3a6:	4501                	li	a0,0
     3a8:	0f3000ef          	jal	c9a <sbrk>
     3ac:	f5843783          	ld	a5,-168(s0)
     3b0:	40a7853b          	subw	a0,a5,a0
     3b4:	0e7000ef          	jal	c9a <sbrk>
     3b8:	b3e1                	j	180 <go+0xd6>
      int pid = fork();
     3ba:	051000ef          	jal	c0a <fork>
     3be:	8d2a                	mv	s10,a0
      if(pid == 0){
     3c0:	c10d                	beqz	a0,3e2 <go+0x338>
      } else if(pid < 0){
     3c2:	02054d63          	bltz	a0,3fc <go+0x352>
      if(chdir("../grindir/..") != 0){
     3c6:	00001517          	auipc	a0,0x1
     3ca:	fba50513          	addi	a0,a0,-70 # 1380 <malloc+0x228>
     3ce:	0b5000ef          	jal	c82 <chdir>
     3d2:	ed15                	bnez	a0,40e <go+0x364>
      kill(pid);
     3d4:	856a                	mv	a0,s10
     3d6:	06d000ef          	jal	c42 <kill>
      wait(0);
     3da:	4501                	li	a0,0
     3dc:	03f000ef          	jal	c1a <wait>
     3e0:	b345                	j	180 <go+0xd6>
        close(open("a", O_CREATE|O_RDWR));
     3e2:	20200593          	li	a1,514
     3e6:	00001517          	auipc	a0,0x1
     3ea:	f9250513          	addi	a0,a0,-110 # 1378 <malloc+0x220>
     3ee:	065000ef          	jal	c52 <open>
     3f2:	049000ef          	jal	c3a <close>
        exit(0);
     3f6:	4501                	li	a0,0
     3f8:	01b000ef          	jal	c12 <exit>
        printf("grind: fork failed\n");
     3fc:	00001517          	auipc	a0,0x1
     400:	f6450513          	addi	a0,a0,-156 # 1360 <malloc+0x208>
     404:	499000ef          	jal	109c <printf>
        exit(1);
     408:	4505                	li	a0,1
     40a:	009000ef          	jal	c12 <exit>
        printf("grind: chdir failed\n");
     40e:	00001517          	auipc	a0,0x1
     412:	f8250513          	addi	a0,a0,-126 # 1390 <malloc+0x238>
     416:	487000ef          	jal	109c <printf>
        exit(1);
     41a:	4505                	li	a0,1
     41c:	7f6000ef          	jal	c12 <exit>
      int pid = fork();
     420:	7ea000ef          	jal	c0a <fork>
      if(pid == 0){
     424:	c519                	beqz	a0,432 <go+0x388>
      } else if(pid < 0){
     426:	00054d63          	bltz	a0,440 <go+0x396>
      wait(0);
     42a:	4501                	li	a0,0
     42c:	7ee000ef          	jal	c1a <wait>
     430:	bb81                	j	180 <go+0xd6>
        kill(getpid());
     432:	061000ef          	jal	c92 <getpid>
     436:	00d000ef          	jal	c42 <kill>
        exit(0);
     43a:	4501                	li	a0,0
     43c:	7d6000ef          	jal	c12 <exit>
        printf("grind: fork failed\n");
     440:	00001517          	auipc	a0,0x1
     444:	f2050513          	addi	a0,a0,-224 # 1360 <malloc+0x208>
     448:	455000ef          	jal	109c <printf>
        exit(1);
     44c:	4505                	li	a0,1
     44e:	7c4000ef          	jal	c12 <exit>
      if(pipe(fds) < 0){
     452:	f7840513          	addi	a0,s0,-136
     456:	7cc000ef          	jal	c22 <pipe>
     45a:	02054363          	bltz	a0,480 <go+0x3d6>
      int pid = fork();
     45e:	7ac000ef          	jal	c0a <fork>
      if(pid == 0){
     462:	c905                	beqz	a0,492 <go+0x3e8>
      } else if(pid < 0){
     464:	08054263          	bltz	a0,4e8 <go+0x43e>
      close(fds[0]);
     468:	f7842503          	lw	a0,-136(s0)
     46c:	7ce000ef          	jal	c3a <close>
      close(fds[1]);
     470:	f7c42503          	lw	a0,-132(s0)
     474:	7c6000ef          	jal	c3a <close>
      wait(0);
     478:	4501                	li	a0,0
     47a:	7a0000ef          	jal	c1a <wait>
     47e:	b309                	j	180 <go+0xd6>
        printf("grind: pipe failed\n");
     480:	00001517          	auipc	a0,0x1
     484:	f2850513          	addi	a0,a0,-216 # 13a8 <malloc+0x250>
     488:	415000ef          	jal	109c <printf>
        exit(1);
     48c:	4505                	li	a0,1
     48e:	784000ef          	jal	c12 <exit>
        fork();
     492:	778000ef          	jal	c0a <fork>
        fork();
     496:	774000ef          	jal	c0a <fork>
        if(write(fds[1], "x", 1) != 1)
     49a:	4605                	li	a2,1
     49c:	00001597          	auipc	a1,0x1
     4a0:	f2458593          	addi	a1,a1,-220 # 13c0 <malloc+0x268>
     4a4:	f7c42503          	lw	a0,-132(s0)
     4a8:	78a000ef          	jal	c32 <write>
     4ac:	4785                	li	a5,1
     4ae:	00f51f63          	bne	a0,a5,4cc <go+0x422>
        if(read(fds[0], &c, 1) != 1)
     4b2:	4605                	li	a2,1
     4b4:	f7040593          	addi	a1,s0,-144
     4b8:	f7842503          	lw	a0,-136(s0)
     4bc:	76e000ef          	jal	c2a <read>
     4c0:	4785                	li	a5,1
     4c2:	00f51c63          	bne	a0,a5,4da <go+0x430>
        exit(0);
     4c6:	4501                	li	a0,0
     4c8:	74a000ef          	jal	c12 <exit>
          printf("grind: pipe write failed\n");
     4cc:	00001517          	auipc	a0,0x1
     4d0:	efc50513          	addi	a0,a0,-260 # 13c8 <malloc+0x270>
     4d4:	3c9000ef          	jal	109c <printf>
     4d8:	bfe9                	j	4b2 <go+0x408>
          printf("grind: pipe read failed\n");
     4da:	00001517          	auipc	a0,0x1
     4de:	f0e50513          	addi	a0,a0,-242 # 13e8 <malloc+0x290>
     4e2:	3bb000ef          	jal	109c <printf>
     4e6:	b7c5                	j	4c6 <go+0x41c>
        printf("grind: fork failed\n");
     4e8:	00001517          	auipc	a0,0x1
     4ec:	e7850513          	addi	a0,a0,-392 # 1360 <malloc+0x208>
     4f0:	3ad000ef          	jal	109c <printf>
        exit(1);
     4f4:	4505                	li	a0,1
     4f6:	71c000ef          	jal	c12 <exit>
      int pid = fork();
     4fa:	710000ef          	jal	c0a <fork>
      if(pid == 0){
     4fe:	c519                	beqz	a0,50c <go+0x462>
      } else if(pid < 0){
     500:	04054f63          	bltz	a0,55e <go+0x4b4>
      wait(0);
     504:	4501                	li	a0,0
     506:	714000ef          	jal	c1a <wait>
     50a:	b99d                	j	180 <go+0xd6>
        unlink("a");
     50c:	00001517          	auipc	a0,0x1
     510:	e6c50513          	addi	a0,a0,-404 # 1378 <malloc+0x220>
     514:	74e000ef          	jal	c62 <unlink>
        mkdir("a");
     518:	00001517          	auipc	a0,0x1
     51c:	e6050513          	addi	a0,a0,-416 # 1378 <malloc+0x220>
     520:	75a000ef          	jal	c7a <mkdir>
        chdir("a");
     524:	00001517          	auipc	a0,0x1
     528:	e5450513          	addi	a0,a0,-428 # 1378 <malloc+0x220>
     52c:	756000ef          	jal	c82 <chdir>
        unlink("../a");
     530:	00001517          	auipc	a0,0x1
     534:	ed850513          	addi	a0,a0,-296 # 1408 <malloc+0x2b0>
     538:	72a000ef          	jal	c62 <unlink>
        fd = open("x", O_CREATE|O_RDWR);
     53c:	20200593          	li	a1,514
     540:	00001517          	auipc	a0,0x1
     544:	e8050513          	addi	a0,a0,-384 # 13c0 <malloc+0x268>
     548:	70a000ef          	jal	c52 <open>
        unlink("x");
     54c:	00001517          	auipc	a0,0x1
     550:	e7450513          	addi	a0,a0,-396 # 13c0 <malloc+0x268>
     554:	70e000ef          	jal	c62 <unlink>
        exit(0);
     558:	4501                	li	a0,0
     55a:	6b8000ef          	jal	c12 <exit>
        printf("grind: fork failed\n");
     55e:	00001517          	auipc	a0,0x1
     562:	e0250513          	addi	a0,a0,-510 # 1360 <malloc+0x208>
     566:	337000ef          	jal	109c <printf>
        exit(1);
     56a:	4505                	li	a0,1
     56c:	6a6000ef          	jal	c12 <exit>
      unlink("c");
     570:	00001517          	auipc	a0,0x1
     574:	ea050513          	addi	a0,a0,-352 # 1410 <malloc+0x2b8>
     578:	6ea000ef          	jal	c62 <unlink>
      int fd1 = open("c", O_CREATE|O_RDWR);
     57c:	20200593          	li	a1,514
     580:	00001517          	auipc	a0,0x1
     584:	e9050513          	addi	a0,a0,-368 # 1410 <malloc+0x2b8>
     588:	6ca000ef          	jal	c52 <open>
     58c:	8d2a                	mv	s10,a0
      if(fd1 < 0){
     58e:	04054563          	bltz	a0,5d8 <go+0x52e>
      if(write(fd1, "x", 1) != 1){
     592:	8652                	mv	a2,s4
     594:	00001597          	auipc	a1,0x1
     598:	e2c58593          	addi	a1,a1,-468 # 13c0 <malloc+0x268>
     59c:	696000ef          	jal	c32 <write>
     5a0:	05451563          	bne	a0,s4,5ea <go+0x540>
      if(fstat(fd1, &st) != 0){
     5a4:	f7840593          	addi	a1,s0,-136
     5a8:	856a                	mv	a0,s10
     5aa:	6c0000ef          	jal	c6a <fstat>
     5ae:	e539                	bnez	a0,5fc <go+0x552>
      if(st.size != 1){
     5b0:	f8843583          	ld	a1,-120(s0)
     5b4:	05459d63          	bne	a1,s4,60e <go+0x564>
      if(st.ino > 200){
     5b8:	f7c42583          	lw	a1,-132(s0)
     5bc:	0c800793          	li	a5,200
     5c0:	06b7e163          	bltu	a5,a1,622 <go+0x578>
      close(fd1);
     5c4:	856a                	mv	a0,s10
     5c6:	674000ef          	jal	c3a <close>
      unlink("c");
     5ca:	00001517          	auipc	a0,0x1
     5ce:	e4650513          	addi	a0,a0,-442 # 1410 <malloc+0x2b8>
     5d2:	690000ef          	jal	c62 <unlink>
     5d6:	b66d                	j	180 <go+0xd6>
        printf("grind: create c failed\n");
     5d8:	00001517          	auipc	a0,0x1
     5dc:	e4050513          	addi	a0,a0,-448 # 1418 <malloc+0x2c0>
     5e0:	2bd000ef          	jal	109c <printf>
        exit(1);
     5e4:	4505                	li	a0,1
     5e6:	62c000ef          	jal	c12 <exit>
        printf("grind: write c failed\n");
     5ea:	00001517          	auipc	a0,0x1
     5ee:	e4650513          	addi	a0,a0,-442 # 1430 <malloc+0x2d8>
     5f2:	2ab000ef          	jal	109c <printf>
        exit(1);
     5f6:	4505                	li	a0,1
     5f8:	61a000ef          	jal	c12 <exit>
        printf("grind: fstat failed\n");
     5fc:	00001517          	auipc	a0,0x1
     600:	e4c50513          	addi	a0,a0,-436 # 1448 <malloc+0x2f0>
     604:	299000ef          	jal	109c <printf>
        exit(1);
     608:	4505                	li	a0,1
     60a:	608000ef          	jal	c12 <exit>
        printf("grind: fstat reports wrong size %d\n", (int)st.size);
     60e:	2581                	sext.w	a1,a1
     610:	00001517          	auipc	a0,0x1
     614:	e5050513          	addi	a0,a0,-432 # 1460 <malloc+0x308>
     618:	285000ef          	jal	109c <printf>
        exit(1);
     61c:	4505                	li	a0,1
     61e:	5f4000ef          	jal	c12 <exit>
        printf("grind: fstat reports crazy i-number %d\n", st.ino);
     622:	00001517          	auipc	a0,0x1
     626:	e6650513          	addi	a0,a0,-410 # 1488 <malloc+0x330>
     62a:	273000ef          	jal	109c <printf>
        exit(1);
     62e:	4505                	li	a0,1
     630:	5e2000ef          	jal	c12 <exit>
      if(pipe(aa) < 0){
     634:	856e                	mv	a0,s11
     636:	5ec000ef          	jal	c22 <pipe>
     63a:	0a054863          	bltz	a0,6ea <go+0x640>
        fprintf(2, "grind: pipe failed\n");
        exit(1);
      }
      if(pipe(bb) < 0){
     63e:	f7040513          	addi	a0,s0,-144
     642:	5e0000ef          	jal	c22 <pipe>
     646:	0a054c63          	bltz	a0,6fe <go+0x654>
        fprintf(2, "grind: pipe failed\n");
        exit(1);
      }
      int pid1 = fork();
     64a:	5c0000ef          	jal	c0a <fork>
      if(pid1 == 0){
     64e:	0c050263          	beqz	a0,712 <go+0x668>
        close(aa[1]);
        char *args[3] = { "echo", "hi", 0 };
        exec("grindir/../echo", args);
        fprintf(2, "grind: echo: not found\n");
        exit(2);
      } else if(pid1 < 0){
     652:	14054463          	bltz	a0,79a <go+0x6f0>
        fprintf(2, "grind: fork failed\n");
        exit(3);
      }
      int pid2 = fork();
     656:	5b4000ef          	jal	c0a <fork>
      if(pid2 == 0){
     65a:	14050a63          	beqz	a0,7ae <go+0x704>
        close(bb[1]);
        char *args[2] = { "cat", 0 };
        exec("/cat", args);
        fprintf(2, "grind: cat: not found\n");
        exit(6);
      } else if(pid2 < 0){
     65e:	1e054863          	bltz	a0,84e <go+0x7a4>
        fprintf(2, "grind: fork failed\n");
        exit(7);
      }
      close(aa[0]);
     662:	f6842503          	lw	a0,-152(s0)
     666:	5d4000ef          	jal	c3a <close>
      close(aa[1]);
     66a:	f6c42503          	lw	a0,-148(s0)
     66e:	5cc000ef          	jal	c3a <close>
      close(bb[1]);
     672:	f7442503          	lw	a0,-140(s0)
     676:	5c4000ef          	jal	c3a <close>
      char buf[4] = { 0, 0, 0, 0 };
     67a:	f6042023          	sw	zero,-160(s0)
      read(bb[0], buf+0, 1);
     67e:	8652                	mv	a2,s4
     680:	f6040593          	addi	a1,s0,-160
     684:	f7042503          	lw	a0,-144(s0)
     688:	5a2000ef          	jal	c2a <read>
      read(bb[0], buf+1, 1);
     68c:	8652                	mv	a2,s4
     68e:	f6140593          	addi	a1,s0,-159
     692:	f7042503          	lw	a0,-144(s0)
     696:	594000ef          	jal	c2a <read>
      read(bb[0], buf+2, 1);
     69a:	8652                	mv	a2,s4
     69c:	f6240593          	addi	a1,s0,-158
     6a0:	f7042503          	lw	a0,-144(s0)
     6a4:	586000ef          	jal	c2a <read>
      close(bb[0]);
     6a8:	f7042503          	lw	a0,-144(s0)
     6ac:	58e000ef          	jal	c3a <close>
      int st1, st2;
      wait(&st1);
     6b0:	f6440513          	addi	a0,s0,-156
     6b4:	566000ef          	jal	c1a <wait>
      wait(&st2);
     6b8:	f7840513          	addi	a0,s0,-136
     6bc:	55e000ef          	jal	c1a <wait>
      if(st1 != 0 || st2 != 0 || strcmp(buf, "hi\n") != 0){
     6c0:	f6442783          	lw	a5,-156(s0)
     6c4:	f7842703          	lw	a4,-136(s0)
     6c8:	f4e43823          	sd	a4,-176(s0)
     6cc:	00e7ed33          	or	s10,a5,a4
     6d0:	180d1963          	bnez	s10,862 <go+0x7b8>
     6d4:	00001597          	auipc	a1,0x1
     6d8:	e5458593          	addi	a1,a1,-428 # 1528 <malloc+0x3d0>
     6dc:	f6040513          	addi	a0,s0,-160
     6e0:	2d8000ef          	jal	9b8 <strcmp>
     6e4:	a8050ee3          	beqz	a0,180 <go+0xd6>
     6e8:	aab5                	j	864 <go+0x7ba>
        fprintf(2, "grind: pipe failed\n");
     6ea:	00001597          	auipc	a1,0x1
     6ee:	cbe58593          	addi	a1,a1,-834 # 13a8 <malloc+0x250>
     6f2:	4509                	li	a0,2
     6f4:	17f000ef          	jal	1072 <fprintf>
        exit(1);
     6f8:	4505                	li	a0,1
     6fa:	518000ef          	jal	c12 <exit>
        fprintf(2, "grind: pipe failed\n");
     6fe:	00001597          	auipc	a1,0x1
     702:	caa58593          	addi	a1,a1,-854 # 13a8 <malloc+0x250>
     706:	4509                	li	a0,2
     708:	16b000ef          	jal	1072 <fprintf>
        exit(1);
     70c:	4505                	li	a0,1
     70e:	504000ef          	jal	c12 <exit>
        close(bb[0]);
     712:	f7042503          	lw	a0,-144(s0)
     716:	524000ef          	jal	c3a <close>
        close(bb[1]);
     71a:	f7442503          	lw	a0,-140(s0)
     71e:	51c000ef          	jal	c3a <close>
        close(aa[0]);
     722:	f6842503          	lw	a0,-152(s0)
     726:	514000ef          	jal	c3a <close>
        close(1);
     72a:	4505                	li	a0,1
     72c:	50e000ef          	jal	c3a <close>
        if(dup(aa[1]) != 1){
     730:	f6c42503          	lw	a0,-148(s0)
     734:	556000ef          	jal	c8a <dup>
     738:	4785                	li	a5,1
     73a:	00f50c63          	beq	a0,a5,752 <go+0x6a8>
          fprintf(2, "grind: dup failed\n");
     73e:	00001597          	auipc	a1,0x1
     742:	d7258593          	addi	a1,a1,-654 # 14b0 <malloc+0x358>
     746:	4509                	li	a0,2
     748:	12b000ef          	jal	1072 <fprintf>
          exit(1);
     74c:	4505                	li	a0,1
     74e:	4c4000ef          	jal	c12 <exit>
        close(aa[1]);
     752:	f6c42503          	lw	a0,-148(s0)
     756:	4e4000ef          	jal	c3a <close>
        char *args[3] = { "echo", "hi", 0 };
     75a:	00001797          	auipc	a5,0x1
     75e:	d6e78793          	addi	a5,a5,-658 # 14c8 <malloc+0x370>
     762:	f6f43c23          	sd	a5,-136(s0)
     766:	00001797          	auipc	a5,0x1
     76a:	d6a78793          	addi	a5,a5,-662 # 14d0 <malloc+0x378>
     76e:	f8f43023          	sd	a5,-128(s0)
     772:	f8043423          	sd	zero,-120(s0)
        exec("grindir/../echo", args);
     776:	f7840593          	addi	a1,s0,-136
     77a:	00001517          	auipc	a0,0x1
     77e:	d5e50513          	addi	a0,a0,-674 # 14d8 <malloc+0x380>
     782:	4c8000ef          	jal	c4a <exec>
        fprintf(2, "grind: echo: not found\n");
     786:	00001597          	auipc	a1,0x1
     78a:	d6258593          	addi	a1,a1,-670 # 14e8 <malloc+0x390>
     78e:	4509                	li	a0,2
     790:	0e3000ef          	jal	1072 <fprintf>
        exit(2);
     794:	4509                	li	a0,2
     796:	47c000ef          	jal	c12 <exit>
        fprintf(2, "grind: fork failed\n");
     79a:	00001597          	auipc	a1,0x1
     79e:	bc658593          	addi	a1,a1,-1082 # 1360 <malloc+0x208>
     7a2:	4509                	li	a0,2
     7a4:	0cf000ef          	jal	1072 <fprintf>
        exit(3);
     7a8:	450d                	li	a0,3
     7aa:	468000ef          	jal	c12 <exit>
        close(aa[1]);
     7ae:	f6c42503          	lw	a0,-148(s0)
     7b2:	488000ef          	jal	c3a <close>
        close(bb[0]);
     7b6:	f7042503          	lw	a0,-144(s0)
     7ba:	480000ef          	jal	c3a <close>
        close(0);
     7be:	4501                	li	a0,0
     7c0:	47a000ef          	jal	c3a <close>
        if(dup(aa[0]) != 0){
     7c4:	f6842503          	lw	a0,-152(s0)
     7c8:	4c2000ef          	jal	c8a <dup>
     7cc:	c919                	beqz	a0,7e2 <go+0x738>
          fprintf(2, "grind: dup failed\n");
     7ce:	00001597          	auipc	a1,0x1
     7d2:	ce258593          	addi	a1,a1,-798 # 14b0 <malloc+0x358>
     7d6:	4509                	li	a0,2
     7d8:	09b000ef          	jal	1072 <fprintf>
          exit(4);
     7dc:	4511                	li	a0,4
     7de:	434000ef          	jal	c12 <exit>
        close(aa[0]);
     7e2:	f6842503          	lw	a0,-152(s0)
     7e6:	454000ef          	jal	c3a <close>
        close(1);
     7ea:	4505                	li	a0,1
     7ec:	44e000ef          	jal	c3a <close>
        if(dup(bb[1]) != 1){
     7f0:	f7442503          	lw	a0,-140(s0)
     7f4:	496000ef          	jal	c8a <dup>
     7f8:	4785                	li	a5,1
     7fa:	00f50c63          	beq	a0,a5,812 <go+0x768>
          fprintf(2, "grind: dup failed\n");
     7fe:	00001597          	auipc	a1,0x1
     802:	cb258593          	addi	a1,a1,-846 # 14b0 <malloc+0x358>
     806:	4509                	li	a0,2
     808:	06b000ef          	jal	1072 <fprintf>
          exit(5);
     80c:	4515                	li	a0,5
     80e:	404000ef          	jal	c12 <exit>
        close(bb[1]);
     812:	f7442503          	lw	a0,-140(s0)
     816:	424000ef          	jal	c3a <close>
        char *args[2] = { "cat", 0 };
     81a:	00001797          	auipc	a5,0x1
     81e:	ce678793          	addi	a5,a5,-794 # 1500 <malloc+0x3a8>
     822:	f6f43c23          	sd	a5,-136(s0)
     826:	f8043023          	sd	zero,-128(s0)
        exec("/cat", args);
     82a:	f7840593          	addi	a1,s0,-136
     82e:	00001517          	auipc	a0,0x1
     832:	cda50513          	addi	a0,a0,-806 # 1508 <malloc+0x3b0>
     836:	414000ef          	jal	c4a <exec>
        fprintf(2, "grind: cat: not found\n");
     83a:	00001597          	auipc	a1,0x1
     83e:	cd658593          	addi	a1,a1,-810 # 1510 <malloc+0x3b8>
     842:	4509                	li	a0,2
     844:	02f000ef          	jal	1072 <fprintf>
        exit(6);
     848:	4519                	li	a0,6
     84a:	3c8000ef          	jal	c12 <exit>
        fprintf(2, "grind: fork failed\n");
     84e:	00001597          	auipc	a1,0x1
     852:	b1258593          	addi	a1,a1,-1262 # 1360 <malloc+0x208>
     856:	4509                	li	a0,2
     858:	01b000ef          	jal	1072 <fprintf>
        exit(7);
     85c:	451d                	li	a0,7
     85e:	3b4000ef          	jal	c12 <exit>
      if(st1 != 0 || st2 != 0 || strcmp(buf, "hi\n") != 0){
     862:	8d3e                	mv	s10,a5
        printf("grind: exec pipeline failed %d %d \"%s\"\n", st1, st2, buf);
     864:	f6040693          	addi	a3,s0,-160
     868:	f5043603          	ld	a2,-176(s0)
     86c:	85ea                	mv	a1,s10
     86e:	00001517          	auipc	a0,0x1
     872:	cc250513          	addi	a0,a0,-830 # 1530 <malloc+0x3d8>
     876:	027000ef          	jal	109c <printf>
        exit(1);
     87a:	4505                	li	a0,1
     87c:	396000ef          	jal	c12 <exit>

0000000000000880 <iter>:
  }
}

void
iter()
{
     880:	7179                	addi	sp,sp,-48
     882:	f406                	sd	ra,40(sp)
     884:	f022                	sd	s0,32(sp)
     886:	1800                	addi	s0,sp,48
  unlink("a");
     888:	00001517          	auipc	a0,0x1
     88c:	af050513          	addi	a0,a0,-1296 # 1378 <malloc+0x220>
     890:	3d2000ef          	jal	c62 <unlink>
  unlink("b");
     894:	00001517          	auipc	a0,0x1
     898:	a9450513          	addi	a0,a0,-1388 # 1328 <malloc+0x1d0>
     89c:	3c6000ef          	jal	c62 <unlink>
  
  int pid1 = fork();
     8a0:	36a000ef          	jal	c0a <fork>
  if(pid1 < 0){
     8a4:	02054163          	bltz	a0,8c6 <iter+0x46>
     8a8:	ec26                	sd	s1,24(sp)
     8aa:	84aa                	mv	s1,a0
    printf("grind: fork failed\n");
    exit(1);
  }
  if(pid1 == 0){
     8ac:	e905                	bnez	a0,8dc <iter+0x5c>
     8ae:	e84a                	sd	s2,16(sp)
    rand_next ^= 31;
     8b0:	00001717          	auipc	a4,0x1
     8b4:	75070713          	addi	a4,a4,1872 # 2000 <rand_next>
     8b8:	631c                	ld	a5,0(a4)
     8ba:	01f7c793          	xori	a5,a5,31
     8be:	e31c                	sd	a5,0(a4)
    go(0);
     8c0:	4501                	li	a0,0
     8c2:	fe8ff0ef          	jal	aa <go>
     8c6:	ec26                	sd	s1,24(sp)
     8c8:	e84a                	sd	s2,16(sp)
    printf("grind: fork failed\n");
     8ca:	00001517          	auipc	a0,0x1
     8ce:	a9650513          	addi	a0,a0,-1386 # 1360 <malloc+0x208>
     8d2:	7ca000ef          	jal	109c <printf>
    exit(1);
     8d6:	4505                	li	a0,1
     8d8:	33a000ef          	jal	c12 <exit>
     8dc:	e84a                	sd	s2,16(sp)
    exit(0);
  }

  int pid2 = fork();
     8de:	32c000ef          	jal	c0a <fork>
     8e2:	892a                	mv	s2,a0
  if(pid2 < 0){
     8e4:	02054063          	bltz	a0,904 <iter+0x84>
    printf("grind: fork failed\n");
    exit(1);
  }
  if(pid2 == 0){
     8e8:	e51d                	bnez	a0,916 <iter+0x96>
    rand_next ^= 7177;
     8ea:	00001697          	auipc	a3,0x1
     8ee:	71668693          	addi	a3,a3,1814 # 2000 <rand_next>
     8f2:	629c                	ld	a5,0(a3)
     8f4:	6709                	lui	a4,0x2
     8f6:	c0970713          	addi	a4,a4,-1015 # 1c09 <digits+0x649>
     8fa:	8fb9                	xor	a5,a5,a4
     8fc:	e29c                	sd	a5,0(a3)
    go(1);
     8fe:	4505                	li	a0,1
     900:	faaff0ef          	jal	aa <go>
    printf("grind: fork failed\n");
     904:	00001517          	auipc	a0,0x1
     908:	a5c50513          	addi	a0,a0,-1444 # 1360 <malloc+0x208>
     90c:	790000ef          	jal	109c <printf>
    exit(1);
     910:	4505                	li	a0,1
     912:	300000ef          	jal	c12 <exit>
    exit(0);
  }

  int st1 = -1;
     916:	57fd                	li	a5,-1
     918:	fcf42e23          	sw	a5,-36(s0)
  wait(&st1);
     91c:	fdc40513          	addi	a0,s0,-36
     920:	2fa000ef          	jal	c1a <wait>
  if(st1 != 0){
     924:	fdc42783          	lw	a5,-36(s0)
     928:	eb99                	bnez	a5,93e <iter+0xbe>
    kill(pid1);
    kill(pid2);
  }
  int st2 = -1;
     92a:	57fd                	li	a5,-1
     92c:	fcf42c23          	sw	a5,-40(s0)
  wait(&st2);
     930:	fd840513          	addi	a0,s0,-40
     934:	2e6000ef          	jal	c1a <wait>

  exit(0);
     938:	4501                	li	a0,0
     93a:	2d8000ef          	jal	c12 <exit>
    kill(pid1);
     93e:	8526                	mv	a0,s1
     940:	302000ef          	jal	c42 <kill>
    kill(pid2);
     944:	854a                	mv	a0,s2
     946:	2fc000ef          	jal	c42 <kill>
     94a:	b7c5                	j	92a <iter+0xaa>

000000000000094c <main>:
}

int
main()
{
     94c:	1101                	addi	sp,sp,-32
     94e:	ec06                	sd	ra,24(sp)
     950:	e822                	sd	s0,16(sp)
     952:	e426                	sd	s1,8(sp)
     954:	e04a                	sd	s2,0(sp)
     956:	1000                	addi	s0,sp,32
      exit(0);
    }
    if(pid > 0){
      wait(0);
    }
    sleep(20);
     958:	4951                	li	s2,20
    rand_next += 1;
     95a:	00001497          	auipc	s1,0x1
     95e:	6a648493          	addi	s1,s1,1702 # 2000 <rand_next>
     962:	a809                	j	974 <main+0x28>
      iter();
     964:	f1dff0ef          	jal	880 <iter>
    sleep(20);
     968:	854a                	mv	a0,s2
     96a:	338000ef          	jal	ca2 <sleep>
    rand_next += 1;
     96e:	609c                	ld	a5,0(s1)
     970:	0785                	addi	a5,a5,1
     972:	e09c                	sd	a5,0(s1)
    int pid = fork();
     974:	296000ef          	jal	c0a <fork>
    if(pid == 0){
     978:	d575                	beqz	a0,964 <main+0x18>
    if(pid > 0){
     97a:	fea057e3          	blez	a0,968 <main+0x1c>
      wait(0);
     97e:	4501                	li	a0,0
     980:	29a000ef          	jal	c1a <wait>
     984:	b7d5                	j	968 <main+0x1c>

0000000000000986 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
     986:	1141                	addi	sp,sp,-16
     988:	e406                	sd	ra,8(sp)
     98a:	e022                	sd	s0,0(sp)
     98c:	0800                	addi	s0,sp,16
  extern int main();
  main();
     98e:	fbfff0ef          	jal	94c <main>
  exit(0);
     992:	4501                	li	a0,0
     994:	27e000ef          	jal	c12 <exit>

0000000000000998 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
     998:	1141                	addi	sp,sp,-16
     99a:	e406                	sd	ra,8(sp)
     99c:	e022                	sd	s0,0(sp)
     99e:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
     9a0:	87aa                	mv	a5,a0
     9a2:	0585                	addi	a1,a1,1
     9a4:	0785                	addi	a5,a5,1
     9a6:	fff5c703          	lbu	a4,-1(a1)
     9aa:	fee78fa3          	sb	a4,-1(a5)
     9ae:	fb75                	bnez	a4,9a2 <strcpy+0xa>
    ;
  return os;
}
     9b0:	60a2                	ld	ra,8(sp)
     9b2:	6402                	ld	s0,0(sp)
     9b4:	0141                	addi	sp,sp,16
     9b6:	8082                	ret

00000000000009b8 <strcmp>:

int
strcmp(const char *p, const char *q)
{
     9b8:	1141                	addi	sp,sp,-16
     9ba:	e406                	sd	ra,8(sp)
     9bc:	e022                	sd	s0,0(sp)
     9be:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
     9c0:	00054783          	lbu	a5,0(a0)
     9c4:	cb91                	beqz	a5,9d8 <strcmp+0x20>
     9c6:	0005c703          	lbu	a4,0(a1)
     9ca:	00f71763          	bne	a4,a5,9d8 <strcmp+0x20>
    p++, q++;
     9ce:	0505                	addi	a0,a0,1
     9d0:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
     9d2:	00054783          	lbu	a5,0(a0)
     9d6:	fbe5                	bnez	a5,9c6 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
     9d8:	0005c503          	lbu	a0,0(a1)
}
     9dc:	40a7853b          	subw	a0,a5,a0
     9e0:	60a2                	ld	ra,8(sp)
     9e2:	6402                	ld	s0,0(sp)
     9e4:	0141                	addi	sp,sp,16
     9e6:	8082                	ret

00000000000009e8 <strlen>:

uint
strlen(const char *s)
{
     9e8:	1141                	addi	sp,sp,-16
     9ea:	e406                	sd	ra,8(sp)
     9ec:	e022                	sd	s0,0(sp)
     9ee:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
     9f0:	00054783          	lbu	a5,0(a0)
     9f4:	cf91                	beqz	a5,a10 <strlen+0x28>
     9f6:	00150793          	addi	a5,a0,1
     9fa:	86be                	mv	a3,a5
     9fc:	0785                	addi	a5,a5,1
     9fe:	fff7c703          	lbu	a4,-1(a5)
     a02:	ff65                	bnez	a4,9fa <strlen+0x12>
     a04:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
     a08:	60a2                	ld	ra,8(sp)
     a0a:	6402                	ld	s0,0(sp)
     a0c:	0141                	addi	sp,sp,16
     a0e:	8082                	ret
  for(n = 0; s[n]; n++)
     a10:	4501                	li	a0,0
     a12:	bfdd                	j	a08 <strlen+0x20>

0000000000000a14 <memset>:

void*
memset(void *dst, int c, uint n)
{
     a14:	1141                	addi	sp,sp,-16
     a16:	e406                	sd	ra,8(sp)
     a18:	e022                	sd	s0,0(sp)
     a1a:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
     a1c:	ca19                	beqz	a2,a32 <memset+0x1e>
     a1e:	87aa                	mv	a5,a0
     a20:	1602                	slli	a2,a2,0x20
     a22:	9201                	srli	a2,a2,0x20
     a24:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
     a28:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
     a2c:	0785                	addi	a5,a5,1
     a2e:	fee79de3          	bne	a5,a4,a28 <memset+0x14>
  }
  return dst;
}
     a32:	60a2                	ld	ra,8(sp)
     a34:	6402                	ld	s0,0(sp)
     a36:	0141                	addi	sp,sp,16
     a38:	8082                	ret

0000000000000a3a <strchr>:

char*
strchr(const char *s, char c)
{
     a3a:	1141                	addi	sp,sp,-16
     a3c:	e406                	sd	ra,8(sp)
     a3e:	e022                	sd	s0,0(sp)
     a40:	0800                	addi	s0,sp,16
  for(; *s; s++)
     a42:	00054783          	lbu	a5,0(a0)
     a46:	c799                	beqz	a5,a54 <strchr+0x1a>
    if(*s == c)
     a48:	00f58763          	beq	a1,a5,a56 <strchr+0x1c>
  for(; *s; s++)
     a4c:	0505                	addi	a0,a0,1
     a4e:	00054783          	lbu	a5,0(a0)
     a52:	fbfd                	bnez	a5,a48 <strchr+0xe>
      return (char*)s;
  return 0;
     a54:	4501                	li	a0,0
}
     a56:	60a2                	ld	ra,8(sp)
     a58:	6402                	ld	s0,0(sp)
     a5a:	0141                	addi	sp,sp,16
     a5c:	8082                	ret

0000000000000a5e <gets>:

char*
gets(char *buf, int max)
{
     a5e:	711d                	addi	sp,sp,-96
     a60:	ec86                	sd	ra,88(sp)
     a62:	e8a2                	sd	s0,80(sp)
     a64:	e4a6                	sd	s1,72(sp)
     a66:	e0ca                	sd	s2,64(sp)
     a68:	fc4e                	sd	s3,56(sp)
     a6a:	f852                	sd	s4,48(sp)
     a6c:	f456                	sd	s5,40(sp)
     a6e:	f05a                	sd	s6,32(sp)
     a70:	ec5e                	sd	s7,24(sp)
     a72:	e862                	sd	s8,16(sp)
     a74:	1080                	addi	s0,sp,96
     a76:	8baa                	mv	s7,a0
     a78:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
     a7a:	892a                	mv	s2,a0
     a7c:	4481                	li	s1,0
    cc = read(0, &c, 1);
     a7e:	faf40b13          	addi	s6,s0,-81
     a82:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
     a84:	8c26                	mv	s8,s1
     a86:	0014899b          	addiw	s3,s1,1
     a8a:	84ce                	mv	s1,s3
     a8c:	0349d863          	bge	s3,s4,abc <gets+0x5e>
    cc = read(0, &c, 1);
     a90:	8656                	mv	a2,s5
     a92:	85da                	mv	a1,s6
     a94:	4501                	li	a0,0
     a96:	194000ef          	jal	c2a <read>
    if(cc < 1)
     a9a:	02a05163          	blez	a0,abc <gets+0x5e>
      break;
    buf[i++] = c;
     a9e:	faf44783          	lbu	a5,-81(s0)
     aa2:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
     aa6:	0905                	addi	s2,s2,1
     aa8:	ff678713          	addi	a4,a5,-10
     aac:	00173713          	seqz	a4,a4
     ab0:	17cd                	addi	a5,a5,-13
     ab2:	0017b793          	seqz	a5,a5
     ab6:	8fd9                	or	a5,a5,a4
     ab8:	d7f1                	beqz	a5,a84 <gets+0x26>
    buf[i++] = c;
     aba:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
     abc:	9c5e                	add	s8,s8,s7
     abe:	000c0023          	sb	zero,0(s8)
  return buf;
}
     ac2:	855e                	mv	a0,s7
     ac4:	60e6                	ld	ra,88(sp)
     ac6:	6446                	ld	s0,80(sp)
     ac8:	64a6                	ld	s1,72(sp)
     aca:	6906                	ld	s2,64(sp)
     acc:	79e2                	ld	s3,56(sp)
     ace:	7a42                	ld	s4,48(sp)
     ad0:	7aa2                	ld	s5,40(sp)
     ad2:	7b02                	ld	s6,32(sp)
     ad4:	6be2                	ld	s7,24(sp)
     ad6:	6c42                	ld	s8,16(sp)
     ad8:	6125                	addi	sp,sp,96
     ada:	8082                	ret

0000000000000adc <stat>:

int
stat(const char *n, struct stat *st)
{
     adc:	1101                	addi	sp,sp,-32
     ade:	ec06                	sd	ra,24(sp)
     ae0:	e822                	sd	s0,16(sp)
     ae2:	e04a                	sd	s2,0(sp)
     ae4:	1000                	addi	s0,sp,32
     ae6:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
     ae8:	4581                	li	a1,0
     aea:	168000ef          	jal	c52 <open>
  if(fd < 0)
     aee:	02054263          	bltz	a0,b12 <stat+0x36>
     af2:	e426                	sd	s1,8(sp)
     af4:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
     af6:	85ca                	mv	a1,s2
     af8:	172000ef          	jal	c6a <fstat>
     afc:	892a                	mv	s2,a0
  close(fd);
     afe:	8526                	mv	a0,s1
     b00:	13a000ef          	jal	c3a <close>
  return r;
     b04:	64a2                	ld	s1,8(sp)
}
     b06:	854a                	mv	a0,s2
     b08:	60e2                	ld	ra,24(sp)
     b0a:	6442                	ld	s0,16(sp)
     b0c:	6902                	ld	s2,0(sp)
     b0e:	6105                	addi	sp,sp,32
     b10:	8082                	ret
    return -1;
     b12:	57fd                	li	a5,-1
     b14:	893e                	mv	s2,a5
     b16:	bfc5                	j	b06 <stat+0x2a>

0000000000000b18 <atoi>:

int
atoi(const char *s)
{
     b18:	1141                	addi	sp,sp,-16
     b1a:	e406                	sd	ra,8(sp)
     b1c:	e022                	sd	s0,0(sp)
     b1e:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
     b20:	00054683          	lbu	a3,0(a0)
     b24:	fd06879b          	addiw	a5,a3,-48
     b28:	0ff7f793          	zext.b	a5,a5
     b2c:	4625                	li	a2,9
     b2e:	02f66963          	bltu	a2,a5,b60 <atoi+0x48>
     b32:	872a                	mv	a4,a0
  n = 0;
     b34:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
     b36:	0705                	addi	a4,a4,1
     b38:	0025179b          	slliw	a5,a0,0x2
     b3c:	9fa9                	addw	a5,a5,a0
     b3e:	0017979b          	slliw	a5,a5,0x1
     b42:	9fb5                	addw	a5,a5,a3
     b44:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
     b48:	00074683          	lbu	a3,0(a4)
     b4c:	fd06879b          	addiw	a5,a3,-48
     b50:	0ff7f793          	zext.b	a5,a5
     b54:	fef671e3          	bgeu	a2,a5,b36 <atoi+0x1e>
  return n;
}
     b58:	60a2                	ld	ra,8(sp)
     b5a:	6402                	ld	s0,0(sp)
     b5c:	0141                	addi	sp,sp,16
     b5e:	8082                	ret
  n = 0;
     b60:	4501                	li	a0,0
     b62:	bfdd                	j	b58 <atoi+0x40>

0000000000000b64 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
     b64:	1141                	addi	sp,sp,-16
     b66:	e406                	sd	ra,8(sp)
     b68:	e022                	sd	s0,0(sp)
     b6a:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
     b6c:	02b57563          	bgeu	a0,a1,b96 <memmove+0x32>
    while(n-- > 0)
     b70:	00c05f63          	blez	a2,b8e <memmove+0x2a>
     b74:	1602                	slli	a2,a2,0x20
     b76:	9201                	srli	a2,a2,0x20
     b78:	00c507b3          	add	a5,a0,a2
  dst = vdst;
     b7c:	872a                	mv	a4,a0
      *dst++ = *src++;
     b7e:	0585                	addi	a1,a1,1
     b80:	0705                	addi	a4,a4,1
     b82:	fff5c683          	lbu	a3,-1(a1)
     b86:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
     b8a:	fee79ae3          	bne	a5,a4,b7e <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
     b8e:	60a2                	ld	ra,8(sp)
     b90:	6402                	ld	s0,0(sp)
     b92:	0141                	addi	sp,sp,16
     b94:	8082                	ret
    while(n-- > 0)
     b96:	fec05ce3          	blez	a2,b8e <memmove+0x2a>
    dst += n;
     b9a:	00c50733          	add	a4,a0,a2
    src += n;
     b9e:	95b2                	add	a1,a1,a2
     ba0:	fff6079b          	addiw	a5,a2,-1
     ba4:	1782                	slli	a5,a5,0x20
     ba6:	9381                	srli	a5,a5,0x20
     ba8:	fff7c793          	not	a5,a5
     bac:	97ba                	add	a5,a5,a4
      *--dst = *--src;
     bae:	15fd                	addi	a1,a1,-1
     bb0:	177d                	addi	a4,a4,-1
     bb2:	0005c683          	lbu	a3,0(a1)
     bb6:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
     bba:	fef71ae3          	bne	a4,a5,bae <memmove+0x4a>
     bbe:	bfc1                	j	b8e <memmove+0x2a>

0000000000000bc0 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
     bc0:	1141                	addi	sp,sp,-16
     bc2:	e406                	sd	ra,8(sp)
     bc4:	e022                	sd	s0,0(sp)
     bc6:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
     bc8:	ce19                	beqz	a2,be6 <memcmp+0x26>
     bca:	1602                	slli	a2,a2,0x20
     bcc:	9201                	srli	a2,a2,0x20
     bce:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
     bd2:	00054783          	lbu	a5,0(a0)
     bd6:	0005c703          	lbu	a4,0(a1)
     bda:	00e79b63          	bne	a5,a4,bf0 <memcmp+0x30>
      return *p1 - *p2;
    }
    p1++;
     bde:	0505                	addi	a0,a0,1
    p2++;
     be0:	0585                	addi	a1,a1,1
  while (n-- > 0) {
     be2:	fed518e3          	bne	a0,a3,bd2 <memcmp+0x12>
  }
  return 0;
     be6:	4501                	li	a0,0
}
     be8:	60a2                	ld	ra,8(sp)
     bea:	6402                	ld	s0,0(sp)
     bec:	0141                	addi	sp,sp,16
     bee:	8082                	ret
      return *p1 - *p2;
     bf0:	40e7853b          	subw	a0,a5,a4
     bf4:	bfd5                	j	be8 <memcmp+0x28>

0000000000000bf6 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
     bf6:	1141                	addi	sp,sp,-16
     bf8:	e406                	sd	ra,8(sp)
     bfa:	e022                	sd	s0,0(sp)
     bfc:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
     bfe:	f67ff0ef          	jal	b64 <memmove>
}
     c02:	60a2                	ld	ra,8(sp)
     c04:	6402                	ld	s0,0(sp)
     c06:	0141                	addi	sp,sp,16
     c08:	8082                	ret

0000000000000c0a <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
     c0a:	4885                	li	a7,1
 ecall
     c0c:	00000073          	ecall
 ret
     c10:	8082                	ret

0000000000000c12 <exit>:
.global exit
exit:
 li a7, SYS_exit
     c12:	4889                	li	a7,2
 ecall
     c14:	00000073          	ecall
 ret
     c18:	8082                	ret

0000000000000c1a <wait>:
.global wait
wait:
 li a7, SYS_wait
     c1a:	488d                	li	a7,3
 ecall
     c1c:	00000073          	ecall
 ret
     c20:	8082                	ret

0000000000000c22 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
     c22:	4891                	li	a7,4
 ecall
     c24:	00000073          	ecall
 ret
     c28:	8082                	ret

0000000000000c2a <read>:
.global read
read:
 li a7, SYS_read
     c2a:	4895                	li	a7,5
 ecall
     c2c:	00000073          	ecall
 ret
     c30:	8082                	ret

0000000000000c32 <write>:
.global write
write:
 li a7, SYS_write
     c32:	48c1                	li	a7,16
 ecall
     c34:	00000073          	ecall
 ret
     c38:	8082                	ret

0000000000000c3a <close>:
.global close
close:
 li a7, SYS_close
     c3a:	48d5                	li	a7,21
 ecall
     c3c:	00000073          	ecall
 ret
     c40:	8082                	ret

0000000000000c42 <kill>:
.global kill
kill:
 li a7, SYS_kill
     c42:	4899                	li	a7,6
 ecall
     c44:	00000073          	ecall
 ret
     c48:	8082                	ret

0000000000000c4a <exec>:
.global exec
exec:
 li a7, SYS_exec
     c4a:	489d                	li	a7,7
 ecall
     c4c:	00000073          	ecall
 ret
     c50:	8082                	ret

0000000000000c52 <open>:
.global open
open:
 li a7, SYS_open
     c52:	48bd                	li	a7,15
 ecall
     c54:	00000073          	ecall
 ret
     c58:	8082                	ret

0000000000000c5a <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
     c5a:	48c5                	li	a7,17
 ecall
     c5c:	00000073          	ecall
 ret
     c60:	8082                	ret

0000000000000c62 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
     c62:	48c9                	li	a7,18
 ecall
     c64:	00000073          	ecall
 ret
     c68:	8082                	ret

0000000000000c6a <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
     c6a:	48a1                	li	a7,8
 ecall
     c6c:	00000073          	ecall
 ret
     c70:	8082                	ret

0000000000000c72 <link>:
.global link
link:
 li a7, SYS_link
     c72:	48cd                	li	a7,19
 ecall
     c74:	00000073          	ecall
 ret
     c78:	8082                	ret

0000000000000c7a <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
     c7a:	48d1                	li	a7,20
 ecall
     c7c:	00000073          	ecall
 ret
     c80:	8082                	ret

0000000000000c82 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
     c82:	48a5                	li	a7,9
 ecall
     c84:	00000073          	ecall
 ret
     c88:	8082                	ret

0000000000000c8a <dup>:
.global dup
dup:
 li a7, SYS_dup
     c8a:	48a9                	li	a7,10
 ecall
     c8c:	00000073          	ecall
 ret
     c90:	8082                	ret

0000000000000c92 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
     c92:	48ad                	li	a7,11
 ecall
     c94:	00000073          	ecall
 ret
     c98:	8082                	ret

0000000000000c9a <sbrk>:
.global sbrk
sbrk:
 li a7, SYS_sbrk
     c9a:	48b1                	li	a7,12
 ecall
     c9c:	00000073          	ecall
 ret
     ca0:	8082                	ret

0000000000000ca2 <sleep>:
.global sleep
sleep:
 li a7, SYS_sleep
     ca2:	48b5                	li	a7,13
 ecall
     ca4:	00000073          	ecall
 ret
     ca8:	8082                	ret

0000000000000caa <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
     caa:	48b9                	li	a7,14
 ecall
     cac:	00000073          	ecall
 ret
     cb0:	8082                	ret

0000000000000cb2 <ucnt_set>:
.global ucnt_set
ucnt_set:
 li a7, SYS_ucnt_set
     cb2:	48d9                	li	a7,22
 ecall
     cb4:	00000073          	ecall
 ret
     cb8:	8082                	ret

0000000000000cba <ucnt_get>:
.global ucnt_get
ucnt_get:
 li a7, SYS_ucnt_get
     cba:	48dd                	li	a7,23
 ecall
     cbc:	00000073          	ecall
 ret
     cc0:	8082                	ret

0000000000000cc2 <ubuf_write>:
.global ubuf_write
ubuf_write:
 li a7, SYS_ubuf_write
     cc2:	48e1                	li	a7,24
 ecall
     cc4:	00000073          	ecall
 ret
     cc8:	8082                	ret

0000000000000cca <ubuf_read>:
.global ubuf_read
ubuf_read:
 li a7, SYS_ubuf_read
     cca:	48e5                	li	a7,25
 ecall
     ccc:	00000073          	ecall
 ret
     cd0:	8082                	ret

0000000000000cd2 <sem_init>:
.global sem_init
sem_init:
 li a7, SYS_sem_init
     cd2:	48e9                	li	a7,26
 ecall
     cd4:	00000073          	ecall
 ret
     cd8:	8082                	ret

0000000000000cda <sem_wait>:
.global sem_wait
sem_wait:
 li a7, SYS_sem_wait
     cda:	48ed                	li	a7,27
 ecall
     cdc:	00000073          	ecall
 ret
     ce0:	8082                	ret

0000000000000ce2 <sem_signal>:
.global sem_signal
sem_signal:
 li a7, SYS_sem_signal
     ce2:	48f1                	li	a7,28
 ecall
     ce4:	00000073          	ecall
 ret
     ce8:	8082                	ret

0000000000000cea <sem_getvalue>:
.global sem_getvalue
sem_getvalue:
 li a7, SYS_sem_getvalue
     cea:	48f5                	li	a7,29
 ecall
     cec:	00000073          	ecall
 ret
     cf0:	8082                	ret

0000000000000cf2 <sem_free>:
.global sem_free
sem_free:
 li a7, SYS_sem_free
     cf2:	48f9                	li	a7,30
 ecall
     cf4:	00000073          	ecall
 ret
     cf8:	8082                	ret

0000000000000cfa <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
     cfa:	1101                	addi	sp,sp,-32
     cfc:	ec06                	sd	ra,24(sp)
     cfe:	e822                	sd	s0,16(sp)
     d00:	1000                	addi	s0,sp,32
     d02:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
     d06:	4605                	li	a2,1
     d08:	fef40593          	addi	a1,s0,-17
     d0c:	f27ff0ef          	jal	c32 <write>
}
     d10:	60e2                	ld	ra,24(sp)
     d12:	6442                	ld	s0,16(sp)
     d14:	6105                	addi	sp,sp,32
     d16:	8082                	ret

0000000000000d18 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
     d18:	715d                	addi	sp,sp,-80
     d1a:	e486                	sd	ra,72(sp)
     d1c:	e0a2                	sd	s0,64(sp)
     d1e:	f84a                	sd	s2,48(sp)
     d20:	f44e                	sd	s3,40(sp)
     d22:	0880                	addi	s0,sp,80
     d24:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
     d26:	00d036b3          	snez	a3,a3
     d2a:	03f5d793          	srli	a5,a1,0x3f
     d2e:	8efd                	and	a3,a3,a5
    neg = 1;
    x = -xx;
  } else {
    x = xx;
     d30:	0005871b          	sext.w	a4,a1
  neg = 0;
     d34:	4301                	li	t1,0
  if(sgn && xx < 0){
     d36:	c681                	beqz	a3,d3e <printint+0x26>
    x = -xx;
     d38:	40b0073b          	negw	a4,a1
    neg = 1;
     d3c:	4305                	li	t1,1
  }

  i = 0;
     d3e:	fb840993          	addi	s3,s0,-72
  neg = 0;
     d42:	85ce                	mv	a1,s3
  i = 0;
     d44:	4681                	li	a3,0
  do{
    buf[i++] = digits[x % base];
     d46:	00001817          	auipc	a6,0x1
     d4a:	87a80813          	addi	a6,a6,-1926 # 15c0 <digits>
     d4e:	88b6                	mv	a7,a3
     d50:	0016851b          	addiw	a0,a3,1
     d54:	86aa                	mv	a3,a0
     d56:	02c777bb          	remuw	a5,a4,a2
     d5a:	1782                	slli	a5,a5,0x20
     d5c:	9381                	srli	a5,a5,0x20
     d5e:	97c2                	add	a5,a5,a6
     d60:	0007c783          	lbu	a5,0(a5)
     d64:	00f58023          	sb	a5,0(a1)
  }while((x /= base) != 0);
     d68:	87ba                	mv	a5,a4
     d6a:	02c7573b          	divuw	a4,a4,a2
     d6e:	0585                	addi	a1,a1,1
     d70:	fcc7ffe3          	bgeu	a5,a2,d4e <printint+0x36>
  if(neg)
     d74:	00030b63          	beqz	t1,d8a <printint+0x72>
    buf[i++] = '-';
     d78:	fd040793          	addi	a5,s0,-48
     d7c:	953e                	add	a0,a0,a5
     d7e:	02d00793          	li	a5,45
     d82:	fef50423          	sb	a5,-24(a0)
     d86:	0028869b          	addiw	a3,a7,2

  while(--i >= 0)
     d8a:	02d05563          	blez	a3,db4 <printint+0x9c>
     d8e:	fc26                	sd	s1,56(sp)
     d90:	36fd                	addiw	a3,a3,-1
     d92:	00d984b3          	add	s1,s3,a3
     d96:	19fd                	addi	s3,s3,-1
     d98:	99b6                	add	s3,s3,a3
     d9a:	1682                	slli	a3,a3,0x20
     d9c:	9281                	srli	a3,a3,0x20
     d9e:	40d989b3          	sub	s3,s3,a3
    putc(fd, buf[i]);
     da2:	0004c583          	lbu	a1,0(s1)
     da6:	854a                	mv	a0,s2
     da8:	f53ff0ef          	jal	cfa <putc>
  while(--i >= 0)
     dac:	14fd                	addi	s1,s1,-1
     dae:	ff349ae3          	bne	s1,s3,da2 <printint+0x8a>
     db2:	74e2                	ld	s1,56(sp)
}
     db4:	60a6                	ld	ra,72(sp)
     db6:	6406                	ld	s0,64(sp)
     db8:	7942                	ld	s2,48(sp)
     dba:	79a2                	ld	s3,40(sp)
     dbc:	6161                	addi	sp,sp,80
     dbe:	8082                	ret

0000000000000dc0 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
     dc0:	711d                	addi	sp,sp,-96
     dc2:	ec86                	sd	ra,88(sp)
     dc4:	e8a2                	sd	s0,80(sp)
     dc6:	e4a6                	sd	s1,72(sp)
     dc8:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
     dca:	0005c483          	lbu	s1,0(a1)
     dce:	28048263          	beqz	s1,1052 <vprintf+0x292>
     dd2:	e0ca                	sd	s2,64(sp)
     dd4:	fc4e                	sd	s3,56(sp)
     dd6:	f852                	sd	s4,48(sp)
     dd8:	f456                	sd	s5,40(sp)
     dda:	f05a                	sd	s6,32(sp)
     ddc:	ec5e                	sd	s7,24(sp)
     dde:	e862                	sd	s8,16(sp)
     de0:	8b2a                	mv	s6,a0
     de2:	8a2e                	mv	s4,a1
     de4:	8bb2                	mv	s7,a2
  state = 0;
     de6:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
     de8:	4901                	li	s2,0
     dea:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
     dec:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
     df0:	06400c13          	li	s8,100
     df4:	a00d                	j	e16 <vprintf+0x56>
        putc(fd, c0);
     df6:	85a6                	mv	a1,s1
     df8:	855a                	mv	a0,s6
     dfa:	f01ff0ef          	jal	cfa <putc>
     dfe:	a019                	j	e04 <vprintf+0x44>
    } else if(state == '%'){
     e00:	03598363          	beq	s3,s5,e26 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
     e04:	0019079b          	addiw	a5,s2,1
     e08:	893e                	mv	s2,a5
     e0a:	873e                	mv	a4,a5
     e0c:	97d2                	add	a5,a5,s4
     e0e:	0007c483          	lbu	s1,0(a5)
     e12:	22048963          	beqz	s1,1044 <vprintf+0x284>
    c0 = fmt[i] & 0xff;
     e16:	0004879b          	sext.w	a5,s1
    if(state == 0){
     e1a:	fe0993e3          	bnez	s3,e00 <vprintf+0x40>
      if(c0 == '%'){
     e1e:	fd579ce3          	bne	a5,s5,df6 <vprintf+0x36>
        state = '%';
     e22:	89be                	mv	s3,a5
     e24:	b7c5                	j	e04 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
     e26:	00ea06b3          	add	a3,s4,a4
     e2a:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
     e2e:	22060763          	beqz	a2,105c <vprintf+0x29c>
      if(c0 == 'd'){
     e32:	0b878363          	beq	a5,s8,ed8 <vprintf+0x118>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
     e36:	f9478693          	addi	a3,a5,-108
     e3a:	0016b693          	seqz	a3,a3
     e3e:	f9c60593          	addi	a1,a2,-100
     e42:	0015b593          	seqz	a1,a1
     e46:	8df5                	and	a1,a1,a3
     e48:	e5c5                	bnez	a1,ef0 <vprintf+0x130>
      if(c1) c2 = fmt[i+2] & 0xff;
     e4a:	9752                	add	a4,a4,s4
     e4c:	00274503          	lbu	a0,2(a4)
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
     e50:	f9460713          	addi	a4,a2,-108
     e54:	00173713          	seqz	a4,a4
     e58:	8f75                	and	a4,a4,a3
     e5a:	f9c50593          	addi	a1,a0,-100
     e5e:	0015b593          	seqz	a1,a1
     e62:	8df9                	and	a1,a1,a4
     e64:	e1dd                	bnez	a1,f0a <vprintf+0x14a>
        printint(fd, va_arg(ap, uint64), 10, 1);
        i += 2;
      } else if(c0 == 'u'){
     e66:	07500593          	li	a1,117
     e6a:	0ab78d63          	beq	a5,a1,f24 <vprintf+0x164>
        printint(fd, va_arg(ap, int), 10, 0);
      } else if(c0 == 'l' && c1 == 'u'){
     e6e:	f8b60593          	addi	a1,a2,-117
     e72:	0015b593          	seqz	a1,a1
     e76:	8df5                	and	a1,a1,a3
     e78:	e1f1                	bnez	a1,f3c <vprintf+0x17c>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
     e7a:	f8b50593          	addi	a1,a0,-117
     e7e:	0015b593          	seqz	a1,a1
     e82:	8df9                	and	a1,a1,a4
     e84:	e9e9                	bnez	a1,f56 <vprintf+0x196>
        printint(fd, va_arg(ap, uint64), 10, 0);
        i += 2;
      } else if(c0 == 'x'){
     e86:	07800593          	li	a1,120
     e8a:	0eb78363          	beq	a5,a1,f70 <vprintf+0x1b0>
        printint(fd, va_arg(ap, int), 16, 0);
      } else if(c0 == 'l' && c1 == 'x'){
     e8e:	f8860613          	addi	a2,a2,-120
     e92:	00163613          	seqz	a2,a2
     e96:	8ef1                	and	a3,a3,a2
     e98:	0e069863          	bnez	a3,f88 <vprintf+0x1c8>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 1;
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
     e9c:	f8850513          	addi	a0,a0,-120
     ea0:	00153513          	seqz	a0,a0
     ea4:	8f69                	and	a4,a4,a0
     ea6:	0e071e63          	bnez	a4,fa2 <vprintf+0x1e2>
        printint(fd, va_arg(ap, uint64), 16, 0);
        i += 2;
      } else if(c0 == 'p'){
     eaa:	07000713          	li	a4,112
     eae:	10e78663          	beq	a5,a4,fba <vprintf+0x1fa>
        printptr(fd, va_arg(ap, uint64));
      } else if(c0 == 's'){
     eb2:	07300713          	li	a4,115
     eb6:	14e78663          	beq	a5,a4,1002 <vprintf+0x242>
        if((s = va_arg(ap, char*)) == 0)
          s = "(null)";
        for(; *s; s++)
          putc(fd, *s);
      } else if(c0 == '%'){
     eba:	02500713          	li	a4,37
     ebe:	16e78e63          	beq	a5,a4,103a <vprintf+0x27a>
        putc(fd, '%');
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
     ec2:	02500593          	li	a1,37
     ec6:	855a                	mv	a0,s6
     ec8:	e33ff0ef          	jal	cfa <putc>
        putc(fd, c0);
     ecc:	85a6                	mv	a1,s1
     ece:	855a                	mv	a0,s6
     ed0:	e2bff0ef          	jal	cfa <putc>
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c);
      }
#endif
      state = 0;
     ed4:	4981                	li	s3,0
     ed6:	b73d                	j	e04 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
     ed8:	008b8493          	addi	s1,s7,8
     edc:	4685                	li	a3,1
     ede:	4629                	li	a2,10
     ee0:	000ba583          	lw	a1,0(s7)
     ee4:	855a                	mv	a0,s6
     ee6:	e33ff0ef          	jal	d18 <printint>
     eea:	8ba6                	mv	s7,s1
      state = 0;
     eec:	4981                	li	s3,0
     eee:	bf19                	j	e04 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
     ef0:	008b8493          	addi	s1,s7,8
     ef4:	4685                	li	a3,1
     ef6:	4629                	li	a2,10
     ef8:	000bb583          	ld	a1,0(s7)
     efc:	855a                	mv	a0,s6
     efe:	e1bff0ef          	jal	d18 <printint>
        i += 1;
     f02:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
     f04:	8ba6                	mv	s7,s1
      state = 0;
     f06:	4981                	li	s3,0
     f08:	bdf5                	j	e04 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 1);
     f0a:	008b8493          	addi	s1,s7,8
     f0e:	4685                	li	a3,1
     f10:	4629                	li	a2,10
     f12:	000bb583          	ld	a1,0(s7)
     f16:	855a                	mv	a0,s6
     f18:	e01ff0ef          	jal	d18 <printint>
        i += 2;
     f1c:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
     f1e:	8ba6                	mv	s7,s1
      state = 0;
     f20:	4981                	li	s3,0
        i += 2;
     f22:	b5cd                	j	e04 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 0);
     f24:	008b8493          	addi	s1,s7,8
     f28:	4681                	li	a3,0
     f2a:	4629                	li	a2,10
     f2c:	000ba583          	lw	a1,0(s7)
     f30:	855a                	mv	a0,s6
     f32:	de7ff0ef          	jal	d18 <printint>
     f36:	8ba6                	mv	s7,s1
      state = 0;
     f38:	4981                	li	s3,0
     f3a:	b5e9                	j	e04 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
     f3c:	008b8493          	addi	s1,s7,8
     f40:	4681                	li	a3,0
     f42:	4629                	li	a2,10
     f44:	000bb583          	ld	a1,0(s7)
     f48:	855a                	mv	a0,s6
     f4a:	dcfff0ef          	jal	d18 <printint>
        i += 1;
     f4e:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
     f50:	8ba6                	mv	s7,s1
      state = 0;
     f52:	4981                	li	s3,0
     f54:	bd45                	j	e04 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
     f56:	008b8493          	addi	s1,s7,8
     f5a:	4681                	li	a3,0
     f5c:	4629                	li	a2,10
     f5e:	000bb583          	ld	a1,0(s7)
     f62:	855a                	mv	a0,s6
     f64:	db5ff0ef          	jal	d18 <printint>
        i += 2;
     f68:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
     f6a:	8ba6                	mv	s7,s1
      state = 0;
     f6c:	4981                	li	s3,0
        i += 2;
     f6e:	bd59                	j	e04 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 16, 0);
     f70:	008b8493          	addi	s1,s7,8
     f74:	4681                	li	a3,0
     f76:	4641                	li	a2,16
     f78:	000ba583          	lw	a1,0(s7)
     f7c:	855a                	mv	a0,s6
     f7e:	d9bff0ef          	jal	d18 <printint>
     f82:	8ba6                	mv	s7,s1
      state = 0;
     f84:	4981                	li	s3,0
     f86:	bdbd                	j	e04 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
     f88:	008b8493          	addi	s1,s7,8
     f8c:	4681                	li	a3,0
     f8e:	4641                	li	a2,16
     f90:	000bb583          	ld	a1,0(s7)
     f94:	855a                	mv	a0,s6
     f96:	d83ff0ef          	jal	d18 <printint>
        i += 1;
     f9a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
     f9c:	8ba6                	mv	s7,s1
      state = 0;
     f9e:	4981                	li	s3,0
     fa0:	b595                	j	e04 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
     fa2:	008b8493          	addi	s1,s7,8
     fa6:	4641                	li	a2,16
     fa8:	000bb583          	ld	a1,0(s7)
     fac:	855a                	mv	a0,s6
     fae:	d6bff0ef          	jal	d18 <printint>
        i += 2;
     fb2:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
     fb4:	8ba6                	mv	s7,s1
      state = 0;
     fb6:	4981                	li	s3,0
        i += 2;
     fb8:	b5b1                	j	e04 <vprintf+0x44>
     fba:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
     fbc:	008b8793          	addi	a5,s7,8
     fc0:	8cbe                	mv	s9,a5
     fc2:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
     fc6:	03000593          	li	a1,48
     fca:	855a                	mv	a0,s6
     fcc:	d2fff0ef          	jal	cfa <putc>
  putc(fd, 'x');
     fd0:	07800593          	li	a1,120
     fd4:	855a                	mv	a0,s6
     fd6:	d25ff0ef          	jal	cfa <putc>
     fda:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
     fdc:	00000b97          	auipc	s7,0x0
     fe0:	5e4b8b93          	addi	s7,s7,1508 # 15c0 <digits>
     fe4:	03c9d793          	srli	a5,s3,0x3c
     fe8:	97de                	add	a5,a5,s7
     fea:	0007c583          	lbu	a1,0(a5)
     fee:	855a                	mv	a0,s6
     ff0:	d0bff0ef          	jal	cfa <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
     ff4:	0992                	slli	s3,s3,0x4
     ff6:	34fd                	addiw	s1,s1,-1
     ff8:	f4f5                	bnez	s1,fe4 <vprintf+0x224>
        printptr(fd, va_arg(ap, uint64));
     ffa:	8be6                	mv	s7,s9
      state = 0;
     ffc:	4981                	li	s3,0
     ffe:	6ca2                	ld	s9,8(sp)
    1000:	b511                	j	e04 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
    1002:	008b8993          	addi	s3,s7,8
    1006:	000bb483          	ld	s1,0(s7)
    100a:	cc91                	beqz	s1,1026 <vprintf+0x266>
        for(; *s; s++)
    100c:	0004c583          	lbu	a1,0(s1)
    1010:	c195                	beqz	a1,1034 <vprintf+0x274>
          putc(fd, *s);
    1012:	855a                	mv	a0,s6
    1014:	ce7ff0ef          	jal	cfa <putc>
        for(; *s; s++)
    1018:	0485                	addi	s1,s1,1
    101a:	0004c583          	lbu	a1,0(s1)
    101e:	f9f5                	bnez	a1,1012 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
    1020:	8bce                	mv	s7,s3
      state = 0;
    1022:	4981                	li	s3,0
    1024:	b3c5                	j	e04 <vprintf+0x44>
          s = "(null)";
    1026:	00000497          	auipc	s1,0x0
    102a:	53248493          	addi	s1,s1,1330 # 1558 <malloc+0x400>
        for(; *s; s++)
    102e:	02800593          	li	a1,40
    1032:	b7c5                	j	1012 <vprintf+0x252>
        if((s = va_arg(ap, char*)) == 0)
    1034:	8bce                	mv	s7,s3
      state = 0;
    1036:	4981                	li	s3,0
    1038:	b3f1                	j	e04 <vprintf+0x44>
        putc(fd, '%');
    103a:	85be                	mv	a1,a5
    103c:	855a                	mv	a0,s6
    103e:	cbdff0ef          	jal	cfa <putc>
    1042:	bd49                	j	ed4 <vprintf+0x114>
    1044:	6906                	ld	s2,64(sp)
    1046:	79e2                	ld	s3,56(sp)
    1048:	7a42                	ld	s4,48(sp)
    104a:	7aa2                	ld	s5,40(sp)
    104c:	7b02                	ld	s6,32(sp)
    104e:	6be2                	ld	s7,24(sp)
    1050:	6c42                	ld	s8,16(sp)
    }
  }
}
    1052:	60e6                	ld	ra,88(sp)
    1054:	6446                	ld	s0,80(sp)
    1056:	64a6                	ld	s1,72(sp)
    1058:	6125                	addi	sp,sp,96
    105a:	8082                	ret
      if(c0 == 'd'){
    105c:	06400713          	li	a4,100
    1060:	e6e78ce3          	beq	a5,a4,ed8 <vprintf+0x118>
      } else if(c0 == 'l' && c1 == 'd'){
    1064:	f9478693          	addi	a3,a5,-108
    1068:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
    106c:	8532                	mv	a0,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    106e:	4701                	li	a4,0
    1070:	bbdd                	j	e66 <vprintf+0xa6>

0000000000001072 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
    1072:	715d                	addi	sp,sp,-80
    1074:	ec06                	sd	ra,24(sp)
    1076:	e822                	sd	s0,16(sp)
    1078:	1000                	addi	s0,sp,32
    107a:	e010                	sd	a2,0(s0)
    107c:	e414                	sd	a3,8(s0)
    107e:	e818                	sd	a4,16(s0)
    1080:	ec1c                	sd	a5,24(s0)
    1082:	03043023          	sd	a6,32(s0)
    1086:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
    108a:	8622                	mv	a2,s0
    108c:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
    1090:	d31ff0ef          	jal	dc0 <vprintf>
}
    1094:	60e2                	ld	ra,24(sp)
    1096:	6442                	ld	s0,16(sp)
    1098:	6161                	addi	sp,sp,80
    109a:	8082                	ret

000000000000109c <printf>:

void
printf(const char *fmt, ...)
{
    109c:	711d                	addi	sp,sp,-96
    109e:	ec06                	sd	ra,24(sp)
    10a0:	e822                	sd	s0,16(sp)
    10a2:	1000                	addi	s0,sp,32
    10a4:	e40c                	sd	a1,8(s0)
    10a6:	e810                	sd	a2,16(s0)
    10a8:	ec14                	sd	a3,24(s0)
    10aa:	f018                	sd	a4,32(s0)
    10ac:	f41c                	sd	a5,40(s0)
    10ae:	03043823          	sd	a6,48(s0)
    10b2:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
    10b6:	00840613          	addi	a2,s0,8
    10ba:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
    10be:	85aa                	mv	a1,a0
    10c0:	4505                	li	a0,1
    10c2:	cffff0ef          	jal	dc0 <vprintf>
}
    10c6:	60e2                	ld	ra,24(sp)
    10c8:	6442                	ld	s0,16(sp)
    10ca:	6125                	addi	sp,sp,96
    10cc:	8082                	ret

00000000000010ce <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
    10ce:	1141                	addi	sp,sp,-16
    10d0:	e406                	sd	ra,8(sp)
    10d2:	e022                	sd	s0,0(sp)
    10d4:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
    10d6:	ff050713          	addi	a4,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    10da:	00001797          	auipc	a5,0x1
    10de:	f367b783          	ld	a5,-202(a5) # 2010 <freep>
    10e2:	a095                	j	1146 <free+0x78>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
      break;
  if(bp + bp->s.size == p->s.ptr){
    10e4:	ff852583          	lw	a1,-8(a0)
    10e8:	6390                	ld	a2,0(a5)
    10ea:	02059813          	slli	a6,a1,0x20
    10ee:	01c85693          	srli	a3,a6,0x1c
    10f2:	96ba                	add	a3,a3,a4
    10f4:	02d60563          	beq	a2,a3,111e <free+0x50>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
    10f8:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    10fc:	4790                	lw	a2,8(a5)
    10fe:	02061593          	slli	a1,a2,0x20
    1102:	01c5d693          	srli	a3,a1,0x1c
    1106:	96be                	add	a3,a3,a5
    1108:	02d70263          	beq	a4,a3,112c <free+0x5e>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
    110c:	e398                	sd	a4,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
    110e:	00001717          	auipc	a4,0x1
    1112:	f0f73123          	sd	a5,-254(a4) # 2010 <freep>
}
    1116:	60a2                	ld	ra,8(sp)
    1118:	6402                	ld	s0,0(sp)
    111a:	0141                	addi	sp,sp,16
    111c:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
    111e:	4614                	lw	a3,8(a2)
    1120:	9ead                	addw	a3,a3,a1
    1122:	fed52c23          	sw	a3,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
    1126:	6394                	ld	a3,0(a5)
    1128:	6290                	ld	a2,0(a3)
    112a:	b7f9                	j	10f8 <free+0x2a>
    p->s.size += bp->s.size;
    112c:	ff852703          	lw	a4,-8(a0)
    1130:	9f31                	addw	a4,a4,a2
    1132:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
    1134:	ff053703          	ld	a4,-16(a0)
    1138:	bfd1                	j	110c <free+0x3e>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    113a:	6394                	ld	a3,0(a5)
    113c:	00d7e463          	bltu	a5,a3,1144 <free+0x76>
    1140:	fad762e3          	bltu	a4,a3,10e4 <free+0x16>
    1144:	87b6                	mv	a5,a3
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    1146:	fee7fae3          	bgeu	a5,a4,113a <free+0x6c>
    114a:	6394                	ld	a3,0(a5)
    114c:	f8d76ce3          	bltu	a4,a3,10e4 <free+0x16>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    1150:	f8d7fae3          	bgeu	a5,a3,10e4 <free+0x16>
    1154:	87b6                	mv	a5,a3
    1156:	bfc5                	j	1146 <free+0x78>

0000000000001158 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
    1158:	7139                	addi	sp,sp,-64
    115a:	fc06                	sd	ra,56(sp)
    115c:	f822                	sd	s0,48(sp)
    115e:	f04a                	sd	s2,32(sp)
    1160:	ec4e                	sd	s3,24(sp)
    1162:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    1164:	02051993          	slli	s3,a0,0x20
    1168:	0209d993          	srli	s3,s3,0x20
    116c:	09bd                	addi	s3,s3,15
    116e:	0049d993          	srli	s3,s3,0x4
    1172:	2985                	addiw	s3,s3,1
    1174:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
    1176:	00001517          	auipc	a0,0x1
    117a:	e9a53503          	ld	a0,-358(a0) # 2010 <freep>
    117e:	c905                	beqz	a0,11ae <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    1180:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    1182:	4798                	lw	a4,8(a5)
    1184:	09377663          	bgeu	a4,s3,1210 <malloc+0xb8>
    1188:	f426                	sd	s1,40(sp)
    118a:	e852                	sd	s4,16(sp)
    118c:	e456                	sd	s5,8(sp)
    118e:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
    1190:	8a4e                	mv	s4,s3
    1192:	6705                	lui	a4,0x1
    1194:	00e9f363          	bgeu	s3,a4,119a <malloc+0x42>
    1198:	6a05                	lui	s4,0x1
    119a:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
    119e:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
    11a2:	00001497          	auipc	s1,0x1
    11a6:	e6e48493          	addi	s1,s1,-402 # 2010 <freep>
  if(p == (char*)-1)
    11aa:	5afd                	li	s5,-1
    11ac:	a83d                	j	11ea <malloc+0x92>
    11ae:	f426                	sd	s1,40(sp)
    11b0:	e852                	sd	s4,16(sp)
    11b2:	e456                	sd	s5,8(sp)
    11b4:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
    11b6:	00001797          	auipc	a5,0x1
    11ba:	25278793          	addi	a5,a5,594 # 2408 <base>
    11be:	00001717          	auipc	a4,0x1
    11c2:	e4f73923          	sd	a5,-430(a4) # 2010 <freep>
    11c6:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
    11c8:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
    11cc:	b7d1                	j	1190 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
    11ce:	6398                	ld	a4,0(a5)
    11d0:	e118                	sd	a4,0(a0)
    11d2:	a899                	j	1228 <malloc+0xd0>
  hp->s.size = nu;
    11d4:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
    11d8:	0541                	addi	a0,a0,16
    11da:	ef5ff0ef          	jal	10ce <free>
  return freep;
    11de:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
    11e0:	c125                	beqz	a0,1240 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    11e2:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    11e4:	4798                	lw	a4,8(a5)
    11e6:	03277163          	bgeu	a4,s2,1208 <malloc+0xb0>
    if(p == freep)
    11ea:	6098                	ld	a4,0(s1)
    11ec:	853e                	mv	a0,a5
    11ee:	fef71ae3          	bne	a4,a5,11e2 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
    11f2:	8552                	mv	a0,s4
    11f4:	aa7ff0ef          	jal	c9a <sbrk>
  if(p == (char*)-1)
    11f8:	fd551ee3          	bne	a0,s5,11d4 <malloc+0x7c>
        return 0;
    11fc:	4501                	li	a0,0
    11fe:	74a2                	ld	s1,40(sp)
    1200:	6a42                	ld	s4,16(sp)
    1202:	6aa2                	ld	s5,8(sp)
    1204:	6b02                	ld	s6,0(sp)
    1206:	a03d                	j	1234 <malloc+0xdc>
    1208:	74a2                	ld	s1,40(sp)
    120a:	6a42                	ld	s4,16(sp)
    120c:	6aa2                	ld	s5,8(sp)
    120e:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
    1210:	fae90fe3          	beq	s2,a4,11ce <malloc+0x76>
        p->s.size -= nunits;
    1214:	4137073b          	subw	a4,a4,s3
    1218:	c798                	sw	a4,8(a5)
        p += p->s.size;
    121a:	02071693          	slli	a3,a4,0x20
    121e:	01c6d713          	srli	a4,a3,0x1c
    1222:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
    1224:	0137a423          	sw	s3,8(a5)
      freep = prevp;
    1228:	00001717          	auipc	a4,0x1
    122c:	dea73423          	sd	a0,-536(a4) # 2010 <freep>
      return (void*)(p + 1);
    1230:	01078513          	addi	a0,a5,16
  }
}
    1234:	70e2                	ld	ra,56(sp)
    1236:	7442                	ld	s0,48(sp)
    1238:	7902                	ld	s2,32(sp)
    123a:	69e2                	ld	s3,24(sp)
    123c:	6121                	addi	sp,sp,64
    123e:	8082                	ret
    1240:	74a2                	ld	s1,40(sp)
    1242:	6a42                	ld	s4,16(sp)
    1244:	6aa2                	ld	s5,8(sp)
    1246:	6b02                	ld	s6,0(sp)
    1248:	b7f5                	j	1234 <malloc+0xdc>
